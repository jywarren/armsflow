package CAIDA::AppPorts::PortMatch;
require 5.004;
## $Id: PortMatch.pm,v 1.12 2007/06/06 18:17:44 kkeys Exp $ $Name: release-3-8-1 $
## -----------------------------------------------------------------------
## Perl module: PortMatch.pm
## 
## This Perl module serves as an access mechanism to a quasi rule-based
## list of Internet Application Ports that may be of interest to 
## monitoring and analysis software.  It's initial "customer" will be
## the CoralReef Report generator: t2_report.  However, other 
## CoralReef applications are expected to also eventually use this 
## scheme for dealing with application ports.
##
## Note: test routines require the Test.pm module or Perl 5.005
##
## Copyright 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
## All Rights Reserved 
##
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
##
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
##
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
##
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
##
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program. Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
##
## Contact: coral-info@caida.org
## ---------------------------------------------------------------------

# Set up object export condition.  No functions accessible directly.
use Exporter ();
@ISA       = qw(Exporter);
@EXPORT    = qw();

# Define required CVS variables
$cvs_Id = '$Id: PortMatch.pm,v 1.12 2007/06/06 18:17:44 kkeys Exp $';
$cvs_Author = '$Author: kkeys $';
$cvs_Name = '$Name: release-3-8-1 $';
$cvs_Revision = '$Revision: 1.12 $';

# Enable error messages to come from calling script
use Carp;

# Force this module to adhere to safe programming practices.
use strict;
use FileHandle;

# Make the module able to deal with
use CGI qw(:all);

# Version of module
my $VERSION = 1.0;

# .   .   .   .   .  Internal object functions  .   .   .   .   .   .   .  

sub _string2ref($ ) {
# ----------------------------------------------
# Internal function to convert either single
# values or ranges into an array ref.
# ----------------------------------------------
    my $string = shift;

    if ($string eq "*") {
	return([0,65535]);
    } elsif ($string =~ /^\d+$/) {
	return([int($string), int($string)]);
    } elsif ($string =~ /-/ ) {
	my ($low, $high) = split(/-/, $string);
	return([int($low), int($high)]);
    } else {
	die "Unknown descriptor type given to PortMap object: ``$string''\n";
    }
}

sub _ref2string($ ) {
# ----------------------------------------------
# Internal function to convert array ref
# intervals into either single values or hyphen
# marked ranges.
# ----------------------------------------------
    my ($low, $high) = @{shift( @_)};

    if ($low == $high) {
	return($low);
    } elsif ($low == 0 and $high == 65535) {
	return "*";
    } else {
	return("$low-$high");
    }
}

# .   .   .   .   .  User Method Subroutines  .   .   .   .   .   .   .   .  

sub new ($$ ) {
# ----------------------------------------------
# Constructor for PortMatch object.  It does the
# usual memory allocation and calls appropriate
# routines if arguments to initialize are 
# provided 
# ----------------------------------------------
    # retrieve parameters
    my ($self, $port_data) = @_;
    my $type = ref($self) || $self;
    my $result;

    # If there is data to initialize object, try.
    if (!defined($port_data)) {
	die "PortMatch constructor needs port data\n";
    }

    # special case single numeric element
    # XXX is there a faster test?
    # maybe just make merge_match take integer or PortMap?
    #if ($port_data + 0 eq $port_data) {
    if ($port_data =~ /^\d+$/) {
	$port_data = int($port_data);
	$result = [1, [$port_data, $port_data] ];
    } else {
	$result = _string2ports($port_data);
    }

    bless $result, $type;
    return $result;
}


sub _string2ports($$ ) {
# ----------------------------------------------
# High level method to convert a string of 
# application ports into a sorted list of
# intervals.
# ----------------------------------------------
    my $interval_str = shift;

    # Convert string into a list of values
    my @intervals = split(/,/, $interval_str);

    # Convert values into a list of ranges
    @intervals = map {_string2ref($_)} @intervals;

    # Sort the ranges
    @intervals = sort{$a->[0] <=> $b->[0]} @intervals;
    # XXX do sanity checks here.

    return [scalar(@intervals), @intervals];
}

sub ports2string($ ) {
# ---------------------------------------------
# Method to convert internal representation of
# a set of port numbers into a string suitable
# for output.
# --------------------------------------------
    my $match_obj = shift;
    my @intervals = @{$match_obj};

    shift @intervals;
    return(join(',', map {_ref2string($_)} @intervals));
}

sub merge_match($$ ) {
# ---------------------------------------------
# Method to match one object with another.
# Process is a variation of merge sort.
# It depends on entries being sorted to start 
# with.
# ---------------------------------------------
    my $match_obj = shift;
    my $merge_obj = shift;

    my $match_len = $match_obj->[0];
    my $merge_len = $merge_obj->[0];

    my ($i, $j) = (1, 1);

    while (($i <= $match_len) and ($j <= $merge_len)) {
	my $match = $match_obj->[$i];
	my $merge = $merge_obj->[$j];
	my $match_low = $match->[0];
	my $match_high = $match->[1];
	my $merge_low = $merge->[0];
	my $merge_high = $merge->[1];

	# Match by elimination. 
	if ($match_high < $merge_low) { # Lower than other interval.
	    $i++;
	} 
	elsif ($merge_high < $match_low) { # Higher than other interval
	    $j++;
	} else {
	    return(1); # If we reach here must be an overlap.
	}
    }
    return(0); # If we reach here none of the groups matched.
}

# =============================
# POD Documentation for Module

__END__

=head1 NAME

PortMatch.pm - Application name lookup from port numbers.

=head1 SYNOPSIS

    # Use module
    use CAIDA::AppPorts;
    # Or Use module with optionally defined names for rule fields.
    use CAIDA::AppPorts qw(:FIELD_NAMES); 

	
=head1 DESCRIPTION


=head1 AUTHOR

CoralReef Development team, CAIDA <coral-info@caida.org>

=head1 COPYRIGHT

Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
All Rights Reserved 

Permission to use, copy, modify and distribute any part of this
CoralReef software package for educational, research and non-profit
purposes, without fee, and without a written agreement is hereby
granted, provided that the above copyright notice, this paragraph
and the following paragraphs appear in all copies.

Those desiring to incorporate this into commercial products or use
for commercial purposes should contact the Technology Transfer
Office, University of California, San Diego, 9500 Gilman Drive, La
Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.

IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
THE POSSIBILITY OF SUCH DAMAGE.

THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
ANY PATENT, TRADEMARK OR OTHER RIGHTS.

The CoralReef software package is developed by the CoralReef
development team at the University of California, San Diego under
the Cooperative Association for Internet Data Analysis (CAIDA)
Program. Support for this effort is provided by the CAIDA grant
NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
N66001-01-1-8909, and by CAIDA members.

Report bugs and suggestions to coral-bugs@caida.org.

=cut

#  .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   . 
1; ##must be last line in the file
