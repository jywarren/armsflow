#!/usr/bin/perl
#package CAIDA::Traffic2::vpvc_data;
#require 5.004;
## $Id: t2_vpvc_data_test.pl,v 1.14 2007/06/06 18:17:36 kkeys Exp $ $Name: release-3-8-1 $
##
## -----------------------------------------------------------------------
## Test program vpvc_data_test.pl.
## Script as first pass towards Perl module to collect and summarize
## data from vpvc pair.
##
## Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
## All Rights Reserved 
##
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
##
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
##
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
##
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
##
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program. Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
##
## Contact: coral-info@caida.org
## ---------------------------------------------------------------------

use Exporter ();
@ISA       = qw(Exporter);
@EXPORT    = qw(process_table_title collect_table_parameters 
				retrieve_table_info get_line
			   );
@EXPORT_OK = qw();

# Enable error messages to come from calling script
use Carp;

# Force this module to adhere to safe programming practices.
use strict;

# Use Perl text wrapping facilities
use Text::Wrap;

# Declare global constants
use vars qw($rows_per_page);
$rows_per_page = 30;

# Version of module
use vars qw($VERSION);
$VERSION = 1.0;

# Replace with static local if possible.
use vars qw($look_ahead $matrix_title);

# Define required CVS variables
use vars qw($cvs_Id $cvs_Author $cvs_Name $cvs_Revision);
$cvs_Id = '$Id: t2_vpvc_data_test.pl,v 1.14 2007/06/06 18:17:36 kkeys Exp $';
$cvs_Author = '$Author: kkeys $';
$cvs_Name = '$Name: release-3-8-1 $';
$cvs_Revision = '$Revision: 1.14 $';

# .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .  

# Need to write constructor object when I get there
# sub new(??? {

# .   .   .   .   .  Internal object functions  .   .   .   .   .   .   .  

sub get_line($$) {
# ----------------------------------------------------
# Function to get a line of input from the specified
# filehandle with a twist.  If the flag is 0 then it
# returns the line from the previous read.
# Implements a poor-mans parse "look ahead" 
# capability.
# ----------------------------------------------------
	my ($filehdl_ref, $flag) = @_;


	# If flag is 0 return same line, else read new line
	if($flag) {
		$look_ahead = <$filehdl_ref>;
		chomp($look_ahead);
		return($look_ahead);
	} else {
		return($look_ahead);
	}
}

sub _is_blank_line($) {
# ---------------------------------------------------
# Small helper function (predicate) to determine if 
# the argument is an empty line
# ---------------------------------------------------
	my $data_line = shift;

	return($data_line =~ /^\s*$/);
}

sub _is_shell_comment($) {
# ----------------------------------------------------
# Helper predicate to determine if the argument is a
# title.  Titles are commented lines without
# tab characters and not starting with a number.
# ----------------------------------------------------
	my $data_line = shift;

	return($data_line =~ /^\#\s*\w+.*$/)
}

sub _is_table_parameter($) {
# ----------------------------------------------------
# Helper predicate to determine if a line is some 
# parameter concerning the the table.  Parameters are
# assumed to start with a number at the very start
# of the comment line.
# ----------------------------------------------------
	my $data_line = shift;

	$data_line =~ /^\#(\d+.+)/;
	return($1);
}

## Main routine test
my %tuples;
my $data_line;
my @data_array;
my $tuple_key;
my @xfer_array;
my ($file_version, $vpvc_pair, $unknown_encaps, $not_ipv4, $pkts, $bytes);

# traffic2 output version: 0.2
# for if  0 vp:vc    20:62
# unknown_encaps: 0
#       not_ipv4: 0
#           pkts: 32292
#          bytes: 3350521
while(defined($data_line = <STDIN>) and _is_shell_comment($data_line)) {
	if($data_line =~ /traffic2 output version: (\d+\.\d+)/) {
		$file_version = $1;
		print("File version is: $file_version\n");
	}
	elsif($data_line =~ /vp\:vc\s+(\d+\:\d+)/) {
		$vpvc_pair = $1;
		print("VP VC pair is: $vpvc_pair\n");
	}
	elsif($data_line =~ /unknown_encaps:\s(\d+)/) {
		$unknown_encaps = $1*1;
	}
	elsif($data_line =~ /not_ipv4:\s(\d+)/) {
		$not_ipv4 = $1*1;
	}
	elsif($data_line =~ /pkts: (\d+)/) {
		$pkts = $1*1;
	}
	elsif($data_line =~ /bytes: (\d+)/) {
		$bytes = $1*1;
	}
	elsif($data_line =~ /\#src/) {
	} else {
		die "Unrecognized vpvc data table format: $data_line $|";
	}
}
do {
	@data_array = split(/\s+/, $data_line);
	$tuple_key = join("\t", @data_array[0..1], @data_array[4..5]);
	if(exists($tuples{$tuple_key})) {
		@xfer_array = $tuples{$tuple_key};
		$tuples{$tuple_key} = [$xfer_array[0]+$data_array[6],
							   $xfer_array[1]+$data_array[7]
							  ];
	} else {
		$tuples{$tuple_key} = [@data_array[6..7]];
	}
} while(defined($data_line = <STDIN>) and 
	  not _is_shell_comment($data_line)
	  ); 

print("\n\n");
print("file_version: $file_version\n");
print("vpvc_pair $vpvc_pair\n");
print("unknown_encaps $unknown_encaps\n");
print("not_ipv4: $not_ipv4\n");
print("Packets: $pkts\n"); 
print("Bytes: $bytes\n\n");

foreach $data_line (sort (keys %tuples)) {
	print($data_line, "\t", ${$tuples{$data_line}}[0], " ");
	print(${$tuples{$data_line}}[1], "\n");
}

# .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .  
# Remove restriction for end developers
no strict;
1; ##must be last line in the file
