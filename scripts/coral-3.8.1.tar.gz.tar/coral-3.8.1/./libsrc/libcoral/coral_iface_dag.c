/*
 * Copyright 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/* High-level functions for Waikato DAG interfaces (devices or tracefiles).
 *
 *  $Id: coral_iface_dag.c,v 1.83 2007/06/06 18:17:53 kkeys Exp $
 *
 */

#include "config.h"
#include "coraldefs.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/param.h>
#include <time.h>

#include "libcoral.h"
#include "libcoral_priv.h"
#include "coral_clock.h"
#include "coral_dag.h"

/* These aren't visible to user, but they help optimization in libcoral. */
typedef struct {
    coral_timestamp_t t;
    uint32_t wand_crc;
    union atm_hdr cu;
    union {
	char payload[ATM_PAYLOAD_SIZE];
    } p;
} coral_dag_atm_cell_t;

static const char RCSid[] = "$Id: coral_iface_dag.c,v 1.83 2007/06/06 18:17:53 kkeys Exp $";

/* always little endian */	/* XXX */
static inline void dag_clock_order(const coral_iface_t *iface,
    const coral_timestamp_t *src, coral_timestamp_t *dst)
{
    dst->i[0] = crl_letohl(src->i[1]);
    dst->i[1] = crl_letohl(src->i[0]);
    /* not the same as dst->i64 = crl_letoh64(src->i64); */
}

static inline void coral_dag_clock_timespec(const coral_iface_t *iface,
    const coral_timestamp_t *t, struct timespec *tspec)
{
    tspec->tv_sec = crl_letohl(t->i[1]);
    tspec->tv_nsec = crl_letohl(t->i[0]) / 4.294967296 + .5;
}

inline void coral_dag_clock_native(const coral_iface_t *iface,
    const struct timespec *src, coral_timestamp_t *dst)
{
    coral_timestamp_t to;

    to.i[0] = src->tv_sec;
    to.i[1] = src->tv_nsec * 4.294967296 + .5;

    dst->i[0] = crl_htolel(to.i[1]);
    dst->i[1] = crl_htolel(to.i[0]);
    /* not the same as dst->i64 = crl_letoh64(to.i64); */
}

void coral_timestamp_to_dag_clock(coral_iface_t *iface,
    const coral_timestamp_t *src, coral_timestamp_t *dst)
{
    if (coral_interface_get_type(iface) == CORAL_TYPE_DAG) {
	/* copy dag timestamp directly */
	*dst = *src;
    } else {
	/* any timestamp -> timespec -> hostorder dag time -> dag time */
	struct timespec t;

	coral_read_clock_timespec(iface, src, &t);
	coral_dag_clock_native(iface, &t, dst);
    }
}

void coral_dag_update_pkt_stats(coral_iface_t *iface)
{
    int cur_drop = ntohs(iface->cur_pkt_stats.pkts_drop);
    iface->pkt_stats.pkts_drop = cur_drop - iface->old_pkt_stats.pkts_drop;
    iface->old_pkt_stats.pkts_drop = cur_drop;
    if (iface->pkt_stats.pkts_drop && cur_drop == 0xFFFF)
	coral_diag(1, ("%s: pkt drop counter overflow; future drops will not "
	    "be reported.\n", iface->src->filename));
}

int coral_header_is_dagfile(const char *buffer, int len)
{
    coral_dag_erf_hdr_t *hdr;
    ssize_t slen, wlen;
    struct timespec t;
    time_t min_time = 915177600; /* 1999-01-01, before DAG std timestamps */
    time_t max_time = time(NULL) + 3600; /* now, plus some wiggle room */

    if (len < sizeof(*hdr))
	return 0;
    hdr = (coral_dag_erf_hdr_t *)buffer;

    if (hdr->type != DAG_TYPE_HDLC_POS &&
	hdr->type != DAG_TYPE_ETH &&
	hdr->type != DAG_TYPE_ATM &&
	hdr->type != DAG_TYPE_AAL5)
	    return 0;

    slen = crl_ntohs(hdr->rlen) - sizeof(*hdr);
    if (slen < 32 || slen > 2048 || slen % 4 != 0)
	return 0;

    wlen = crl_ntohs(hdr->wlen);
    if (hdr->flags & DAG_FLAG_VARLEN) {
	if (slen > wlen)
	    return 0;
    }

    coral_dag_clock_timespec(NULL, &hdr->t, &t); /* doesn't use 1st arg */
    if (t.tv_sec < min_time || t.tv_sec > max_time)
	return 0;

    return 1;
}

static inline coral_dag_erf_hdr_t *coral_dag_queued_hdr(coral_iface_t *iface)
{
    return (coral_dag_erf_hdr_t*)iface->pktq_head->rec;
}


static inline coral_dag_erf_hdr_t *coral_dag_novarlen_hdr(
    coral_iface_t *target_iface, coral_iface_t *iface0)
{
    return coral_iccell(iface0);
}

static inline coral_dag_erf_hdr_t *coral_dag_varlen_hdr(coral_iface_t *iface0)
{
    uint16_t rlen;
    coral_dag_erf_hdr_t *hdr;
    coral_source_t *src = iface0->src;

    if (iface0->u.vblk.current + sizeof(coral_dag_erf_hdr_t) >
	iface0->u.vblk.block + iface0->u.vblk.end)
    {
	coral_diag(19, ("%s: header wraps at end of blk\n",
	    iface0->src->filename));
	if (!src->type.read_raw(src)) /* may move vblk->current */
	    return NULL;
    }

    hdr = (coral_dag_erf_hdr_t*)iface0->u.vblk.current;
    rlen = ntohs(hdr->rlen);

    if (iface0->u.vblk.current + rlen >
	iface0->u.vblk.block + iface0->u.vblk.end)
    {
	coral_diag(19, ("%s: record wraps at end of blk\n",
	    iface0->src->filename));
	if (!src->type.read_raw(src)) /* may move vblk->current */
	    return NULL;
	hdr = (coral_dag_erf_hdr_t*)iface0->u.vblk.current;
    }

    iface0->u.vblk.current += rlen;

    return hdr;
}

static inline void coral_dag_queue_pkt(coral_iface_t *iface,
    coral_dag_erf_hdr_t *hdr)
{
    coral_pktq_node_t *node;
    coral_source_t *src = iface->src;

    /* get a pktq node from freelist */
    node = src->pktq_freelist;
    src->pktq_freelist = src->pktq_freelist->srcnext;
    node->rec = (char*)hdr;
    src->pktq_size++;
    /* insert node at tail of iface's queue */
    node->ifnext = NULL;
    *(iface->pktq_tail ? &iface->pktq_tail->ifnext : &iface->pktq_head) =
	node;
    iface->pktq_tail = node;
    /* insert node at tail of src's queue */
    node->srcnext = NULL;
    node->srcprev = src->pktq_tail;
    *(src->pktq_tail ? &src->pktq_tail->srcnext : &src->pktq_head) = node;
    src->pktq_tail = node;
}

static inline int coral_dag_erf_prep_pkt(coral_iface_t *iface,
    coral_dag_erf_hdr_t *hdr)
{
    uint16_t rlen, wlen;

    iface->src->current_iface = iface;

    rlen = ntohs(hdr->rlen);
    wlen = ntohs(hdr->wlen);

    /* rlen includes ERF header */
    iface->packetbuf.caplen = rlen - coral_cell_field_offset(iface, PAYLOAD);

    /* TODO: handle offset in ETH records.  But remember to ignore offset in
     * 3.5E format. */

    /* Whether the wlen includes 2 bytes for FCS may depend on DAG version
     * and PHY type, and is poorly documented.  If we incorrectly don't
     * subtract, little harm is done:  the caplen is still correct, and
     * the layer 2 or 3 protocol header will indicate the correct length
     * anyway.  OTOH, if we incorrectly subtract from wlen, we will truncate
     * a perfectly good packet.  So, we don't subtract.
     */
    iface->packetbuf.totlen = wlen;

    if (iface->packetbuf.caplen > iface->packetbuf.totlen)
	iface->packetbuf.caplen = iface->packetbuf.totlen;
    return 1;
}

static inline void coral_dag_fill_pkt_result(coral_iface_t *iface,
    coral_dag_erf_hdr_t *hdr)
{
    iface->pkt_stats.pkts_recv++;
    iface->pkt_stats.ok_packet++;
    /* lctr is big endian, but we defer conversion until interval end */
    iface->cur_pkt_stats.pkts_drop = hdr->lctr;

    iface->pkt_result.timestamp = &hdr->t;

    iface->packetbuf.buf = coral_cell_payload_req(iface, hdr);
    iface->packetbuf.protocol = iface->iface_info.datalink;
    iface->pkt_result.packet = &iface->packetbuf;

    if (coral_cell_field_offset(iface, HEADER) >= 0) {
	iface->headerbuf.buf = (char*)coral_cell_header(iface, hdr);
#if 0 /* These were set in coral_init_atm_iface() and never change */
	iface->headerbuf.protocol = CORAL_PHY_ATM;
	iface->headerbuf.is_dynamic = 0;
#endif
	iface->headerbuf.caplen = 4;
	iface->headerbuf.totlen = 5;
	iface->pkt_result.header = &iface->headerbuf;
    } else {
	iface->pkt_result.header = NULL;
    }

    iface->pkt_result.trailer = NULL;
}

static inline int coral_dag_novarlen_prep_pkt_end(coral_iface_t *iface,
    coral_iface_t *iface0, coral_dag_erf_hdr_t *hdr)
{
    if (iface->packetbuf.caplen < iface->packetbuf.totlen &&
	!(coral_config.flags & CORAL_OPT_PARTIAL_PKT))
    {
	/* discard partial packet */
	iface->pkt_stats.truncated++;
	return 0;
    }

    coral_dag_fill_pkt_result(iface, hdr);

    coral_blk_prep_pkt(iface, iface0, coral_dag_clock_timespec);
    return 1;
}

/* check_period_end should be called on a pkt when it becomes the iface's
 * current pkt.
 */
static void check_period_end(coral_iface_t *iface, coral_dag_erf_hdr_t *hdr)
{
    /* Optimization: we compare native pkt timestamp to native_period_end,
     * avoiding the need to do per-pkt conversion.  (On big endian hosts,
     * we still need to do a byte swap, but most DAG work is on little
     * endian hosts, where we don't even need to byte swap.) */
    /* iface->native_ts was set by read_any, read_iface, or consume */
    iface->synced = iface->period_end.tv_sec >= 0 &&
        crl_letoh64(*(uint64_t*)&hdr->t) >=
        crl_letoh64(*(uint64_t*)&iface->native_period_end);
    if (iface->synced) {
	coral_diag(8, ("iface %d synced with native_period_end\n", iface->id));
	coral_update_latest_ts(iface); /* need the converted timestamp */
	if (timestamp_duration_ended(iface, &iface->latest_ts)) {
	    coral_diag(8, ("iface %d passed duration_end\n", iface->id));
	    iface->have_data = 0;
	}
    }
}

static inline int coral_dag_varlen_prep_pkt_end(coral_iface_t *iface,
    coral_dag_erf_hdr_t *hdr)
{
    if (iface->packetbuf.caplen < iface->packetbuf.totlen &&
	!(coral_config.flags & CORAL_OPT_PARTIAL_PKT))
    {
	/* discard partial packet */
	iface->pkt_stats.truncated++;
        iface->have_data = 0;

    } else {
	coral_dag_fill_pkt_result(iface, hdr);
	iface->have_data = 1;
    }

    return iface->have_data;
}


/* returns -1 for error, 1 for complete packet, 0 for no packet */
static int coral_dag_pos_prep_pkt(coral_iface_t *iface)
{
    coral_dag_erf_hdr_t *hdr; /* legacy pos hdr is compatible with erf hdr */
    coral_iface_t *iface0 = iface; /* legacy pos can only have one iface */

    hdr = iface->pktq_head ? coral_dag_queued_hdr(iface) :
	coral_dag_novarlen_hdr(iface, iface0);
    if (!hdr) return -1;

    if (hdr->flags) {
	/* XXX msg should give location (packet #) */
	coral_diag(0, ("illegal flags %#02x in DAG legacy file\n", hdr->flags));
	return -1;
    }
    if (hdr->type != DAG_TYPE_LEGACY && hdr->type != DAG_TYPE_HDLC_POS) {
	coral_diag(0, ("unsupported DAG header type %d\n", hdr->type));
	if (coral_verbosity > 1) {
	    coral_fprint_data(coral_get_errfile(), 0, (unsigned char*)hdr, 64);
	}
	return -1;
    }

    coral_dag_erf_prep_pkt(iface, hdr); /* legacy POS is compatible with ERF */

#if 0
    if (coral_cell_size(iface) != rlen) {
	coral_diag(0, ("inconsistent record size %d != %d\n",
	    iface->packetbuf.caplen, coral_cell_size(iface)));
	return -1;
    }
#endif

    return coral_dag_novarlen_prep_pkt_end(iface, iface0, hdr);
}

/* returns -1 for error, 1 for complete packet, 0 for no packet */
static int coral_dag_erf_varlen_prep_pkt(coral_iface_t *target_iface)
{
    coral_iface_t *iface0, *current_iface;
    unsigned ifnum;
    coral_dag_erf_hdr_t *hdr;

    iface0 = cinst[target_iface->src->id[0]];

    hdr = target_iface->pktq_head ? coral_dag_queued_hdr(target_iface) :
	coral_dag_varlen_hdr(iface0);
    if (!hdr)
	return 0;
    ifnum = hdr->flags & DAG_FLAG_IFMASK;
    /* validity of ifnum has already been tested */
    current_iface = cinst[target_iface->src->id[ifnum]];
    if (current_iface->eof)
	return 0; /* discard data on this iface */

    if (!coral_dag_erf_prep_pkt(current_iface, hdr))
	return -1;
    return coral_dag_varlen_prep_pkt_end(current_iface, hdr);
}

/* returns -1 for error, 1 for complete packet, 0 for no packet */
/* optimized to take advantage of fixed record size */
static int coral_dag_erf_novarlen_prep_pkt(coral_iface_t *target_iface)
{
    coral_dag_erf_hdr_t *hdr;
    coral_iface_t *iface0, *current_iface;
    int ifnum;

    iface0 = cinst[target_iface->src->id[0]];

    hdr = target_iface->pktq_head ? coral_dag_queued_hdr(target_iface) :
	coral_dag_novarlen_hdr(target_iface, iface0);
    if (!hdr)
	return -1;
    ifnum = hdr->flags & DAG_FLAG_IFMASK;
    /* validity of ifnum has already been tested */
    current_iface = cinst[target_iface->src->id[ifnum]];
    if (current_iface->eof)
	return 0; /* discard data on this iface */

    if (!coral_dag_erf_prep_pkt(current_iface, hdr))
	return -1;
    return coral_dag_novarlen_prep_pkt_end(current_iface, iface0, hdr);
}

/* returns -1 for error, 1 for complete packet, 0 for no packet */
/* optimized to take advantage of fixed record size */
static int coral_dag_erf_atm_prep_pkt(coral_iface_t *target_iface)
{
    coral_dag_erf_hdr_t *hdr;
    coral_iface_t *iface0, *current_iface;
    int ifnum;

    iface0 = cinst[target_iface->src->id[0]];

    hdr = target_iface->pktq_head ? coral_dag_queued_hdr(target_iface) :
	coral_dag_novarlen_hdr(target_iface, iface0);
    if (!hdr)
	return -1;
    ifnum = hdr->flags & DAG_FLAG_IFMASK;
    /* validity of ifnum has already been tested */
    current_iface = cinst[target_iface->src->id[ifnum]];
    if (current_iface->eof)
	return 0; /* discard data on this iface */

    if (!coral_aal5_reassemble(current_iface, hdr, &current_iface->pkt_result))
	return 0;

    /* lctr is big endian, but we defer conversion until interval end */
    current_iface->cur_pkt_stats.pkts_drop = hdr->lctr; /* XXX ??? */

    coral_blk_prep_pkt(current_iface, iface0, coral_dag_clock_timespec);
    return 1;
}


/* consume the packet just used on iface, and try to update iface's
 * timestamp (if the next pkt is already queued).
 */
static int coral_dag_erf_varlen_consume(coral_iface_t *iface, int want)
{
    coral_pktq_node_t *node = iface->pktq_head;

    errno = 0; /* So NULL return value just means "no packet", not "error". */

    if (iface->pktq_head && iface->packetbuf.buf ==
	coral_cell_payload_req(iface, iface->pktq_head->rec))
    {
#ifndef NDEBUG
	coral_diag(24, ("iface %d: consumed pkt\n", iface->id));
#endif
	/* remove from arbitrary position in src's doubly linked list */
	*(node->srcnext ? &node->srcnext->srcprev : &iface->src->pktq_tail) =
	    node->srcprev;
	*(node->srcprev ? &node->srcprev->srcnext : &iface->src->pktq_head) =
	    node->srcnext;
	iface->src->pktq_size--;

	/* remove from head of iface's queue */
	iface->pktq_head = iface->pktq_head->ifnext;
	if (!iface->pktq_head)
	    iface->pktq_tail = NULL;

	/* free node */
	node->srcnext = iface->src->pktq_freelist;
	iface->src->pktq_freelist = node;
    } else {
#ifndef NDEBUG
	coral_diag(24, ("iface %d: no pkt to consume\n", iface->id));
#endif
    }

    if (!iface->pktq_head) {
	iface->have_data = 0;
	if (iface->src->eof) /* can never get more data from iface */
	    coral_mark_eof(iface);
	return 0;
    }

    /* Use next record to update timestamp */
    {
	coral_dag_erf_hdr_t *hdr = coral_dag_queued_hdr(iface);
	coral_set_ts2(iface, &hdr->t, coral_dag_clock_timespec);
	check_period_end(iface, hdr); /* may stop src and set iface->eof */
    }

    iface->have_data = !iface->eof;
    return iface->have_data;
}

static inline coral_iface_t *coral_dag_find_iface_of_pkt(coral_source_t *src,
    coral_dag_erf_hdr_t *hdr)
{
    coral_iface_t *iface;
    int ifnum;

    ifnum = hdr->flags & DAG_FLAG_IFMASK;
    if (ifnum >= src->iface_count) {
	coral_diag(0, ("%s: invalid interface %d in DAG ERF header.  (Perhaps your \"nif\" iomode option is incorrect?)\n",
	    src->filename, ifnum));
	errno = CORAL_EBADIFNUM;
	return NULL;
    }
    iface = cinst[src->id[ifnum]];
#if 0
    coral_diag(10, ("read pkt from %d (%d): %08x %08x.\n", iface->id, ifnum,
	crl_letohl(hdr->t.i[1]), crl_letohl(hdr->t.i[0])));
#endif

    /* coral_set_iface_capture_tv() was done in coral_dagfile_init() */
    return iface;
}

/* Return any iface from the same source that has a packet.
 * Called by non-sorting api.
 */
coral_iface_t *coral_dagerf_read_any(coral_iface_t *target_iface)
{
    coral_source_t *src = target_iface->src;
    coral_iface_t *iface;
    coral_iface_t *iface0 = cinst[src->id[0]];
    coral_dag_erf_hdr_t *hdr;

    while (src->pktq_size < src->pktq_max) {
	if (src->eof)
	    return NULL;
	hdr = (void*)coral_dag_varlen_hdr(iface0);
	if (!hdr) return NULL;
	if (!(iface = coral_dag_find_iface_of_pkt(src, hdr))) {
	    if (errno) return NULL;
	    continue;
	}
	if (iface->eof)
	    continue;
	if (!iface->pktq_head) {
	    assert(!iface->synced); /* if synced, queue shouldn't be empty */
	    coral_set_native_ts(iface, &hdr->t);
	    check_period_end(iface, hdr); /* may stop src and set iface->eof */
	    if (iface->eof)
		continue;
	}
	iface->have_data = 1;
	if (iface->pktq_head) {
	    coral_dag_queue_pkt(iface, hdr);
	} else if (iface->synced) {
	    /* We had skipped queuing as an optimization, but must queue now */
	    coral_dag_queue_pkt(iface, hdr);
	    return iface; /* so caller can count it as NEWLY synced */
	} else {
	    coral_set_native_ts(iface, &hdr->t);
	    if (!coral_dag_erf_prep_pkt(iface, hdr))
		return NULL;
	    if (coral_dag_varlen_prep_pkt_end(iface, hdr)) {
		errno = 0;
		return iface;
	    }
	}
    }

    /* queue is full */
    if (!target_iface->synced) {
	target_iface->synced = 1;
	return target_iface; /* so caller can count it as NEWLY synced */
    }

    return NULL;
}

/* Returns target_iface if successful, or NULL at EOF or if pktq_size is
 * exceeded.  Called by sorting api (and thus first pkt of nonsorting api).
 */
coral_iface_t *coral_dagerf_read_iface(coral_iface_t *target_iface)
{
    coral_source_t *src = target_iface->src;
    coral_iface_t *iface;
    coral_iface_t *iface0 = cinst[src->id[0]];
    coral_dag_erf_hdr_t *hdr;

    do {
	hdr = (void*)coral_dag_varlen_hdr(iface0);
	if (!hdr) return NULL;
	if (!(iface = coral_dag_find_iface_of_pkt(src, hdr)))
	    return NULL;
	if (iface->eof) {
	    errno = 0;
	    if (iface == target_iface) return NULL;
	    continue;
	}
	if (!iface->pktq_head) {
	    /* NB: do not naively optimize coral_set_ts2() to skip setting
	     * native_ts, because this can be called from non-sorting API,
	     * which requires native_ts to be set. */
	    coral_set_ts2(iface, &hdr->t, coral_dag_clock_timespec);
	    check_period_end(iface, hdr); /* may stop src and set iface->eof */
	    iface->have_data = !iface->eof;
	    if (iface->eof) {
		if (iface == target_iface) return NULL;
		continue;
	    }
	}
	coral_dag_queue_pkt(iface, hdr);
	errno = 0;
	if (iface == target_iface) return iface;
    } while (src->pktq_size < src->pktq_max);

    errno = EAGAIN; /* XXX ??? */
    return NULL;
}

static void dag_iface_init(coral_iface_t *iface)
{
    iface->time_is_normal = 1;
}


#define IFACE_TYPE dag
#include "coral_atm.h"


const coral_iface_type_t coral_iface_type_dag_atm = {
    {
	sizeof(coral_dag_atm_cell_t),	/* size = 64 */
	offsetof(coral_dag_atm_cell_t, t),	/* 0 */
	offsetof(coral_dag_atm_cell_t, cu),	/* 12 */
	-1,	/* offset of ATM HEC */
	offsetof(coral_dag_atm_cell_t, p),	/* 16 */
	-1,	/* offset of caplen */
	-1,	/* offset of totlen */
	-1	/* unused3 */
    },
    "dag (legacy atm)",
    CORAL_API_BLOCK | CORAL_API_CELL | CORAL_API_PKT,
    dag_iface_init,
    dag_clock_order,
    NULL /* clock_read_double */,
    coral_dag_clock_timespec,
    NULL /* correct_clock */,
    coral_dag_clock_native,
    coral_cell_consume,
    coral_atm_consume_pkt,
    coral_dag_atm_prep_pkt,
    NULL /* update_pkt_stats */,
    coral_atm_iface_close,
    { { CORAL_RX, 48 }, KBPS_OC3c, CORAL_PHY_ATM, CORAL_DLT_ATM_RFC1483, NULL }
};

/* For internal use only.  User never sees POS "cells". */
const coral_iface_type_t coral_iface_type_dag_pos = {
    {
	64,	/* size of records in old dag format */
	offsetof(coral_dag_erf_hdr_t, t),	/* 0 */
	-1,	/* offset of ATM header */
	-1,	/* offset of ATM HEC */
	sizeof(coral_dag_erf_hdr_t),	/* 16 */
	-1,	/* offset of caplen */
	-1,	/* offset of totlen */
	-1	/* unused3 */
    },
    "dag (legacy pos)",
    CORAL_API_PKT,
    dag_iface_init,
    dag_clock_order,
    NULL /* clock_read_double */,
    coral_dag_clock_timespec,
    NULL /* correct_clock */,
    coral_dag_clock_native,
    coral_cell_consume,
    NULL /* consume_pkt */,
    coral_dag_pos_prep_pkt,
    coral_dag_update_pkt_stats,
    NULL /* close */,
    { { CORAL_RX, 48 }, KBPS_OC3c, CORAL_PHY_POS, CORAL_DLT_UoPOS, NULL }
};

const coral_iface_type_t coral_iface_type_dag_erf_atm = {
    {
	-1,	/* record size - will be filled in by init */
	offsetof(coral_dag_erf_hdr_t, t),	/* 0 */
	-1,	/* offset of ATM header */
	-1,	/* offset of ATM HEC */
	-1,	/* offset of payload - will be filled in by init */
	-1,	/* offset of caplen */
	-1,	/* offset of totlen */
	-1	/* unused3 */
    },
    "dag (erf atm)",
    CORAL_API_PKT,
    dag_iface_init,
    dag_clock_order,
    NULL /* clock_read_double */,
    coral_dag_clock_timespec,
    NULL /* correct_clock */,
    coral_dag_clock_native,
    coral_cell_consume,
    coral_atm_consume_pkt,
    coral_dag_erf_atm_prep_pkt,
    coral_dag_update_pkt_stats,
    NULL /* close */,
    { { CORAL_RX, 48 }, 0, CORAL_PROTO_UNKNOWN, CORAL_PROTO_UNKNOWN, NULL }
};

const coral_iface_type_t coral_iface_type_dag_erf_novarlen = {
    {
	-1,	/* record size - will be filled in by init */
	offsetof(coral_dag_erf_hdr_t, t),	/* 0 */
	-1,	/* offset of ATM header */
	-1,	/* offset of ATM HEC */
	-1,	/* offset of payload - will be filled in by init */
	-1,	/* offset of caplen */
	-1,	/* offset of totlen */
	-1	/* unused3 */
    },
    "dag (erf novarlen)",
    CORAL_API_PKT,
    dag_iface_init,
    dag_clock_order,
    NULL /* clock_read_double */,
    coral_dag_clock_timespec,
    NULL /* correct_clock */,
    coral_dag_clock_native,
    coral_cell_consume,
    NULL /* consume_pkt */,
    coral_dag_erf_novarlen_prep_pkt,
    coral_dag_update_pkt_stats,
    NULL /* close */,
    { { CORAL_RX, 48 }, 0, CORAL_PROTO_UNKNOWN, CORAL_PROTO_UNKNOWN, NULL }
};

const coral_iface_type_t coral_iface_type_dag_erf_varlen = {
    {
	-1,	/* record size */
	offsetof(coral_dag_erf_hdr_t, t),	/* 0 */
	-1,	/* offset of ATM header */
	-1,	/* offset of ATM HEC */
	-1,	/* offset of payload - will be filled in by init */
	-1,	/* offset of caplen */
	-1,	/* offset of totlen */
	-1	/* unused3 */
    },
    "dag",
    CORAL_API_PKT,
    dag_iface_init,
    dag_clock_order,
    NULL /* clock_read_double */,
    coral_dag_clock_timespec,
    NULL /* correct_clock */,
    coral_dag_clock_native,
    coral_dag_erf_varlen_consume,
    NULL /* consume_pkt */,
    coral_dag_erf_varlen_prep_pkt,
    coral_dag_update_pkt_stats,
    NULL /* close */,
    { { CORAL_RX, 48 }, 0, CORAL_PROTO_UNKNOWN, CORAL_PROTO_UNKNOWN, NULL }
};


