/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 * Template for checking pairs of syn->rst or syn->synack.  Displays info on
 * which ones we find and the time difference between the syn and the rst or
 * synack.
 *
 * $Id: template-synack.c,v 1.26 2007/06/06 18:17:34 kkeys Exp $
 */


static const char RCSid[]="$Id: template-synack.c,v 1.26 2007/06/06 18:17:34 kkeys Exp $";

#include "config.h"
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <sys/time.h>
#include <sys/errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <signal.h>
#include <errno.h>

#include <netinet/in.h>
#include <netinet/in_systm.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <netinet/ip_icmp.h>
#include <arpa/inet.h>
#include <netdb.h>

#include "libcoral.h"
#include "hashtab.h"

#include "traffic.h"

#define SYN_HASH_TABLE_SIZE	229

/*
 * Syn structure, contains all info we need about the syn we receive.
 */
typedef struct syn {
    
    unsigned long src_addr;
    unsigned long dst_addr;
    unsigned short src_port;
    unsigned short dst_port;
    double time_seen;
} syn;

hash_tab *syn_hash;


/*
 * Display the results from finding a matching syn->synack or syn->rst pair.
 */
static void display_match(const char *type, unsigned long ip_src, 
                   unsigned long ip_dst, unsigned short th_sport, 
                   unsigned short th_dport, double time_difference)
{
    struct in_addr src;
    struct in_addr dst;
    
    /* Save the source and dst IP addresses. */
    src.s_addr=htonl(ip_src);
    dst.s_addr=htonl(ip_dst);
    
    /* Print the stats. */
    printf("%s: src: %s:%i ", type, inet_ntoa(src), th_sport);
    printf("dst: %s:%i, time delta: %f\n", inet_ntoa(dst), th_dport, 
           time_difference);
    
    return;
}


/*
 * Function to be called if we see a syn-ack packet.  This will check for a
 * matching syn packet and return the time we saw it.  If there is no match,
 * it will return 0.
 */
static double saw_syn_ack(unsigned long src_addr, unsigned long dst_addr,
			  unsigned short src_port, unsigned short dst_port)
{
    syn *synfound;
    syn synfind;
    double time_seen;
    
    /* 
     * Look and see if we've seen a syn that matches this syn-ack.
     * Note: the notion of source and destination are reversed for the
     * syn and syn-ack packets.
     */
    synfind.src_addr=src_addr;
    synfind.dst_addr=dst_addr;
    synfind.src_port=src_port;
    synfind.dst_port=dst_port;
    synfound=(syn *) find_hash_entry(syn_hash, &synfind);
    
    /* Did we find a matching syn? */
    if(synfound != NULL) {
        time_seen=synfound->time_seen;
        
        /* Forget this syn, it is connected now. */
        clear_hash_entry(syn_hash, synfound);
    	
    	/* Return the time we saw the syn at. */
    	return(time_seen);
    }
    
    /* We didn't have a syn matching this syn-ack. */
    else {
	/* fprintf(stderr, "No syn corresponding to this synack.\n"); */
    	return(0);
    }
}


/*
 * Function to be called if we see a rst packet.  This will check for a
 * matching syn packet and return the time we saw it.  If there is no match,
 * it will return 0.
 */
static double saw_rst(unsigned long src_addr, unsigned long dst_addr,
		      unsigned short src_port, unsigned short dst_port)
{
    syn *synfound;
    syn synfind;
    double time_seen;
    
    /* 
     * Look and see if we've seen a syn that matches this rst.
     * Note: the notion of source and destination are reversed for the
     * syn and rst packets.
     */
    synfind.src_addr=src_addr;
    synfind.dst_addr=dst_addr;
    synfind.src_port=src_port;
    synfind.dst_port=dst_port;
    synfound=(syn *) find_hash_entry(syn_hash, &synfind);
    
    /* Did we find a matching syn? */
    if(synfound != NULL) {
        time_seen=synfound->time_seen;
        
        /* Forget this syn, it is connected now. */
        clear_hash_entry(syn_hash, synfound);
    	
    	/* Return the time we saw the syn at. */
    	return(time_seen);
    }
    
    /* We didn't have a syn matching this rst. */
    else {
	/* fprintf(stderr, "No syn corresponding to this rst.\n"); */
    	return(0);
    }
}


/*
 * Function to be called when we see a syn packet.  Records where the syn
 * came from and went to along with the time we saw it.
 */
static void saw_syn(unsigned long src_addr, unsigned long dst_addr,
		    unsigned short src_port, unsigned short dst_port,
		    double time_seen)
{
    syn newsyn;
    syn *temp;
    syn *synfound;
    
    /* 
     * Check if we've seen a syn sent to the same address already.
     */
    newsyn.src_addr=src_addr;
    newsyn.dst_addr=dst_addr;
    newsyn.src_port=src_port;
    newsyn.dst_port=dst_port;
    newsyn.time_seen=time_seen;
    synfound=(syn *) find_hash_entry(syn_hash, &newsyn);
    
    /* Had we already seen a syn between these two systems? */
    if(synfound != NULL) {
        
        /* Report that we've seen a duplicate syn. */
        display_match("dup syn", src_addr, dst_addr, src_port, dst_port, time_seen - synfound->time_seen);
        
        /* Update the time that we saw this syn. */
        synfound->time_seen=time_seen;
    }
    
    /* This is a new syn, we need to record it and its time. */
    else {
        
        /* Keep track of this syn by adding it to the hash. */
        temp=(syn *) malloc(sizeof(syn));
        (void) memcpy(temp, &newsyn, sizeof(syn));
        add_hash_entry(syn_hash, temp);
    }
    
    return;
}


/* 
 * The quit routine is called after the packet reading duration is over.  It
 * signals CoralReef to stop reading packets.
 */
static void quit(int sig)
{
    coral_pkt_done = 1;
}


/*
 * Function that gets called by CoralReef whenever it has assembled a
 * packet.
 *
 * The iface argument is the interface that the packet was read on.
 *
 * Timestamp is the time the packet was read.
 *
 * Userdata is what was passed to coral_read_pkts as userdata.  In this
 * case, it will be NULL.
 *
 * Packet is a buffer where the link level packet is stored and other info
 * about the packet.
 *
 * Header is a buffer with the packet's link level header if the link level
 * uses headers, otherwise it is NULL.
 *
 * Trailer is a buffer containing the packet's link level trailer if used
 * and the packet was not truncated, otherwise it is NULL.
 */
static void pkthandler(coral_iface_t *iface, const coral_timestamp_t *timestamp,
    void *userdata, coral_pkt_buffer_t *packet, coral_pkt_buffer_t *header,
    coral_pkt_buffer_t *trailer)
{
    struct ip *ip;
    struct tcphdr *tcp;
    double time_seen;
    unsigned long src_addr, dst_addr;
    unsigned short src_port, dst_port;
    coral_pkt_buffer_t ippkt;
    
    /* Get the IP packet from the link layer packet passed to us. */
    if (coral_get_payload_by_proto(packet, &ippkt, CORAL_NETPROTO_IP) < 0)
	return;
    ip = (struct ip *)ippkt.buf;

    /* The protocol should be TCP. */
    if(ip->ip_p != IPPROTO_TCP) return;
    
    /* Get the TCP packet's header. */
    tcp = (struct tcphdr*)((char*)ip + ip->ip_hl * 4);
    
    /* Convert fields from network byte order to something we can manage. */
    src_addr=ntohl(ip->ip_src.s_addr);
    dst_addr=ntohl(ip->ip_dst.s_addr);
    src_port=ntohs(tcp->th_sport);
    dst_port=ntohs(tcp->th_dport);
    
    /* Is this a syn-ack packet? */
    if((tcp->th_flags & (TH_SYN | TH_ACK)) == (TH_SYN | TH_ACK)) {
        
        /* Signal that we saw the syn-ack. In the OTHER direction. */
        time_seen=saw_syn_ack(dst_addr, src_addr, dst_port, src_port);
        
        /* Display the information if we matched. */
        if(time_seen) {
            display_match("synack", src_addr, dst_addr,
                          src_port, dst_port,
                          coral_read_clock_double(iface, timestamp) - time_seen);
        }
    }
    
    /* Is this a syn packet? */
    else if(tcp->th_flags & TH_SYN) {
        
        /* Signal that we saw the syn. */
        saw_syn(src_addr, dst_addr, src_port, dst_port,
                coral_read_clock_double(iface, timestamp));
    }
    
    /* Is this a rst packet? */
    else if(tcp->th_flags & TH_RST) {
        
        /* Signal that we saw the rst.  In the other direction. */
        time_seen=saw_rst(dst_addr, src_addr, dst_port, src_port);
        
        /* Display the information if we matched. */
        if(time_seen) {
            display_match("rst", src_addr, dst_addr,
                          src_port, dst_port,
                          coral_read_clock_double(iface, timestamp) - time_seen);
        }
    }
    
    return;
}


/*
 * Compare two syn structures to see if they match.  Returns 0 if so.
 */
static int compare_syn(const void *entry1, const void *entry2)
{
    const syn *syn1 = entry1;
    const syn *syn2 = entry2;
    
    return(!(syn1->src_addr == syn2->src_addr &&
            syn1->dst_addr == syn2->dst_addr &&
            syn1->src_port == syn2->src_port &&
            syn1->dst_port == syn2->dst_port));
}


/*
 * Generates a key for the hash table to index syn structures by.
 */
static unsigned long make_key_syn(const void *entry)
{
    const syn *what = entry;
    
    return ((unsigned) what->src_addr * 59 + what->dst_addr +
	    ((unsigned)what->dst_port<<16) + what->src_port);
}


/*
 * Frees any memory associated with a syn structure.
 */
static void delete_syn(void *entry)
{
    syn *what = entry;

    if (!what) return;

    free(what);
}


/*
 * Initialize the hash table we use to store syn structures.
 */
static void init_hashes(void)
{
    syn_hash = init_hash_table("# hashes entries for syns",
			       compare_syn, make_key_syn,
			       delete_syn, SYN_HASH_TABLE_SIZE);
}


/* Main. */
int main(int argc, char *argv[])
{
    int n, opt;
    coral_iface_t *iface;

    /* Hook signals to our quit routine so we can clean up when finished. */
    signal(SIGINT, quit);

    /* Allow -Cfilter option. */
    coral_set_api(CORAL_API_PKT);

    /* Allow at most 1 source. */
    coral_set_max_sources(1);
    
    /* Set the default mode for CoralReef devices. */
    coral_set_iomode(0, CORAL_RX_UNKNOWN, -1, 0);

    /* Set the default duration (0 == infinite). */
    coral_set_duration(0);
    
    /* Check commandline arguments. */
    while ((opt = getopt(argc, argv, "C:pP")) >= 0) {
        
        /* Parse CoralReef commandline arguments. */
        if (opt == 'C') {
            if (coral_config_command(optarg) < 0)
                exit(-1);
        
        /* Parse an option to (not) read partial packets. */
        } else if (opt == 'P') {
	    coral_set_options(CORAL_OPT_PARTIAL_PKT, 0);
        } else if (opt == 'p') {
	    coral_set_options(0, CORAL_OPT_PARTIAL_PKT);
        } 
        else {
            coral_usage(argv[0], "[-P] <source>\n"
		"-P    do not allow partial packets\n");
            exit(-1);
        }
    }
    
    /* Any leftover commandline arguments are treated as CoralReef sources. */
    while (optind < argc) {
        if (!coral_new_source(argv[optind]))
            exit(-1);
        optind++;
    }

    /* Initialize the hash tables we use to store SYNs. */
    init_hashes();
    
    /* Open all the CoralReef sources listed on the commandline. */
    if ((n = coral_open_all()) < 0)
        exit(-1);
    if (n == 0) {
	coral_diag(0, ("no sources.\n"));
	exit(0);
    }

    /* If any of the sources are devices (not traces) start the devices. */
    if (coral_start_all() < 0)
        exit(-1);
    
    /* Get an interface to extract packets from. */
    iface = coral_next_interface(NULL);
    
    /* 
     * Read packets and send them to our pkthandler function until the
     * duration is over.
     */
    if (coral_read_pkts(NULL, iface, pkthandler, NULL, NULL, NULL, NULL) < 0)
	exit(errno);
    
    /* Stop any running devices and close all sources. */
    coral_stop_all();
    coral_close_all();
    
    return(0);
}
