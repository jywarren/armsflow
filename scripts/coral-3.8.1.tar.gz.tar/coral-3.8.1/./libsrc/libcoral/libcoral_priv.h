/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 * libcoral_priv.h - private definitions for libcoral
 *
 * $Id: libcoral_priv.h,v 1.231 2007/06/06 18:17:56 kkeys Exp $
 */

#ifndef LIBCORAL_PRIV_H
#define LIBCORAL_PRIV_H

#include <netinet/in.h>	/* for ntohl() et al */
#include "caida_t.h"
#include <assert.h>
/* #include "coral_ioctl.h" */
#ifdef HAVE_LIBPCAP
# include <pcap.h>
#endif

#include <string.h> /* for memcpy() */
#include <limits.h>
#ifndef PATH_MAX
# ifdef MAXPATHLEN
#  define PATH_MAX MAXPATHLEN
# else
#  define PATH_MAX 1024
# endif
#endif

/* CORAL_MAGIC must be the first word in any coral file.  The third word
 * should be the version number.
 */
#define CORAL_MAGIC             0x000C04A1
/* file format version numbers */
#define CORAL_VERSION_OLD_ANY   0x00000000ul	/* version in mci/nlanr trace */
#define CORAL_VERSION_OLD_NLANR 0x00000001ul	/* internal nlanr identifier */
#define CORAL_VERSION_OLD_MCI   0x00000002ul	/* internal mci identifier */

#define CORAL_VERSION_2	    0x80000002ul
#define CORAL_VERSION_3	    0x80000003ul /* 4, w/o iface_info.datalink */
#define CORAL_VERSION_4	    0x80000004ul /* 5, but fatm trace has
					  * little endian atm header */
#define CORAL_VERSION_5	    0x80000005ul /* 6, but protocol is always
					  * DLT_ATM_RFC1483 */
#define CORAL_VERSION_6	    0x80000006ul /* 7, but first_n is in cells */
#define CORAL_VERSION_7	    0x80000007ul /* 8, with cells_per_blk instead
					  * of blk_size */
#define CORAL_VERSION_8	    0x80000008ul /* 9, w/o iface_info.capture_tv */
#define CORAL_VERSION_9	    0x80000009ul /* 33, w/o iface_info.physical */
#define CORAL_VERSION_32    0x80000020ul /* reserved */
#define CORAL_VERSION_33    0x80000021ul /* 34, w/o iface_info.proto_rule_count */
#define CORAL_VERSION_34    0x80000022ul /* current version */

#define CORAL_VERSION	CORAL_VERSION_34

#define CORAL_VERSION_IS_NEW(v)	((v) & 0x80000000)
#define CORAL_VERSION_VALUE(v)	((v) & ~0x80000000)

/* protocols */
#define CORAL_PROTO_ATM_AAL5	0
#define CORAL_PROTO_RESERVED	1

#define GZIP_MAGIC "\037\213"


/* RFC 2225 specifies a default MTU of 9180 for IP over ATM AAL5, so
 * that is the absolute minimum we must support. */
#define MAX_PACKET_SIZE	(1<<16)


/* v3.3: only device-specific code should access this structure directly;
 * all other code should use accessors instead.
 */
typedef struct {
    coral_timestamp_t t;	/* timestamp, in card-specific format */
    union atm_hdr cu;		/* ATM header (without HEC) */
    union {
	char payload[ATM_PAYLOAD_SIZE];
	uint16_t payload_shorts[ATM_PAYLOAD_SIZE/2];
	uint32_t payload_i[ATM_PAYLOAD_SIZE/4];
    } p;			/* ATM cell payload == SAR-PDU */
} coral_old_atm_cell_t;

/* For libcoral internal use only.  App programmer never sees TSH records. */
#define TSH_PAYLOAD_SIZE (36)
typedef struct {
    coral_timestamp_t	t;
    char 		payload[TSH_PAYLOAD_SIZE];
} coral_tsh_record_t;

typedef coral_old_atm_cell_t coral_fatm_atm_cell_t;
typedef coral_old_atm_cell_t coral_point_atm_cell_t;

/* For compatibility with version 2 block header, magic must be first word and
 * version must be third word of file.  Fields are in network byte order. */
typedef struct {
    uint32_t magic;		/* coral magic number */
    uint32_t header_size;	/* incl. iface_infos, proto_rules, padding */
    uint32_t version;		/* CORAL_VERSION */
    uint32_t link_protocol;	/* CORAL_PROTO_* (not really used) */
    uint32_t site_id;		/* ??? (not used) */
    uint32_t checksum[4];	/* checksum of entire file (not used) */
    char encoding[32];		/* name of encoding, if any */
    uint32_t encoding_version;	/* version of encoding */
    int16_t iface_info_count;	/* number of iface_info structures */
    int16_t proto_rule_count;	/* number of proto_rule structures (including
				    those for individual interfaces) */
    char  desc[256];		/* NUL terminated string */
/*  coral_iface_info_t iface_info[iface_info_count]; */
/*  coral_proto_rule_t proto_rule[proto_rule_count]; */
				/* Each iface may have a number of proto_rules;
				 * those are first, in the same order as the
				 * ifaces they belong to.  Any remaining rules
				 * apply to the entire file. */
} coral_file_header_t;

#define CORAL_FILE_HEADER_SIZE	sizeof(coral_file_header_t)

#if (SIZEOF_CORAL_PROTOCOL_T == 4)
# define coral_proto32_t coral_protocol_t	/* makes debugging easier */
#else
# define coral_proto32_t uint32_t
#endif
/* This must be architecture independent, so fields must be fixed size. */
typedef struct {
    uint32_t hw_type;
    uint32_t hw_version;
    uint32_t fw_type;
    uint32_t fw_version;
    uint32_t sw_type;
    uint32_t sw_version;
    coral_io_mode_t iomode;
    int32_t capture_time;	/* obsolete: replaced by capture_tv */
    int32_t bandwidth;		/* KBPS_OC* */
    uint32_t time_is_le;	/* true if timestamp is little endian */
    /* fields added (but not necessarily used) in v4 (at end for compat.) */
    coral_proto32_t datalink;	/* iface protocol (not used correctly til v6) */
    int32_t tzoff;		/* offset from UTC in seconds (used in v5) */
    /* added in v9 */
    struct timeval capture_tv;  /* time capture was started */
    /* added in v33 */
    coral_proto32_t physical;	/* physical protocol */
    /* added in v34 */
    int16_t proto_rule_count;	/* number of proto_rules for this iface */
    int16_t pad;		/* pad to 4 byte alignment */
} coral_iface_info_t;

#ifndef offsetof
# define offsetof(type, field)		((size_t)(&(((type*)0)->field)))
#endif

#define CORAL_V34_IFACE_INFO_SIZE	(sizeof(coral_iface_info_t))
#define CORAL_V33_IFACE_INFO_SIZE	offsetof(coral_iface_info_t,proto_rule_count)
#define CORAL_V9_IFACE_INFO_SIZE	offsetof(coral_iface_info_t,physical)
#define CORAL_V8_IFACE_INFO_SIZE	offsetof(coral_iface_info_t,capture_tv)
#define CORAL_V7_IFACE_INFO_SIZE	(CORAL_V8_IFACE_INFO_SIZE)
#define CORAL_V6_IFACE_INFO_SIZE	(CORAL_V7_IFACE_INFO_SIZE)
#define CORAL_V5_IFACE_INFO_SIZE	(CORAL_V6_IFACE_INFO_SIZE)
#define CORAL_V4_IFACE_INFO_SIZE	(CORAL_V5_IFACE_INFO_SIZE)
#define CORAL_V3_IFACE_INFO_SIZE	offsetof(coral_iface_info_t,datalink)

/* This must be architecture independent, so fields must be fixed size. */
typedef struct coral_proto_rule {
    uint32_t subif;	/* subinterface id */
    uint32_t subifmask;	/* which bits should be compared */
    coral_proto32_t protocol;	/* protocol */
    char allow;		/* what to do with matching cells */
    char pad[3];	/* make sure this struct's size is a multiple of 4 */
} coral_proto_rule_t;

typedef struct coral_proto_rulenode {
    coral_proto_rule_t	rule;
    struct coral_proto_rulenode *next;
} coral_proto_rulenode_t;

typedef struct {
    coral_proto_rulenode_t *head;
    coral_proto_rulenode_t *tail;
} coral_proto_rule_list_t;

typedef struct {
    coral_protocol_t id;
    const char *abbr;
    const char *desc;
    int proto_ok;
} coral_protolabel_t;

extern const coral_protolabel_t coral_protolabel[];


typedef int (s_init_t)(coral_source_t *src);
typedef coral_iface_t* (s_read_min_t)(coral_iface_t *iface);
typedef int (s_read_raw_t)(coral_source_t *src);
typedef coral_iface_t* (s_nextblk_t)(coral_source_t *src,
    coral_blk_info_t **binfop, coral_atm_cell_t **cellp, int endonly);
typedef void (s_release_t)(coral_iface_t *iface);
typedef int (s_start_t)(coral_source_t *src);
typedef int (s_stop_t)(coral_source_t *src);
typedef int (s_close_t)(coral_source_t *src, int final);

/* Entry points to functions specific to a given source type */
typedef struct {
    int		    coral_type;
    const char *    name;
    char	    is_live;		/* 1: live;  0: always-readable file */
    char	    is_buffered;	/* 1: can't be read til buf is full */
					/* 0: can be read without select */
    char	    is_block;		/* uses coral blocks? */
    char	    can_interleave;	/* records from multiple ifaces are
					 * sorted and interleaved within blk? */
    s_init_t	    *init;	/* initialize src (called by coral_open()) */
    s_start_t	    *start;	/* start capturing on src */
    s_read_raw_t    *read_raw;	/* low-level read */
    s_read_min_t    *read_any;	/* do minimum read from to get a timestamp for
				 * ANY iface of iface->src.  For blk sources,
				 * also updates cell_count.
				 * Guarantees that capture_tv is
				 * set, in case file fmt didn't include it.
				 * Does not guarantee ts_is_valid (i.e.,
				 * latest_ts may not agree with native_ts).
				 * Returns iface for success; or NULL with
				 * errno=0 for eof, errno=EAGAIN for no data,
				 * errno=other for error.
				 * Used by non-sorting api. */
    s_read_min_t    *read_iface;/* like read_any, but reads until it gets
				 * data for the specified iface.
				 * Guarantees ts_is_valid (i.e., latest_ts
				 * agrees with native_ts).
				 * Used by sorting api. */
    s_nextblk_t	    *nextblk;	/* (if src uses blocks) read a block. */
    s_release_t	    *release;	/* (if src queues blocks) free a queued block */
    s_stop_t	    *stop;	/* stop capturing on src, but don't close it */
    s_close_t	    *close;	/* free and clean up references to src */
} coral_src_type_t;

extern const coral_src_type_t coral_src_type_file;
extern const coral_src_type_t coral_src_type_point;
extern const coral_src_type_t coral_src_type_fatm;
extern const coral_src_type_t coral_src_type_dag;
extern const coral_src_type_t coral_src_type_dagfile;
extern const coral_src_type_t coral_src_type_dagfilevar;
extern const coral_src_type_t coral_src_type_pcap;
extern const coral_src_type_t coral_src_type_pcaplive;
extern const coral_src_type_t coral_src_type_tsh;
extern const coral_src_type_t coral_src_type_optistar;

/* internal data structures */

typedef struct coral_blknode {
    char *block;			/* raw block */
    coral_blk_info_t *binfo;		/* block header */
    char *data;				/* block data */
    unsigned long cell_count;		/* (in host byte order) */
    struct coral_blknode *next;
    int index;				/* index of current cell in data */
    int next_int;			/* index of 1st cell of next interval */
} coral_blknode_t;

/* states for coral_read_pkt() */
typedef enum {
    PKTST_NEW,		/* just starting */
    PKTST_CONSUME,	/* processed some data; must consume it */
    PKTST_RETRY,	/* didn't process any data */
    PKTST_BEGAN_INT,	/* began an interval */
    PKTST_ENDED_INT,	/* ended an interval */
    PKTST_DONE		/* done */
} pkt_state_t;

/* state data for packet api */
typedef struct {
    coral_source_t *src;	/* source of input */
    coral_iface_t *iface;	/* iface of input */
    struct timespec begin, end;	/* interval boundaries */
    struct timespec itime;	/* time for interval compare */
    coral_iface_t *last_iface;	/* iface of current pkt */
    pkt_state_t state;		/* what to do next */
    void *entry;
    coral_pkt_handler pkthandler;
    coral_pre_interval_handler preinthandler;
    coral_post_interval_handler postinthandler;
    struct timespec interval;
    void *parameter;
    coral_pkt_stats_t stats;
    struct timespec tend;	/* end time of last block */
    int synced;			/* # of synced ifaces (read_pkt_nosort) */
    int missing;		/* # of ifs with !have_data (read_pkt_sort) */
    int need_select;		/* # of ifs need select()ing (read_pkt_sort) */
    long pkts_since_read;
} pkt_info_t;

typedef struct {
    coral_io_mode_t iomode;		/* iomode */
    int32_t bandwidth;			/* KBPS_OC* */
    coral_protocol_t physical;		/* type of physical layer */
    coral_protocol_t datalink;		/* type of data link layer */
    const char *firmware;		/* firmware image (POINT, FATM) */
    int vlan_hack;			/* workaround for bug in libpcap */
    int num_ifaces;			/* number of interfaces */
} coral_dev_config_t;

typedef void (i_init_t)(coral_iface_t *iface);
typedef void (i_clock_order_t)(const coral_iface_t *iface,
	const coral_timestamp_t *src, coral_timestamp_t *dst);
typedef double (i_clock_double_t)(const coral_iface_t *iface,
	const coral_timestamp_t *t);
typedef void (i_clock_timespec_t)(const coral_iface_t *iface,
	const coral_timestamp_t *t, struct timespec *tspec);
typedef int (i_correct_clock_t)(coral_iface_t *iface,
	coral_blk_info_t *binfo, coral_atm_cell_t *cell);
typedef void (i_clock_native_t)(const coral_iface_t *iface,
	const struct timespec *tspec, coral_timestamp_t *t);
typedef int (i_consume_t)(coral_iface_t *iface, int want);
typedef void (i_consume_pkt_t)(coral_iface_t *iface);
typedef int (i_prep_pkt_t)(coral_iface_t *iface);
typedef void (i_update_pkt_stats_t)(coral_iface_t *iface);
typedef void (i_close_t)(coral_iface_t *iface);

struct coral_iface_type {
    /* cell_layout MUST be first member, for cell accessor macros */
    const int cell_layout[CORAL_CELL_NUM_FIELDS];
    const char name[32];
    int allowed_api;
    i_init_t		 *init;
    i_clock_order_t	 *clock_read_order;
    i_clock_double_t	 *clock_read_double;
    i_clock_timespec_t	 *clock_read_timespec;
    i_correct_clock_t	 *correct_clock;    /* fix tmstmps; return # to skip */
    i_clock_native_t	 *clock_native;	    /* convert timespec to native */
    i_consume_t		 *consume;	    /* use up last timestamp */
    i_consume_pkt_t	 *consume_pkt;	    /* use up last packet */
    i_prep_pkt_t	 *prep_pkt;	    /* update pkt_result w/ stored data,
					     * and set iface->synced if past
					     * end of interval. */
    i_update_pkt_stats_t *update_pkt_stats; /* update pkt_stats after interval*/
    i_close_t		 *close;	    /* close iface */
    coral_dev_config_t	 default_config;
};

#ifdef HAVE_LIBPCAP
extern const coral_iface_type_t coral_iface_type_pcap;
#endif
extern const coral_iface_type_t coral_iface_type_point;
extern const coral_iface_type_t coral_iface_type_fatm;
extern const coral_iface_type_t coral_iface_type_dag_atm;
extern const coral_iface_type_t coral_iface_type_dag_pos;
extern const coral_iface_type_t coral_iface_type_dag_erf_atm;
extern const coral_iface_type_t coral_iface_type_dag_erf_novarlen;
extern const coral_iface_type_t coral_iface_type_dag_erf_varlen;
extern const coral_iface_type_t coral_iface_type_tsh;
extern const coral_iface_type_t coral_iface_type_optistar;
extern const coral_iface_type_t *const coral_iface_types[];

typedef struct coral_pktq_node {
    char *rec;
    struct coral_pktq_node *ifnext;
    struct coral_pktq_node *srcnext;
    struct coral_pktq_node *srcprev;
} coral_pktq_node_t;

/* Information about an open interface */
struct coral_iface {
    coral_iface_pfx			/* members visible in libcoral.h */
    coral_iface_info_t	iface_info;	/* info about _original_ interface */
    coral_interface	devinfo;	/* info about _actual_ interface */
    coral_proto_rule_list_t		proto_rules;
    /*int			proto_rule_count;*/ /* XXX */

    struct {			/* Scratch space to hack around buggy clocks */
	coral_timestamp_t last_to;	/* last timestamp (host-ordered) */
	int32_t correction;
    } clock;
    int holding;		/* holding blocks for discontinuity check? */

    /* raw_ts is the timestamp that was converted unnormalized to cached_ts. */
    /* If cached_tsn_valid==1, then cached_tsn is the normalized time. */
    coral_timestamp_t	raw_ts;
    struct timespec	cached_ts;
    struct timespec	cached_tsn;
    int			cached_tsn_valid;

    int time_is_normal;			/* true if native clock is normalized */

    int have_interval;			/* true if an interval was specified */
    struct timespec duration_end;	/* end of duration */
    struct timespec period_end;		/* end of interval or duration,
					 * whichever is earlier (for read_pkt)*/
    coral_timestamp_t native_period_end;/* period_end, in native format
					 * (only some iface types use this) */
    int			eof;		/* true if EOF was reached */
    int			expired;	/* true if end of block (not necessarily
					 * current record) passed duration */
    int			have_data;	/* iface has some data ready? */
    int			have_blk;	/* iface has some blocks queued? */
    int			synced;		/* iface is at end of interval? */

    coral_timestamp_t	native_ts;	/* latest native timestamp from iface */
    struct timespec	latest_ts;	/* converted copy of native_ts */
    int			ts_is_valid;	/* is latest_ts valid? */
    struct timespec	prev_ts;	/* timestamp of previous packet */
    char		must_check_file_order;

    union {
	struct {
	    /* Info about block/cell data for interfaces with fixed sized
	     * records.  For devices, there will only be one block at a time,
	     * with its blknode stored directly in this structure.  For files,
	     * there my be multiple blocks; the current blknode is stored
	     * directly here, but the rest are malloc'd, and chained off the
	     * first.
	     */
	    coral_blknode_t node;	/* current block */
	    coral_blknode_t *tail;	/* last node in blknode list */
	    long blk_count;		/* # of blocks read */
	} blk;
	struct {
	    /* Info about block/record data for interfaces with variable
	     * sized records.
	     */
	    char *block;		/* raw block */
	    char *current;		/* start of current record */
	    unsigned long end;		/* offset of end of block */
	} vblk;
#ifdef HAVE_LIBPCAP
	struct {
	    struct pcap_pkthdr hdr;	/* pcap header of current pkt */
	    struct pcap_stat stats;	/* cumulative stats at last interval */
	} pcap;
#endif
    } u;

    coral_pktq_node_t *pktq_head;
    coral_pktq_node_t *pktq_tail;

#ifdef HAVE_LIBPCAP
    int pcap_proto;			/* pcap equiv of iface_info.datalink */
    pcap_t *user_pcap;			/* for coral_iface_to_pcapp() */
    struct bpf_program *bpfprog;	/* filter */
    pcap_t *internal_pcap;		/* needed for filter */
    int bpfprog_is_private;		/* true if allocated by libcoral */
    struct bpf_program *ip_bpfprog;	/* ipfilter */
    pcap_t *ip_pcap;			/* needed for ipfilter */
    struct bpf_program *prebpfprog;	/* prefilter (before ATM reassembly) */
#endif

    /* Info about packet data */
    coral_pkt_result_t pkt_result;
    coral_pkt_stats_t pkt_stats;
    coral_pkt_stats_t old_pkt_stats;
    coral_pkt_stats_t cur_pkt_stats;
    coral_pkt_buffer_t headerbuf;
    coral_pkt_buffer_t packetbuf;
    coral_pkt_buffer_t trailerbuf;
    void *statedata;
};


struct coral_source {
    coral_src_pfx			/* members visible in libcoral.h */
    coral_src_type_t	type;
    coral_dev_config_t	dev_config;	/* device configuration */
    int			filename_count;	/* number of items in filename_list */
    int			filename_index;	/* current item in filename_list */
    char **		filename_list;	/* list of filenames */
    char *		hardware;
    char *		encoding;		/* encoding, from file header */
    unsigned int	encoding_version;	/* encoding, from file header */
    int			iface_count;	/* number of interfaces in this src */
    void *		file;		/* file pointer for sources w/o fd's */
    char *		ubase;		/* mmapped blks or read buffer */
    coral_blk_info_t	binfo_buf;	/* place for driver to write blk info */
    int			preread;	/* how much of next blk we have */
    u_int		version;
    int			id[CORAL_MAXOPEN];	/* cinst indexes */
    int			api;		/* which API is used on this source */
    int			eof;		/* true if EOF/duration was reached */
    int			started;	/* true if start()ed but not stop()ed */
    int			can_reopen;	/* can src->filename be reopened? */
    int			can_seek;	/* can we lseek(src->fd)? */
    int			is_interleaved;	/* contains interleaved ifaces? */
    coral_proto_rule_list_t		proto_rules;

    /* used by coral_read_cell_common() and read_pkt_sort() */
    coral_iface_t *	current_iface;
    struct timespec	ts;		/* timestamp of current cell */
    /* used by read_pkt_sort() */
    int			pktq_size;	/* # of pkts on pktq */
    int			pktq_max;	/* # of pkts needed to guarantee sync */
    coral_pktq_node_t * pktq_head;	/* pending pkts */
    coral_pktq_node_t * pktq_tail;	/* pending pkts */
    coral_pktq_node_t * pktq_freelist;	/* freelist of pktq_nodes */
};

typedef enum {
    CORAL_ANON_ALG_NONE,
    CORAL_ANON_ALG_CRYPTOPAN,
    CORAL_ANON_ALG_ZERO
} coral_anon_alg_t;

struct coral_anon {
    coral_anon_alg_t alg;
    void *anonymizer;
    uint32_t keepmask;
    unsigned src:1;
    unsigned dst:1;
    unsigned keep:1;
    unsigned notrunc:1;
};

typedef struct {
    int maxsrc;				/* maximum number of sources */
    coral_dev_config_t dev_config;	/* default device configuration */
    unsigned long flags;
    long duration;
    struct timeval interval;
    /* fields above are initialized by CORAL_DEFAULT_CONFIG_INITIALIZER */
    struct timeval mintime;
    struct timeval maxtime;
    int errfile_is_private;		/* true if opened by liboral */
    coral_rotfile_t *err_rf;		/* rotating error file */
    int iomode_is_fixed;		/* if nonzero, user can't set iomode */
    int source_count;
    int filter_count;
    char *comment;
    const char *gzip;			/* gzip level/strategy */
    int user_polltime;			/* polltime was set by user config */
    long polltime;			/* microseconds to wait between polls */
    char *bpf_filter_text;
    char *bpf_ipfilter_text;
    char *bpf_prefilter_text;
    coral_anon_t anon;
    int api;
    uint64_t blks;	    /* counter */
    uint64_t cells;	    /* counter */
    uint64_t pkts;	    /* counter */
    uint64_t max_blks;	    /* maximum value of counter */
    uint64_t max_cells;	    /* maximum value of counter */
    uint64_t max_pkts;	    /* maximum value of counter */
    int argc;
    char **argv;
} coral_config_t;

extern coral_config_t coral_config;
extern FILE *coral_errfile;	/* declared in coral_print.c, not part of coral_config */


extern coral_proto_rule_list_t coral_proto_rules;

/* internal fxns */
static inline void coral_copy_fd_set(int nfds, fd_set *dst, fd_set *src)
{
    memcpy(dst, src, (nfds+31)/32 * 4);
}

static inline void coral_or_fd_set(int nfds, fd_set *dst, fd_set *src)
{
    int i;
    for (i = 0; i < (nfds+31)/32; i++)
        ((uint32_t*)dst)[i] |= ((uint32_t*)src)[i];
}

#define strerror(err) coral_strerror(NULL, err) /* never returns NULL */
#define crl_snappend(bufp, lenp, c) \
    do { if (*lenp > 1) { **(bufp) = c; *++*(bufp) = '\0'; --*(lenp); } } \
    while (0)
extern void crl_sncat(char **buf, int *len, const char *src, int srclen,
    const char *esc);
extern int crl_snprintf(char **buf, int *len, const char *fmt, ...);
extern void coral_snprint_data(char **dumpbuf, int *buflen, int indent,
    const u_char *data, int len);
extern void coral_debug(coral_source_t *src);
extern void coral_debug_all(void);
extern int coral_new_instance(coral_source_t *src, int sid);
extern void coral_file_check_iomode(coral_source_t *src);
extern void coral_set_dev_config_defaults(coral_dev_config_t *dev_config,
    const coral_dev_config_t *const default_config);
extern const coral_protolabel_t *coral_protolabel_by_name(const char *name);
extern void coral_dump_rules(coral_proto_rulenode_t *head, int indent);
extern void coral_mark_eof(coral_iface_t *iface);
extern s_stop_t coral_mark_eof_src;
extern coral_iface_t *coral_queue_nextblk(coral_source_t *src, int is_first,
    int endonly);
extern void coral_new_current_block(coral_iface_t *iface);
extern s_read_min_t	    coral_blk_read_min;
extern i_consume_t	    coral_cell_consume;
extern i_consume_pkt_t	    coral_atm_consume_pkt;
extern int coral_dequeue_block(coral_iface_t *iface);
extern void coral_init_atm_iface(coral_iface_t *iface);
extern int coral_aal5_reassemble(coral_iface_t *iface, coral_atm_cell_t *cell,
    coral_pkt_result_t *pkt_result);
extern coral_iface_t *coral_find_earliest_iface(coral_source_t *src);
extern s_stop_t coral_coraldev_stop;
extern s_start_t coral_coraldev_start;
extern s_close_t coral_blk_close;
extern i_update_pkt_stats_t coral_pcap_update_pkt_stats;
extern i_update_pkt_stats_t coral_dag_update_pkt_stats;
extern i_close_t coral_atm_iface_close;
extern const char *coral_bandwidth_fmt(int32_t bw);

extern void coral_rf_auto_start(struct timeval *tv);
extern void coral_rf_auto_end(void);
extern void coral_tmpname(char *buf);
extern const char *coral_gzmode(const char *gzmode);

extern long coral_check_block_duration(coral_iface_t *iface, const char *data,
    unsigned long cell_count, unsigned long start);
extern void coral_check_block_interval(coral_iface_t *iface);

extern void coral_align_interval(struct timespec *end,
    struct timespec *interval);

#ifdef CAN_CONVERT_TO_PCAP
extern pcap_t *coral_iface_to_alloced_pcapp(const coral_iface_t *iface, int raw);
#endif

extern int coral_freshen(coral_iface_t *iface, int want);
extern int coral_freshen_iface(coral_source_t *src, coral_iface_t *iface, int want,
    fd_set *rfds, fd_set *mfds, int *selectable);
enum { CORAL_WANT_TIME, CORAL_WANT_PKT };

extern coral_iface_t *coral_atm_read_pkt(coral_iface_t *iface);

extern ssize_t coral_readall(coral_source_t *src, void *buf, size_t want);
extern int coral_file_common_init(coral_source_t *src, size_t bufsize);
extern int coral_next_compound_file(coral_source_t *src);
#define has_another_file(src) (src->filename_index + 1 < src->filename_count)
extern s_read_min_t coral_file_read_min;
extern s_release_t coral_file_release;
extern s_close_t coral_file_close;
extern int coral_header_is_dagfile(const char *buffer, int len);
extern int coral_dag_common_init(coral_source_t *src, int ifcount, int isfirst);
extern coral_iface_t *coral_dagerf_read_any(coral_iface_t *target_iface);
extern coral_iface_t *coral_dagerf_read_iface(coral_iface_t *target_iface);

extern void normalize_if_needed(const coral_source_t *src, const coral_iface_t *iface);
extern int coral_infer_capture_time(coral_source_t *src);

extern void set_iface_duration(coral_iface_t *iface);
extern void coral_set_iface_capture_tv(coral_iface_t *iface,
    struct timespec *tspec, const coral_timestamp_t *tstamp);

extern i_clock_timespec_t coral_generic_clock_timespec;
extern i_clock_double_t coral_generic_clock_double;


extern coral_iface_t *(*coral_read_cell_all_common)
    (coral_blk_info_t **binfo, coral_atm_cell_t **cell, struct timeval *tv,
    coral_interval_result_t *int_result, struct timeval *interval);

/* coral_read_cell_all_common points to one of these */
extern coral_iface_t *coral_read_cell_natural(coral_blk_info_t **binfop,
    coral_atm_cell_t **cellp, struct timeval *tv,
    coral_interval_result_t *int_result, struct timeval *interval);
extern coral_iface_t *coral_read_cell_sorttime(coral_blk_info_t **binfop,
    coral_atm_cell_t **cellp, struct timeval *tv,
    coral_interval_result_t *int_result, struct timeval *interval);

#if 0 /* XXX */
extern coral_iface_t *coral_read_cell_sorttime_src(coral_source_t *src,
    coral_blk_info_t **binfop, coral_atm_cell_t **cellp, struct timeval *tv,
    coral_interval_result_t *int_result, struct timeval *interval);
#endif

/* get current cell of iface (for read_cell_{natural,sorttime}) */
#define coral_iccell(iface) \
    coral_nth_cell((iface), (iface)->u.blk.node.data, \
	(iface)->u.blk.node.index)

#ifdef HAVE_BPF_FILTER
extern int coral_pkt_filter(coral_iface_t *iface, pcap_t *pcap,
    struct bpf_program *bpfprog, const coral_pkt_buffer_t *pkt);
int coral_pcap_compile_verbose(coral_iface_t *iface, pcap_t *pcap,
    struct bpf_program *fp, char *str, int optimize, uint32_t netmask);
#endif


extern coral_iface_t *cinst[];
extern coral_source_t *csource[];
extern int coral_max_src, coral_max_iface;
extern coral_source_t *coral_fd_table[];
extern fd_set coral_select_fds;
extern int coral_select_fd_max;
extern int coral_select_count;
extern int coral_noselect_count;
extern int coral_offline_ifaces;
extern int coral_live_ifaces;
extern int coral_total_ifaces;


#include "crl_byteorder.h"

/* integer divide, and round UP */
#define divup(num, denom)	((num + denom - 1) / denom)

#ifdef HAVE_STRCASECMP
# define cstrcmp strcasecmp
#else
extern int cstrcmp(const char *s, const char *t);
#endif

/* internal data for duration */
extern struct timeval coral_duration_end;
extern int coral_all_running;

static inline struct timeval *calculate_timeout(
    struct timeval *timeout,	/* user-specified timeout */
    struct timeval *tvp)	/* buffer to write into if needed */
{
    static const struct timeval coral_tvzero = { 0, 0 };
    if (coral_duration_end.tv_sec >= 0) {
	gettimeofday(tvp, NULL);
	timersub(&coral_duration_end, tvp, tvp);
	if (!timeout || timercmp(tvp, timeout, <))
	    timeout = tvp;
	if (timercmp(timeout, &coral_tvzero, <)) {
	    timeout = tvp;
	    *tvp = coral_tvzero;
	}
    }
    return timeout;
}

/* If realtime passes duration, stop src and return 1, else return 0. */
static inline int realtime_duration_ended(coral_source_t *src)
{
    struct timeval tv;

    if (!src && !coral_all_running) return 1;
    if (coral_duration_end.tv_sec >= 0 &&
	(gettimeofday(&tv, NULL), timercmp(&tv, &coral_duration_end, >=)))
    {
	coral_diag(4, ("libcoral: duration expired in realtime\n"));
	src ? coral_stop(src) : coral_stop_all();
	return 1;
    }
    return 0;
}

/* If timestamp is past duration, stop src and return 1, else return 0. */
static inline int timestamp_duration_ended(coral_iface_t *iface,
    struct timespec *ts)
{
    if (iface->duration_end.tv_sec >= 0 &&
	timespeccmp(ts, &iface->duration_end, >))
    {
	/* End duration on this iface. */
	coral_diag(4, ("libcoral: duration expired on interface %d\n",
	    iface->id));
	coral_stop(iface->src);
	coral_mark_eof(iface);
	return 1;
    }
    return 0;
}

/* Consume the timestamp for iface.  Returns 1 if it was able to update a
 * timestamp on iface using buffered data, 0 if not.
 */
static inline int coral_consume(coral_iface_t *iface, int want)
{
#if 0 /* this would break the end-timestamp of the cell-api interval at eof */
    iface->native_ts.tv_sec = iface->native_ts.tv_nsec = -1;
    iface->latest_ts.tv_sec = iface->latest_ts.tv_nsec = -1;
    iface->ts_is_valid = 0;
#endif
    iface->have_data = iface->iface_type->consume &&
	iface->iface_type->consume(iface, want);
    return iface->have_data;
}

/* coral_blk_prep_pkt()
 * iface - iface on which packet is stored
 * blkiface - iface on which block is stored
 */
#define coral_blk_prep_pkt(iface, blkiface, clockfunc) \
do { \
    iface->pkt_result.packet->parent_proto = CORAL_PROTO_UNKNOWN; \
    iface->synced = (blkiface->u.blk.node.index >= blkiface->u.blk.node.next_int); \
    /* We wust set iface->latest_ts at end of interval or duration if not
     * sorting, or always if sorting.  Reaching cell_count means we may have
     * reached duration. */ \
    if (coral_config.flags & CORAL_OPT_SORT_TIME || iface->synced || \
	blkiface->u.blk.node.index >= blkiface->u.blk.node.cell_count - 1) \
    { \
	coral_set_native_ts(iface, iface->pkt_result.timestamp); \
	coral_update_latest_ts2(iface, clockfunc); \
    } \
} while (0)

#define coral_normalize_timespec(iface, tspec) \
    do { \
	(tspec)->tv_sec += (iface)->iface_info.capture_tv.tv_sec; \
	(tspec)->tv_nsec += (iface)->iface_info.capture_tv.tv_usec * 1000; \
	if ((tspec)->tv_nsec >= 1000000000) { \
	    (tspec)->tv_sec++; \
	    (tspec)->tv_nsec -= 1000000000; \
	} \
    } while(0)

/* cache test is inlined; func is inlined if possible */
#define coral_clock_timespec_inline2(iface, t, tspec, func, normalize) \
    do { \
	if ((iface)->raw_ts.i[0] != (t)->i[0] || \
	    (iface)->raw_ts.i[1] != (t)->i[1]) \
	{ \
	    /*coral_internal_stats.clock_timespec++;*/ \
	    /* calculate and cache results */ \
	    func((iface), t, &(iface)->cached_ts); \
	    (iface)->raw_ts = *(t); \
	    (iface)->cached_tsn_valid = 0; \
	} \
	if (normalize && !(iface)->time_is_normal) { \
	    if (!(iface)->cached_tsn_valid) { \
		(iface)->cached_tsn = (iface)->cached_ts; \
		coral_normalize_timespec(iface, &(iface)->cached_tsn); \
		(iface)->cached_tsn_valid = 1; \
	    } \
	    (*tspec) = (iface)->cached_tsn; \
	} else { \
	    /* fetch cached results */ \
	    (*tspec) = (iface)->cached_ts; \
	} \
    } while (0)

/* like coral_clock_timespec_inline2, but use configured normalize flag */
#define coral_clock_timespec_inline2_nf(iface, t, tspec, func) \
    coral_clock_timespec_inline2(iface, t, tspec, func, \
	coral_config.flags & CORAL_OPT_NORMALIZE_TIME)

/* cache test is inlined, but func isn't */
#define coral_clock_timespec_inline(iface, t, tspec, normalize) \
    coral_clock_timespec_inline2(iface, t, tspec, \
	(iface)->iface_type->clock_read_timespec, normalize)

/* like coral_clock_timespec_inline, but use configured normalize flag */
#define coral_clock_timespec_inline_nf(iface, t, tspec) \
    coral_clock_timespec_inline(iface, t, tspec, \
	coral_config.flags & CORAL_OPT_NORMALIZE_TIME)


/* Current timestamp macros.
 * The code for some interfaces can use native timestamps for comparison
 * against period_end, so they set native_ts (with set_native_ts()) and
 * avoid conversion; if the timespec is needed later, update_latest_ts()
 * is used to do the conversion; if called multiple times, it will only
 * convert once.
 * Code for other interfaces always operates on timespecs, so doesn't set
 * native_ts, but sets latest_ts directly with set_latest_ts().
 */

/* set native_ts.  Must be converted later if latest_ts is needed. */
#define coral_set_native_ts(iface, t) \
    do { \
	(iface)->native_ts = *(t); \
	(iface)->ts_is_valid = 0; \
    } while (0)

/* convert native_ts to latest_ts, inlining func if possible */
#define coral_update_latest_ts2(iface, func) \
    do { \
	if (!(iface)->ts_is_valid) { \
	    coral_clock_timespec_inline2_nf((iface), &(iface)->native_ts, \
		&(iface)->latest_ts, func); \
	    (iface)->ts_is_valid = 1; \
	} \
    } while (0)

/* set native_ts and latest_ts, inlining func if possible */
/* for generic code that works for both kinds of interfaces */
#define coral_set_ts2(iface, t, func) \
    do { \
	(iface)->native_ts = *(t); \
	coral_clock_timespec_inline2_nf(iface, t, &(iface)->latest_ts, func); \
	(iface)->ts_is_valid = 1; \
    } while (0)

/* set latest_ts directly, skipping native_ts, inlining func if possible */
#define coral_set_latest_ts2(iface, t, func) \
    do { \
	coral_clock_timespec_inline2_nf(iface, t, &(iface)->latest_ts, func); \
	(iface)->ts_is_valid = 1; \
    } while (0)

/* convert native_ts to latest_ts, using iface's func pointer */
#define coral_update_latest_ts(iface) \
    coral_update_latest_ts2(iface, (iface)->iface_type->clock_read_timespec)

/* set native_ts and latest_ts, using iface's func pointer */
#define coral_set_ts(iface, t) \
    coral_set_ts2(iface, t, (iface)->iface_type->clock_read_timespec)

/* set latest_ts, using iface's func pointer */
#define coral_set_latest_ts(iface, t) \
    coral_set_latest_ts2(iface, t, (iface)->iface_type->clock_read_timespec)


#if 0
typedef struct {
    uint64_t clock_order;
    uint64_t clock_timespec;
    uint64_t clock_double;
} coral_internal_stats_t;

extern coral_internal_stats_t coral_internal_stats;
#endif

static inline int coral_check_file_order(coral_iface_t *iface)
{
    if (iface->must_check_file_order) {
	iface->must_check_file_order = 0;
	coral_update_latest_ts(iface);
	if (timespeccmp(&iface->prev_ts, &iface->latest_ts, >)) {
	    coral_diag(0, ("Error: files %s and %s of compound source are not in correct order.\n",
		iface->src->filename_list[iface->src->filename_index-1],
		iface->src->filename));
	    coral_close(iface->src);
	    errno = CORAL_EBADTIME;
	    return 0;
	}
    }
    return 1;
}

static inline coral_iface_t *coral_read_any(coral_iface_t *iface) {
    coral_iface_t *result = iface->src->type.read_any(iface);
    if (result && !coral_check_file_order(result))
	return NULL;
    return result;
}

static inline coral_iface_t *coral_read_iface(coral_iface_t *iface) {
    coral_iface_t *result = iface->src->type.read_iface(iface);
    if (result && !coral_check_file_order(result))
	return NULL;
    return result;
}

/* copy *p to newly allocated memory.  p must be properly typed. */
#define objdup(p)   memcpy(malloc(sizeof(*p)), p, sizeof(*p))

/* protocol parsers */
#ifdef HAVE_ARPA_NAMESER_H
extern int coral_get_dns_payload(const coral_pkt_buffer_t *src,
    coral_pkt_buffer_t *dst, char *dumpbuf, int buflen);
#endif

#endif /* LIBCORAL_PRIV_H */
