#! /usr/local/bin/perl -w
## 
## Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
## All Rights Reserved 
## 
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
## 
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
## 
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
## 
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
## 
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program. Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
## 
## Report bugs and suggestions to coral-bugs@caida.org.
## 

## $Id: crl_tos.pl,v 1.33 2007/06/06 18:17:30 kkeys Exp $
## $Author: kkeys $
## $Name: release-3-8-1 $
## $Revision: 1.33 $
##
## USAGE:  crl_tos.pl <Coral Dump>
##

my $coral_dir;
BEGIN { $coral_dir = "/usr/local/Coral"; } # This will be edited during build.
use lib "$coral_dir/lib"; #coral global libdir#
use lib "../../lib"; #coral local libdir#
use CRL;
use strict;

my $ip_opts = new Unpacker("ip", ["ip_tos"]);

Coral::set_duration(0);
Coral::quick_start(0);
Coral::read_pkt_init(undef, undef);

my $packet = new Coral::Pkt_result;

my (%seen_tos, %total_packets);
my $iface;
while (defined($iface = Coral::read_pkt($packet))) {
    my ($interface) = Coral::interface_get_number($iface);

    my $ip_record = Coral::get_ip($iface, $packet->packet);
    if (!defined $ip_record) { next; } # not an ipv4 packet

    my ($ip_tos) = $ip_opts->unpack($ip_record);

    $seen_tos{$interface}{$ip_tos}++;
    $total_packets{$interface}++;

    $seen_tos{"both"}{$ip_tos}++;
    $total_packets{"both"}++;
}

my @interfaces = (0, 1, "both");

foreach my $interface (@interfaces) {
    if (!defined $total_packets{$interface}) {
	$total_packets{$interface} = 0;
    }

    printf("\n# Interface: %s\tTotal packets: %.f\n",
	   $interface, $total_packets{$interface});
    print "TOS\t% of packets\n";

    foreach my $tos (sort { $a <=> $b } keys %{ $seen_tos{$interface} }) {
	
        printf("0x%02x\t%.5f\n", $tos, 
	       $seen_tos{$interface}{$tos}/$total_packets{$interface}*100);
    }
}


