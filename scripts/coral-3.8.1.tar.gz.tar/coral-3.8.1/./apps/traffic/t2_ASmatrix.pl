#!/usr/local/bin/perl -w
## 
## Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
## All Rights Reserved 
## 
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
## 
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
## 
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
## 
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
## 
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program. Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
## 
## Report bugs and suggestions to coral-bugs@caida.org.
## 

use strict;

use Getopt::Std;
use vars qw($opt_S $opt_n);
my ($byte_sort, $pkt_sort, $flow_sort);

my $coral_dir;
BEGIN { $coral_dir = "/usr/local/Coral"; } # This will be edited during build.
use lib "$coral_dir/lib"; #coral global libdir#
use lib "../../lib"; #coral local libdir#

$| = 1;                 # don't buffer output

my ($pname) = $0 =~ m#([^/]+)$#;

if (!getopts('S:n:') or @ARGV != 1) {
    print STDERR "Usage: crl_traffic2 {crl_traffic2_options} | ",
				"$pname {${pname}_options} <route table>\n",
	    "   Or: $pname {${pname}_options} <route table> < file.t2\n",
	    "$pname options:\n",
	    "-S[bpf] controls sorting options as follows:\n",
	    "        b sorts by bytes.\n",
	    "        p sorts by packets.\n",
	    "        f sorts by flows.\n",
	    "   (with no sorting option, entries will be sorted by keys)\n",
	    "-n<topn> limits the number of displayed entries to topn.\n",
	    "   (defaults to showing all)\n";
    exit 1;
}

if ($opt_S) {
    $byte_sort = ($opt_S =~ /b/);
    $pkt_sort = ($opt_S =~ /p/);
    $flow_sort = ($opt_S =~ /f/);
}

my $route_table = shift @ARGV;

use CAIDA::ASFinder;
my $as_finder = new CAIDA::ASFinder();
$as_finder->load_file_text($route_table);

use CAIDA::Tables::Tuple_Table;
my $tuple_table = new CAIDA::Tables::Tuple_Table;

my $intable = 0;
my $line;
my $style;

$line = <STDIN>;
while (defined $line) {
    if ($line =~ /^#/ && $intable) {
	my $as_matrix = $tuple_table->make_AS_Matrix({'as_finder'=>$as_finder});
	my $top_n = -1; # Show all for default
	my @values;
	if ($opt_n) {
	    $top_n = $opt_n;
	}
	if ($byte_sort) {
	    @values = $as_matrix->sort_by_bytes($top_n);
	} elsif ($pkt_sort) {
	    @values = $as_matrix->sort_by_pkts($top_n);
	} elsif ($flow_sort) {
	    @values = $as_matrix->sort_by_flows($top_n);
	} else { 
	    @values = $as_matrix->sort_by_keys($top_n, 1);
	}
	foreach my $key (@values) {
	    my ($src_as, $dst_as) = $as_matrix->get_key_fields($key);
	    my $count = $as_matrix->data()->{$key};
	    printf "%16s %16s %6.f %8.f %9.f\n", $src_as, $dst_as,
			$count->flows(), $count->pkts(), $count->bytes();
	}
	$intable = 0;
	# comment this out to make each output cumulative
	$tuple_table = new CAIDA::Tables::Tuple_Table;
    }
    if (!$intable) {
	if ($line =~ /^#src/) {
	    printf("#%15s %16s %6s %8s %9s\n",
		"src AS", "dst AS", "flows", "pkts", "bytes");
	    $style = 'text';
	    $intable = 1;
	} elsif ($line =~ /^#binary/) {
	    printf("#%15s %16s %6s %8s %9s\n",
		"src AS", "dst AS", "flows", "pkts", "bytes");
	    $style = 'binary';
	    $intable = 1;
	} else {
	    $line =~ s/Tuple Table/AS Matrix/g if $line =~ /Tuple Table/;
	    print $line;
	    $line = <STDIN>;
	    next;
	}
    }
    # we have table data to read
    if ($style eq 'text') {
	$line = $tuple_table->load_text(\*STDIN);
    } elsif ($style eq 'binary') {
	$line = $tuple_table->load_binary(\*STDIN);
    } else {
	die "Unknown file format!";
    }
}
