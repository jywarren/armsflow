## 
## Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
## All Rights Reserved 
## 
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
## 
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
## 
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
## 
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
## 
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program. Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
## 
## Report bugs and suggestions to coral-bugs@caida.org.
## 

package Flow_Hist;
use Carp;

# in the future we'll have a few different flow subclasses for doing
# things like timeout or syn/fin flows in addition to bin based flows.
my %fields = (
	      'histogram_cnt_hash_ref'	=> undef,
	      'current_flows_hash_ref'	=> undef,
	      'bin_size'		=> undef,
	      'first_bin'		=> undef,
	      'previous_bin'		=> undef,
	      'flow_cnt'		=> undef,
	     );

sub new {
    my ($class, $bin_size) = @_;
    my $self = { %fields };

    bless $self, $class;

    $self->{'histogram_cnt_hash_ref'} = {};
    $self->{'bin_size'} = $bin_size;

    return $self;
}


# XXX - This still probably doesn't handle it well if the clock goes
# backwards.  Or maybe it's ok, hmm.  Problem's probably more in the
# get_next_cell logic.

sub saw_time {
    my ($self, $timestamp) = @_;
    my $bin = int($timestamp / $self->{'bin_size'});
    # * $self->{'bin_size'};

#print STDERR "bin:\t$bin\t$timestamp\n";

    if (defined $self->{'previous_bin'} && $bin < $self->{'previous_bin'}) {
	printf STDERR ("saw_flow: clock moved backwards: %.f -> %.f bin\n",
		       $self->{'previous_bin'}, $bin);
    }

    # if this is the first bin, or the clock moved backwards set everything
    # up.  (we ignore data in the bin proceeding/following a clock rewind).
    if (!defined $self->{'first_bin'} || $bin < $self->{'previous_bin'}) {

	$self->{'first_bin'} = $bin;
	$self->{'previous_bin'} = $bin;
	$self->{'current_flows_hash_ref'} = {};
    }

    # ignore everything in the first bin, since it might be partial
    if ($bin == $self->{'first_bin'}) {
	return 0;
    }

    # If we're starting another bin, copy the statistics for the previous
    # bin and clear out the current one for new data.
    if ($bin != $self->{'previous_bin'}) {
	
	if ($self->{'previous_bin'} != $self->{'first_bin'}) {
	    my $flow_cnt = $self->{'flow_cnt'};
#print STDERR "Adding $flow_cnt flows to the histogram at bin $bin.\n";
	    $self->{'histogram_cnt_hash_ref'}{$flow_cnt}++;
	}

	# if we skipped some bins, insert the 0 flows for them
	for (my $i = $self->{'previous_bin'} + 1; $i < $bin; $i++) {
#print STDERR "Skipping bin $bin.\n";
	    $self->{'histogram_cnt_hash_ref'}{0}++;
	}

	$self->{'flow_cnt'} = 0;
	undef %{ $self->{'current_flows_hash_ref'} };
	$self->{'current_flows_hash_ref'} = {};
	$self->{'previous_bin'} = $bin;
    }

    return 1;
}


sub saw_flow {
    my ($self, $key, $timestamp) = @_;

    # update existing bin stuff, and are we skipping this bin?
    if (!$self->saw_time($timestamp)) {
	return;
    }

    # Mark that we saw this flow.
    if (!defined $self->{'current_flows_hash_ref'}{$key}) {
	$self->{'flow_cnt'}++;
    }
    $self->{'current_flows_hash_ref'}{$key}++;
}



sub stats {
    my ($self) = @_;

    my $min;
    my $max;
    my $avg_tot = 0;
    my $n = 0;

    while (my ($flow_cnt, $hist_cnt) = 
	   each %{ $self->{'histogram_cnt_hash_ref'} }) {
	if (!defined $min || $flow_cnt < $min) {
	    $min = $flow_cnt;
	}
	if (!defined $max || $flow_cnt > $max) {
	    $max = $flow_cnt;
	}
	$avg_tot += $flow_cnt * $hist_cnt;
	$n += $hist_cnt;
    }

    my $median;
    my $counter = 0;

    foreach my $flow_cnt (sort { $a <=> $b } keys %{ $self->{'histogram_cnt_hash_ref'} }) {
	my $hist_cnt = $self->{'histogram_cnt_hash_ref'}{$flow_cnt};
	$counter += $hist_cnt;
	if ($counter > $n/2) {
	    $median = $flow_cnt;
	    last;
	}
    }

    return ($n, $min, $max, (($n > 0) ? $avg_tot/$n : undef), $median);
}


sub print_stats {
    my ($self, $fh) = @_;

    if (!defined $fh) {
	$fh = \*STDOUT;
    }

    my ($n, $min, $max, $avg, $median) = $self->stats();

    if (0) {
	printf $fh ("bin size: %f seconds\n", $self->{'bin_size'});
	printf $fh ("number of complete bins measured: %.f\n", $n);
	if ($n > 0) {
	    printf $fh ("min number of flows in any time bin: %.f\n", $min);
	    printf $fh ("max number of flows in any time bin: %.f\n", $max);
	    printf $fh ("avg number of flows in any time bin: %f\n", $avg);
	    printf $fh ("med number of flows in any time bin: %.f\n", $median);
	}
	printf $fh ("\n");
    } else {
	if ($n == 0) {
	    $min = $max = $avg = $median = 0;
	}
	printf $fh ("%8.5f\t%.f\t\t\t%.f\t%.2f\t%.f\t%.f\n",
		    $self->{'bin_size'}, $n, $min, $avg, $median, $max);
    }
}

1;
