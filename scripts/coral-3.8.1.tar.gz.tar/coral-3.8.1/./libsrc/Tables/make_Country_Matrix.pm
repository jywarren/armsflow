## 
## Copyright 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
## All Rights Reserved 
## 
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
## 
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
## 
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
## 
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
## 
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program. Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
## 
## Report bugs and suggestions to coral-bugs@caida.org.
## 

package CAIDA::Tables::make_Country_Matrix;
require Exporter;
@ISA = qw(Exporter);
@EXPORT = qw(&make_Country_Matrix);

# Define required CVS variables
$cvs_Id = '$Id: make_Country_Matrix.pm,v 1.17 2007/06/06 18:17:48 kkeys Exp $';
$cvs_Author = '$Author: kkeys $';
$cvs_Name = '$Name: release-3-8-1 $';
$cvs_Revision = '$Revision: 1.17 $';


use Carp;
use CAIDA::Tables::get_Country;
use strict;

sub make_Country_Matrix (@ ) {
    my ($self, $args) = @_;
    my $netacq = $args->{'netacq'};
    my $countries = $args->{'countries'};
    my $netgeo = $args->{'netgeo'};
    my $as_finder = $args->{'as_finder'};
    my $abbr_len = $args->{'country_abbr'};
    $abbr_len = 2 unless defined $abbr_len;
    my ($has_ip, $uses_ip, $uses_as);
    $uses_as = 1 if ref($self) =~ /AS_Matrix/;
    if (ref($self) =~ /Tuple_Table/ or ref($self) =~ /IP_Matrix/) {
	$has_ip = 1;
	if ($netacq) {
	    $uses_ip = 1;
	} else {
	    $uses_as = 1;
	}
    }

    if ($uses_as and $has_ip and not $as_finder) {
	die "Need an ASFinder object to do country lookups.";
    } elsif ($uses_as and not $netgeo) {
	die "Need a NetGeoClient object to do country lookups.";
    }

    my $temp_table;
    if ($uses_as and ref($self) !~ /AS_Matrix/) {
	$temp_table = $self->make_AS_Matrix($args);
    } else {
	$temp_table = $self;
    }

    require CAIDA::Tables::Country_Matrix;
    my $country_matrix = new CAIDA::Tables::Country_Matrix();
    # Loop over table elements, collecting keys
    my %keys; # Hash to uniqueify
    foreach my $opaque_key (keys %{ $temp_table->data() }) {
	my ($key1, $key2) = $temp_table->get_key_fields($opaque_key);
	$keys{$key1}++;
	$keys{$key2}++;
    }

    my $key_to_loc_ref;
    # Do table key -> country conversion
    if ($uses_ip) {
	$key_to_loc_ref = _get_locs_byIP($netacq, $countries, $abbr_len,
					    keys %keys);
    } elsif ($uses_as) {
	$key_to_loc_ref = _get_locs_byAS($netgeo, $countries, $abbr_len,
					    keys %keys);
    }

    # Loop over table elements, making Country Matrix
    while (my ($opaque_key, $counts) = each %{ $temp_table->data() }) {
	my ($key1, $key2) = $temp_table->get_key_fields($opaque_key);
	my $loc_ref1 = $key_to_loc_ref->{$key1};
	my $loc_ref2 = $key_to_loc_ref->{$key2};
	my ($country1, $country2) = ('UNKNOWN', 'UNKNOWN');
	($country1) = @$loc_ref1 if defined $loc_ref1;
	($country2) = @$loc_ref2 if defined $loc_ref2;
	$country_matrix->entry_add($country1, $country2, $counts);
    }
    $country_matrix->total->add($self->other);
    $country_matrix->other->add($self->other);
    return $country_matrix;
}

1;
