#!/usr/local/bin/perl
## $Id: create_report.pl,v 1.12 2007/06/07 18:27:49 rkoga Exp $ $Name: release-3-8-1 $
## 
## Copyright 2005, 2007
## The Regents of the University of California 
## All Rights Reserved 
## 
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
## 
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
## 
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
## 
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
## 
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program.  Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
## 
## Report bugs and suggestions to coral-bugs@caida.org.
## 

use warnings;
use strict;

my $coral_dir;
BEGIN { $coral_dir = "/usr/local/Coral"; } # This will be edited during build.
use lib "$coral_dir/lib"; #coral global libdir#
use lib "../../../lib"; #coral local libdir#
use CAIDA::Traffic2::ReportSupport;
use File::Basename;
use File::stat;
use Getopt::Std;
use File::Glob ':glob';

use vars qw($opt_f);
getopts("f");

my %mon_config;
my %shared_config;
my $monitor_pat = '\s*monitor\s*{';
my $shared_pat = '\s*shared\s*{';
my @updated;

my (undef, $path) = fileparse($0);

if (@ARGV != 1) {
    print STDERR "Usage: $0 [-f] <config_file>\n";
    print STDERR "\t-f   force graph generation even if up to date\n";
    exit 1;
}

my ($config_file) = @ARGV;
open CONFIG, $config_file or die "Couldn't open config file $config_file: $!";

parse_config(\*CONFIG, {$monitor_pat => \%mon_config,
			$shared_pat => \%shared_config});
my $default = $shared_config{'default'};
my $non_creation_warning = get_config_var($shared_config{'general'},
					    'non_creation_warning');
close CONFIG;
foreach my $mon_name (get_config_keys(\%mon_config)) {
    my $stanza = $mon_config{$mon_name};
    my $rrd_store_dir = get_best_var($default, $stanza, 'rrd_dir');
    my $graph_dir = get_best_var($default, $stanza, 'graph_dir');
    my $datastat = stat "$rrd_store_dir/$mon_name/.lastdata";
    next unless defined $datastat; # Even with regeneration, need data to exist
    my $graphstat = stat "$graph_dir/$mon_name/.graphsdone";
    if ($opt_f or not defined $graphstat or
	$datastat->mtime > $graphstat->mtime)
    {
	push @updated, $mon_name;
    }
}
if (@updated == 0) {
    if ($non_creation_warning) {
	print STDERR "Note: no graphs were created because no monitors ",
		    "have updated data.\n",
		    "Try using $0 -f to force graph regeneration.\n";
    }
    exit;
}
system "cat $config_file | ${path}config_graphs " . join(' ', @updated) .
	" | ${path}create_graphs";
foreach my $mon (@updated) {
    my $graph_dir = get_best_var($default, $mon_config{$mon}, 'graph_dir');
    system "touch $graph_dir/$mon/.graphsdone" if -d "$graph_dir/$mon";
}
my $transfer_stanza = $shared_config{'transfer'};
if (defined $transfer_stanza) {
    my $cp_cmd = get_config_var($transfer_stanza, 'cp_cmd');
    my $cgi_dir = get_config_var($transfer_stanza, 'cgi_dir');
    my $html_dir = get_config_var($transfer_stanza, 'html_dir');
    my $server = get_config_var($transfer_stanza, 'server');
    if (defined $server) { # Allow for local transfers with cp/mv
	$server .= ":"
    } else {
	$server = "";
    }
    foreach my $mon (@updated) {
	my $stanza = $mon_config{$mon};
	my $graph_dir = get_best_var($default, $stanza, 'graph_dir');
	my $big_dir = get_best_var($default, $stanza, 'big_dir');
	my $table_dir = get_best_var($default, $stanza, 'table_dir');
	my $make_big_ts = get_best_var($default, $stanza, 'make_big_ts');
	my $make_table = get_best_var($default, $stanza, 'make_table');
	if (bsd_glob "$graph_dir/$mon/*.png") {
	    system "$cp_cmd $graph_dir/$mon/*.png $server$html_dir/$mon";
	}
	if ($make_big_ts and bsd_glob "$big_dir/$mon/*.png") {
	    system "$cp_cmd $big_dir/$mon/*.png $server$html_dir/$mon/big";
	}
	if (bsd_glob "$graph_dir/$mon/*.txt") {
	    system "$cp_cmd $graph_dir/$mon/*.txt $server$cgi_dir/$mon";
	}
	if ($make_table and bsd_glob "$table_dir/$mon/*.txt") {
	    system "$cp_cmd $table_dir/$mon/*.txt $server$cgi_dir/$mon";
	}
    }
}
