/* 
 * Copyright 2002, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program.  Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

//----------------------------------------------------------------------------
//       template <class Data> class Ipv4PrefixPatricia
//       template <class Data> class Ipv6PrefixPatricia
//----------------------------------------------------------------------------
//  These template classes implement a Patricia tree keyed by prefix, which
//  is represented by a Ipv4Network or Ipv6Network.  They are derived from
//  IpPrefixPatricia<>, which contains all the real code.  It is particularly
//  useful for storing any type of data keyed by IP address.  Because it's
//  Patricia, exact match searches are relatively speedy.  So are
//  longest-match searches.
//
//  The Ipv4Network or Ipv6Network used as the key must be normalized, i.e.
//  all bits beyond the masklen must be 0.  This happens automatically if the
//  Ipv4Network or Ipv6Network constructors are used.
//
//  The interfaces here are very STL-like.  For the most part, missing
//  features are missing only because they weren't needed.  Unlike
//  dwm's implementation, no features are left out for performance reasons; in
//  particular, all iterators _can_ be incremented and decremented (and
//  iterating from begin() to end() has performance equal to that of visit()).
//
//  Iterator traversal is preorder, not inorder; so it would give, e.g.,
//  42.0.0.0/8 42.0.0.0/16 42.128.0.0/16
//  (dwm's old implementation would have given the less useful
//  42.0.0.0/16 42.0.0.0/8 42.128.0.0/16).
//
//  operator[] works just like it does for STL's <map>: it will insert if the
//  key was not found.  This permits using it on the left hand side of a
//  statement for assignment of a value in the tree.
//
//  erase() members work as expected, removing a key or value from the
//  tree.  They do not invalidate any iterators other than those pointing to
//  the values being erased.
//
//  LongestMatch(addr) returns an iterator pointing to the longest matching
//  prefix.
//
//  ShortestMatchIt(addr) and LongestMatchIt(addr) return a match_iterator
//  or const_match_iterator instead of a normal iterator.  Incrementing
//  (decrementing) a match_iterator makes it point to a longer (shorter)
//  matching prefix.  If it has walked off the end, it will equal
//  endMatchIt().
//
//  TODO:  aggregate() member that eliminates prefixes inside other prefixes
//  and joins neighboring prefixes into a single prefix to produce the
//  smallest set of prefixes that covers the same space as the original set.
//  (But what do we do with the data when we merge/delete prefixes?)
//
//  Ken Keys
//  CAIDA
//  June 2003
//
//----------------------------------------------------------------------------

#ifndef IPPREFIXPATRICIA_HH
#define IPPREFIXPATRICIA_HH

extern "C" {
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <assert.h>

#include "caida_t.h"
}

#include <utility>
#include <iterator>


template <class It>
class Const_Iterator_Base
{
    It it;
public:
    Const_Iterator_Base() : it() {}
    Const_Iterator_Base(It &i) : it(i) {}
    Const_Iterator_Base & operator++ () { ++it; return *this; }
    Const_Iterator_Base & operator-- () { --it; return *this; }
    void operator++ (int) { ++it; }
    void operator-- (int) { --it; }
    const typename It::value_type & operator* () const { return *it; }
    bool operator!= (const It & rhs) const
	{ return it != rhs; }
    bool operator!= (const Const_Iterator_Base & rhs) const
	{ return it != rhs.it; }
    bool operator== (const It & rhs) const
	{ return it == rhs; }
    bool operator== (const Const_Iterator_Base & rhs) const
	{ return it == rhs.it; }
};

template <class It>
class Const_Iterator : public Const_Iterator_Base<It>
{
    typedef Const_Iterator_Base<It> Base;
public:
    Const_Iterator() : Base() {};
    Const_Iterator(It i) : Base(i) {};
};


// The Patricia Trie
template <class Key, class Data>
class IpPrefixPatricia
{
public:
    typedef Key					key_type;
    typedef Data				data_type;
    typedef typename Key::ipaddr_type		ipaddr_type;
    typedef std::pair<const key_type, data_type>	value_type;
    typedef uint32_t				size_type;
    static const int family = Key::family;

private:
    enum { useNode = 0x1, useLeft = 0x2, useRight = 0x4 };
    static const size_t nbits = sizeof(key_type) * 8;

    class Node {
    public:
	typename IpPrefixPatricia::value_type	val;
	bool		has_data;   // val.second (i.e., data) is valid
	Node		*left;	    // left child node
	Node		*right;	    // right child node
	Node		*parent;    // parent node

	Node() : val(), left(), right(), parent() {};

	Node(const IpPrefixPatricia::value_type &value, Node *p = 0) :
	    val(value), has_data(true), left(), right(), parent(p) { };

	Node(const IpPrefixPatricia::key_type &key, Node *p = 0) :
	    val(value_type(key, data_type())), has_data(false),
	    left(), right(), parent(p) { };

	// deep-copy constructor from the tree rooted at src, with newparent as
	// the new tree's parent node.
	Node(const Node *src, Node *newparent) :
	    val(src->val), has_data(src->has_data), parent(newparent)
	{
	    this->left = src->left ? new Node(src->left, this) : NULL;
	    this->right = src->right ? new Node(src->right, this) : NULL;
	}

	// like Ipv4Network::Matches(), but also handles maskLen 0
	bool Matches(const ipaddr_type &addr) const {
	    return (val.first.maskLen == 0) || val.first.Matches(addr);
	}

	void clear() {
	    if (left) { left->clear(); delete left; }
	    if (right) { right->clear(); delete right; }
	}
    };

    size_type	_size;
    Node	*root;

public:

    // bidirectional_iterator is not part of C++ standard, we must define it
    // ourselves
    template<typename _Tp, typename _Distance>
    struct bidirectional_iterator {
	typedef std::bidirectional_iterator_tag iterator_category;
	typedef _Tp                        value_type;
	typedef _Distance                  difference_type;
	typedef _Tp*                       pointer;
	typedef _Tp&                       reference;
    };

    class iterator : public bidirectional_iterator<value_type, ptrdiff_t>
    {
	Node *node;
	friend class IpPrefixPatricia<Key, Data>;

    public:
	// constructor
	iterator(Node *n = 0) : node(n) {};

	// destructor
	virtual ~iterator() { node = (Node *)0; }

	virtual iterator & operator= (const iterator & src)
	{
	    node = src.node;
	    return *this;
	}

	iterator & operator++ ()  // prefix ++
	{
	    if (!node) return *this;
	    unsigned int state = useLeft | useRight;

	    // find next node with data in preorder traversal
	    while (1) {
		if ((state & useNode) && node->has_data) {
		    return *this;
		} else if ((state & useLeft) && node->left) {
		    state = useNode | useLeft | useRight;
		    node = node->left;
		} else if ((state & useRight) && node->right) {
		    state = useNode | useLeft | useRight;
		    node = node->right;
		} else if (node->parent) {
		    state = 0;
		    if (node == node->parent->left)
			state |= useRight;
		    node = node->parent;
		} else {
		    node = NULL;
		    return *this;
		}
	    }
	}

	iterator & operator-- ()  // prefix --
	{
	    if (!node) return *this;
	    unsigned int state = 0;

	    while (1) {
		if ((state & useRight) && node->right) {
		    state = useNode | useLeft | useRight;
		    node = node->right;
		} else if ((state & useLeft) && node->left) {
		    state = useNode | useLeft | useRight;
		    node = node->left;
		} else if ((state & useNode) && node->has_data) {
		    return *this;
		} else if (node->parent) {
		    state = useNode;
		    if (node == node->parent->right)
			state |= useLeft;
		    node = node->parent;
		} else {
		    node = NULL;
		    return *this;
		}
	    }
	}

	void operator++ (int)  // postfix ++
	    { ++*this; }

	void operator-- (int)  // postfix --
	    { --*this; }

	virtual typename iterator::value_type & operator* ()
	    { return node->val; }

	virtual const typename iterator::value_type & operator* () const
	    { return node->val; }

	bool operator!= (const iterator & rhs) const
	    { return this->node != rhs.node; }

	bool operator== (const iterator & rhs) const
	    { return this->node == rhs.node; }
    };

    class reverse_iterator : public bidirectional_iterator<value_type, ptrdiff_t>
    {
	iterator fwd;
    public:
	reverse_iterator(Node *node = 0) : fwd(node) {};
	virtual ~reverse_iterator() {};
	reverse_iterator & operator++ () { --fwd; return *this; }
	void operator++ (int) { ++*this; }
	reverse_iterator & operator-- () { ++fwd; return *this; }
	void operator-- (int) { --*this; }
	const typename reverse_iterator::value_type & operator* () const
	    { return *fwd; }
	bool operator!= (const reverse_iterator & rit) const
	    { return fwd != rit.fwd; }
	bool operator== (const reverse_iterator & rit) const
	    { return fwd == rit.fwd; }
    };

    class match_iterator : public bidirectional_iterator<value_type, ptrdiff_t>
    {
	Node *node;
	ipaddr_type addr;
	friend class IpPrefixPatricia<Key, Data>;

    public:
	// constructor
	match_iterator(const ipaddr_type &a, Node *n = 0) : node(n), addr(a) {};
	match_iterator(Node *n = 0) : node(n), addr() {};

	// destructor
	virtual ~match_iterator() { node = (Node *)0; }

	virtual match_iterator & operator= (const match_iterator & src)
	{
	    node = src.node;
	    addr = src.addr;
	    return *this;
	}

	match_iterator & operator++ ()  // prefix ++
	{
	    if (!node) return *this;
	    while (1) {
		node = (IpPrefixPatricia::
		    bittest(addr, node->val.first.maskLen)) ?
		    node->right : node->left;
		if (!node || !node->Matches(addr))
		    break;
		if (node->has_data)
		    return *this;
	    }
	    node = 0;
	    return *this;
	}

	match_iterator & operator-- ()  // prefix --
	{
	    if (!node) {
		node = LongestMatchNode(addr);
		return *this;
	    } else {
		Node *p = node;
		while (p->parent) {
		    if (p->parent->has_data) {
			node = p;
			return *this;
		    }
		    p = p->parent;
		}
		node = 0;
		return *this;
	    }
	}

	void operator++ (int)  // postfix ++
	    { ++*this; }

	void operator-- (int)  // postfix --
	    { --*this; }

	virtual typename match_iterator::value_type & operator* ()
	    { return node->val; }

	virtual const typename match_iterator::value_type & operator* () const
	    { return node->val; }

	bool operator== (const match_iterator & rhs) const
	    { return this->node == rhs.node; }

	bool operator!= (const match_iterator & rhs) const
	    { return !(*this == rhs); }
    };

    typedef Const_Iterator<iterator> const_iterator;
    typedef Const_Iterator<reverse_iterator> const_reverse_iterator;
    typedef Const_Iterator<match_iterator> const_match_iterator;

    // constructor
    IpPrefixPatricia() : _size(), root() {};

    // destructor
    ~IpPrefixPatricia<Key, Data>() { clear(); }

    void clear() { if (root) { root->clear(); delete root; root = 0; } }
  
    // operator= to deep-copy an IpPrefixPatricia.
    IpPrefixPatricia & operator= (IpPrefixPatricia<Key, Data> & src)
    {
	root = new Node(src.root, NULL);
	_size = src._size;
    }

    inline iterator begin()
    {
	iterator it(root);
	return (!root || root->has_data) ? it : ++it;
    }

    inline iterator end() { return iterator(); }

    inline const_iterator begin() const
    {
	const_iterator it(root);
	return (!root || root->has_data) ? it : ++it;
    }

    inline const_iterator end() const { return const_iterator(); }

    inline reverse_iterator rbegin()
    {
	Node *node = root;
	if (node) {
	    while (node->right || node->left)
		node = node->right ? node->right : node->left;
	    assert(node->has_data);
	}
	return reverse_iterator(node);
    }

    inline reverse_iterator rend()
    {
	reverse_iterator it(NULL);
	return it;
    }

    iterator find(const key_type & key)
    {
	Node *node = root;

	while (node && node->Matches(key.net)) {
	    if (node->has_data && node->val.first.maskLen == key.maskLen)
		return iterator(node);
	    if (node->val.first.maskLen >= key.maskLen)
		break;
	    node = (bittest(key.net, node->val.first.maskLen)) ?
		node->right : node->left;
	}

	return iterator(NULL);
    }

    size_type count(const key_type & key) { return find(key) == end() ? 0 : 1; }

private:
    //------------------------------------------------------------------------
    //         inline Node *LongestMatchNode(const ipaddr_type & addr)
    //........................................................................
    // Find a prefix with the longest match for an IP address.
    //------------------------------------------------------------------------
    inline Node *LongestMatchNode(const ipaddr_type & addr, int len = nbits)
    {
        Node *node = root, *match = NULL;

        while (node && node->val.first.maskLen <= len && node->Matches(addr)) {
	    if (node->has_data)
		match = node;
	    if (node->val.first.maskLen == len)
		return match;
	    node = (bittest(addr, node->val.first.maskLen)) ?
		node->right : node->left;
        }

        return match;
    }

    //------------------------------------------------------------------------
    //         inline Node *ShortestMatchNode(const ipaddr_type & addr)
    //........................................................................
    // Returns the shortest matched prefix.
    //------------------------------------------------------------------------
    inline Node *ShortestMatchNode(const ipaddr_type & addr)
    {
        Node *node = root;

        while (node && node->Matches(addr)) {
	    if (node->has_data)
		return node;
	    node = (bittest(addr, node->val.first.maskLen)) ?
		node->right : node->left;
        }
        return node;
    }

public:
    inline iterator LongestMatch(const ipaddr_type & addr, int len = nbits)
    {
	return iterator(LongestMatchNode(addr, len));
    }


    inline match_iterator LongestMatchIt(const ipaddr_type & addr,
	int len = nbits)
    {
	return match_iterator(addr, LongestMatchNode(addr, len));
    }

    inline match_iterator ShortestMatchIt(const ipaddr_type & addr)
    {
	return match_iterator(addr, ShortestMatchNode(addr));
    }

    inline match_iterator endMatchIt() { return match_iterator(); }


    inline const_match_iterator LongestMatchIt(const ipaddr_type & addr,
	int len = nbits) const
    {
	return const_match_iterator(addr, LongestMatchNode(addr, len));
    }

    inline const_match_iterator ShortestMatchIt(const ipaddr_type & addr) const
    {
	return const_match_iterator(addr, ShortestMatchNode(addr));
    }

    inline const_match_iterator endMatchIt() const {
	return const_match_iterator();
    }


    bool empty() const { return root == 0; }

    const uint32_t size() const { return _size; }

    Data & operator[] (const key_type & key)
    {
        return (*((insert(value_type(key, data_type()))).first)).second;
    }

    // kept for backward compatability
    inline void visit(void (*visitFunc)(iterator &, void *), void *other)
    {
	for (iterator it = begin(); it != end(); it++)
	    visitFunc(it, other);
    }

    size_type erase(const key_type & key)
    {
	iterator it = find(key);

	if (it == end()) return 0;
	erase(it);
	return 1;
    }

    // does not invalidate iterators other than itself
    void erase(iterator it)
    {
	Node *node = it.node, *parent;
	Node **heir;

	assert(node->has_data);
	node->has_data = false;
	_size--;
	do {
	    if (node->has_data) {
		// This can't be true in the first iteration, but might be
		// as we go back up the tree collapsing parents.
		return;
	    }
	    if (node->left && node->right)
		return; // must keep node with 2 children
	    // Delete node with no data and <= 1 children.
	    // Parent inherits node's child, on the same side that node was on
	    parent = node->parent;
	    heir = !parent ? &root :
		(node == parent->left) ? &parent->left : &parent->right;
	    *heir = node->left ? node->left : node->right;
	    // Fix child's parent pointer.
	    if (*heir)
		(*heir)->parent = parent;
	    delete node;
	} while ((node = parent)); // climb tree, collapsing parent nodes
    }


    // TODO: optimize by using clear() on subtrees that are contained entirely
    // within [first, last), instead of iterating through them
    void erase(const iterator & first, const iterator & last)
    {
	// depends on erase(iterator) not invalidating other iterators
	iterator next, it;
	for (next = it = first; it != last; it = next) {
	    ++next;
	    erase(it);
	}
	return;
    }

    //------------------------------------------------------------------------
    // Returns true iff the kth bit of an IP address is set (k=0 is MSB).
    // Network byte order is handled because we treat the address as an
    // array of bytes.
    // TODO: optimized specialization for IPv4 on big endian hosts.
    //------------------------------------------------------------------------
    static bool bittest(const ipaddr_type &addr, size_t k) {
	return ((const uint8_t*)(&addr))[k/8] & (1 << ((nbits-1-k)%8));
    }

    std::pair<iterator,bool> insert(const value_type & value)
    {
	Node **nodep;
	Node *parent, *datanode, *newnode;

	// Search for the child pointer that we'd want to follow but can't
	// because there is no child there, the child's length is too long,
	// or the child's prefix doesn't match.
	parent = NULL;
	nodep = &root;
        while (*nodep && (*nodep)->val.first.maskLen < value.first.maskLen &&
	    (*nodep)->Matches(value.first.net))
	{
	    parent = *nodep;
	    nodep = bittest(value.first.net, (*nodep)->val.first.maskLen) ?
		&(*nodep)->right : &(*nodep)->left;
        }

	if (!*nodep) {
	    // The branch where value's key belongs does not exist
	    *nodep = new Node(value, parent);
	    _size++;
	    return make_pair(iterator(*nodep), true);
	}

        if (value.first.Matches((*nodep)->val.first.net)) {
	    if ((*nodep)->val.first.maskLen == value.first.maskLen) {
		// The correct node already exists at (*nodep)
		bool is_new = !((*nodep)->has_data);
		if (is_new) {
		    _size++;
		    (*nodep)->val.second = value.second;
		    (*nodep)->has_data = true;
		}
		return make_pair(iterator(*nodep), is_new);
	    } else {
		// value's key is a prefix of (*nodep)'s key; insert value
		// in new node above (*nodep).
		datanode = new Node(value, (*nodep)->parent);
		if (bittest((*nodep)->val.first.net, value.first.maskLen))
		    datanode->right = *nodep;
		else
		    datanode->left = *nodep;
		(*nodep)->parent = datanode;
		*nodep = datanode;
		_size++;
		return make_pair(iterator(datanode), true);
	    }
	}

	// Value and (*nodep) may share a prefix, but neither is a prefix of
	// the other.  Insert a new node corresponding to the shared prefix
	// and make value and (*nodep) the children of the new node.
	int i;
	for (i = (*nodep)->parent ? (*nodep)->parent->val.first.maskLen : 0;
	    i < (*nodep)->val.first.maskLen; i++)
	{
	    if (bittest((*nodep)->val.first.net, i) !=
		bittest(value.first.net, i))
	    {
		newnode = new Node(key_type(value.first.net, i),
		    (*nodep)->parent);
		(*nodep)->parent = newnode;
		datanode = new Node(value, newnode);
		if (bittest((*nodep)->val.first.net, i)) {
		    newnode->right = *nodep;
		    newnode->left = datanode;
		} else {
		    newnode->left = *nodep;
		    newnode->right = datanode;
		}
		*nodep = newnode;
		_size++;
		return make_pair(iterator(datanode), true);
	    }
	}

	assert(0);
	return make_pair(iterator(), false); // shouldn't happen
    }
};

class ipv4addr_t; // so ipv4addr.hh isn't required if it isn't used
class Ipv4Network; // so Ipv4Network.hh isn't required if it isn't used
template <class Data>
class Ipv4PrefixPatricia : public IpPrefixPatricia<Ipv4Network, Data>
    { public: typedef ipv4addr_t ipaddr_type; };

class ipv6addr_t; // so ipv6addr.hh isn't required if it isn't used
class Ipv6Network; // so Ipv6Network.hh isn't required if it isn't used
template <class Data>
class Ipv6PrefixPatricia : public IpPrefixPatricia<Ipv6Network, Data>
    { public: typedef ipv6addr_t ipaddr_type; };

#endif // IPPREFIXPATRICIA_HH
