#ifndef IPV4ADDR_HH
#define IPV4ADDR_HH

extern "C" {
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
}

class ipv4addr_t : public in_addr {
public:
    static const int family = AF_INET;
    ipv4addr_t(uint32_t a = 0) { s_addr = a; }
    ipv4addr_t(const in_addr &src) { s_addr = src.s_addr; }
    ipv4addr_t operator= (const in_addr &src)
	{ s_addr = src.s_addr; return *this; }

    uint32_t to_hl() const { return ntohl(s_addr); }
    uint32_t to_nl() const { return s_addr; }

    // not implemented in order to avoid accidents.
    //operator uint32_t() const { return s_addr; }

    bool operator < (const ipv4addr_t &b) const
	{ return ntohl(s_addr) < ntohl(b.s_addr); }

    bool operator == (const ipv4addr_t &b) const
	{ return s_addr == b.s_addr; }

#if 0 // untested, not needed (yet)
    ipv4addr_t operator + (const uint32_t &b)
	{ return ipv4addr_t(htonl(ntohl(s_addr) + b)); }
    ipv4addr_t operator - (const uint32_t &b)
	{ return ipv4addr_t(htonl(ntohl(s_addr) - b)); }
    ipv4addr_t operator ++ ();
    ipv4addr_t operator ++ (int bogus);
    ipv4addr_t operator -- ();
    ipv4addr_t operator -- (int bogus);
#endif

    ipv4addr_t operator & (const ipv4addr_t &b) const
	{ return ipv4addr_t(s_addr & b.s_addr); }
    ipv4addr_t operator | (const ipv4addr_t &b) const
	{ return ipv4addr_t(s_addr | b.s_addr); }
    ipv4addr_t operator ^ (const ipv4addr_t &b) const
	{ return ipv4addr_t(s_addr ^ b.s_addr); }

    ipv4addr_t & operator &= (const ipv4addr_t &b)
	{ s_addr &= b.s_addr; return *this; }
    ipv4addr_t & operator |= (const ipv4addr_t &b)
	{ s_addr |= b.s_addr; return *this; }
    ipv4addr_t & operator ^= (const ipv4addr_t &b)
	{ s_addr ^= b.s_addr; return *this; }

    friend std::ostream & operator << (std::ostream & os, const ipv4addr_t &a)
	{ return os << inet_ntoa(a); }
};

#endif // IPV4ADDR_HH
