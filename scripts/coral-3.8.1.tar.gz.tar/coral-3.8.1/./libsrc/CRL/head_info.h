/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/* $Id: head_info.h,v 1.17 2007/06/06 18:17:45 kkeys Exp $ */

#ifndef HEAD_INFO_H
#define HEAD_INFO_H

typedef struct data_info {
    void *data;
    size_t len;
} data_info;


#define UNPACK_TYPE_UNDEF	0
#define UNPACK_TYPE_INT8	1
#define UNPACK_TYPE_UINT8	2
#define UNPACK_TYPE_INT16	3
#define UNPACK_TYPE_UINT16	4
#define UNPACK_TYPE_INT32	5
#define UNPACK_TYPE_UINT32	6
#define UNPACK_TYPE_DBL		7
#define UNPACK_TYPE_STR		8
#define UNPACK_TYPE_DATA	9
#define UNPACK_TYPE_BOOL	10
#define UNPACK_TYPE_IN_ADDR	11

typedef struct head_info {
    u_char type;
    union {
        char INT8;
	u_char UINT8;
	short INT16;
	u_short UINT16;
	long INT32;
	u_long UINT32;
	double DBL;
	char * STR;
	data_info *DATA;
	u_long BOOL;		/* swig returns only 0 or 1 */
	struct in_addr IN_ADDR;	/* swig returns dotted ip addr string */
    } rep;
} head_info;

typedef struct ret_info {
    head_info *vals;
    int len;			/* number of vals present (valid) */
    int size;			/* actually allocated size of vals */
} ret_info;


#define UNPACK_STRUCT_unknown	0
#define UNPACK_STRUCT_ip	1
#define UNPACK_STRUCT_tcp	2
#define UNPACK_STRUCT_udp	3
#define UNPACK_STRUCT_llcsnap	4
#define UNPACK_STRUCT_igmp	5
#define UNPACK_STRUCT_bhead	6
#define UNPACK_STRUCT_atm	7
#define UNPACK_STRUCT_icmp	8

typedef struct options_info {
    int type;
    int *opts;			/* values for opts[x] in options.h */
    int len;
} options_info;

#endif
