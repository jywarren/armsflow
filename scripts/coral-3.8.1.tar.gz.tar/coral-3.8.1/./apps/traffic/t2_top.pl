#!/usr/local/bin/perl -w
## 
## Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
## All Rights Reserved 
## 
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
## 
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
## 
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
## 
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
## 
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program. Support for this effort is provided by the CAIDA grant
## NCR-9711092, and by CAIDA members.
## 
## Report bugs and suggestions to coral-bugs@caida.org.
## 

use strict;

use Getopt::Std;
use vars qw($opt_D $opt_S $opt_n $opt_h);
my ($show_meta, $byte_sort, $pkt_sort, $flow_sort);

my $coral_dir;
BEGIN { $coral_dir = "/usr/local/Coral"; } # This will be edited during build.
use lib "$coral_dir/lib"; #coral global libdir#
use lib "../../lib"; #coral local libdir#
use CAIDA::Traffic2::FileReader;
use CAIDA::Traffic2::FileWriter;

$| = 1;                 # don't buffer output

my ($pname) = $0 =~ m#([^/]+)$#;

if (!getopts('D:S:n:h') or @ARGV > 0) {
    print STDERR "Usage: crl_traffic2 {crl_traffic2_options} | ",
				"$pname {${pname}_options}\n",
	    "   Or: $pname {${pname}_options} < file.t2\n",
	    "$pname options:\n",
	    "-D[m] controls display options as follows:\n",
	    "        m shows metainformation about the input tables.\n",
	    "-S[bpf] controls sorting options as follows:\n",
	    "        b sorts by bytes.\n",
	    "        p sorts by packets.\n",
	    "        f sorts by flows.\n",
	    "   (with no sorting option, entries will be sorted by keys)\n",
	    "-n<topn> limits the number of displayed entries to topn.\n",
	    "   (defaults to showing all)\n",
	    "-h formats the output in a more human-readable form, attempting\n",
	    "   to line up the field columns.\n";
    exit 1;
}

if ($opt_S) {
    $byte_sort = ($opt_S =~ /b/);
    $pkt_sort = ($opt_S =~ /p/);
    $flow_sort = ($opt_S =~ /f/);
}
if ($opt_D) {
    $show_meta = ($opt_D =~ /m/);
}

my $reader = new CAIDA::Traffic2::FileReader(*STDIN);
die "Cannot understand input" if not defined $reader;
my $writer;
if ($show_meta) {
    $writer = new CAIDA::Traffic2::FileWriter(*STDOUT);
}

sub max ($$ ) {
    my ($a, $b) = @_;
    return !defined($a) ? $b : !defined($b) ? $a : $a > $b ? $a : $b;
}


sub dump_table ($$$$;$ ) {
    my ($table, $subif_id, $type, $sort_field, $direction) = @_;
    my $top_n = -1; # Show all for default
    if ($opt_n) {
	$top_n = $opt_n;
    }

    my $selector = "sort_by_${sort_field}";
    my @values;
    if (!defined($direction)) {
	@values = $table->$selector($top_n);
    } else {
	@values = $table->$selector($top_n, $direction);
    }

    my $top_txt = "";
    $top_txt = "top $top_n " if $top_n > 0;
    print "\n# begin $type for subif: $subif_id (", $table->num_entries, " entries)\n";
    if (!$opt_h) {		# !human-readable
	print "#KEYs\tpkts\tbytes\tflows\t(${top_txt}sorted by $sort_field)\n";
	foreach my $key (@values) {
	    my @fields = $table->get_key_fields($key);
	    foreach my $field (@fields) {
		print $field, "\t";
	    }
	    my $count = $table->data()->{$key};
	    printf("%.f\t%.f\t%.f\n",
		   $count->pkts(), $count->bytes(), $count->flows());
	}
	print "# end of text table\n\n";
    } else {
	# compute width of largest key output
	my @widths;
	my ($flows_width, $pkts_width, $bytes_width);
	foreach my $key (@values) {
	    my @fields = $table->get_key_fields($key);
	    
	    for (my $i = 0; $i < scalar(@fields); $i++) {
		$widths[$i] = max($widths[$i], length($fields[$i]));
	    }
	    
	    my $count = $table->data()->{$key};
	    $pkts_width = max($pkts_width, length($count->pkts()));
	    $bytes_width = max($bytes_width, length($count->bytes()));
	    $flows_width = max($flows_width, length($count->flows()));
	}
	
	my $keys_width = 0;
	foreach my $width (@widths) {
	    $keys_width += $width;
	    $keys_width++;		# space between columns
	}
	$keys_width--;			# extra space on end
	
	# make key widths at least as wide as `#KEYs'
	if ($keys_width < 5) {
	    $widths[$#widths] += (5 - $keys_width);
	    $keys_width = 5;
	}
	$pkts_width = max($pkts_width, 4);
	$bytes_width = max($bytes_width, 5);
	$flows_width = max($flows_width, 5);

	my $total_pkts = $table->total()->pkts();
	my $total_bytes = $table->total()->bytes();
	my $total_flows = $table->total()->flows();
    	
	printf("%-${keys_width}s %${pkts_width}s %${bytes_width}s %${flows_width}s %7s %7s %7s %s\n",
	       "#KEYs", "pkts", "bytes", "flows", "%pkts", "%bytes", "%flows", "(${top_txt}sorted by $sort_field)");
	foreach my $key (@values) {
	    my @fields = $table->get_key_fields($key);
	    for (my $i = 0; $i < scalar(@fields); $i++) {
		printf("%-" . $widths[$i] . "s ", $fields[$i]);
	    }
	    my $count = $table->data()->{$key};
	    printf("%${pkts_width}.f %${bytes_width}.f %${flows_width}.f %7.3f %7.3f %7.3f\n",
		   $count->pkts(), $count->bytes(), $count->flows(),
		   $count->pkts() / $total_pkts * 100,
		   $count->bytes() / $total_bytes * 100,
		   $count->flows() / $total_flows * 100);
	}
	print "\n";
    }
}

while (my $interval = $reader->get_next_interval()) {
    if ($show_meta) {
	$writer->initialize($interval);
	$writer->dump_interval_start();
    }
    foreach my $id_info ($interval->get_id_infos()) {
	foreach my $type ($id_info->get_table_types()) {
	    my $table = $interval->get_table($id_info, $type);
	    my $id = $id_info->get_metadata('id');
	    next unless $table;
	    if ($byte_sort) { dump_table($table, $id, $type, "bytes"); }
	    if ($pkt_sort) { dump_table($table, $id, $type, "pkts"); }
	    if ($flow_sort) { dump_table($table, $id, $type, "flows"); }
	    if (!$byte_sort && !$pkt_sort && !$flow_sort) {
		dump_table($table, $id, $type, "keys", 1);
	    }
	}
    }
    if ($show_meta) {
	$writer->dump_interval_end();
    }
}
