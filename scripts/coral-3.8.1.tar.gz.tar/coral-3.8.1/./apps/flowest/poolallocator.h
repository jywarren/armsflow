// A PoolAllocator object is used to allocate a large number of same-sized
// small objects with minimial wasted memory (compared to some library
// allocators which, for example, reserve 128 bytes for a 64 byte request).
// Freed memory is returned to the PoolAllocator's pool.  There is currently
// no way to return memory to the general pool.
//
// Standalone usage:
//   PoolAllocator allocator(sizeof(mytype));
//   mytype *p = allocator();
//   allocator.free(p);
//
// Usage as a class allocator:
//   class Foo {
//       static PoolAllocator allocator;
//       ...
//       void *operator new() { return allocator(); }
//       void operator delete() { allocator.free(); }
//   };
//   static PoolAllocator Foo::allocator(sizeof(Foo));

// TODO:
//   way to return memory to general pool (destructor?)
//   way to allocate contiguous array of objects
//   way to preallocate for predicted requirements

#ifndef ALLOCATOR_H
#define ALLOCATOR_H

#include <cstddef>
#include "alignmentof.h"

class PoolAllocator {
    size_t objsize;
    void *freelist;
    static const size_t overhead = 4; // depends on system library
    static const size_t default_block_size = 4096;
    bool is_large;
    size_t nallocated, ninuse, nfree;

    bool grow(int count = 1)
    {
	char *hunk;
        while (count > 0) {
	    int i;
	    size_t block_size = default_block_size;
	    while ((count * objsize) >= (2*block_size) - overhead)
		block_size *= 2;
	    const int num = (block_size - overhead) / objsize;
	    if (!(hunk = new char[objsize * num]))
		return false;
//	    for (i = 0; i < objsize * num / 4; i += 4)
//		*(uint32_t*)&hunk[i] = 0xdeadbeef;
	    for (i = 0; i < num-1; i++)
		*(void**)(hunk + (objsize * i)) = hunk + objsize * (i+1);
	    *(void**)(hunk + (objsize * i)) = freelist;
	    freelist = hunk;
	    count -= num;
	    nallocated += num;
	    nfree += num;
	    return true;
	}
	return false;
    }

public:
    class TooSmall {};

    PoolAllocator() : objsize(0), freelist(0), nallocated(0), ninuse(0), nfree(0) {}
    PoolAllocator(size_t size, size_t alignment = 4)
	: freelist(0), nallocated(0), ninuse(0), nfree(0)
    {
	if (alignment < alignmentof(void*))
	    alignment = alignmentof(void*); // needed for freelist pointers
	objsize = (size + alignment - 1) / alignment * alignment;
	if (objsize < sizeof(void*)) throw TooSmall();
	is_large = (objsize > (default_block_size - overhead) / 2);
    }

    void *operator() ()
    {
	void *result;
	if (is_large) {
	    result = (void*)(new char[objsize]);
	} else {
	    if (!freelist && !grow())
		return 0;
	    result = freelist;
	    freelist = *(void**)freelist;
	    nfree--;
	}
        ninuse++;
	return result;
    }

    void free(void *p)
    {
	if (is_large) {
	    delete[] static_cast<char *>(p);
	} else {
	    *(void**)p = freelist;
	    freelist = p;
	    nfree++;
	}
	ninuse--;
    }

    void stats() const
    {
#if 0
	cerr << "# size " << objsize <<
	    ", allocated " << nallocated <<
	    ", in use " << ninuse <<
	    ", free " << nfree <<
	    endl;
#endif
    }
};

#endif // ALLOCATOR_H
