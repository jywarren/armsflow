/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 * $Id: crl_rate.c,v 1.64 2007/06/06 18:17:37 kkeys Exp $
 *
 */


static const char RCSid[]="$Id: crl_rate.c,v 1.64 2007/06/06 18:17:37 kkeys Exp $";

#include "config.h"
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>
#include <sys/time.h>
#include <sys/errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <signal.h>
#include <errno.h>

#include <netinet/in.h>
#include <netinet/in_systm.h>
#include <netinet/ip.h>
#include <arpa/inet.h>

#include "libcoral.h"
#include "hashtab.h"

static int show_iface = 1;
static int show_subif = 1;
static int show_totals = 1;
static int show_ip4 = 0;
static int show_ip6 = 0;
static int no_repeat_i = 1;
static int no_repeat_t = 1;
static int short_output = 0;
static int if_count = 0;
static int dumped_once = 0;

static void quit(int arg) {
    fprintf(stderr, "got sig %d ", arg);

    switch(arg) {
    default:
	coral_pkt_done = 1;
	break;
    }
}

#define HASH_TABLE_SIZE 1021

typedef struct {
    coral_iface_t *iface;
    u_int iface_id;
    u_int subif_id;
    uint64_t non_ip;
    uint64_t ipv4pkts;
    uint64_t ipv4bytes;
    uint64_t ipv6pkts;
    uint64_t ipv6bytes;
} subif_stats;

static subif_stats * get_subif_entry(hash_tab *ht, coral_iface_t *iface, u_int subif_id)
{
    subif_stats * rec;
    subif_stats tmp;

    tmp.iface = iface;
    tmp.iface_id = coral_interface_get_number(iface);
    tmp.subif_id = subif_id;
    tmp.ipv4pkts = tmp.ipv4bytes = 0;
    tmp.ipv6pkts = tmp.ipv6bytes = 0;
    tmp.non_ip = 0;

    rec = (subif_stats *)find_hash_entry(ht, &tmp);
    if (rec == NULL) {
	rec = malloc(sizeof(subif_stats));

	if (rec == NULL) {
	    coral_puts("can't malloc subif_stats.\n");
	    coral_pkt_done = 1;
	    return NULL;
	}
	*rec = tmp;
	add_hash_entry(ht, rec);
    }
    return rec;
}

static void format_num(double num, char * buf) {
    if (num > 1000000) {
        sprintf(buf, "%6.2fM", num / 1000000);
    } else if (num > 1000) {
        sprintf(buf, "%6.2fk", num / 1000);
    } else {
        sprintf(buf, "%6.2f ", num);
    }
}

static const char *if_fmt = "%-9s";
static const char *short_hdr_start_fmt = "%-10s";
static const char *short_start_fmt = "%-10lu";
static const char *hdr_count_fmt = " %8s %10s";
static const char *data_count_fmt = " %8" PRIu64 " %10" PRIu64;
static const char *hdr_nonip_fmt = " %6s";
static const char *data_nonip_fmt = " %6" PRIu64;
static const char *rate_fmt = " %8s %8s";

static void dump_line_stats(const subif_stats *stats, double doub_diff)
{
    char buf1[64], buf2[64];

    if (show_ip4)
	fprintf(stdout, data_count_fmt, stats->ipv4pkts, stats->ipv4bytes);
    if (show_ip6)
	fprintf(stdout, data_count_fmt, stats->ipv6pkts, stats->ipv6bytes);
    fprintf(stdout, data_nonip_fmt, stats->non_ip);
    if (show_ip4) {
	format_num(stats->ipv4pkts/doub_diff, buf1);
	format_num(stats->ipv4bytes*8/doub_diff, buf2);
	fprintf(stdout, rate_fmt, buf1, buf2);
    }
    if (show_ip6) {
	format_num(stats->ipv6pkts/doub_diff, buf1);
	format_num(stats->ipv6bytes*8/doub_diff, buf2);
	fprintf(stdout, rate_fmt, buf1, buf2);
    }
    fputc('\n', stdout);
}

static void dump_subif_stats(hash_tab *ht, coral_interval_result_t *int_result)
{
    const subif_stats *rec;
    subif_stats total;
    subif_stats * iface_totals[CORAL_MAXOPEN];
    struct timeval diff;
    double doub_diff;
    int i;

    init_hash_walk(ht);

    timersub(&int_result->end, &int_result->begin, &diff);
    doub_diff = timevaltodouble(&diff);
    
    if (!short_output) {
	if (dumped_once) {
	    fputc('\n', stdout);
	}
	fprintf(stdout,
	    "# time %lu.%.6lu (%lu.%.6lus), packets lost: %" PRIu64 "\n",
	    int_result->begin.tv_sec, int_result->begin.tv_usec,
	    diff.tv_sec, diff.tv_usec,
	    int_result->stats->pkts_drop);
	fprintf(stdout, if_fmt, "# if[sub]");
	if (show_ip4)
	    fprintf(stdout, hdr_count_fmt, "v4pkts", "v4bytes");
	if (show_ip6)
	    fprintf(stdout, hdr_count_fmt, "v6pkts", "v6bytes");
	fprintf(stdout, hdr_nonip_fmt,
	    show_ip4 && show_ip6 ? "non-IP" : show_ip4 ? "nonIP4" : "nonIP6");
	if (show_ip4)
	    fprintf(stdout, rate_fmt, "v4pkts/s", "v4bits/s");
	if (show_ip6)
	    fprintf(stdout, rate_fmt, "v6pkts/s", "v6bits/s");
	fputc('\n', stdout);
    }

    bzero(iface_totals, sizeof(subif_stats*)*CORAL_MAXOPEN);

    total.ipv4pkts = total.ipv4bytes = 0;
    total.ipv6pkts = total.ipv6bytes = 0;
    total.non_ip = 0;
    while ((rec = next_hash_walk(ht))) {
	if (!iface_totals[rec->iface_id]) {
	    iface_totals[rec->iface_id] =
				(subif_stats*)calloc(1, sizeof(subif_stats));
	}
	iface_totals[rec->iface_id]->ipv4pkts += rec->ipv4pkts;
	iface_totals[rec->iface_id]->ipv4bytes += rec->ipv4bytes;
	iface_totals[rec->iface_id]->ipv6pkts += rec->ipv6pkts;
	iface_totals[rec->iface_id]->ipv6bytes += rec->ipv6bytes;
	iface_totals[rec->iface_id]->non_ip += rec->non_ip;
	total.ipv4pkts += rec->ipv4pkts;
	total.ipv4bytes += rec->ipv4bytes;
	total.ipv6pkts += rec->ipv6pkts;
	total.ipv6bytes += rec->ipv6bytes;
	total.non_ip += rec->non_ip;
    }
    if (short_output) {
	fprintf(stdout, short_start_fmt, int_result->begin.tv_sec);
	dump_line_stats(&total, doub_diff);

    } else {
	for (i = 0; i < CORAL_MAXOPEN; i++) {
	    if (iface_totals[i]) {
		char ifbuffer[100];
		int subif_count = 0;
		dumped_once = 1;

		if (show_subif) {
		    init_hash_walk(ht);
		    while ((rec = next_hash_walk(ht))) {
			if (rec->iface_id != i) { continue; }

			subif_count++;
			coral_fmt_if_subif(ifbuffer, rec->iface, rec->subif_id);
			fprintf(stdout, if_fmt, ifbuffer);
			dump_line_stats(rec, doub_diff);
		    }
		}
		if (show_iface && !(no_repeat_i && subif_count == 1)) {
		    sprintf(ifbuffer, "%-3d TOTAL", i);
		    fprintf(stdout, if_fmt, ifbuffer);
		    dump_line_stats(iface_totals[i], doub_diff);
		    if (show_subif && if_count > 1) {
			fputc('\n', stdout);
		    }
		}
	    }
	}
	if (show_totals && !(no_repeat_t && if_count == 1)) {
	    fprintf(stdout, if_fmt, "ALL TOTAL");
	    dump_line_stats(&total, doub_diff);
	}
    }
    fflush(stdout);

    clear_hash_table(ht);
    if (total_hash_entries())
	fprintf(stderr, "error clearing ht, #entries: %d\n",
		(int)total_hash_entries());
}

/* return 0 if the same - for use by the hashtable */
static int compare_subif_stats(const void *entry1, const void *entry2)
{
    const subif_stats *foo1 = entry1;
    const subif_stats *foo2 = entry2;

    return (foo1->subif_id != foo2->subif_id ||
            foo1->iface_id != foo2->iface_id);
}

/* make a hash of an entry - for use by the hashtable */
static unsigned long make_key_subif_stats(const void *entry)
{
    const subif_stats *what = entry;


    return (unsigned) what->subif_id * 425879 + what->iface_id;
}

/* free mem of an entry - for use by the hashtable */
static void delete_subif_stats(void *entry)
{
    subif_stats *what = entry;

    if (!what) return;

    free(what);
}

int main(int argc, char *argv[])
{
    hash_tab *subif_hash;
    int error = 0;
    char opt;

    coral_iface_t *iface;
    struct timeval interval = { 60, 0 };

    subif_stats * hash_rec;
    coral_pkt_buffer_t * linkpkt;
    coral_pkt_buffer_t netpkt;
    coral_pkt_result_t pkt_result;
    coral_interval_result_t interval_result;
    struct ip *ip;

    coral_set_api(CORAL_API_PKT);
    coral_set_interval(&interval);
    coral_set_duration(0);
    coral_set_iomode(0, CORAL_RX, 48, 0);

    while (!error && (opt = getopt(argc, argv, "C:D:s46")) != -1) {
	switch (opt) {
	case 'C':
	    if (coral_config_command(optarg) < 0)
		exit(-1);
	    break;
	case 'D':
	    show_subif = show_iface = show_totals = 0;
	    if (strchr(optarg, 's') || strchr(optarg, 'S')) { /* Equivalent */
		show_subif = 1;
	    }
	    if (strchr(optarg, 'i')) {
		show_iface = 1;
		no_repeat_i = 1;
	    }
	    if (strchr(optarg, 't')) {
		show_totals = 1;
		no_repeat_t = 1;
	    }
	    if (strchr(optarg, 'I')) {
		show_iface = 1;
		no_repeat_i = 0;
	    }
	    if (strchr(optarg, 'T')) {
		show_totals = 1;
		no_repeat_t = 0;
	    }
	    break;
	case '4':
	    show_ip4 = 1;
	    break;
	case '6':
	    show_ip6 = 1;
	    break;
	case 's':
	    short_output = 1;
	    break;
	default:
	    error++;
	    break;
	}
    }
    if (error) {
	coral_usage(argv[0], "[-s] [-4] [-6] [-D[sitSIT]] <source>...\n"
	    "-s will output information in 'short mode', with only\n"
	    "   a single line for each interval.\n"
	    "-4 show only IPv4 stats\n"
	    "-6 show only IPv6 stats\n"
	    "-D controls display options as follows:\n"
	    "\tS displays subinterface-level information.\n"
	    "\tI displays interface-level totals.\n"
	    "\tT displays totals for all interfaces.\n"
	    "\ts, i, and t are the same as S, I and T, except that\n"
	    "\t    redundant information is suppressed.\n"
	    "\t    (eg. if there's only one interface, only that total\n"
	    "\t     will be displayed)\n"
	    "The default is equivalent to -Dsit\n"
	   );
	exit(1);
    }

    if (!show_ip4 && !show_ip6)
	show_ip4 = show_ip6 = 1;

    while (optind < argc) {
	if (!coral_new_source(argv[optind]))
	    exit(1);
	optind++;
    }

    subif_hash = init_hash_table("# src dst pkt and byte counter",
				compare_subif_stats, make_key_subif_stats,
				delete_subif_stats, HASH_TABLE_SIZE);

    coral_set_options(0, CORAL_OPT_PARTIAL_PKT);

    if ((if_count = coral_open_all()) <= 0)
	exit(1);

    if (coral_start_all() < 0)
	exit(1);


    signal(SIGINT, quit);
    signal(SIGTERM, quit);

    if (coral_get_interval(&interval) >= 0)
	coral_diag(2, ("collection interval set to %ld.%06ld second(s)\n",
	    interval.tv_sec, interval.tv_usec));

    coral_read_pkt_init(NULL, NULL, &interval);
    if (short_output) {
	fprintf(stdout, short_hdr_start_fmt, "# start");
	if (show_ip4)
	    fprintf(stdout, hdr_count_fmt, "v4pkts", "v4bytes");
	if (show_ip6)
	    fprintf(stdout, hdr_count_fmt, "v6pkts", "v6bytes");
	fprintf(stdout, hdr_nonip_fmt,
	    show_ip4 && show_ip6 ? "non-IP" : show_ip4 ? "nonIP4" : "nonIP6");
	if (show_ip4)
	    fprintf(stdout, rate_fmt, "v4pkts/s", "v4bits/s");
	if (show_ip6)
	    fprintf(stdout, rate_fmt, "v6pkts/s", "v6bits/s");
	fputc('\n', stdout);
    }

    while ((iface = coral_read_pkt(&pkt_result, &interval_result))) {
	if (!pkt_result.packet && !interval_result.stats) {
	    /* beginning of interval */
	} else if (pkt_result.packet) {
	    /* got packet */
	    hash_rec = get_subif_entry(subif_hash, iface, pkt_result.subiface);
	    if (!hash_rec) continue;

	    linkpkt = pkt_result.packet;

	    if (coral_get_payload_by_layer(linkpkt, &netpkt, 3) < 0) {
		hash_rec->non_ip++;
#if 0
		if (coral_get_verbosity() && coral_get_verbosity() <= 3) {
		/* something useful here? */    
		}
#endif
		continue;
	    }

	    if (netpkt.protocol == CORAL_NETPROTO_IP && show_ip4) {
		hash_rec->ipv4pkts++;
		ip = (struct ip*)netpkt.buf;
		hash_rec->ipv4bytes += (uint16_t)ntohs(ip->ip_len);
	    } else if (netpkt.protocol == CORAL_NETPROTO_IPv6 && show_ip6) {
		hash_rec->ipv6pkts++;
		/* header length + payload length.
		 * We use the cast and offset so we don't need <netinet/ip6.h>.
		 */
		hash_rec->ipv6bytes += 40 + (uint16_t)ntohs(((uint16_t*)&netpkt.buf)[2]);
	    } else {
		hash_rec->non_ip++;
	    }
	} else if (!pkt_result.packet && interval_result.stats) {
	    /* end of interval */
	    dump_subif_stats(subif_hash, &interval_result);
	}
    }
    if (errno) exit(errno);

    coral_stop_all();

/*    dump_hashtab_stats(subif_hash); */
    return 0;
}
