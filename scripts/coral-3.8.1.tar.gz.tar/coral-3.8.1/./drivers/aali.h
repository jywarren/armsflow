/*
 * ATM AAL Interface (AALI) for Fore Systems' 200-series adapters.
 * 
 * Copyright (c) 1991 by Fore Systems, Inc.
 */
#ifndef aali_h
#define aali_h

/* note that actual payload FIFO between ESP and i960 can become
 * 2^11 (if only one FIFO is enabled) or 2^9 (if all 4 are enabled)
 * cells deep, but the software has truncated the range to save
 * memory, which is OK since we never saw it go past 5 or so
 */
#define MAX_PHY_FIFO_DEPTH   15

#define EXTRACT_NIBBLE_6(x)  (((x) & 0x0f000000) >> 24)
#define EXTRACT_NIBBLE_7(x)  (((x) & 0xf0000000) >> 28)
#define EXTRACT_BYTE_0(x)    ((x) & 0x000000ff)
#define EXTRACT_BYTE_1(x)    (((x) & 0x0000ff00) >> 8)
#define EXTRACT_BYTE_2(x)    (((x) & 0x00ff0000) >> 16)
#define EXTRACT_BYTE_3(x)    (((x) & 0xff000000) >> 24)
#define EXTRACT_SHORT_0(x)   ((x) & 0x0000ffff)
#define EXTRACT_SHORT_1(x)   (((x) & 0xffff0000) >> 16)

#define POSITION_0(x)        (x)
#define POSITION_1(x)        ((x) << 4)
#define POSITION_2(x)        ((x) << 8)
#define POSITION_3(x)        ((x) << 12)
#define POSITION_4(x)        ((x) << 16)
#define POSITION_5(x)        ((x) << 20)
#define POSITION_6(x)        ((x) << 24)
#define POSITION_7(x)        ((x) << 28)

typedef u_int Haddr;		/* host address/DMA address */

/*
 * Command opcodes.
 */
enum opcodes {
    op_initialize = 0x01,	/* init 200-series */
    op_activate_vcout = 0x03,	/* activate outgoing VCI */
    op_deactivate_vcout = 0x05,	/* deactivate outgoing VCI */
    op_request_stats = 0x06,	/* return AAL and buffer stats */
    op_oc3_set_reg = 0x07,	/* modify OC3 register */
    op_oc3_get_reg = 0x08,	/* return OC3 register value */
#ifdef PBI
    op_get_prom_data = 0x09,	/* return expansion rom info */
#endif /* PBI */
    op_clear_timestamp= 0x0A,	/* used to sync cards with host & each other */
    op_shutdown = 0x0B,		/* stop all writing to host memory */
    op_interrupt_sel = 0x80	/* interrupt select */
};
typedef volatile enum opcodes Opcode;

/*
 * Request statistics command block.
 */
struct request_stats {
    Opcode op;
    Haddr stats_buff;		/* DMA address of stats buffer */
};
typedef volatile struct request_stats Request_stats;

/*
 * OC3 SET/GET REG: used by the host to alter specific SUNI register values,
 * or return register contents to the host.
 * 
 * op structure:
 * 
 * 31     24 23    16 15      8 7       0
 * +--------+--------+---------+--------+
 * |  mask  | value  |   reg   | opcode |
 * +--------+--------+---------+--------+
 * 
 * 'opcode' is the OC3 register operation to be performed, either reading, or
 * writing.
 * 
 * 'reg' is the SUNI OC3 register to operate on.
 * 
 * 'mask' specifes which bits within 'value' should be interpreted when writing
 * to th SUNI reg.
 * 
 * 'value' specifies the logical value to place at each bit position of 'reg'
 * that 'mask' says should be interpreted.
 * 
 * SUNI write example: Set the two high order bits of SUNI reg 0x34 to 0, not
 * altering the low order 6 bits.
 * 
 * mask = 0xC0 (high order 2 bits set to 1) value = 0x00 (high order 2 bits set
 * to 0) reg = 0x34 opcode = op_oc3_set_reg
 * 
 * (i.e. Only consider the two high order bits of 'value' when writing to
 * register 0x34 leaving the other 6 bits alone, and the value of these two
 * bits are 0)
 * 
 * SUNI read example: Return the value from SUNI reg 0x34.
 * 
 * reg = 0x34 opcode = op_oc3_get_reg
 * 
 * The value of register 0x34 is returned to the host.
 * 
 */

struct oc3_reg_op {
    Opcode oc3_op;
    Haddr oc3_buff;		/* DMA address of stats buffer */
};
typedef volatile struct oc3_reg_op Oc3_reg_op_t;

#ifdef PBI
/*
 * Request Hardware Version Number command block.
 */

struct hardware_version {
    Opcode op;
    u_int HardwareVersion;
};
typedef volatile struct hardware_version hardware_version_op_t;

/*
 * Request Serial Number command block.
 */

struct serial_number {
    Opcode op;
    u_short SerialNumber;
};
typedef volatile struct serial_number serial_number_op_t;

/*
 * Request MAC Address bytes 0 - 3 command block.
 */

struct mac_address0_3 {
    Opcode op;
    u_int MacAddress0_3;
};
typedef volatile struct mac_address0_3 mac_address0_3_op_t;

/*
 * Request MAC Address bytes 4 - 5 command block.
 */

struct mac_address4_5 {
    Opcode op;
    u_short MacAddress4_5;
};
typedef volatile struct mac_address4_5 mac_address4_5_op_t;

#endif /* PBI */

union command {
    Opcode op;
    Request_stats stats_param;
    Oc3_reg_op_t oc3_reg_param;
#ifdef PBI
    hardware_version_op_t hardware_version_param;
    serial_number_op_t serial_number_param;
    mac_address0_3_op_t mac_address0_3_param;
    mac_address4_5_op_t mac_address4_5_param;
#endif
    int force_multiple4[4];	/* gcc960 does this */
};
typedef volatile union command Command;

#ifdef CARD_STATUS
/*
 * The following changes were made to place status words on the card rather
 * than in host memory.  This was done for the MCA200 in an RS6000 running
 * AIX due to the high overhead associated with maintaining data cache
 * coherency for the IOCC DMA cache and the CPU cache.
 *
 * The stataddr member has been eliminated from the Qcard queue entry.
 * The ioblock member of the queue entry serves the dual function of
 * initiating operations by passing the DMA address to the card from the
 * host and is also used to indicate the completion status.
 *
 *         ioblock member (pending state):
 *
 *        31                                         0
 *        +-------------------------------------------+
 *        |                ioblock addr               |
 *        ---------------------------------------------
 *
 *        ioblock member (non-pending state):
 *
 *        31                                 4 3 2 1 0
 *        +-----------------------------------+-------+
 *        |   <---------- Null ---------->    | status|
 *        ---------------------------------------------
 *
 * To initiate an operation, the host writes the ioblock member of the
 * CP resident queue entry with the DMA address of the host resident
 * I/O block.  This sets the state of the entry to pending (the"stat_pending"
 * definition is no longer used).
 *
 * The CP then notices that the ioblock member of the queue entry has
 * changed and starts the operation associated with that queue.  At
 * the end of the operation, the CP will write the ioblock member of
 * the queue entry with "stat_complete".
 */
struct command_block {
    u_int    status;
    int      force_multiple4[3]; /* gcc960 does this */
    Command  cmd;
};
typedef volatile struct command_block Qcard_cmd;

#else /* CARD_STATUS */

struct command_block {
    Command cmd;
    Haddr stataddr;
    int force_multiple4[3];	/* gcc960 does this */
};
typedef volatile struct command_block Qcard_cmd;

#endif /* CARD_STATUS */

/*
 * Queue entry state. Initialized by the host before an operation,
 * overwritten by the 200-series upon completion of an operation.
 */
enum status {
    StatPending = 0x01,
    StatComplete = 0x02,
    StatFree = 0x04,
    StatError = 0x08
};
typedef enum status Status;

#ifdef CARD_STATUS

#define STAT_ADDR_MASK 0xfffffff0

#ifdef aix
#define QSTATUS_SET(q, val) \
    ((Qcard *)((u_int)(q)->card_qentry + (u_int)fcp_ram))->ioblock = (val);
#define QSTATUS(q) \
    (((Qcard *)((u_int) (q)->card_qentry + (u_int)fcp_ram))->ioblock)
#else /* aix */
#define QSTATUS_SET(q, val) \
    SLAVE_XFER((((Qcard *) (q)->card_qentry)->ioblock), (val));
#define QSTATUS(q)              (((Qcard *)(q)->card_qentry)->ioblock)
#endif /* aix */

#define QSTATUS_FREE(q)         (QSTATUS(q) == StatFree)
#define QSTATUS_ERROR(q)        (QSTATUS(q) & StatError)
#define QSTATUS_COMPLETE(q)     ((QSTATUS(q) & (~StatError)) == StatComplete)
#define QSTATUS_PENDING(q)      (QSTATUS(q) & STAT_ADDR_MASK)

#define QSTATUS_VAR(x)          (x)
#define QSTATUS_FREE_VAR(x)     (QSTATUS_VAR(x) == StatFree)
#define QSTATUS_ERROR_VAR(x)    (QSTATUS_VAR(x) & StatError)
#define QSTATUS_COMPLETE_VAR(x) (((x) & (~StatError)) == StatComplete)
#define QSTATUS_PENDING_VAR(x)  (QSTATUS_VAR(x) & STAT_ADDR_MASK)

#else /* CARD_STATUS */

#ifdef SunOS5
#define QSTATUS_SET(q, val) \
		(*((q)->card_stataddr)) = (val);
#else /* SunOS5 */
#define QSTATUS_SET(q, val) \
		(*((q)->card_stataddr)) = (val); \
		QSTATUS_FLUSH(q);
#endif /* SunOS5 */

#ifdef	aix
#define QSTATUS(q) \
	(d_complete(au->dma_channel_id, DMA_NOHIDE, (q)->card_stataddr, \
		sizeof((q)->card_stataddr), &au->x_mem, (q)->stataddr_daddr) \
		== DMA_SUCC ? (*((q)->card_stataddr)) \
			: ((*((q)->card_stataddr)) | StatError))
#else /* aix */
#define QSTATUS(q)              (*((q)->card_stataddr))
#endif /* aix */
#define QSTATUS_FREE(q)         (QSTATUS(q) & StatFree)
#define QSTATUS_ERROR(q)        (QSTATUS(q) & StatError)
#define QSTATUS_COMPLETE(q)     (QSTATUS(q) & StatComplete)
#define QSTATUS_PENDING(q)      (QSTATUS(q) & StatPending)

#define QSTATUS_VAR(x)          (x)
#define QSTATUS_FREE_VAR(x)     (QSTATUS_VAR(x) & StatFree)
#define QSTATUS_ERROR_VAR(x)    (QSTATUS_VAR(x) & StatError)
#define QSTATUS_COMPLETE_VAR(x) (QSTATUS_VAR(x) & StatComplete)
#define QSTATUS_PENDING_VAR(x)  (QSTATUS_VAR(x) & StatPending)

#endif /* CARD_STATUS */

/*
 * For environments where the host can't clear the
 * interrupt status bit (istat).
 * 
 * Specifically, certain Sun machines can not access istat
 * due to the sbus rerun.
 *
 * ISTAT_NOT_CLEARED is used in the interrupt mask (imask)
 * field to specify that the host can't/won't clear the
 * istat, so go ahead and interrupt again even though it's
 * not cleared.
 *
 * ISTAT_ACCEPT_INT is used in the interrupt mask (imask)
 * field to specify that the firmware can interrupt the
 * host when appropriate.
 */

#define ISTAT_ACCEPT_INT	0x1
#define ISTAT_NOT_CLEARED	0x2

typedef unsigned int Vpvc;

struct init_block {
    Opcode op;
    Status status;		/* initialized and read directly by host */
    u_int index_bits_avail;	/* filled by card, altered by host, for VPI/VCI state lookup */
    u_int bits_from_vci;	/* starting at lsb, remainder come from VPI */
    Vpvc high_vpi_vci;		/* most sig bits (unused for indexing) must match this */
    u_int host_block_size;	/* measured in bytes */
    int cqueue_len;		/* command queue */
    int pad[1];			/* force quad alignment */
};
typedef volatile struct init_block Init_block;

/*
 * Shared read-only structure used by host to initialize host resident queue
 * pointers.
 * 
 * Each queue is write only. To initiate an operation the host writes a queue
 * entry with an address of the input/output block located in host memory.
 */
struct cp_queues {
    Qcard_cmd *command_queue;
    Haddr current_host_limit;	/* calculated by card from current_host_block and init.host_block_size, when copying to current_host_block */
    Haddr current_host_block;   /* written by host during init, card copies from next_host_block afterwards as needed */
    Haddr next_host_block;      /* written by host during init, afterwards when host sees end of block was written to */
    u_int imask;		/* non zero enables CP to host interrupts */
    u_int istat;		/* 1 for interrupt posted */
    u_int heap_base;		/* offset form beginning of ram */
    u_int heap_size;		/* space in bytes available for queues */
    u_int hlogger;		/* non zero for host logging */
    u_int heartbeat;
    u_int firmware_release;
    u_int mon960_release;
    u_int tq_plen;		/* transmit throughput measurements */

    /*
     * To be compatible with host compilers make sure the init block remains
     * on a quad word boundary. gcc960 does this.
     */
    int pad[3];

    Init_block init;		/* one time command, not in cmd queue */
    u_int media_type;		/* media type id */
    int oc3_revision;		/* OC3 revision number */

    u_int fifo_depth_counts[ MAX_PHY_FIFO_DEPTH + 1 ];
};
typedef volatile struct cp_queues Cp_queues;

#define MIN_BSIZE     64

#endif /* aali_h */
