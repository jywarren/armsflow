/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 * crl_fail.c - program to capture raw packet traces from a Coral device,
 *		but only those which fail checks for being IP.
 *
 * $Id: crl_fail.c,v 1.30 2007/06/06 18:17:36 kkeys Exp $
 *
 */

static const char RCSid[]="$Id: crl_fail.c,v 1.30 2007/06/06 18:17:36 kkeys Exp $";

#include "config.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <signal.h>
#include <ctype.h>
#include <time.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <errno.h>
#include <netinet/in.h>
#include <netinet/in_systm.h>
#include <netinet/ip.h>
#include <limits.h>

#include "libcoral.h"

#if !PATH_MAX
# define PATH_MAX 1024
#endif

int done = 0;

static void quit(int arg)
{
    done = 1;
}

static void usage(const char *name)
{
    coral_usage(name, "[-o <outfile>] <source>...");
    fputs(
"<outfile> is the name of the output file.  '%s' will be replaced with the\n"
"  number of seconds since 1970-01-01 00:00:00 Z.  The default value of\n"
"  <outfile> is '%s.crl'.\n",
    stderr);
    fputs("\nUsage example:\n", stderr);
    fprintf(stderr, "%s -C'duration 60' -C'comment <site_name>' "
	"/dev/point0\n\n", name);
}

int main(int argc, char *argv[])
{
    coral_writer_t *writer;
    struct timeval t1;
    coral_iface_t *iface;
    char buf[PATH_MAX+1], *t;
    const char *s, *outfile = "%s.crl";
    coral_atm_cell_t *cell;
    coral_pkt_buffer_t linkpkt, netpkt;
    long duration;
    int opt;


    signal(SIGINT, quit);

    coral_set_api(CORAL_API_CELL | CORAL_API_WRITE);
    coral_set_iomode(0, CORAL_RX, 1, 1);
    coral_set_duration(duration = 86400);	/* default to one day */

    while ((opt = getopt(argc, argv, "C:o:")) != -1) {
        switch (opt) {
        case 'C':
            if (coral_config_command(optarg) < 0) {
		usage(argv[0]);
                exit(-1);
	    }
            break;
        case 'o':
            outfile = strdup(optarg);
            break;
        default:
            usage(argv[0]);
            exit(-1);
        }
    }

    while (optind < argc) {
        if (!coral_new_source(argv[optind]))
            exit(-1);
        optind++;
    }

    if (coral_open_all() <= 0) {
	usage(argv[0]);
	exit(2);
    }

    duration = coral_get_duration();
    coral_diag(2, ("collection duration set max to %d second(s)\n", duration));

    if (coral_start_all() < 0)
	exit(3);

    gettimeofday(&t1, 0);

    s = outfile;
    t = buf;
    while (*s && t < buf + sizeof(buf) - 11) {
	if (*s == '%') {
	    switch (*++s) {
		case '\0':
		    break;
		case '%':
		    *t++ = *s++;
		    break;
		case 's':
		    t += sprintf(t, "%ld", t1.tv_sec);
		    s++;
		    break;
		default:
		    *t++ = '%';
		    *t++ = *s++;
		    break;
	    }
	} else {
	    *t++ = *s++;
	}
    }
    *t = '\0';

    writer = coral_write_open(buf);
    if (!writer) exit(4);
    coral_diag(1, ("opened output file: %s\n", buf));
    coral_write_set_encoding(writer, "none", 0);

    if (coral_write_init_all(writer) < 0)
	exit(5);

    while (!done) {
	iface = coral_read_cell_all(NULL, &cell, NULL);
	if (!iface) {
	    if (!errno) done = 3;
	    break;
	}

	if (coral_cell_to_pkt(iface, cell, &linkpkt) &&
	    coral_get_payload_by_proto(&linkpkt, &netpkt, CORAL_NETPROTO_IP) == 0 &&
	    ((struct ip*)netpkt.buf)->ip_v == 4 &&
	    ((struct ip*)netpkt.buf)->ip_hl >= 5)
	{
	    continue;
	}

	if (coral_write_cells(writer, iface, cell, 1) < 0)
	    exit(6);
    }

    coral_stop_all();
    coral_stats_all();

    fprintf(stderr, "closing output file\n");
    coral_write_close(writer);

    coral_close_all();

    if (done == 1) {
	fprintf(stderr, "terminated by signal\n");
    } else if (!done) {
	fprintf(stderr, "terminated by error\n");
    }
    coral_diag(2, (".... done ....\n"));

    return(0);
}
