/* 
 * Copyright 2003, 2004, 2005, 2007
 * The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program.  Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

#ifndef XTRBMP_H
#define XTRBMP_H

#include <string>
#include <cmath>
#include <math.h>
#include <memory>
#include "poolallocator.h"
#include "alignmentof.h"
#include "intmath.h"

// List-Triggered Bitmap
// Keeps a list of up to g hashvals.  When g is exceeded, a MultiResBitmap
// is allocated.  This is much more accurate than the original TriggeredBitmap
// as there's no sampling factor, yet has similar memory and cpu requirements;
// also, the choice of g is not as critical or difficult.
// c, b, k are as in MultiResBmp::Param.

template<class tag, class Key> class ListTrigBmp {
    typedef ListTrigBmp<tag, Key> Self_t;
    class subtag {};
    typedef MultiResBmp<subtag, Key> MRB_t;

    const static uint32_t magic = 0xa10ca7ed; // indicates our new was called

    MRB_t *mrbmp;
    unsigned entries;	// current number of entries in keys[]
    Key keys[];		// variable size - must be last member

    void checkmagic()
    {
#ifndef NDEBUG
	if (*reinterpret_cast<uint32_t*>(&this->keys) != magic)
	    throw Unalloced();
#endif
    }

public:
    struct Unalloced : public std::exception {
	const char *what() const throw()
	    { return "ListTrigBmp objects can only be allocated with 'new'."; }
    };

    friend class Param;
    class Param {
	friend class ListTrigBmp;
	unsigned g;
	mutable PoolAllocator alloc;

	void init() {
	    alloc = PoolAllocator(bytes(), alignmentof(ListTrigBmp));
	}

    public:
	Param(unsigned pd, unsigned pg, unsigned pc, unsigned pb)
	{
	    g = pg;
	    MRB_t::p = new typename MRB_t::Param(0, 0, pc, pb);
	    init();
	}

	// Default value of g required, otherwise segmentation fault ensues
	Param(uint64_t N, double E, unsigned pg = 4)
	{
	    g = pg;
	    MRB_t::p = new typename MRB_t::Param(N, E);
	    init();
	}

	std::string namestr() const { return "ListTrigBmp::Param"; }
	std::string paramstr() const
	{
	    char buf[64]; // XXX Someday, stringstream is the way to go here
	    std::string ret_val;
	    sprintf(buf, "g=%u, ", g);
	    ret_val += buf;
	    ret_val += MRB_t::p->paramstr();
	    return ret_val;
	}

	size_t varbytes() const
	    { return g * sizeof(Key); } /* size of variable part */
	size_t bytes() const
	    { return sizeof(Self_t) + varbytes(); } /* total size */
	void stats() const { alloc.stats(); MRB_t::p->stats(); }
    };

    static const Param *p;

    void setmagic() {
#ifndef NDEBUG
	*reinterpret_cast<uint32_t*>(&this->keys) = magic;
#endif
    }

    void *operator new(size_t size)
    {
	void *ptr = p->alloc();
	(static_cast<ListTrigBmp*>(ptr))->setmagic();
	return ptr;
    }

    ListTrigBmp() : mrbmp(0), entries(0) { checkmagic(); reset(); }
    ~ListTrigBmp() { if (mrbmp) delete mrbmp; }
    void operator delete(void *ptr, size_t size) { p->alloc.free(ptr); }
    inline void set(Key key);
    double estimate() const {
	if (!mrbmp) return entries;
	double est = mrbmp->estimate();
	if (est < p->g + 1)
	    return p->g + 1; // must have been at least this to create mrbmp
	return est;
    }
    void reset()
    {
	if (mrbmp) delete mrbmp;
	mrbmp = 0;
	entries = 0;
    }
    bool have_mrbmp() const { return mrbmp != 0; }
};

template<class tag, class Key> const typename ListTrigBmp<tag, Key>::Param *ListTrigBmp<tag, Key>::p = 0;

template<class tag, class Key> inline void ListTrigBmp<tag, Key>::set(Key key)
{
    if (mrbmp) {
	mrbmp->set(key);
    } else {
	// we're more likely to match the most recent entry, so search backwards
	for (unsigned i = entries; i > 0; )
	    if (keys[--i] == key) return;   // already in exact array
	if (entries < p->g) {		// fits in exact array
	    keys[entries++] = key;	// insert in exact array
	} else {
	    mrbmp = new typename Self_t::MRB_t(); // create and initialize
	    for (unsigned i = 0; i < p->g; i++)
		mrbmp->set(keys[i]);
	    mrbmp->set(key);
	}
    }
}

#endif // XTRBMP_H
