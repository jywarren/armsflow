## 
## Copyright 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
## All Rights Reserved 
## 
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
## 
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
## 
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
## 
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
## 
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program. Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
## 
## Report bugs and suggestions to coral-bugs@caida.org.
## 

package CAIDA::Tables::make_Country_Table;
require Exporter;
@ISA = qw(Exporter);
@EXPORT = qw(&make_Country_Table &make_src_Country_Table
		&make_dst_Country_Table);

# Define required CVS variables
$cvs_Id = '$Id: make_Country_Table.pm,v 1.19 2007/06/06 18:17:48 kkeys Exp $';
$cvs_Author = '$Author: kkeys $';
$cvs_Name = '$Name: release-3-8-1 $';
$cvs_Revision = '$Revision: 1.19 $';


use Carp;
use CAIDA::Tables::get_Country;
use strict;

sub make_src_Country_Table {
    return make_Country_Table(shift, shift, 'src');
}

sub make_dst_Country_Table {
    return make_Country_Table(shift, shift, 'dst');
}

sub make_Country_Table {
    my ($self, $args, $src_dst) = @_;
    my $netacq = $args->{'netacq'};
    my $countries = $args->{'countries'};
    my $netgeo = $args->{'netgeo'};
    my $as_finder = $args->{'as_finder'};
    my $abbr_len = $args->{'country_abbr'};
    $abbr_len = 2 unless defined $abbr_len;
    my ($has_ip, $uses_ip, $uses_as, $uses_country, $from_matrix);
    $uses_as = 1 if ref($self) =~ /AS_/;
    if (ref($self) =~ /Tuple_Table/ or ref($self) =~ /IP_/) {
	$has_ip = 1;
	if ($netacq) {
	    $uses_ip = 1;
	} else {
	    $uses_as = 1;
	}
    }

    require CAIDA::Tables::Country_Table;
    my $country_table;

    # XXX Using String_Matrix is a hack due to SWIG and aliasing.
    if (ref($self) =~ /Country_Matrix/ or ref($self) =~ /String_Matrix/) {
	$country_table = new CAIDA::Tables::Country_Table();
	my $country;
	while (my ($opaque_key, $counts) = each %{ $self->data() }) {
	    if ($src_dst eq 'src') {
		($country, undef) = $self->get_key_fields($opaque_key);
	    } elsif ($src_dst eq 'dst') {
		(undef, $country) = $self->get_key_fields($opaque_key);
	    }
	    $country_table->entry_add($country, $counts);
	}
	return $country_table;
    }

    $from_matrix = 1 if ref($self) =~ /Tuple_Table/ or ref($self) =~ /Matrix/;
    if ($uses_as and $has_ip and not $as_finder) {
	die "Need an ASFinder object to do country lookups.";
    } elsif ($uses_as and not $netgeo) {
	die "Need a NetGeoClient object to do country lookups.";
    }
    if ($from_matrix and not defined $src_dst) {
	die "make_Country_Table() is not supported by this class.\n" .
		"Please use make_{src|dst}_Country_Table().";
    }

    my $desired_table;
    if ($uses_ip) {
	$desired_table = 'IP_Table';
    } elsif ($uses_as) {
	$desired_table = 'AS_Table';
    }

    # Convert intermediate table.
    my $temp_table;
    if ($from_matrix) {
	eval "\$temp_table = \$self->make_${src_dst}_$desired_table(\$args);";
	die "Can't create $desired_table: $@" if $@;
    } elsif (ref($self) =~ /$desired_table/) {
	$temp_table = $self;
    } else {
	eval "\$temp_table = \$self->make_$desired_table(\$args);";
	die "Can't create $desired_table: $@" if $@;
    }

    $country_table = new CAIDA::Tables::Country_Table();
    # Loop over table elements, collecting keys
    my @keys;
    foreach my $opaque_key (keys %{ $temp_table->data() }) {
	my ($key) = $temp_table->get_key_fields($opaque_key);
	push @keys, $key;
    }

    my $key_to_loc_ref;
    # Do table key -> country conversion
    if ($uses_ip) {
	$key_to_loc_ref = _get_locs_byIP($netacq, $countries, $abbr_len, @keys);
    } elsif ($uses_as) {
	$key_to_loc_ref = _get_locs_byAS($netgeo, $countries, $abbr_len, @keys);
    } # Country case should already been taken care of.

    # Loop over table elements, making Country Table
    while (my ($opaque_key, $counts) = each %{ $temp_table->data() }) {
	my ($key) = $temp_table->get_key_fields($opaque_key);
	my $loc_ref = $key_to_loc_ref->{$key};
	my $country = 'UNKNOWN';
	($country) = @$loc_ref if defined $loc_ref;
	$country_table->entry_add($country, $counts);
    }
    $country_table->total->add($self->other);
    $country_table->other->add($self->other);
    return $country_table;
}

1;
