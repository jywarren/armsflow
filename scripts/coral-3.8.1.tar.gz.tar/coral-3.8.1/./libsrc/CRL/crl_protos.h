# 1 "protocols.h"
# 1 "/home/kkeys/coral/coral-3.8.1/libsrc/CRL//"
# 1 "<built-in>"
# 1 "<command line>"
# 1 "protocols.h"



# 1 "../../libsrc/libcoral/coral_proto.h" 1
# 52 "../../libsrc/libcoral/coral_proto.h"
%constant PROTO_UNKNOWN = (0 << 28 | 0);



%constant PHY_ATM = (1 << 28 | 1001);
%constant PHY_POS = (1 << 28 | 1008);




%constant DLT_NULL = (2 << 28 | 0);
%constant DLT_ETHER = (2 << 28 | 1);
%constant DLT_EN10MB = (2 << 28 | 1);
%constant DLT_IEEE802 = (2 << 28 | 6);
%constant DLT_ATM = (2 << 28 | 1001);
%constant DLT_ATM_AAL5 = (2 << 28 | 1002);
%constant DLT_ILMI = (2 << 28 | 1030);
%constant DLT_ATM_RFC1483 = (2 << 28 | 11);
%constant DLT_LANE_IEEE8023 = (2 << 28 | 1003);
%constant DLT_LANE_IEEE8025 = (2 << 28 | 1004);
%constant DLT_LANE_LLC = (2 << 28 | 1005);
%constant DLT_GIGX = (2 << 28 | 1007);
%constant DLT_POS = (2 << 28 | 1008);
%constant DLT_CHDLC = (2 << 28 | 1009);
%constant DLT_PPP = (2 << 28 | 1010);
%constant DLT_PPPoHDLC = (2 << 28 | 1011);
%constant DLT_PPPoES = (2 << 28 | 1012);
%constant DLT_PPPoED = (2 << 28 | 1013);
%constant DLT_PPPoFR = (2 << 28 | 1014);
%constant DLT_BRIDGED_LAN = (2 << 28 | 1020);
%constant DLT_IEEE8021D = (2 << 28 | 1021);

%constant DLT_FDDI = (2 << 28 | 1022);

%constant DLT_UoPOS = (2 << 28 | 1023);
%constant DLT_MPoFR = (2 << 28 | 1024);
%constant DLT_MPLS = (2 << 28 | 0x8847);



%constant NETPROTO_IPv4 = (3 << 28 | 0x0800);
%constant NETPROTO_IP = (3 << 28 | 0x0800);
%constant NETPROTO_ARP = (3 << 28 | 0x0806);
%constant NETPROTO_IPX = (3 << 28 | 0x8037);
%constant NETPROTO_APPLETALK = (3 << 28 | 0x809B);
%constant NETPROTO_AARP = (3 << 28 | 0x80F3);
%constant NETPROTO_IPX_E = (3 << 28 | 0x8137);
%constant NETPROTO_IPv6 = (3 << 28 | 0x86DD);

%constant NETPROTO_RAW_IP = (3 << 28 | 0x10000);
%constant PROTO_ILMI_PDU = (3 << 28 | 0x10406);



%constant IPPROTO_HOPOPTS = (4 << 28 | 0);
%constant IPPROTO_ICMP = (4 << 28 | 1);
%constant IPPROTO_ICMP4 = (4 << 28 | 1);
%constant IPPROTO_IGMP = (4 << 28 | 2);
%constant IPPROTO_TCP = (4 << 28 | 6);
%constant IPPROTO_UDP = (4 << 28 | 17);
%constant IPPROTO_ROUTING = (4 << 28 | 43);
%constant IPPROTO_FRAGMENT = (4 << 28 | 44);
%constant IPPROTO_RSVP = (4 << 28 | 46);
%constant IPPROTO_GRE = (4 << 28 | 47);
%constant IPPROTO_ESP = (4 << 28 | 50);
%constant IPPROTO_AH = (4 << 28 | 51);
%constant IPPROTO_ICMP6 = (4 << 28 | 58);
%constant IPPROTO_DSTOPTS = (4 << 28 | 60);


%constant PROTO_DNS = (5 << 28 | 53);
%constant PROTO_SNMP = (5 << 28 | 161);
%constant PROTO_SNMP_PDU = (6 << 28 | 161);
# 5 "protocols.h" 2
