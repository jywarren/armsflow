//===========================================================================
//  $Name: release-3-8-1 $
//  $Id: Ipv6Network.hh,v 1.5 2004/06/24 19:09:08 kkeys Exp $
//===========================================================================

#ifndef _IPV6NETWORK_HH_
#define _IPV6NETWORK_HH_

extern "C" {
#include "caida_t.h"
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
}

#include <iostream>
#include "ipv6addr.hh"

//----------------------------------------------------------------------------
//                            class Ipv6Network                            
//----------------------------------------------------------------------------
//!  This class encapsulates an IPv6 network address.  It's really
//!  nothing more than a struct (not the data members are public) with
//!  some constructors and overloaded operators, plus a Matches() member
//!  for testing whether or not a host IP address in inside the
//!  Ipv6Network (where 'inside' means the network portion of the host IP
//!  address matches the Ipv6Network).
//----------------------------------------------------------------------------
class Ipv6Network 
{
public:
    typedef ipv6addr_t ipaddr_type;
    static const int family = ipaddr_type::family;
    ipv6addr_t net;
    uint8_t maskLen;

    // constructor
    Ipv6Network() : maskLen(128)
    {
	memset(&net, 0, sizeof(net));
    }

    // Constructor that accepts netaork address and masklength as parameters.
    // 'network' must be in network byte order.  network will be masked
    // according to masklength.
    Ipv6Network(const struct in6_addr &network, uint8_t masklength)
	: net(network), maskLen(masklength)
    {
	if (masklength % 8)
	    ((uint8_t*)&net)[masklength/8] &= (0xFF << (8-masklength%8));
	for (size_t i = (masklength+7)/8; i < sizeof(net); i++)
	    ((uint8_t*)&net)[i] = 0;
    }

    bool operator == (const Ipv6Network & rhs) const
    {
	for (size_t i = 0; i < sizeof(net); i++)
	    if (((uint8_t*)&net)[i] != ((uint8_t*)&rhs.net)[i])
		return false;
	return maskLen == rhs.maskLen;
    }

    // Compare the network addresses; if they're equal, compare the masklengths.
    // This permits semi-standard ordering of objects by network address.
    bool operator < (const Ipv6Network & rhs) const
    {
	for (size_t i = 0; i < sizeof(net); i++)
	    if (((uint8_t*)&net)[i] != ((uint8_t*)&rhs.net)[i])
		return ((uint8_t*)&net)[i] < ((uint8_t*)&rhs.net)[i];
	return maskLen < rhs.maskLen;
    }

    // Return true iff the IPv6 address falls within the Ipv6Network.
    bool Matches(const struct in6_addr &addr) const
    {
	int i;
	for (i = 0; i < maskLen/8; i++)
	    if (((uint8_t*)&addr)[i] != ((uint8_t*)&net)[i])
		return false;
	if (maskLen % 8)
	    if ((((uint8_t*)&addr)[i] & (0xFF << 8 - (maskLen % 8))) !=
		((uint8_t*)&net)[i])
		    return false;
	return true;
    }

    friend std::ostream & operator << (std::ostream & os,
	const Ipv6Network & ipv6net)
    {
	return os << ipv6net.net << "/" << (int)ipv6net.maskLen;
    }

#if 0
    std::istream & read(std::istream & is) {}
    int read(int fd) {}
    std::ostream & write(std::ostream & os) const {}
    int write(int fd) const {}

    // Returns the number of bytes required to store the Ipv6Network on disk.
    uint32_t Length() const {}
#endif

};


#endif  // _IPV6NETWORK_HH_
