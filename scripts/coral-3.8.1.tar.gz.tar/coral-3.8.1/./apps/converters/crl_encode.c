/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */


static const char RCSid[]="$Id: crl_encode.c,v 1.43 2007/06/06 18:17:27 kkeys Exp $";

#include "config.h"
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <sys/time.h>
#include <sys/errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <signal.h>
#include <errno.h>
#include <netinet/in.h>
#include <netinet/in_systm.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <netinet/ip_icmp.h>
#include <netinet/igmp.h>

#include "libcoral.h"
#include "hashtab.h"

#define HASH_TABLE_SIZE 500009
#define ICMP_SIZE 8
#define UDP_SIZE 8
#define TCP_SIZE 20
#define TIMESTAMP_SIZE 8

#ifndef IPPROTO_IPIP
#define IPPROTO_IPIP 4
#endif

int net_count = 0;
hash_tab *host_count;
hash_tab *host_map;
hash_tab *net_map;

struct addr_entry {
    long key;
    long value;
};

/* Take the actual network address and return the encoded network address. */
static long enc_net(long net) {
    struct addr_entry * net_entry;
    struct addr_entry * net_data;

    net_entry = (struct addr_entry *)malloc(sizeof(struct addr_entry));
    net_entry->key = net;
    net_data = (struct addr_entry *)find_hash_entry(net_map, net_entry);
    if (net_data == NULL) { /* This is a new network */
	net_entry->value = ++net_count;
	add_hash_entry(net_map, net_entry);
	net_data = net_entry;
    } else {
	free(net_entry); /* Wasn't added. */
    }

    return net_data->value;
}

/* Take the actual (full) host address and return the encoded (subnet) address. */
static long enc_host(long net, long host) {
    struct addr_entry * net_count_entry;
    struct addr_entry * net_count_data;
    struct addr_entry * host_entry;
    struct addr_entry * host_data;

    host_entry = (struct addr_entry *)malloc(sizeof(struct addr_entry));
    host_entry->key = host;
    host_data = (struct addr_entry *)find_hash_entry(host_map, host_entry);
    if (host_data == NULL) { /* A new host */
	net_count_entry = (struct addr_entry *)malloc(sizeof(struct addr_entry));
	net_count_entry->key = net;
	net_count_data = (struct addr_entry *)find_hash_entry(host_count,
							net_count_entry);
	if (net_count_data == NULL) { /* This is a new network */
	    net_count_entry->value = 0;
	    add_hash_entry(host_count, net_count_entry);
	    net_count_data = net_count_entry;
	} else {
	    free(net_count_entry); /* Wasn't added. */
	}
	host_entry->value = ++(net_count_data->value);
	add_hash_entry(host_map, host_entry);
	host_data = host_entry;
    } else {
	free(host_entry); /* Wasn't added */
    }

    return host_data->value;
}

/* XXX should preserve class space and "special" nets like 10, etc */
static struct in_addr encode_addr(struct in_addr non_encoded) {
    long addr;
    long net;
    long new_net, new_host;
    struct in_addr ret_val;
    
    addr = ntohl(non_encoded.s_addr);
    if (IN_CLASSA(addr)) {
	net = addr &  IN_CLASSA_NET;
    } else if (IN_CLASSB(addr)) {
	net = addr &  IN_CLASSB_NET;
    } else if (IN_CLASSC(addr)) {
	net = addr &  IN_CLASSC_NET;
    } else {
	/* class D & E - don't encode these */
	return non_encoded;
    }

    new_net = enc_net(net);
    new_host = enc_host(net, addr);

    ret_val.s_addr = htonl(new_net << 16 | new_host);
    return ret_val;
}

/* return 0 if the same - for use by the hashtable */
static int compare_addr_entry(const void *entry1, const void *entry2)
{
    const struct addr_entry *foo1 = entry1;
    const struct addr_entry *foo2 = entry2;
    return (foo1->key != foo2->key);
}

/* make a hash of an entry - for use by the hashtable */
static unsigned long make_key_addr_entry(const void *entry)
{
    const struct addr_entry *what = entry;
    return (unsigned long) what->key;
}

/* free mem of an entry - for use by the hashtable */
static void delete_addr_entry(void *entry)
{
    struct addr_entry *what = entry;
    if (!what) return;
    free(what);
}

static void clean_payload(char * data, int start, int save_aal5)
{
    int len = ATM_PAYLOAD_SIZE - start;

    /* XXX this isn't correct.  We should only save the trailer
       if this was a final cell.  Maybe this whole program should be
       rewritten to not be ATM specific. */
    if (save_aal5) {
	len -= sizeof(aal5_trailer_t);
    }
    if (len > 0)
	memset(data + start, 0, len);
}

static void sanitize_ip(char * payload, int offset, int save_aal5)
{
    struct ip * ip_h;
    int ihl;
    int ip_prot;

    if (offset >= ATM_PAYLOAD_SIZE) {
	return;
    }

    ip_h = (struct ip*)(payload + offset);
    ip_h->ip_src = encode_addr(ip_h->ip_src);
    ip_h->ip_dst = encode_addr(ip_h->ip_dst);
    ihl = ip_h->ip_hl*4;

    if (ihl < 20) { /* Most likely a bad header */
	/* Destroy even this header. */
	clean_payload(payload, offset, save_aal5);
	return;
    }

    ip_prot = ip_h->ip_p;

    if (ip_prot == IPPROTO_TCP) {
	clean_payload(payload, offset+ihl+TCP_SIZE, save_aal5);
    } else if (ip_prot == IPPROTO_UDP) {
	clean_payload(payload, offset+ihl+UDP_SIZE, save_aal5);
    } else if (ip_prot == IPPROTO_ICMP) {
	clean_payload(payload, offset+ihl+ICMP_SIZE, save_aal5);
    } else if (ip_prot == IPPROTO_IPIP) {
	sanitize_ip(payload, offset+ihl, save_aal5);
    } else {
	clean_payload(payload, offset+ihl, save_aal5);
    }
}

int main(int argc, char ** argv) {

    coral_atm_cell_t *blk;
    coral_iface_t *iface;
    coral_writer_t *writer;
    u_int cells_in_blk;
    const char * argsyn = "-o<outfile> <source>...";
    char * outfile = NULL;
    int i;
    int opt;
    extern char *optarg;
    extern int optind;
    coral_blk_info_t *binfo;
    coral_atm_cell_t *cell;
    coral_pkt_buffer_t linkpkt, netpkt;
    union atm_hdr header;
    int source_count = 0;
    int save_aal5 = 0;

    coral_set_api(CORAL_API_BLOCK | CORAL_API_WRITE);
    coral_set_duration(0);

    while ((opt = getopt(argc, argv, "C:o:")) != -1) {
        switch (opt) {
        case 'C':     
            if (coral_config_command(optarg) < 0)
                exit(1);
            break;
        case 'o':
	    outfile = strdup(optarg);
            break;    
        default:
            coral_usage(argv[0], argsyn);
            exit(1); 
        }             
    }           
    
    while (optind < argc) {
        if (!coral_new_source(argv[optind]))
            exit(1); 
        optind++;
        source_count++;
    }

    if (!outfile || !source_count) {
	coral_usage(argv[0], argsyn);
	exit(1); 
    }

    host_count = init_hash_table("host_count", compare_addr_entry,
		    make_key_addr_entry, delete_addr_entry, HASH_TABLE_SIZE);
    net_map = init_hash_table("net_map", compare_addr_entry,
		    make_key_addr_entry, delete_addr_entry, HASH_TABLE_SIZE);
    host_map = init_hash_table("host_map", compare_addr_entry,
		    make_key_addr_entry, delete_addr_entry, HASH_TABLE_SIZE);

    /* Don't compensate for time bugs. */
    coral_set_options(0, CORAL_OPT_RAW_TIME);

    if (coral_open_all() <= 0)
	exit(1);

    if (coral_start_all() < 0)
	exit(1);

    if (!(writer = coral_write_open(outfile)))
	exit(1);

    coral_write_set_encoding(writer, "crl_encode", 1);

    if (coral_write_init_all(writer) < 0)
	exit(1);

    while ((iface = coral_read_block_all(&binfo, &blk, NULL))) {
	long cell_size, blk_size;

	cells_in_blk = ntohl(binfo->cell_count);
	cell_size = coral_cell_size(iface);
	blk_size = ntohl(binfo->blk_size);
	
	/* packet entries */
	for (i = 0; i < cells_in_blk; i++) {
	    cell = (char *)blk + i * cell_size;

	    if (!coral_cell_to_pkt(iface, cell, &linkpkt) ||
		coral_get_payload_by_proto(&linkpkt, &netpkt,
		    CORAL_NETPROTO_IP) < 0)
	    {
		/* if not ip on this cell at least output the timestamp */
		memset((void*)coral_cell_payload(iface, cell), 0,
							ATM_PAYLOAD_SIZE);
		memset((void*)coral_cell_header(iface, cell), 0,
						sizeof(union atm_hdr));
		continue;
	    }
	    
	    header = *coral_cell_header(iface,cell);
	    header.ui = ntohl(header.ui);
	    /* If this cell contains the aal5 trailer, save it. */
	    if (header.h.sdu_type == 1) {
		save_aal5 = 1;
	    } else {
		save_aal5 = 0;
	    }
	    /* For a good cell, clean up the IP and erase any payload */
	    sanitize_ip((char *)coral_cell_payload(iface,cell),
		    netpkt.buf - linkpkt.buf, save_aal5);
	}

	if (i * cell_size < blk_size) { 
	    /* Zero out the rest of the block */
	    memset((char*)blk + i * cell_size, 0, blk_size - (i * cell_size));
	}

	coral_write_block(writer, iface, binfo, blk);
    }
    if (errno) exit(errno);
    coral_write_close(writer);
    return 0;
}

