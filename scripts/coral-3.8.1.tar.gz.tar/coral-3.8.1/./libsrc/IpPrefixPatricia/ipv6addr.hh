#ifndef IPV6ADDR_HH
#define IPV6ADDR_HH

extern "C" {
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
}

class ipv6addr_t : public in6_addr {
public:
    static const int family = AF_INET6;
    ipv6addr_t() { memset(this, 0, sizeof(*this)); }
    ipv6addr_t(const in6_addr &src)
	{ *this = *static_cast<const ipv6addr_t*>(&src); }
    ipv6addr_t operator= (const in6_addr &src)
	{ return (*this = *static_cast<const ipv6addr_t*>(&src)); }

    bool operator < (const ipv6addr_t &b) const
    {
	for (size_t i = 0; i < sizeof(s6_addr); i++)
	    if (((uint8_t*)this)[i] != ((uint8_t*)&b)[i])
		return ((uint8_t*)this)[i] < ((uint8_t*)&b)[i];
	return false;
    }

    bool operator == (const ipv6addr_t &b) const
    {
	for (size_t i = 0; i < sizeof(s6_addr); i++)
	    if (((uint8_t*)this)[i] != ((uint8_t*)&b)[i])
		return false;
	return true;
    }

    ipv6addr_t operator & (const ipv6addr_t &b) const; // not implemented
    ipv6addr_t operator | (const ipv6addr_t &b) const; // not implemented
    ipv6addr_t operator ^ (const ipv6addr_t &b) const; // not implemented

    ipv6addr_t & operator &= (const ipv6addr_t &b); // not implemented
    ipv6addr_t & operator |= (const ipv6addr_t &b); // not implemented
    ipv6addr_t & operator ^= (const ipv6addr_t &b); // not implemented

    friend std::ostream & operator << (std::ostream & os, const ipv6addr_t &a)
    {
	char buf[64];
	return os << inet_ntop(AF_INET6, &a, buf, sizeof(buf));
    }
};

#endif // IPV6ADDR_HH
