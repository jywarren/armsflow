# Copyright 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
# All Rights Reserved 
# 
# Permission to use, copy, modify and distribute any part of this
# CoralReef software package for educational, research and non-profit
# purposes, without fee, and without a written agreement is hereby
# granted, provided that the above copyright notice, this paragraph
# and the following paragraphs appear in all copies.
# 
# Those desiring to incorporate this into commercial products or use
# for commercial purposes should contact the Technology Transfer
# Office, University of California, San Diego, 9500 Gilman Drive, La
# Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
# 
# IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
# PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
# DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
# SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
# THE POSSIBILITY OF SUCH DAMAGE.
# 
# THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
# UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
# SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
# OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
# OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
# PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
# ANY PATENT, TRADEMARK OR OTHER RIGHTS.
# 
# The CoralReef software package is developed by the CoralReef
# development team at the University of California, San Diego under
# the Cooperative Association for Internet Data Analysis (CAIDA)
# Program. Support for this effort is provided by the CAIDA grant
# NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
# N66001-01-1-8909, and by CAIDA members.
# 
# Report bugs and suggestions to coral-bugs@caida.org.

# Define required CVS variables
#$cvs_Id = '$Id: make_tables.pl,v 1.70 2007/06/06 18:17:48 kkeys Exp $';
#$cvs_Author = '$Author: kkeys $';
#$cvs_Name = '$Name: release-3-8-1 $';
#$cvs_Revision = '$Revision: 1.70 $';

use strict;
if (@ARGV < 2) {
    print STDERR "Usage:  $0 <copyright file> <class definition file> [...]\n";
    exit -1;
}

my $copyright_file = shift @ARGV;

my $swigfile = "Tables.swig";
my (%outfile, $reading_fields, $reading_agg, $reading_cmps,
    %aggregators, %agg_result, %agg_data_name, %agg_map, %field_cmp,
    %agg_fields, %other_fields, %field_type, %fields, %requires,
    %includes, %data_name, %keygen, %def_size, %isa_equiv, %table_sizes);
my @comp_types = ('pkts', 'bytes', 'flows', 'first', 'latest', 'duration',
		    'keys');

while (@ARGV) {
    my $def_file = shift @ARGV;
    $reading_fields = 0;

    if (!open(DEFS, $def_file)) {
	warn "Couldn't open $def_file to build C++ tables\n";
	next;
    }

    my $class_name;
    while (<DEFS>) {
	my $line = $_;
	chomp $line;
	if (substr($line, 0, 1) eq "#") { next; }
	if ($line =~ /^\s*$/) {
	    undef $reading_fields;
	    undef $reading_agg;
	    undef $class_name;
	    next;
	}
	if ($reading_fields) {
	    if (substr($line,0,1) =~ /\s/) {
		my @not_fields = split " ", $line;
		my $var_name = pop @not_fields;
		my $type_name = join " ", @not_fields;
		push @{$fields{$class_name}}, $var_name;
		$field_type{$class_name}{$var_name} = $type_name;
		next;
	    } else {
		$reading_fields = 0;
	    }
	}
	if ($reading_cmps) {
	    if (substr($line,0,1) =~ /\s/) {
		my ($var, $cmp_func) = split " ", $line;
		$field_cmp{$class_name}{$var} = $cmp_func;
		next;
	    } else {
		$reading_cmps = 0;
	    }
	}
	if ($reading_agg) {
	    if (substr($line,0,1) =~ /\s/) {
		my @chunks = split " ", $line;
		my $agg_name = $chunks[0];
		push @{$aggregators{$class_name}}, $agg_name;
		$agg_result{$class_name}{$agg_name} = $chunks[1];
		$agg_data_name{$class_name}{$agg_name} = $chunks[2];
		my @these_fields = split /,/, $chunks[3];
		my @those_fields = split /,/, $chunks[4];
		$agg_fields{$class_name}{$agg_name} = \@these_fields;
		$other_fields{$class_name}{$agg_name} = \@those_fields;
		if ($chunks[5]) {
		    $agg_map{$class_name}{$agg_name} = $chunks[5];
		}
		next;
	    } else {
		$reading_agg = 0;
	    }
	}
	my ($var, $value) = split /:/, $line;
	if ($var eq "ClassName") {
	    $class_name = $value;
	} elsif ($var eq "ISA") {
	    if (not defined $class_name) {
		die "Must define a class before doing ISA equivalence.\n";
	    }
	    $isa_equiv{$class_name} = "$value";
	} elsif ($var eq "HeaderFile") {
	    $outfile{$class_name} = "$value";
	} elsif ($var eq "Includes") {
	    my @inc = split /,/, $value;
	    $includes{$class_name} = \@inc;
	} elsif ($var eq "Requires") {
	    my @req = split /,/, $value;
	    $requires{$class_name} = \@req;
	} elsif ($var eq "DataName") {
	    $data_name{$class_name} = $value;
	} elsif ($var eq "KeyGen") {
	    $keygen{$class_name} = $value;
	} elsif ($var eq "TableSizes") {
	    my @tab_sizes = split /,/, $value;
	    $table_sizes{$class_name} = \@tab_sizes;
	} elsif ($var eq "DefaultSize") {
	    $def_size{$class_name} = $value;
	} elsif ($var eq "Fields") {
	    $reading_fields = 1;
	} elsif ($var eq "FieldCompares") {
	    $reading_cmps = 1;
	} elsif ($var eq "Aggregators") {
	    $reading_agg = 1;
	} else {
	    print STDERR "Unknown option: $line\n";
	}
    }
    close DEFS;
}
start_swigfile();
foreach my $class_name (keys %outfile) {
    output_header($class_name);
    add_to_swigfile($class_name);
    output_modfile($class_name);
}
foreach my $aliased (keys %isa_equiv) {
    output_modfile($aliased);
}


######################################################################
# Helper subroutines (called by other subroutines)
# Most of these subroutines are here because any new data type will
# need to change all of them, and thus they are collected together.
######################################################################


# For copying the arguments for entry_add() and entry_get().
sub copy_args
{
    my ($class_name) = @_;
    foreach my $field (@{$fields{$class_name}}) {
	if ($field_type{$class_name}{$field} eq "struct in_addr") {
#	    print OUTFILE "\tinet_aton($field, \&test_val->$field);\n";
	    print OUTFILE "\ttest_val->$field.s_addr = inet_addr($field);\n";
	} elsif ($field_type{$class_name}{$field} eq "char *") {
	    # ONLY used for lookup, okay to use same pointer unless NULL.
	    print OUTFILE "\ttest_val->$field = $field;\n";
	    print OUTFILE "\tif (!test_val->$field) { ",
			    "test_val->$field = \"\"; }\n";
	} else {
	    print OUTFILE "\ttest_val->$field = $field;\n";
	}
    }
}

# For copying the fields to be used when adding to hash table.
sub set_add_fields
{
    my ($class_name, $field, $type) = @_;
    if ($type eq "char *") {
	# Storing actual data, must make copy.
	print OUTFILE "\t    insert_val->$field = strdup(test_val->$field);\n";
    } else {
	print OUTFILE "\t    insert_val->$field = test_val->$field;\n";
    }
}

# For copying fields from one type of table to another.
# XXX This section is perhaps the most hard-coded area.
sub copy_agg
{
    my ($class_name, $local_field, $other_field, $other_type, $map) = @_;
    my $local_type = $field_type{$class_name}{$local_field};
    my $local = "curr_entry->$local_field";
    if (defined $map and $map eq "get_as_raw") {
	# XXX We are assuming that the type is struct in_addr, for get_as.
	$local = "\&$local";
	$local = "(char*)get_as_raw((ASFinder*)opt_ptr, $local, NULL, NULL)";
	print OUTFILE "\t    if (opt_ptr == NULL) { fputs(", 
	    "\"Need an ASFinder object to be able to do AS lookups.\\n\", ",
	    "stderr); exit(1); }\n";
    } elsif (defined $map and $map eq "proto_filter") {
	# XXX We assume we're aggregating from something with a protocol.
	print OUTFILE "\t    if (opt_ptr != NULL) {\n", 
	    "\t\tif (*(int*)opt_ptr != curr_entry->ip_proto) { continue; }\n",
	    "\t    }\n";
    }

    # XXX Currently all types can be directly copied, but perhaps not later.
    print OUTFILE "\t    test_val->$other_field = $local;\n";

    if (defined $map and $map eq "get_as_raw") {
	# XXX We are assuming that the other type is char *, from get_as.
	print OUTFILE "\t    if (!test_val->$other_field) { ",
			"test_val->$other_field = \"NOROUTE\"; }\n";
    }
}

# For specifying the parameters for entry_add() and entry_get().
sub write_param
{
    my ($class_name, $field) = @_;
    if ($field_type{$class_name}{$field} eq "struct in_addr") {
	print OUTFILE "\t\t\t\tchar * $field";
    } else {
	print OUTFILE "\t\t\t\t$field_type{$class_name}{$field} $field";
    }
}

sub save_text_keys
{
    my ($class_name) = @_;
    my @flds = @{$fields{$class_name}};
    foreach my $field (@flds) {
	my $type = $field_type{$class_name}{$field};
	if ($type eq "struct in_addr") {
	    print OUTFILE "\t    fprintf(stream, \"%s\\t\", ",
			    "inet_ntoa(curr_entry->$field));\n";
	} elsif ($type eq "char *") {
	    print OUTFILE
		"\t    fprintf(stream, \"%s\\t\", curr_entry->$field);\n";
	} else {
	    print OUTFILE
		"\t    fprintf(stream, \"%d\\t\", curr_entry->$field);\n";
	}
    }
}

sub load_text_keys
{
    my ($class_name) = @_;
    my @flds = @{$fields{$class_name}};
    foreach my $field (@flds) {
	my $type = $field_type{$class_name}{$field};
	print OUTFILE "\t    chunk = coral_strsep(&munged_line, \"\\t\");\n";
	print OUTFILE "\t    if (!chunk) {\n",
			"\t\tdelete_$data_name{$class_name}(insert_val);\n",
			"\t\treturn NULL;\n",
			"\t    }\n";
	if ($type eq "struct in_addr") {
	    print OUTFILE
		"\t    insert_val->$field.s_addr = inet_addr(chunk);\n";
	} elsif ($type eq "char *") {
	    print OUTFILE "\t    insert_val->$field = strdup(chunk);\n";
	} else {
	    print OUTFILE "\t    insert_val->$field = atoi(chunk);\n";
	}
    }
}

# Only in subroutine because it's used in more than one place; not due to
# dynamic data requirements
sub save_text_counter
{

print OUTFILE <<BLOCK;
		if (save_all) {
		    double first = 0, latest = 0;
		    if (counter.first() != FC_UNDEF) {
			first = counter.first();
		    }
		    if (counter.latest() != FC_UNDEF) {
			latest = counter.latest();
		    }
		    sprintf(buffer, "%" PRId64 "\\t%" PRId64 
				    "\\t%" PRId64 "\\t%.9f\\t%.9f",
			    counter.pkts(), counter.bytes(),
			    counter.flows(), first, latest);
		} else {
		    sprintf(buffer, "%" PRId64 "\\t%" PRId64 
				    "\\t%" PRId64,
			    counter.pkts(), counter.bytes(), counter.flows());
		}
BLOCK

}

# Only in subroutine because it's used in more than one place; not due to
# dynamic data requirements
sub load_text_counter
{

print OUTFILE <<BLOCK;
	    uint64_t pkts = 0, bytes = 0, flows = 0;
	    bool error = false;
	    chunk = coral_strsep(&munged_line, "\\t");
	    if (!chunk) {
		error = true;
		goto end;
	    }
	    sscanf(chunk, "%" SCNu64, &pkts);
	    if (multiplier > 1.0) {
		pkts = (uint64_t)(pkts * multiplier);
	    }
	    addend.pkts(pkts);
	    chunk = coral_strsep(&munged_line, "\\t");
	    if (!chunk) {
		error = true;
		goto end;
	    }
	    sscanf(chunk, "%" SCNu64, &bytes);
	    if (multiplier > 1.0) {
		bytes = (uint64_t)(bytes * multiplier);
	    }
	    addend.bytes(bytes);
	    chunk = coral_strsep(&munged_line, "\\t");
	    if (!chunk) {
		error = true;
		goto end;
	    }
	    sscanf(chunk, "%" SCNu64, &flows);
	    if (multiplier > 1.0) {
		flows = (uint64_t)(flows * multiplier);
	    }
	    addend.flows(flows);
	    chunk = coral_strsep(&munged_line, "\\t");
	    if (chunk) {
		addend.first(atof(chunk));
	    }
	    chunk = coral_strsep(&munged_line, "\\t");
	    if (chunk) {
		addend.latest(atof(chunk));
	    }
end:
BLOCK

}

sub save_bin_keylen
{
    my ($class_name) = @_;
    my @flds = @{$fields{$class_name}};
    foreach my $field (@flds) {
	my $type = $field_type{$class_name}{$field};
	if ($type eq "char *") {
	    print OUTFILE "\t\tstrlen(curr_entry->$field) ";
	} else {
	    print OUTFILE "\t\tsizeof($type) ";
	}
	if ($field ne $flds[$#flds]) { # No + for last element.
	    # Room for nul, for strings that aren't the last field.
	    # XXX Relies on structure of CAIDA::Tables::Split
	    if ($type eq "char *") {
		print OUTFILE "+ 1 ";
	    }
	    print OUTFILE "+\n";
	} else {
	    print OUTFILE ";\n";
	}
    }
}
sub save_bin_keys
{
    my ($class_name) = @_;
    my @flds = @{$fields{$class_name}};
    foreach my $field (@flds) {
	my $type = $field_type{$class_name}{$field};
	if ($type eq "char *") {
	    print OUTFILE "\t    fwrite(curr_entry->$field, sizeof(char), ",
			    "strlen(curr_entry->$field), stream);\n";
	} elsif ($type eq "uint32_t") {
	    print OUTFILE
		"\t    $type net_$field = htonl(curr_entry->$field);\n";
	    print OUTFILE
		"\t    fwrite(&net_$field, sizeof($type), 1, stream);\n";
	} elsif ($type eq "uint16_t") {
	    print OUTFILE
		"\t    $type net_$field = htons(curr_entry->$field);\n";
	    print OUTFILE
		"\t    fwrite(&net_$field, sizeof($type), 1, stream);\n";
	} else {
	    print OUTFILE "\t    fwrite(&curr_entry->$field, sizeof($type), ",
			    "1, stream);\n";
	}
	if ($type eq "char *" and $field ne $flds[$#flds]) {
	    # XXX Relies on structure of CAIDA::Tables::Split
	    print OUTFILE "\t    fwrite(&sep, sizeof(char), 1, stream);\n";
	}
    }
}

sub load_bin_keys
{
    my ($class_name) = @_;
    my @flds = @{$fields{$class_name}};
    foreach my $field (@flds) {
	my $type = $field_type{$class_name}{$field};
	if ($type eq "char *") {

print OUTFILE <<BLOCK;
	    if (keylen - str_read) {
		char * buf = new char[keylen];
		char curr_char;
		int i = 0;
		while (str_read < keylen) {
		    read_err = !fread(&curr_char, sizeof(char), 1, stream);
		    if (read_err) {
			delete_$data_name{$class_name}(insert_val);
			delete [] buf;
			return NULL;
		    }
		    str_read++;
		    if (curr_char == '\\0') {
			break;
		    }
		    buf[i++] = curr_char;
		}
		buf[i] = '\\0';
		insert_val->$field = strdup(buf);
		delete [] buf;
	    } else {
		insert_val->$field = strdup("");
	    }
BLOCK

	} else {
	    print OUTFILE
		"\t    read_err = !fread(&insert_val->$field, sizeof($type), 1, stream);\n";
	    if ($type eq "uint32_t") {
		print OUTFILE
		    "\t    insert_val->$field = ntohl(insert_val->$field);\n";
	    } elsif ($type eq "uint16_t") {
		print OUTFILE
		    "\t    insert_val->$field = ntohs(insert_val->$field);\n";
	    }
	    print OUTFILE "\t    if (read_err) {\n",
		"\t\tdelete_$data_name{$class_name}(insert_val);\n",
		"\t\treturn NULL;\n",
		"\t    }\n";
	}
    }
}

# For setting the return value in entry_get().
sub set_ret_val
{
    my ($class_name) = @_;
    print OUTFILE "\tret_val = new char*[", @{$fields{$class_name}}+1, "];\n";
    my $index = 0;
    foreach my $field (@{$fields{$class_name}}) {
	if ($field_type{$class_name}{$field} eq "struct in_addr") {
	    print OUTFILE "\tret_val[", $index++, "] = ",
			    "strdup(inet_ntoa(opaque_key->$field));\n";
	} elsif ($field_type{$class_name}{$field} eq "char *") {
	    print OUTFILE "\tret_val[", $index++, "] = ",
			    "strdup(opaque_key->$field);\n";
	} else {
	    print OUTFILE "\tsprintf(tmpstr, \"%d\", opaque_key->$field);\n";
	    print OUTFILE "\tret_val[", $index++, "] = strdup(tmpstr);\n";
	}
    }
    print OUTFILE "\tret_val[$index] = NULL;\n";
}

# For doing comparisons inside the hash's internal data structure.
sub compare_fields
{
    my ($class_name) = @_;
    my @flds = @{$fields{$class_name}};
    foreach my $field (@flds) {
	my $compare_str;
	if (defined $field_cmp{$class_name}{$field}) {
	    $compare_str = $field_cmp{$class_name}{$field} .
			    "(compare1->$field, compare2->$field)";
	} elsif ($field_type{$class_name}{$field} eq "struct in_addr") {
	    $compare_str = "num_compare(ntohl(compare1->$field.s_addr), ".
			    "ntohl(compare2->$field.s_addr))";
	} elsif ($field_type{$class_name}{$field} eq "char *") {
	    $compare_str = "strcmp(compare1->$field, compare2->$field)";
	} else {
	    $compare_str = "num_compare(compare1->$field, compare2->$field)";
	}
	print OUTFILE "    if (ret_val = $compare_str) {}\n";
	if ($field ne $flds[$#flds]) { # No else for last compare
	    print OUTFILE "    else";
	}
    }
}

sub delete_fields
{
    my ($class_name) = @_;
    my @flds = @{$fields{$class_name}};
    foreach my $field (@flds) {
	if ($field_type{$class_name}{$field} eq "char *") {
	    print OUTFILE "    if (to_die->$field) {\n";
	    print OUTFILE "\tfree(to_die->$field);\n";
	    print OUTFILE "    }\n";
	}
    }
}

# Print out the copyright to the specified file.  Erases any existing data in
# file.
sub print_copyright {
    my ($filename) = @_;

    open COPYRIGHT, $copyright_file or die "Couldn't open $copyright_file";
    open DUMPFILE, ">$filename" or die "Couldn't open $filename";

    if ($filename =~ /\.pm$/ or $filename =~ /\.inc$/) {

print DUMPFILE <<BLOCK;
# WARNING:  This file is autogenerated by $0, do NOT modify,
#	     all changes will be lost.
BLOCK

	while (<COPYRIGHT>) {
	    print DUMPFILE "# $_";
	}

    } else {

print DUMPFILE <<BLOCK;
/*
 * WARNING:  This file is autogenerated by $0, do NOT modify,
 *	     all changes will be lost.
 */
BLOCK

	print DUMPFILE "/*\n";
	while (<COPYRIGHT>) {
	    print DUMPFILE " * $_";
	}
	print DUMPFILE " */\n\n";
    }

    print DUMPFILE "\n";
    close DUMPFILE;
    close COPYRIGHT;
}


######################################################################
# Important subroutines (called in main code)
######################################################################

sub start_swigfile
{
    if (not defined $swigfile) {
	die "Didn't define a swig filename";
    }
    print_copyright($swigfile);
    open SWIGFILE, ">>$swigfile" or
		    die "Couldn't open $swigfile";

print SWIGFILE <<BLOCK;
%module "CAIDA::Tables";

%feature("compactdefaultargs", "1");

%include "../CRL/charmap.swig"

/* This could be a lie, but it shouldn't matter to SWIG. 
 * We just don't want SWIG to try to make _p_uint16_t types. */
typedef unsigned char uint8_t;
typedef unsigned short uint16_t;
typedef unsigned int uint32_t;
%{
#include "clean_perl.hh" // get rid of perl defines that conflict with g++
#include "../Traffic2/FlowCounter.h"
typedef FlowCounter mortal_FlowCounter;
/* Incredible hack to work around a potential SWIG bug, where even with
 * -noproxy used, references are being manipulated to cause
 * double-deallocation.  Setting SWIG_SHADOW to 0 seems to avoid this...for
 * now.  Only happen when SWIG recognizes pointers to existing classes
 * (SWIG 1.3.25) */
#undef SWIG_SHADOW
#define SWIG_SHADOW 0
%}
/* Hack to force SWIG to accept FlowCounter and mortal_FlowCounter as equiv.  */
class FlowCounter {};
class mortal_FlowCounter : public FlowCounter {};
BLOCK

print SWIGFILE <<BLOCK;

%typemap(in) void * new_state
{
    if (!SvROK(\$input))
	croak("\$input is not a reference.");
    if (!SvOK(\$input)) {
	// If we set this to NULL without releasing it, it would cause
	// a memory leak, and one should not pass in an undefined state
	// anyway.
	croak("Sorry, undefined value not allowed.");
    } else {
	MAGIC * tie_magic;
	tie_magic = mg_find(SvRV(\$input), 'P');
	// If we do not decrement the refcount, it will create a reference
	// loop and never be freed.
	SvREFCNT_dec(SvRV((SV*)tie_magic->mg_obj));
	\$1 = (void*)newRV_inc(SvRV(\$input));
    }
}

%typemap(out) void *
{
    if (\$1 == NULL) {
	\$result = &PL_sv_undef;
    } else {
	\$result = (SV*)\$1;
    }
    argvi++;
}

%typemap(in) FILE * instream
{
    SV * val;
    if (SvROK(\$input)) {
	val = SvRV(\$input);
    } else {
	val = \$input;
    }
    PerlIO * handle = IoIFP(sv_2io(val));
    \$1 = PerlIO_findFILE(handle);
}

%typemap(in) FILE * outstream
{
    SV * val;
    if (SvROK(\$input)) {
	val = SvRV(\$input);
    } else {
	val = \$input;
    }
    PerlIO * handle = IoOFP(sv_2io(val));
    \$1 = PerlIO_findFILE(handle);
}

%inline %{
int * int_munch(int num)
{
    static int ret_val;
    ret_val = num;
    return &ret_val;
}
%}

%{
// Slightly hacky, this returns the difference between the previous
// refcount and the new one.  Ideally, it should be 0, as table->m_data
// should point to a hash with only one reference, but this is not
// guaranteed to be true.  Therefore, if not, we should not delete
// this table until the last reference is properly disposed of.
template <class TYPE>
int release_magic(TYPE * table)
{
    MAGIC * tie_magic;
    SV * table_obj;
    int old_refcnt, new_refcnt;
    if (!table->m_data) return 0;
    tie_magic = mg_find(SvRV((SV*)table->m_data), 'P');
    table_obj = SvRV(tie_magic->mg_obj);
    // Here we must readjust the refcount we decremented above.
    old_refcnt = SvREFCNT(table_obj);
    SvREFCNT_inc(table_obj);
    // This will delete the reference.
    SvREFCNT_dec((SV*)table->m_data);
    new_refcnt = SvREFCNT(table_obj);
    // In case this function is called twice.
    table->m_data = NULL;
    return new_refcnt - old_refcnt;
}
%}

BLOCK

    close SWIGFILE;
}

sub add_to_swigfile
{
    my ($class_name) = @_;
    open SWIGFILE, ">>$swigfile" or
		    die "Couldn't open $swigfile";

print SWIGFILE <<BLOCK;

%typemap(out) $data_name{$class_name}_t **
{
    AV *myav;
    SV **svs;
    int i = 0, len = 0;
    /* Figure out how many elements we have */
    while (\$1[len])
        len++;
    svs = (SV **) malloc(len*sizeof(SV *));
    for (i = 0; i < len ; i++) {
	svs[i] = sv_newmortal();
	sv_setref_pv((SV*)svs[i],"_p_$data_name{$class_name}_t",
			(void *) \$1[i]);
    };
    myav = av_make(len,svs);
    free(svs);
    \$result = newRV_noinc((SV*)myav);
    sv_2mortal(\$result);
    argvi++;
}

%{
#include "$outfile{$class_name}"
typedef $class_name mortal_$class_name;
%}
%include "$outfile{$class_name}"

class mortal_$class_name : public $class_name {};
%inline %{
int release_${class_name}_magic($class_name * table)
{
    return release_magic(table);
}
%}
BLOCK

    close SWIGFILE;
}

sub output_header
{
    my ($class_name) = @_;
    print_copyright($outfile{$class_name});
    if (not defined $outfile{$class_name}) {
	die "Didn't define a header filename";
    }
    open OUTFILE, ">>$outfile{$class_name}" or
		    die "Couldn't open $outfile{$class_name}";
    my $data_type = $data_name{$class_name} . "_t";

    print OUTFILE "#ifndef ", uc($class_name), "_H\n";
    print OUTFILE "#define ", uc($class_name), "_H\n";

print OUTFILE <<BLOCK;

#include "config.h"
#include "crl_byteorder.h"
#include "caida_t.h"
#include "misc_funcs.hh"
#include "../Traffic2/FlowCounter.h"
extern "C" {
#include "libcoral.h"
#include "hashtab.h"
};
#include <algorithm>

BLOCK

    foreach my $agg (@{$aggregators{$class_name}}) {
	my $result = $agg_result{$class_name}{$agg};
	if ($isa_equiv{$result}) {
	    $result = $isa_equiv{$result};
	}
	print OUTFILE "#include \"$outfile{$result}\"\n";
    }

    foreach my $include (@{$includes{$class_name}}) {
	print OUTFILE "#include \"$include\"\n";
    }

    print OUTFILE "typedef struct $data_type {\n";
    foreach my $field (@{$fields{$class_name}}) {
	print OUTFILE "    $field_type{$class_name}{$field} $field;\n";
    }

print OUTFILE <<BLOCK;
    FlowCounter count;
} $data_type;

static int cmp_$data_name{$class_name}_by_keys(const void * data1,
					    const void * data2)
{
    $data_type * compare1 = ($data_type *)data1;
    $data_type * compare2 = ($data_type *)data2;
    int ret_val;
BLOCK
    compare_fields($class_name);
    print OUTFILE "    return ret_val;\n}\n\n";

    foreach my $type (@comp_types) {
	# For ascending sort
	print OUTFILE "static bool $data_name{$class_name}_less_by_$type(", 
			"$data_type* data1, $data_type* data2)\n{\n";
	if ($type eq 'keys') {
	    # See helper subroutine
	    print OUTFILE "    return (cmp_$data_name{$class_name}_by_keys((void*)data1, (void*)data2) < 0);\n}\n\n";
	} else {
	    print OUTFILE "    return data1->count.$type() < data2->count.$type();\n}\n\n";
	}

	# For descending sort
	print OUTFILE "static bool $data_name{$class_name}_more_by_$type(", 
			"$data_type* data1, $data_type* data2)\n{\n";
	if ($type eq 'keys') {
	    # See helper subroutine
	    print OUTFILE "    return (cmp_$data_name{$class_name}_by_keys((void*)data1, (void*)data2) > 0);\n}\n\n";
	} else {
	    print OUTFILE "    return data1->count.$type() > data2->count.$type();\n}\n\n";
	}
    }

print OUTFILE <<BLOCK;
static unsigned long make_$data_name{$class_name}_key(const void * data) {
    const $data_type * key_maker = ($data_type *)data;
BLOCK

    foreach my $field (@{$fields{$class_name}}) {
	$keygen{$class_name} =~ s/$field/key_maker->$field/;
    }

print OUTFILE <<BLOCK;
    return (unsigned long) $keygen{$class_name};
}

static void delete_$data_name{$class_name}(void * data) {
    $data_type * to_die = ($data_type *)data;
    if (!to_die) return;
BLOCK

    # See helper subroutine
    delete_fields($class_name);

print OUTFILE <<BLOCK;
    delete to_die;
}

class $class_name {
public:
    FlowCounter * total() { return &m_total; };
    FlowCounter * other() { return &m_other; };
    void read_other(char * str)
    {
	double multiplier = 1.0; // XXX Currently no reason to scale 'other'
	char * munged_line = strdup(str);
	char * chunk = NULL;
	FlowCounter addend;
BLOCK

    load_text_counter();

print OUTFILE <<BLOCK;
	if (!error) {
	    m_other = addend;
	    m_total.add(&addend);
	}
	free(munged_line);
	return;
    }
    char * write_other(bool save_all = true)
    {
	static char buffer[1024];
	FlowCounter counter = m_other;
BLOCK

    save_text_counter();

print OUTFILE <<BLOCK;
	return buffer;
    }
    int num_entries() {
	if (!m_table) { return 0; }
	return num_hash_entries(m_table);
    };
    char ** get_key_fields($data_type * opaque_key)
    {
	static char ** ret_val = NULL;
	char tmpstr[50];
	if (ret_val) {
	    int i = 0;
	    while (ret_val[i]) {
		free(ret_val[i]); // Made with strdup()
		ret_val[i] = NULL;
		i++;
	    }
	    delete [] ret_val;
	    ret_val = NULL;
	}
BLOCK

    # See helper subroutine
    set_ret_val($class_name);

print OUTFILE <<BLOCK;
	return ret_val;
    };
BLOCK

    foreach my $type (@comp_types) {

print OUTFILE <<BLOCK;
    $data_type ** sort_by_$type(int top_n = -1, int ascend_sort = 0)
    {
	static $data_type ** ret_val = NULL;
	$data_type ** temp_array = NULL;
	$data_type * test_val;
	int idx;
	int table_size;
	if (ret_val) {
	    delete [] ret_val;
	    ret_val = NULL;
	}

	if (!m_table) {
	    ret_val = new $data_type*[1];
	    ret_val[0] = NULL;
	    return ret_val;
	}

	table_size = num_hash_entries(m_table);
	if (top_n < 0 || top_n > table_size) {
	    top_n = table_size;
	}

	if (top_n == 0) { // No point in continuing
	    ret_val = new $data_type*[1];
	    ret_val[0] = NULL;
	    return ret_val;
	}

	init_hash_walk(m_table);

	idx = 0;
	temp_array = new $data_type*[table_size+1];
	while (test_val = ($data_type*)next_hash_walk(m_table)) {
	    temp_array[idx++] = test_val;
	}
	if (top_n == table_size) { // Normal sort
	    ret_val = temp_array;
	    if (ascend_sort) {
		std::sort(ret_val, ret_val+table_size, $data_name{$class_name}_less_by_$type);
	    } else {
		std::sort(ret_val, ret_val+table_size, $data_name{$class_name}_more_by_$type);
	    }
	} else {
	    ret_val = new $data_type*[top_n+1];
	    if (ascend_sort) {
		std::partial_sort_copy(temp_array, temp_array+table_size,
			    ret_val, ret_val+top_n, $data_name{$class_name}_less_by_$type);
	    } else {
		std::partial_sort_copy(temp_array, temp_array+table_size,
			    ret_val, ret_val+top_n, $data_name{$class_name}_more_by_$type);
	    }
	    delete [] temp_array;
	}
	ret_val[top_n] = NULL;
	return ret_val;
    }
BLOCK

    }

    print OUTFILE "    FlowCounter * entry_get(\n";

    my @flds = @{$fields{$class_name}};
    foreach my $field (@flds) {
	# See helper subroutine
	write_param($class_name, $field);
	if ($field ne $flds[$#flds]) { # No comma for last arg
	    print OUTFILE ",\n";
	} else {
	    print OUTFILE ")\n";
	}
    }

print OUTFILE <<BLOCK;
    {
	$data_type * test_val = new $data_type;
	$data_type * found_val;
	if (!m_table)
	    return NULL;

BLOCK

    # See helper subroutine
    copy_args($class_name);

print OUTFILE <<BLOCK;
	found_val = ($data_type*)find_hash_entry(m_table, test_val);
	delete test_val;
	if (found_val) {
	    return &found_val->count;
	} else {
	    return NULL;
	}
    };
    FlowCounter * entry_add(
BLOCK

    foreach my $field (@{$fields{$class_name}}) {
	# See helper subroutine
	write_param($class_name, $field);
	print OUTFILE ",\n";
    }

print OUTFILE <<BLOCK;
				FlowCounter * addend)
    {
	$data_type * test_val = new $data_type;
	$data_type * found_val;
	if (!m_table) {
	    m_table = init_hash_table("# $class_name hash",
				    cmp_$data_name{$class_name}_by_keys,
				    make_$data_name{$class_name}_key,
				    delete_$data_name{$class_name}, m_size);
	    if (!m_table) { out_of_mem(); }
	}
BLOCK

    # See helper subroutine
    copy_args($class_name);

print OUTFILE <<BLOCK;
	found_val = ($data_type*)find_hash_entry(m_table, test_val);
	if (found_val) {
	    delete test_val;
	    m_total.add(addend);
	    return found_val->count.add(addend);
	} else {
	    $data_type * insert_val = new $data_type;
BLOCK

    foreach my $field (@{$fields{$class_name}}) {
	my $type = $field_type{$class_name}{$field};
	# See helper subroutine
	set_add_fields($class_name, $field, $type);
    }

print OUTFILE <<BLOCK;
	    delete test_val;
	    m_total.add(addend);
	    if (add_hash_entry(m_table, insert_val)) {
		out_of_mem();
	    }
	    return insert_val->count.add(addend);
	}
    };
    $data_type * first_key()
    {
	if (!m_table)
	    return NULL;

	init_hash_walk(m_table);
	return ($data_type*)next_hash_walk(m_table);
    };
    $data_type * next_key() {
	if (!m_table)
	    return NULL;

	return ($data_type*)next_hash_walk(m_table);
    };
    FlowCounter * get_count_from_key($data_type * opaque_key)
    {
	return &opaque_key->count;
    };
    $class_name * add($class_name * other)
    {
	$data_type * test_val;
	$data_type * local_found;
	$data_type * insert_val;
	if (!other) // No table to add
	    return this;

	if (!other->m_table) // Nothing to add
	    return this;

	init_hash_walk(other->m_table);
	if (!m_table) {
	    m_table = init_hash_table("# $class_name hash",
				    cmp_$data_name{$class_name}_by_keys,
				    make_$data_name{$class_name}_key,
				    delete_$data_name{$class_name}, m_size);
	    if (!m_table) { out_of_mem(); }
	}
	while (test_val = ($data_type*)next_hash_walk(other->m_table)) {
	    local_found = ($data_type*)find_hash_entry(m_table, test_val);
	    if (local_found) {
		local_found->count.add(&test_val->count);
	    } else {
		insert_val = new $data_type;
BLOCK

    foreach my $field (@{$fields{$class_name}}) {
	my $type = $field_type{$class_name}{$field};
	# See helper subroutine
	set_add_fields($class_name, $field, $type);
    }

print OUTFILE <<BLOCK;
		insert_val->count.add(&test_val->count);
		if (add_hash_entry(m_table, insert_val)) {
		    out_of_mem();
		}
	    }
	}
	m_total.add(&other->m_total);
	m_other.add(&other->m_other);
	return this;
    };
BLOCK

    foreach my $agg (@{$aggregators{$class_name}}) {
	my $result = $agg_result{$class_name}{$agg};
	if ($isa_equiv{$result}) {
	    $result = $isa_equiv{$result};
	}
	my @class_fields = @{$agg_fields{$class_name}{$agg}};
	my $agg_name = $agg_data_name{$class_name}{$agg};
	my $agg_type = $agg_name . "_t";
	my $table_name = $agg_name . "_table";

print OUTFILE <<BLOCK;
    $result * $agg(int table_size = -1, void * opt_ptr = NULL)
    {
	$result * $table_name;
	$data_type * curr_entry;
	$agg_type * found_val;
	$agg_type * test_val;

	if (table_size < 0) {
	    table_size = m_size;
	}
	$table_name = new $result(table_size);
	if (!m_table)
	    return $table_name;

	test_val = new $agg_type;
	$table_name->m_table = init_hash_table("# $result hash",
		    cmp_${agg_name}_by_keys, make_${agg_name}_key,
		    delete_$agg_name, $table_name->m_size);
	if (!$table_name->m_table) { out_of_mem(); }
	init_hash_walk(m_table);
	while (curr_entry = ($data_type *)next_hash_walk(m_table)) {
BLOCK

	for (my $field_num = 0; $field_num < @class_fields; $field_num++)
	{
	    my $this_field = $class_fields[$field_num];
	    my $that_field = ${$other_fields{$class_name}{$agg}}[$field_num];
	    # Only store info on current class, must assume are the same.
	    my $other_type = $field_type{$result}{$that_field};
	    my $map = $agg_map{$class_name}{$agg};
	    # See helper subroutine
	    copy_agg($class_name, $this_field, $that_field, $other_type, $map);
	}

print OUTFILE <<BLOCK;
	    found_val = ($agg_type *)find_hash_entry($table_name->m_table,
						    test_val);
	    if (found_val) {
		found_val->count.add(&curr_entry->count);
	    } else {
		$agg_type * insert_val = new $agg_type;
BLOCK

	for (my $field_num = 0; $field_num < @class_fields; $field_num++)
	{
	    my $this_field = $class_fields[$field_num];
	    my $that_field = ${$other_fields{$class_name}{$agg}}[$field_num];
	    my $type = $field_type{$result}{$that_field};
	    # See helper subroutine
	    set_add_fields($class_name, $that_field, $type);
	}

print OUTFILE <<BLOCK;
		insert_val->count.add(&curr_entry->count);
		if (add_hash_entry($table_name->m_table, insert_val)) {
		    out_of_mem();
		}
	    }
	    $table_name->m_total.add(&curr_entry->count);
	}
	$table_name->m_total.add(&m_other);
	$table_name->m_other.add(&m_other);
	delete test_val;
	return $table_name;
    };
BLOCK

    }

print OUTFILE <<BLOCK;
    int save_text(FILE * outstream, int save_all = 1)
    {
	$data_type * curr_entry;
	FILE * stream = outstream;

	if (!stream) {
	    coral_diag(1, ("Warning:  invalid filehandle in save_text()\\n"));
	    return 1;
	}

	if (m_table) {
	    init_hash_walk(m_table);
	    while (curr_entry = ($data_type *)next_hash_walk(m_table)) {
		FlowCounter& counter = curr_entry->count;
		char buffer[1024];
BLOCK

    # See helper subroutine
    save_text_keys($class_name);
    save_text_counter();

print OUTFILE <<BLOCK;
		fprintf(stream, "%s\\n", buffer);
	    }
	}
	fprintf(stream, "# end of text table\\n");
	fflush(stream);
	return 0;
    }
    char * load_text(FILE * instream, double multiplier = 1.0)
    {
	const int line_size = 200;
	static char * file_line = new char[line_size];
	char * munged_line = NULL;
	char * chunk = NULL;
	FILE * stream = instream;

	if (!stream) {
	    coral_diag(1, ("Warning:  invalid filehandle in load_text()\\n"));
	    return NULL;
	}

	if (!m_table) {
	    m_table = init_hash_table("# $class_name hash",
				    cmp_$data_name{$class_name}_by_keys,
				    make_$data_name{$class_name}_key,
				    delete_$data_name{$class_name}, m_size);
	    if (!m_table) { out_of_mem(); }
	}
	while (fgets(file_line, line_size, stream)) {
	    if (file_line[0] == '#') {
		return file_line;
	    }
	    $data_type * insert_val = new $data_type;
	    $data_type * found_val;
	    FlowCounter addend;
	    munged_line = file_line;
BLOCK

    # See helper subroutine
    load_text_keys($class_name);
    load_text_counter();

print OUTFILE <<BLOCK;
	    if (error) {
		delete_$data_name{$class_name}(insert_val);
		return NULL;
	    }
	    found_val = ($data_type*)find_hash_entry(m_table, insert_val);
	    if (found_val) {
		found_val->count.add(&addend);
		delete_$data_name{$class_name}(insert_val);
	    } else {
		insert_val->count = addend;
		if (add_hash_entry(m_table, insert_val)) {
		    out_of_mem();
		}
	    }
	    m_total.add(&addend);
	}
	return NULL;
    }
    int save_binary(FILE * outstream, int save_all = 1)
    {
	uint8_t full_count = save_all;
	$data_type * curr_entry;
	char sep = '\\0';
	FILE * stream = outstream;
	uint8_t keylen;

	if (!stream) {
	    coral_diag(1, ("Warning:  invalid filehandle in save_binary()\\n"));
	    return 1;
	}

	if (m_table) {
	    init_hash_walk(m_table);
	    while (curr_entry = ($data_type *)next_hash_walk(m_table)) {
		keylen =
BLOCK

    # See helper subroutine
    save_bin_keylen($class_name);

    print OUTFILE "\t    fwrite(&keylen, sizeof(uint8_t), 1, stream);\n";
    print OUTFILE "\t    fwrite(&full_count, sizeof(uint8_t), 1, stream);\n";

    # See helper subroutine
    save_bin_keys($class_name);

print OUTFILE <<BLOCK;
		uint64_t pkts = crl_hton64(curr_entry->count.pkts());
		uint64_t bytes = crl_hton64(curr_entry->count.bytes());
		uint64_t flows = crl_hton64(curr_entry->count.flows());
		fwrite(&pkts, sizeof(uint64_t), 1, stream);
		fwrite(&bytes, sizeof(uint64_t), 1, stream);
		fwrite(&flows, sizeof(uint64_t), 1, stream);

		if (full_count) {
		    uint32_t first_sec = htonl((int)curr_entry->count.first());
		    uint32_t first_nsec = htonl(
				    (int)((curr_entry->count.first() -
				    (int)curr_entry->count.first()) * 1e9));
		    uint32_t latest_sec = htonl(
				    (int)curr_entry->count.latest());
		    uint32_t latest_nsec = htonl(
				    (int)((curr_entry->count.latest() -
				    (int)curr_entry->count.latest()) * 1e9));
		    fwrite(&first_sec, sizeof(uint32_t), 1, stream);
		    fwrite(&first_nsec, sizeof(uint32_t), 1, stream);
		    fwrite(&latest_sec, sizeof(uint32_t), 1, stream);
		    fwrite(&latest_nsec, sizeof(uint32_t), 1, stream);
		}
	    }
	}
	uint8_t trailer = 0;
	fwrite(&trailer, sizeof(uint8_t), 1, stream);
	fprintf(stream, "\\n# end of binary table\\n");
	fflush(stream);
	return 0;
    }
    char * load_binary(FILE * instream, double multiplier = 1.0)
    {
	uint8_t keylen;
	uint8_t full_count; // Does flow count include first and latest?
	FILE * stream = instream;

	if (!stream) {
	    coral_diag(1, ("Warning:  invalid filehandle in load_binary()\\n"));
	    return NULL;
	}

	if (!m_table) {
	    m_table = init_hash_table("# $class_name hash",
				    cmp_$data_name{$class_name}_by_keys,
				    make_$data_name{$class_name}_key,
				    delete_$data_name{$class_name}, m_size);
	    if (!m_table) { out_of_mem(); }
	}
	while (fread(&keylen, sizeof(uint8_t), 1, stream)) {
	    int str_read = 0;
	    int read_err;
	    if (keylen == 0) {
		static char file_line[200];
		fgetc(stream); // Munch the newline
		fgets(file_line, 200, stream);
		return file_line;
	    }
	    read_err = !fread(&full_count, sizeof(uint8_t), 1, stream);
	    if (read_err) return NULL;
	    $data_type * insert_val = new $data_type;
	    $data_type * found_val;
	    FlowCounter addend;
BLOCK

    # See helper subroutine
    load_bin_keys($class_name);

print OUTFILE <<BLOCK;
            uint64_t pkts = 0, bytes = 0, flows = 0;
            uint32_t first_sec, first_nsec, latest_sec, latest_nsec;
	    read_err = !fread(&pkts, sizeof(uint64_t), 1, stream);
	    if (read_err) {
		delete_$data_name{$class_name}(insert_val);
		return NULL;
	    }
	    pkts = crl_ntoh64(pkts);
	    if (multiplier > 1.0) {
		pkts = (uint64_t)(pkts * multiplier);
	    }
	    read_err = !fread(&bytes, sizeof(uint64_t), 1, stream);
	    if (read_err) {
		delete_$data_name{$class_name}(insert_val);
		return NULL;
	    }
	    bytes = crl_ntoh64(bytes);
	    if (multiplier > 1.0) {
		bytes = (uint64_t)(bytes * multiplier);
	    }
	    read_err = !fread(&flows, sizeof(uint64_t), 1, stream);
	    if (read_err) {
		delete_$data_name{$class_name}(insert_val);
		return NULL;
	    }
	    flows = crl_ntoh64(flows);
	    if (multiplier > 1.0) {
		flows = (uint64_t)(flows * multiplier);
	    }
            addend.pkts(pkts);
            addend.bytes(bytes);
            addend.flows(flows);

	    if (full_count) {
		read_err = !fread(&first_sec, sizeof(uint32_t), 1, stream);
		if (read_err) {
		    delete_$data_name{$class_name}(insert_val);
		    return NULL;
		}
		read_err = !fread(&first_nsec, sizeof(uint32_t), 1, stream);
		if (read_err) {
		    delete_$data_name{$class_name}(insert_val);
		    return NULL;
		}
		read_err = !fread(&latest_sec, sizeof(uint32_t), 1, stream);
		if (read_err) {
		    delete_$data_name{$class_name}(insert_val);
		    return NULL;
		}
		read_err = !fread(&latest_nsec, sizeof(uint32_t), 1, stream);
		if (read_err) {
		    delete_$data_name{$class_name}(insert_val);
		    return NULL;
		}
		addend.first(ntohl(first_sec) + (ntohl(first_nsec) / 1e9));
		addend.latest(ntohl(latest_sec) + (ntohl(latest_nsec) / 1e9));
	    }

	    found_val = ($data_type*)find_hash_entry(m_table, insert_val);
	    if (found_val) {
		found_val->count.add(&addend);
		delete_$data_name{$class_name}(insert_val);
	    } else {
		insert_val->count = addend;
		if (add_hash_entry(m_table, insert_val)) {
		    out_of_mem();
		}
	    }
	    m_total.add(&addend);
	}
	return NULL;
    }
    void save_state(void * new_state) { m_data = new_state; };
    void * load_state() { return m_data; };
    void clear()
    {
	if (m_table) {
	    clear_hash_table(m_table);
	}
	m_total.reset();
    };
    $class_name(int table_size = -1)
    {
BLOCK

    print OUTFILE "\tstatic const long sizes[] = { ";
    my @tab_sizes = @{$table_sizes{$class_name}};
    foreach my $size (@tab_sizes) {
	print OUTFILE $size;
	if ($size ne $tab_sizes[$#tab_sizes]) { # No comma for last value
	    print OUTFILE ", ";
	}
    }
    print OUTFILE " };\n";

print OUTFILE <<BLOCK;
	std::set_new_handler(out_of_mem);
	m_size = 0;
	if (table_size > 0) {
	    for (int idx = 0; idx <= $#tab_sizes; idx++) {
		if (table_size <= sizes[idx]) {
		    m_size = sizes[idx];
		    break;
		}
	    }
	    if (!m_size) { // Given size is larger than all available
		// Use largest available
		m_size = sizes[$#tab_sizes];
	    }
	}
	if (!m_size) { // Use default
	    m_size = $def_size{$class_name};
	}
	m_table = NULL;
	m_data = NULL;
    };
    ~$class_name()
    {
	if (m_table) {
//	    dump_hashtab_stats(m_table);
	    free_hash_table(m_table);
	    m_table = NULL;
	}
    };
    int m_size;
    hash_tab * m_table;
    void * m_data;
    FlowCounter m_total;
    FlowCounter m_other;
};
#endif
BLOCK

    close OUTFILE;
}

sub output_modfile
{
    my ($class_name) = @_;
    my $perlfile = "$class_name" . "_SWIG.pm";
    print_copyright($perlfile);
    open PM, ">>$perlfile" or die "Couldn't open $perlfile";

    print PM "package CAIDA::Tables::${class_name}_SWIG;\n";
print PM <<BLOCK;
if (\$CAIDA::Tables::failed_new{'CAIDA::Tables'}) {
    die "Previous problem loading CAIDA::Tables";
}
eval 'require CAIDA::Tables;';
if (\$@) {
    \$CAIDA::Tables::failed_new{'CAIDA::Tables'} = 1;
    die "\$@" .  "Cannot load $class_name";
}

BLOCK

    if (defined $isa_equiv{$class_name}) {

print PM <<BLOCK;
use CAIDA::Tables::$isa_equiv{$class_name}_SWIG;
use vars qw(\@ISA);
\@ISA = qw(CAIDA::Tables::$isa_equiv{$class_name}_SWIG);

package CAIDA::Tables::$isa_equiv{$class_name}_SWIG;
BLOCK

    }

    foreach my $require (@{$requires{$class_name}}) {
	$require = "CAIDA::Tables::$require";
	print PM "use $require;\n";
    }

    if (defined $isa_equiv{$class_name}) {
	print PM "1;\n";
	return;
    }

print PM <<'BLOCK';

use Carp;
use strict;

sub TIEHASH
{
    return $_[1];
}

sub FIRSTKEY
{
    my ($self) = @_;
BLOCK

    print PM "    my \$key = CAIDA::Tables::${class_name}_first_key(\$self);\n";

print PM <<'BLOCK';
    if (not defined $key) {
	return ();
    } else {
	return $key;
    }
}

sub NEXTKEY
{
    my ($self) = @_;
BLOCK

    print PM "    my \$key = CAIDA::Tables::${class_name}_next_key(\$self);\n";

print PM <<'BLOCK';
    if (not defined $key) {
	return ();
    } else {
	return $key;
    }
}

sub FETCH
{
    my ($self, $key) = @_;
BLOCK

    print PM "    my \$value = CAIDA::Tables::$class_name",
		    "_get_count_from_key(\$self, \$key);\n";

print PM <<'BLOCK';
    return $value;
}

sub STORE
{
    # XXX Doing nothing here.  Maybe someday.
    my ($self, $key, $value) = @_;
}

BLOCK

print PM "package CAIDA::Tables::${class_name}_SWIG;\n";

print PM <<BLOCK;
*entry_add = \\\&CAIDA::Tables::${class_name}_entry_add;
*entry_get = \\\&CAIDA::Tables::${class_name}_entry_get;
*read_other = \\\&CAIDA::Tables::${class_name}_read_other;
*write_other = \\\&CAIDA::Tables::${class_name}_write_other;
*add = \\\&CAIDA::Tables::${class_name}_add;
*nadd = \\\&CAIDA::Tables::${class_name}_add;
BLOCK

    foreach my $agg (@{$aggregators{$class_name}}) {
	my $result = $agg_result{$class_name}{$agg};
	if ($isa_equiv{$result}) {
	    $result = $isa_equiv{$result};
	}

print PM <<BLOCK;
sub $agg
{
    my (\$self, \$arg_hash_ref) = \@_;
    my \$size = \$arg_hash_ref->{'table_size'};
    my \$as_finder = \$arg_hash_ref->{'as_finder'};
    my \$protocol = \$arg_hash_ref->{'protocol'};
    my \@args;
    if (\$size) {
	push \@args, \$size;
    } else {
	push \@args, -1; # Default
    }
    # Can't currently give more than one option.
    if (\$as_finder) {
	push \@args, \$as_finder;
    } elsif (\$protocol) {
	# Users pass in a number, we must pass in a blessed ref.
	\$protocol = CAIDA::Tables::int_munch(\$protocol);
	push \@args, \$protocol;
    }
    require CAIDA::Tables::${result}_SWIG;
    my \$ret_val = CAIDA::Tables::${class_name}_$agg(\$self, \@args);
    return bless \$ret_val, "_p_mortal_$result";
}
BLOCK

    }

print PM <<BLOCK;

*total = \\\&CAIDA::Tables::${class_name}_total;
*other = \\\&CAIDA::Tables::${class_name}_other;
*num_entries = \\\&CAIDA::Tables::${class_name}_num_entries;
*clear = \\\&CAIDA::Tables::${class_name}_clear;

sub get_key_fields
{
    return \@{CAIDA::Tables::${class_name}_get_key_fields(\@_)};
}

sub save_text
{
    my (\$self, \$file, \@opts) = \@_;
    if (not \$file) {
	carp "save_text requires a file name or file handle to write to.";
	return undef;
    } elsif (defined fileno \$file) {
	# Do nothing, this is okay.
    } elsif (ref \$file) {
	carp "save_text requires a file name or file handle to write to.";
	return undef;
    } else {
	require IO::File;
	my \$new_handle = new IO::File ">\$file";
	if (not \$new_handle) {
	    carp "Cannot open file \$file: \$!";
	    return undef;
	}
	\$file = \$new_handle;
    }
    my \$ret_val = CAIDA::Tables::${class_name}_save_text(
						\$self, \$file, \@opts);
    return not \$ret_val; # C says 0 is good, Perl says it's bad.
}

sub load_binary
{
    my (\$self, \$file, \@opts) = \@_;
    if (not \$file) {
	carp "load_binary requires a file name or file handle to read from.";
	return undef;
    } elsif (defined fileno \$file) {
	# Do nothing, this is okay.
    } elsif (ref \$file) {
	carp "load_binary requires a file name or file handle to read from.";
	return undef;
    } else {
	require IO::File;
	my \$new_handle = new IO::File "<\$file";
	if (not \$new_handle) {
	    carp "Cannot open file \$file: \$!";
	    return undef;
	}
	\$file = \$new_handle;
    }
    my \$ret_val = CAIDA::Tables::${class_name}_load_binary(\$self, \$file, \@opts);
    return \$ret_val;
}

sub save_binary
{
    my (\$self, \$file, \@opts) = \@_;
    if (not \$file) {
	carp "save_binary requires a file name or file handle to write to.";
	return undef;
    } elsif (defined fileno \$file) {
	# Do nothing, this is okay.
    } elsif (ref \$file) {
	carp "save_binary requires a file name or file handle to write to.";
	return undef;
    } else {
	require IO::File;
	my \$new_handle = new IO::File ">\$file";
	if (not \$new_handle) {
	    carp "Cannot open file \$file: \$!";
	    return undef;
	}
	\$file = \$new_handle;
    }
    my \$ret_val = CAIDA::Tables::${class_name}_save_binary(
						\$self, \$file, \@opts);
    return not \$ret_val; # C says 0 is good, Perl says it's bad.
}

sub load_text
{
    my (\$self, \$file, \@opts) = \@_;
    if (not \$file) {
	carp "load_text requires a file name or file handle to read from.";
	return undef;
    } elsif (defined fileno \$file) {
	# Do nothing, this is okay.
    } elsif (ref \$file) {
	carp "load_text requires a file name or file handle to read from.";
	return undef;
    } else {
	require IO::File;
	my \$new_handle = new IO::File "<\$file";
	if (not \$new_handle) {
	    carp "Cannot open file \$file: \$!";
	    return undef;
	}
	\$file = \$new_handle;
    }
    my \$ret_val = CAIDA::Tables::${class_name}_load_text(\$self, \$file, \@opts);
    return \$ret_val;
}

sub data
{
    my (\$self) = \@_;
    my \$tieref = CAIDA::Tables::${class_name}_load_state(\$self);
    if (\$tieref) {
	return \$tieref;
    } else {
	my %retval;
	tie %retval, "CAIDA::Tables::${class_name}_SWIG", \$self;
	CAIDA::Tables::${class_name}_save_state(\$self, \\\%retval);
	return \\\%retval;
    }
}
BLOCK

print PM <<'BLOCK';
sub new
{
    my $self = shift;
    my @args = @_;
BLOCK

    print PM "    \$self = CAIDA::Tables::new_$class_name(\@args);\n";
    print PM "    return bless \$self, \"_p_mortal_$class_name\";\n";

print PM <<'BLOCK';
}

sub aggregate_columns ($@ ) {
# -----------------------------------------
# Creates an entirely new table with the
# related columns in it.  Aggregation is
# done by adding up previous rows which 
# now map to a single row.
# -----------------------------------------
    my ($self, @columns) = @_;
    my $args = {'force_perl' => 1};
BLOCK

    print PM "    require CAIDA::Tables::$class_name;\n";
    print PM "    my \$temptemp = new CAIDA::Tables::$class_name(",
			    "undef, \$args);\n";

print PM <<'BLOCK';
    my $result = $temptemp->aggregate_columns(@columns);
    $result->{'_num_fields'} = scalar(@columns);

    # Loop through data in object 
    while (my ($opaque_key, $value) = each %{ $self->data() }) {
	my @fields = $self->get_key_fields($opaque_key);
	$result->entry_add(@fields[@columns], $value);
    }
    return $result;
}

BLOCK

    foreach my $type (@comp_types) {

print PM <<BLOCK;
sub sort_by_$type
{
    my \$self = shift;
    my \@opts = \@_;
    \$opts[1] = 1 if \$opts[1];  # Perl->C boolean conversion

    return \@{CAIDA::Tables::${class_name}_sort_by_$type(
	    \$self, \@opts)};
}
BLOCK

    }

print PM <<BLOCK;

sub sort_by_counter_field
{
    my \$self = shift;
    my \$field = shift;

BLOCK

    foreach my $type (@comp_types[0..$#comp_types-1]) { # Don't use 'keys'

print PM <<BLOCK;
    if (\$field eq "$type") {
	return \$self->sort_by_$type(\@_);
    }
BLOCK

    }

print PM <<BLOCK;

    croak "Unknown counter field: \$field";
}

package _p_${class_name};
use vars qw(\@ISA);
\@ISA = qw(CAIDA::Tables::${class_name}_SWIG);

package _p_mortal_${class_name};
use vars qw(\@ISA);
\@ISA = qw(CAIDA::Tables::${class_name}_SWIG);

sub DESTROY
{
    my \$self = shift;
    my \$ref_diff =
	CAIDA::Tables::release_${class_name}_magic(\$self);
    CAIDA::Tables::delete_$class_name(\$self) unless \$ref_diff;
}

1; ##must be last line in the file
BLOCK
}
