#!/usr/local/bin/perl
## $Id: create_graphs.pl,v 1.32 2007/06/07 18:53:38 rkoga Exp $ $Name: release-3-8-1 $
## 
## Copyright 2004, 2005, 2007
## The Regents of the University of California 
## All Rights Reserved 
## 
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
## 
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
## 
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
## 
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
## 
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program.  Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
## 
## Report bugs and suggestions to coral-bugs@caida.org.
## 

use strict;
use warnings;

sub log_error {
    print STDERR "$0: ", @_;
}

my $coral_dir;
BEGIN { $coral_dir = "/usr/local/Coral"; } # This will be edited during build.
my $gd_dir;
BEGIN { $gd_dir = "/usr/local/lib"; } # This will be edited during build.
my $chartgraph_dir;
BEGIN { $chartgraph_dir = "/usr/local/lib"; } # This will be edited during build.
my $rrd_dir;
BEGIN { $rrd_dir = "/usr/local/RRDtool"; } # This will be edited during build.
use lib "$coral_dir/lib"; #coral global libdir#
use lib "../../../lib"; #coral local libdir#
use lib "$rrd_dir/lib/perl";
use lib "$gd_dir/"; # Path to GD.pm
use lib "$chartgraph_dir/"; # Path to Chart/Graph.pm
use POSIX;
use File::Temp qw(tempfile);
use CAIDA::Countries;
use CAIDA::Traffic2::ReportSupport;

use vars qw($RRD_ok $GD_ok $ChartGraph_ok);
BEGIN {
$RRD_ok = 0;
$GD_ok = 0;
$ChartGraph_ok = 0;
eval 'require RRDs; import RRDs';
$RRD_ok = 1 if $@ eq '';
unless ($RRD_ok) {
    log_error("RRDtool not loaded, cannot use RRD files.\nReason: $@\n");
}

eval 'require GD; import GD';
$GD_ok = 1 if $@ eq '';
unless ($GD_ok) {
    log_error("GD not loaded, cannot create maps or pie charts.\nReason: $@\n");
} else {
    require GD::Graph::pie; import GD::Graph::pie;
    require GD::Graph::colour; import GD::Graph::colour;
    require GD::Text; import GD::Text;
}

eval 'require Chart::Graph; import Chart::Graph qw(gnuplot)';
$ChartGraph_ok = 1 if $@ eq '';
unless ($ChartGraph_ok) {
    log_error("Chart::Graph not loaded, cannot create histograms or CDFs.\n"
		. "Reason: $@\n");
}
}

# Constants
my $graph_pat = '^\s*graph\s*{';
my $shared_pat = '^\s*shared\s*{';
my ($KNOWN_SET, $RECENT_TOP, $JOINT_TOP, $SPECIFIC_TOP, $SEPARATE_TOP)=(1 .. 5);

# Global config vars;
my %graph_config;
my %shared_config;


my %g_cons_funcs = (
	'AVERAGE' => 'avg',
	'MAX' => 'max',
	'MIN' => 'min',
);

parse_config(\*STDIN, {$graph_pat => \%graph_config,
			$shared_pat => \%shared_config});

my $countries = new CAIDA::Countries;

# XXX Should colors for RRDs be defined globally or per-graph?
my (%key_colors, %long_names);
%key_colors = %{$shared_config{'colors'}} if $shared_config{'colors'};
%long_names = %{$shared_config{'long_names'}} if $shared_config{'long_names'};
my %used_colors; # XXX Global reverse mapping, kinda hacky
foreach my $graph_name (get_config_keys(\%graph_config)) {
    my $graph_stanza = $graph_config{$graph_name};
    my @time_intervals = get_config_list($graph_stanza, 'intervals');
    my @def_colors = get_config_list($graph_stanza, 'def_colors');
    my $style = get_config_var($graph_stanza, 'style');
    my $format = get_config_var($graph_stanza, 'format');

    my $graph_dir = get_config_var($graph_stanza, 'dir');
    my $monitor = get_config_var($graph_stanza, 'monitor');
    # XXX Check return values.
    unless (-d "$graph_dir") {
	mkdir("$graph_dir", 0755);
    }
    unless (-d "$graph_dir/$monitor") {
	mkdir("$graph_dir/$monitor", 0755);
    }

    my $max_rrds = get_config_var($graph_stanza, 'max_rrds');
    if ($format eq 'rrd' and $RRD_ok) {
	my @units = get_config_list($graph_stanza, 'counters');
	if ($style eq 'table') { # Special case, shows all counters.
	    foreach my $unit (@units) {
		my $rrdlist_obj = parse_rrd_top_n(\@time_intervals, $unit,
						    $graph_stanza);
		foreach my $interval (@time_intervals) {
		    my @rrd_names = get_rrdlist($rrdlist_obj, $interval);
		    generate_table($graph_stanza, $unit, $interval, \@rrd_names,
				    \@units);
		}
	    }
	    next;
	}
	foreach my $unit (@units) {
	    my $rrdlist_obj = parse_rrd_top_n(\@time_intervals, $unit,
						$graph_stanza);
	    foreach my $interval (@time_intervals) {
		my @rrd_names = get_rrdlist($rrdlist_obj, $interval);
		my @new_colors = CreateColors(scalar(@rrd_names));
		unshift @new_colors, @def_colors;

		if (defined $max_rrds and @rrd_names > $max_rrds) {
		    @new_colors = @new_colors[0 .. $max_rrds-1];
		    @rrd_names = @rrd_names[0 .. $max_rrds-1];
		}

		if ($style eq 'timeseries') {
		    generate_timeseries($graph_stanza, $unit, $interval,
				    \@new_colors, \@rrd_names);
		} elsif ($style eq 'pie' and $GD_ok) {
		    generate_pie_graph($graph_stanza, $unit, $interval,
				    \@new_colors, \@rrd_names);
		} elsif ($style eq 'histogram' and $ChartGraph_ok) {
		    generate_histogram($graph_stanza, $unit, $interval,
					\@rrd_names);
		} elsif ($style eq 'cdf' and $ChartGraph_ok) {
		    generate_cdf($graph_stanza, $unit, $interval, \@rrd_names);
		} elsif ($style eq 'map' and $GD_ok) {
		    generate_map($graph_stanza, $unit, $interval, \@rrd_names);
		} else {
		    # XXX Error of some sort.
		}
	    }
	}
    } elsif ($format eq 'raw') {
	if ($style eq 'pie' and $GD_ok) {
	    my @new_colors = CreateColors(100); # XXX HACK
	    unshift @new_colors, @def_colors;
	    generate_pie_graph($graph_stanza, undef, undef, \@new_colors);
	} elsif ($style eq 'histogram' and $ChartGraph_ok) {
	    generate_histogram($graph_stanza);
	} elsif ($style eq 'cdf' and $ChartGraph_ok) {
	    generate_cdf($graph_stanza);
	} elsif ($style eq 'map' and $GD_ok) {
	    generate_map($graph_stanza);
	} else {
	    # XXX Error of some sort.
	}
    } else {
	# XXX Error of some sort.
    }
}

# Automatically converts to mega-, kilo-, or milli- as the case warrants.
sub scale_val {
    my ($val, $precision) = @_;
    my $suffix = ' ';
    if ($val > 1e6) {
	$val /= 1e6;
	$suffix = 'M';
    } elsif ($val > 1e3) {
	$val /= 1e3;
	$suffix = 'k';
    } elsif ($val < 1e-3) {
	$val /= 1e-3;
	$suffix = 'm';
    }
    $val = sprintf("%.${precision}f", $val) if $precision;
    if ($val == 0) {
	$suffix = ' ';
    }
    return ($val, $suffix);
}

# Assumes existence of file
sub get_img_size($) {
    my $fname = shift;
    my $pnmhdr = `anytopnm "$fname" 2>&- | head -2`;
    if ($pnmhdr =~ /^P[56]\s+(\d+)\s+(\d+)\s+/m) {
	return ($1, $2);
    }
    die "Unknown image header '$pnmhdr' from decoder for file '$fname'";
}

sub CreateColors {
    my ($number) = @_;
    my @colors;
    foreach my $index (0 .. ($number-1)) {
        my $hue = (360*$index)/$number;
        my $saturation = 1;
        my $value = 255;
        my ($red, $green, $blue) = (rand(155)+100, rand(155)+100, rand(155)+100);
	my $new_color = "#" . sprintf("%.2X%.2X%.2X", $red, $green, $blue);
	push @colors, $new_color;
    }
    return @colors;
}

sub HSVtoRGB {
    my ($hue, $saturation, $brightness) = @_;

    while ($hue < 0) {
        $hue += 360;
    }
    $hue %= 360;

    my ($red, $green, $blue);
    if ($saturation == 0) { # grey
        $red = $green = $blue = $brightness;
        return ($red, $green, $blue);
    }

    my $sector_frac = $hue / 60;
    my $sector = POSIX::floor($sector_frac);
    my $fraction = $sector_frac - $sector; # fractional part of sector
    my $p = $brightness * ( 1 - $saturation );
    my $q = $brightness * ( 1 - $saturation * $fraction );
    my $t = $brightness * ( 1 - $saturation * ( 1 - $fraction ) );


    if ($sector == 0) {
        $red = $brightness;
        $green = $t;
        $blue = $p;
    } elsif ($sector == 1) {
        $red = $q;
        $green = $brightness;
        $blue = $p;
    } elsif ($sector == 2) {
        $red = $p;
        $green = $brightness;
        $blue = $t;
    } elsif ($sector == 3) {
        $red = $p;
        $green = $q;
        $blue = $brightness;
    } elsif ($sector == 4) {
        $red = $t;
        $green = $p;
        $blue = $brightness;
    } else { # $sector == 5
        $red = $brightness;
        $green = $p;
        $blue = $q;
    }
    return ($red, $green, $blue);
}

sub extract_rrd_value {
    my ($file, $unit, $def_func, $agg_func, $timeframe, $endtime) = @_;

    die "$file not found" unless -f $file;
    my $def = "DEF:orig_val=$file:$unit:$def_func";
    my $calc_def;
    # To get average, better to treat undef as 0, but not for max and
    # especially not for min.
    if ($def_func eq 'AVERAGE') {
	$calc_def = "CDEF:new_val=orig_val,UN,0,orig_val,IF";
    } else {
	$calc_def = "CDEF:new_val=orig_val";
    }
    my ($results) = RRDs::graph("", "--start=end-$timeframe", "--end=$endtime",
			$def, $calc_def, "PRINT:new_val:$agg_func:%lf");
    my $error = RRDs::error();
    if ($error) {
	log_error("Got error: $error\n");
	exit;
    }
    my $value = $results->[0];
    if ($value < 0) {
	log_error("Warning: Negative value $value from RRD $file\n");
    }
    $value = 0 if $value eq 'NaN';
    return $value;
}

sub generate_timeseries {
    my ($stanza_ref, $unit, $interval, $colors_ref, $names_ref) = @_;
    my @graph_colors = @$colors_ref;
    my @rrd_names = @$names_ref if defined $names_ref;

    my $rrd_store_dir = get_config_var($stanza_ref, 'rrd_dir');
    my $monitor = get_config_var($stanza_ref, 'monitor');
    my $category = get_config_var($stanza_ref, 'category');
    my $graph_dir = get_config_var($stanza_ref, 'dir');
    my $type = get_config_var($stanza_ref, 'type');
    my $graph_func = get_config_var($stanza_ref, 'graph_func');
    my $endtime = get_config_var($stanza_ref, 'endtime');
    my $width = get_config_var($stanza_ref, 'width');
    my $height = get_config_var($stanza_ref, 'height');
    my $use_other = get_config_var($stanza_ref, 'use_other');
    my $use_perc = get_config_var($stanza_ref, 'use_perc');
    my $watermark = get_config_var($stanza_ref, 'watermark');
    my @graph_commands;

    $width = 400 unless $width;
    $height = 400 unless $height;

    $endtime = time if $endtime eq 'now';

    (my $base_cat = $category) =~ s/(src|dst)_//g;
    if ($use_perc) {
	push @graph_commands, '--upper-limit', 100, '--rigid';
    }

    my %name_map;
    my $incrementer = 0;
    unshift @rrd_names, 'total';
    foreach my $rrd (@rrd_names) {
	$name_map{$rrd} = $incrementer++;
	$used_colors{$base_cat}{$key_colors{$rrd}}++ if exists $key_colors{$rrd};
	while (my ($func, $func_name) = each %g_cons_funcs) {
	    my $var;
	    if ($rrd eq 'total') {
		$var = $func_name . 'total';
		push(@graph_commands,
		    "DEF:P$var=$rrd_store_dir/$monitor/total.rrd:$unit:$func");
	    } else {
		$var = $func_name . $name_map{$rrd};
		push(@graph_commands,
		    "DEF:P$var=$rrd_store_dir/$monitor/$category/$rrd.rrd:" .
		    "$unit:$func");
	    }
	    my $cdef = "CDEF:C$var=P$var";
	    if ($use_perc and $rrd ne 'total') {
		$cdef .= ",C${func_name}total,/,100,*";
	    }
	    push @graph_commands, $cdef;

	    # Make unknown into 0 for graphing.
	    my $cdef_z = "CDEF:CZ$var=C$var,UN,0,C$var,IF";
	    push @graph_commands, $cdef_z;
	}
    }
    # We use total in the variables, but we don't graph it.
    delete $name_map{'total'};
    shift @rrd_names;

    if ($use_other and @rrd_names) { # Don't do anything if there's no input
	#Define total traffic, Top N apps, and difference
	while (my ($func, $func_name) = each %g_cons_funcs) {
	    my $tot_var = $func_name . 'total';
	    my $subtot_var = $func_name . 'subtotal';
	    my $other_var = $func_name . 'other';
	    push @graph_commands, "CDEF:CZ$subtot_var=0,CZ$func_name" .
		  join(",+,CZ$func_name", values %name_map) .  ",+";
	    # For the GPRINT line
	    my $command = "CDEF:C$other_var=0,CZ$tot_var";
	    if ($use_perc) {
		# Magically, if total == 0, this just becomes UN, and the
		# 'other' category disappears.
		$command .= ",CZ$tot_var,/,100,*";
	    }
	    $command .= ",CZ$subtot_var,-,MAX";
	    push @graph_commands, $command;
	    # For the graph
	    push @graph_commands, "CDEF:CZ$other_var=C$other_var";
	}
	push @rrd_names, 'other';
    }

    my $starttime = $endtime - $interval*3600;
    my $date_start = strftime("%B %d %Y", localtime($starttime));
    my $date_end = strftime("%B %d %Y", localtime($endtime));
    my $date_str = $date_start;
    if ($date_start ne $date_end) {
	$date_str .= " - $date_end";
    }

# Pad number of characters in protocols.
    my $pad = length($type);
    foreach my $rrd (@rrd_names){
	my $rrd_name = $rrd;
	if (exists $long_names{$rrd}) {
	    $rrd_name .= " ($long_names{$rrd})";
	}

	if (length($rrd_name) > $pad) {
	    $pad = length($rrd_name);
	}
    }
    my $line_max;
    my $data_width = 6;
    if ($RRDs::VERSION >= 1.2) {
	# XXX Experimentally acquired numbers for rrdtool 1.2.x default font.
	$line_max = 10 + ($width/100)*14;
    } else {
	# XXX Experimentally acquired numbers for rrdtool 1.0.x font.
	$line_max = 14 + ($width/100)*16;
    }
    # 4 spaces for color box+spacing, 3 data values (+ 1 space for units)
    my $non_pad = 4 + ($data_width+1)*3;
    if ($pad + $non_pad + 1 > $line_max) {
	$pad = $line_max - $non_pad;
	$pad = 3 if $pad < 3;
    }

    my $head = $type;
    if (length($head) > $pad) {
	$head = substr($type, 0, $pad);
    }
    push @graph_commands, "COMMENT:$date_str\\c";
    push @graph_commands, "COMMENT:  $head " . (" " x ($pad - length($head)));
    push @graph_commands, 'COMMENT:Min ';
    push @graph_commands, 'COMMENT:Avg ';
    push @graph_commands, 'COMMENT:Max \j';

    my $tag = "AREA";
    my $scale = $use_perc ? '%%' : '%s';
    foreach my $rrd (@rrd_names){
	my $color;
	if (exists $key_colors{$rrd}) {
	    $color = $key_colors{$rrd};
	} elsif ($rrd eq 'other') {
	    $color = '#000000';
	} else {
	    $color = shift @graph_colors;
	    while (exists $used_colors{$base_cat}{$color}) {
		push @graph_colors, CreateColors(1);
		$color = shift @graph_colors;
	    }
	    $key_colors{$rrd} = $color;
	    $used_colors{$base_cat}{$color}++;
	}
	my $rrd_name = $rrd;
	if (exists $long_names{$rrd}) {
	    $rrd_name .= " ($long_names{$rrd})";
	}
	if (length($rrd_name) > $pad) {
	    $rrd_name = substr($rrd_name, 0, $pad);
	}
	my $num;
	if (exists $name_map{$rrd}) { # Deal with 'other'
	    $num = $name_map{$rrd};
	} else {
	    $num = $rrd;
	}
	my $func_name = $g_cons_funcs{$graph_func};
	my $padded_name = $rrd_name . (" " x ($pad - length($rrd_name)));
	push @graph_commands, "$tag:CZ$func_name$num$color:$padded_name";
	push @graph_commands,
		    "GPRINT:C$func_name$num:MIN:\%$data_width.2lf$scale";
	push @graph_commands,
		    "GPRINT:CZ$func_name$num:AVERAGE:\%$data_width.2lf$scale";
	push @graph_commands,
		    "GPRINT:C$func_name$num:MAX:\%$data_width.2lf$scale\\j";

	$tag = "STACK";
    }
    my $time = strftime("%c %Z", localtime);
    if ($RRDs::VERSION >= 1.2) {
	$time =~ s/:/\\:/g;
    }
    push @graph_commands, "COMMENT:\\s";
    push @graph_commands, "COMMENT:generated $time\\c";

    my $label = $unit;
    $label .= "/s";
    if ($use_perc) {
	$label = "% of $label";
    }
    my $title = "$type $label - ";
    if ($interval < 24) {
	$title .= "$interval hour" . ($interval == 1 ? "" : "s");
    } elsif ($interval < 7*24) {
	my $unit_count = sprintf("%.5g", $interval / 24);
	$title .= "$unit_count day" . ($unit_count == 1 ? "" : "s");
    } elsif ($interval < 365*24) {
	my $unit_count = sprintf("%.5g", $interval / (24*7));
	$title .= "$unit_count week" . ($unit_count == 1 ? "" : "s");
    } else {
	my $unit_count = sprintf("%.5g", $interval / (24*365));
	$title .= "$unit_count year" . ($unit_count == 1 ? "" : "s");
    }

    my @info_list = ('ts');
    if ($use_perc) {
	push @info_list, "perc";
    }
    push @info_list, $category, $unit, $graph_func, $interval;
    my $filename = "$graph_dir/$monitor/" .  join('_', @info_list) .  '.png';
    my @opts = ("--title", $title,
		"--width", $width,
		"--height", $height,
		"--vertical-label", "$label", 
		"--start" , "end-" . $interval*(3600),
		"--end", $endtime,
		"--lower-limit", 0);
    if ($RRDs::VERSION >= 1.2013 and defined $watermark) {
	push @opts, "--watermark", $watermark;
    }
    RRDs::graph("$filename", @opts, @graph_commands);
    my $error = RRDs::error();
    if ($error) {
	log_error("While generating $graph_dir/$monitor/",
		"ts_${category}_${unit}_$interval.png: $error\n");
	exit;
    }
}

sub generate_pie_graph {
    my ($stanza_ref, $unit, $interval, $colors_ref, $names_ref)
	    = @_;
    my @graph_colors = @$colors_ref;
    my @rrd_names = @$names_ref if defined $names_ref;

    my $monitor = get_config_var($stanza_ref, 'monitor');
    my $category = get_config_var($stanza_ref, 'category');
    my $graph_dir = get_config_var($stanza_ref, 'dir');
    my $type = get_config_var($stanza_ref, 'type');
    my $graph_func = get_config_var($stanza_ref, 'graph_func');
    my $width = get_config_var($stanza_ref, 'width');
    my $height = get_config_var($stanza_ref, 'height');
    my $use_other = get_config_var($stanza_ref, 'use_other');
    my $format = get_config_var($stanza_ref, 'format');

    (my $base_cat = $category) =~ s/(src|dst)_//g;

    my %records;
    my @sorted;
    my ($total, $subtotal);
    if ($format eq 'rrd') {
	my $rrd_store_dir = get_config_var($stanza_ref, 'rrd_dir');
	my $endtime = get_config_var($stanza_ref, 'endtime');
	$endtime = time if $endtime eq 'now';
	@sorted = @rrd_names;
	if ($use_other) {
	    $total = extract_rrd_value("$rrd_store_dir/$monitor/total.rrd",
		    $unit, $graph_func, $graph_func, $interval*3600, $endtime);
	}
	foreach my $rrd (@rrd_names) {
	    my $file = "$rrd_store_dir/$monitor/$category/$rrd.rrd";
	    my $count = extract_rrd_value($file, $unit, $graph_func,
					$graph_func, $interval*3600, $endtime);
	    $records{$rrd} = $count if $count > 0;  # Can't plot 0
	}
    } elsif ($format eq 'raw') {
	my $data_file = get_config_var($stanza_ref, 'data_file');
	my @names = get_config_list($stanza_ref, 'to_graph');
	open TAB_DEL_FILE, $data_file or
		    log_error("Couldn't open $data_file: $!\n") and return;
	while (<TAB_DEL_FILE>) {
	    my ($key, $count) = split /\t/;
	    $records{$key} = $count if $count;  # Can't plot 0
	    $total += $count;
	}
	close TAB_DEL_FILE;
	if ($names[0] !~ /top (\d+)/i) { # Specific keys
	    @sorted = @names;
	} else {
	    my $top_n = $1;
	    @sorted = sort {$records{$b} <=> $records{$a}} keys %records;
	    @sorted = @sorted[0 .. $top_n-1] if @sorted > $top_n;
	}
    } else {
	log_error("Unknown data format\n");
    }

    my @actual_colors;
    my @actual_keys;
    my @dummy_names;
    my @data_values;

    # Need to deal with pre-defined colors.
    foreach my $key (@sorted) {
	$used_colors{$base_cat}{$key_colors{$key}}++ if exists $key_colors{$key};
    }

    foreach my $key (@sorted) {
	next unless exists $records{$key};
	if ($records{$key} < 0) {
	    log_error("Cannot plot negative value on pie graph, skipping.\n");
	    next;
	}
	my $color;
	if (exists $key_colors{$key}) {
	    $color = $key_colors{$key};
	} else {
	    $color = shift @graph_colors;
	    (my $new_category = $category) =~ s/(src|dst)_//g;
	    while (exists $used_colors{$base_cat}{$color}) {
		push @graph_colors, CreateColors(1);
		$color = shift @graph_colors;
	    }
	    $key_colors{$key} = $color;
	    $used_colors{$base_cat}{$color}++;
	}
	push @actual_colors, $color;
	push @actual_keys, $key;
	push @dummy_names, '';
	push @data_values, $records{$key};
	$subtotal += $records{$key};
    }

    # Weirdly enough, sometimes the subtotal is higher than the total.
    # Can't really explain except for RRDtool averaging, or rounding
    # errors.
    if (not @data_values) { # Deal with absent data
	push @actual_colors, "#000000";
	push @actual_keys, 'NO DATA';
	push @dummy_names, '';
	push @data_values, 1;
    } elsif ($use_other) {
	my $other = $total-$subtotal;
	$other = 0 if $other < 0;
	push @actual_colors, "#000000";
	push @actual_keys, 'other';
	push @dummy_names, '';
	push @data_values, $other;
    }

    my $graph = new GD::Graph::pie($width, $height);
    $graph->set( 
		 'start_angle' => 90,
		 '3d' => 0,
		 'transparent' => 1,
		 'l_margin' => 5,
		 'r_margin' => 5,
		 't_margin' => 5,
		 'b_margin' => 5,
		 'show_values' => 0,
		 'dclrs' => \@actual_colors,
		);
    my @info_list = ('pie', $category);
    if ($format eq 'rrd') {
	push @info_list, $unit, $graph_func, $interval;
    }
    my $filename = "$graph_dir/$monitor/" .  join('_', @info_list) .  '.png';
    open IMG, ">$filename" or die "Can't create image file $filename";
    my $plot = $graph->plot([\@dummy_names, \@data_values]);
    if (defined $plot) {
	print IMG $plot->png;
    } else {
	log_error("Error creating pie graph: " . $graph->error() . "\n");
    }
    close IMG;

    # Need to print out key->color list, since graph has no legend.
    $filename = "$graph_dir/$monitor/" .  join('_', @info_list) .  '.txt';
    open DATA, ">$filename" or die "Can't create data file $filename";
    for (my $i = 0; $i <= $#actual_keys; $i++) {
	my $key = $actual_keys[$i];
	if (exists $long_names{$key}) {
	    $key = $long_names{$key};
	}
	print DATA "$key\t$actual_colors[$i]\n";
    }
    close DATA;
}

sub generate_hist_or_cdf {
    my ($hist_or_cdf, $stanza_ref, $unit, $interval, $names_ref) = @_;
    my @rrd_names = @$names_ref if defined $names_ref;

    my $rrd_store_dir = get_config_var($stanza_ref, 'rrd_dir');
    my $monitor = get_config_var($stanza_ref, 'monitor');
    my $category = get_config_var($stanza_ref, 'category');
    my $graph_dir = get_config_var($stanza_ref, 'dir');
    my $type = get_config_var($stanza_ref, 'type');
    my $graph_func = get_config_var($stanza_ref, 'graph_func');
    my $width = get_config_var($stanza_ref, 'width');
    my $height = get_config_var($stanza_ref, 'height');
    my $format = get_config_var($stanza_ref, 'format');
    my $buck_size = get_config_var($stanza_ref, 'buck_size');
    my $num_buckets = get_config_var($stanza_ref, 'num_buckets');
    $num_buckets = 10 if not defined $num_buckets;

    my $style;
    if ($hist_or_cdf eq 'histogram') {
	$style = 'boxes';
    } elsif ($hist_or_cdf eq 'cdf') {
	$style = 'lines';
    } else {
	log_error("Invalid specification of hist or cdf.\n");
	exit 10;
    }

    my %records;
    my @key_list;
    if ($format eq 'rrd') {
	my $rrd_store_dir = get_config_var($stanza_ref, 'rrd_dir');
	my $endtime = get_config_var($stanza_ref, 'endtime');
	$endtime = time if $endtime eq 'now';
	@key_list = @rrd_names;
	foreach my $rrd (@rrd_names) {
	    my $file = "$rrd_store_dir/$monitor/$category/$rrd.rrd";
	    my (undef, undef, $names, $data) = RRDs::fetch($file, $graph_func,
			    "--start=end-". $interval*3600, "--end=$endtime");
	    my $error = RRDs::error();
	    if ($error) {
		log_error("Got error: $error\n");
		exit;
	    }
	    my $data_pos;
	    for ($data_pos = 0; $data_pos < $#$names; $data_pos++) {
		last if $names->[$data_pos] eq $unit;
	    }
	    if ($data_pos == $#$names) {
		log_error("Couldn't find data for $hist_or_cdf\n");
		exit;
	    }
	    foreach my $line (@$data) {
		my $count = $line->[$data_pos];
		next unless defined $count;
		push @{$records{$rrd}}, $count;
	    }
	}
    } elsif ($format eq 'raw') {
	my $data_file = get_config_var($stanza_ref, 'data_file');
	my @names = get_config_list($stanza_ref, 'to_graph');
	open TAB_DEL_FILE, $data_file or
		    log_error("Couldn't open $data_file: $!\n") and return;
	while (<TAB_DEL_FILE>) {
	    chomp;
	    my ($key, $count) = split /\t/;
	    push @{$records{$key}}, $count;
	}
	close TAB_DEL_FILE;
	if ($names[0] !~ /top (\d+)/i) { # Specific keys
	    @key_list = @names;
	} else {
	    my $top_n = $1;
	    @key_list = keys %records;
	    @key_list = @key_list[0 .. $top_n-1] if @key_list > $top_n;
	}
    } else {
	log_error("Unknown data format\n");
    }

    foreach my $key (@key_list) {
	next unless exists $records{$key};
	
	my %freq_table;
	my $total_counts;
	my @matrix;
	my @count_data = @{$records{$key}};

	if ($hist_or_cdf eq 'histogram' and not defined $buck_size) {
	    # Autocalculate bucket size
	    @count_data = sort {$a <=> $b} @count_data;
	    my $min = $count_data[0];
	    my $max = $count_data[$#count_data];
	    $buck_size = POSIX::floor(($max - $min) / $num_buckets);
	    $buck_size = 1 unless $buck_size > 0;
	    $buck_size = substr($buck_size, 0, 1) . '0'x(length($buck_size)-1);
	}

	foreach my $count (@count_data) {
	    if ($hist_or_cdf eq 'histogram') {
		# Get both sides of bucket instead of just greater than.
		$count += $buck_size/2;
		$count = POSIX::floor($count/$buck_size)*$buck_size;
	    }
	    $freq_table{$count}++;
	    $total_counts++;
	}

	next unless defined $total_counts;

	my $accumulator;
	foreach my $x (sort {$a <=> $b} keys %freq_table) {
	    if ($hist_or_cdf eq 'histogram') {
		push @matrix, [$x, $freq_table{$x}/$total_counts*100];
	    } elsif ($hist_or_cdf eq 'cdf') {
		$accumulator += $freq_table{$x};
		push @matrix, [$x, $accumulator/$total_counts*100];
	    }
	}

	my $label;
	if ($format eq 'rrd') {
	    $label = "$unit/s";
	}
	$label = "data" unless defined $label;

	my $graph_type = $hist_or_cdf;
	$graph_type =~ s/ogram//;
	my @info_list = ($graph_type, $category, $key);
	my $extra_opts = 'set nokey';
	if ($format eq 'rrd') {
	    push @info_list, $unit, $graph_func, $interval;
	}
	if ($hist_or_cdf eq 'histogram') {
	    $extra_opts .= "\nset boxwidth $buck_size";
	}
	my $filename = "$graph_dir/$monitor/" .  join('_', @info_list) .  '.png';
	my %global_opts = (
	    "title" => "$label $hist_or_cdf for $key",
	    "output type" => 'png',
	    "output file" => "$filename",
	    "x-axis label" => "$label",
	    "y-axis label" => "percent of total",
	    "xrange" => "[0:*]",
	    "extra_opts" => $extra_opts,
	);
	if (defined $width and defined $height) {
	    # XXX Assumes that default gnuplot png output is 640x480
	    my $x_scale = $width/640;
	    my $y_scale = $height/480;
	    $global_opts{"size"} = [$x_scale, $y_scale];
	}

	gnuplot(
	    \%global_opts,
	    [
		{
		    "type" => "matrix",
		    "style" => $style,
		    "title" => "percentage",
		}, \@matrix,
	    ]
	);
    }
}

sub generate_histogram {
    return generate_hist_or_cdf('histogram', @_);
}

sub generate_cdf {
    return generate_hist_or_cdf('cdf', @_);
}

sub generate_map { # Only works with 2- or 3-letter country code RRDs.
    my ($stanza_ref, $unit, $interval, $names_ref) = @_;
    my @rrd_names = @$names_ref if defined $names_ref;

    my $rrd_store_dir = get_config_var($stanza_ref, 'rrd_dir');
    my $monitor = get_config_var($stanza_ref, 'monitor');
    my $category = get_config_var($stanza_ref, 'category');
    my $graph_dir = get_config_var($stanza_ref, 'dir');
    my $type = get_config_var($stanza_ref, 'type');
    my $graph_func = get_config_var($stanza_ref, 'graph_func');
    my $endtime = get_config_var($stanza_ref, 'endtime');
    my $width = get_config_var($stanza_ref, 'width');
    my $height = get_config_var($stanza_ref, 'height');
    my $color = get_config_var($stanza_ref, 'circle_color');
    my $source_map = get_config_var($stanza_ref, 'map');
    my $left_str1 = get_config_var($stanza_ref, 'left_str1');
    my $left_str2 = get_config_var($stanza_ref, 'left_str2');
    my $right_str1 = get_config_var($stanza_ref, 'right_str1');
    my $right_str2 = get_config_var($stanza_ref, 'right_str2');
    my $diam_scale = get_config_var($stanza_ref, 'diam_scale');
    my $max_diam = get_config_var($stanza_ref, 'max_diam');
    my $font = get_config_var($stanza_ref, 'font');
    my $pll_path = get_config_var($stanza_ref, 'pll_path');
    my $pll_data = get_config_var($stanza_ref, 'pll_data');
    my $pll_type = get_config_var($stanza_ref, 'pll_type');
    my $format = get_config_var($stanza_ref, 'format');
    my $data_file = get_config_var($stanza_ref, 'data_file');

    my @color_parts = (0,0,0);
    if (defined $color) {
	# Color is defined as #RRGGBB
	@color_parts = (hex(substr($color,1,2)), hex(substr($color,3,2)),
			hex(substr($color,5,2)));
    }

    $endtime = time if $endtime eq 'now';

    my @data;
    my $max_size = 0; # For autoscaling
    my ($handle, $latlon_file) = tempfile(); # lat/lon -> x/y mapping tempfile
    my $pll_cmd = "$pll_path -c -m $pll_type";
    $pll_cmd .= " -i $pll_data" if defined $pll_data;
    open LATLONXY, "| $pll_cmd > /dev/null 2>$latlon_file";
    if ($format eq 'rrd') {
	foreach my $rrd (@rrd_names) {
	    my $iso2;
	    if (length($rrd) == 2) {
		$iso2 = lc($rrd);
	    } elsif (length($rrd) == 3) {
		$iso2 = $countries->get_iso2code_by_iso3code(lc($rrd));
	    } else {
		next;
	    }
	    next unless defined $iso2;
	    my $latlon_str = $countries->get_latlon_by_iso2code($iso2);
	    next unless defined $latlon_str;
	    my ($lat, $lon) = split /,/, $latlon_str;
	    next unless $lat and $lon; # 0,0 is unknown
	    my $file = "$rrd_store_dir/$monitor/$category/$rrd.rrd";
	    my $count = extract_rrd_value($file, $unit, $graph_func,
					$graph_func, $interval*3600, $endtime);
	    next if $count == 0;
	    $max_size = $count if $count > $max_size;
	    push @data, [$lat, $lon, $count];
	    print LATLONXY "$lat $lon\n";
	}
    } elsif ($format eq 'raw') {
	open TAB_DEL_FILE, $data_file or
		    log_error("Couldn't open $data_file: $!\n") and return;
	while (<TAB_DEL_FILE>) {
	    my ($key, $count) = split /\t/;
	    my ($lat, $lon) = split ',', $key;
	    next unless $lat and $lon; # 0,0 is unknown
	    $max_size = $count if $count > $max_size;
	    push @data, [$lat, $lon, $count];
	    print LATLONXY "$lat $lon\n";
	}
    } else {
	log_error("Unknown data format\n");
    }
    close LATLONXY;
    my %ll_to_xy;
    while (<$handle>) {
	my ($other_lat, $other_lon, $x, $y) = split;
	$ll_to_xy{"$other_lat,$other_lon"} = [$x, $y];
    }
    close $handle;
    unlink $latlon_file;
    my @info_list = ('map', $category);
    if ($format eq 'rrd') {
	push @info_list, $unit, $graph_func, $interval;
    }
    my $graph_file = "$graph_dir/$monitor/" .  join('_', @info_list) . '.png';
    my ($MapXPix, $MapYPix) = ($width, $height); # Only used for no source
    if (defined $source_map and -e $source_map) {
	($MapXPix, $MapYPix) = get_img_size($source_map);
    } else {
	undef $source_map;
    }

    my $image;
    if (defined($source_map)) {
	$image = GD::Image->newFromPng($source_map);
    } else {
	$image = new GD::Image($MapXPix, $MapYPix);
	$image->colorAllocate(255,255,255); # background
    }
    my $draw_color = $image->colorAllocate(@color_parts); 
    my $black = $image->colorAllocate(0,0,0); 

    $max_diam = $MapXPix / 20 if not defined $max_diam;
    $diam_scale = $max_diam/log(1 + $max_size)
			if not defined $diam_scale and $max_size > 0;
    my $BigVersion = 0;
    my $font_obj;
    my $pix_scale;
    if (not defined $font) {
	if ($MapXPix > 540) {
	    $font = 'giant';
	} else {
	    $font = 'small';
	}
    }
    if ($font eq 'giant') {
	$font_obj = gdGiantFont();
    } elsif ($font eq 'large') {
	$font_obj = gdLargeFont();
    } elsif ($font eq 'medium') {
	$font_obj = gdMediumBoldFont();
    } elsif ($font eq 'small') {
	$font_obj = gdSmallFont();
    } elsif ($font eq 'tiny') {
	$font_obj = gdTinyFont();
    } else {
	log_error("Invalid font specification\n");
	exit 20;
    }
    foreach my $rec (@data) {
	my ($lat, $lon, $count) = @$rec;
	next if ($lat eq 'X' and $lon eq 'X') or ($lat == 0 and $lon == 0)
		or ($lat == 360 and $lon == 360) or $count == 0;
	my $xy_ref = $ll_to_xy{"$lat,$lon"};
	unless (defined $xy_ref) {
	    log_error("Could not convert coordinates $lat/$lon into " .
			"pixel locations, skipping.\n");
	    next;
	}
	my ($x, $y) = @$xy_ref;
	next unless defined $x;
	my $diam = $diam_scale * (1 + log($count));
	if ($diam < 1) {
	    $diam = 1;
	}
	$image->filledArc($x, $y, $diam, $diam, 0, 360, $draw_color);
    }

    my ($text_x, $text_y);
    my $gd_text = new GD::Text;
    $gd_text->set_font($font_obj);
    my $border = POSIX::floor(0.01 * $MapXPix);

    if (defined $left_str1) {
	$text_x = $border;
	$text_y = $MapYPix - 2*$gd_text->get('height') - $border;
	$image->string($font_obj, $text_x, $text_y, $left_str1, $black);
    }

    if (defined $left_str2) {
	$text_x = $border;
	$text_y = $MapYPix - $gd_text->get('height') - $border;
	$image->string($font_obj, $text_x, $text_y, $left_str2, $black);
    }

    if (defined $right_str1) {
	$gd_text->set_text($right_str1);
	$text_x = $MapXPix - $gd_text->get('width') - $border;
	$text_y = $MapYPix - 2*$gd_text->get('height') - $border;
	$image->string($font_obj, $text_x, $text_y, $right_str1, $black);
    }

    if (defined $right_str2) {
	$gd_text->set_text($right_str2);
	$text_x = $MapXPix - $gd_text->get('width') - $border;
	$text_y = $MapYPix - $gd_text->get('height') - $border;
	$image->string($font_obj, $text_x, $text_y, $right_str2, $black);
    }

    open OUTPUT, ">$graph_file" or die "Couldn't open output file: $!";
    print OUTPUT $image->png;
    close OUTPUT;

}

sub generate_table {
    my ($stanza_ref, $sort_unit, $interval, $names_ref, $units_ref) = @_;
    my @rrd_names = @$names_ref if defined $names_ref;
    my @units = @$units_ref;

    my $monitor = get_config_var($stanza_ref, 'monitor');
    my $category = get_config_var($stanza_ref, 'category');
    my $table_dir = get_config_var($stanza_ref, 'dir');
    my $type = get_config_var($stanza_ref, 'type');
    my $graph_func = get_config_var($stanza_ref, 'graph_func');
    my $width = get_config_var($stanza_ref, 'width');
    my $height = get_config_var($stanza_ref, 'height');
    my $format = get_config_var($stanza_ref, 'format');
    my $use_other = get_config_var($stanza_ref, 'use_other');

    my %records;
    my @sorted;
    my (%total, %subtotal);
    if ($format eq 'rrd') {
	my $rrd_store_dir = get_config_var($stanza_ref, 'rrd_dir');
	my $endtime = get_config_var($stanza_ref, 'endtime');
	$endtime = time if $endtime eq 'now';
	@sorted = @rrd_names;
	foreach my $unit (@units) {
	    $total{$unit} = extract_rrd_value(
			    "$rrd_store_dir/$monitor/total.rrd",
			    $unit, $graph_func, $graph_func, $interval*3600,
			    $endtime);
	}
	foreach my $rrd (@sorted) {
	    foreach my $unit (@units) {
		my $file = "$rrd_store_dir/$monitor/$category/$rrd.rrd";
		my $count = extract_rrd_value($file, $unit, $graph_func,
					$graph_func, $interval*3600, $endtime);
		# Done in this order to decrease hash memory usage
		$records{$unit}{$rrd} += $count;
		$subtotal{$unit} += $count;
	    }
	}
=pod
# XXX Untested zone
    } elsif ($format eq 'raw') {
	my $data_file = get_config_var($stanza_ref, 'data_file');
	my @names = get_config_list($stanza_ref, 'to_graph');
	open TAB_DEL_FILE, $data_file or
		    log_error("Couldn't open $data_file: $!\n") and return;
	while (<TAB_DEL_FILE>) {
	    my ($key, $count) = split /\t/;
	    $records{$key} += $count;
	    $total += $count;
	}
	close TAB_DEL_FILE;
	if ($names[0] !~ /top (\d+)/i) { # Specific keys
	    @sorted = @names;
	} else {
	    my $top_n = $1;
	    @sorted = sort {$records{$b} <=> $records{$a}} keys %records;
	    @sorted = @sorted[0 .. $top_n-1] if @sorted > $top_n;
	}
    } else {
	log_error("Unknown data format\n");
=cut
    }

    my @info_list = ('table', $category);
    if ($format eq 'rrd') {
	push @info_list, $sort_unit, $graph_func, $interval;
    }
    my $filename = "$table_dir/$monitor/" .  join('_', @info_list) .  '.txt';
    open DATA, ">$filename" or die "Can't create data file $filename";
    print DATA "$type";
    foreach my $unit (@units) {
	print DATA "\t$unit/s\t% $unit/s";
    }
    print DATA "\n";

    foreach my $key (@sorted) {
	next unless exists $records{$sort_unit}{$key};
	my $long_name = "";
	if (exists $long_names{$key}) {
	    $long_name = " ($long_names{$key})";
	}
	print DATA "$key$long_name";
	foreach my $unit (@units) {
	    unless (defined $records{$unit}{$key}) {
		log_error("Unknown value for $unit and $key\n");
	    }
	    my ($value, $suffix) = scale_val($records{$unit}{$key}, 3);
	    my $perc;
	    if ($total{$unit} > 0) {
		$perc = $records{$unit}{$key}/$total{$unit}*100;
	    } else {
		$perc = 0;
	    }
	    printf DATA "\t%.3f$suffix\t%.2f", $value, $perc;
	}
	print DATA "\n";
    }
    if ($use_other and @sorted) {
	print DATA "other";
	foreach my $unit (@units) {
	    my $other = $total{$unit} - $subtotal{$unit};
	    $other = 0 if $other < 0;
	    my ($value, $suffix) = scale_val($other, 3);
	    my $perc;
	    if ($total{$unit} > 0) {
		$perc = $other/$total{$unit}*100;
	    } else {
		$perc = 0;
	    }
	    printf DATA "\t%.3f$suffix\t%.2f", $value, $perc;
	}
	print DATA "\n";
    }
    close DATA;
}

my %list_cache;

sub parse_rrd_top_n {
    my ($intervalref, $unit, $stanza_ref) = @_;

    my @names = get_config_list($stanza_ref, 'to_graph');
    my $rrd_store_dir = get_config_var($stanza_ref, 'rrd_dir');
    my $monitor = get_config_var($stanza_ref, 'monitor');
    my $category = get_config_var($stanza_ref, 'category');
    my $endtime = get_config_var($stanza_ref, 'endtime');
    my $directory = "$rrd_store_dir/$monitor/$category";
    my @intervals = @$intervalref;
    my %rrdlists;

    my @files = glob "$directory/*.rrd";
    warn "No RRD data in $directory!" if @files == 0;
    if ($names[0] !~ /top (\d+)/i) { # Simple case of specified RRDs.
	$rrdlists{'sort_type'} = $KNOWN_SET;
	$rrdlists{'known'} = \@names;
	return \%rrdlists;
    }
    my $id_str = join(',', @names) . ":$unit:$category:$monitor:" .
		    join(',', @intervals);
    return $list_cache{$id_str} if exists $list_cache{$id_str};

    my $top_n = $1;
    my $sort_str = $names[1];
    if ($sort_str =~ /recent/) {
	$rrdlists{'sort_type'} = $RECENT_TOP;
	@intervals = ('recent');
    } elsif ($sort_str =~ /area (\d+)/) {
	$rrdlists{'sort_type'} = $SPECIFIC_TOP;
	$rrdlists{'sort_interval'} = $1;
	@intervals = ($1);
    } elsif ($sort_str =~ /separate_area/) {
	$rrdlists{'sort_type'} = $SEPARATE_TOP;
    } elsif ($sort_str =~ /joint_area/) {
	$rrdlists{'sort_type'} = $JOINT_TOP;
    } else {
	log_error("Error of some sort.\n");
    }
    my $func;
    if (defined $names[2]) {
	$func = $names[2];
    } else {
	$func = "AVERAGE";
    }
    my %all_intervals;
    foreach my $interval (@intervals) {
	my %rrd_data;
	my $timeframe = $interval;
	if ($timeframe eq 'recent') {
	    $timeframe = 300; # XXX Assumes knowledge of step size.
	} else {
	    $timeframe *= 3600;  # Hours into seconds.
	}
	my $sortfile = "$directory/top_n_for_${interval}_by_$unit.txt";
	if (open SORTED, $sortfile) { # Replace with most likely candidates.
	    undef @files;
	    while (<SORTED>) {
		my ($rrd) = split /:/;
		push @files, "$directory/$rrd.rrd";
	    }
	    close SORTED;
	    die "Possible error with $sortfile" if @files == 0;
	}
	foreach my $file (@files) {
	    # NB -- The DEF func and PRINT func need not be equivalent,
	    # for instance one might want to print the minimum of the
	    # maximum values stored in the RRD.  If that happens, they
	    # should not both be $func.  However, that is currently the
	    # case.

	    (my $name = $file) =~ s/$directory\/(.*)\.rrd/$1/;
	    $rrd_data{$name} = extract_rrd_value($file, $unit, $func, $func,
						$timeframe, $endtime);
	}
	$all_intervals{$interval} = \%rrd_data;
	my @good_keys = sort {$rrd_data{$b} <=> $rrd_data{$a}} keys %rrd_data;
	if (@good_keys > $top_n) {
	    @good_keys = @good_keys[0 .. $top_n-1];
	}
	if (@good_keys > 0 and $rrd_data{$good_keys[0]} == 0 and
	    $rrdlists{'sort_type'} == $JOINT_TOP)
	{ # With no top N, use the RRDs of other timescales
	    @good_keys = ();
	}
	$rrdlists{$interval} = \@good_keys;
    }
    if ($rrdlists{'sort_type'} == $JOINT_TOP) {
	foreach my $interval (@intervals) {
	    my %known_rrds;
	    my @new_list = @{$rrdlists{$interval}};
	    foreach my $rrd (@new_list) {
		$known_rrds{$rrd}++;
	    }
	    # Look at other intervals and check if unknown rrds exist there.
	    foreach my $other_interval (@intervals) {
		next if $interval eq $other_interval; 
		my @other_rrds = @{$rrdlists{$other_interval}};
		my $size = @other_rrds;
		my $last_rank = $size > $top_n ? $top_n-1 : $size-1;
		foreach my $rank (0 .. $last_rank) {
		    my $rrd = $other_rrds[$rank];
		    if ($rrd and not exists $known_rrds{$rrd}) {
			$known_rrds{$rrd}++;
			push @new_list, $rrd;
		    }
		}
	    }
	    my $rrd_data = $all_intervals{$interval};
	    no warnings;
	    @new_list = sort {$rrd_data->{$b} <=> $rrd_data->{$a}} @new_list;
	    use warnings;
	    $rrdlists{$interval} = \@new_list;
	}
    }
    $list_cache{$id_str} = \%rrdlists;
    return \%rrdlists;
}


sub get_rrdlist {
    my ($rrdlist_obj, $interval) = @_;
    if ($rrdlist_obj->{'sort_type'} == $KNOWN_SET) {
	return @{$rrdlist_obj->{'known'}};
    } elsif ($rrdlist_obj->{'sort_type'} == $RECENT_TOP) {
	return @{$rrdlist_obj->{'recent'}};
    } elsif ($rrdlist_obj->{'sort_type'} == $SPECIFIC_TOP) {
	my $specific_interval = $rrdlist_obj->{'sort_interval'};
	return @{$rrdlist_obj->{$specific_interval}};
    } elsif ($rrdlist_obj->{'sort_type'} == $SEPARATE_TOP or
	     $rrdlist_obj->{'sort_type'} == $JOINT_TOP) {
	return @{$rrdlist_obj->{$interval}};
    } else {
	# XXX Error of some sort.
    }
}
