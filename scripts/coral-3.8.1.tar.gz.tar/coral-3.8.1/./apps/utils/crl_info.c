/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 * crl_info.c - program to print information about the selected Coral
 * device.
 *
 * $Id: crl_info.c,v 1.60 2007/06/06 18:17:36 kkeys Exp $
 *
 */

static const char RCSid[]="$Id: crl_info.c,v 1.60 2007/06/06 18:17:36 kkeys Exp $";

#include "config.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <signal.h>
#include <ctype.h>
#include <time.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <errno.h>
#include <netinet/in.h>

#include "libcoral.h"

#ifdef HAVE_PCAP_FINDALLDEVS
# include <pcap.h>
#endif

typedef struct {
    uint64_t block_count;
    uint64_t count;
    coral_timestamp_t beg;
    coral_timestamp_t end;
} info_t;

static info_t info[CORAL_MAXOPEN];
static int short_flag = 0;
static int data_flag = 0;
static int block_flag = 0;
static int cell_flag = 0;
static int pkt_flag = 0;
static int find_iface_flag = 0;

static int count_cells_by_blocks(coral_source_t *src)
{
    coral_blk_info_t *binfo;
    coral_atm_cell_t *blk;
    coral_iface_t *iface;
    int i, cell_count;
    struct timeval beg, end;

    coral_start(src);
    memset(info, 0, sizeof(info));

    while ((iface = coral_read_block_endonly(src, &binfo, &blk, NULL))) {
	i = coral_interface_get_number(iface);
	cell_count = ntohl(binfo->cell_count);
	if (block_flag)
	    coral_diag(0, ("    if %d, blk %" PRIu64 ": records=%d",
		i, info[i].block_count, cell_count));
	info[i].block_count++;
	if (cell_count > 0) {
	    if (!info[i].count)
		info[i].beg = *coral_cell_time(iface, blk);
	    info[i].end = *coral_cell_time(iface,
		coral_nth_cell(iface, blk, (cell_count-1)));
	    info[i].count += cell_count;
	    if (block_flag) {
		CORAL_TIMESTAMP_TO_TIMEVAL(iface, coral_cell_time(iface, blk),
		    &beg);
		CORAL_TIMESTAMP_TO_TIMEVAL(iface, &info[i].end, &end);
		coral_diag(0, (", time %10ld.%06ld - %10ld.%06ld",
		    beg.tv_sec, beg.tv_usec, end.tv_sec, end.tv_usec));
	    }
	}
	if (block_flag)
	    coral_diag(0, ("\n"));
    }
    if (errno) return errno;

    if (block_flag)
	coral_diag(0, ("\n"));

    iface = NULL;
    while ((iface = coral_next_src_iface(src, iface))) {
	i = coral_interface_get_number(iface);
	CORAL_TIMESTAMP_TO_TIMEVAL(iface, &info[i].beg, &beg);
	CORAL_TIMESTAMP_TO_TIMEVAL(iface, &info[i].end, &end);
	/* We use coral_diag() because coral_dump() did. */
	coral_diag(0, ("  if %d:  blocks=%" PRIu64 ", records=%" PRIu64,
	    i, info[i].block_count, info[i].count));
	if (info[i].count > 0) {
	    coral_diag(0, (", time %10ld.%06ld - %10ld.%06ld",
		beg.tv_sec, beg.tv_usec, end.tv_sec, end.tv_usec));
	}
	coral_diag(0, ("\n"));
    }
    coral_diag(0, ("\n"));
    coral_stop(src);
    return 0;
}

static int count_cells_by_cells(coral_source_t *src)
{
    coral_atm_cell_t *cell;
    coral_iface_t *iface;
    int i;
    struct timeval beg, end;

    coral_start(src);
    memset(info, 0, sizeof(info));

    while ((iface = coral_read_cell(src, NULL, &cell, NULL))) {
	i = coral_interface_get_number(iface);
	if (!info[i].count)
	    info[i].beg = *coral_cell_time(iface, cell);
	info[i].end = *coral_cell_time(iface, cell);
	info[i].count++;
    }
    if (errno) return errno;

    iface = NULL;
    while ((iface = coral_next_src_iface(src, iface))) {
	i = coral_interface_get_number(iface);
	CORAL_TIMESTAMP_TO_TIMEVAL(iface, &info[i].beg, &beg);
	CORAL_TIMESTAMP_TO_TIMEVAL(iface, &info[i].end, &end);
	/* We use coral_diag() because coral_dump() did. */
	coral_diag(0, ("  if %d:  records=%" PRIu64, i, info[i].count));
	if (info[i].count > 0) {
	    coral_diag(0, (", time %10ld.%06ld - %10ld.%06ld",
		beg.tv_sec, beg.tv_usec, end.tv_sec, end.tv_usec));
	}
	coral_diag(0, ("\n"));
    }
    coral_diag(0, ("\n"));
    coral_stop(src);
    return 0;
}

static int count_pkts(coral_source_t *src)
{
    coral_iface_t *iface;
    coral_pkt_result_t pkt_result;
    int i;
    struct timeval beg, end;

    memset(info, 0, sizeof(info));
    coral_start(src);
    if (coral_read_pkt_init(NULL, NULL, NULL) < 0)
	goto stop;
    while ((iface = coral_read_pkt(&pkt_result, NULL))) {
	i = coral_interface_get_number(iface);
	if (!info[i].count)
	    info[i].beg = *pkt_result.timestamp;
	info[i].end = *pkt_result.timestamp;
	info[i].count++;
    }
    if (errno) return errno;

    iface = NULL;
    while ((iface = coral_next_src_iface(src, iface))) {
	i = coral_interface_get_number(iface);
	CORAL_TIMESTAMP_TO_TIMEVAL(iface, &info[i].beg, &beg);
	CORAL_TIMESTAMP_TO_TIMEVAL(iface, &info[i].end, &end);
	/* We use coral_diag() because coral_dump() did. */
	coral_diag(0, ("  if %d:  packets=%" PRIu64, i, info[i].count));
	if (info[i].count > 0) {
	    coral_diag(0, (", time %10ld.%06ld - %10ld.%06ld",
		beg.tv_sec, beg.tv_usec, end.tv_sec, end.tv_usec));
	}
	coral_diag(0, ("\n"));
    }
    coral_diag(0, ("\n"));
stop:
    coral_stop(src);
    return 0;
}

static int src_info(coral_source_t *src)
{
    int error = 0;
    if (coral_open(src) <= 0) {
	coral_diag(0, ("\n"));
	return CORAL_ERROR;
    }

    if (short_flag)
	coral_diag(0, ("%s:\n", coral_source_get_name(src)));
    else
	coral_dump(src);

    if (data_flag) {
	if (pkt_flag || !coral_source_is_block(src)) {
	    error = count_pkts(src);
	} else if (cell_flag) {
	    error = count_cells_by_cells(src);
	} else {
	    error = count_cells_by_blocks(src);
	}
    }

    coral_close(src);
    return error;
}

static void usage(const char* name)
{
    coral_usage(name, "[-vdpsbcr] [<source>]...\n"
#ifdef HAVE_PCAP_FINDALLDEVS
	"-i    print info for all standard interfaces\n"
#endif
	"-v    print CoralReef package and file format versions\n"
	"-d    print counts and first/last timestamps of records\n"
	"      (blocks, cells, or packets, depending on file type)\n"
	"-s    short form: omit format information\n"
	"-p    like -d, but for packets, regardless of file type\n"
	"-b    like -d, plus per-block counts (if applicable)\n"
	"-c    like -d, but on cells instead of blocks (if applicable)\n"
	"-r    use raw (uncorrected) time\n");
}

int main(int argc, char *argv[])
{
    int opt, error;
    coral_source_t *src, *next;

    coral_set_argv(argc, argv);
    coral_set_options(0, CORAL_OPT_NO_COMPOUND_SRC);
    /*coral_set_iomode(0, CORAL_RX_UNKNOWN, -1, 1);*/
    coral_set_duration(-1); /* don't allow user to set */

    while ((opt = getopt(argc, argv, "C:rsdpbcvi")) != -1) {
        switch (opt) {
        case 'C':
            if (coral_config_command(optarg) < 0) {
		usage(argv[0]);
                exit(-1);
	    }
            break;
        case 'r':
	    coral_set_options(0, CORAL_OPT_RAW_TIME);
            break;
        case 's':
            short_flag = data_flag = 1;
            break;
        case 'd':
            data_flag = 1;
            break;
        case 'p':
            pkt_flag = data_flag = 1;
	    coral_set_api(CORAL_API_PKT);
            break;
        case 'b':
            block_flag = data_flag = 1;
	    coral_set_api(CORAL_API_BLOCK);
            break;
        case 'c':
            cell_flag = data_flag = 1;
	    coral_set_api(CORAL_API_CELL);
            break;
        case 'v':
	    coral_config_command("version");
            break;
        case 'i':
#ifdef HAVE_PCAP_FINDALLDEVS
	    find_iface_flag = 1;
#else
	    coral_diag(0, ("-%c is not supported in this copy of %s.\n",
		opt, argv[0]));
#endif
            break;
        default:
	    usage(argv[0]);
            exit(-1);
        }
    }

#ifdef HAVE_PCAP_FINDALLDEVS
    if (find_iface_flag) {
	pcap_if_t *devs, *dp;
	char errbuf[PCAP_ERRBUF_SIZE];
	char name[1024];
	if (pcap_findalldevs(&devs, errbuf) < 0) {
	    coral_diag(0, ("%s\n", errbuf));
	} else {
	    for (dp = devs; dp; dp = dp->next) {
		sprintf(name, "if:%s", dp->name);
		if (!(src = coral_new_source(name)))
		    exit(-1);
		if ((error = src_info(src))) exit(error);
	    }
	    pcap_freealldevs(devs);
	}
    }
#endif

    next = coral_next_source(NULL);
    while ((src = next)) {
	next = coral_next_source(src);
	if ((error = src_info(src))) exit(error);
    }

    /* Doing arguments one at a time avoids the source count limit. */
    for ( ; optind < argc; optind++) {
	if (!(src = coral_new_source(argv[optind])))
	    exit(-1);
	if ((error = src_info(src))) exit(error);
    }

    coral_dump_all();	/* This is needed to print global proto rules. */

    return 0;
}
