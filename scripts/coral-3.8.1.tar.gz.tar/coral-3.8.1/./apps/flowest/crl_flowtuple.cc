#define TUPLE
#include "crl_flowest.cc"
