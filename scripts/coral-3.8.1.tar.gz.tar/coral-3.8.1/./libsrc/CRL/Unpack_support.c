/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/* $Id: Unpack_support.c,v 1.30 2007/06/06 18:17:45 kkeys Exp $ */

#include "config.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <netinet/in_systm.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <netinet/ip_icmp.h>
#include <netinet/igmp.h>
#include <arpa/inet.h>
#include "libcoral.h"
#include "head_info.h"
#include "Unpack.h"
#include "options.h"


#ifndef NULL
#define NULL 0
#endif


/* XXX - Ok, this is currently making a perl dependence. */
extern void Perl_croak(const char *fmt, ...);
extern void Perl_warn(const char *fmt, ...);

#define unpack_die Perl_croak
#define unpack_warn Perl_warn



#define HANDLE_OPT(TITLE, TYPE, OFFSET, SELECTOR) \
        case OPT_##TITLE: \
            if (head_len >= (OFFSET)) {   \
                 response.vals[i].rep.TYPE = (SELECTOR); \
                 response.vals[i].type = UNPACK_TYPE_##TYPE; \
            } else {\
                 response.vals[i].type = UNPACK_TYPE_UNDEF;  \
	    } \
            break



#define STATIC_RET_INFO(NAME) \
    static ret_info NAME = { NULL, 0, 0 }


static void reset_ret_info(ret_info *info, int new_size)
{
    /* Loop here to free any elements of the vals array which need
       special cleanup. */

    info->len = new_size;

    if (info->size >= new_size) return;

    if (info->vals) {
	info->vals = (head_info *) realloc(info->vals,
					   sizeof(head_info) * new_size);
    } else {
	info->vals = (head_info *) malloc(sizeof(head_info) * new_size);
    }

    info->size = new_size;
}


#define CONV_OPT(TYPE, OPTION) \
    if (type == UNPACK_STRUCT_##TYPE || type == UNPACK_STRUCT_unknown) { \
	if (!strcmp(options[i], #OPTION)) { \
	    result->opts[i] = OPT_##OPTION; \
	    type = UNPACK_STRUCT_##TYPE; \
	    continue; \
	} \
    }

static options_info *make_options_info(char **options, int type)
{
    int i, opt_size = 0;
    options_info *result;
    const char *type_name = "";

    while (options[opt_size])
        opt_size++;

    result = (options_info *) malloc(sizeof(options_info));
    result->len = opt_size;
    result->opts =  (int *) malloc(sizeof(int) * opt_size);

    for (i = 0; i < opt_size; i++) {
        result->opts[i] = OPT_UNKNOWN;
        CONV_OPT(ip, ip_hl);
        CONV_OPT(ip, ihl);
        CONV_OPT(ip, ip_v);
        CONV_OPT(ip, ip_tos);
        CONV_OPT(ip, ip_len);
        CONV_OPT(ip, ip_id);
        CONV_OPT(ip, ip_off);
        CONV_OPT(ip, ip_df);
        CONV_OPT(ip, ip_mf);
        CONV_OPT(ip, ip_offset);
        CONV_OPT(ip, ip_frag);
        CONV_OPT(ip, ip_ttl);
        CONV_OPT(ip, ip_p);
        CONV_OPT(ip, ip_sum);
        CONV_OPT(ip, ip_src);
        CONV_OPT(ip, ip_dst);
        CONV_OPT(ip, ip_src_dotted);
        CONV_OPT(ip, ip_dst_dotted);

        CONV_OPT(icmp, icmp_type);
        CONV_OPT(icmp, icmp_code);
        CONV_OPT(icmp, icmp_cksum);

	CONV_OPT(tcp, th_sport);
	CONV_OPT(tcp, th_dport);
	CONV_OPT(tcp, th_seq);
	CONV_OPT(tcp, th_ack);
	CONV_OPT(tcp, th_off);
	CONV_OPT(tcp, th_x2);
	CONV_OPT(tcp, th_flags);
	CONV_OPT(tcp, th_win);
	CONV_OPT(tcp, th_sum);
	CONV_OPT(tcp, th_urp);
	CONV_OPT(tcp, fin);
	CONV_OPT(tcp, syn);
	CONV_OPT(tcp, rst);
	CONV_OPT(tcp, psh);
	CONV_OPT(tcp, ack);
	CONV_OPT(tcp, urg);

	CONV_OPT(udp, uh_sport);
	CONV_OPT(udp, uh_dport);
	CONV_OPT(udp, uh_ulen);
	CONV_OPT(udp, uh_sum);

	CONV_OPT(llcsnap, llc_dsap);
	CONV_OPT(llcsnap, llc_ssap);
	CONV_OPT(llcsnap, llc_cntl);
	CONV_OPT(llcsnap, snap_org);
	CONV_OPT(llcsnap, snap_org1);
	CONV_OPT(llcsnap, snap_org2);
	CONV_OPT(llcsnap, snap_org3);
	CONV_OPT(llcsnap, snap_type);

	CONV_OPT(igmp, igmp_type);
	CONV_OPT(igmp, igmp_code);
	CONV_OPT(igmp, igmp_cksum);
	CONV_OPT(igmp, igmp_group);

	CONV_OPT(bhead, interface);
	CONV_OPT(bhead, blk_size);
	CONV_OPT(bhead, cell_count);
	CONV_OPT(bhead, cells_lost);
	CONV_OPT(bhead, unknown_vpi_vci);
	CONV_OPT(bhead, tbegin_sec);
	CONV_OPT(bhead, tbegin_nsec);
	CONV_OPT(bhead, tend_sec);
	CONV_OPT(bhead, tend_nsec);

	CONV_OPT(atm, gfc);
	CONV_OPT(atm, vp);
	CONV_OPT(atm, vc);
	CONV_OPT(atm, oam_rm);
	CONV_OPT(atm, congestion);
	CONV_OPT(atm, sdu_type);
	CONV_OPT(atm, clp);

	/* issue warning about unknown option type here */
	switch (type) {
	case UNPACK_STRUCT_unknown:	type_name = "unknown";	break;
	case UNPACK_STRUCT_ip:		type_name = "ip";	break;
	case UNPACK_STRUCT_icmp:	type_name = "icmp";	break;
	case UNPACK_STRUCT_tcp:		type_name = "tcp";	break;
	case UNPACK_STRUCT_udp:		type_name = "udp";	break;
	case UNPACK_STRUCT_llcsnap:	type_name = "llcsnap";	break;
	case UNPACK_STRUCT_igmp:	type_name = "igmp";	break;
	case UNPACK_STRUCT_bhead:	type_name = "bhead";	break;
	case UNPACK_STRUCT_atm:		type_name = "atm";	break;
	}

	unpack_die("unknown option for structure type %s: %s",
		   type_name, options[i]);
    }

    result->type = type;

    return result;
}

#undef CONV_OPT

#define CONV_STRUCT(TYPE) \
    do { \
	if (!strcmp(type_name, #TYPE)) { \
	    type = UNPACK_STRUCT_##TYPE; \
	} \
    } while (0)

options_info *new_Unpacker(char *type_name, char **options)
{
    int type = UNPACK_STRUCT_unknown;

    CONV_STRUCT(ip);
    CONV_STRUCT(icmp);
    CONV_STRUCT(tcp);
    CONV_STRUCT(udp);
    CONV_STRUCT(llcsnap);
    CONV_STRUCT(igmp);
    CONV_STRUCT(bhead);
    CONV_STRUCT(atm);

    if (type == UNPACK_STRUCT_unknown) {
	unpack_die("unknown structure type: %s", type_name);
	/* DOES NOT RETURN */
    }

    return make_options_info(options, type);
}

#undef CONV_STRUCT


ret_info *unpack(options_info *options, data_info *header, int offset)
{
    STATIC_RET_INFO(response);

    switch (options->type) {
    case UNPACK_STRUCT_ip:
	return unpack_ip(header, options, offset);
    case UNPACK_STRUCT_icmp:
	return unpack_icmp(header, options, offset);
    case UNPACK_STRUCT_tcp:
	return unpack_tcp(header, options, offset);
    case UNPACK_STRUCT_udp:
	return unpack_udp(header, options, offset);
    case UNPACK_STRUCT_llcsnap:
	return unpack_llcsnap(header, options, offset);
    case UNPACK_STRUCT_igmp:
	return unpack_igmp(header, options, offset);
    case UNPACK_STRUCT_bhead:
	return unpack_bhead(header, options, offset);
    case UNPACK_STRUCT_atm:
	return unpack_atm(header, options, offset);
    }

    return &response;
}


ret_info *unpack_ip(data_info *header, options_info *options, int offset)
{
    int i;
    struct ip * hd_p;
    size_t head_len;
    uint16_t ip_off = 0;
    STATIC_RET_INFO(response);

    reset_ret_info(&response, options->len);

    hd_p = (struct ip*) ((char *) header->data + offset);
    head_len = header->len - offset;

    /* ip_off is used in many spots, only fix byte order once */
    if (head_len >= 8) {
	ip_off = ntohs(hd_p->ip_off);
    }

    for (i = 0; i < options->len; i++) {
        switch (options->opts[i]) {
            HANDLE_OPT(ip_hl, UINT8, 1, hd_p->ip_hl);
	    HANDLE_OPT(ihl, UINT8, 1, hd_p->ip_hl * 4);
            HANDLE_OPT(ip_v, UINT8, 1, hd_p->ip_v);
            HANDLE_OPT(ip_tos, UINT8, 2, hd_p->ip_tos);
            HANDLE_OPT(ip_len, UINT16, 4, ntohs(hd_p->ip_len));
            HANDLE_OPT(ip_id, UINT16, 6, ntohs(hd_p->ip_id));

	    /* note that ip_off has already been ntohs'd */
            HANDLE_OPT(ip_off, UINT16, 8, ip_off);
            HANDLE_OPT(ip_offset, UINT16, 8, ip_off & IP_OFFMASK);
            HANDLE_OPT(ip_df, BOOL, 8, ip_off & IP_DF);
            HANDLE_OPT(ip_mf, BOOL, 8, ip_off & IP_MF);
            HANDLE_OPT(ip_frag, BOOL, 8, ip_off & (IP_OFFMASK | IP_MF));

            HANDLE_OPT(ip_ttl, UINT8, 9, hd_p->ip_ttl);
            HANDLE_OPT(ip_p, UINT8, 10, hd_p->ip_p);
            HANDLE_OPT(ip_sum, UINT16, 12, ntohs(hd_p->ip_sum));
            HANDLE_OPT(ip_src, UINT32, 16, ntohl(hd_p->ip_src.s_addr));
            HANDLE_OPT(ip_dst, UINT32, 20, ntohl(hd_p->ip_dst.s_addr));
            HANDLE_OPT(ip_src_dotted, IN_ADDR, 16, hd_p->ip_src);
            HANDLE_OPT(ip_dst_dotted, IN_ADDR, 20, hd_p->ip_dst);
        }
    }
    return &response;
}


ret_info *unpack_icmp(data_info *header, options_info *options, int offset)
{
    int i;
    struct icmp * hd_p;
    size_t head_len;
    STATIC_RET_INFO(response);

    reset_ret_info(&response, options->len);

    hd_p = (struct icmp*) ((char *) header->data + offset);
    head_len = header->len - offset;

    for (i = 0; i < options->len; i++) {
        switch (options->opts[i]) {
            HANDLE_OPT(icmp_type, UINT8, 1, hd_p->icmp_type);
            HANDLE_OPT(icmp_code, UINT8, 2, hd_p->icmp_code);
            HANDLE_OPT(icmp_cksum, UINT16, 4, ntohs(hd_p->icmp_cksum));
        }
    }
    return &response;
}


ret_info *unpack_tcp(data_info *header, options_info *options, int offset)
{
    int i;
    struct tcphdr * hd_p;
    size_t head_len;
    STATIC_RET_INFO(response);

    reset_ret_info(&response, options->len);

    hd_p = (struct tcphdr*) ((char *) header->data + offset);
    head_len = header->len - offset;

    for (i = 0; i < options->len; i++) {
        switch (options->opts[i]) {
            HANDLE_OPT(th_sport, UINT16, 2, ntohs(hd_p->th_sport));
            HANDLE_OPT(th_dport, UINT16, 4, ntohs(hd_p->th_dport));
            HANDLE_OPT(th_seq, UINT32, 8, ntohl(hd_p->th_seq));
            HANDLE_OPT(th_ack, UINT32, 12, ntohl(hd_p->th_ack));
            HANDLE_OPT(th_x2, UINT8, 13, hd_p->th_x2);
            HANDLE_OPT(th_off, UINT8, 13, hd_p->th_off);
            HANDLE_OPT(th_flags, UINT8, 14, hd_p->th_flags);
            HANDLE_OPT(fin, BOOL, 14, hd_p->th_flags & TH_FIN);
            HANDLE_OPT(syn, BOOL, 14, hd_p->th_flags & TH_SYN);
            HANDLE_OPT(rst, BOOL, 14, hd_p->th_flags & TH_RST);
            HANDLE_OPT(psh, BOOL, 14, hd_p->th_flags & TH_PUSH);
            HANDLE_OPT(ack, BOOL, 14, hd_p->th_flags & TH_ACK);
            HANDLE_OPT(urg, BOOL, 14, hd_p->th_flags & TH_URG);
            HANDLE_OPT(th_win, UINT16, 16, ntohs(hd_p->th_win));
            HANDLE_OPT(th_sum, UINT16, 18, ntohs(hd_p->th_sum));
            HANDLE_OPT(th_urp, UINT16, 20, ntohs(hd_p->th_urp));
        }
    }
    return &response;
}


ret_info *unpack_udp(data_info *header, options_info *options, int offset)
{
    int i;
    struct udphdr * hd_p;
    size_t head_len;
    STATIC_RET_INFO(response);

    reset_ret_info(&response, options->len);

    hd_p = (struct udphdr*) ((char *) header->data + offset);
    head_len = header->len - offset;

    for (i = 0; i < options->len; i++) {
        switch (options->opts[i]) {
            HANDLE_OPT(uh_sport, UINT16, 2, ntohs(hd_p->uh_sport));
            HANDLE_OPT(uh_dport, UINT16, 4, ntohs(hd_p->uh_dport));
            HANDLE_OPT(uh_ulen, UINT16, 6, ntohs(hd_p->uh_ulen));
            HANDLE_OPT(uh_sum, UINT16, 8, ntohs(hd_p->uh_sum));
        }
    }
    return &response;
}


ret_info *unpack_llcsnap(data_info *header, options_info *options, int offset)
{
    int i;
    coral_llcsnap_t * hd_p;
    size_t head_len;
    STATIC_RET_INFO(response);

    reset_ret_info(&response, options->len);

    hd_p = (coral_llcsnap_t*) ((char *) header->data + offset);
    head_len = header->len - offset;

    for (i = 0; i < options->len; i++) {
        switch (options->opts[i]) {
            HANDLE_OPT(llc_dsap, UINT8, 1, hd_p->llc_dsap);
            HANDLE_OPT(llc_ssap, UINT8, 2, hd_p->llc_ssap);
            HANDLE_OPT(llc_cntl, UINT8, 3, hd_p->llc_cntl);
            HANDLE_OPT(snap_org1, UINT8, 4, hd_p->snap_org[0]);
            HANDLE_OPT(snap_org2, UINT8, 5, hd_p->snap_org[1]);
            HANDLE_OPT(snap_org3, UINT8, 6, hd_p->snap_org[2]);
            HANDLE_OPT(snap_type, UINT16, 8, ntohs(hd_p->snap_type));
	    /* XXX - does this need casts to unsigned for the shift? */
            HANDLE_OPT(snap_org, UINT32, 6, ((hd_p->snap_org[0] << 16) |
					     (hd_p->snap_org[1] << 8) |
					     hd_p->snap_org[2]));
        }
    }
    return &response;
}


ret_info *unpack_igmp(data_info *header, options_info *options, int offset)
{
    int i;
    struct igmp *hd_p;
    size_t head_len;
    STATIC_RET_INFO(response);

    reset_ret_info(&response, options->len);

    hd_p = (struct igmp *) ((char *) header->data + offset);
    head_len = header->len - offset;

    for (i = 0; i < options->len; i++) {
        switch (options->opts[i]) {
            HANDLE_OPT(igmp_type, UINT8, 1, hd_p->igmp_type);
            HANDLE_OPT(igmp_code, UINT8, 2, hd_p->igmp_code);
            HANDLE_OPT(igmp_cksum, UINT16, 4, ntohs(hd_p->igmp_cksum));
            /* igmp_group isn't a struct in_addr on all systems, so we cast */
            HANDLE_OPT(igmp_group, UINT32, 8,
                ntohl(((struct in_addr*)&hd_p->igmp_group)->s_addr));
        }
    }
    return &response;
}

ret_info *unpack_bhead(data_info *header, options_info *options, int offset)
{
    int i;
    coral_blk_info_t *hd_p;
    size_t head_len;
    STATIC_RET_INFO(response);

    reset_ret_info(&response, options->len);

    hd_p = (coral_blk_info_t *) ((char *) header->data + offset);
    head_len = header->len - offset;

    for (i = 0; i < options->len; i++) {
        switch (options->opts[i]) {
            HANDLE_OPT(interface, UINT32, 4, ntohl(hd_p->interface));
            HANDLE_OPT(blk_size, UINT32, 8, ntohl(hd_p->blk_size));
            HANDLE_OPT(cell_count, UINT32, 12, ntohl(hd_p->cell_count));
            HANDLE_OPT(cells_lost, UINT32, 16, ntohl(hd_p->cells_lost));
            HANDLE_OPT(unknown_vpi_vci, UINT32, 20, ntohl(hd_p->unknown_vpi_vci));
	    HANDLE_OPT(tbegin_sec, UINT32, 24, ntohl(hd_p->tbegin.tv_sec));
	    HANDLE_OPT(tbegin_nsec, UINT32, 28, ntohl(hd_p->tbegin.tv_nsec));
	    HANDLE_OPT(tend_sec, UINT32, 32, ntohl(hd_p->tend.tv_sec));
	    HANDLE_OPT(tend_nsec, UINT32, 36, ntohl(hd_p->tend.tv_nsec));
        }
    }
    return &response;
}

ret_info *unpack_atm(data_info *header, options_info *options, int offset)
{
    int i;
    union atm_hdr *hd_p;
    static union atm_hdr flipper;
    size_t head_len;
    STATIC_RET_INFO(response);

    reset_ret_info(&response, options->len);

    hd_p = (union atm_hdr *) ((char *) header->data + offset);
    flipper.ui = ntohl(hd_p->ui);
    head_len = header->len - offset;

    for (i = 0; i < options->len; i++) {
        switch (options->opts[i]) {
            HANDLE_OPT(gfc, UINT8, 4, flipper.h.gfc);
            HANDLE_OPT(vp, UINT32, 4, get_vpvc_vp(flipper.h.vpvc));
            HANDLE_OPT(vc, UINT32, 4, get_vpvc_vc(flipper.h.vpvc));
            HANDLE_OPT(oam_rm, BOOL, 4, flipper.h.oam_rm);
            HANDLE_OPT(congestion, BOOL, 4, flipper.h.congestion);
            HANDLE_OPT(sdu_type, BOOL, 4, flipper.h.sdu_type);
            HANDLE_OPT(clp, BOOL, 4, flipper.h.clp);
        }
    }
    return &response;
}
