/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 * crl_guess.c - program to guess the format and encapsulation protocols
 * of a trace file.
 *
 * $Id: crl_guess.c,v 1.27 2007/06/06 18:17:30 kkeys Exp $
 *
 */

static const char RCSid[]="$Id: crl_guess.c,v 1.27 2007/06/06 18:17:30 kkeys Exp $";

#include "config.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <signal.h>
#include <ctype.h>
#include <time.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <errno.h>
#include <math.h>

#include "libcoral.h"
#include "libcoral_priv.h"
#include "hashtab.h"

#define MAXDEPTH 7
#define MINPKTS 500
#define MAXPKTS 2000
#define MINBLKS 2

#define HASH_TABLE_SIZE	    101

typedef struct {
    /*int iface_id;*/
    uint32_t subif_id;
    long pkts;
    long totpkts;		/* total # of pkts from this subif, if known */
    long err, unknown, ip;
    long depth[MAXDEPTH];
    coral_protocol_t proto;
    int identified;
    int ignored;
    int failed;
    double score;
} subif_info_t;

typedef struct {
    long pkts;
    long badtime;
    struct timespec prevts[16];
    long err, unknown, ip;
    int identified;
    int failed;
    int max_ifnum;
} src_info_t;

static hash_tab *subif_tab = NULL;
static coral_source_t *src = NULL;
static int debug_flag = 0;
static long blk_count = 0;
static long max_blks = 0;
static long min_pkts = MINPKTS;
static src_info_t src_info;


#ifndef min
# define max(a,b)	((a)>(b) ? (a) : (b))
#endif
#define debug(args)	do { if (debug_flag) fprintf args; } while (0)

static void cell_block_hook(const coral_iface_t *iface,
    const coral_blk_info_t *binfo)
{
    debug((stderr, "blk %ld, id %d, fail %d, if %d, subifs %ld, pkts %ld, "
	"max_blks %ld\n",
	blk_count, src_info.identified, src_info.failed, iface->id,
	num_hash_entries(subif_tab), src_info.pkts, max_blks));
    blk_count++;
    if (blk_count > max_blks) {
	debug((stderr, "too many (%ld) blocks\n", blk_count));
	coral_pkt_done = 1;
    }
}

/* for qsort */
static int compare_entry_ptrs(const void *entry1, const void *entry2)
{
    const subif_info_t *a = *(subif_info_t**)entry1;
    const subif_info_t *b = *(subif_info_t**)entry2;

#if 0
    return (a->iface_id != b->iface_id) ? (a->iface_id - b->iface_id) :
	(a->subif_id - b->subif_id);
#else
    return (a->subif_id - b->subif_id);
#endif
}

/* for hash table */
static int compare_entries(const void *entry1, const void *entry2)
{
    const subif_info_t *a = entry1;
    const subif_info_t *b = entry2;

#if 0
    return (a->iface_id != b->iface_id) ? (a->iface_id - b->iface_id) :
	(a->subif_id - b->subif_id);
#else
    return (a->subif_id - b->subif_id);
#endif
}

static unsigned long make_entry_key(const void *entry)
{
    const subif_info_t *what = entry;

#if 0
    return (unsigned) what->subif_id * 425879 + what->iface_id;
#else
    return (unsigned) what->subif_id;
#endif
}

/* free mem of an entry - for use by the hashtable */
static void delete_entry(void *entry)
{
    if (!entry) return;
    free(entry);
}


static double info_score(subif_info_t *info) {
    double score;
    int i;

    score = info->ip;
    for (i = 0; i < MAXDEPTH; i++)
	score += info->depth[i] * (i+1);
    score /= info->pkts;

    score *= pow(info->pkts - info->err - info->unknown, 2);
    score /= pow(info->pkts, 2);

    score *= pow(info->pkts - info->err, 3);
    score /= pow(info->pkts, 3);

#if 0
    /* lack-of-confidence decreases exponentially with amount of data */
    score *= (1 - exp(info->pkts/-10.0));
#endif

    return score;
}

static void dump_score(subif_info_t *info, double score)
{
    int i;
    if (!debug_flag) return;
    fprintf(stderr, "%d:%d %s%s e=%ld, u=%ld, i=%ld, p=%ld, d=",
	get_vpvc_vp(info->subif_id), get_vpvc_vc(info->subif_id),
	info->ignored ? " IG" : "",
	info->identified ? " ID" : "",
	info->err, info->unknown, info->ip, info->pkts);
    for (i = 0; i < MAXDEPTH; i++)
	fprintf(stderr, "%ld ", info->depth[i]);
    fprintf(stderr, "s=%f\n", score);
}

static int tryproto(const char *name,
    coral_protocol_t phy, coral_protocol_t datalink, int first)
{
    coral_pkt_buffer_t pkt_buf[2], *spkt, *dpkt;
    coral_pkt_result_t pkt_result;
    double score;
    struct timespec ts;
    int depth, result;
    int old_subifs = 0;	/* number of subifs seen on previous passes */
    subif_info_t tmp, *info;
    coral_iface_t *iface;
    const coral_pkt_stats_t *pkt_stats;

    if (src) coral_close(src);
    memset(&src_info, 0, sizeof(src_info));
    src_info.max_ifnum = -1;

    coral_config.dev_config.datalink = datalink;

    if (!(src = coral_new_source(name)))
	return -1;
    if (phy != CORAL_PROTO_UNKNOWN)
	src->dev_config.physical = phy;

#if 1
    debug((stderr, "tryproto(): %s, ", coral_proto_abbr(src->dev_config.physical)));
    debug((stderr, "%s, %d...\n", coral_proto_abbr(datalink), first));
#endif

    if (first == 65535)
	coral_source_set_iomode(src, 0, CORAL_RX_USER_ALL, -1);
    else
	coral_source_set_iomode(src, 0, 0, first);

    if (coral_open(src) <= 0) {
	debug((stderr, "open failed\n"));
	src = NULL;
	return -1;
    }
    /* Ignore proto rules stored in file */
    coral_delete_proto_rules(src, NULL);

    /* reset */
    src_info.identified = src_info.failed = 0;
    src_info.pkts = src_info.badtime = src_info.err = src_info.unknown = 0;
    old_subifs = num_hash_entries(subif_tab);

    /* reset the subifs we don't know, skip the subifs we do know */
    init_hash_walk(subif_tab);
    while ((info = next_hash_walk(subif_tab))) {
	if (info->identified) {
	    if (info->subif_id)
		coral_set_proto_rule(src, NULL, 'd', info->subif_id, -1, 0);
	    src_info.identified++;
	} else if (info->ignored) {
	    if (info->subif_id)
		coral_set_proto_rule(src, NULL, 'd', info->subif_id, -1, 0);
	    src_info.failed++;
	} else {
	    info->pkts = info->err = info->unknown = info->ip = 0;
	    info->failed = 0;
	    memset(info->depth, 0, sizeof(info->depth));
	}
    }

    blk_count = 0;
    coral_pkt_done = 0;

    if (coral_start(src) < 0) {
	debug((stderr, "start failed\n"));
	return -1;
    }
    if (coral_read_pkt_init(NULL, NULL, NULL) < 0) {
	debug((stderr, "pkt_init failed\n"));
	return -1;
    }

    while ((src_info.pkts <= min_pkts ||
	src_info.identified + src_info.failed < num_hash_entries(subif_tab)) &&
	(iface = coral_read_pkt(&pkt_result, NULL)) &&
	!coral_pkt_done)
    {
	int ifnum = ((coral_iface_pfx_t*)(iface))->sid;
	if (ifnum > src_info.max_ifnum)
	    src_info.max_ifnum = ifnum;
#if 1
	if (src_info.pkts == 0)
	    debug((stderr, "tryproto: first packet is %s\n",
		coral_proto_str(pkt_result.packet->protocol)));
#endif
#if 0
	if (datalink == CORAL_NETPROTO_RAW_IP) {
	    int layers[] = {1,7};
	    coral_mprint_pkt(iface, pkt_result.timestamp, layers,
		pkt_result.packet, NULL, NULL);
	}
#endif
	/*tmp.iface_id = coral_interface_get_number(iface);*/
	tmp.subif_id = pkt_result.subiface;
	if (!(info = (subif_info_t*)find_hash_entry(subif_tab, &tmp))) {
	    if (!(info = (subif_info_t*)calloc(1, sizeof(subif_info_t)))) {
		debug((stderr, "calloc entry: %s", strerror(errno)));
		exit(1);
	    }
	    /*info->iface = iface;*/
	    /*info->iface_id = coral_interface_get_number(iface);*/
	    info->subif_id = pkt_result.subiface;
	    add_hash_entry(subif_tab, info);
	    debug((stderr, "new subif %d:%d\n",
		get_vpvc_vp(info->subif_id), get_vpvc_vc(info->subif_id)));
	}
	if (max_blks < max(10, blk_count) + num_hash_entries(subif_tab) -
	    (src_info.identified + src_info.failed))
	{
	    max_blks = max(10, blk_count) + num_hash_entries(subif_tab) -
		(src_info.identified + src_info.failed);
	    coral_set_max_blks(max_blks);
	}

	/* If there are subifs, increase min_pkts to give every subif a chance
	 * to make an appearance.
	 */
	if (info->subif_id)
	    min_pkts = 3 * MINPKTS;

	CORAL_TIMESTAMP_TO_TIMESPEC(iface, pkt_result.timestamp, &ts);
	if (src_info.pkts && !timespeccmp(&src_info.prevts[iface->id], &ts, <))
	    src_info.badtime++;
	src_info.prevts[iface->id] = ts;

	src_info.pkts++;
	info->pkts++;

	if (src_info.pkts >= MINPKTS) {
	    /* If there are way too many errors after reading a decent
	     * amount of data, stop wasting time.
	     */
	    if (num_hash_entries(subif_tab) - old_subifs >
		20 * log(src_info.pkts))
	    {
		debug((stderr, "too many (%ld/%ld) subifs\n",
		    num_hash_entries(subif_tab), src_info.pkts));
		return -1; /* too many subifs */
	    }
	    /* Allow a few bad times early, then a very very low error rate */
	    if (src_info.badtime > 10 + 0.0001 * src_info.pkts) {
		debug((stderr, "too many (%ld/%ld) bad timestamps\n",
		    src_info.badtime, src_info.pkts));
		return -1; /* too many bad timestamps */
	    }
#if 0
	    if (src_info.err + src_info.unknown > 0.9 * src_info.pkts) {
		debug((stderr, "too many unparsable packets\n"));
		return identified; /* too many unparsable packets */
	    }
#endif
	}
	if (src_info.pkts >= MINPKTS || blk_count >= MINBLKS) {
	    /* If there are way too many errors after reading a decent
	     * amount of data, stop wasting time.
	     * Check aal5 errors after a minimum blk_count because aal5 errors
	     * and "deny" rules prevent src_info.pkts++, even if a lot of
	     * data is being read.
	     */
	    pkt_stats = coral_get_iface_stats(iface);
	    if (pkt_stats->aal5_trailer > src_info.pkts * 0.05) {
		/* probably means <first> is incorrect */
		debug((stderr, "too many (%" PRIu64 "/%ld) bad aal5 trailers\n",
		    pkt_stats->aal5_trailer, src_info.pkts));
		return -1; /* too many bad aal5 trailers */
	    }
	}

	if (info->ignored || info->failed)
	    continue;

	if (phy == CORAL_PHY_ATM && info->subif_id < 16) {
	    /* ATM 0:0 through 0:15 are signalling that coral can't parse */
	    src_info.failed++;
	    info->ignored = 1;
	    /* don't need to read this subif anymore */
	    coral_set_proto_rule(src, NULL, 'd', info->subif_id, -1, 0);
	    debug((stderr, "ignoring %d:%d\n",
		get_vpvc_vp(info->subif_id), get_vpvc_vc(info->subif_id)));
	    continue;
	}

	spkt = pkt_result.packet;
	dpkt = &pkt_buf[depth=0];

	result = coral_get_payload(spkt, dpkt);
	if (result == CORAL_ENOPROTO) {
	    /* libcoral can't parse this protocol, so don't try any more */
	    debug((stderr, "tryproto: can't parse %s\n",
		coral_proto_str(spkt->protocol)));
	    return src_info.identified;
	} else if (result < 0) {
	    info->err++;
	    src_info.err++;
	} else if (dpkt->protocol == CORAL_PROTO_UNKNOWN) {
	    /* With IPv4, an unknown next layer could mean it's a bad packet,
	     * or just that it's a non-first fragment.  libcoral's IPv4 parser
	     * does enough validation that we assume it means the latter, and
	     * don't increment the unknown counters. */
	    if (spkt->protocol == CORAL_NETPROTO_IPv4) {
		/* But since we're not 100% sure, we only increment one of the
		 * depth and ip counters. */
		info->depth[depth]++;
		/* info->ip++; */
	    } else {
		info->unknown++;
		src_info.unknown++;
	    }

	} else {
	    do {
		if (spkt->protocol == CORAL_NETPROTO_IPv4 ||
		    spkt->protocol == CORAL_NETPROTO_IPv6 ||
		    spkt->protocol == CORAL_NETPROTO_RAW_IP)
		{
		    info->ip++;  /* parsable IP gives us extra confidence */
		}
		info->depth[depth]++;
#if 0
		if (dpkt->protocol == CORAL_NETPROTO_IP)
		    info->depth[depth]++;
#endif
		spkt = dpkt;
		dpkt = &pkt_buf[(++depth)%2];
	    } while (depth < MAXDEPTH && coral_get_payload(spkt, dpkt) >= 0);
	}

	/* got enough packets */
	if ((info->pkts >= MINPKTS && info->pkts % 100 == 0) ||
	    (info->totpkts > 0 && info->pkts >= info->totpkts))
	{
	    score = info_score(info);
	    if (score >= 1) {
		src_info.identified++;
		info->proto = datalink;
		info->identified = 1;
		info->score = score;
		/* don't need to read this subif anymore */
		if (info->subif_id)
		    coral_set_proto_rule(src, NULL, 'd', info->subif_id, -1, 0);
		dump_score(info, score);
		debug((stderr, "identified %d:%d after %ld pkts\n",
		    get_vpvc_vp(info->subif_id), get_vpvc_vc(info->subif_id),
		    info->pkts));

	    } else if (info->pkts >= MAXPKTS ||
		(info->totpkts > 0 && info->pkts >= info->totpkts) ||
		score <= 0.5)
	    {
		info->failed = 1;
		src_info.failed++;
		if (info->subif_id)
		    coral_set_proto_rule(src, NULL, 'd', info->subif_id, -1, 0);
		dump_score(info, score);
		debug((stderr, "giving up on %d:%d after %ld pkts: ",
		    get_vpvc_vp(info->subif_id), get_vpvc_vc(info->subif_id),
		    info->pkts));
		if (info->pkts >= MAXPKTS) {
		    debug((stderr, "inconclusive\n"));
		} else if (info->totpkts > 0 && info->pkts >= info->totpkts) {
		    debug((stderr, "out of pkts\n"));
		} else {
		    debug((stderr, "protocol obviously wrong\n"));
		}
	    }
	}
    }

    src->dev_config.num_ifaces = src_info.max_ifnum + 1;

    if (src_info.identified + src_info.failed >= num_hash_entries(subif_tab) &&
	src_info.pkts >= min_pkts)
    {
	debug((stderr,
	    "satisfied with %ld subifs, %d id'd, %d failed, %ld packets\n",
	    num_hash_entries(subif_tab), src_info.identified, src_info.failed,
	    src_info.pkts));
    }

    if (iface) {
	debug((stderr, "\n"));
    } else {
	debug((stderr, "EOF\n"));
    }

    if (src_info.pkts <= 0) {
	debug((stderr, "src_info.pkts == %ld\n", src_info.pkts));
	return 0;
    }

    if (src_info.identified < num_hash_entries(subif_tab)) {
	init_hash_walk(subif_tab);
	while ((info = next_hash_walk(subif_tab))) {
	    if (info->identified || info->ignored)
		continue;
	    if (!iface) /* reached EOF */ {
		info->totpkts = info->pkts;
		/* Remember this so we can avoid scanning to EOF */
	    }
	    score = info_score(info);
	    dump_score(info, score);
	    if (score > info->score) {
		if (score >= 1) {
		    src_info.identified++;
		    info->identified = 1;
		    debug((stderr, "identified %d:%d\n",
			get_vpvc_vp(info->subif_id),
			get_vpvc_vc(info->subif_id)));
		}
		info->score = score;
		info->proto = datalink;
	    }
	}
    }

    debug((stderr, "# %ld subifs, %d identified, %d failed\n",
	num_hash_entries(subif_tab), src_info.identified, src_info.failed));
    fflush(stderr);

    return src_info.identified;
}

static int guess(const char *name,
    coral_protocol_t phy, coral_protocol_t datalink, int first)
{
    int i, j, identified = -1;

    coral_protocol_t atm_proto[] = {
	CORAL_DLT_ATM_RFC1483,
	CORAL_DLT_LANE_IEEE8023,
	CORAL_DLT_ILMI,
	CORAL_NETPROTO_IPv4,
	CORAL_NETPROTO_IPv6,
	0 };
    coral_protocol_t pos_proto[] = {
	CORAL_DLT_PPP,
	CORAL_DLT_CHDLC,
	0 };
    coral_protocol_t *likely_proto = NULL;

    clear_hash_table(subif_tab);
    max_blks = 10;
    coral_set_max_blks(max_blks);

    debug((stderr, "# guess(): %s, %s, ", name, coral_proto_abbr(phy)));
    debug((stderr, "%s, %d...\n", coral_proto_abbr(datalink), first));

    if (datalink != CORAL_PROTO_UNKNOWN) {
	identified = tryproto(name, phy, datalink, first);

    } else {
#if 1
	switch (phy) {
	    case CORAL_PHY_ATM:	likely_proto = atm_proto; break;
	    case CORAL_PHY_POS:	likely_proto = pos_proto; break;
	    default: likely_proto = NULL;
	}
#endif

	if (likely_proto) {
	    for (i = 0; likely_proto[i]; i++) {
		datalink = likely_proto[i];
		identified =
		    tryproto(name, phy, likely_proto[i], first);
		if (identified < 0) goto done;
		if (identified == num_hash_entries(subif_tab)) goto done;
	    }
	}

#if 1
	for (i = 0; coral_protolabel[i].abbr; ) {
	    /* skip protocols that don't make sense */
	    if (!coral_protolabel[i].proto_ok)
		goto next;
	    if (likely_proto) {
		for (j = 0; likely_proto[j]; j++)
		    if (coral_protolabel[i].id == likely_proto[j])
			goto next; /* already tried this proto */
	    }
	    /* try it */
	    datalink = coral_protolabel[i].id;
	    identified =
		tryproto(name, phy, coral_protolabel[i].id, first);
	    if (identified < 0) goto done;
	    if (identified == num_hash_entries(subif_tab)) goto done;
	    next: i++;
	}
#endif
    }

done:
    if (identified < 0) {
	int err = errno;
	debug((stderr, "guess error: %s\n", strerror(errno)));
	errno = err;
    }
    if (identified < 0 && errno <= 0)
	return 0;
    else
	return identified;
}

static void usage(const char *progname)
{
    fprintf(stderr, "usage: %s [-d] <file>\n", progname);
    fprintf(stderr, "\t-d\tdebug\n");
}

int main(int argc, char *argv[])
{
    int opt, first, identified;
    const char *name;
    char buf[BUFSIZ];
    struct stat statbuf;

    /*coral_set_iomode(0, CORAL_RX_UNKNOWN, -1, 1);*/
    coral_set_duration(-1); /* don't allow user to set */
    coral_set_api(CORAL_API_PKT);
    coral_set_options(0, CORAL_OPT_IGNORE_TIME_ERR);
    coral_config.dev_config.num_ifaces = 4; /* for dag */

    while ((opt = getopt(argc, argv, "d")) != -1) {
	switch (opt) {
	case 'd':
	    debug_flag = 1;
	    break;
	default:
	    usage(argv[0]);
	    exit(-1);
	}
    }

    if (!debug_flag)
	coral_set_errfilename("/dev/null");
    if (optind != argc - 1) {
	usage(argv[0]);
	exit(-1);
    }
    name = argv[optind];

    if (stat(name, &statbuf) < 0) {
	fprintf(stderr, "%s: %s\n", name, strerror(errno));
	exit(1);
    }

    if ((statbuf.st_mode & S_IFMT) != S_IFREG) {
	fprintf(stderr, "%s: not a regular file\n", name);
	exit(1);
    }

    subif_tab = init_hash_table("# subif table",
	compare_entries, make_entry_key, delete_entry, HASH_TABLE_SIZE);

    coral_cell_block_hook = cell_block_hook;

    /* try formats that can be autoidentified (crl, pcap) */
    if ((src = coral_new_source(name)) && coral_open(src) >= 0) {
	identified = guess(name,
	    coral_interface_get_physical(coral_next_interface(NULL)),
	    CORAL_PROTO_UNKNOWN, -1);
	if (identified > 0) goto succeed;
	goto fail; /* open was successful, so can't be any other format */
    }
    src = NULL;

    /* try other formats */

#if 1
    /* tsh is easy to confirm or deny with confidence */
    snprintf(buf, sizeof(buf), "tsh:%s", name);
    identified = guess(buf, CORAL_PROTO_UNKNOWN, CORAL_NETPROTO_IPv4, 36);
    if (identified > 0) goto succeed;
    if (identified < 0) goto fail;
#endif

    snprintf(buf, sizeof(buf), "dag:%s", name);
#if 1
    identified = guess(buf, CORAL_PHY_POS, CORAL_PROTO_UNKNOWN, 48);
    if (identified > 0) goto succeed;
    if (identified < 0) goto fail;
#endif
#if 1
    for (first = 48; first <= 15*48; first += 48) {
	identified = guess(buf, CORAL_PHY_ATM, CORAL_PROTO_UNKNOWN, first);
	if (identified > num_hash_entries(subif_tab) * 0.7)
	    goto succeed;
	if (identified < 0) goto fail;
    }
    identified = guess(buf, CORAL_PHY_ATM, CORAL_PROTO_UNKNOWN, 65535);
    if (identified > num_hash_entries(subif_tab) * 0.7)
	goto succeed;
    if (identified < 0) goto fail;
#endif
    if (identified > 0)
	goto succeed;

fail:
    printf("# %s: unknown\n\n", name);
    return(1);

succeed:
    {
	subif_info_t *info, **array;
	char iomode_buf[64];
	coral_iface_t *iface;
	int i, n;

	iface = coral_next_src_iface(src, NULL);
	coral_format_iomode(iomode_buf, &iface->iface_info.iomode);
	printf("\nsource=%s", src->name);
	printf(",nif=%d", src->dev_config.num_ifaces);
	if (coral_interface_get_physical(iface) != CORAL_PROTO_UNKNOWN)
	    printf(",phy=%s",
		coral_proto_str(coral_interface_get_physical(iface)));
	if (num_hash_entries(subif_tab) == 1)
	    printf(",proto=%s",
		coral_proto_str(coral_interface_get_datalink(iface)));
	printf(",%s\n", iomode_buf);

	if (num_hash_entries(subif_tab) > 1) {
	    array = malloc(sizeof(info) * num_hash_entries(subif_tab));
	    init_hash_walk(subif_tab);
	    for (n = 0; (info = next_hash_walk(subif_tab)); n++)
		array[n] = info;
	    qsort(array, n, sizeof(info), compare_entry_ptrs);
	    for (i = 0; i < n; i++) {
		info = array[i];
		coral_fmt_subif(buf, iface, info->subif_id);
		if (info->identified < 0)
		    printf("deny %s\n", buf);
		else {
		    printf("proto %s %s", buf, coral_proto_abbr(info->proto));
		    if (debug_flag)
			printf("\t\t# %.3f", info->score);
		    putchar('\n');
		}
	    }
	}
    }

    return(0);
}
