/* 
 * Copyright 2001, 2002, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program.  Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

#ifndef _TABLE_TYPES_H
#define _TABLE_TYPES_H

#include "config.h"
#include "crl_byteorder.h" // For crl_hton64()
#include "caida_t.h" // For uint64_t, etc.
#include <sys/param.h> // For htonl, etc
#include <netinet/in.h> // For in_addr
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h> // For inet_ntoa
#include <time.h> // For timespec
// This isn't standard.
// #include <hash_map> // For hash()
#include <functional> // For less() and equal_to()
#include <iomanip> // For setw()
#include <cstdarg> // For varargs in formatting structure
#include <cstdio> // For sprintf/sscanf

namespace {

inline unsigned short my_ntohs(unsigned short var) { return ntohs(var); }
inline unsigned long my_ntohl(unsigned long var) { return ntohl(var); }
inline unsigned short my_htons(unsigned short var) { return htons(var); }
inline unsigned long my_htonl(unsigned long var) { return htonl(var); }

template <class _TYPE>
inline std::ios::fmtflags alignment()
{
    return std::ios::right;
}

template <class _TYPE>
inline std::ios::fmtflags alignment(const _TYPE)
{
    return alignment<_TYPE>();
}

// Specializations to override default
template <> inline std::ios::fmtflags alignment<char *>()
{
    return std::ios::left;
}

template <> inline std::ios::fmtflags alignment<const char *>()
{
    return std::ios::left;
}

template <> inline std::ios::fmtflags alignment<in_addr>()
{
    return std::ios::left;
}

template <class _TYPE>
inline int var_width();

// Specializations for different-width types
template <> inline int var_width<uint64_t>()
{
    return 20;
}

template <> inline int var_width<uint16_t>()
{
    return 5;
}

template <> inline int var_width<in_addr>()
{
    return 15;
}

template <> inline int var_width<timespec>()
{
    return 20;
}

template<class _TYPE>
struct bin_munge
{
    virtual inline const _TYPE operator()(const _TYPE& var);
};

template<> struct bin_munge<uint8_t>
{
    inline const uint8_t operator()(const uint8_t& var)
	{ return var; }
};

template<> struct bin_munge<uint16_t>
{
    inline const uint16_t operator()(const uint16_t& var)
	{ return my_htons(var); } // Workaround gcc bug
};

template<> struct bin_munge<uint32_t>
{
    inline const uint32_t operator()(const uint32_t& var)
	{ return my_htonl(var); } // Workaround gcc bug
};

template<> struct bin_munge<uint64_t>
{
    inline const uint64_t operator()(const uint64_t& var)
	{ return crl_hton64(var); }
};

template<> struct bin_munge<in_addr>
{
    inline const in_addr operator()(const in_addr& var)
	{ return var; }
};

template<class _TYPE>
struct bin_unmunge
{
    virtual inline const _TYPE operator()(const _TYPE& var);
};

template<> struct bin_unmunge<uint8_t>
{
    inline const uint8_t operator()(const uint8_t& var)
	{ return var; }
};

template<> struct bin_unmunge<uint16_t>
{
    inline const uint16_t operator()(const uint16_t& var)
	{ return my_ntohs(var); } // Workaround gcc bug
};

template<> struct bin_unmunge<uint32_t>
{
    inline const uint32_t operator()(const uint32_t& var)
	{ return my_ntohl(var); } // Workaround gcc bug
};

template<> struct bin_unmunge<uint64_t>
{
    inline const uint64_t operator()(const uint64_t& var)
	{ return crl_ntoh64(var); }
};

template<> struct bin_unmunge<in_addr>
{
    inline in_addr operator()(in_addr var)
	{ return var; }
};

template <class _TYPE>
struct text_munge
{
    inline _TYPE operator()(_TYPE var)
    {
	return var;
    }
};

template<>
struct text_munge<timespec>
{
    inline const char * operator()(timespec var)
    {
	static char time_str[20];
	sprintf(time_str, "%lu.%09lu", var.tv_sec, var.tv_nsec);
	return time_str;
    }
};

template<>
struct text_munge<in_addr>
{
    inline const char * operator()(in_addr var)
    {
	return inet_ntoa(var);
    }
};

template <class _TYPE>
struct text_unmunge : public std::unary_function<_TYPE, _TYPE>
{
    inline _TYPE operator()(_TYPE var)
    {
	return var;
    }
};

template<>
struct text_unmunge<in_addr> : public std::unary_function<char[16], in_addr>
{
    inline in_addr operator()(char var[16])
    {
	in_addr ret_val;
	ret_val.s_addr = inet_addr(var);
	return ret_val;
    }
};

template<>
struct text_unmunge<timespec> : public std::unary_function<char[21], timespec>
{
    inline timespec operator()(char var[21])
    {
	timespec ret_val;
	sscanf(var, "%lu.%09lu", &ret_val.tv_sec, &ret_val.tv_nsec);
	return ret_val;
    }
};

template <class _TYPE>
inline void bin_write(std::ostream& out, const _TYPE& var)
{
    _TYPE temp;
    bin_munge<_TYPE> munger;

    temp = munger(var);
    out.write(reinterpret_cast<char*>(&temp), sizeof(temp));
}

template <> inline void bin_write<timespec>(std::ostream& out, const timespec& var)
{
    uint32_t temp;
    bin_munge<uint32_t> munger;
    // This code will break if tv_sec or tv_nsec is not 32 bits.  But in that
    // case, we need to come up with a new file format anyway.

    temp = var.tv_sec;
    temp = munger(temp);
    out.write(reinterpret_cast<char*>(&temp), sizeof(temp));
    temp = var.tv_nsec;
    temp = munger(temp);
    out.write(reinterpret_cast<char*>(&temp), sizeof(temp));
}

template <class _TYPE>
inline void bin_read(std::istream& in, _TYPE& var)
{
    _TYPE temp;
    bin_unmunge<_TYPE> unmunger;

    in.read(reinterpret_cast<char*>(&temp), sizeof(temp));
    var = unmunger(temp);
}

template <> inline void bin_read<timespec>(std::istream& in, timespec& var)
{
    uint32_t temp;
    bin_unmunge<uint32_t> unmunger;

    in.read(reinterpret_cast<char*>(&temp), sizeof(temp));
    var.tv_sec = unmunger(temp);
    in.read(reinterpret_cast<char*>(&temp), sizeof(temp));
    var.tv_nsec = unmunger(temp);
}

template <class _TYPE>
inline void text_write(std::ostream& out, _TYPE var, int width = -1)
{
    out.setf(alignment(var), std::ios::adjustfield);
    if (width >= 0) {
	out.width(width);
    } else {
	out.width(var_width<_TYPE>());
    }
    text_munge<_TYPE> munger;
    out << munger(var) << ' ';
}

template <class _TYPE>
inline void text_read(std::istream& in, _TYPE& var)
{
    text_unmunge<_TYPE> unmunger;
    typename text_unmunge<_TYPE>::argument_type temp;
    in >> temp;
    var = unmunger(temp);
}

template <class _TYPE>
struct format : public std::vector<_TYPE>
{
    format(int num, ...)
    {
	va_list args;
	va_start(args, num);
	for (int i = 0; i < num; i++) {
	    _TYPE next;
	    next = va_arg(args, _TYPE);
	    push_back(next);
	}
	va_end(args);
    }
};

} // end anonymous namespace

inline bool operator < (const timespec& a, const timespec& b)
{
    return (a.tv_sec == b.tv_sec) ? (a.tv_nsec < b.tv_nsec) :
				    (a.tv_sec < b.tv_sec);
}

///////////////
// Public API
///////////////

namespace Table {

// Keys

struct tuple_t
{
    in_addr src;
    in_addr dst;
    uint8_t ip_proto;
    uint8_t ports_ok;
    uint16_t sport;
    uint16_t dport;
    tuple_t() : ports_ok(false), sport(0), dport(0) {}
    uint8_t size() const
    {
	return 2*sizeof(in_addr) + 2*sizeof(uint8_t) + 2*sizeof(uint16_t);
    }
    static void write_header(std::ostream& outfile)
    {
	outfile << "src            dst             proto ok sport dport";
    }
    void save_binary(std::ostream& outfile) const
    {
	bin_write(outfile, src);
	bin_write(outfile, dst);
	bin_write(outfile, ip_proto);
	bin_write(outfile, ports_ok);
	bin_write(outfile, sport);
	bin_write(outfile, dport);
    }
    void save_text(std::ostream& outfile) const
    {
	text_write(outfile, src);
	text_write(outfile, dst);
	text_write(outfile, static_cast<uint16_t>(ip_proto), 5);
	text_write(outfile, static_cast<uint16_t>(ports_ok), 2);
	text_write(outfile, sport);
	text_write(outfile, dport);
    }
    void load_binary(std::istream& infile)
    {
	bin_read(infile, src);
	bin_read(infile, dst);
	bin_read(infile, ip_proto);
	bin_read(infile, ports_ok);
	bin_read(infile, sport);
	bin_read(infile, dport);
    }
    void load_text(std::istream& infile)
    {
	uint16_t tmp_proto, tmp_ports_ok;
	text_read(infile, src);
	text_read(infile, dst);
	text_read(infile, tmp_proto);
	ip_proto = static_cast<uint8_t>(tmp_proto);
	text_read(infile, tmp_ports_ok);
	ports_ok = static_cast<uint8_t>(tmp_ports_ok);
	text_read(infile, sport);
	text_read(infile, dport);
    }
    static const char * type() { return "tuple_t"; }
};

struct proto_ports_t
{
    uint8_t ip_proto;
    uint8_t ports_ok;
    uint16_t sport;
    uint16_t dport;
    proto_ports_t() : ports_ok(false), sport(0), dport(0) {}
    uint8_t size() const
    {
	return sizeof(struct proto_ports_t);
    }
    static void write_header(std::ostream& outfile)
    {
	outfile << " proto ok sport dport";
    }
    void save_binary(std::ostream& outfile) const
    {
	bin_write(outfile, ip_proto);
	bin_write(outfile, ports_ok);
	bin_write(outfile, sport);
	bin_write(outfile, dport);
    }
    void save_text(std::ostream& outfile) const
    {
	text_write(outfile, static_cast<uint16_t>(ip_proto), 5);
	text_write(outfile, static_cast<uint16_t>(ports_ok), 2);
	text_write(outfile, sport);
	text_write(outfile, dport);
    }
    void load_binary(std::istream& infile)
    {
	bin_read(infile, ip_proto);
	bin_read(infile, ports_ok);
	bin_read(infile, sport);
	bin_read(infile, dport);
    }
    void load_text(std::istream& infile)
    {
	uint16_t tmp_proto, tmp_ports_ok;
	text_read(infile, tmp_proto);
	ip_proto = static_cast<uint8_t>(tmp_proto);
	text_read(infile, tmp_ports_ok);
	ports_ok = static_cast<uint8_t>(tmp_ports_ok);
	text_read(infile, sport);
	text_read(infile, dport);
    }
    static const char * type() { return "proto_ports_t"; }
};

struct len_t
{
    uint16_t length;
    len_t() : length(0) {}
    uint8_t size() const
    {
	return sizeof(struct len_t);
    }
    static void write_header(std::ostream& outfile)
    {
	outfile << " length";
    }
    void save_binary(std::ostream& outfile) const
    {
	bin_write(outfile, length);
    }
    void save_text(std::ostream& outfile) const
    {
	text_write(outfile, length, 8);
    }
    void load_binary(std::istream& infile)
    {
	bin_read(infile, length);
    }
    void load_text(std::istream& infile)
    {
	text_read(infile, length);
    }
    static const char * type() { return "len_t"; }
};

struct ip_pair_t
{
    in_addr src;
    in_addr dst;
    uint8_t size() const
    {
	return sizeof(struct ip_pair_t);
    }
    void load_binary(std::istream& infile)
    {
	bin_read(infile, src);
	bin_read(infile, dst);
    }
    void load_text(std::istream& infile)
    {
	text_read(infile, src);
	text_read(infile, dst);
    }
    static const char * type() { return "ip_pair_t"; }
};

struct ip_t
{
    in_addr addr;
    uint8_t size() const
    {
	return sizeof(struct ip_t);
    }
    static void write_header(std::ostream& outfile)
    {
	outfile << "ip_addr       ";
    }
    void save_binary(std::ostream& outfile) const
    {
	bin_write(outfile, addr);
    }
    void save_text(std::ostream& outfile) const
    {
	text_write(outfile, addr);
    }
    void load_binary(std::istream& infile)
    {
	bin_read(infile, addr);
    }
    void load_text(std::istream& infile)
    {
	text_read(infile, addr);
    }
    static const char * type() { return "ip_t"; }
};

// Counters

struct simp_cntr
{
    uint64_t tuples;
    uint64_t pkts;
    uint64_t bytes;
    simp_cntr() : tuples(0), pkts(0), bytes(0) {}
    uint8_t size() const
    {
	return 3*sizeof(uint64_t);
    }
    static void write_header(std::ostream& outfile)
    {
	outfile << "  tuples            pkts              bytes";
    }
    void save_binary(std::ostream& outfile) const
    {
	bin_write(outfile, tuples);
	bin_write(outfile, pkts);
	bin_write(outfile, bytes);
    }
    void save_text(std::ostream& outfile) const
    {
	text_write(outfile, tuples, 7);
	text_write(outfile, pkts, 15);
	text_write(outfile, bytes, 18);
    }
    void load_binary(std::istream& infile)
    {
	bin_read(infile, tuples);
	bin_read(infile, pkts);
	bin_read(infile, bytes);
    }
    void load_text(std::istream& infile)
    {
	text_read(infile, tuples);
	text_read(infile, pkts);
	text_read(infile, bytes);
    }

    simp_cntr& add(const simp_cntr& other)
    {
	tuples += other.tuples;
	pkts += other.pkts;
	bytes += other.bytes;
	return *this;
    }
    static const char * type() { return "simp_cntr"; }
};

struct tuple_cntr : public simp_cntr
{
    timespec first;
    timespec latest;
    tuple_cntr() : simp_cntr() {}
    uint8_t size() const
    {
	return simp_cntr::size() + 4*sizeof(uint32_t);
    }
    static void write_header(std::ostream& outfile)
    {
	simp_cntr::write_header(outfile);
	outfile << "                first               latest";
    }
    void save_binary(std::ostream& outfile) const
    {
	simp_cntr::save_binary(outfile);

	bin_write(outfile, first);
	bin_write(outfile, latest);
    }
    void save_text(std::ostream& outfile) const
    {
	simp_cntr::save_text(outfile);
	text_write(outfile, first);
	text_write(outfile, latest);
    }
    void load_binary(std::istream& infile)
    {
	simp_cntr::load_binary(infile);

	bin_read(infile, first);
	bin_read(infile, latest);
    }
    void load_text(std::istream& infile)
    {
	simp_cntr::load_text(infile);
	text_read(infile, first);
	text_read(infile, latest);
    }
    tuple_cntr& add(const tuple_cntr& other)
    {
	simp_cntr::add(other);
	first = min(first, other.first, std::less<timespec>());
	latest = max(latest, other.latest, std::less<timespec>());
	return *this;
    }
    static const char * type() { return "tuple_cntr"; }
};

} // end namespace Table

// External helper functions (for STL containers)

namespace std {

// Currently undefined until we make sure hash_map/etc exist
/*
struct hash<Table::tuple_t>
{
    inline size_t operator()(const Table::tuple_t& _obj) const
    {
	return (size_t) _obj.src.s_addr * 59 + _obj.dst.s_addr +
	    _obj.ip_proto + ((size_t)_obj.dport<<16) + _obj.sport;
    }
};
*/

inline bool operator < (const Table::tuple_t& _obj1,
			const Table::tuple_t& _obj2)
{
    return (_obj1.sport != _obj2.sport ? _obj1.sport < _obj2.sport :
	    _obj1.dport != _obj2.dport ? _obj1.dport < _obj2.dport :
	    _obj1.src.s_addr != _obj2.src.s_addr ?
				    _obj1.src.s_addr < _obj2.src.s_addr :
	    _obj1.dst.s_addr != _obj2.dst.s_addr ?
				    _obj1.dst.s_addr < _obj2.dst.s_addr :
	    _obj1.ip_proto != _obj2.ip_proto ?
				    _obj1.ip_proto < _obj2.ip_proto :
	    _obj1.ports_ok < _obj2.ports_ok);
}

template<>
struct equal_to<Table::tuple_t>
{
    inline bool operator()(const Table::tuple_t& _obj1,
			    const Table::tuple_t& _obj2) const
    {
	return (_obj1.sport == _obj2.sport &&
		_obj1.dport == _obj2.dport &&
		_obj1.src.s_addr == _obj2.src.s_addr &&
		_obj1.dst.s_addr == _obj2.dst.s_addr &&
		_obj1.ip_proto == _obj2.ip_proto &&
		_obj1.ports_ok == _obj2.ports_ok);
    }
};

// Currently undefined until we make sure hash_map/etc exist
/*
struct hash<Table::proto_ports_t>
{
    inline size_t operator()(const Table::proto_ports_t& _obj) const
    {
	return (size_t) _obj.ip_proto + ((size_t)_obj.dport<<16) + _obj.sport;
    }
};
*/

inline bool operator < (const Table::proto_ports_t& _obj1,
			const Table::proto_ports_t& _obj2)
{
    return (_obj1.sport != _obj2.sport ? _obj1.sport < _obj2.sport :
	    _obj1.dport != _obj2.dport ? _obj1.dport < _obj2.dport :
	    _obj1.ip_proto != _obj2.ip_proto ?
				    _obj1.ip_proto < _obj2.ip_proto :
	    _obj1.ports_ok < _obj2.ports_ok);
}

template<>
struct equal_to<Table::proto_ports_t>
{
    inline bool operator()(const Table::proto_ports_t& _obj1,
			    const Table::proto_ports_t& _obj2) const
    {
	return (_obj1.sport == _obj2.sport &&
		_obj1.dport == _obj2.dport &&
		_obj1.ip_proto == _obj2.ip_proto &&
		_obj1.ports_ok == _obj2.ports_ok);
    }
};

// Currently undefined until we make sure hash_map/etc exist
/*
struct hash<Table::len_t>
{
    inline size_t operator()(const Table::len_t& _obj) const
    {
	return (size_t) _obj.length;
    }
};
*/

inline bool operator < (const Table::len_t& _obj1, const Table::len_t& _obj2)
{
    return (_obj1.length < _obj2.length);
}

template<>
struct equal_to<Table::len_t>
{
    inline bool operator()(const Table::len_t& _obj1,
			    const Table::len_t& _obj2) const
    {
	return (_obj1.length == _obj2.length);
    }
};

// Currently undefined until we make sure hash_map/etc exist
/*
struct hash<Table::ip_pair_t>
{
    inline size_t operator()(const Table::ip_pair_t& _obj) const
    {
	return (size_t) _obj.src.s_addr * 59 + _obj.dst.s_addr;
    }
};
*/

template<>
struct equal_to<Table::ip_pair_t>
{
    inline bool operator()(const Table::ip_pair_t& _obj1,
			    const Table::ip_pair_t& _obj2) const
    {
	return (_obj1.src.s_addr == _obj2.src.s_addr &&
		_obj1.dst.s_addr == _obj2.dst.s_addr);
    }
};

// Currently undefined until we make sure hash_map/etc exist
/*
struct hash<Table::ip_t>
{
    inline size_t operator()(const Table::ip_t& _obj) const
    {
	return (size_t) _obj.addr.s_addr;
    }
};
*/

template<>
struct equal_to<Table::ip_t>
{
    inline bool operator()(const Table::ip_t& _obj1,
			    const Table::ip_t& _obj2) const
    {
	return (_obj1.addr.s_addr == _obj2.addr.s_addr);
    }
};

} // end namespace std

#endif // _TABLE_TYPES_H
