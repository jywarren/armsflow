/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/* $Id: crl_portsummary.c,v 1.33 2007/06/06 18:17:32 kkeys Exp $ */


static const char RCSid[]="$Id: crl_portsummary.c,v 1.33 2007/06/06 18:17:32 kkeys Exp $";

#include "config.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <assert.h>
#include <limits.h>
#include <sys/types.h>
#include DB_H
#include <sys/stat.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <netinet/in_systm.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <netinet/ip_icmp.h>
#include <netinet/igmp.h>

/* Solaris crap */
#ifndef IP_OFFMASK
#define IP_OFFMASK 0x1FFF
#endif

#ifndef errno
extern int errno;
#endif

/* Get the special structures used for handling coral format files. */
#include "libcoral.h"


/* "key" structure for hashtable mapping a set of summarized information
   to the number of packets which match it. */
struct summary_info {
    u_short	interface;
    u_char	ip_proto;
    u_char	ports_ok;
    u_short	sport;
    u_short	dport;
    short	plen;
};


/* #### unsigned long long would be better for overflow, but was
   having trouble with either the `rawdata.bytes +=' or the `%llf'
   printf format. */
struct raw_data {
    unsigned long packets;
};


/* #### This should probably be unsigned long long too. */
static double total_packets;
static double inserted_packets;

static int dumpRate = 50;

static u_int blockCount = 0;
static DB *matrix = NULL;
static HASHINFO hashinfo;

static int rawDB_insert(DB *rawDB, coral_iface_t *iface,
    coral_pkt_buffer_t *pkt)
{
    DBT keyDBT;
    DBT dataDBT;
    struct summary_info key;
    struct raw_data rawdata;
    int ihl;
    short offset;
    int result;
    coral_pkt_buffer_t ip_pkt;
    struct ip *ip_header;
    const char *transport_header;

    if (coral_get_payload_by_proto(pkt, &ip_pkt, CORAL_NETPROTO_IP) < 0)
	return 0;

    ip_header = (struct ip*)ip_pkt.buf;
    ihl = ip_header->ip_hl * 4;
    offset = ntohs(ip_header->ip_off) & IP_OFFMASK;

    /* warn if this packet is not ip v4 */
    if (ip_header->ip_v != 4) {
	fprintf(stderr, "unexpected ip version: %d\n", (int)ip_header->ip_v);
    }

    /* Set the key to the source/destination address pair. */
    key.interface = coral_interface_get_number(iface);
    key.ip_proto = ip_header->ip_p;
    key.ports_ok = 0;
    key.sport = 0;
    key.dport = 0;
    key.plen = ntohs(ip_header->ip_len);

    transport_header = ip_pkt.buf + ihl;

    if (ip_header->ip_p == IPPROTO_TCP) {
	if (!offset && ihl <= 36) {
	    struct tcphdr *t = (struct tcphdr*)transport_header;

	    key.sport = ntohs(t->th_sport);
	    key.dport = ntohs(t->th_dport);
	    key.ports_ok = 1;
	}
    } else if  (ip_header->ip_p == IPPROTO_UDP) {
	if (!offset && ihl <= 36) {
	    struct udphdr *u = (struct udphdr*)transport_header;

	    key.sport = ntohs(u->uh_sport);
	    key.dport = ntohs(u->uh_dport);
	    key.ports_ok = 1;
	}
    } else if  (ip_header->ip_p == IPPROTO_ICMP) {
        if (!offset && ihl <= 38) {
            struct icmp *u = (struct icmp*)transport_header;

            key.sport = (u_short) u->icmp_type;
            key.dport = (u_short) u->icmp_code;
            key.ports_ok = 1;
        }
    } else if  (ip_header->ip_p == IPPROTO_IGMP) {
        if (!offset && ihl <= 38) {
            struct igmp *u = (struct igmp*)transport_header;

            key.sport = (u_short) u->igmp_type;
            key.dport = (u_short) u->igmp_code;
            key.ports_ok = 1;
        }
    }

    keyDBT.data = &key;
    keyDBT.size = sizeof(key);

    /* Read the current value out of the database. */
    result = rawDB->get(rawDB, &keyDBT, &dataDBT, 0);
    if (result == 0 && dataDBT.size == sizeof(rawdata)) {
	/* already existing entry */
	memcpy(&rawdata, dataDBT.data, sizeof(rawdata));
    } else if (result == 1) {
	/* new entry */
	rawdata.packets = 0;
inserted_packets++;
    } else {
	/* error case */
	fprintf(stderr, "rawDB->get failed: %s\n",
		strerror(errno));
	return -1;
    }

    /* Increment the counters. */
    rawdata.packets++;
    total_packets++;

    /* Write it out. */
    dataDBT.data = &rawdata;
    dataDBT.size = sizeof(rawdata);
    result = rawDB->put(rawDB, &keyDBT, &dataDBT, 0);
    if (result != 0) {
	fprintf(stderr, "rawDB->put %f failed: %s\n",
	        total_packets, strerror(errno));
	return -1;
    }

    return 0;
}


static int dumpDB(DB *rawDB, FILE *outFile)
{
    DBT keyDBT;
    DBT dataDBT;
    u_int which = R_FIRST;
    struct summary_info *key_ptr;
    struct raw_data *rawdata_ptr;
    int result;

    while ((result = rawDB->seq(rawDB, &keyDBT, &dataDBT, which)) == 0) {
	/* #### should check the lengths are right. */
	key_ptr = keyDBT.data;
	rawdata_ptr = dataDBT.data;
	
	fprintf(outFile, "%u\t%u\t%u\t%u\t%u\t%d\t%lu\n",
		(unsigned) key_ptr->interface, 
		(unsigned) key_ptr->ip_proto,
		(unsigned) key_ptr->ports_ok,
		(unsigned) key_ptr->sport,
		(unsigned) key_ptr->dport,
		(int) key_ptr->plen,
		rawdata_ptr->packets);

	/* Get the next database item. */
	which = R_NEXT;
    }

    if (result != 1) {
	fprintf(stderr, "rawDB->seq failed: %s\n",
		strerror(errno));
	return -1;
    }
    
    return 0;
}

static int closeDB(DB **rawDB_ptr)
{
    DB *rawDB = *rawDB_ptr;
    int result = 0;

    if (rawDB && rawDB->close(rawDB) == -1) {
	fprintf(stderr, "rawDB->close failed: %s\n",
		strerror(errno));
	result = -1;
    }
    
    *rawDB_ptr = NULL;
    return result;    
}

static void pkthandler(coral_iface_t *iface, const coral_timestamp_t *ts,
    void *user, coral_pkt_buffer_t *pkt, coral_pkt_buffer_t *header,
    coral_pkt_buffer_t *trailer)
{
	/* Dump and close existing db periodically to prevent from
	   growing too large, and keeping an output stream moving. */
	if (matrix && (blockCount % dumpRate == 0)) {
	    if (dumpDB(matrix, stdout) == -1) exit(errno);
	    if (closeDB(&matrix) == -1) exit(errno);
	}

	/* Setup hash table for this set of blocks, if needed. */
	if (!matrix) {
	    matrix = dbopen(NULL, O_RDWR|O_CREAT, 0644, DB_HASH, &hashinfo);
	}

	blockCount++;

	/* Add packet to the summary. */
	if (rawDB_insert(matrix, iface, pkt) == -1)
	    exit(errno);
}

int main (int argc, char *argv[])
{
    int retval = 0;
    coral_source_t *src;

    total_packets = 0;

    coral_set_api(CORAL_API_PKT);
    coral_set_options(0, CORAL_OPT_PARTIAL_PKT);
    coral_set_duration(0);
    coral_set_max_sources(1);

    if (coral_config_arguments(argc, argv) < 0)
        exit(-1);

    /* Create an in-memory temporary db to hold a mapping from struct
       ip's to raw_data's.  We use all of the default values, except
       increase the cachesize to 10MB. */
    hashinfo.bsize = 256;
    hashinfo.bsize = 4096; /* XXX */
    hashinfo.ffactor = 8;
    hashinfo.ffactor = 128; /* XXX */
    hashinfo.nelem = 1;
    hashinfo.cachesize = 10*1024*1024;
    hashinfo.hash = NULL;
    hashinfo.lorder = 0;

    if (!(src = coral_next_source(NULL)))
        exit(-1);
    if (coral_open(src) < 0)
        exit(0);
    if (coral_start(src) < 0)
        exit(0);

    if (coral_read_pkts(src, NULL, pkthandler, NULL, NULL, 0, NULL) < 0)
	retval = errno;

    /* Dump and close any partial remaing db. */
    if (matrix) {
	if (dumpDB(matrix, stdout) == -1) exit(errno);
	if (closeDB(&matrix) == -1) exit(errno);
    }

    coral_stop_all();
    coral_close_all();
    exit(retval);
}
