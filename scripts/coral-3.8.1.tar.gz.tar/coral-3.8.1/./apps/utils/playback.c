/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 * playback.c - Coral playback program.  Allows use of Coral devices as packet
 *              generators. (only fatm oc3 for now)
 *
 * $Id: playback.c,v 1.52 2007/06/06 18:17:37 kkeys Exp $
 *
 */

static const char RCSid[]="$Id: playback.c,v 1.52 2007/06/06 18:17:37 kkeys Exp $";

#include "config.h"

#include <stdio.h>
#include <limits.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>

#include <fcntl.h>
#include <signal.h>
#include <sys/ioccom.h>

#include "libcoral.h"


/* repeat count and cell to be sent
 * - this is ultimately passed to the card
 */
struct tracerec_send {
    u_int count;             /* BE number of times to send */
    union atm_hdr cu;
    u_char celldata[48];     /* cell contents */
};

/* how cells to transmit are stored on disk (always big-endian byte ordering)
 */
/* format of input file is same as the dos input file,
 * described in integrat/trace.h
 */
struct traceblock_send {
    u_int used; /* BE */
    u_char cardindex;
    char padding[ 512 - sizeof(char) - sizeof(int) ];
};

int done;
static void fp (int sig)
{
    return;
}

static void imdone(int sig)
{
    switch (sig) {
    case SIGINT:
	done = 1;
	break;
    case SIGTSTP:
    case SIGALRM:
	done = 2;
	break;
    }
}

int protocell[14] = { 
    0x00440000,		/* repeat count, BE */
    0x02040000,		/* atm header */
    0x0003aaaa,		/* llc/snap */
    0x00800000,		/* llc/snap */

    0x20000045,		/*  */
    0x00009c00,		/*  */
    0x04581140,		/*  */
    0x0807110a,		/* ip.src */

    0x0407110a,		/* ip.dst */
    0x10270004,		/*  */
    0x97e00c00,		/*  */
    0x000000d2,		/*  */

    0x28000000,		/*  */
    0x6aae9a30		/*  */
};

int main(int argc, char *argv[])
{
    int card_index;
    coral_source_t *src;
    int err;
    int errcnt = 0;
    u_int cell_i = 0;
    struct tracerec_send *record;
    char filename[PATH_MAX+1];
    u_int vpi = 42, vci;

    if (argc < 2 || argc > 4) {
	fprintf( stderr, "\n" );
	fprintf( stderr, "usage: %s board-index [vpi] [vci]\n", argv[0]);
	fprintf( stderr, "\n" );
	return 1;
    }
    if (1 != sscanf(argv[1], "%d", &card_index)) {
	fprintf(stderr, "unable to convert cardindex '%s' to integer\n",
		argv[1]);
	return 4;
    }
    if (argc > 2) {
        if (1 != sscanf(argv[2], "%d", &vpi)) {
	    fprintf(stderr, "unable to convert vpi '%s' to integer\n",
		    argv[2]);
	    return 4;
        }
    }
    if (argc > 3) {
        if (1 != sscanf(argv[3], "%d", &vci)) {
	    fprintf(stderr, "unable to convert vci '%s' to integer\n",
		    argv[3]);
	    return 4;
        }
    } else
	vci = 100 + card_index;

    fprintf(stderr, "opening card index %d to send on %d:%d\n", card_index, 
	    vpi, vci);

    signal(SIGFPE, fp);
    signal(SIGINT, imdone);
    /*signal(SIGTSTP, imdone);*/

    sprintf(filename, "/dev/fatm%d", card_index);
    src = coral_new_source(filename);
    coral_source_set_iomode(src, CORAL_RX, CORAL_TX, -1);
    coral_source_set_firmware(src, FATM_FW);
    if (coral_open(src) < 0) {
	exit(-1);
    }

    record = (struct tracerec_send *)BLK_IDX_TO_ADR(0, coral_base(src),
	FATM_BLK_SIZE, FATM_NUM_BLKS);
    memcpy(record, protocell, sizeof(protocell));

    record->cu.ui = ntohl(record->cu.ui);
    set_vpvc_vp(record->cu.h.vpvc, vpi);
    set_vpvc_vc(record->cu.h.vpvc, vci);
    record->cu.ui = htonl(record->cu.ui);

    record->count = htonl(1<<30);

    while (done != 1) {

	/*((int*)record)[13] = htonl(cell_i++);*/
	cell_i++;

	err = coral_sendblk(src, 1);
	if (err) {
	    fprintf(stderr, "sendblk failed (%d) at %d: %s\n", errcnt,
		    cell_i, strerror(errno));
	}
	sleep(5);
    }
    coral_stop(src);
    coral_close(src);
    return 0;
}

