/* 
 * Copyright 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 *
 * $Id: crl_portmap.c,v 1.40 2007/06/06 18:17:31 kkeys Exp $
 *
 */

#include "config.h"
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <signal.h>
#include <errno.h>

#ifndef HAVE_BPF_FILTER
int main(int argc, char *argv[])
{
    fprintf(stderr, "%s: this application requires bpf filtering, "
	"which is not supported in this installation of CoralReef.\n",
	argv[0]);
    return -1;
}
#else

#include <sys/types.h>
#include <netinet/in_systm.h>
#define __KERNEL__
#include <sys/socket.h>
#undef __KERNEL__
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>

/* To do:
 * 1) wire in new filter junk (UDP)
 */

#include <pcap.h>
#include "libcoral.h"

#define CALL 0

/*
 * filter buffer
 */
char Cmdbuf[16384];
/*
 * Base filter for the monitor.  Can be modified to limit
 *      traffic under consideration.
 */
char dcmdbuf[]="port 111";

void new_filter(void);
void mk_new_filter(u_int,u_int);
RETSIGTYPE reset_filter(int);

pcap_t *pcap;
coral_iface_t *iface;
pcap_dumper_t *pcap_dumper = NULL;
struct bpf_program fcode;
char filt_buf[1024];
int optimize=0;
unsigned int netmask=0xffffff00;

static void quit(int sig)
{
    coral_pkt_done = 1;
}

static void pkthandler(coral_iface_t *crlif, const coral_timestamp_t *timestamp,
    void *userdata, coral_pkt_buffer_t *packet, coral_pkt_buffer_t *header,
    coral_pkt_buffer_t *trailer)
{
    struct ip *ip;
    struct tcphdr *tcp;
    struct udphdr *up;
    int dport, sport, flags, hlen, off;
    int *ptr;

    if (pcap_dumper) {
	int offset;
	struct pcap_pkthdr pphr;
	offset = coral_pkt_to_pcap(crlif, timestamp, packet, pcap, &pphr);
	if (offset >= 0)
	    pcap_dump((u_char *)pcap_dumper, &pphr,
		(u_char *)packet->buf + offset);
    }

    /* XXX should use coral_get_payload_by_proto() */
    ip = (struct ip *)(packet->buf+8);
    hlen = ip->ip_hl * 4;
    off = ntohs(ip->ip_off);
    if ( off & 0x1fff ) return;

    /* XXX should use coral_get_payload() */
    switch ( ip->ip_p ) {
    case IPPROTO_TCP:
	tcp = (struct tcphdr *)(ip+1);
	dport = ntohs(tcp->th_dport);
	sport = ntohs(tcp->th_sport);
	flags = tcp->th_flags;

	if ( dport == 111 && (flags&(TH_SYN|TH_ACK)) == TH_SYN )
		mk_new_filter(ip->ip_src.s_addr,ip->ip_dst.s_addr);
	break;
    case IPPROTO_UDP:
	up = (struct udphdr *)(ip+1);

        sport = ntohs(up->uh_sport);
        dport = ntohs(up->uh_dport);
        ptr = (int *)(up + 1);

/* req:
 * ptr[0] = XID
 * ptr[1] = direction
 * ptr[2] != 0 rpcvers
 * ptr[3] != 0 prog
 * ptr[4] pvers
 * ptr[5] proc
 */
	{
	unsigned int ptr1 = ntohl(ptr[1]);
	unsigned int ptr2 = ntohl(ptr[2]);
	unsigned int ptr3 = ntohl(ptr[3]);
	unsigned int ptr5 = ntohl(ptr[5]);

        /* if start of a portmapper request, grab data from that host */
        if ( dport == 111 && ptr1 == CALL && ptr2 !=0 && ptr3 != 0 ) {
#if 0
		unsigned int ptr10 = ntohl(ptr[10]);
                /*remedy crap + walld + ???*/
                if ( ptr3==100000 && ( ptr10 == 390600 || ptr10 == 390601
                                          || ptr10 == 390604
                                          || ptr10 == 314159                                                            || ptr10 == 0x186a8
                                          || ptr10 == 0x5f762
                                          || ptr10 == 100
                                          || ptr10 == 0x2222222
                        ) ) return;
#endif
                if ( !ptr5 ) return; /* no null calls */
                mk_new_filter(ip->ip_src.s_addr,ip->ip_dst.s_addr);
        }

	}



	/* stuff */
	break;
    }
}

int main(int argc, char *argv[])
{
    int n, opt;
    const char *ofname=NULL;
    int retval = 0;

    signal(SIGINT, quit);

    coral_set_api(CORAL_API_PKT);
#if 0
    coral_set_max_sources(1);  /* There can be only one */
#endif
    coral_set_duration(0);

    while ((opt = getopt(argc, argv, "C:o:pP")) >= 0) {
        if (opt == 'C') {
            if (coral_config_command(optarg) < 0)
                exit(-1);
        } else if (opt == 'P') {
	    coral_set_options(CORAL_OPT_PARTIAL_PKT, 0);
        } else if (opt == 'o') {
	    ofname = strdup(optarg);
        } else {
            coral_usage(argv[0], "[-o <dumpfile>] [-P] <source>...\n"
		"-o <dumpfile>  dump matches to pcap file <dumpfile>\n"
		"-P             do not allow partial packets\n");
            exit(-1);
        }
    }

    while (optind < argc) {
        if (!coral_new_source(argv[optind]))
            exit(-1);
        optind++;
    }

    /* coral_source_set_iomode_all(0, CORAL_RX_UNKNOWN, -1); */
    if ((n = coral_open_all()) < 0)
        exit(-1);
    if (n == 0) {
	coral_diag(0, ("no sources.\n"));
	exit(0);
    }

    if (coral_start_all() < 0)
        exit(-1);

    iface = coral_next_interface(NULL);
    pcap = coral_iface_to_pcapp_raw(iface);
    if (!pcap) {
	coral_diag(0, ("%s\n", strerror(errno)));
	exit(-1);
    }
    
    strcpy(Cmdbuf,dcmdbuf);

    if (coral_pcap_compile(iface, &fcode, Cmdbuf, optimize, netmask) < 0)
	exit(-1);
    if (coral_pcap_setfilter(iface, &fcode) < 0)
	exit(-1);

    if (ofname) {
	pcap_dumper = pcap_dump_open(pcap, ofname);
	if (!pcap_dumper)
	    coral_diag(0, ("%s: %s\n", ofname, pcap_geterr(pcap)));
    }

    if (coral_read_pkts(NULL, NULL, pkthandler, NULL, NULL, NULL, NULL) < 0)
	retval = errno;

    if (pcap_dumper)
	pcap_dump_close(pcap_dumper);
    coral_stop_all();
    coral_close_all();
    return retval;
}

int hcount=0,hlist[256];

void
mk_new_filter(u_int i, u_int j)
{
	int l;
	struct in_addr foo;

#if 0
printf("MNF %d %x %x\n",hcount,i,j);
#endif
	/* are we full ? */
	if ( hcount >= 256 ) {
		fprintf(stderr, "Filter table is full!!\n");
		return;
	}

#if 0
	/* XXX: high volume hosts need anti-sense orientation */
	if ( i == 0x84f92820 || i == 0x84f92830 || i == 0x84f92837 ||
	     i == 0xc6112e3b || i == 0xc6112e3a || i == 0x84ef5e5b ) {
		printf("ASO: %x\n",i);
		i=j;
	}

	/* localhost cruft */
	/* ruby.oce.orst.edu cruft */
	if ( j == 0x7f000001 || j == 0x80c14036 ) return;

	/* nix AMPR stuff */
	if ( (i>>24) & 0xff == 0x44 ) return;
#endif

	/* check for duplicate */
	for (l=0; l<hcount; l++)
		if ( hlist[l] == i ) return;
	hlist[hcount] = i; hcount++;

	/* tag onto current filter */
	strcat(Cmdbuf," or ( ip and host ");
#if 0
printf("MNF IN2A\n");
#endif
	foo.s_addr = i;
	strcat(Cmdbuf,(char *)inet_ntoa(foo));
#if 0
printf("MNF IN2A XXX\n");
#endif
	strcat(Cmdbuf," )");
#if 0
printf("MNF Call NF\n");
#endif
	new_filter();
}


/*
 * compile and install new filter
 */
void
new_filter(void)
{
	fprintf(stderr, "Filter = %s\n",Cmdbuf);
	fflush(stderr);
        if (coral_pcap_compile(iface, &fcode, Cmdbuf, optimize, netmask) < 0)
                return;
        if (coral_pcap_setfilter(iface, &fcode) < 0)
                return;
}


/*
 * Upon timeout (no packets for 5 min.), reset to original filter
 */
RETSIGTYPE
reset_filter(int signo)
{
	(void)signal(SIGALRM, reset_filter);

	strcpy(Cmdbuf,dcmdbuf);
	fprintf(stderr, "Reset ");
	new_filter();
	hcount=0;
}

#endif /* HAVE_BPF_FILTER */
