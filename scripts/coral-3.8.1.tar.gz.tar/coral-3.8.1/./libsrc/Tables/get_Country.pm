## 
## Copyright 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
## All Rights Reserved 
## 
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
## 
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
## 
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
## 
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
## 
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program. Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
## 
## Report bugs and suggestions to coral-bugs@caida.org.
## 

package CAIDA::Tables::get_Country;
require Exporter;
@ISA = qw(Exporter);
@EXPORT = qw(&_get_locs_byIP &_get_locs_byAS &_get_locs_byCountry);

# Define required CVS variables
$cvs_Id = '$Id: get_Country.pm,v 1.23 2007/06/07 18:49:39 rkoga Exp $';
$cvs_Author = '$Author: rkoga $';
$cvs_Name = '$Name: release-3-8-1 $';
$cvs_Revision = '$Revision: 1.23 $';


use Carp;
use File::Temp qw(tempfile);
use strict;

my @unknown = (0,0);
    
my %as_to_loc;
my %country_to_loc;

$as_to_loc{'MCAST'} = ['MCAST', @unknown];
$as_to_loc{'NOROUTE'} = ['NOROUTE', @unknown];
$country_to_loc{'MCAST'} = ['MCAST', @unknown];
$country_to_loc{'NOROUTE'} = ['NOROUTE', @unknown];
$country_to_loc{'UNKNOWN'} = ['UNKNOWN', @unknown];

# NB:  This relies on a Caida-specific tool and database.
sub _get_locs_byIP {
    my ($netacq, $countries, $abbr_len, @ips) = @_;
    my ($handle, $ip_file) = tempfile();
    my %ip_to_loc;
    foreach my $ip (@ips) {
	print $handle "$ip\n";
    }
    close $handle;
    open NETACQ_PIPE, "$netacq -pgf $ip_file |" or die
						"Couldn't call $netacq: $!";
    while (<NETACQ_PIPE>) {
	next if /^#/;
	chomp;
	# Current format has tab-separated fields in this order:
	# ip continent country region city latitude longitude hostname
	my @fields = split /\t/;
	my $ip = $fields[0];
	my ($country) = $fields[2];
	my ($lat, $lon) = @fields[5 .. 6];

	if (not defined $country or $country eq '***' or $country eq '?') {
	    $country = 'UNKNOWN';
	} elsif (defined $countries and $abbr_len == 2) {
	    # NB: assumes netacq returns 3-letter abbreviations
	    $country = $countries->get_iso2code_by_iso3code($country);
	    $country = 'UNKNOWN' unless $country;
	}
	$country = uc $country;
	$ip_to_loc{$ip} = [$country, $lat, $lon];
    }
    close NETACQ_PIPE;
    unlink $ip_file;
    return \%ip_to_loc;
}

sub _get_locs_byAS {
    my ($netgeo, $countries, $abbr_len, @ases) = @_;
    _preload_locs_byAS($netgeo, @ases);
    foreach my $as (@ases) {
	next if $as_to_loc{$as};
	if ($as =~ /^\{/) {
	    my $as_set = $as;
	    $as =~ s/\{(.*)\}/$1/;
	    my @ases = split /,/, $as;
	    my $first_rec = $netgeo->getRecord(shift @ases);
	    my $first_country = $first_rec->{'COUNTRY'};
	    my ($lat, $lon) = @unknown;
	    if (defined $first_country) {
		$lat = $first_rec->{'LAT'};
		$lon = $first_rec->{'LONG'};
		if (defined $countries and $abbr_len == 3) {
		    # NB: assumes netgeo returns 2-letter abbreviations
		    $first_country = uc($countries->get_iso3code_by_iso2code(
							lc($first_country)));
		    $first_country = 'UNKNOWN' unless $first_country;
		}
	    } else {
		$first_country = 'UNKNOWN';
	    }
	    $as_to_loc{$as_set} = [$first_country, $lat, $lon];
	    foreach $as (@ases) {
		my $test_rec = $netgeo->getRecord($as);
		my $test_country = $test_rec->{'COUNTRY'};
		if (defined $countries and $abbr_len == 3) {
		    # NB: assumes netgeo returns 2-letter abbreviations
		    $test_country = uc($countries->get_iso3code_by_iso2code(
							lc($test_country)));
		    $test_country = 'UNKNOWN' unless $test_country;
		}
		next if $test_country eq $first_country; # Good, same result
		next if $test_country eq 'UNKNOWN'; # Known always beats unknown
		if ($first_country eq 'UNKNOWN') { # and $test_country is known
		    $lat = $test_rec->{'LAT'};
		    $lon = $test_rec->{'LONG'};
		    $as_to_loc{$as_set} = [$test_country, $lat, $lon];
		    $first_country = $test_country; # First KNOWN country
		} else {
		    if ($CAIDA::Tables::DEBUG) {
			print STDERR "CONFLICT between $test_country and ",
				    "$first_country for AS set: $as_set\n";
		    }
		    $as_to_loc{$as_set} = ['UNKNOWN', @unknown];
		    last;
		}
	    }
	} else {
	    my $as_rec = $netgeo->getRecord($as);
	    my $country = $as_rec->{'COUNTRY'};
	    if (defined $countries and $abbr_len == 3) {
		# NB: assumes netgeo returns 2-letter abbreviations
		$country = uc($countries->get_iso3code_by_iso2code(
							    lc($country)));
		$country = 'UNKNOWN' unless $country;
	    }
	    my ($lat, $lon) = @unknown;
	    if (defined $country) {
		$lat = $as_rec->{'LAT'};
		$lon = $as_rec->{'LONG'};
	    } else {
		$country = 'UNKNOWN';
	    }
	    $as_to_loc{$as} = [$country, $lat, $lon];
	}
    }
    return \%as_to_loc;
}

sub _get_locs_byCountry {
    my ($countries, @country_codes) = @_;
    my %country_to_loc;
    foreach my $code (@country_codes) {
	my ($lat, $lon) = @unknown;
	my $latlon_str;
	if (length($code) == 2) {
	    $latlon_str = $countries->get_latlon_by_iso2code(lc($code));
	} elsif (length($code) == 3) {
	    $latlon_str = $countries->get_latlon_by_iso3code(lc($code));
	}
	if (defined $latlon_str) {
	    ($lat, $lon) = split /,/, $latlon_str;
	}
	$country_to_loc{$code} = [$code, $lat, $lon];
    }
    return \%country_to_loc;
}

sub getRecordList {
    require CAIDA::NetGeoClient;
    my ($as_array_ref, $netgeo) = @_;

    my @rest_list = @$as_array_ref;
    my @record_list;
    my @trunc_list;
    while (scalar(@rest_list)) {
	if (@rest_list > $CAIDA::NetGeoClient::ARRAY_LENGTH_LIMIT) {
	    @trunc_list = splice @rest_list, 0,
				    $CAIDA::NetGeoClient::ARRAY_LENGTH_LIMIT;
	} else {
	    @trunc_list = @rest_list;
	    @rest_list = ();
	}
	my $fail_count = 0;
GET:	my $temp_ret_val = $netgeo->getRecordArray(\@trunc_list);
	foreach my $ref (@$temp_ret_val) {
	    if ($ref->{STATUS} eq $CAIDA::NetGeoClient::NETGEO_LIMIT_EXCEEDED) {
		print STDERR "Exceeded rate limit, sleeping.\n";
		sleep(30 * ++$fail_count + int(rand 5) + 1);
		goto GET;
	    } else {
		shift @trunc_list; # If we need to requery, don't want dup's.
		push @record_list, $ref;
	    }
	}
    }

    return \@record_list;
}

sub _preload_locs_byAS {
# ---------------------------------
    my ($netgeo, @ases_with_sets) = @_;
    my @ases_without_sets;
    
    while (@ases_with_sets) {
	my $as = shift @ases_with_sets;
	next if exists $as_to_loc{$as};
	if ($as =~ /^\{(.*)\}/) {
	    push @ases_without_sets, split /,/, $1;
	} else {
	    push @ases_without_sets, $as;
	}
    }
    getRecordList(\@ases_without_sets, $netgeo);
}

1;
