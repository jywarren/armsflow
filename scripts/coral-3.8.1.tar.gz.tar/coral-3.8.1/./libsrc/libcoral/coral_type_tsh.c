/* 
 * Copyright 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 * This TSH format handler does not use a block interface (it does not have a
 * nextblk function nor use a binfo structure), but it still uses some of the
 * low-level block code (the per-interface block queue,
 * coral_check_block_duration()).
 */

#include "config.h"
#include "coraldefs.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <assert.h>

#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <sys/time.h>
#include <errno.h>

#include "libcoral.h"
#include "libcoral_priv.h"

static const char RCSid[] = "$Id: coral_type_tsh.c,v 1.43 2007/06/06 18:17:56 kkeys Exp $";


#define TSH_RECORD_SIZE (44)
#define TSH_PAYLOAD_SIZE (36)

/* 44B doesn't divide evenly into 1MB, but this number is close to 1MB and is
 * also a multiple of 8196, so it will line up on disk block boundaries. */
#define TSH_BLK_SIZE (TSH_RECORD_SIZE * 22528)

static int coral_tsh_init(coral_source_t *src)
{
    int i, iface_count;
    struct timespec tspec;
    unsigned id;
    ssize_t len;
    const coral_timestamp_t *tstamp;
    long max_rel_time =      3600; /* Startup can't take > 1 hour. */
    long min_abs_time = 883612800; /* 1998-01-01, before HWB started taking
				    * traces with seconds in filename */

    if (src->fd >= 0) {
	/* already open */
    } else if (strcmp(src->filename, "-") == 0) {
	src->fd = STDIN_FILENO;
    } else {
	if ((src->fd = open(src->filename, O_RDONLY, 0)) < 0) {
	    coral_diag(0, ("coral_open: %s: open: %s\n",
		src->filename, strerror(errno)));
	    return -1;
	}
	coral_diag(4, ("coral_open: %s: fd %d\n", src->filename, src->fd));
    }

    if (src->dev_config.iomode.flags == CORAL_RX_UNKNOWN) {
	src->dev_config.iomode.flags = CORAL_RX;
	src->dev_config.iomode.first_n = TSH_PAYLOAD_SIZE;
    }

    if (src->dev_config.iomode.flags & ~CORAL_RX) {
	char iomode_buffer[CORAL_FORMAT_IOMODE_LEN];
	coral_format_iomode(iomode_buffer, &src->dev_config.iomode);
	coral_diag(0, ("%s: unsupported mode: %s\n",
	    src->filename, iomode_buffer));
	errno = CORAL_ERROR;
	return -1;
    }

    if (src->dev_config.iomode.first_n != TSH_PAYLOAD_SIZE) {
	coral_diag(1, ("warning: %s: %s length is fixed at %d.\n",
	    src->filename, coral_iface_type_tsh.name, TSH_PAYLOAD_SIZE));
	src->dev_config.iomode.first_n = TSH_PAYLOAD_SIZE;
    }

    if (src->iface_count == 0)
	src->iface_count = 1;
    if (coral_file_common_init(src, TSH_BLK_SIZE) < 0)
	return -1;

    /* Read first block and get timestamp from first record */
    len = coral_readall(src, src->ubase, TSH_BLK_SIZE);
    if (!len) {
	return 0;
    } else if (len < 0) {
	coral_diag(0, ("coral: %s: %s\n", src->filename,
	    coral_strerror(src->file, errno)));
	return -1;
    }
    src->preread = len;
    tstamp = &((coral_tsh_record_t*)src->ubase)->t;

    /* Check interface number of first packet:  if 0, assume it's a
     * single-interface file; if 1 or 2, assume it's a 2-interface file.
     */
    id = ((char*)tstamp)[4];
    if (id == 0) {
	iface_count = 1;
    } else if (id <= 2) {
	iface_count = 2;
    } else {
	coral_diag(0, ("coral: %s: bad TSH interface number %d\n",
	    src->filename, id));
	errno = CORAL_EBADIFNUM;
	return -1;
    }

    /* Create additional interfaces */
    while (src->iface_count < iface_count) {
	if (coral_new_instance(src, src->iface_count) < 0)
	    return -1;
	src->iface_count++;
    }

    /* Initialize interfaces */
    for (i = 0; i < src->iface_count; i++) {
	coral_iface_t *iface = cinst[src->id[i]];
	iface->devinfo.type = CORAL_TYPE_TSH;
	iface->iface_type = &coral_iface_type_tsh;
	iface->iface_info.hw_type		= CORAL_TYPE_NONE;
	iface->iface_info.hw_version		= 0;
	iface->iface_info.fw_type		= 0;
	iface->iface_info.fw_version		= 0;
	iface->iface_info.sw_type		= SW_TYPE_NLANR;
	iface->iface_info.iomode.flags		= 0;
	iface->iface_info.iomode.first_n	= TSH_PAYLOAD_SIZE;
	iface->iface_info.capture_time		= 0;
	iface->iface_info.bandwidth		= 0;
	iface->iface_info.time_is_le		= 0;
	iface->iface_info.datalink		= CORAL_NETPROTO_IPv4;
	iface->iface_info.physical		= CORAL_PROTO_UNKNOWN;
	iface->iface_info.tzoff			= 0;
	iface->iface_info.capture_tv.tv_sec	= 0;
	iface->iface_info.capture_tv.tv_usec	= 0;
    }

    /* If timestamp from the first record is normalized, use it as the
     * capture time for all interfaces.  (If timestamps are normalized, it
     * would be wrong to infer capture time from filename, since iface clocks
     * may not be synchronized with clock used to create filename time.)
     */
    coral_set_latest_ts(cinst[src->id[0]], tstamp);
    tspec = cinst[src->id[0]]->latest_ts;

    if (tspec.tv_sec > min_abs_time) {
	for (i = 0; i < src->iface_count; i++) {
	    coral_iface_t *iface = cinst[src->id[i]];
	    iface->time_is_normal = 1;
	    coral_set_iface_capture_tv(iface, &tspec, NULL);
	}
    } else if (tspec.tv_sec > max_rel_time) {
	coral_diag(0, ("coral: %s: timestamp out of bounds (%ld)\n",
	    src->filename, tspec.tv_sec));
	errno = CORAL_EBADTIME;
	return -1;
    }

    src->ts = cinst[src->id[0]]->latest_ts;
    src->current_iface = cinst[src->id[0]];

    /* If data timestamps aren't normalized, try to infer capture time
     * from filename.
     */
    if (!cinst[src->id[0]]->time_is_normal)
	if (!coral_infer_capture_time(src))
	    coral_diag(1, ("%s: could not find capture time; "
		"timestamps will not be normalized.\n", src->filename));

    return 0;
}

/* Read next block if there is one, and store it on the first iface.
 * Or return NULL and errno==EAGAIN.  Nonblocking.  Checks for duration.
 */
static coral_iface_t *tsh_queue_nextblk(coral_source_t *src)
{
    coral_iface_t *iface[2];
    ssize_t len;
    unsigned long cell_count;

    if (src->eof) return NULL;
    iface[0] = cinst[src->id[0]];
    iface[1] = src->iface_count > 1 ? cinst[src->id[1]] : iface[0];

    /* Time-sorted reading api can not steal ubase. */
    assert(src->ubase);

    if (src->preread < TSH_BLK_SIZE) {
	len = coral_readall(src, src->ubase + src->preread, TSH_BLK_SIZE);
	if (len < 0) {
	    coral_diag(0, ("coral: %s: %s\n", src->filename,
		coral_strerror(src->file, errno)));
	} else if (!(len += src->preread)) {
	    errno = 0; /* EOF */
	}
	if (len == 0 && has_another_file(src)) {
	    if (!coral_next_compound_file(src))
		return NULL;
	    /* coral_tsh_init() read a block */
	    len = src->preread;
	}
	if (len <= 0) {
	    iface[0]->have_data = 0;
	    iface[1]->have_data = 0;
	    if (errno == EAGAIN) return NULL;
	    if (!iface[0]->eof) coral_mark_eof(iface[0]);
	    if (!iface[1]->eof) coral_mark_eof(iface[1]);
	    if (errno)
		coral_diag(0, ("%s: %s\n", src->filename, strerror(errno)));
	    return NULL; /* with errno */
	}

    } else {
	len = src->preread;
    }
    src->preread = 0;

    if (len % TSH_RECORD_SIZE) {
	coral_diag(1, ("warning: %s: unexpected EOF; discarding %d-byte truncated record.\n",
	    src->filename, (len % TSH_RECORD_SIZE)));
    }

    cell_count = len / TSH_RECORD_SIZE;

    coral_diag(19, (src->iface_count > 1 ?
	"libcoral: read buffer of %d records from ifaces %d, %d\n" :
	"libcoral: read buffer of %d records from iface %d\n",
	cell_count, src->id[0], src->id[1]));

    /* if a timestamp > iface->duration_end, truncate the block
     * and mark the source as EOF'd */
    if (iface[0]->duration_end.tv_sec >= 0) {
	cell_count = coral_check_block_duration(iface[0], src->ubase,
	    cell_count, 0);
	iface[1]->expired = iface[0]->expired;
	if (!cell_count) {
	    if (!iface[0]->eof) coral_mark_eof(iface[0]);
	    if (!iface[1]->eof) coral_mark_eof(iface[1]);
	    errno = 0;
	    return NULL;
	}
    }

    iface[0]->u.blk.node.data = src->ubase;
    iface[0]->u.blk.node.cell_count = cell_count;
    iface[0]->u.blk.node.index = 0;
    iface[0]->u.blk.node.next_int = cell_count; /* until check_block_interval */
    iface[0]->u.blk.blk_count++;

    return iface[0];
}

/* Reads until it gets a non-empty block, EOF, EAGAIN, or error.  */
static coral_iface_t *coral_tsh_read_min(coral_iface_t *target_iface)
{
    coral_iface_t *iface[2];
    coral_source_t *src = target_iface->src;
    unsigned id;

    iface[0] = cinst[src->id[0]];
    iface[1] = src->iface_count > 1 ? cinst[src->id[1]] : iface[0];

    if (!iface[0]->u.blk.node.data ||
        ++iface[0]->u.blk.node.index >= iface[0]->u.blk.node.cell_count)
    {
	/* We've reached the end of the current block. */
	if (iface[0]->u.blk.node.data) {
	    coral_diag(10, (src->iface_count > 1 ?
		"end of block on iface %d\n" :
		"end of block on ifaces %d, %d\n",
		src->id[0], src->id[1]));
	    if (iface[0]->expired) {
		coral_mark_eof_src(src);
		errno = 0;
		return NULL;
	    }
	}
	if (!tsh_queue_nextblk(src))
	    return NULL /* with errno */;
    }
    coral_new_current_block(iface[0]);
    src->ts = iface[1]->latest_ts = iface[0]->latest_ts;
    iface[1]->native_ts = iface[0]->native_ts;
    iface[1]->ts_is_valid = iface[0]->ts_is_valid;

    /* Everything was stored on iface[0].  We now figure out which iface the
     * next cell really belongs to.
     */
    id = ((char*)coral_iccell(iface[0]))[4] - 1;
    if (id >= src->iface_count)
	id = 0; /* force valid id (error will be caught in prep_pkt) */
    iface[id]->have_data = 1;
    iface[!id]->have_data = 0;
    src->current_iface = iface[id];
    return iface[id];
}

const coral_src_type_t coral_src_type_tsh = {
    CORAL_TYPE_TSH,
    "tsh",
    0 /* is_live */,
    0 /* is_buffered */,
    1 /* is_block */,
    1 /* is_interleaved */,
    coral_tsh_init,
    NULL /* start */,
    NULL /* read_raw */,
    coral_tsh_read_min,
    coral_tsh_read_min,
    NULL /* nextblk */,
    NULL /* release */,
    coral_mark_eof_src /* stop */,
    coral_file_close
};
