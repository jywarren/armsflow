/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

#include "config.h"
#include "coraldefs.h"
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/stat.h> /* for mkfifo */

#ifdef HAVE_LIBPCAP
# include <pcap.h>
# ifdef HAVE_PCAP_INT_H
#  include <pcap-int.h>
# endif
#endif /* HAVE_LIBPCAP */

#include "libcoral.h"
#include "libcoral_priv.h"

#ifdef HAVE_LIBZ
# include <zlib.h>
#endif

#define PCAP_POLLTIME 500000 /* microseconds */

static const char RCSid[] = "$Id: coral_type_pcap.c,v 1.85 2007/06/06 18:17:55 kkeys Exp $";

#ifdef HAVE_LIBPCAP

static int coral_pcap_init2(coral_source_t *src);

static int coral_pcap_init(coral_source_t *src)
{
    pcap_t *pfile;
    char ebuf[PCAP_ERRBUF_SIZE], zbuf[2];
    int fd, n;
    int need_gzip = 0;
    src->version = 0;
    src->iface_count = 1;

    if (src->fd >= 0) {
	coral_diag(0, ("coral_open: %s: %s\n", src->filename,
	    "pcap files can not be opened from file descriptors"));
	return -1;
    }

#ifdef HAVE_LIBZ
    if (src->can_reopen && (fd = open(src->filename, O_RDONLY, 0)) >= 0) {
	/* If src can't be reopened, there's nothing we can do */
	if ((n = read(fd, zbuf, 2)) < 2) {
	    coral_diag(0, ("%s: %s\n", src->filename,
		n < 0 ? strerror(errno) : "empty"));
	    return -1;
	}
	close(fd);
	need_gzip = (memcmp(zbuf, GZIP_MAGIC, 2) == 0);
    }
    if (need_gzip) {
	/* libpcap can't read gzipped files.  So, we fork a child to unzip the
	 * file and pipe it to a fifo, and make libpcap read from the fifo.
	 * (A more obvious implementation would use popen("gzip -dc ..."), but
	 * that has problems with shell metachars, race conditions, failing
	 * to find gzip, and security (if e.g. this process is setuid)).
	 */
	char fifoname[PATH_MAX];
	gzFile gzfile = NULL;
	pid_t pid;
	coral_tmpname(fifoname);
	if (!(gzfile = gzopen(src->filename, "rb"))) {
	    coral_diag(0, ("coral_open (%s): gzopen %s: %s\n",
		src->filename, src->filename, strerror(errno)));
	    goto error;
	}
	if (mkfifo(fifoname, S_IRWXU) < 0) {
	    coral_diag(0, ("coral_open (%s): mkfifo %s: %s\n",
		src->filename, fifoname, strerror(errno)));
	    goto error;
	}
	coral_diag(5, ("coral_open (%s): mkfifo %s\n", src->filename, fifoname));
	if ((pid = fork()) < 0) {
	    /* fork: error */
	    coral_diag(0, ("coral_open (%s): fork: %s\n",
		src->filename, strerror(errno)));
	    error:
		if (gzfile) gzclose(gzfile);
		unlink(fifoname);
		return -1;
	} else if (pid == 0) {
	    /* fork: child */
	    /* The gzfile is already open for reading, so the only way the
	     * child can fail is in open(fifoname), gzread() or write(). */
	    ssize_t nread, nwritten, offset;
	    int fifo, exitval = 1;
	    char buf[8192];
	    if ((fifo = open(fifoname, O_WRONLY)) < 0) {
		/* can only happen if someone else messed with the fifo */
		coral_diag(0, ("coral_open (%s): open %s: %s\n",
		    src->filename, fifoname, strerror(errno)));
		goto childexit;
	    }
	    while ((nread = gzread(gzfile, buf, sizeof(buf))) > 0) {
		offset = 0;
		while (nread > 0) {
		    nwritten = write(fifo, buf + offset, nread);
		    if (nwritten < 0) goto childexit;
		    offset += nwritten;
		    nread -= nwritten;
		}
	    }
	    if (nread == 0) exitval = 0;
	    childexit:
	    gzclose(gzfile);
	    close(fifo);
	    exit(exitval);
	}
	/* parent */
	gzclose(gzfile);
	src->file = pfile = pcap_open_offline(fifoname, ebuf);
	/* since pcap_open_offline has returned, child must have written
	 * something, so it's safe to unlink fifo now. */
	unlink(fifoname);
	/* XXX bug: we never wait() for child */
    } else
#endif /* HAVE_LIBZ */
    {
	src->file = pfile = pcap_open_offline(src->filename, ebuf);
    }

    if (!pfile) {
	coral_diag(0, ("coral_open (%s): pcap: %s\n", src->filename, ebuf));
	return -1;
    }
    coral_diag(4, ("coral_open (%s): pcap\n", src->filename));

    cinst[src->id[0]]->iface_info.iomode.flags = CORAL_RX;
    cinst[src->id[0]]->iface_info.iomode.first_n = pcap_snapshot(src->file);

    if (coral_pcap_init2(src) < 0) return -1;
    coral_file_check_iomode(src);
    return 0;
}

static int coral_pcaplive_init(coral_source_t *src)
{
    pcap_t *pfile;
    char ebuf[PCAP_ERRBUF_SIZE];

    src->version = 0;
    src->iface_count = 1;

    /* If any src->dev_config fields are still unset, use device defaults. */
    coral_set_dev_config_defaults(&src->dev_config,
	&coral_iface_type_pcap.default_config);

    if (src->dev_config.iomode.flags & CORAL_RX_USER_ALL) {
	src->dev_config.iomode.first_n = MAX_PACKET_SIZE;
    }

    src->fd = -1;
    /* Open with a timeout so pcap_dispatch does not block indefinitely.
     * We need it to not block so we can read other interfaces, and handle
     * any flags set by interrupt handlers (pcap_dispatch does not return
     * when interrupted).
     */
    src->file = pfile = pcap_open_live(src->filename,
	src->dev_config.iomode.first_n, 1, 1, ebuf);
    if (!pfile) {
	coral_diag(0, ("coral_open (%s): %s\n", src->filename, ebuf));
	return -1;
    }
    coral_diag(4, ("coral_open (%s): pcap-opened with snaplen %d\n",
	src->filename, src->dev_config.iomode.first_n));
    src->fd = pcap_fileno(pfile);

    cinst[src->id[0]]->iface_info.iomode = src->dev_config.iomode;

    if (coral_pcap_init2(src) < 0) return -1;
    coral_file_check_iomode(src);

    if (!coral_config.user_polltime && (coral_config.polltime == 0 ||
	coral_config.polltime > PCAP_POLLTIME))
    {
	coral_config.polltime = PCAP_POLLTIME;
    }
    return 0;
}

static coral_protocol_t coral_pcap_dlt_to_coral(pcap_t *pfile)
{
    switch (pcap_datalink(pfile)) {
	case DLT_NULL:		return CORAL_DLT_NULL;
	case DLT_EN10MB:	return CORAL_DLT_ETHER;
	case DLT_IEEE802:	return CORAL_DLT_IEEE802;
	case DLT_PPP:		return CORAL_DLT_PPP;
	case DLT_ATM_RFC1483:	return CORAL_DLT_ATM_RFC1483;
#ifdef DLT_RAW
	case DLT_RAW:		return CORAL_NETPROTO_RAW_IP;
#endif
#ifdef DLT_C_HDLC
	case DLT_C_HDLC:	return CORAL_DLT_CHDLC;
#endif
#ifdef DLT_PPP_ETHER
	case DLT_PPP_ETHER:	return CORAL_DLT_PPPoES;
#endif
#if defined(DLT_FDDI) && !defined(NDEBUG)
	case DLT_FDDI:		return CORAL_DLT_FDDI;
#endif
	default:
	    return CORAL_PROTO_UNKNOWN;
    }
}

static int coral_pcap_init2(coral_source_t *src)
{
    coral_iface_t *iface;
    pcap_t *pfile = src->file;

    iface = cinst[src->id[0]];
    iface->internal_pcap		= src->file;
    iface->user_pcap			= NULL;
    iface->iface_info.hw_type           = 0;
    iface->iface_info.hw_version        = 0;
    iface->iface_info.fw_type           = 0;
    iface->iface_info.fw_version        = 0;
    iface->iface_info.sw_type           = SW_TYPE_PCAP;
    iface->iface_info.sw_version        = (pcap_major_version(pfile) << 16) |
					 (pcap_minor_version(pfile) & 0xFFFF);
    iface->iface_info.capture_time      = 0;
    iface->iface_info.bandwidth         = 0;

    /* libpcap always returns data in host order */
    iface->iface_info.time_is_le        = !WORDS_BIGENDIAN;

    iface->iface_type			= &coral_iface_type_pcap;
#ifdef HAVE_PCAP_INT_H
    iface->iface_info.tzoff		= pfile->tzoff;
#else
    iface->iface_info.tzoff		= 0;
#endif
    iface->iface_info.capture_tv.tv_sec = 0;
    iface->iface_info.capture_tv.tv_usec= 0;

    iface->iface_info.datalink = coral_pcap_dlt_to_coral(pfile);
    if (iface->iface_info.datalink == CORAL_PROTO_UNKNOWN) {
	coral_diag(1,
	    ("coral_open (%s): unknown/unsupported data link type %d\n",
	    src->filename, pcap_datalink(pfile)));
    }
    return 0;
}

/* from libpcap-0.4/pcap.c */
struct singleton {
    struct pcap_pkthdr *hdr;
    const u_char *pkt;
};

static void
pcap_oneshot(u_char *userData, const struct pcap_pkthdr *h, const u_char *pkt)
{
    struct singleton *sp = (struct singleton *)userData;
    *sp->hdr = *h;
    sp->pkt = pkt;
}
/* end pcap.c */


/* Read the next packet and store it and its timestamp on the iface struct.
 * Since this can only be called from the packet API, we also update the
 * iface->pkt_result, eliminating the need for a pcap prep_pkt().
 */
static coral_iface_t *coral_pcap_read_min(coral_iface_t *iface)
{
    int result;
    struct singleton s;

    s.hdr = &iface->u.pcap.hdr;
    assert(!iface->eof);
    iface->have_data = 0;

retry:
    result = pcap_dispatch(iface->src->file, 1, pcap_oneshot, (u_char*)&s);
    /* pcap_dispatch returns:
     *              file live
     * read packet:    1    1
     * no data:        x    0
     * eof:            0    x
     * error:         -1   -1
     */
    if (coral_verbosity >= 24) {
	coral_printf("pcap_dispatch on iface %d returned %d\n",
	    iface->id, result);
	if (result < 0)
	    coral_printf("    errno=%d (%s)\n", errno, strerror(errno));
    }
    if (result < 0) {
	coral_diag(0, ("%s: %s\n",
	    iface->src->filename, pcap_geterr(iface->src->file)));
	coral_mark_eof(iface);
	if (!errno) errno = CORAL_EPCAP;
	/*iface->have_data = 0;*/
	return NULL;
    }
    if (result == 0) {
	if (iface->src->type.coral_type == CORAL_TYPE_PCAPLIVE) {
	    errno = EAGAIN;
	} else {
	    if (has_another_file(iface->src)) {
		if (!coral_next_compound_file(iface->src))
		    return NULL;
		goto retry;
	    }
	    errno = 0;
	    coral_mark_eof(iface);
	}
	/*iface->have_data = 0;*/
	return NULL;
    }

    iface->packetbuf.buf = (char*)s.pkt;
    /* note: libpcap (at least <= 0.7.1) does not apply snaplen if no filter
     * was set, so we must check it ourselves. */
    iface->packetbuf.caplen = 
	iface->iface_info.iomode.first_n < iface->u.pcap.hdr.caplen ?
	iface->iface_info.iomode.first_n : iface->u.pcap.hdr.caplen;
    iface->packetbuf.totlen = iface->u.pcap.hdr.len;
    iface->packetbuf.is_dynamic = 0;
    iface->packetbuf.protocol = iface->iface_info.datalink;
    iface->packetbuf.passed = 1;	/* libpcap already applied bpf filter */

    iface->pkt_result.packet = &iface->packetbuf;
    iface->pkt_result.packet->parent_proto = CORAL_PROTO_UNKNOWN;
    iface->pkt_result.header = NULL;
    iface->pkt_result.trailer = NULL;
    iface->pkt_result.subiface = 0;
    iface->pkt_result.timestamp = (coral_timestamp_t*)&iface->u.pcap.hdr.ts;

    coral_set_latest_ts(iface, iface->pkt_result.timestamp);

    if (!iface->iface_info.capture_tv.tv_sec)
	coral_set_iface_capture_tv(iface, &iface->latest_ts, NULL);

    iface->synced = iface->period_end.tv_sec >= 0 &&
	timespeccmp(&iface->latest_ts, &iface->period_end, >=);
    if (iface->synced && timestamp_duration_ended(iface, &iface->latest_ts)) {
	/*iface->have_data = 0;*/
	return NULL;
    }

    iface->have_data = 1;
    return iface;
}

/* clean up stuff we malloc'd or opened in coral_file_open */
static int coral_pcap_close(coral_source_t *src, int final)
{
    if (final && src->ubase)
	free(src->ubase);
    if (src->file) {
	pcap_close(src->file);
	src->file = NULL;
    }
    return 0;
}

#if 0
static int coral_pcap_fd(coral_source_t *src)
{
    return ((struct pcap*)src->file)->fd;
}
#endif

static int coral_pcaplive_stop(coral_source_t *src)
{
    if (src->file) {
	coral_pcap_update_pkt_stats(cinst[src->id[0]]); /* get stats first! */
	pcap_close(src->file);
    }
    src->file = NULL;
    coral_mark_eof(cinst[src->id[0]]);
    return 0;
}

#endif /* HAVE_LIBPCAP */

const coral_src_type_t coral_src_type_pcap = {
    CORAL_TYPE_PCAP,
    "pcap",
#ifdef HAVE_LIBPCAP
    0 /* is_live */,
    0 /* is_buffered */,
    0 /* is_block */,
    0 /* is_interleaved */,
    coral_pcap_init,
    NULL /* start */,
    NULL /* read_raw */,
    coral_pcap_read_min,
    coral_pcap_read_min,
    NULL,   /* nextblk */
    NULL,   /* release */
    coral_mark_eof_src,   /* stop */
    coral_pcap_close
#endif /* HAVE_LIBPCAP */
};

const coral_src_type_t coral_src_type_pcaplive = {
    CORAL_TYPE_PCAPLIVE,
    "pcaplive",
#ifdef HAVE_LIBPCAP
    1 /* is_live */,
    0 /* is_buffered */,	/* pcap_dispatch returns before buffer fills */
    0 /* is_block */,
    0 /* is_interleaved */,
    coral_pcaplive_init,
    NULL /* start */,
    NULL /* read_raw */,
    coral_pcap_read_min,
    coral_pcap_read_min,
    NULL,   /* nextblk */
    NULL,   /* release */
    coral_pcaplive_stop,
    coral_pcap_close
#endif /* HAVE_LIBPCAP */
};

