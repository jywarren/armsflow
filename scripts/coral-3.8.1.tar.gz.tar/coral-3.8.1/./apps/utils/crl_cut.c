/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 * crl_cut.c - extract a section of a trace file by time or count
 *
 * $Id: crl_cut.c,v 1.27 2007/06/06 18:17:36 kkeys Exp $
 *
 */

static const char RCSid[]="$Id: crl_cut.c,v 1.27 2007/06/06 18:17:36 kkeys Exp $";

#include "config.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <signal.h>
#include <ctype.h>
#include <time.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <errno.h>

#include "libcoral.h"

enum { ST_RUN, ST_STOPPED, ST_INT, ST_ERROR };

static const char *outfile = "out.crl";
static int n_start = 0, n_end = -1;
static double t, t_start = -1, t_end = -1;

static void usage(const char *name)
{
    coral_usage(name, "[-o<file>] [-i<n>] [-n<n>] [-N<n>] [-t<t>] [-T<t>] <source>...\n"
	"-o<file>  write output to <file> (default: \"%s\")\n"
	"-i<n>     read only from interface <n>\n"
	"-n<n>     read only cells with number >= <n>\n"
	"-N<n>     read only cells with number <= <n>\n"
	"-t<t>     read only cells with timestamp >= <t> (in seconds)\n"
	"-T<t>     read only cells with timestamp <= <t> (in seconds)\n",
	outfile);
}

int main(int argc, char *argv[])
{
    coral_writer_t *writer;
    coral_iface_t *iface, *input_iface = NULL;
    coral_source_t *input_src = NULL;
    coral_atm_cell_t *cell;
    int opt;
    long ifn = -1, total = 0, i = -1;

    coral_set_api(CORAL_API_CELL | CORAL_API_WRITE);
    coral_set_iomode(0, CORAL_RX_UNKNOWN, -1, 0);
    coral_set_duration(0);
    coral_set_options(CORAL_OPT_RAW_TIME, CORAL_OPT_SORT_TIME);

    while ((opt = getopt(argc, argv, "C:o:i:n:N:t:T:")) != -1) {
        switch (opt) {
        case 'C':
            if (coral_config_command(optarg) < 0) {
		usage(argv[0]);
                exit(-1);
	    }
            break;
        case 'i':
            ifn = atoi(optarg);  break;
        case 'n':
            n_start = atoi(optarg);  break;
        case 'N':
            n_end = atoi(optarg);  break;
        case 't':
            t_start = atof(optarg);  break;
        case 'T':
            t_end = atof(optarg);  break;
        case 'o':
            outfile = strdup(optarg);  break;
        default:
            usage(argv[0]);
            exit(-1);
        }
    }

    while (optind < argc) {
        if (!coral_new_source(argv[optind]))
            exit(-1);
        optind++;
    }

    if (coral_open_all() <= 0) {
	exit(2);
    }

    if (coral_start_all() < 0)
	exit(3);

    writer = coral_write_open(outfile);

    if (!writer) exit(4);
    coral_diag(1, ("opened output file: %s\n", outfile));

    if (ifn < 0) {
	if (coral_write_init_all(writer) < 0)
	    exit(4);
    } else {
	input_iface = coral_next_interface(NULL);
	while (1) {
	    if (!input_iface) {
		coral_printf("no interface %d\n", ifn);
		exit(5);
	    }
	    if (coral_interface_get_number(input_iface) == ifn) break;
	    input_iface = coral_next_interface(input_iface);
	}
	if (coral_write_init_interface(writer, input_iface) < 0)
	    exit(6);
	input_src = coral_interface_get_src(input_iface);
    }

    fputs("copying", stdout);
    fflush(stdout);

    while (1) {
	iface = input_src ?
	    coral_read_cell(input_src, NULL, &cell, NULL) :
	    coral_read_cell_all(NULL, &cell, NULL);
	if (!iface) {
	    break;
	}
	if (input_iface && iface != input_iface)
	    continue;
	i++;

	if (i < n_start)
	    continue;
	if (n_end >= 0 && i > n_end)
	    break;
	if (t_start > 0 || t_end >= 0) {
	    t = coral_read_clock_double(iface, coral_cell_time(iface, cell));
	    if (t_start > 0 && t < t_start)
		continue;
	    if (t_end >= 0 && t > t_end)
		continue;
	}

	if (coral_write_cells(writer, iface, cell, 1) < 0)
	    exit(6);
	total++;
	if (total % 20000 == 0) {
	    putchar('.');
	    fflush(stdout);
	}
    }

    fprintf(stderr, "\n\ncopied %ld cells to %s\n", total, outfile);
    if (errno) {
	fprintf(stderr, "aborted\n");
	exit(errno);
    }

    coral_write_close(writer);
    coral_close_all();

    return(0);
}
