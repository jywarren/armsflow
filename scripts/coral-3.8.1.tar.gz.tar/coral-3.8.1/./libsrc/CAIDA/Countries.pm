## 
## Copyright 1999, 2000, 2001, 2002, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
## All Rights Reserved 
## 
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
## 
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
## 
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
## 
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
## 
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program.  Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
## 
## Report bugs and suggestions to coral-bugs@caida.org.
## 

## 
## 

package CAIDA::Countries;
@EXPORT    = qw();
@EXPORT_OK = qw();

# Enable error messages to come from calling script
use Carp;

# Define required CVS variables
$cvs_Id = '$Id: Countries.pm,v 1.20 2007/06/06 18:17:43 kkeys Exp $';
$cvs_Author = '$Author: kkeys $';
$cvs_Name = '$Name: release-3-8-1 $';
$cvs_Revision = '$Revision: 1.20 $';

my $coral_dir;
BEGIN { $coral_dir = "/usr/local/Coral"; } # This will be edited during build.

# Version of module
$VERSION = 1.0;

use strict;
use warnings;
use IO::File;

# list of Countries object variables
#===================================
# INPUT FILES
#    	$self->{'country_data_file'}
#	$self->{'location_data_file'}
#	$self->{'iso3_data_file'}
#	$self->{'fips_data_file'}
#	$self->{'continent_data_file'}
# DATA HASHES
#	$self->{'Countries2ISO2Codes'}
#	$self->{'ISO2Codes2Countries'}
#	$self->{'ISO2Codes2ISO3Codes'}
#	$self->{'ISO3Codes2ISO2Codes'}
#	$self->{'ISO2Codes2FIPSCodes'}
#	$self->{'FIPSCodes2ISO2Codes'}
#	$self->{'ISO2Codes2Locations'}
#	$self->{'Continents2ISO2Codes'}
#	$self->{'Continents2Names'}
#	$self->{'Names2Continents'}
# FUNCTIONS
#   dump_continents_to_countries($$) {
#   dump_locations ($$) {
#   dump_countries ($$) {
#   dump_iso2codes_to_countries ($$) {
#   dump_iso2codes_to_iso3codes ($$) {
#   dump_iso3codes_to_iso2codes ($$) {
#   dump_iso2codes_to_fipscodes ($$) {
#   dump_fipscodes_to_iso2_codes ($$) {
#   dump_continents_to_names ($$) {
#   dump_names_to_continents ($$) {
#
#   get_iso2code_by_name($$) {
#   get_name_by_iso2code($$) {
#
#   get_iso3code_by_iso2code($$) {
#   get_iso2code_by_iso3code($$) {
#
#   get_fipscode_by_iso2code($$) {
#   get_iso2code_by_fipscode($$) {
#
#   get_location_by_iso2code($$) {
#   get_iso2codes_by_contcode($$) {
#   get_continent_by_iso2code($$) {
#   get_latlon_by_iso2code($$) {
#
#   get_contname_by_contcode($$) {
#   get_contcode_by_contname($$) {
#
#   get_name_by_iso3code($$) {
#   get_name_by_fipscode($$) {
#   get_names_by_contcode($$) {
#
#   get_iso3code_by_name($$) {
#   get_iso3code_by_fipscode($$) {
#   get_iso3codes_by_contcode($$) {
#
#   get_fipscode_by_name($$) {
#   get_fipscode_by_iso3code($$) {
#   get_fipscodes_by_contcode($$) {
#
#   get_continent_by_name($$) {
#   get_continent_by_iso3code($$) {
#   get_continent_by_fipscode($$) {
#
#   get_latlon_by_name($$) {
#   get_latlon_by_iso3code($$) {
#   get_latlon_by_fipscode($$) {
#
#   get_location_by_name($$) {
#   get_location_by_iso3code($$) {
#   get_location_by_fipscode($$) {
#
#   get_split_loc($$$) {


sub _load_iso2($$) {
    my ($self, $iso2_file) = @_;
    my $errors = 0;
    my %ISO2Codes2Countries;
    my %Countries2ISO2Codes;

    my @abbrev;

    my $iso2file = new IO::File("< " . $iso2_file) or die "couldn't open data input file $iso2_file:$!\n";

    while (defined(my $line = <$iso2file>)) {
	# should be tab separated, but tabs can look like spaces -- just require
	#	more than one

	if ($line =~ /^\s*$/ || $line =~ /^\s*#/) {
	    next;
	}
	chomp $line;

	my ($code, $country) = split / {2,}|\t/, $line;
	if (! defined $code || ! defined $country || $code eq '' || $country eq '') {
	    warn "Error parsing input: $line\n";
	    next;
	}

	if (! exists $ISO2Codes2Countries{$code}) {
	    $ISO2Codes2Countries{$code} = $country;
	} else {
	    if ($ISO2Codes2Countries{$code} eq $country) {
		warn "duplicate insertion of $country for $code at $line\n";
	    } else {
		warn "conflict between $ISO2Codes2Countries{$code} and $country for code $code\n";
	    }
	    $errors++;
	}
	
	# country has parentheses (no country only exists in parentheses)
	#	also, no country should start with parentheses
	if ($country =~ /\(.*\)/) {
	    $country =~ /([\w ']*) \(([\w ']+)\)(?: )*([\w ']*)/;
	    if (0) {
		print "$country:\t";
		if (defined $1) {
		    print "$1\t";
		}
		if (defined $2) {
		    print "$2\t";
		}
		if (defined $3) {
		    print "$3";
		}
		print "\n";
	    }
	    # alternate name in parens after the real name
	    if (!defined $3 && defined $1) {
		if (exists $Countries2ISO2Codes{$1}) {
		    if ($Countries2ISO2Codes{$1} eq $code) {
			warn "duplicate insertion of $code for $1 at $line\n";
		    } else {
			warn "conflict between $Countries2ISO2Codes{$1} and $code for country $country\n";
		    }
		    $errors++;
		} else {
		    $Countries2ISO2Codes{$1} = $code;
		}
		if (exists $Countries2ISO2Codes{$2}) {
		    if ($Countries2ISO2Codes{$2} eq $code) {
			warn "duplicate insertion of $code for $2 at $line\n";
		    } else {
			warn "conflict between $Countries2ISO2Codes{$2} and $code for country $country\n";
		    }
		    $errors++;
		} else {
		    $Countries2ISO2Codes{$2} = $code;
		}
	    # alternate beginning name in parentheses
	    } elsif (defined $1 && defined $2 && defined $3) {
		if (exists $Countries2ISO2Codes{"$1 $3"}) {
		    if ($Countries2ISO2Codes{"$1 $3"} eq $code) {
			warn "duplicate insertion of $code for $1 $3 at $line\n";
		    } else {
			warn "conflict between " . $Countries2ISO2Codes{"$1 $3"} . " and $code for country $country\n";
		    }
		    $errors++;
		} else {
		    $Countries2ISO2Codes{"$1 $3"} = $code;
		}
		if (exists$Countries2ISO2Codes{"$2 $3"}) {
		    if ($Countries2ISO2Codes{"$2 $3"} eq $code) {
			warn "duplicate insertion of $code for $2 $3 at $line\n";
		    } else {
			warn "conflict between " . $Countries2ISO2Codes{"$2 $3"} . " and $code for country $country\n";
		    }
		    $errors++;
		} else {
		    $Countries2ISO2Codes{"$2 $3"} = $code;
		}
	    } else {
		warn "Error processing parentheses in country $country\n";
		$errors++;
	    }

	# country has brackets (optional country affiliation)
	} elsif ($country =~ /\[.*\]$/) {
	    $country =~ /([\w ]+) \[([\w ]+)\]/;
	    if (defined $1 && defined $2) {
		if (exists$Countries2ISO2Codes{$1}) {
		    if ($Countries2ISO2Codes{$1} eq $code) {
			warn "duplicate insertion of $code for $1 at $line\n";
		    } else {
			warn "conflict between $Countries2ISO2Codes{$1} and $code for country $country\n";
		    }
		    $errors++;
		} else {
		    $Countries2ISO2Codes{$1} = $code;
		}
		if (exists$Countries2ISO2Codes{"$2 $1"}) {
		    if ($Countries2ISO2Codes{"$2 $1"} eq $code) {
			warn "duplicate insertion of $code for $2 $1 at $line\n";
		    } else {
			warn "conflict between " . $Countries2ISO2Codes{"$2 $1"} . " and $code for country $country\n";
		    }
		    $errors++;
		} else {
		    $Countries2ISO2Codes{"$2 $1"} = $code;
		}
	    } else {
		warn "Error processing brackets in country $country\n";
		$errors++;
	    }

	# country has a comma
	} elsif ($country =~ /,/) {
	    my ($name, $prefix) = split /, /, $country;
	    if (exists $Countries2ISO2Codes{$name}) {
		if ($Countries2ISO2Codes{$name} eq $code) {
		    warn "duplicate insertion of $code for $name at $line\n";
		} else {
		    warn "conflict between $Countries2ISO2Codes{$name} and $code for country $name\n";
		}
		$errors++;
	    } else {
		push @abbrev, [$code, $name];
	    }
	    if (exists $Countries2ISO2Codes{"$prefix $name"}) {
		if ($Countries2ISO2Codes{"$prefix $name"} eq $code) {
		    warn "duplicate insertion of $code for $prefix $name at $line\n";
		} else {
		    warn "conflict between " . $Countries2ISO2Codes{"$prefix $name"} . " and $code for country $prefix $name\n";
		}
		$errors++;
	    } else {
		$Countries2ISO2Codes{"$prefix $name"} = $code;
	    }

	} else {
	    if (exists $Countries2ISO2Codes{$country}) {
		if ($Countries2ISO2Codes{$country} eq $code) {
		    warn "duplicate insertion of $code for $country at $line\n";
		} else {
		    warn "conflict between $Countries2ISO2Codes{$country} and $code for country $country\n";
		}
		$errors++;
	    } else {
		$Countries2ISO2Codes{$country} = $code;
	    }
	}
    }

    # put abbreviations as long as they don't conflict with other countries
    foreach my $pair_ref (@abbrev) {
	my ($code, $name) = @{$pair_ref};
	if (! exists $Countries2ISO2Codes{$name}) {
	    $Countries2ISO2Codes{$name} = $code;
	}
    }

    $self->{'Countries2ISO2Codes'} = \%Countries2ISO2Codes;
    $self->{'ISO2Codes2Countries'} = \%ISO2Codes2Countries;

    return $errors;
}

sub _load_iso3($$) {
    my ($self, $iso3_file) = @_;
    my $errors = 0;
    my %ISO2Codes2ISO3Codes;
    my %ISO3Codes2ISO2Codes;

    my $iso3file = new IO::File("< " . $iso3_file) or die "couldn't open data input file $iso3_file:$!\n";

    while (defined(my $line = <$iso3file>)) {
	# skip blank lines and comments
	if ($line =~ /^\s*$/ || $line =~ /^\s*#/) {
	    next;
	}
	chomp $line;
	my ($iso2, $iso3) = split /\s+/, $line;

	# add to iso2->iso3
	if (exists $ISO2Codes2ISO3Codes{$iso2}) {
	    if ($ISO2Codes2ISO3Codes{$iso2} eq $iso3) {
		warn "duplicate insertion of $iso3 for $iso2 at $line\n";
	    } else {
		warn "conflict between $ISO2Codes2ISO3Codes{$iso2} and $iso3 for $iso2\n";
	    }
	    $errors++;
	} else {
	    $ISO2Codes2ISO3Codes{$iso2} = $iso3;
	}

	# add to iso3->iso2
	if (exists $ISO3Codes2ISO2Codes{$iso3}) {
	    if ($ISO3Codes2ISO2Codes{$iso3} eq $iso2) {
		warn "duplicate insertion of $iso2 for $iso3 at $line\n";
	    } else {
		warn "conflict between $ISO3Codes2ISO2Codes{$iso3} and $iso2 for $iso3\n";
	    }
	    $errors++;
	} else {
	    $ISO3Codes2ISO2Codes{$iso3} = $iso2;
	}
    }
    
    $self->{'ISO2Codes2ISO3Codes'} = \%ISO2Codes2ISO3Codes;
    $self->{'ISO3Codes2ISO2Codes'} = \%ISO3Codes2ISO2Codes;

    return $errors;
}

sub _load_fips($$) {
    my ($self, $fips_file) = @_;
    my $errors = 0;
    my %ISO2Codes2FIPSCodes;
    my %FIPSCodes2ISO2Codes;

    my $fipsfile = new IO::File("< " . $fips_file) or die "couldn't open data input file $fips_file:$!\n";

    while (defined(my $line = <$fipsfile>)) {
	# skip blank lines and comments
	if ($line =~ /^\s*$/ || $line =~ /^\s*#/) {
	    next;
	}
	chomp $line;
	my ($iso2, $fips) = split /\s+/, $line;
	
	# add to iso2->fips
	if (exists $ISO2Codes2FIPSCodes{$iso2}) {
	    if ($ISO2Codes2FIPSCodes{$iso2} eq $fips) {
		warn "duplicate insertion of $fips for $iso2 at $line\n";
	    } else {
		warn "conflict between $ISO2Codes2FIPSCodes{$iso2} and $fips for $iso2\n";
	    }
	    $errors++;
	} else {
	    $ISO2Codes2FIPSCodes{$iso2} = $fips;
	}

	# add to fips->iso2
	if (exists $FIPSCodes2ISO2Codes{$fips}) {
	    if ($FIPSCodes2ISO2Codes{$fips} eq $iso2) {
		warn "duplicate insertion of $iso2 for $fips at $line\n";
	    } else {
		warn "conflict between $FIPSCodes2ISO2Codes{$fips} and $iso2 for $fips\n";
	    }
	    $errors++;
	} else {
	    $FIPSCodes2ISO2Codes{$fips} = $iso2;
	}
    }

    $self->{'ISO2Codes2FIPSCodes'} = \%ISO2Codes2FIPSCodes;
    $self->{'FIPSCodes2ISO2Codes'} = \%FIPSCodes2ISO2Codes;

    return $errors;
}

sub _load_loc($$) {
    my ($self, $loc_file) = @_;
    my $errors = 0;
    my %ISO2Codes2Locations;
    my %Continents2ISO2Codes;

    my $locfile = new IO::File("< " . $loc_file) or die "couldn't open location input file $loc_file:$!\n";

    while (defined(my $line = <$locfile>)) {
	# skip blank lines and comments
	if ($line =~ /^\s*$/ || $line =~ /^\s*#/) {
	    next;
	}
	chomp $line;
	my ($code, $continent, $latlon) = split /\t/, $line;

	# add to %ISO2Codes2Locations
	# each country should only be in one place
	if (exists $ISO2Codes2Locations{$code}) {
	    warn "conflict between '$ISO2Codes2Locations{$code}' and '$continent\t$latlon' for $code\n";
	    $errors++;
	} else {
	    $ISO2Codes2Locations{$code} = "$continent\t$latlon";
	}

	# add to %Continents2ISO2Codes
	# each country should only be in its continent once
	if (exists $Continents2ISO2Codes{$continent}->{$code}) {
	    warn "duplicate insertion of $code into $continent at $line\n";
	    $errors++;
	} else {
	    # only one continent should contain each country
	    # non-fatal error in case anyone does this on purpose
	    #	(although who knows why they would)
	    foreach my $tmpcont (keys %Continents2ISO2Codes) {
		# but this continent is allowed to have it
		#	(could integrate previous duplication check)
		if ($tmpcont eq $continent) {
		    next;
		}
		if (exists $Continents2ISO2Codes{$tmpcont}->{$code}) {
		    warn "attempt to place $code into $continent with $code already in $tmpcont\n";
		    $errors++;
		}
	    }
	    $Continents2ISO2Codes{$continent}->{$code} = 1;
	}
    }

    $self->{'ISO2Codes2Locations'} = \%ISO2Codes2Locations;
    $self->{'Continents2ISO2Codes'} = \%Continents2ISO2Codes;

    return $errors;
}

sub _load_continent($) {
    my ($self, $cont_file) = @_;
    my %Names2Continents;
    my %Continents2Names;
    my $errors = 0;

    my $contfile = new IO::File("< " . $cont_file) or die "couldn't open continent input file $cont_file:$!\n";

    while (defined(my $line = <$contfile>)) {
	# skip blank lines and comments
	if ($line =~ /^\s*$/ || $line =~ /^\s*#/) {
	    next;
	}
	chomp $line;
	my ($contcode, $contname) = split /\t/, $line;

	# add to %Names2Continents
	if (exists $Names2Continents{$contname}) {
	    if ($Names2Continents{$contname} eq $contcode) {
		warn "duplicate insertion of $contcode for $contname at $line\n";
	    } else {
		warn "conflict between '$Names2Continents{$contname}' and '$contcode' for $contname\n";
	    }
	    $errors++;
	} else {
	    $Names2Continents{$contname} = $contcode;
	}

	# add to $Continents2Names
	if (exists $Continents2Names{$contcode}) {
	    if ($Continents2Names{$contcode} eq $contname) {
		warn "duplicate insertion of $contname for $contcode at $line\n";
	    } else {
		warn "conflict between '$Continents2Names{$contcode}' and '$contname' for $contcode\n";
	    }
	    $errors++;
	} else {
	    $Continents2Names{$contcode} = $contname;
	}
    }

    $self->{'Names2Continents'} = \%Names2Continents;
    $self->{'Continents2Names'} = \%Continents2Names;

    return $errors;
}

sub _load_data($$) {
    my ($self, $iso2_file, $loc_file, $iso3_file, $fips_file, $continent_file) = @_;

    my $errors = 0;
    $errors += $self->_load_iso2($iso2_file);
    $errors += $self->_load_iso3($iso3_file);
    $errors += $self->_load_fips($fips_file);
    $errors += $self->_load_loc($loc_file);
    $errors += $self->_load_continent($continent_file);
    return $errors;
}

sub dump_continents_to_countries($;$) {
    my ($self, $fileref) = @_;
    if (!defined $fileref) {
	$fileref = \*STDOUT;
    }
    foreach my $continent (keys %{$self->{'Continents2ISO2Codes'}}) {
	print $fileref "$continent:";
	foreach my $country (sort {$a cmp $b} keys %{$self->{'Continents2ISO2Codes'}->{$continent}}) {
	    print $fileref "\t$country";
	}
	print $fileref "\n\n";
    }
}

sub dump_locations ($;$) {
    my ($self, $fileref) = @_;
    if (!defined $fileref) {
	$fileref = \*STDOUT;
    }
    foreach my $code (keys %{$self->{'ISO2Codes2Locations'}}) {
	print $fileref $code . "\t" .
	    $self->{'ISO2Codes2Locations'}->{$code} . "\n"; 
    }
}

sub dump_countries ($;$) {
    my ($self, $fileref) = @_;
    if (!defined $fileref) {
	$fileref = \*STDOUT;
    }
    foreach my $country (keys %{$self->{'Countries2ISO2Codes'}}) {
	print $fileref $country . "\t" .
	    $self->{'Countries2ISO2Codes'}->{$country} . "\n"; 
    }
}

sub dump_iso2codes_to_countries ($;$) {
    my ($self, $fileref) = @_;
    if (!defined $fileref) {
	$fileref = \*STDOUT;
    }
    foreach my $code (keys %{$self->{'ISO2Codes2Countries'}}) {
	print $fileref $code . "\t" .
	    $self->{'ISO2Codes2Countries'}->{$code} . "\n"; 
    }
}

sub dump_iso2codes_to_iso3codes ($;$) {
    my ($self, $fileref) = @_;
    if (!defined $fileref) {
	$fileref = \*STDOUT;
    }
    foreach my $iso2 (keys %{$self->{'ISO2Codes2ISO3Codes'}}) {
	print $fileref $iso2 . "\t" .
	    $self->{'ISO2Codes2ISO3Codes'}->{$iso2} . "\n"; 
    }
}

sub dump_iso3codes_to_iso2codes ($;$) {
    my ($self, $fileref) = @_;
    if (!defined $fileref) {
	$fileref = \*STDOUT;
    }
    foreach my $iso3 (keys %{$self->{'ISO3Codes2ISO2Codes'}}) {
	print $fileref $iso3 . "\t" .
	    $self->{'ISO3Codes2ISO2Codes'}->{$iso3} . "\n"; 
    }
}

sub dump_iso2codes_to_fipscodes ($;$) {
    my ($self, $fileref) = @_;
    if (!defined $fileref) {
	$fileref = \*STDOUT;
    }
    foreach my $iso2 (keys %{$self->{'ISO2Codes2FIPSCodes'}}) {
	print $fileref $iso2 . "\t" .
	    $self->{'ISO2Codes2FIPSCodes'}->{$iso2} . "\n"; 
    }
}

sub dump_fipscodes_to_iso2_codes ($;$) {
    my ($self, $fileref) = @_;
    if (!defined $fileref) {
	$fileref = \*STDOUT;
    }
    foreach my $fips (keys %{$self->{'FIPSCodes2ISO2Codes'}}) {
	print $fileref $fips . "\t" .
	    $self->{'FIPSCodes2ISO2Codes'}->{$fips} . "\n"; 
    }
}

sub dump_continents_to_names ($;$) {
    my ($self, $fileref) = @_;
    if (!defined $fileref) {
	$fileref = \*STDOUT;
    }
    foreach my $contcode (keys %{$self->{'Continents2Names'}}) {
	print $fileref $contcode . "\t" .
	    $self->{'Continents2Names'}->{$contcode} . "\n";
    }
}

sub dump_names_to_continents ($;$) {
    my ($self, $fileref) = @_;
    if (!defined $fileref) {
	$fileref = \*STDOUT;
    } foreach my $contname (keys %{$self->{'Names2Continents'}}) {
	print $fileref $contname . "\t" .
	    $self->{'Names2Continents'}->{$contname} . "\n";
    }
}

# single level lookups
sub get_iso2code_by_name($$) {
    my ($self, $country) = @_;
    if (exists $self->{'Countries2ISO2Codes'}->{$country}) {
	return $self->{'Countries2ISO2Codes'}->{$country};
    } else {
	return undef;
    }
}

sub get_name_by_iso2code($$) {
    my ($self, $code) = @_;
    if (exists $self->{'ISO2Codes2Countries'}->{$code}) {
	return $self->{'ISO2Codes2Countries'}->{$code};
    } else {
	return undef;
    }
}

sub get_iso3code_by_iso2code($$) {
    my ($self, $iso2) = @_;
    if (exists $self->{'ISO2Codes2ISO3Codes'}->{$iso2}) {
	return $self->{'ISO2Codes2ISO3Codes'}->{$iso2};
    } else {
	return undef;
    }
}

sub get_iso2code_by_iso3code($$) {
    my ($self, $iso3) = @_;
    if (exists $self->{'ISO3Codes2ISO2Codes'}->{$iso3}) {
	return $self->{'ISO3Codes2ISO2Codes'}->{$iso3};
    } else {
	return undef;
    }
}

sub get_fipscode_by_iso2code($$) {
    my ($self, $iso2) = @_;
    if (exists $self->{'ISO2Codes2FIPSCodes'}->{$iso2}) {
	return $self->{'ISO2Codes2FIPSCodes'}->{$iso2};
    } else {
	return undef;
    }
}

sub get_iso2code_by_fipscode($$) {
    my ($self, $fips) = @_;
    if (exists $self->{'FIPSCodes2ISO2Codes'}->{$fips}) {
	return $self->{'FIPSCodes2ISO2Codes'}->{$fips};
    } else {
	return undef;
    }
}

sub get_location_by_iso2code($$) {
    my ($self, $iso2) = @_;
    if (exists $self->{'ISO2Codes2Locations'}->{$iso2}) {
	return $self->{'ISO2Codes2Locations'}->{$iso2};
    } else {
	return undef;
    }
}

sub get_iso2codes_by_contcode($$) {
    my ($self, $cont_code) = @_;
    if (exists $self->{'Continents2ISO2Codes'}->{$cont_code}) {
	my @iso2codes = sort {$a cmp $b} keys %{$self->{'Continents2ISO2Codes'}->{$cont_code}};
	#warn "iso2codes: " . join("\t", @iso2codes) . "\n";
	return(\@iso2codes);
    } else {
	return undef;
    }
}


sub get_split_loc($$$) {
    my ($self, $iso2, $flag) = @_;
    if (!defined $flag) {
	return undef;
    }
    if (exists $self->{'ISO2Codes2Locations'}->{$iso2}) {
	my $loc = $self->{'ISO2Codes2Locations'}->{$iso2};
	if (defined $loc) {
	    my ($continent, $latlon) = split /\t/, $loc;
	    if ($flag == 0) {
		return $continent;
	    } elsif ($flag == 1) {
		return $latlon;
	    } else {
		return undef;
	    }
	} else {
	    return undef;
	}
    } else {
	return undef;
    }
}

sub get_continent_by_iso2code($$) {
    my ($self, $iso2) = @_;
    return $self->get_split_loc($iso2, 0);
}

sub get_latlon_by_iso2code($$) {
    my ($self, $iso2) = @_;
    return $self->get_split_loc($iso2, 1);
}

sub get_contname_by_contcode($$) {
    my ($self, $code) = @_;
    if (exists $self->{'Continents2Names'}->{$code}) {
	return $self->{'Continents2Names'}->{$code};
    } else {
	return undef;
    }
}

sub get_contcode_by_contname ($$) {
    my ($self, $name) = @_;
    if (exists $self->{'Names2Continents'}->{$name}) {
	return $self->{'Names2Continents'}->{$name};
    } else {
	return undef;
    }
}

#multi-level lookups
sub get_name_by_iso3code($$) {
    my ($self, $iso3) = @_;
    return($self->get_name_by_iso2code($self->get_iso2code_by_iso3code($iso3)));
}

sub get_name_by_fipscode($$) {
    my ($self, $fips) = @_;
    return($self->get_name_by_iso2code($self->get_iso2code_by_fipscode($fips)));
}

sub get_names_by_contcode($$) {
    my ($self, $continent) = @_;
    my @iso2codes = @{$self->get_iso2codes_by_contcode($continent)};
    my @names;
    foreach my $iso2 (@iso2codes) {
	push @names, $self->get_name_by_iso2code($iso2);
    }
    return \@names;
}

sub get_iso3code_by_name($$) {
    my ($self, $country) = @_;
    return ($self->get_iso3code_by_iso2code($self->get_iso2code_by_name($country)));
}

sub get_iso3code_by_fipscode($$) {
    my ($self, $fips) = @_;
    return($self->get_iso3code_by_iso2code($self->get_iso2code_by_fipscode($fips)));
}

sub get_iso3codes_by_contcode($$) {
    my ($self, $continent) = @_;
    my @iso2codes = @{$self->get_iso2codes_by_contcode($continent)};
    my @iso3codes;
    foreach my $iso2 (@iso2codes) {
	push @iso3codes, $self->get_iso3code_by_iso2code($iso2);
    }
    return \@iso3codes;
}

sub get_fipscode_by_name($$) {
    my ($self, $country) = @_;
    return($self->get_fipscode_by_iso2code($self->get_iso2code_by_name($country)));
}

sub get_fipscode_by_iso3code($$) {
    my ($self, $iso3) = @_;
    return($self->get_fipscode_by_iso2code($self->get_iso2code_by_iso3code($iso3)));
}

sub get_fipscodes_by_contcode($$) {
    my ($self, $continent) = @_;
    my @iso2codes = @{$self->get_iso2codes_by_contcode($continent)};
    my @fipscodes;
    foreach my $iso2 (@iso2codes) {
	push @fipscodes, $self->get_fipscode_by_iso2code($iso2);
    }
    return \@fipscodes;
}

sub get_continent_by_name($$) {
    my ($self, $country) = @_;
    return($self->get_continent_by_iso2code($self->get_iso2code_by_name($country)));
}

sub get_continent_by_iso3code($$) {
    my ($self, $iso3) = @_;
    return($self->get_continent_by_iso2code($self->get_iso2code_by_iso3code($iso3)));
}

sub get_continent_by_fipscode($$) {
    my ($self, $fips) = @_;
    return($self->get_continent_by_iso2code($self->get_iso2code_by_fipscode($fips)));
}

sub get_latlon_by_name($$) {
    my ($self, $name) = @_;
    return($self->get_latlon_by_iso2code($self->get_iso2code_by_name($name)));
}

sub get_latlon_by_iso3code($$) {
    my ($self, $iso3) = @_;
    return($self->get_latlon_by_iso2code($self->get_iso2code_by_iso3code($iso3)));
}

sub get_latlon_by_fipscode($$) {
    my ($self, $fips) = @_;
    return($self->get_latlon_by_iso2code($self->get_iso2code_by_fipscode($fips)));
}

sub get_location_by_name($$) {
    my ($self, $name) = @_;
    return($self->get_location_by_iso2code($self->get_iso2code_by_name($name)));
}

sub get_location_by_iso3code($$) {
    my ($self, $iso3) = @_;
    return($self->get_location_by_iso2code($self->get_iso2code_by_iso3code($iso3)));
}

sub get_location_by_fipscode($$) {
    my ($self, $fips) = @_;
    return($self->get_location_by_iso2code($self->get_iso2code_by_fipscode($fips)));
}

sub new ($;$$$$) {
    my ($class, $countryfile, $locfile, $iso3file, $fipsfile, $contfile) = @_;

    my $type = ref($class) || $class;
    my $self = {};
    bless $self, $class;

    if (defined $countryfile) {
	$self->{'country_data_file'} = $countryfile;
    } else {
	$self->{'country_data_file'} = "$coral_dir/etc/iso3166_2letter.txt";
    }

    if (defined $locfile) {
	$self->{'location_data_file'} = $locfile;
    } else {
	$self->{'location_data_file'} = "$coral_dir/etc/iso3166_loc.txt";
    }

    if (defined $iso3file) {
	$self->{'iso3_data_file'} = $iso3file;
    } else {
	$self->{'iso3_data_file'} = "$coral_dir/etc/iso3166_3letter.txt";
    }

    if (defined $fipsfile) {
	$self->{'fips_data_file'} = $fipsfile;
    } else {
	$self->{'fips_data_file'} = "$coral_dir/etc/fips.txt";
    }

    if (defined $contfile) {
	$self->{'continent_data_file'} = $contfile;
    } else {
	$self->{'continent_data_file'} = "$coral_dir/etc/continents.txt";
    }

    $self->_load_data(	$self->{'country_data_file'},
			$self->{'location_data_file'},
			$self->{'iso3_data_file'},
			$self->{'fips_data_file'},
			$self->{'continent_data_file'},
		    );
    return $self;
}

1;

__END__

# POD Documentation

=head1 NAME

Countries.pm - Perl module providing country name, country code, and continent information

=head1 SYNOPSIS

    use CAIDA::Countries;

    my $countries = new CAIDA::Countries();

    print "Canada's 2-letter ISO code is: " .
	$country->get_iso2code_by_name('Canada') . "\n";
    print "Zimbabwe is on the continent of " .
	$country->get_contname_by_contcode(
	$country->get_continent_by_iso2code(
	$country->get_iso2code_by_name('Zimbabwe'))) . ".\n";

=head1 DESCRIPTION

Countries is a module that lets you look up information on countries,
continents, and country locations.  It is meant to provide general,
relatively static information.  It does not map latitude and longitude
to a specific country, but it does map the name of a country to the
latitude and longitude of its geographic center.

=over 4

=item Module Setup

=over 4

=item new(COUNTRY-NAME--ISO2--FILE, ISO2--LOCATION--FILE, ISO2--ISO3--FILE, ISO2--FIPS--FILE, CONTINENT-CODE--CONTINENT-NAME--FILE)

    sets up a new Countries module object.  takes five optional arguments
    describing the location of the input data files you wish to use to
    perform the country/country code/continent/location mappings.  in all
    files, a # indicates a comment line to be ignored.  if specified, each
    data source file will be used in lieu of the defaults listed below:

=over 4

=item COUNTRY-NAME--ISO2--FILE

    file of the format:
    "ISO-2-letter-code<tab>country-full-name\n"

    a name in parentheses indicates an alternate name for that country.  a
    name in square brackets indicates an optional addition (usually a prefix)
    to the existing name.

    default: <your-coral-directory>/etc/iso3166_2letter.txt

=item ISO2--LOCATION--FILE

    file of the format:
    "ISO-2-letter-code<tab>continent-code<tab>latitude,longitude\n"

    default: <your-coral-directory/etc/iso3166_loc.txt

=item ISO2--ISO3--FILE

    file of the format:
    "ISO-2-letter-code<tab>ISO-3-letter-code\n"

    default: <your-coral-directory/etc/iso3166_3letter.txt

=item ISO2--FIPS--FILE

    file of the format:
    "ISO-2-letter-code<tab>fips-code\n"

    default: <your-coral-directory/etc/iso3166_fips.txt

=item CONTINENT-CODE--CONTINENT-NAME--FILE

    file of the format:
    "continent-code<tab>continent-name\n"

    default: <your-coral-directory/etc/continents.txt

=back

=for html These files are further documented in conjunction with other CoralReef
data files at: <a href="../../etc/doc/txt_data_files.html">txt_data_files.html</a><br /><br />

=back

=item Country Name Information

Countries.pm lets you look up country names by country code (ISO2,
ISO3, or FIPS), look up country code (ISO2, ISO3, FIPS) by country
name, and convert between verious types of country codes.

=over 4

=item get_name_by_iso2code(ISO2CODE)

    returns the full name of the country specified by the given ISO 2-letter
    country code.

=item get_name_by_iso3code(ISO3CODE)

    returns the full name of the country specified by the given ISO 3-letter
    country code.

=item get_name_by_fipscode(FIPSCODE)

    returns the full name of the country specified by the given FIPS
    country code.

=item get_iso2code_by_name(COUNTRY-NAME)

    returns the ISO 2-letter country code that corresponds to the provided
    name of a country.

=item get_iso2code_by_iso3code(ISO3CODE)

    returns the ISO 2-letter country code that corresponds to the given ISO
    3-letter country code.

=item get_iso2code_by_fipscode(FIPSCODE)

    returns the ISO 2-letter country code that corresponds to the given 
    FIPS country code.

=item get_iso3code_by_name(COUNTRY-NAME)

    returns the ISO 3-letter country code that corresponds to the provided
    name of a country.

=item get_iso3code_by_iso2code(ISO2CODE)

    returns the ISO 3-letter country code that corresponds to the given ISO
    2-letter country code.

=item get_iso3code_by_fipscode(FIPSCODE)

    returns the ISO 3-letter country code that corresponds to the given
    FIPS country code.


=item get_fipscode_by_name(COUNTRY-NAME)

    returns the FIPS country code that corresponds to the provided
    name of a country.

=item get_fipscode_by_iso2code(ISO2CODE)

    returns the FIPS country code that corresponds to the given ISO 2-letter
    country code.

=item get_fipscode_by_iso3code(ISO3CODE)

    returns the FIPS country code that corresponds to the given ISO
    3-letter country code.

=back


=item Continent Information

=over 4

=item get_contname_by_contcode(CONTINENT-CODE)

    returns the continent code that corresponds to the provided
    continent name.

=item get_contcode_by_contname(CONTINENT-NAME)

    returns the continent name that corresponds to the provided
    continent code.

=item get_continent_by_name(COUNTRY-NAME)

    returns the continent code that corresponds to the provided
    country name.

=item get_continent_by_iso2code(ISO2CODE)

    returns the continent code that corresponds to the provided
    iso 2-letter country code.

=item get_continent_by_iso3code(ISO3CODE)

    returns the continent code that corresponds to the provided
    iso 3-letter country code.

=item get_continent_by_fipscode(FIPSCODE)

    returns the continent code that corresponds to the provided
    fips country code.

=item get_names_by_contcode(CONTINENT-CODE)

    returns a reference to an array that is a list of the names of all of
    the countries inside the continent that corresponds to the provided
    continent code.

=item get_iso2codes_by_contcode(CONTINENT-CODE)

    returns a reference to an array that is a list of the ISO 2-letter
    country codes of all of the countries inside the continent that
    corresponds to the provided continent code.

=item get_iso3codes_by_contcode(CONTINENT-CODE)

    returns a reference to an array that is a list of the ISO 3-letter
    country codes of all of the countries inside the continent that
    corresponds to the provided continent code.

=item get_fipscodes_by_contcode(CONTINENT-CODE)

    returns a reference to an array that is a list of the FIPS
    country codes of all of the countries inside the continent that
    corresponds to the provided continent code.


=back

=item Location Information

=over 4

=item get_location_by_name(COUNTRY-NAME)

    returns a string of the form "continent<tab>latitude,longitude" that
    corresponds to the geographic center of the country specified by the
    given country name.

=item get_location_by_iso2code(ISO2CODE)

    returns a string of the form "continent<tab>latitude,longitude" that
    corresponds to the geographic center of the country specified by the
    given iso 2-letter country code.

=item get_location_by_iso3code(ISO3CODE)

    returns a string of the form "continent<tab>latitude,longitude" that
    corresponds to the geographic center of the country specified by the
    given iso 3-letter country code.

=item get_location_by_fipscode(FIPSCODE)

    returns a string of the form "continent<tab>latitude,longitude" that
    corresponds to the geographic center of the country specified by the
    given fips country code.


=item get_latlon_by_name(COUNTRY-NAME)

    returns a string of the form "latitude,longitude" that corresponds
    to the geographic center of the country specified by the given
    country name.

=item get_latlon_by_iso2code(ISO2CODE)

    returns a string of the form "latitude,longitude" that corresponds
    to the geographic center of the country specified by the given
    iso 2-letter country code.

=item get_latlon_by_iso3code(ISO3CODE)

    returns a string of the form "latitude,longitude" that corresponds
    to the geographic center of the country specified by the given
    iso 3-letter country code.

=item get_latlon_by_fipscode(FIPSCODE)

    returns a string of the form "latitude,longitude" that corresponds
    to the geographic center of the country specified by the given
    fipscountry code.


=item get_split_loc(ISO2CODE, TARGET-FLAG)

    
    if target-flag is 0:
    returns the continent code that corresponds to the provided
    iso 2-letter country code.

    if target-flag is 1:
    returns a string of the form "latitude,longitude" that corresponds
    to the geographic center of the country specified by the given
    iso 2-letter country code.
    
    this function is used extensively within the module to support all of the
    previously documented functions; it is available for external use as well.


=back

=item Data Output

    each of these functions takes a reference to a file as an optional
    argument.  if no file reference is given, the data is sent to STDOUT.

=over 4

=item dump_continents_to_countries(FILEREF)

    prints the continent code/iso 2-letter country code mappings as an
    alphabetized list to the specified file as lines of the form: 
    "continent-code<tab>iso-2-letter-code<tab>iso-2-letter-code...\n"

=item dump_locations (FILEREF)

    prints the ISO 2-letter code/location mappings to the specified file
    as lines of the form: 
    "iso-2-letter-code<tab>continent-code<tab>latitude,longitude\n"

=item dump_countries (FILEREF)

    prints the country name/ISO 2-letter code mappings to the specified
    file as lines of the form: 
    "country-name<tab>iso-2-letter-code\n"

=item dump_iso2codes_to_countries (FILEREF)

    prints the ISO 2-letter code/country name mappings to the specified
    file as lines of the form: 
    "iso-2-letter-code<tab>country-name\n"

=item dump_iso2codes_to_iso3codes (FILEREF)

    prints the ISO 2-letter code/ISO 3-letter code mappings to the
    specified file as lines of the form: 
    "iso-2-letter-code<tab>iso-3-letter-code\n"

=item dump_iso3codes_to_iso2codes (FILEREF)

    prints the ISO 3-letter code/ISO 2-letter code mappings to the
    specified file as lines of the form: 
    "iso-3-letter-code<tab>iso-2-letter-code\n"

=item dump_iso2codes_to_fipscodes (FILEREF)

    prints the ISO 2-letter code/FIPS code mappings to the specified file
    as lines of the form: 
    "iso-2-letter-code<tab>fips-code\n"

=item dump_fipscodes_to_iso2_codes (FILEREF)

    prints the FIPS code/ISO 2-letter code mappings to the specified file
    as lines of the form: 
    "fips-code<tab>iso-2-letter-code\n"

=item dump_continents_to_names (FILEREF)

    prints the continent name/continent code mappings to the specified
    file as lines of the form: 
    "continent-code<tab>continent-name\n"

=item dump_names_to_continents (FILEREF)

    prints the continent code/country name mappings to the specified
    file as lines of the form: 
    "continent-name<tab>continent-code\n"

=back

=back

=head1 ERRORS

=head1 EXAMPLES

    use CAIDA::Countries;
    my $country = new CAIDA::Countries();

    $country->get_iso2code_by_name('Canada');
    $country->get_name_by_iso2code('ca');

    $country->get_iso3code_by_iso2code('ca');
    $country->get_iso2code_by_iso3code('can');

    $country->get_fipscode_by_iso2code('cc');
    $country->get_iso2code_by_fipscode('ck');

    $country->get_location_by_iso2code('ca');
    $country->get_iso2codes_by_contcode('na');
    $country->get_continent_by_iso2code('ca');
    $country->get_latlon_by_iso2code('ca');

    $country->get_name_by_iso3code('can');
    $country->get_name_by_fipscode('ck');
    $country->get_names_by_contcode('na');

    $country->get_fipscode_by_name('Cocos Islands');
    $country->get_fipscode_by_iso3code('cck');
    $country->get_fipscodes_by_contcode('na');

    $country->get_continent_by_name('Canada');
    $country->get_continent_by_iso3code('can');
    $country->get_continent_by_fipscode('ck');

    $country->get_latlon_by_name('Canada');
    $country->get_latlon_by_iso3code('can');
    $country->get_latlon_by_fipscode('ck');

    $country->get_location_by_name('Canada');
    $country->get_location_by_iso3code('can');
    $country->get_location_by_fipscode('ck');

    $country->get_contname_by_contcode('na');
    $country->get_contcode_by_contname('North America');
    
    my $loc = 'ca';
    $country->get_split_loc($loc, 0);
    $country->get_split_loc($loc, 1);
    
    $country->dump_countries();

=head1 ENVIRONMENT

=head1 SEE ALSO

=head1 NOTES

=head1 WARNINGS

=head1 DIAGNOSTICS

=head1 BUGS

=head1 RESTRICTIONS

=head1 AUTHOR

CoralReef Development team, CAIDA <coral-info@caida.org>
