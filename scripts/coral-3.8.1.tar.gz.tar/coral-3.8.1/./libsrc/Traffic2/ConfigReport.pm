package CAIDA::Traffic2::ConfigReport;
require 5.004;
## $Id: ConfigReport.pm,v 1.62 2007/06/06 18:17:50 kkeys Exp $ $Name: release-3-8-1 $
##
## -----------------------------------------------------------------------
## Perl module:Traffic2::ConfigReport.pm
## 
## This Perl module moves the overhead associated with initializing and 
## maintaining global state for the t2_report program.  This is a Perl
## module only in so far as it separates code from the main script.  No
## object oriented features are used or needed.  Instead, object-oriented
## capabilities from the CPAN Perl module AppConfig.pm are used 
## extensively to maintain state in a "tidy" fashion.
## 
## Note: test routines require the Test.pm module or Perl 5.005
##
## Copyright 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
## All Rights Reserved 
##
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
##
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
##
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
##
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
##
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program. Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
##
## Contact: coral-info@caida.org
## ---------------------------------------------------------------------


# Set up object export condition.  No functions accessible directly.
use Exporter ();
@ISA       = qw(Exporter);
@EXPORT    = qw(
		define_config_state
		reset_config_state
		get_config_state 
		user_help 
		dump_config_state
	       );
@EXPORT_OK = qw();

# Define required CVS variables
$cvs_Id = '$Id: ConfigReport.pm,v 1.62 2007/06/06 18:17:50 kkeys Exp $';
$cvs_Author = '$Author: kkeys $';
$cvs_Name = '$Name: release-3-8-1 $';
$cvs_Revision = '$Revision: 1.62 $';

# Enable error messages to come from calling script
use Carp;

# Force this module to adhere to safe programming practices.
use strict;

# Version of module
my $VERSION = 1.0;

use AppConfig qw(:argcount);
use CAIDA::Traffic2::ReportUserGuide;

use vars qw($base_dir $config_filename $ports_filename $user_guide);

# Presently not used but eventually path to global configuration file.
$config_filename = "t2_report.conf";
$ports_filename = "t2_report.ports";

# New object of the Report Generator's specific User Guide.
$user_guide = new CAIDA::Traffic2::ReportUserGuide;

#   .   .   .   .   .   . Internal methods  .   .   .   .   .   .   .   .


sub _get_user_path($ ) {
# ----------------------------------------------------------
# Helper function to determine path to user's home 
# directory.  It is a convenience to finding directory for
# user specific preferences.
# ----------------------------------------------------------
    my $prefs_folder = shift;
    
    # If using environment is a problem we can use system calls instead.
    # my @home_info = getwuid($UID);
    # my $home_dir = $home_info[7];
    my $home_dir = $ENV{'HOME'}; # Get home directory for user.
    return("$home_dir/$prefs_folder");
}

sub _is_a_time($ ) {
# ----------------------------------------------------------
# Helper function to test if a string is a set of numbers 
# separated by colons.
# ----------------------------------------------------------
    my $time_string = shift;
    my @time_parts;

    if ($time_string =~ /:/) {
	my @time_parts = split(/:/, $time_string);
	foreach my $part (@time_parts) {
	    unless ($part == 1*$part) {
		die "Unrecognized time format";
	    }
	} 
	return(@time_parts);
    }else {
	return(undef);
    }
}

sub _parse_combining_option($ ) {
# ----------------------------------------------------------
# Helper function to convert the argument passed to the
# sample combining function to allow for the specification
# of either a time or number of samples to be combined.
# ----------------------------------------------------------
    my $config = shift;
    my $combine_format = $config->get('merge');
    my $debug = $config->get('debug');
    my $epsilon = $config->get('epsilon');
    my $combine_samples;
    my @time_parts;

    if($combine_format =~ /:/) {
	# Fuss through the cases to make sense of time.

	$combine_format = "time";
	# Should run tests to make sure these are numbers.
	if($#time_parts == 2) {
	    $combine_samples = $time_parts[0]*360+
		$time_parts[1]*60+$time_parts[2];
	} 
	elsif($#time_parts == 1) {
	    $combine_samples = $time_parts[0]*360+$time_parts[1]*60;
	} else {
	    $combine_samples = $time_parts[0]*360;
	}
	if($debug) {
	    print STDERR "-D> Intervals will be combined into", 
	    " approximately: $combine_samples second blocks\n";
	}
	$combine_samples += $epsilon;
    } 
    elsif($combine_format =~ /^\d+$/) {
	$combine_samples = $combine_format;
	$combine_format = "samples";
	if($debug) {
	    print STDERR "-D> Intervals will be combined into groups of ",
	    " $combine_samples size\n";
	}
	$combine_samples--;
    } else {
	print STDERR "Unable to interpret Interval combination options\n";
	print STDERR "Option will be ignored\n";
	$combine_format = 'none';
    }
    $config->set('combine_format', $combine_format);
    $config->set('combine_samples', $combine_samples);
} # End sub _parse_combining_option

sub _command_line_config( ) {
# ----------------------------------------------------------
# Helper subroutine to search "by hand" through the command
# line arguments before any other parsers are applied.  
# Unfortunately available parsers either "swallow up"
# arguments or would not execute in the properly order.
# Any command line configuration file should be loaded
# BEFORE other command line options are processed.
# ---------------------------------------------------------
    my @argv = @main::ARGV;
    my $arg_count;
    my ($tmp, $file) = (undef, undef);

    # Loop through arguments looking for preference file.
    for ($arg_count=0; $arg_count <= $#argv; $arg_count++) {
	if ( ($argv[$arg_count] =~ /-f\=/i) or 
	     ($argv[$arg_count] =~ /-configfile\=/i) 
	   ) {
	    ($tmp, $file) = split('=', $argv[$arg_count]);
	    last;
	}
	elsif ( ($argv[$arg_count] =~ /-f$/i) or 
	        ($argv[$arg_count] =~ /-configfile$/i) 
	      ) {
	    $file = $argv[$arg_count+1];
	    last;
	}
    }
    return($file);
}

sub _use_user_guide( ) {
# ----------------------------------------------------------
# Look "by hand" for command line options related to 
# providing user information.  These commands are processed
# before other command line arguments because AppConfig
# insists on a fixed number of arguments to a command line
# option.
# XXX Perhaps try using Getopt::Long to fix?
# ----------------------------------------------------------
    my @argv = @main::ARGV;
    my ($arg_count, $tmp);
    my $help = undef;
    my $help_item = undef;

    # Loop through arguments looking for help request
    for ($arg_count=0; $arg_count <= $#argv; $arg_count++) {
	if ( ($argv[$arg_count] =~ /-h\=/i) or 
	     ($argv[$arg_count] =~ /-help\=/i) 
	   ) {
	    $help = 1;
	    ($tmp, $help_item) = split('=', $argv[$arg_count]);
	    last;
	}
	elsif ( ($argv[$arg_count] =~ /-h$/i) or 
	        ($argv[$arg_count] =~ /-help$/i) 
	      ) {
	    $help = 1;
	    if ($argv[$arg_count+1] !~/^-/) {
		$help_item = $argv[$arg_count+1];
	    }
	    last;
	}
    }
    return($help, $help_item);
}

sub _member_of($@ ) {
# ----------------------------------------------------------
# Recursive predicate that tests if item is a member of
# the list (set).
# ----------------------------------------------------------
    my $element = shift;
    my $test = shift;
    my @set = @_;

    if ($element eq $test) {
	return(1);
    } 
    elsif (scalar(@set) == 0) {
	return(0);
    } else {
	return(_member_of($element, @set));
    }
}

sub _rrd_graph_subset($$$ ) {
# ----------------------------------------------------------
# Internal subroutine that checks to see that all items
# that have been requested to be graphed are a items for
# which RRD data is being collected.  It generates
# error messages for any item that doesn't have an
# associated database and returns a list of all items
# that can be graphed.
# ----------------------------------------------------------
    my @request_set = @{shift(@_)};
    my @database_set = @{shift(@_)};
    my $category = shift;
    my @graph_set;
    my $request;

    foreach $request (@request_set) {
	if(_member_of($request, @database_set)) {
	    push @graph_set, $request;
	} else {
	    print STDERR "Item $request isn't in RRDtool", 
	                 " dataset of $category\n";
	}
    }
    return(@graph_set);
}

sub my_die {
# ----------------------------------------------------------
# Patch Error handler that forces AppConfig to stop after
# an error has occurred
# ----------------------------------------------------------
  print STDERR ("Configuration Error - variable ", @_, "\n");
  exit(1);
}

#   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   

sub define_config_state( ) {
# ----------------------------------------------------------
# Convenient spot to define all global variables and packed
# into a function that can be used to reset all global 
# variables back to their "factory settings."
#
# DO NOT CHANGE GLOBAL VARIABLES ANYWHERE ELSE BUT IN THIS
# SUBROUTINE!!!! - YOU HAVE BEEN WARNED!
# ----------------------------------------------------------
    my $config;
    
    # Create new AppConfig object with global settings
    $config = AppConfig->new( {
				   ERROR => \&my_die,
			       GLOBAL => {
					  DEFAULT  => undef,
					  # Most arguments are scalars.
					  ARGCOUNT =>  ARGCOUNT_ONE,
					 }
			      }
			    );
    # Define variables in configuration.
    # First define variables that are common command line options.
    $config->define('asfinder', {
				 ARGCOUNT => ARGCOUNT_ONE,
				 DEFAULT => 0,
				 ALIAS => 'a'
			       } 
		   );
    $config->define('RRD_backdate', {ARGCOUNT => ARGCOUNT_ONE,
				     ALIAS => 'backdate',
				     ALIAS => 'b',
				     DEFAULT => 0,
					}
		   );
    $config->define('command', {
				ARGCOUNT => ARGCOUNT_LIST,
				ALIAS => 'c'
			       }
		   );
    $config->define('debug', {DEFAULT => 0, 
			      ALIAS => 'd',
				  VALIDATE => '^\d+$'
			     }
		   );
    # Placeholder ... actually parsed out before.
    $config->define('configfile', {
				  ARGCOUNT => ARGCOUNT_ONE,
				  ALIAS => 'f'
				 }
		   );
    $config->define('graphtool', { 
				  DEFAULT => "none",
				  ALIAS => 'g',
				 }
		   );

    $config->define('incremental_read', {
                                     ARGCOUNT => ARGCOUNT_ONE,
                                     DEFAULT => 0,
                                    }
                   );
    $config->define('internetapps', {
                                     ARGCOUNT => ARGCOUNT_ONE,
                                     DEFAULT => 1,
                                     ALIAS => 'i',
                                    }
                   );

    $config->define('javaserver', {
				   ARGCOUNT => ARGCOUNT_ONE,
				   DEFAULT => undef,
				   ALIAS => 'j',
				  }
		   );

    $config->define('merge', {
			      ARGCOUNT => ARGCOUNT_ONE,
			      ALIAS => 'm',
				  VALIDATE => '^\d+$'
			     }
		   );
    $config->define('netgeo', { 
			       DEFAULT => 0,
			       ALIAS => 'n',
			      } 
		   );
    $config->define('promiscuous', { 
				    DEFAULT => 0,
				    ALIAS => 'p',
				  VALIDATE => '^\d+$'
				   }
		   );
    $config->define('RRDtool', { 
				ARGCOUNT => ARGCOUNT_ONE,
				DEFAULT => 0,
				ALIAS => 'r'
			       } 
		   );
    $config->define('RRD_nograph', { 
				ARGCOUNT => ARGCOUNT_ONE,
				DEFAULT => 0,
			       } 
		   );
    $config->define('sample_limit', { # XXX should be changed to just debug
					DEFAULT => -1,
				        ALIAS => 'samples',
				        ALIAS => 's'
				       }
		   );
    $config->define('display_count', { 
				      DEFAULT => 10, 
				      ALIAS => 'todisplay',
				      ALIAS => 't',
				      VALIDATE => '^\d+$'
				     }
		   );
    $config->define('rrd_display_count', {DEFAULT => 5,
                                          VALIDATE => '^\d+$'
				     }
		   );
                                     
    $config->define('verbose', {ARGCOUNT => ARGCOUNT_HASH,
                                ALIAS => 'v'
                               }
                   );
    $config->define('with_rrd_top_apps', {DEFAULT => 0,
					  ALIAS => 'top_apps',
					  ALIAS => 'w',
					 }
		   );
    $config->define('zaptotals', { 
				      DEFAULT => 0, 
				      ALIAS => 'z',
				      VALIDATE => '^\d+$'
				     }
		   );

    # Define config variables that aren't command line options or are
    # straight arguments to t2_report.

    $config->define('RRD_DIR', { ARGCOUNT => ARGCOUNT_ONE });
    $config->define('PROTO_NAMES', { ARGCOUNT => ARGCOUNT_HASH });
    $config->define('RRD_GRAPH_PROTOS', { ARGCOUNT => ARGCOUNT_LIST });
    $config->define('RRD_GRAPH_COUNTRIES', { ARGCOUNT => ARGCOUNT_LIST });
    # Java archive codebase to speed up loading.
    $config->define('javaserver_archive', { DEFAULT => undef });

    $config->define('RRDCOLORS', { ARGCOUNT => ARGCOUNT_LIST });
    $config->define('image_file_cnt');

    $config->define('extra_html');
    $config->define('html_dir');
    $config->define('interval_dir');
    $config->define('page_dir');
    $config->define('site_name');
    $config->define('route_table');
    $config->define('source_file');
    $config->define('AppPorts_rules');
    $config->define('subif_names', { ARGCOUNT => ARGCOUNT_HASH });
    $config->define('rrd_graph_apps', { ARGCOUNT => ARGCOUNT_LIST });
    $config->define('rrd_top_apps_bytes', { ARGCOUNT => ARGCOUNT_ONE } );
    $config->define('rrd_top_apps_packets', { ARGCOUNT => ARGCOUNT_ONE } );
    $config->define('rrd_top_apps_flows', { ARGCOUNT => ARGCOUNT_ONE } );
    # RRD picture size parameters
    $config->define('rrd_graph_width', { ARGCOUNT => ARGCOUNT_ONE,
					 DEFAULT => 400
				       } );
    $config->define('rrd_graph_height', { ARGCOUNT => ARGCOUNT_ONE,
				          DEFAULT => 200
				 } );
    # Desired graph intervals in hours.
    $config->define('rrd_time_samples', { ARGCOUNT => ARGCOUNT_LIST,
					  DEFAULT => 1, 
					  DEFAULT => 24, 
					  DEFAULT => 7*24, 
					  DEFAULT => 28*24, 
					  DEFAULT => 365*24
					}
		    );
    # Configuration information for Pie charts
    $config->define('pie_slices', {DEFAULT => 20});
    $config->define('3d_pie', {DEFAULT => 0});

    # Internal state variables used to avoid clutter in t2_report.pl
    $config->define('combine_samples', {DEFAULT => 0});
    $config->define('combine_format', {DEFAULT => 'none'});
    $config->define('epsilon', { DEFAULT => 7 });
    $config->define('traffic2_dump_dir');

    # Internal state variables related to backlog management
    $config->define('backlog', {DEFAULT => 0});
    $config->define('sample_interval', {DEFAULT => 300});

# Add back if UserGuide could be handled by AppConfig.
#    $config->define('UserGuide');

    return($config);
}

sub reset_config_state($ ) {
# ----------------------------------------------------------
# Routine to reset all arrays to an empty list.  This 
# allows for the reloading of arrays without appending 
# the same values to the end.
# ----------------------------------------------------------
    my $config = shift;
    my @reset_arrays = qw(rrd_graph_apps RRDCOLORS RRD_GRAPH_PROTOS 
			  command rrd_time_samples);

    foreach my $array (@reset_arrays) {
	$config->_default($array);
    }
}

sub get_config_state ($$$) {
# ----------------------------------------------------------
# Catch all subroutine to get state of all global variables
# by all the "approved" methods.  Presently, the following
# strategy is applied:
#    1st: The $coral_dir/etc directory is searched for
#         a file called t2_report.conf.  If found its
#         settings are loaded.
#    2nd: The script looks for the directory ~/.Coral and
#         if it finds it, it looks for the file 
#	      t2_report.conf inside.  If found its settings are
#         loaded.
#    3rd: Finally command line options are processed.
#         These can include yet a third file of 
#         configuration options and/or additional settings.
#         command line options are processed last so that
#         can override any previously read configuration
#         file (including the one specified on the command
#         line.)
# ----------------------------------------------------------
    my $config = shift;
    my $base_dir = shift(@_) . "/etc";
    my $arg_ref = shift;

    my $base_config = "$base_dir/$config_filename";
    my $user_dir = _get_user_path('.Coral');
    my $user_config =  "$user_dir/$config_filename";
    my ($file, $help, $help_item, $ports_file);
    my (@store_protocol, @graph_protocol);
    my (@store_apps, @graph_apps);
    
    # Check if we have a file in the base CoralReef tree
    # presently not implemented.
     if (-d $base_dir) {
 	if (-e $base_config) {
 	    unless ($config->file($base_config)) {
 		carp "Error in t2_report configuration file: $base_config";
 	    }
  	}
 	if (-e "$base_dir/$ports_filename") {
 	    $ports_file = "$base_dir/$ports_filename";
 	}
      }
    
    # Next check for a file in the user directory.
    if (-d $user_dir) {
	if (-e $user_config) {
	    unless ($config->file($user_config)) {
		carp "Error in t2_report configuration file: $user_config";
	    }
	}
	if (-e "$user_dir/$ports_filename") {
	    $ports_file = "$user_dir/$ports_filename";
	}

    }

    # Check to see if we have command line configuration file.
    $file =  _command_line_config();
    # If we have a command line preference file, slurp it up!
    if ($file and (-e $file)) {
	unless ($config->file($file)) {
	    carp "Error in t2_report configuration file: $file";
	}
    }

    # Check if there is a request for help help information.
    ($help, $help_item) = _use_user_guide( );
    if ($help) {
	$user_guide->process_request($help_item);
	exit(0);
    }
	
	
	
    # Finally, use the built-in function of AppConfig to parse
    # command line arguments .... If needed change to GetOpt
    my $args_state = $config->args($arg_ref);
    unless ($args_state) {
	print STDERR "Error in command line arguments ... will be ignored\n";
    }

    # In order to simplify use on command line, check to see if the 
    # boolean switches on ASFinder and RRDtool don't in fact point to 
    # a BGProuting table and a RRDtool data directory respectively.
    # This saves the user from turning the option on and then having to 
    # specify required arguments.
    if ($config->get('asfinder') and (-e $config->get('asfinder'))) {
	$config->set('route_table', $config->get('asfinder'));
    }
    if ($config->get('rrdtool') and (-d $config->get('rrdtool'))) {
	$config->set('RRD_DIR', $config->get('rrdtool'));
    }

    # For compatibility with other CoralReef apps, take any -c options
    # and process them as command line options.  Note, these arguments
    # receive no syntax checking!
    foreach my $option (@{$config->get('command')}) {
	my ($config_var, $value) = split(/\s|\=/, $option, 2);
	$config->set($config_var, $value);
    }
    
    # Now that all permutations of options have been loaded, decode
    # the combination options.
    if (defined($config->get('merge'))) {
	_parse_combining_option($config);
    } 
    # Disable them for now.  XXX Fix for next release.
    if ($config->get('combine_format') ne 'none') {
	print STDERR "Warning: merging of sample periods not supported in ",
	             "this release\n";
	$config->set('combine_format', 'none');
    }
    # If there exists a file of application ports - assign value.
    if ((not $config->get('AppPorts_rules')) or 
	 (not -e $config->get('AppPorts_rules')) and 
	 $ports_file) {
	 $config->set('AppPorts_rules', $ports_file);
     }
} #End get_config_state


sub dump_config_state($ ) {
# ----------------------------------------------------------
# Subroutine provided mainly for the benefit of debugging.
# It dumps the state of configuration variables to STDERR.
# To ease reading, it displays arrays and hashes in the
# same format that the program uses to read them one item
# per line.
# ----------------------------------------------------------
    my $config = shift;
    
    # Fetch hash of variables and values
    my %config_hash = $config->varlist('.*');
    
    # Start dump
    print STDERR "-D>\n-D>\t\t=== DUMP OF CONFIGURATION VARIABLES ===\n";
    
    # Loop through all the configuration variables.
    foreach my $var (keys(%config_hash)) {
	# If values is a hash, extract key/value pairs
	if (ref($config_hash{$var}) eq 'HASH') {
	    print STDERR "-D>\n-D>\tHASH: $var\n";
	    foreach my $key (keys(%{$config_hash{$var}})) {
		printf STDERR "-D>\t%20s\t%10s\t%s\n", $var, $key, 
		$config_hash{$var}->{$key};
	    }
	    print STDERR "-D>\n";
	    # If values are an array display each value
	} elsif (ref($config_hash{$var}) eq 'ARRAY') {
	    print STDERR "-D>\n-D>\tARRAY: $var\n";
	    foreach my $item (@{$config_hash{$var}}) {
		printf STDERR "-D>\t%20s\t%s\n", $var, $item; 
	    }
	    print STDERR "-D>\n";
	    # Else display scalar
	} else {
	    printf STDERR "-D>\t%20s\t%s\n", $var, $config_hash{$var};
	}
    }
    # Mark end of dump for ease of reading.
    print STDERR "-D>\n-D>\t\t=== End Configuration variables ===\n";
} # End dump_config_state
