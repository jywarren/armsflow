/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/* Any file that includes this one must first #define defproto().  This file is
 * included from coral_init.c, libcoral.h, and libsrc/CRL/protocols.h.
 *
 * Protocol numbers should not be changed, to retain compatibility with
 * traces taken by old versions of CoralReef.
 */

/* defproto(layer, prefix, abbr, proto_ok, id, desc) */

/* unknown protocol */
/* Tracefiles may contain this, so must not change across CoralReef versions */
defproto(0, PROTO, UNKNOWN,	0,0,	"Unknown")

/* Physical layer */
/* Tracefiles may contain this, so must not change across CoralReef versions */
defproto(1, PHY, ATM,		0,1001,	"ATM")
defproto(1, PHY, POS,		0,1008,	"Packet over SONET")

/* Data Link protocols (more or less - there are a lot of sublayers here) */
/* If you add something here, be sure to update coral_{type,to}_pcap.c */
/* Tracefiles may contain this, so must not change across CoralReef versions */
defproto(2, DLT, NULL,		0,0,	"Null")
defproto(2, DLT, ETHER,		1,1,	"Ethernet")
defproto(2, DLT, EN10MB,	0,1,	"Ethernet (10Mb)")	/* ==ETHER */
defproto(2, DLT, IEEE802,	1,6,	"IEEE 802 Networks")
defproto(2, DLT, ATM,		0,1001,	"")	    /* obsoleted by PHY_ATM */
defproto(2, DLT, ATM_AAL5,	0,1002,	"ATM AAL5")		/* over ATM */
defproto(2, DLT, ILMI,		1,1030,	"ILMI")
defproto(2, DLT, ATM_RFC1483,	1,11,	"AAL5 LLC/SNAP")	/* over AAL5 */
defproto(2, DLT, LANE_IEEE8023,	1,1003,	"LANE IEEE 802.3")	/* over AAL5 */
defproto(2, DLT, LANE_IEEE8025,	1,1004,	"LANE IEEE 802.5")	/* over AAL5 */
defproto(2, DLT, LANE_LLC,	1,1005,	"LANE LLC-multiplexed")	/* over AAL5 */
defproto(2, DLT, GIGX,		1,1007,	"DEC Gigaswitch?")	/* over AAL5 */
defproto(2, DLT, POS,		0,1008,	"")	/* obsoleted by PHY_POS */
defproto(2, DLT, CHDLC,		1,1009,	"Cisco HDLC")		/* over POS */
defproto(2, DLT, PPP,		1,1010,	"Point-to-Point Protocol")
defproto(2, DLT, PPPoHDLC,	0,1011,	"PPP over HDLC")
defproto(2, DLT, PPPoES,	0,1012,	"PPP over Ethernet (session stage)")
defproto(2, DLT, PPPoED,	0,1013,	"PPP over Ethernet (discovery stage)")
defproto(2, DLT, PPPoFR,	0,1014,	"PPP over Frame Relay")
defproto(2, DLT, BRIDGED_LAN,	0,1020,	"Bridged LAN")		/* over PPP */
defproto(2, DLT, IEEE8021D,	0,1021,	"IEEE 802.1D")
#ifndef NDEBUG /* hack - developer only */
defproto(2, DLT, FDDI,		0,1022,	"FDDI")
#endif
defproto(2, DLT, UoPOS,		0,1023,	"unknown protocol over PoS")
defproto(2, DLT, MPoFR,		1,1024,	"Multiprotocol over Frame Relay")
defproto(2, DLT, MPLS,		0,0x8847, "Multi-Protocol Label Switching")

/* Network protocols (layer 3, id 0x0000-0xFFFF matches ethertype) */
/* Tracefiles may contain this, so must not change across CoralReef versions */
defproto(3, NETPROTO, IPv4,	 1, 0x0800, "Internet Protocol version 4")
defproto(3, NETPROTO, IP,	 0, 0x0800, "Internet Protocol version 4")/*==IPv4*/
defproto(3, NETPROTO, ARP,	 1, 0x0806, "Address Resolution Protocol")
defproto(3, NETPROTO, IPX,	 1, 0x8037, "IPX")
defproto(3, NETPROTO, APPLETALK, 1, 0x809B, "AppleTalk")
defproto(3, NETPROTO, AARP,	 1, 0x80F3, "AppleTalk AARP")
defproto(3, NETPROTO, IPX_E,	 1, 0x8137, "IPX_E")
defproto(3, NETPROTO, IPv6,	 1, 0x86DD, "Internet Protocol version 6")

defproto(3, NETPROTO, RAW_IP,	 1,0x10000,	"raw IP")
defproto(3, PROTO,    ILMI_PDU,	 0,0x10406,	"ILMI_PDU")

/* IP protocols (layer 4, id 0-255 matches IP protocol numbers) */
/* Tracefiles shouldn't contain this, so may change across CoralReef versions */
defproto(4, IPPROTO, HOPOPTS,	0,0,	"hop-by-hop options")
defproto(4, IPPROTO, ICMP,	0,1,	"IPv4 Control Message Protocol")
defproto(4, IPPROTO, ICMP4,	0,1,	"IPv4 Control Message Protocol")
defproto(4, IPPROTO, IGMP,	0,2,	"Group Management Protocol")
defproto(4, IPPROTO, TCP,	0,6,	"Transport Control Protocol")
defproto(4, IPPROTO, UDP,	0,17,	"User Datagram Protocol")
defproto(4, IPPROTO, ROUTING,	0,43,	"routing header")
defproto(4, IPPROTO, FRAGMENT,	0,44,	"fragment header")
defproto(4, IPPROTO, RSVP,	0,46,	"Resource Reservation Protocol")
defproto(4, IPPROTO, GRE,	0,47,	"Generic Routing Encapsulation")
defproto(4, IPPROTO, ESP,	0,50,	"encap security payload")
defproto(4, IPPROTO, AH,	0,51,	"authentication header")
defproto(4, IPPROTO, ICMP6,	0,58,	"IPv6 Control Message Protocol") /* RFC 2463 */
defproto(4, IPPROTO, DSTOPTS,	0,60,	"destination options")

/* Higher layer protocols.  id 0-255 matches UDP port number. */
defproto(5, PROTO, DNS,		0,53,	"DNS")
defproto(5, PROTO, SNMP,	0,161,	"SNMP")
defproto(6, PROTO, SNMP_PDU,	0,161,	"SNMP_PDU")


#undef defproto

#define coral_proto_layer(proto) (proto >> 28)
#define coral_proto_num(proto) (proto & 0x0FFFFFFF)
#define coral_proto_is_IP(proto) \
    (proto == CORAL_NETPROTO_IPv4 || \
    proto == CORAL_NETPROTO_IPv6 || \
    proto == CORAL_NETPROTO_RAW_IP)
