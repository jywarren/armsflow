/* 
 * Copyright 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 */

/*
 * $Id: coral_binary.c,v 1.6 2007/06/06 18:17:53 kkeys Exp $
 */

static const char RCSid[]="$Id: coral_binary.c,v 1.6 2007/06/06 18:17:53 kkeys Exp $";

#include "config.h"
#include <sys/param.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <errno.h>

#include "libcoral.h"
#include "crl_byteorder.h"

#define BISIZE1	    0x00
#define BISIZE2	    0x40
#define BISIZE4	    0x80
#define BISIZE8	    0xc0

typedef union {
    uint8_t n8;
    uint16_t n16;
    uint32_t n32;
    uint64_t n64;
    char c[8];
} binint_t;

/* writes integer in network order */
size_t coral_fwrite_binint_func(FILE *file, const void *p, size_t size)
{
    binint_t b;

    switch (size) {
    case 1:
	return fwrite(p, 1, 1, file);
    case 2:
	b.n16 = crl_htons(*(uint16_t*)p);
	return fwrite(&b.n16, 2, 1, file);
    case 4:
	b.n32 = crl_htonl(*(uint32_t*)p);
	return fwrite(&b.n32, 4, 1, file);
    case 8:
	/* compression: first 2 bits tells whether integer is
	 * 6, 14, 30, or 62 bits. */
	b.n64 = *(uint64_t*)p;
	if (b.n64 <= 0x3F) {
	    b.n8 = b.n64;
	    b.c[0] |= BISIZE1;
	    return fwrite(&b.n8, 1, 1, file);
	} else if (b.n64 <= 0x3FFF) {
	    b.n16 = crl_htons(b.n64);
	    b.c[0] |= BISIZE2;
	    return fwrite(&b.n16, 2, 1, file);
	} else if (b.n64 <= 0x3FFFFFFFul) {
	    b.n32 = crl_htonl(b.n64);
	    b.c[0] |= BISIZE4;
	    return fwrite(&b.n32, 4, 1, file);
	} else if (b.n64 <= 0x3FFFFFFFFFFFFFFFull) {
	    b.n64 = crl_hton64(b.n64);
	    b.c[0] |= BISIZE8;
	    return fwrite(&b.n32, 8, 1, file);
	} else {
	    coral_diag(0, ("coral_fwrite_binint: number too large\n"));
	    return 0;
	}
    }
    return 0;
}

/* reads network order integer */
size_t coral_fread_binint_func(FILE *file, void *p, size_t size)
{
    binint_t b;
    uint8_t bisize;

    switch (size) {
    case 1:
	return fread(p, 1, 1, file);
    case 2:
	if ((size = fread(&b.n16, 2, 1, file)))
	    *(uint16_t*)p = crl_ntohs(b.n16);
	return size;
    case 4:
	if ((size = fread(&b.n32, 4, 1, file)))
	    *(uint32_t*)p = crl_ntohl(b.n32);
	return size;
    case 8:
	if (!(size = fread(&b.c[0], 1, 1, file)))
	    return 0;
	bisize = (b.c[0] & 0xc0);
	b.c[0] &= ~0xc0;
	switch (bisize) {
	case BISIZE1:
	    *(uint64_t*)p = b.n8;
	    return 1;
	case BISIZE2:
	    if ((size = fread(&b.c[1], 1, 1, file)))
		*(uint64_t*)p = crl_ntohs(b.n16);
	    return size+1;
	case BISIZE4:
	    if ((size = fread(&b.c[1], 1, 3, file)))
		*(uint64_t*)p = crl_ntohl(b.n32);
	    return size+1;
	case BISIZE8:
	    if ((size = fread(&b.c[1], 1, 7, file)))
		*(uint64_t*)p = crl_ntoh64(b.n64);
	    return size+1;
	}
    }
    return 0;
}

