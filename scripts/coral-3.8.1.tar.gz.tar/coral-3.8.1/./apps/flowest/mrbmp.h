/* 
 * Copyright 2003, 2004, 2005, 2007
 * The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program.  Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

#ifndef MRBMP_H
#define MRBMP_H

#include <string>
#include <memory>
#include <cmath>
#include <stdexcept>
#include "poolallocator.h"
#include "intmath.h"

#include <typeinfo> // XXX

extern const double MultiResBmp_consts[][4];

/*
 * c = number of virtual bitmap components of multiresolution bitmap
 * b = number of bits in each component (except the last)
 * k = ratio of resolutions of adjacent components
 */

template<class tag, class Key> class MultiResBmp {
    typedef MultiResBmp<tag, Key> Self_t;
    class subtag {};
    typedef Bitmap<subtag> BMP_t;
    BMP_t bmp;

public:
    friend class Param;
    class Param {
	static double rhomin(unsigned k) { return MultiResBmp_consts[k-2][0]; }
	static double rhomax(unsigned k) { return MultiResBmp_consts[k-2][1]; }
	static double errcoef(unsigned k) { return MultiResBmp_consts[k-2][2]; }
	friend class MultiResBmp;
	unsigned c;
	unsigned b;
	static const unsigned k = 2;
	unsigned lastb; // The size of the last component
	unsigned setmax;
	mutable PoolAllocator alloc;
	static double vbmperror(double rho, unsigned pb)
	    { return sqrt(exp(rho)-1)/rho/sqrt(pb); }
	static double mrblnerror(double rho, unsigned pk, unsigned pb, unsigned plastb)
	    { return sqrt(pb*(exp(rho)-1)+plastb*(exp(rho*pb/(pk-1)/plastb)-1))*(pk-1)/pk/rho/pb; }
	Param() : c(0), b(0), lastb(UINT32_MAX) {};
	void copy(const Param &src) { b = src.b; c = src.c; lastb = src.lastb; }
    public:
	Param(unsigned pd, unsigned pg, unsigned pc, unsigned pb);
	Param(uint64_t N, double E);

	std::string namestr() const { return "MultiResBmp::Param"; }
	std::string paramstr() const
	{
	    char buf[64]; // XXX Someday, stringstream is the way to go here
	    std::string ret_val;
	    sprintf(buf, "c=%u", c);
	    ret_val += buf;
	    sprintf(buf, ", b=%u", b);
	    ret_val += buf;
	    sprintf(buf, ", E=%lf", err());
	    ret_val += buf;
	    return ret_val;
	}

	void init();
	unsigned nbits() const { return (c-1)*b + lastb; }
	size_t varbytes() const
	    { return BMP_t::bytes(); } /* size of variable part */
	size_t bytes() const
	    { return sizeof(Self_t) + varbytes(); } /* total size */
	void stats() const { alloc.stats(); }
	double err() const
	{
	    double rho = rhomax(k); // XXX ???
	    // equation (5) from paper as of 2003-02-03
	    return sqrt((k-1)/double(k) * (exp(rho) + exp(rho/k) - 2)
		    + exp(rho/k/k) - 1) / (rho * sqrt(b * k / (k-1)));
	}
    };

    static const Param *p;

    void setmagic() { bmp.setmagic(); }

    void *operator new(size_t size)
    {
	void *ptr = p->alloc();
	(static_cast<MultiResBmp*>(ptr))->setmagic();
	return ptr;
    }

    void operator delete(void *ptr, size_t size) { p->alloc.free(ptr); }
    MultiResBmp() : bmp() {}
    MultiResBmp & reset() { bmp.reset(); return *this; }
    inline MultiResBmp & set(Key key);
    double estimate() const;
    bool have_mrbmp() { return true; }
#if 0
    void printdetails();
#endif
};

template<class tag, class Key> void MultiResBmp<tag, Key>::Param::init()
{
    if (log(b*k/(k-1))+log(k)*(c-1)+log(5)>32*log(2)-log(5))
	throw std::domain_error("These MultiResBmp parameters are unsafe with 32 bits");
    if (log(b*k/(k-1))+log(k)*(c-1)+log(5)>64*log(2)-log(5))
	throw std::domain_error("These MultiResBmp parameters are unsafe with 64 bits");
    BMP_t::nbits = nbits();
    alloc = PoolAllocator(bytes(), alignmentof(MultiResBmp));
    setmax = unsigned(b*(1-1/exp(rhomax(k)))+0.5);
    if (setmax >= b)
	throw std::domain_error("MultiResBmp b is too small");
}

template<class tag, class Key>
MultiResBmp<tag, Key>::Param::Param(unsigned pd, unsigned pg, unsigned pc, unsigned pb)
    : c(pc), b(pb), lastb(b * k/(k-1))
{
    if (b<=1)
	throw std::domain_error("MultiResBmp b must be > 1");
    if (c<=0)
	throw std::domain_error("MultiResBmp c must be > 0");
    if (k<2 || k>4)
	throw std::domain_error("MultiResBmp k must be in [2,4]");
    if (b % (k-1) != 0) {
	char buf[64];
	sprintf(buf, "MultiResBmp b must be divisible by %d", k-1);
	throw std::domain_error(buf);
    }
    init();
}

template<class tag, class Key> MultiResBmp<tag, Key>::Param::Param(uint64_t N, double E)
{
    if (E > 0.25)
	throw std::domain_error("MultiResBmp error must be <= 0.25");

    // algorithm from Cristi's computemrbconfiguration.pl 2002-02-19
    Param best;

    // default configuration
    b = unsigned(ceil(errcoef(k)/(E*E)));
    lastb = unsigned(ceil(errcoef(k)/(E*E)*k/(k-1)));
    c = 3 + unsigned(ceil(log(N/(b*rhomax(k)))/log(k)));
    best.copy(*this);

    // try to use last normal component
    if (c > 1) { // +kkeys
	c--;
	while (mrblnerror(rhomin(k), k, b, lastb) > E ||
	    mrblnerror(rhomax(k), k, b, lastb) > E)
	{
	    lastb++;
	}
	if (nbits() < best.nbits())
	    best.copy(*this);
    }

    // try to use last component
    while (vbmperror(rhomax(k)/(k-1)*b/lastb, lastb) > E) {
	lastb++;
    }
    double rhomaxlast = 1.6;
    while (vbmperror(rhomaxlast+0.00001, lastb) < E) {
	rhomaxlast += 0.00001;
    }
    c = unsigned(ceil(log(N/(lastb*rhomaxlast))/log(k))) + 1;
    if (nbits() < best.nbits())
	best.copy(*this);

    // try to push last component a little harder
    while (ceil(log(N/(lastb*rhomaxlast))/log(k)) > c - 2) {
	lastb++;
	while (vbmperror(rhomaxlast+0.00001, lastb) < E) {
	    rhomaxlast += 0.00001;
	}
    }
    c = unsigned(ceil(log(N/(lastb*rhomaxlast))/log(k))) + 1;
    if (nbits() < best.nbits())
	best.copy(*this);

    copy(best);

    // might as well use the bits up to the 32 bit allocation boundary
    if (nbits() % 32 > 0)
	lastb += 32 - (nbits() % 32);

    init();
}

inline double logb(double x, double base)
{
    return log(x) / log(base);
}

template<class tag, class Key> const typename MultiResBmp<tag, Key>::Param *MultiResBmp<tag, Key>::p = 0;

template<class tag, class Key> inline MultiResBmp<tag, Key> &MultiResBmp<tag, Key>::set(Key key)
{
    unsigned ci, bi; // component iterator, bit iterator
    const unsigned bv = p->b * p->k / (p->k-1);

    for (ci = 0; ci < p->c - 1; ci++) {
	bi = key % bv;
	if (bi < p->b) {
	    bmp.set(ci * p->b + bi);
	    return *this;
	}
	key = key / bv * (bv / p->k) + (bi - p->b);
	// The two lines below may look like they do the same thing as the
	// line above, but they are different due to integer arithmetic.
	// The one above gives the best accuracy.
	//key = key / p->k + (bi - p->b);
	//key = (bv / p->k) * key / bv + (bi - p->b);
    }
    bi = key % p->lastb;
    bmp.set(ci * p->b + bi);
    return *this;
}

template<class tag, class Key> double MultiResBmp<tag, Key>::estimate() const
{
    unsigned base, i, factor, off;
    double m;

    for (base = 0, factor = 1; base < p->c - 1 ; base++, factor *= p->k) {
	if (bmp.count(p->b, base * p->b) <= p->setmax)
            break;
    }

#if 0
    if (base == p->c - 1) {
	if (bmp.count(p->lastb, base * b) == p->lastb) {
	    return inf;
	} else {
	    warning "estimate might be inaccurate";
	}
    }
#endif

    m = 0;
    for (i = base; i < p->c - 1; i++) {
	off = bmp.nzero(p->b, i * p->b);
	assert(off!=0);
	m += p->b * (log((double)p->b/off));
    }
    off = bmp.nzero(p->lastb, i * p->b);
    if (off==0)
	throw std::overflow_error("MultiResBmp overflow");
    /* XXX last summand used to be rounded */
    m += p->lastb * (log((double)p->lastb/off));
    return factor * m;
}

#endif // MRBMP_H
