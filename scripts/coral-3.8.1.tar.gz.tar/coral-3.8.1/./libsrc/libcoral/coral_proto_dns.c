/* 
 * Copyright 2002, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 *
 * $Id: coral_proto_dns.c,v 1.36.4.1 2007/07/02 19:21:55 kkeys Exp $
 * DNS protocol parser (RFC 1035, 2136, 1876)
 *
 */

#include "config.h"
#include "coraldefs.h"

#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <setjmp.h>

#include "libcoral.h"
#include "libcoral_priv.h"
#include "dns.h"

static const char RCSid[] = "$Id: coral_proto_dns.c,v 1.36.4.1 2007/07/02 19:21:55 kkeys Exp $";

static int labels_initted = 0;
static const char *op_label[NS_UPDATE_OP+1];
static const char *qtype_label[T_ANY+1];
static const char *qclass_label[C_ANY+1];
static const char *rcode_label[255+1];
static jmp_buf trunc_env;

static void init_labels(void)
{
#define defop(val, label)	op_label[val] = #label;
#include "dns_op.h"
#undef defop

#define defqtype(val, label)	qtype_label[val] = #label;
#include "dns_qtype.h"
#undef defqtype

#define defqclass(val, label)	qclass_label[val] = #label;
#include "dns_qclass.h"
#undef defqclass

#define defrcode(val, label)	rcode_label[val] = #label;
#include "dns_rcode.h"
#undef defrcode

    labels_initted = 1;
}

#define init_labels_once() \
    do { if (!labels_initted) init_labels(); } while (0)


uint8_t coral_dns_str_to_op(const char *str)
{
    uint8_t op;
    if (isdigit(*str))
	return atoi(str);
    init_labels_once();
    for (op = 0; op <= NS_UPDATE_OP; op++) {
        if (op_label[op] && cstrcmp(op_label[op], str) == 0)
            return op;
    }
    return -1;
}

uint16_t coral_dns_str_to_qtype(const char *str)
{
    uint16_t qtype;
    if (isdigit(*str))
	return atoi(str);
    init_labels_once();
    for (qtype = 0; qtype <= T_ANY; qtype++) {
        if (qtype_label[qtype] && cstrcmp(qtype_label[qtype], str) == 0)
            return qtype;
    }
    return -1;
}

uint16_t coral_dns_str_to_qclass(const char *str)
{
    uint16_t qclass;
    if (isdigit(*str))
	return atoi(str);
    init_labels_once();
    for (qclass = 0; qclass <= C_ANY; qclass++) {
        if (qclass_label[qclass] && cstrcmp(qclass_label[qclass], str) == 0)
            return qclass;
    }
    return -1;
}

const char *coral_dns_op_label(uint8_t op)
{
    init_labels_once();
    return (op <= NS_UPDATE_OP && op_label[op]) ?
	op_label[op] : NULL;
}

const char *coral_dns_rcode_label(uint16_t rcode)
{
    init_labels_once();
    return (rcode <= 255 && rcode_label[rcode]) ?
	rcode_label[rcode] : NULL;
}

const char *coral_dns_qtype_label(uint16_t qtype)
{
    init_labels_once();
    return (qtype <= T_ANY && qtype_label[qtype]) ?
	qtype_label[qtype] : NULL;
}

const char *coral_dns_qclass_label(uint16_t qclass)
{
    init_labels_once();
    return (qclass <= C_ANY && qclass_label[qclass]) ?
	qclass_label[qclass] : NULL;
}

const char *coral_dns_op_to_str(uint8_t op)
{
    static char buf[8];
    const char *result;
    if ((result = coral_dns_op_label(op)))
	return result;
    sprintf(buf, "%d", op);
    return buf;
}

const char *coral_dns_qtype_to_str(uint16_t qtype)
{
    static char buf[8];
    const char *result;
    if ((result = coral_dns_qtype_label(qtype)))
	return result;
    sprintf(buf, "%d", qtype);
    return buf;
}

const char *coral_dns_qclass_to_str(uint16_t qclass)
{
    static char buf[8];
    const char *result;
    if ((result = coral_dns_qclass_label(qclass)))
	return result;
    sprintf(buf, "%d", qclass);
    return buf;
}

static int fmt_text(const coral_pkt_buffer_t *src, int offset,
    char **dumpbufp, int *buflenp)
{
    int len, overflow = 0;

    if (offset >= src->caplen) longjmp(trunc_env, 1);

    len = (unsigned)src->buf[offset];
    crl_snappend(dumpbufp, buflenp, '"');
    ++offset;
    if (len > src->caplen - offset) {
	len = src->caplen - offset;
	overflow = 1;
    }
    crl_sncat(dumpbufp, buflenp, src->buf + offset, len, "\"");
    if (overflow) {
	crl_sncat(dumpbufp, buflenp, "...\"", 3, NULL);
	longjmp(trunc_env, 1);
    }
    crl_sncat(dumpbufp, buflenp, "\" ", 2, NULL);
    offset += len;
    if (offset >= src->caplen) longjmp(trunc_env, 1);

    return offset;
}

static int fmt_name_recursive(const coral_pkt_buffer_t *src, int offset,
    char **dumpbufp, int *buflenp, int depth)
{
    unsigned int len;

    if (offset >= src->caplen) longjmp(trunc_env, 1);
    if (!src->buf[offset]) {
	crl_snprintf(dumpbufp, buflenp, ".");
    } else {
	while ((len = (unsigned char)src->buf[offset])) {
	    if ((src->buf[offset] & 0xc0) == 0xc0) {
		/* RFC 1035 4.1.4 compression */
		int nextoff = crl_nptohs(src->buf+offset) & ~0xc000;
		if (nextoff == offset || depth >= 127) {
		    crl_snprintf(dumpbufp, buflenp, "[LOOP]");
		    return offset + 2;
		}
		if (offset + 2 > src->caplen) longjmp(trunc_env, 1);
		fmt_name_recursive(src, nextoff, dumpbufp, buflenp, depth+1);
		return offset + 2;
	    }

	    ++offset;
	    if (len > src->caplen - offset)
		len = src->caplen - offset;
	    crl_sncat(dumpbufp, buflenp, src->buf + offset, len, ".");
	    offset += len;
	    if (offset >= src->caplen) longjmp(trunc_env, 1);
	    crl_snappend(dumpbufp, buflenp, '.');
	}
    }

    return offset + 1;
}

static int fmt_name(const coral_pkt_buffer_t *src, int offset,
    char **dumpbufp, int *buflenp)
{
    return fmt_name_recursive(src, offset, dumpbufp, buflenp, 0);
}

/* RFC 1876 */
static void fmt_loc_size(char **dumpbufp, int *buflenp, char data, const char *label)
{
    uint32_t b, e;
    crl_snprintf(dumpbufp, buflenp, " %s=", label);
    b = ((unsigned char)data & 0xF0) >> 4;
    e = (unsigned char)data & 0x0F;
    if (b == 0) {
	crl_snprintf(dumpbufp, buflenp, "0m");
    } else if (e < 2) {
	crl_snprintf(dumpbufp, buflenp, "%d%.*scm", b, e, "000000");
    } else if (e < 5) {
	crl_snprintf(dumpbufp, buflenp, "%d%.*sm", b, e-2, "000000");
    } else {
	crl_snprintf(dumpbufp, buflenp, "%d%.*skm", b, e-5, "000000");
    }
}

/* RFC 1876 */
static void fmt_loc_latlong(char **dumpbufp, int *buflenp, const char *data,
    const char *hemisphere)
{
    int32_t n = crl_nptohl(data) - 0x80000000;
    int neg = 0;
    if ((neg = (n < 0)))
	n = -n;

    crl_snprintf(dumpbufp, buflenp, " %c %03d",
	hemisphere[neg], n / (60 * 60 * 1000));
    n = n % (60 * 60 * 1000);
    crl_snprintf(dumpbufp, buflenp, " %02d'", n / (60 * 1000));
    n = n % (60 * 1000);
    crl_snprintf(dumpbufp, buflenp, " %02d.%03d\"", n / 1000, n % 1000);
}

static int fmt_opt_rr(const coral_pkt_buffer_t *src, int offset,
    char **dumpbufp, int *buflenp)
{
    uint16_t z, rdlen;
    int result;
    const char *fmt;
    const dnshdr_t *dns;
    uint8_t rcode;

    /* name and qtype were handled by fmt_rr() */

    if (offset + 2 > src->caplen) longjmp(trunc_env, 1);
    crl_snprintf(dumpbufp, buflenp, " payload=%u", crl_nptohs(src->buf+offset));
    offset += 2;

    dns = (dnshdr_t*)src->buf;
    rcode = crl_dns_rcode(dns);
    if (crl_dns_qr(dns) && src->buf[offset]) {
	if (offset >= src->caplen) longjmp(trunc_env, 1);
	switch ((src->buf[offset] << 4) + rcode) {
	    case BADVERS:	fmt = " BADVERS";	break;
	    default:		fmt = " xrcode=%d";	break;
	}
	crl_snprintf(dumpbufp, buflenp, fmt, (src->buf[offset] << 4) + rcode);
    }
    offset++;

    if (offset >= src->caplen) longjmp(trunc_env, 1);
    crl_snprintf(dumpbufp, buflenp, " ver=%d", src->buf[offset]);
    offset++;

    if (offset + 2 > src->caplen) longjmp(trunc_env, 1);
    if ((z = crl_nptohs(src->buf+offset)))
	crl_snprintf(dumpbufp, buflenp, " Z=0x%04x", z);
    offset += 2;

    if (offset + 2 > src->caplen) longjmp(trunc_env, 1);
    rdlen = crl_nptohs(src->buf+offset);
    offset += 2;

    result = offset + rdlen;
    {
	crl_snappend(dumpbufp, buflenp, '\n');
	coral_snprint_data(dumpbufp, buflenp, 7, (u_char*)src->buf+offset,
	    rdlen);
    }

    return result;
}

static int fmt_rr(const coral_pkt_buffer_t *src, int offset,
    char **dumpbufp, int *buflenp)
{
    uint16_t qtype, qclass, ttl, rdlen;
    int result;

    offset = fmt_name(src, offset, dumpbufp, buflenp);

    if (offset + 2 > src->caplen) longjmp(trunc_env, 1);
    qtype = crl_nptohs(src->buf+offset);
    offset += 2;
    crl_snprintf(dumpbufp, buflenp, " %s", coral_dns_qtype_to_str(qtype));

    if (qtype == T_OPT)
	return fmt_opt_rr(src, offset, dumpbufp, buflenp);

    if (offset + 2 > src->caplen) longjmp(trunc_env, 1);
    qclass = crl_nptohs(src->buf+offset);
    offset += 2;
    crl_snprintf(dumpbufp, buflenp, " %s", coral_dns_qclass_to_str(qclass));

    if (offset + 4 > src->caplen) longjmp(trunc_env, 1);
    ttl = crl_nptohl(src->buf+offset);
    offset += 4;
    crl_snprintf(dumpbufp, buflenp, " TTL=%d ", ttl);

    if (offset + 2 > src->caplen) longjmp(trunc_env, 1);
    rdlen = crl_nptohs(src->buf+offset);
    offset += 2;

    result = offset + rdlen;
    if (qtype == T_A && qclass == C_IN) {
	struct in_addr in_addr;
	if (offset + 4 > src->caplen) longjmp(trunc_env, 1);
	memcpy(&in_addr, src->buf + offset, sizeof(in_addr));
	crl_snprintf(dumpbufp, buflenp, "%s", inet_ntoa(in_addr));
#ifdef HAVE_INET6
    } else if (qtype == T_AAAA && qclass == C_IN) {
        struct in6_addr in6_addr;
        char addrbuf[INET6_ADDRSTRLEN+1];
	if (offset + 16 > src->caplen) longjmp(trunc_env, 1);
        memcpy(&in6_addr, src->buf + offset, sizeof(in6_addr));
        crl_snprintf(dumpbufp, buflenp, "%s",
            inet_ntop(AF_INET6, (char*)&in6_addr, addrbuf, INET6_ADDRSTRLEN));
#endif
    } else if (qtype == T_TXT) {
	offset = fmt_text(src, offset, dumpbufp, buflenp);
    } else if (qtype == T_HINFO) {
	crl_snprintf(dumpbufp, buflenp, "CPU=");
	offset = fmt_text(src, offset, dumpbufp, buflenp);
	crl_snprintf(dumpbufp, buflenp, " OS=");
	offset = fmt_text(src, offset, dumpbufp, buflenp);
    } else if (qtype == T_NS || qtype == T_CNAME || qtype == T_PTR) {
	fmt_name(src, offset, dumpbufp, buflenp);
    } else if (qtype == T_MX) {
	if (offset + 2 > src->caplen) longjmp(trunc_env, 1);
	crl_snprintf(dumpbufp, buflenp, "preference=%d ",
	    crl_nptohs(src->buf+offset));
	offset += 2;
	fmt_name(src, offset, dumpbufp, buflenp);
    } else if (qtype == T_SOA) {
	if (offset >= src->caplen) longjmp(trunc_env, 1);
	offset = fmt_name(src, offset, dumpbufp, buflenp); /* MNAME */
	if (offset >= src->caplen) longjmp(trunc_env, 1);
	crl_snprintf(dumpbufp, buflenp, " ");
	offset = fmt_name(src, offset, dumpbufp, buflenp); /* RNAME */
	if (offset + 4 > src->caplen) longjmp(trunc_env, 1);
	crl_snprintf(dumpbufp,buflenp, " serial=%d", crl_nptohl(src->buf+offset));
	offset += 4;
	if (offset + 4 > src->caplen) longjmp(trunc_env, 1);
	crl_snprintf(dumpbufp,buflenp, " refresh=%d", crl_nptohl(src->buf+offset));
	offset += 4;
	if (offset + 4 > src->caplen) longjmp(trunc_env, 1);
	crl_snprintf(dumpbufp,buflenp, " retry=%d", crl_nptohl(src->buf+offset));
	offset += 4;
	if (offset + 4 > src->caplen) longjmp(trunc_env, 1);
	crl_snprintf(dumpbufp,buflenp, " expire=%d", crl_nptohl(src->buf+offset));
	offset += 4;
	if (offset + 4 > src->caplen) longjmp(trunc_env, 1);
	crl_snprintf(dumpbufp,buflenp, " minimum=%d", crl_nptohl(src->buf+offset));
	offset += 4;
    } else if (qtype == T_LOC && offset+2 <= src->caplen &&
	src->buf[offset] == 0)
    {
	/* RFC 1876 */
	uint32_t alt;

	offset++;
	fmt_loc_size(dumpbufp, buflenp, src->buf[offset], "size");
	offset++;

	if (offset >= src->caplen) longjmp(trunc_env, 1);
	fmt_loc_size(dumpbufp, buflenp, src->buf[offset], "hprec");
	offset++;

	if (offset >= src->caplen) longjmp(trunc_env, 1);
	fmt_loc_size(dumpbufp, buflenp, src->buf[offset], "vprec");
	offset++;

	if (offset + 4 > src->caplen) longjmp(trunc_env, 1);
	fmt_loc_latlong(dumpbufp, buflenp, src->buf+offset, "NS");
	offset += 4;

	if (offset + 4 > src->caplen) longjmp(trunc_env, 1);
	fmt_loc_latlong(dumpbufp, buflenp, src->buf+offset, "EW");
	offset += 4;

	if (offset + 4 > src->caplen) longjmp(trunc_env, 1);
	alt = crl_nptohl(src->buf+offset) - 10000000;
	crl_snprintf(dumpbufp, buflenp, " alt=%d.%02dm", alt/100, alt%100);
	offset += 4;

    } else if (rdlen > 0) {
	crl_snappend(dumpbufp, buflenp, '\n');
	coral_snprint_data(dumpbufp, buflenp, 7, (u_char*)src->buf+offset,
	    rdlen);
    }

    return result;
}

int coral_get_dns_payload(const coral_pkt_buffer_t *src,
    coral_pkt_buffer_t *dst, char *dumpbuf, int buflen)
{
    const dnshdr_t *dns;
    int offset;
    const char *fmt;
    uint16_t qdcount, ancount, nscount, arcount;
    uint16_t qtype, qclass;
    coral_pkt_buffer_t pktbuf;
    uint8_t opcode, qr;

    dst->buf = NULL;
    dst->protocol = CORAL_PROTO_UNKNOWN;
    dst->totlen = 0;
    dst->caplen = 0;
    if (!dumpbuf) return 0;

    if (setjmp(trunc_env)) {
	return CORAL_ELENGTH;
    }

    if (src->parent_proto == CORAL_IPPROTO_TCP) {
	/* DNS over TCP begins with 16-bit length field */
	pktbuf = *src;
	pktbuf.buf += 2;
	pktbuf.caplen -= 2;
	pktbuf.totlen -= 2;
	src = &pktbuf;
    }

    dns = (dnshdr_t*)src->buf;
    offset = sizeof(dnshdr_t);

    if (!coral_field_fits(dns, id, src->caplen)) longjmp(trunc_env, 1);
    crl_snprintf(&dumpbuf, &buflen, "id=%04x ", crl_nptohs(&dns->id));
    if (src->caplen < 3) longjmp(trunc_env, 1);
    qr = crl_dns_qr(dns);
    crl_snprintf(&dumpbuf, &buflen, "qr=%d ", qr);

    opcode = crl_dns_opcode(dns);
    fmt = coral_dns_op_label(opcode);
    crl_snprintf(&dumpbuf, &buflen, fmt ? fmt : "op=%d", opcode);
    crl_snappend(&dumpbuf, &buflen, ' ');

    if (crl_dns_aa(dns)) crl_snprintf(&dumpbuf, &buflen, "AA ");
    if (crl_dns_tc(dns)) crl_snprintf(&dumpbuf, &buflen, "TC ");
    if (crl_dns_rd(dns)) crl_snprintf(&dumpbuf, &buflen, "RD ");

    if (src->caplen < 4) longjmp(trunc_env, 1);
    if (crl_dns_ra(dns)) crl_snprintf(&dumpbuf, &buflen, "RA ");
    if (crl_dns_unused(dns)) crl_snprintf(&dumpbuf, &buflen, "MBZ ");
    if (crl_dns_ad(dns)) crl_snprintf(&dumpbuf, &buflen, "AD ");
    if (crl_dns_cd(dns)) crl_snprintf(&dumpbuf, &buflen, "CD ");
    if (qr) {
	uint8_t rcode = crl_dns_rcode(dns);
	fmt = coral_dns_rcode_label(rcode);
	crl_snprintf(&dumpbuf, &buflen, fmt ? fmt : "rcode=%d", rcode);
	crl_snappend(&dumpbuf, &buflen, ' ');
    }

    if (!coral_field_fits(dns, qdcount, src->caplen)) longjmp(trunc_env, 1);
    if ((qdcount = crl_nptohs(&dns->qdcount)))
	crl_snprintf(&dumpbuf, &buflen, "qdcount=%u ", qdcount);

    if (!coral_field_fits(dns, ancount, src->caplen)) longjmp(trunc_env, 1);
    if ((ancount = crl_nptohs(&dns->ancount)))
	crl_snprintf(&dumpbuf, &buflen, "ancount=%u ", ancount);

    if (!coral_field_fits(dns, nscount, src->caplen)) longjmp(trunc_env, 1);
    if ((nscount = crl_nptohs(&dns->nscount)))
	crl_snprintf(&dumpbuf, &buflen, "nscount=%u ", nscount);

    if (!coral_field_fits(dns, arcount, src->caplen)) longjmp(trunc_env, 1);
    if ((arcount = crl_nptohs(&dns->arcount)))
	crl_snprintf(&dumpbuf, &buflen, "arcount=%u ", arcount);

    for ( ; qdcount; qdcount--) {
	crl_snprintf(&dumpbuf, &buflen, "\n    %s: ",
	    (opcode == NS_UPDATE_OP) ? "zone" : "query");
	if (offset >= src->caplen) longjmp(trunc_env, 1);
	offset = fmt_name(src, offset, &dumpbuf, &buflen);
	if (offset + 2 > src->caplen) longjmp(trunc_env, 1);
	qtype = crl_nptohs(src->buf+offset);
	offset += 2;
	crl_snprintf(&dumpbuf, &buflen, " %s", coral_dns_qtype_to_str(qtype));
	if (offset + 2 > src->caplen) longjmp(trunc_env, 1);
	qclass = crl_nptohs(src->buf+offset);
	offset += 2;
	crl_snprintf(&dumpbuf, &buflen, " %s", coral_dns_qclass_to_str(qclass));
    }

    for ( ; ancount; ancount--) {
	crl_snprintf(&dumpbuf, &buflen, "\n    %s: ",
	    (opcode == NS_UPDATE_OP) ? "prereq" : "answer");
	if (offset >= src->caplen) longjmp(trunc_env, 1);
	offset = fmt_rr(src, offset, &dumpbuf, &buflen);
    }

    for ( ; nscount; nscount--) {
	crl_snprintf(&dumpbuf, &buflen, "\n    %s: ",
	    (opcode == NS_UPDATE_OP) ? "update" : "nameserver");
	if (offset >= src->caplen) longjmp(trunc_env, 1);
	offset = fmt_rr(src, offset, &dumpbuf, &buflen);
    }

    for ( ; arcount; arcount--) {
	crl_snprintf(&dumpbuf, &buflen, "\n    additional: ");
	if (offset >= src->caplen) longjmp(trunc_env, 1);
	offset = fmt_rr(src, offset, &dumpbuf, &buflen);
    }

    return 0;
}


