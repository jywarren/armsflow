/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 * coral_ioctl.h -
 * $Id: coral_ioctl.h,v 1.63 2007/06/06 18:17:41 kkeys Exp $
 *
 * Definitions that are used only in the driver and in code that uses
 * the driver directly.
 */

#ifndef CORAL_IOCTL_H
#define CORAL_IOCTL_H

#ifdef HAVE_SYS_IOCCOM_H
#include <sys/ioccom.h>
#endif
#ifndef __KERNEL__
#include <sys/types.h>
#include <sys/time.h>
#endif

#if (__FreeBSD_version < 400000 && defined(KERNEL)) || \
    (__FreeBSD_version >= 400000 && defined(_KERNEL))
# include <pci/coral_global.h>
#else
# include "coral_global.h"
#endif

/* for fore atm firmware loading */
typedef struct mem_copy {
    unsigned int address;
    unsigned int value;
} *memory_copy;

#define CORAL_DRIVER_VERSION	6   /* version of this driver api (not
				     * necessarily same as libcoral version) */


/* for point firmware(fpga) loads, data is kept in p->buffer (ick) */
#define POINT_DL_BYTE(n, b)	(*((b) + CORAL_BLK_HEADER_SIZE + (n)))

/* starts at 20 so as not to conflict w/ the old fatm stuff. */
#define CORAL_FILLINFO		_IOWR('Z', 0x14, coral_interface)
#define CORAL_RESET		_IO  ('Z', 0x15)
#define CORAL_READ_SRAM		_IOWR('Z', 0x29, u_int)
#define CORAL_INIT		_IOWR('Z', 0x16, coral_io_mode_t)

#define CORAL_CLRTSTAMP		_IO  ('Z', 0x17)
#define CORAL_START		_IO  ('Z', 0x18)
#define CORAL_STOP		_IO  ('Z', 0x19)
#define CORAL_NEXTBLK		_IOWR('Z', 0x1a, int)
#define CORAL_CLOCKSYNC		_IO  ('Z', 0x1b)/* driver dependant, used to 
						 * synch clocks of cards in 
						 * same machine, somewhat */
#define CORAL_FILL_BLKHEADER	_IOWR('Z', 0x1c, coral_blk_info_t)
#define CORAL_SENDBLK		_IOWR('Z', 0x1d, int)

#define FATM_MWRITE		_IOWR('Z', 0x05, struct mem_copy)
#define POINT_LOAD_FIRMWARE	_IOWR('Z', 0x28, u_int)

#define CORAL_NEXTBLK_NORELEASE	_IOWR('Z', 0x30, int)
#define CORAL_RELEASE		_IO('Z', 0x31)

#endif /* CORAL_IOCTL_H */
