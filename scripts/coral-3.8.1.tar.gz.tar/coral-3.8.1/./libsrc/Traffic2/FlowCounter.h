/* 
 * Copyright 1999,2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

#ifndef FLOWCOUNTER_H
#define FLOWCOUNTER_H

#include <iostream>
#include "caida_t.h"

#define FC_UNDEF -1
#define fc_max(a,b) (a == FC_UNDEF) ? b : (b == FC_UNDEF) ? a : (a > b) ? a : b
#define fc_min(a,b) (a == FC_UNDEF) ? b : (b == FC_UNDEF) ? a : (a < b) ? a : b

class FlowCounter {
public:
    int64_t bytes(int64_t new_bytes = FC_UNDEF)
    {
	if (new_bytes >= 0) {
	    m_bytes = new_bytes;
	} else if (new_bytes == FC_UNDEF) {
	    return m_bytes;
	} else {
	    std::cerr
		<< "Warning:  Must use positive value to set FlowCounter's "
		<<  "bytes\nYou tried to use " << new_bytes << std::endl;
	}
    }
    int64_t pkts(int64_t new_pkts = FC_UNDEF)
    {
	if (new_pkts >= 0) {
	    m_pkts = new_pkts;
	} else if (new_pkts == FC_UNDEF) {
	    return m_pkts;
	} else {
	    std::cerr
		<< "Warning:  Must use positive value to set FlowCounter's "
		<<  "pkts\nYou tried to use " << new_pkts << std::endl;
	}
	return m_pkts;
    }
    int64_t flows(int64_t new_flows = FC_UNDEF)
    {
	if (new_flows >= 0) {
	    m_flows = new_flows;
	} else if (new_flows == FC_UNDEF) {
	    return m_flows;
	} else {
	    std::cerr
		<< "Warning:  Must use positive value to set FlowCounter's "
		<<  "flows\nYou tried to use " << new_flows << std::endl;
	}
	return m_flows;
    }
    double first(double new_first = FC_UNDEF)
    {
	if (new_first >= 0) {
	    m_first = new_first;
	} else if (new_first == FC_UNDEF) {
	    return m_first;
	} else {
	    std::cerr
		<< "Warning:  Must use positive value to set FlowCounter's "
		<<  "first\nYou tried to use " << new_first << std::endl;
	}
	return m_first;
    }
    double latest(double new_latest = FC_UNDEF)
    {
	if (new_latest >= 0) {
	    m_latest = new_latest;
	} else if (new_latest == FC_UNDEF) {
	    return m_latest;
	} else {
	    std::cerr
		<< "Warning:  Must use positive value to set FlowCounter's "
		<<  "latest\nYou tried to use " << new_latest << std::endl;
	}
	return m_latest;
    }
    double duration()
    {
	if (m_first != FC_UNDEF && m_latest != FC_UNDEF) {
	    return m_latest - m_first;
	} else {
	    return FC_UNDEF;
	}
    }
    FlowCounter* add(FlowCounter* addend)
    {
	m_bytes += addend->m_bytes;
	m_pkts += addend->m_pkts;
	m_flows += addend->m_flows;
	m_first = fc_min(m_first, addend->m_first);
	m_latest = fc_max(m_latest, addend->m_latest);
	return this;
    }
    void reset()
    {
	m_bytes = 0;
	m_pkts = 0;
	m_flows = 0;
	m_first = FC_UNDEF;
	m_latest = FC_UNDEF;
    }
    FlowCounter() : m_bytes(0), m_pkts(0), m_flows(0), m_first(FC_UNDEF), m_latest(FC_UNDEF) {};
    ~FlowCounter() {};
private:
    int64_t m_bytes;
    int64_t m_pkts;
    int64_t m_flows;
    double m_first;
    double m_latest;
};

#undef fc_max
#undef fc_min

#endif
