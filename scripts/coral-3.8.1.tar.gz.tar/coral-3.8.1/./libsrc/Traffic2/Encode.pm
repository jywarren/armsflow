package CAIDA::Traffic2::Encode;
require 5.004;
# ------------------------------------------------------------------
# Object-class: Encode.pm
# Internal object class for use with Sample.pm
#
# Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
# All Rights Reserved 
#
# Permission to use, copy, modify and distribute any part of this
# CoralReef software package for educational, research and non-profit
# purposes, without fee, and without a written agreement is hereby
# granted, provided that the above copyright notice, this paragraph
# and the following paragraphs appear in all copies.
#
# Those desiring to incorporate this into commercial products or use
# for commercial purposes should contact the Technology Transfer
# Office, University of California, San Diego, 9500 Gilman Drive, La
# Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
#
# IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
# PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
# DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
# SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
# THE POSSIBILITY OF SUCH DAMAGE.
#
# THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
# UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
# SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
# OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
# OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
# PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
# ANY PATENT, TRADEMARK OR OTHER RIGHTS.
#
# The CoralReef software package is developed by the CoralReef
# development team at the University of California, San Diego under
# the Cooperative Association for Internet Data Analysis (CAIDA)
# Program. Support for this effort is provided by the CAIDA grant
# NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
# N66001-01-1-8909, and by CAIDA members.
#
# Report bugs and suggestions to coral-bugs@caida.org.
# ---------------------------------------------------------------------
use integer;

use Socket;

my %host_map = ();
my %net_map = ();

my $net_count = 0;
my $host_count = 0;
my %host_count = ();

my %reverse_map = ();





# XXX should preserve class space and "special" nets like 10, etc
sub _encode_addr {
    my ($addr) = @_;

    my $id = ($addr >> 28) & 0xf;
    my $net;
    my $host;
    
    if ($id < 0x8) {
	# class A
	$net = $addr &  0xff000000;
	$host = $addr & 0x00ffffff;
    } elsif ($id < 0xc) {
	# class B
	$net = $addr &  0xffff0000;
	$host = $addr & 0x0000ffff;
    } elsif ($id < 0xe) {
	# class C
	$net = $addr &  0xffffff00;
	$host = $addr & 0x000000ff;
    } else {
	# class D & E - don't encode these
	return $addr;
    }

    my $net_key = pack("N", $net);
    my $host_key = pack("N", $addr); # addr not net since we use single
				#  hash lookup below in $host_map

    if (!defined $net_map{$net_key}) {
	$net_map{$net_key} = ++$net_count;
    }

    if (!defined $host_map{$host_key}) {
	$host_map{$host_key} = ++$host_count{$net_key};
	++$host_count;
    }

    my $result = ($net_map{$net_key} << 16) | $host_map{$host_key};
    $reverse_map{$result} = $addr; #  let people break the key

    return $result;

}

sub encode_inet_addr ($ ) {
    my $addr_int = unpack("N", $_[0]);

    my $encode_int = _encode_addr($addr_int);

    return pack("N", $encode_int);
}

sub encode_addr($ ) {
# ----------------------------
# 
    my $addr_str = shift;
    return Socket::inet_ntoa(encode_inet_addr(Socket::inet_aton($addr_str)));
}


sub decode_addr($ ) {
# ----------------------------
# 

  my $addr_str = shift;

  my $addr_int = unpack("N", Socket::inet_aton($addr_str));

  my $decode_int = $reverse_map{$addr_int};

  return(Socket::inet_ntoa(pack("N", $decode_int)));
}

# Must be last line in file.
1;

# =============================
# POD Documentation for Module

__END__

=head1 NAME

Encode - IP packet encryption (Internal use only!)

=head1 DESCRIPTION

Encode.pm is an internal object-class used in the implmentation of the
of the Sample.pm module.  It is not intended for use on its own.

=head1 AUTHOR

David Moore <dmoore@caida.org>

=head1 COPYRIGHT

Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
All Rights Reserved 

Permission to use, copy, modify and distribute any part of this
CoralReef software package for educational, research and non-profit
purposes, without fee, and without a written agreement is hereby
granted, provided that the above copyright notice, this paragraph
and the following paragraphs appear in all copies.

Those desiring to incorporate this into commercial products or use
for commercial purposes should contact the Technology Transfer
Office, University of California, San Diego, 9500 Gilman Drive, La
Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.

IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
THE POSSIBILITY OF SUCH DAMAGE.

THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
ANY PATENT, TRADEMARK OR OTHER RIGHTS.

The CoralReef software package is developed by the CoralReef
development team at the University of California, San Diego under
the Cooperative Association for Internet Data Analysis (CAIDA)
Program. Support for this effort is provided by the CAIDA grant
NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
N66001-01-1-8909, and by CAIDA members.

Report bugs and suggestions to coral-bugs@caida.org.

=cut
