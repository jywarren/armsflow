/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 * $Id: portstats.c,v 1.16 2007/06/06 18:17:33 kkeys Exp $
 */


static const char RCSid[]="$Id: portstats.c,v 1.16 2007/06/06 18:17:33 kkeys Exp $";

#include "config.h"
#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>

#include "hashtab/hashtab.h"

#include <netinet/in.h>
#include <netinet/in_systm.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <netinet/ip_icmp.h>

#ifndef IP_OFFMASK
#define IP_OFFMASK 0x1fff	/* mask for fragmenting bits */
#endif
/* * * * port hash table fxns * * * */
typedef struct {
    u_char	ip_proto;
    u_char	ports_ok;
    u_short	sport;
    u_short	dport;
    u_int	pkts;
    u_int	bytes;
} port_stats;

/* return 0 if the same - for use by the hashtable */
static int compare_port_stats(const void *entry1, const void *entry2)
{
    const port_stats *foo1 = entry1;
    const port_stats *foo2 = entry2;

    return (foo1->ip_proto != foo2->ip_proto ||
	    foo1->sport != foo2->sport ||
	    foo1->dport != foo2->dport);
}

/* make a hash key for an entry - for use by the hashtable */
static unsigned long make_key_port_stats(const void *entry)
{
    const port_stats *what = entry;

    return (unsigned) 863363 * what->sport + what->dport;
}

/* free mem of an entry - for use by the hashtable */
static void delete_port_stats(void *entry)
{
    port_stats *what = entry;

    if (!what) return;

    free(what);
}

hash_tab *new_port_table(u_int ht_size, char *label)
{
    return init_hash_table(label, compare_port_stats, make_key_port_stats,
			   delete_port_stats, ht_size);
}

void dump_port_table(hash_tab *ht)
{
    const port_stats *rec;
    char *proto;

    init_hash_walk(ht);
    
    fprintf(stdout, "#proto         srcport  dstport     pkts    bytes\n");

    while ((rec = next_hash_walk(ht))) {
	if (rec->ports_ok == 2) {
	    fprintf(stdout, " icmp type: %d code: %d   %d %d\n",
		    rec->sport, rec->dport, rec->pkts, rec->bytes);
	} else {
	    switch (rec->ip_proto) {
	    case IPPROTO_TCP:
		proto = "tcp";
		break;
	    case IPPROTO_UDP:
		proto = "udp";
		break;
	    default:
		proto = "unk";
		break;
	    }
	    fprintf(stdout, " %-10s %7d %7d %9d %9d\n", proto, rec->sport, 
		    rec->dport, rec->pkts, rec->bytes);
	}
    }
}

void count_ports(hash_tab *ht, struct ip *ip)
{
    u_short ihl;
    port_stats tmp;
    port_stats *rec;
    short offset;
    char *transport_header;

    ihl = ip->ip_hl * 4;
    offset = ntohs(ip->ip_off) & IP_OFFMASK;

    /* warn if this packet is not ip v4 */
    if (ip->ip_v != 4) {
	fprintf(stderr, "unexpected ip version: %d\n", (int)ip->ip_v);
    }

    /* Set the key to the source/destination address pair. */
    tmp.ip_proto = ip->ip_p;
    tmp.ports_ok = 0;
    tmp.sport = 0;
    tmp.dport = 0;

    transport_header = (char*)ip + ihl;

    if (ip->ip_p == IPPROTO_TCP) {
	if (!offset && ihl <= 36) {
	    struct tcphdr *t = (struct tcphdr*)transport_header;

	    tmp.sport = ntohs(t->th_sport);
	    tmp.dport = ntohs(t->th_dport);
	    tmp.ports_ok = 1;
	}
    } else if (ip->ip_p == IPPROTO_UDP) {
	if (!offset && ihl <= 36) {
	    struct udphdr *u = (struct udphdr*)transport_header;

	    tmp.sport = ntohs(u->uh_sport);
	    tmp.dport = ntohs(u->uh_dport);
	    tmp.ports_ok = 1;
	}
    } else if (ip->ip_p == IPPROTO_ICMP) {
	if (!offset && ihl <= 36) {
	    struct icmp *icmp = (struct icmp*)transport_header;

	    tmp.sport = icmp->icmp_type;
	    tmp.dport = icmp->icmp_code;
	    tmp.ports_ok = 2;
	}
    }

    /* Read the current value out of the database. */
    if ((rec = (port_stats*)find_hash_entry(ht, &tmp))) {
	rec->pkts++;
	rec->bytes += ntohs(ip->ip_len);
    } else {
	rec = (port_stats*)malloc(sizeof(port_stats));
	if (rec == NULL) {
	    fprintf(stderr, "can't malloc port_stats.\n");
	    return;
	}
	*rec = tmp;

	rec->pkts = 1;
	rec->bytes = ntohs(ip->ip_len);
	add_hash_entry(ht, rec);
    }
}
/* * * * end of port hash table fxn's * * * */
