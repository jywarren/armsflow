## $Id: FlowCounter.pm,v 1.29 2007/06/06 18:17:51 kkeys Exp $ $Name: release-3-8-1 $
package CAIDA::Traffic2::FlowCounter;
## -----------------------------------------------------------------------
## Perl module:FlowCounter.pm
## 
## This Perl module XXXXXXXXXXXXXXXXXX
## 
## Note: test routines require the Test.pm module or Perl 5.005
##
## Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
## All Rights Reserved 
##
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
##
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
##
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
##
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
##
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program. Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
##
## Contact: coral-info@caida.org
## ---------------------------------------------------------------------
package CAIDA::Traffic2::FlowCounter;

@EXPORT    = qw();
@EXPORT_OK = qw();

# Enable error messages to come from calling script
use Carp;

# Define required CVS variables
$cvs_Id = '$Id: FlowCounter.pm,v 1.29 2007/06/06 18:17:51 kkeys Exp $';
$cvs_Author = '$Author: kkeys $';
$cvs_Name = '$Name: release-3-8-1 $';
$cvs_Revision = '$Revision: 1.29 $';

# Version of module
$VERSION = 2.0;

# Force this module to adhere to safe programming practices.
use strict;

my $use_c_backend;

BEGIN {
    eval 'use vars qw(@ISA); require Exporter; require DynaLoader; @ISA = qw(Exporter DynaLoader); bootstrap CAIDA::Traffic2::FlowCounter;';
    if ($@) {
	$use_c_backend = 0;
	print STDERR "Using Perl version of CAIDA::Traffic2::FlowCounter:\n$@";
    } else {
	$use_c_backend = 1;
    }
}

if ($use_c_backend) {

    *bytes = \&CAIDA::Traffic2::FlowCounter::FlowCounter_bytes;
    *pkts = \&CAIDA::Traffic2::FlowCounter::FlowCounter_pkts;
    *flows = \&CAIDA::Traffic2::FlowCounter::FlowCounter_flows;
    *first = \&CAIDA::Traffic2::FlowCounter::FlowCounter_first;
    *latest = \&CAIDA::Traffic2::FlowCounter::FlowCounter_latest;
    *duration = \&CAIDA::Traffic2::FlowCounter::FlowCounter_duration;
    *add = \&CAIDA::Traffic2::FlowCounter::FlowCounter_add;
    *nadd = \&CAIDA::Traffic2::FlowCounter::FlowCounter_add;
    *reset = \&CAIDA::Traffic2::FlowCounter::FlowCounter_reset;

    *new = sub {
	my ($class, @values) = @_;
	# Easier to just bless here than separating classes and method
	# wrapping in SWIG file.
	my $self = bless CAIDA::Traffic2::FlowCounter::new_FlowCounter(),
			    "_p_mortal_FlowCounter";

	if (@values) {
	    defined($values[0]) && ($self->pkts($values[0]));
	    defined($values[1]) && ($self->bytes($values[1]));
	    defined($values[2]) && ($self->flows($values[2]));
	    defined($values[3]) && ($self->first($values[3]));
	    defined($values[4]) && ($self->latest($values[4]));
	}

	return $self;
    };

} else { # use perl-only version

# -----------------------------------------------
# Create new counter object.  Not much to do 
# here except allocate space and return 
# reference to it.
# -----------------------------------------------
    *new = sub {
	my ($self, @values) = @_;
	my $type = ref($self) || $self;
	
	my $counter = [ 0, 0, 0, undef, undef ];

	if (@values) {
	    defined($values[0]) && ($counter->[0] = $values[0]);
	    defined($values[1]) && ($counter->[1] = $values[1]);
	    defined($values[2]) && ($counter->[2] = $values[2]);
	    defined($values[3]) && ($counter->[3] = $values[3]);
	    defined($values[4]) && ($counter->[4] = $values[4]);
	}

	bless $counter, $type;

	return $counter;
    };

# -----------------------------------------------
# Function to find smaller of two values.
# Checks to see if both values are defined 
# and will return one value is only one item is
# passed as a parameter.  Code depends on 
# generous Perl handling of undefined values.
# -----------------------------------------------
    *min = sub {
	my ($a, $b) = @_;
	return !defined($a) ? $b : !defined($b) ? $a : $a < $b ? $a : $b;
    };

# -----------------------------------------------
# Function to find larger of two values.
# Checks to see if both values are defined 
# and will return one value is only one item is
# passed as a parameter.  Code depends on 
# generous Perl handling of undefined values.
# -----------------------------------------------
    *max = sub {
	my ($a, $b) = @_;
	return !defined($a) ? $b : !defined($b) ? $a : $a > $b ? $a : $b;
    };

# -----------------------------------------------
# Access/Modifier function to get packets data.
# If two arguments are passed, then the second
# value is assigned to the packets slot in the 
# array.  Otherwise the first item of the array 
# is returned.
# -----------------------------------------------
    *pkts = sub {
	my ($self, $value) = @_;
	if (defined($value)) {
		$self->[0] = $value;
	}
	return $self->[0];
    };

# -----------------------------------------------
# Access/Modifier function to get bytes data.
# If two arguments are passed, then the second
# value is assigned to the bytes slot in the 
# array.  Otherwise the second item of the array 
# is returned.
# -----------------------------------------------
    *bytes = sub {
	my ($self, $value) = @_;
	if (defined($value)) {
		$self->[1] = $value;
	}
	return $self->[1];
    };

# -----------------------------------------------
# Access/Modifier function to get flows data.
# If two arguments are passed, then the second
# value is assigned to the flows slot in the 
# array.  Otherwise the third item of the array 
# is returned.
# -----------------------------------------------
    *flows = sub {
	my ($self, $value) = @_;
	if (defined($value)) {
		$self->[2] = $value;
	}
	return $self->[2];
    };

# -----------------------------------------------
# Access/Modifier function to get the first
# time.  If two arguments are passed, 
# then the second value is assigned to the
# fourth slot in the array.  Otherwise the fourth 
# item of the array is returned.
# -----------------------------------------------
    *first = sub {
	my ($self, $value) = @_;
	if (defined($value)) {
		$self->[3] = $value;
	}
	return $self->[3];
    };

# -----------------------------------------------
# Access/Modifier function to get the latest
# time.  If two arguments are passed, 
# then the second value is assigned to the
# fifth slot in the array.  Otherwise the 
# fifth item of the array is returned.
# -----------------------------------------------
    *latest = sub {
	my ($self, $value) = @_;
	if (defined($value)) {
		$self->[4] = $value;
	}
	return $self->[4];
    };

# -----------------------------------------------
# Accessor function to get the flow duration,
# which is the fourth item minus the third item.
# -----------------------------------------------
    *duration = sub {
	my ($self) = @_;
	if (defined $self->[3] and defined $self->[4]) {
	    return $self->[4] - $self->[3];
	} else {
	    return undef;
	}
    };

# -----------------------------------------------
# Method to combine two FlowCounter objects.
# Packets, Bytes, and Flows are simply added up.
# The first count is the smaller of the two 
# first counts, the latest is the largest of
# the two latest packets.
# -----------------------------------------------
    *add = sub {
	my ($self, $other) = @_;
	$self->[0] += $other->[0];
	$self->[1] += $other->[1];
	$self->[2] += $other->[2];
	$self->[3] = min($self->[3], $other->[3]);
	$self->[4] = max($self->[4], $other->[4]);
	return $self;
    };


# Like add, but is allowed to modify or destroy `other'.
    *nadd = sub {
	my ($self, $other) = @_;

	return $self->add($other);
    };

    *reset = sub {
	my ($self) = @_;
	@$self = (0, 0, 0, undef, undef);
    };
}

no strict; # For @ISA

package _p_FlowCounter;

@ISA = qw(CAIDA::Traffic2::FlowCounter);

package _p_mortal_FlowCounter;

@ISA = qw(CAIDA::Traffic2::FlowCounter);
*DESTROY = \&CAIDA::Traffic2::FlowCounter::delete_FlowCounter;

use strict;

# same thing w/o first, latest
package CAIDA::Traffic2::FlowCounter_Light;

if ($use_c_backend) {

    no strict;
    @ISA = qw(CAIDA::Traffic2::FlowCounter);
    use strict;

} else { # use perl-only version

    no strict;
    @ISA = qw(CAIDA::Traffic2::FlowCounter);
    $VERSION = 1.0;
    use strict;


    *new = sub {
	my ($self, @values) = @_;
	my $type = ref($self) || $self;


	my $counter = [ 0, 0, 0 ];

	if (@values) {
	    defined($values[0]) && ($counter->[0] = $values[0]);
	    defined($values[1]) && ($counter->[1] = $values[1]);
	    defined($values[2]) && ($counter->[2] = $values[2]);
	}

	bless $counter, $type;

	return $counter;
    };


    *add = sub {
	my ($self, $other) = @_;
	$self->[0] += $other->[0];
	$self->[1] += $other->[1];
	$self->[2] += $other->[2];
	return $self;
    };

    *reset = sub {
	my ($self) = @_;
	@$self = (0, 0, 0);
    };
}

1
