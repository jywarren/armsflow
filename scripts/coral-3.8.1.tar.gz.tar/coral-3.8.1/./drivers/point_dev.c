/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 * point_dev.c - main driver code for apptel's point 622 card
 *               there is alot of code from Joel Apisdorf's dos oc21mon
 *               here.
 *
 * The point card takes a buffer to fill.  When it has filled that buffer it
 * issues an interrupt.  The interrupt is responsible for taking the block
 * off the card and saving it and giving the card a new block to write on. 
 * The two functions used for this are EAT_BLK and FEED_BLK.  The user calls
 * point_nextblk to get filled blocks that were taken off the card with
 * EAT_BLK.  
 *
 * Calling point_nextblk means that you are done with the last
 * block returned by it, so that block becomes available to feed the card
 * with.  In this way, the user can only hold onto one block at a time.  If
 * you want to hold onto more than one block at a time, you can use the
 * CORAL_NEXTBLK_NORELEASE ioctl.  This tells point_nextblk via setting the
 * norelease argument to not release the last user locked block.  When you
 * are done with a block, you must call the CORAL_RELEASE ioctl which calls
 * point_release.  This puts the oldest locked block back into the
 * block_pool.  You cannot currently release blocks out of order.
 *
 * The structure used to manage blocks is block_pool.  It can be found in
 * the coral_common.* files.  They contain code that should be generic
 * enough to use in all coral drivers.
 *
 * $Id: point_dev.c,v 1.86 2007/06/06 18:17:42 kkeys Exp $
 */

/* 
 * XXX: The firmware download stuff is half macro and half hardcoded.  It
 * works, but clean it eventually.  What would be really nice is to have a
 * load firmware ioctl that takes the address and length of the userspace
 * memory containing the firmware.  Would need some kernel magic to mmap
 * in a userspace region..
 */

#include <sys/param.h>
#include <sys/conf.h>
#include <sys/systm.h>
#include <sys/errno.h>
#include <sys/mman.h>
#include <sys/fcntl.h>
#include <sys/socket.h>
#include <sys/sockio.h>
#include <sys/proc.h>
#include <sys/syslog.h>
#include <machine/clock.h>

#include <vm/vm.h>
#include <vm/pmap.h>

#include <pci/coral_ioctl.h>
#include <pci/point.h>

#if __FreeBSD_version >= 300000
#include <sys/poll.h>
#else
#include <sys/fcntl.h>
#endif

static int sram_read(volatile fpga_regs *fpga, u_int offset, int *val);
static int sram_write(volatile fpga_regs *fpga, u_int offset, int val);
static int point_init(point_622_atm *p, coral_io_mode_t *iomode);
static int point_load_fpga(point_622_atm *p, u_int *data);
static int point_nextblk(point_622_atm *p, int *cbi, int norelease);
static int point_start(point_622_atm *p);
static void point_stop(point_622_atm *p);
static void point_reset(point_622_atm *p);

#define MAX_SRAM_ADDRESS	((1 << 20) - 1)
#define MAX_CYCLE_DELAY		1000000
#define MAX_START_TIME		50000
#define MAX_VERIFY_TIME		6000
#define MAX_DONE_TIME		500000

/* FreeBSD 2 doesn't have nanotime.  The shame.  Let's help it out. */
#if __FreeBSD_version < 300000
static inline void nanotime(struct timespec *time) {
    struct timeval tvtime;
    
    /* 
     * Get the time with microtime and convert it to units as seen with
     * nanotime.
     */
    microtime(&tvtime);
    TIMEVAL_TO_TIMESPEC(&tvtime, time);
}
#endif


/* 
 * Save the time on our block timestamp. 
 */
static inline void savetime(struct timespec *time_location) {
    nanotime(time_location);
    return;
}


/*
 * read_cell_loss -
 * when cell loss has been detected, this should be called.
 * first set a bit that causes the internal cell loss counter
 * to be transfered to a register on the card, when that
 * transfer is complete, the bit goes low.  once that happens
 * we read the register, and store it in lost_cells field for
 * the desired blk (blkidx).
 *
 * XXX: The card seems to ignore the LatchAndClear and sets it back to 0
 * immediately.  Useless values are read, but this code should work in
 * theory.  The timeout handling is crappy, use nanotime if this ever works.
 */
static inline void read_cell_loss(point_622_atm *p, struct block *block)
{
    int timeout = 0;

    p->fpga->CellCountTransferReset.LatchAndClear = 1;
    while (p->fpga->CellCountTransferReset.LatchAndClear && timeout < 30000) {
	timeout++;
    }

    if (timeout >= 30000)
	log(LOG_ERR, "point%d: error reading lost cell count %d\n", p->pointi,
	       timeout);

    block->header->cells_lost = 
	   p->fpga->CellDropCountRead3
	| (p->fpga->CellDropCountRead2 << 8)
	| (p->fpga->CellDropCountRead1 << 16)
	| (p->fpga->CellDropCountRead0 << 24);

    p->rx_errors++;
}


/* 
 * Give the card the next available block if possible and tell the amcc (the
 * card's pci dma controller) to start filling it with cells.  If a block is
 * not available, the 'losing' mode will be set on the interface.
 */
static inline void FEED_BLK(point_622_atm *p)
{
    struct block *block;
    
    /* Get a free block to fill. */
    block=block_pool_free_get(&p->block_pool);
    
    /* 
     * If we're out of free blocks, we can't feed the card right now and
     * will have to start losing.
     */
    if(!block) {
	p->losing = TRUE;
	return;
    }
    
    /* Save the time that we started writing to this block. */
    savetime(&block->header->tbegin);
    
    /* Denote this block as currently being filled. */
    block_pool_filling_set(&p->block_pool, block);
    
    /* 
     * XXX: The cell shifting bug might be due to sending the WriteAddress
     * without having disabled something or set something correctly.  Go
     * through the point manual and make sure this is done at the right
     * state.  Also, test to see if it's writing out of bounds of the block
     * by 4 bytes or so when we have such a problem.
     */
    /* Tell the card to start writing to this block. */
    p->amcc->MasterWriteAddress = vtophys(block->raw_block);
    /* XXX which is right?  If they're not equal, it might matter. */
#if 0
    p->amcc->MasterWriteTransferCount = POINT_CELLS_PER_BLK * POINT_CELL_SIZE;
#else
    p->amcc->MasterWriteTransferCount = POINT_BLK_SIZE;
#endif
    p->amcc->BusMasterControlStatus.EnableWriteTransfer = TRUE;
    
    return;
}


/*
 * Take the current block off the card and save it for the user to take. 
 */
static inline struct block *EAT_BLK(point_622_atm *p)
{
    struct RxStatus1_register stat1;
    struct block *block;
    
    /* Take the block that was just filled off the filling list. */
    block=block_pool_filling_get(&p->block_pool);
    
    /* If we have no previously filled block we can just skip this code. */
    if(block == NULL) {
    	return(NULL);
    }
    
    /* If we lost cells, save the number of them we lost. */
    stat1 = p->fpga->Status1;
    if (stat1.FifoEverFull) {
	read_cell_loss(p, block);
    }
    else {
	block->header->cells_lost=htonl(0);
    }
    
    /* Save the time we completed this block. */
    savetime(&block->header->tend);
    
    /* Stick this block in the list of filled blocks. */
    block_pool_filled_set(&p->block_pool, block);
    
    /* Wake up libcoral apps to read this new block we got. */
    selwakeup(&p->s);

    return(block);
}


/*
 * interrupt handler for the point card.  this is called when the
 *  card has completed a bus-mastered transfer of cell data to 
 *  host memory.  first call EAT_BLK to do what we need to to take
 *  the current blk off the card.  second, if we have a free memory block
 *  to give to the card, give it to the card, and tell it to start
 *  capturing. third wakeup any processes waiting for data from us.
 * this function has to load the next blk into the card asap, ie call FEED_BLK
 */
void MODUNIQ(point_interrupt)(point_622_atm *p)
{
    struct AmccInterruptControlStatus_register amcc_intr;
    struct AmccBusMasterControlStatus_register amcc_bus;
    struct block *block;

    amcc_intr=p->amcc->InterruptControlStatus;
    amcc_bus=p->amcc->BusMasterControlStatus;
    
    /* 
     * We should never get here if we are in losing mode.  If we do, it
     * means we didn't correctly shut off the card filling and it has
     * probably been refilling the block we had previously finished with.
     */
    if(p->losing) {
	printf("Losing mode during an interrupt?  Serious bug.\n");
    }
    
    if (!(p->state & ST_CAPTURING)) {
	/* XXX: It does?  I haven't seen it.. */
	/* printf("XXX: Ok, I guess it does..\n"); */
	/* currently this always happens once during initialization.
	 * which is ok, until someone figures out a better way to 
	 * do the initialization, that works */

    } else if (amcc_intr.WriteTransferCompleted) {

	/* Disable the card from writing any more cells. */
	amcc_bus.EnableWriteTransfer = FALSE;
	p->amcc->BusMasterControlStatus = amcc_bus;
        
	/* Take the currently filling block out and save it. */
	block = EAT_BLK(p);
        block->header->cell_count = ntohl(POINT_CELLS_PER_BLK);

        /* Give the card a new block to fill. */
	FEED_BLK(p);
	
    } else {
	printf("point%d: unknown interrupt amcc_intr: "
	       "%x amcc_bus: %x state: 0x%x\n", 
	       p->pointi, *(u_int*)&amcc_intr, *(u_int*)&amcc_bus, p->state);
    }

    /* this clears the interrupts that brought us here by writing
     * a 1 to the bit corresponding to the interrupt who occurred */
    p->amcc->InterruptControlStatus = amcc_intr;
    
    p->interrupts++;
}


/*
 * point_start - set all the blkinfo's to the right values
 * 		 feed the card and clear it's loss counters
 * 
 */
static int point_start(point_622_atm *p)
{
    struct RxStatus1_register stat1;

#ifdef CORAL_DEBUG
    uprintf("point%d: point_start\n", p->pointi);
#endif

    if (!(p->state & ST_FPGAINITED)) {
	log(LOG_ERR, "point%d: point_start called before card initalized\n", 
	       p->pointi);
	return ENODEV/*ENXIO*/;
    }
    if (p->state & ST_CAPTURING) {
	log(LOG_ERR, "point%d: point_start called while already receiving\n",
	       p->pointi);
	return EALREADY;
    }
    
    /* Reset the buffer so all blocks are free and have sane settings. */
    block_pool_reset(&p->block_pool, p->pointi, POINT_BLK_SIZE);
    
    /* Record that we are now capturing cells. */
    p->state |= ST_CAPTURING;

    /* clear the various cell counters */
    p->fpga->CellCountTransferReset.LatchAndClear = 1;

    /* clear the error indicator bits */
    stat1 = p->fpga->Status1;

    /* next two for when we do a start after a stop */
    p->amcc->InterruptControlStatus.EnableWriteTransferCompleteInterrupt 
	= TRUE;
    /* 2. re-start the fpga passing cells along */
    p->fpga->Control1.EnableCells = TRUE;

    /* Feed the first block to the card to get it started. */
    FEED_BLK(p);

    return(0);
}


/*
 * point_stop - stop the capture of cells, maybe
 *        someday implement/test the ability to restart
 *        a capture after it has been stopped
 */
static void point_stop(point_622_atm *p)
{
    u_int last_adr;
    struct block *block;
    /* struct RxStatus1_register stat1; */

    /* We must have been started to be able to stop. :) */
    if (!(p->state & ST_CAPTURING)) {
#ifdef CORAL_DEBUG
	uprintf("point%d: point_stop called before point_start state:%x\n",
		p->pointi, p->state);
#endif
	return;
    }
    
    /* stop the fpga from passing cells along */
    p->fpga->Control1.EnableCells = FALSE;
    
    /* allow time for the cells in the fifo to get off
     * of the card. 1 cell = 0.000000707 sec, fifo is 4k*32bits deep,
     * cells are 60 bytes; time to empty fifo: 0.0001933 sec, 
     * one millisecond should be plenty.
     */
    DELAY(2);

    /* shutdown the pci bus mastering */
    p->amcc->BusMasterControlStatus.EnableWriteTransfer = FALSE;
    p->amcc->InterruptControlStatus.EnableWriteTransferCompleteInterrupt
	= FALSE;
    p->state &= (~ST_CAPTURING);

    /* Take the block that is currently being filled off the card. */
    block=EAT_BLK(p);
           
    /* If we had a partially filled block, record how full it was. */
    if(block != NULL) {
        last_adr=p->amcc->MasterWriteAddress;
        last_adr-=vtophys(BLK_IDX_TO_ADR(block->index, p->buffer, POINT_BLK_SIZE, POINT_NUM_BLKS));
        last_adr/=POINT_CELL_SIZE;
        block->header->cell_count=htonl(last_adr);
    }

    return;
}


/*
 * Release the oldest user locked block back to the free block list.
 */
static int point_release(point_622_atm *p) {
    struct block *previous_block;
    
    /* Free the oldest user locked block. */
    previous_block=block_pool_locked_get(&p->block_pool);
    if(previous_block) {
        
        /* Free the block. */
        block_pool_free_set(&p->block_pool, previous_block);

        /* Had we previously run out of blocks to feed the card? */
        if (p->losing && (p->state & ST_CAPTURING)) {

            /* We've freed up a block, start the card capturing again. */
   	    p->losing = FALSE;
   	    FEED_BLK(p);
        }
    }
    
    /* We didn't have any user locked blocks?  Silly user. */
    else {
    	return(EAGAIN);
    }
    
    return(0);
}


/*
 * point_nextblk -
 *	this acts like a poll, if (there's no data available) return EAGAIN;
 *	else {
 *		return the index of the next full blk.
 *		if the card is stopped because of lack of memory 
 *		to give to the card, give it some and restart it.
 *	}
 */
static int point_nextblk(point_622_atm *p, int *cbi, int norelease)
{
    coral_blk_info_t *cb;
    struct block *block;
    
    /* Take a block off the filled list. */
    block=block_pool_filled_get(&p->block_pool);
    
    /* Did we not have any available blocks? */
    if(block == NULL) {
    
        /* 
         * If we wern't capturing, we return ok but an index of -1 to
         * indicate that we have read the last block.
         */
    	if(!(p->state & ST_CAPTURING)) {
	    *cbi=-1;
	    return(0);
	}
    	
    	/* Tell the caller to try again some other time. */
    	return(EAGAIN);
    }
    
    /* 
     * If norelease isn't set, we should free the previous user block if one
     * exists.
     */
    if(!norelease) {
        (void) point_release(p);
    }
    
    /* Add this block to the locked by the user list. */
    block_pool_locked_set(&p->block_pool, block);
    
    /* Return the index of this block. */
    *cbi=block->index;

    /* 
     * XXX Why is this here?  If it's just a speedup hack for the int
     * routine, that's just silly.  Ints don't happen that quickly to
     * bother adding mess to the driver.
     */
    cb = BLK_IDX_TO_INFO(*cbi, p->buffer, POINT_BLK_SIZE, POINT_NUM_BLKS);
    cb->tbegin.tv_sec = htonl(cb->tbegin.tv_sec);
    cb->tbegin.tv_nsec = htonl(cb->tbegin.tv_nsec);
    cb->tend.tv_sec = htonl(cb->tend.tv_sec);
    cb->tend.tv_nsec = htonl(cb->tend.tv_nsec);
    
    return(0);
}


/*
 * the *data is the length of valid fpga bytes in POINT_DL_BYTE(i, p->buffer)
 *
 * the data is assumed to have already been stashed by the 
 * user in shared mem, use POINT_DL_BYTE(i, p->buffer) to get the addr.
 *
 * if successful, return 0; else non-zero
 *
 * most of this code is lifted from Joel's (apisdorf@mci.net) dos driver.
 *
 */
static int point_load_fpga(point_622_atm *p, u_int *imglen)
{
    u_int i;
    u_int len = *imglen;
    u_char readback_byte, program_byte;
    u_long elapsed, total = 0;
    struct CpldControl1_register cpld_temp;
    int firmware_checksum = 0;
    
    /* XXX should check for other invalid lengths */
    if (!len) {
	log(LOG_ERR, "point%d fpga download data is zero length\n", p->pointi);
    }

    /* 
     * Calculate a checksum of this fpga. 
     *
     * XXX: Summation sucks for checksums, if coralreef gets CRC32 code, use
     * that instead.  Possibly just save the old firmware in memory..
     */
    for(i=0; i < len; i++) {
	firmware_checksum += POINT_DL_BYTE(i, p->buffer);
    }
    
    /* If this is the first fpga loaded, save the checksum. */
    if (!(p->state & ST_FPGALOADED)) {
	
	/* Save new checksum. */
	p->firmware_checksum=firmware_checksum;
	
	/* We will need to init due to this new firmware. */
	p->state &= ~ST_FPGAINITED;
    }
    
    /* 
     * There's already a fpga loaded, if the checksums match, we don't need
     * to reload it.
     */
    else {
	if(p->firmware_checksum == firmware_checksum) {
	    /* XXX: Test this further before enabling. */
	    /* return(0); */
	}
    }

#ifdef CORAL_DEBUG
    printf("point%d beginning to load fpgas; length: %u\n", p->pointi, len);
#endif
    
    /* Assert program line and wait. */
    p->cpld->cpld_Control1.ProgramNot = 0;
    DELAY(MAX_START_TIME);

    /* make sure the program line is asserted (low),
     * so we know the jumpers are set properly on the card */
    if (p->cpld->cpld_Control1.ProgramNot) {
	printf("point%d: cannot assert program line; jumpers"
	       "are probably wrong\n", p->pointi);
	return(EIO);
    }

    /* Deassert program line and wait. */
    p->cpld->cpld_Control1.ProgramNot = 1;
    DELAY(MAX_START_TIME);
    
    /* make sure the program line is deasserted (high),
     * so we know the jumpers are set properly on the card */
    if (p->cpld->cpld_Control1.ProgramNot == 0) {
	log(LOG_ERR, "point%d: cannot deassert program line; jumpers "
	       " are probably wrong\n", p->pointi);
	return(EIO);
    }
    
    /* Write each byte of the firmware to the point card. */
    for (i = 0; i < len; i++) {
	    
	p->fpga->tx_rw = program_byte = POINT_DL_BYTE(i, p->buffer);
	elapsed = 0;
	do {
	    DELAY(1); /* 1 usec */
	    elapsed += 1;
	    total += 1;

	    readback_byte = p->fpga->tx_rw;

	    /* check that bits 0-6 were high */
	    if ((readback_byte & 0x7F) != 0x7F) {
		log(LOG_ERR, "point%d: after wr %dth value 0x%X,"
		       " low 6 bits were 0x%x; time %lu\n",
		       p->pointi, i, (char)program_byte, 
		       readback_byte & 0x7F, elapsed);
		return(EIO);
	    }

	    /* while bit 7 was read as 0
	     * and not too much time has elapsed */
	} while ( !(readback_byte & 0x80) && elapsed < MAX_VERIFY_TIME);

	if (elapsed >= MAX_VERIFY_TIME) {
	    log(LOG_ERR, "point%d: waited too long (%dus) for FPGA to"
		   " accept %dth value 0x%x\n", p->pointi, 
		   (int)elapsed, i, program_byte);
	    return(EIO);
	}

	/* check that ~config error line is deasserted (high) */
	if (!p->cpld->cpld_Control1.ConfigErrorNot) {
	    log(LOG_ERR, "point%d: config error line was asserted (low) after"
		   " %dth value 0x%x was verified\n", 
		   p->pointi, i, program_byte);
	    return(EIO);
	}
    }

#ifdef CORAL_DEBUG
    printf("point%d: total DELAY delay during load: %d usec\n",
	   p->pointi, (int)(total));
#endif

    /* wait for done signal to be asserted (high)
     * or for config error signal to be asserted (low)
     * or for too much time to elapse
     */
    elapsed = 0;
    cpld_temp = p->cpld->cpld_Control1;

    while (cpld_temp.ConfigErrorNot
	   && !cpld_temp.Done
	   && elapsed < MAX_DONE_TIME) {
	cpld_temp = p->cpld->cpld_Control1;
	DELAY(7);
	elapsed += 7;
	total += 7;
    }

    if (!cpld_temp.ConfigErrorNot) {
	log(LOG_ERR, "point%d: configuration error after %d bytes"
	       " transferred to FPGA's\n",
	       p->pointi, i);
	return(EIO);
    }
    
    if (elapsed >= MAX_DONE_TIME) {
	log(LOG_ERR, "point%d: error!  waited more than %d usec for "
	       "done line to be asserted\n",
	       p->pointi, MAX_DONE_TIME);
	return(EIO);
    }
    p->state |= ST_FPGALOADED;

#ifdef CORAL_DEBUG
    printf("point%d: wrote %d bytes to fpgas\n", p->pointi, i);
    printf("point%d: total DELAY time: %d usec\n", p->pointi, (int)(total));
#endif
    return 0;
}


/*
 * Read from the sram memory of the point card at a specific location.
 */
static int sram_read(volatile fpga_regs *fpga, u_int offset, int *val)
{
    u_char tmp = 0;
    long long elapsed;
    
    if (offset > MAX_SRAM_ADDRESS) {
        log(LOG_ERR, "address 0x%x is larger than maximum 0x%x\n", offset, 
	       MAX_SRAM_ADDRESS);
        return E2BIG;
    }

    /* a word to the wise: if you do these register writes
     * in order of ascending addresses, the host locks up hard,
     * requiring a hard reset or power-cycle
     * here's why: (really a CPLD s/w bug)
     * doing register writes in order causes the Intel
     * 83439HX PCI controller on the motherboard to generate
     * a burst on the PCI bus, and during the 2nd data phase
     * the AMCC PCI i/f on the POINT card determines that
     * a burst is in progress, and it leaves PTATN# asserted,
     * but the CPLD on the board assumes that signal will
     * always be deasserted before reassertion (single cycles),
     * so it never asserts the PTRDY# signal for the 3rd+ data
     * phases, and hence the AMCC will issue a PCI retry request,
     * but since the CPLD never sees a PTATN# deassertion, when
     * the host tries again 272 nS later it will fail again,
     * ad infinitum, ad nauseum */

    /* put the low 2 bytes of the address directly into the
     * RX FPGA registers */
    fpga->SramAddress1 = (offset >> 8) & 255;
    fpga->SramAddress0 = offset & 255;

    /* put the high 4 bits of the address into a host-based
     * temporary area, so we can write it, along with the
     * command, all at once, and set DoCycle */
    tmp = ((offset >> 16) & 15) | 0x80;
    *(char*)&fpga->SramAddress2Control = tmp;

    elapsed = 0;
    do {
        tmp = fpga->SramAddress2Control.DoCycle;
	DELAY(1);
	elapsed += 1;
    } while (tmp && elapsed <= MAX_CYCLE_DELAY);

    if (tmp) {
        log(LOG_ERR, "point: more than %d usec elapsed waiting for SRAM\n", 
	       MAX_CYCLE_DELAY);
        return -1;
    }

    *val = fpga->SramData0
	| (fpga->SramData1 << 8)
	| (fpga->SramData2 << 16)
	| (fpga->SramData3 << 24);

    return 0;
}


/*
 * Write a value to the card's sram memory at a specific location.
 */
static int sram_write(volatile fpga_regs *fpga, u_int offset, int val)
{
    struct RxSramAddress2Control_register address2control;
    struct timespec timer_start, timer;
    
    if (offset > MAX_SRAM_ADDRESS) {
        log(LOG_ERR, "address 0x%x is larger than maximum 0x%x\n", offset, 
	       MAX_SRAM_ADDRESS);
        return E2BIG;
    }

    /* the same warning from sram_read applies here */
    fpga->SramData3 = (val >> 24) & 255;
    fpga->SramData2 = (val >> 16) & 255;
    fpga->SramData1 = (val >> 8) & 255;
    fpga->SramData0 = val & 255;
    
    /* put the low 2 bytes of the address directly into the
     * RX FPGA registers */
    fpga->SramAddress1 = (offset >> 8) & 255;
    fpga->SramAddress0 = offset & 255;
    
    /* put the high 4 bits of the address into a host-based
     * temporary area, so we can write it, along with the
     * command, all at once */
    /* and set docycle, cycleiswrite too */
    address2control.Value = (offset >> 16) & 0xf;
    
    /* fill in the control fields of same register */
    address2control.Reserved = 0;
    address2control.DoCycle = TRUE;
    address2control.CycleIsWrite = TRUE;

    fpga->SramAddress2Control = address2control;
    
    /* Wait for the write to complete up to MAX_CYCLE_DELAY usecs. */
    nanotime(&timer_start);
    for(;;) {
	
	/* Has the write completed?  This will go low if so. */
	if(!fpga->SramAddress2Control.DoCycle) break;
	
	/* Check if we've exceeded the maximum delay (in usec). */
	nanotime(&timer);
	if(((timer.tv_sec - timer_start.tv_sec) * 1000000) + ((timer.tv_nsec - timer_start.tv_nsec) / 1000) > MAX_CYCLE_DELAY) {
	    log(LOG_ERR, "\npoint: more than %d usec elapsed waiting for SRAM at %x\n", MAX_CYCLE_DELAY, offset);
	    log(LOG_ERR, "rx_ctl1: 0x%x\nrx_stat1: 0x%x\n", *(char*)&fpga->Control1, *(char*)&fpga->Status1);
	    return -1;
	}
    }
    
    return(0);
}

/* point_init - 
 * 	initialize the card, clears everything on the card.
 */
static int point_init(point_622_atm *p, coral_io_mode_t *iomode)
{
    u_int i;
    struct RxControl1_register rx_ctl1;
    struct RxControl2_register rx_ctl2;
    struct RxMatchUnusedBits_register rx_match;
    struct AmccBusMasterControlStatus_register amcc_bus;
    struct AmccInterruptControlStatus_register amcc_intr;
    struct SuniRacpControl_register suni_ctl;
    
    *(u_int*)&amcc_bus = 0;
    *(u_int*)&amcc_intr = 0;

    if (!(p->state & ST_FPGALOADED)) {
	printf("point%d: trying to initialize before loading fpgas\n", 
	       p->pointi);
	return ENODEV/*ENXIO*/;
    }

    if (iomode->flags & ~CORAL_POINT_MODES) {
	printf("point%d: unsupported mode\n", p->pointi);
	return ENODEV;
    }

    /* make sure we know there's nothing happening */
    p->state &= ~ST_CAPTURING;
    p->losing = 0;
    p->iomode = *iomode;

    /* 
     * Set state for all VPI/VCI's to "no cells seen yet". 
     * 
     * Be sure to do this in descending order or else a PCI burst handling
     * bug could cause the card to lockup.
     */
#ifdef CORAL_DEBUG
    uprintf("clearing sram...iomode == %x, %d\n",
	p->iomode.flags, p->iomode.first_n);
#endif
    for(i = MAX_SRAM_ADDRESS; i > 0; i--) {
	if (sram_write(p->fpga, i-1, 0)) {
	    printf("cpld mbox status': %x\n", 
		   *(u_int*)&p->amcc->MailBoxStatuses);
	    printf("cpld ic status'  : %x\n", 
		   *(u_int*)&p->amcc->InterruptControlStatus);
	    printf("cpld bmc status' : %x\n", 
		   *(u_int*)&p->amcc->BusMasterControlStatus);
	    printf("point%d: sram_write failed\n", p->pointi);
	    return EIO;
	}
    }

    /* assert S/UNI-622 reset (low power),
     * so it won't give us any data while we are discarding
     * data on the FPGA. */
    p->suni->Master.Reset = TRUE;

    /* assert external FIFO reset and load level */
    rx_ctl1.UnResetExternalFifo = FALSE;
    rx_ctl1.EnableCells = FALSE;
    rx_ctl1.EnableFifoWrite = FALSE;
    rx_ctl1.EnableAmccWrite = FALSE;
    rx_ctl1.UnLoadFifoLevels = FALSE;
    rx_ctl1.CopyTimestampsToHost = FALSE;
    rx_ctl1.CopyAtmHeadersToHost = FALSE;
    rx_ctl1.CopyAtmPayloadsToHost = FALSE;
    p->fpga->Control1 = rx_ctl1;

    amcc_bus.ResetReadFifoFlags = TRUE;
    amcc_bus.ResetWriteFifoFlags = TRUE;
    p->amcc->BusMasterControlStatus = amcc_bus;


    /* stop resetting the addon-to-PCI FIFO status flags,
     * enable card to write to host memory, give writes
     * (toward host) priority over reads (toward card),
     * we dont make the  pci bus cycles because i dont
     * think it would make that much of a difference.
     * (of course, i could be wrong.)  and since cells are
     * 15 words, you could end up with 3 words of the last cell
     * in a blk just sitting in the amcc's fifo, and no more 
     * cells on the way to push it through.
     */
    amcc_bus.ResetReadFifoFlags = FALSE;
    amcc_bus.ResetWriteFifoFlags = FALSE;
    amcc_bus.EnableWriteTransfer = FALSE;
    amcc_bus.WriteVersusReadPriority = TRUE;
    amcc_bus.WriteFifo4FilledForPciReq = FALSE;
    p->amcc->BusMasterControlStatus = amcc_bus;

    /* ok, the strategy for now is not to ask why, but just to accept
     * that doing it this way works:
     * we set up the dma to transfer only ONE cell before it interrupts
     * then we go on and continue to initialize the card, enabling 
     * interrupts and everything.  this way of doing things makes it
     * so that the only thing that has to happen when point_start()
     * is called is for it to feed the card a blk.  this whole initialization
     * and starting paradigm could be reexamined, but in the meantime:
     * "just accept that doing it this way works."
     */
    /* -- begin special case of FEED_BLK() -- */
    /* XXX This is really crappy. */
    p->amcc->MasterWriteAddress = vtophys(p->buffer + 512); 

    /* 1 cell only, the interrupt handler knows that p->listen == 0,
     * so nothing will happen */
    p->amcc->MasterWriteTransferCount = POINT_CELL_SIZE;
/*    p->amcc->MasterWriteTransferCount = POINT_BLK_SIZE;*/

    /* re-enable bus master writes to host memory */
    amcc_bus.EnableWriteTransfer = TRUE;
    p->amcc->BusMasterControlStatus = amcc_bus;

    /* -- end special case of FEED_BLK() -- */

    /* enable AMCC to interrupt host when write transfer is complete */
    amcc_intr.EnableWriteTransferCompleteInterrupt = TRUE;
    p->amcc->InterruptControlStatus = amcc_intr;

    /* stop resetting the external FIFO */
    rx_ctl1.UnResetExternalFifo = TRUE;
    p->fpga->Control1 = rx_ctl1;

    /* set the external FIFO's almost-empty level to 1
     * and its almost-full level to FULL - 0xe
     * this is because 14 words is enough to finish
     * putting the current cell in the fifo. */

    p->fpga->FifoLevelWrite = 0x01;
    p->fpga->FifoLevelWrite = 0x00;
    p->fpga->FifoLevelWrite = 0x0e;
    p->fpga->FifoLevelWrite = 0x00;

    /* stop loading FIFO levels */
    rx_ctl1.UnLoadFifoLevels = TRUE;
    p->fpga->Control1 = rx_ctl1;

    /* enable the parts of the cell we want copied to host */
    rx_ctl1.CopyTimestampsToHost = TRUE;
    rx_ctl1.CopyAtmHeadersToHost = TRUE;
    rx_ctl1.CopyAtmPayloadsToHost = TRUE;
    p->fpga->Control1 = rx_ctl1;

    /* unused bits of VPI/VCI (in this case the GFC)
     * must match 0
     * DANGER: executing this write (at address +410h)
     * immediately after the write to RX control2 register
     * (at address +40Ch) allows the 82439HX to merge the
     * 2 accesses into a PCI burst which a POINT CPLD bug...lockup */
    rx_match.Value = 0;
    rx_match.Mask = 0xf;
    p->fpga->MatchUnusedBits = rx_match;

    /* UNI addressing */
    p->fpga->Control2.NumVciBitsStolenForVpi = 0;


    if (p->iomode.flags & (CORAL_RX_OAM | CORAL_RX_IDLE)) {
/*	printf("passing oam/rm\n");*/
	rx_ctl2.PassOamRmCells = TRUE;
    } else {
	rx_ctl2.PassOamRmCells = FALSE;
    }
    if (p->iomode.flags & (CORAL_RX_LAST | CORAL_RX_USER_ALL | CORAL_RX_IDLE)) {
/*	printf("passing last\n");*/
	/* Note: AllAAL5 does not include AllLast */
	rx_ctl2.PassAllLastCells = TRUE;
    } else {
	rx_ctl2.PassAllLastCells = FALSE;
    }
    if (p->iomode.flags & (CORAL_RX_USER_ALL | CORAL_RX_IDLE)) {
/*	printf("passing all aal5 cells\n"); */
	rx_ctl2.PassAllAAL5Cells = TRUE;
    } else {
	rx_ctl2.NumAAL5CellsToPass = p->iomode.first_n;
	rx_ctl2.PassAllAAL5Cells = FALSE;
    }

    rx_ctl2.NumAAL5CellsToPass = 1;
    p->fpga->Control2 = rx_ctl2;

    /* clear the RX FPGA's counts of various kinds of cells, */
    p->fpga->CellCountTransferReset.LatchAndClear = 1;
    
    /* tell the TriQuint serial/parallel chip how to loop */
    /* Facility; - world rx what card and world tx */
    if (CORAL_RX_IDLE & p->iomode.flags)
	p->cpld->LoopbackControl.Select = Split;    /* be non-intrusive */
    else
	p->cpld->LoopbackControl.Select = Facility; /* i rx, i tx, world tx */
#ifdef CORAL_DEBUG
/*    printf("enable cells & amcc...\n"); * save this until point_start() */
#endif
    rx_ctl1.EnableCells = TRUE;
    p->fpga->Control1 = rx_ctl1;

    /* enable writes to AMCC FIFO */
    rx_ctl1.EnableAmccWrite = TRUE;
    p->fpga->Control1 = rx_ctl1;

    /* enable writes to external FIFO */
    rx_ctl1.EnableFifoWrite = TRUE;
    p->fpga->Control1 = rx_ctl1;

    /* deassert S/UNI-622 reset
     * note that if the framer was already enabled, this would
     * clear all S/UNI counters, including RX section BIP-8 error count */
#ifdef CORAL_DEBUG
/*    printf("suni un reset...\n");*/
#endif
    p->suni->Master.Reset = FALSE;

    /* suni stuff */
    suni_ctl.DisablePayloadDescrambling = FALSE;
    suni_ctl.ResetFifo                  = FALSE;
    suni_ctl.AddCosetPolynomialToHcs    = TRUE;
    suni_ctl.PassUncorrectableHcsErrors = FALSE;
    suni_ctl.DisableHcsErrorCorrection  = FALSE;
    suni_ctl.RxParityEven               = FALSE;
    suni_ctl.EnableFixedStuffing        = TRUE;
    if (p->iomode.flags & CORAL_RX_IDLE) {
	log(LOG_DEBUG, "passing idle cells\n");
	suni_ctl.PassFilteredCells      = TRUE;
    } else
	suni_ctl.PassFilteredCells      = FALSE;
    p->suni->RacpControl = suni_ctl;
    
    /* If we are an OC3 card, we set the S/UNI-622 to receive at that rate. */
    if(p->bitrate == KBPS_OC3c) {
	p->suni->MasterConfiguration.TMODE=0x01;
	p->suni->MasterConfiguration.RMODE=0x01;
    }
    
    p->suni->GfcAndMiscControl.RxGfcEnable0               = TRUE;
    p->suni->GfcAndMiscControl.RxGfcEnable1               = TRUE;
    p->suni->GfcAndMiscControl.RxGfcEnable2               = TRUE;
    p->suni->GfcAndMiscControl.RxGfcEnable3               = TRUE;
    p->suni->GfcAndMiscControl.Unused                     = 0;
    p->suni->GfcAndMiscControl.RxByteParity               = FALSE;
    /* would be different for ppp */
    p->suni->GfcAndMiscControl.CellDelineationDisable     = FALSE;

    p->state |= ST_FPGAINITED;
    
    return 0;
}

/*
 * point_reset - nothing really
 */
static void point_reset(point_622_atm *p)
{
/*    point_stop(p);*/
}


/*
 * here starts the vfs interface stuff
 */
static d_open_t pointopen;
static d_close_t pointclose;
static d_ioctl_t pointioctl;
static d_poll_t pointselect;
static d_mmap_t pointmmap;

#if __FreeBSD_version < 400000
struct cdevsw MODUNIQ(point_cdevsw) = {
    pointopen,
    pointclose,
    noread,
    nowrite,
    pointioctl,
    nostop,
    noreset,
    nodevtotty,
    pointselect,
    pointmmap,
    NULL, /* d_strategy */
    "point", /* d_name */
    NULL, /* d_spare */
    -1, /* d_maj */
};

#else /* __FreeBSD_version >= 400000 */
struct cdevsw MODUNIQ(point_cdevsw) = {
    pointopen,
    pointclose,
    noread,
    nowrite,
    pointioctl,
    pointselect,
    pointmmap,
    NULL, /* d_strategy */
    "point", /* d_name */
    CDEV_MAJOR,
    nodump,
    nopsize,
    0,
    -1, /* bmaj */
};
#endif

/*
 * point_attach()
 *
 * this is the first thing called, and the only fxn 
 * in this file called at boot time.  if we could get
 * the flat memory allocation to work after boot time,
 * then we could do this as a module, and also not waste
 * so much mem.
 */
void MODUNIQ(point_attach)(point_622_atm *p, int unit)
{
    int err;
    static int once = 0;

    p->pointi = unit;
    p->state = 0;

#ifdef MODULE

    /* code to attach as a module */
    /* ...nothing */

#else

/*    timeout((void *)point_leds, p, 1); */

    /* add entry to the devide tables */

    if (!once++) {
#ifdef CORAL_DEBUG
	uprintf("point%d: adding dev entry", unit);
#endif
#if __FreeBSD_version >= 400000
	err = cdevsw_add(&MODUNIQ(point_cdevsw));
#else
	dev_t dev;
	dev = makedev(CDEV_MAJOR, unit);
	err = cdevsw_add(&dev, &MODUNIQ(point_cdevsw), NULL);
#endif
	if (err)
	    printf(" .. cdevsw_add() returned %d\n", err);
    }
#endif
#if __FreeBSD_version >= 400000
    make_dev(&point_cdevsw, unit, UID_ROOT, GID_WHEEL, 0644, "point%d", unit);
#endif
}


/*
 * pointopen - setup the device for use by userland.
 * 
 * only allow one user to open a point at a time
 * cleanup dev specific counters, etc...
 */

static int pointopen(dev_t dev, int flag, int mode, struct proc *pr)
{
    point_622_atm *p = POINT_FROM_DEV(dev);

#ifdef CORAL_DEBUG
    /* uprintf("point%d: open()\n", p->pointi); */
#endif

    if (p->state & ST_OPEN) {
	return EBUSY;
    }
    if (!p->buffer) {
	log(LOG_ERR, "point%d: no buffer allocated\n", p->pointi);
	return ENXIO;
    }
    
    /* The card shouldn't be capturing if it wasn't open. */
    if(p->state & ST_CAPTURING) {
    	log(LOG_ERR, "point%d: Non-open device was capturing?\n", p->pointi);
        return EBUSY;
    }
    
    bzero(&p->s, sizeof(struct selinfo));

    p->state |= ST_OPEN;

    p->iomode.flags = 0;
    p->iomode.first_n = 1;

    p->losing = 0;
    p->rx_errors = 0;
    p->interrupts = 0;
    
    /* Save the pid of the process opening us so we can CLOCKSYNC correctly. */
    p->pid=pr->p_pid;
    
    return 0;
}

/*
 * pointclose - shutdown the card, let others use the card again
 *
 */
static int pointclose(dev_t dev, int flag, int mode, struct proc *pr)
{
    point_622_atm *p = POINT_FROM_DEV(dev);
    
#ifdef CORAL_DEBUG
    uprintf("point%d: closing\n", p->pointi);
#endif
    
    if (p->state & ST_CAPTURING) {
	point_stop(p);
    }

    p->state &= ~ST_OPEN;
    
    return 0;
}

/* 
 * pointioctl - main entry point to driver functionality
 */
static int pointioctl(dev_t dev, u_long cmd, caddr_t data, 
		      int flag, struct proc *pr)
{
    point_622_atm *p = POINT_FROM_DEV(dev);
    coral_interface *ci;
    int i;
    int s;
    
#ifdef CORAL_DEBUG
    /*uprintf("point%d: ioctl (0x%x)\n", p->pointi, cmd);*/
#endif

    switch (cmd) {
    case CORAL_FILLINFO:
	ci = (coral_interface *)data;
	ci->version = CORAL_DRIVER_VERSION;
	ci->type = CORAL_TYPE_POINT;
	ci->kmem_buffer = p->buffer;
	ci->blk_size = POINT_BLK_SIZE;
	ci->num_blks = POINT_NUM_BLKS;
	ci->iomode = p->iomode;
	ci->tx_errors = 0;
	ci->rx_errors = p->rx_errors;
	ci->interrupts = p->interrupts;
	ci->bitrate = p->bitrate;
        break;
    
    case CORAL_READ_SRAM:
        
        /* Make sure the location passed is in range. */
        if(*(int *)data < 0 || *(int *)data > MAX_SRAM_ADDRESS) {
        	return(ERANGE);
        }
        
        /* Read and return the value at the location passed. */
        sram_read(p->fpga, *(int *)data, (int *)data);
        break;
    
    case CORAL_RESET:
	point_reset(p);
	break;

    case CORAL_INIT:
	return point_init(p, (coral_io_mode_t*)data);
	break;

    case CORAL_CLRTSTAMP:
	p->fpga->CellCountTransferReset.ClearTimestamp = 1;
	break;

    case CORAL_CLOCKSYNC:

	s = splhigh();
	for (i = 0; i < NPOINT; i++) {
	    
	    /* We only reset cards opened by the caller process. */
	    if ((points[i].state & ST_OPEN) && (points[i].pid == pr->p_pid))

#ifdef CORAL_DEBUG		
		uprintf("point%d: Issuing clear for pid %d.\n", i, pr->p_pid);
#endif
		
		/* Reset this card's timestamp. */
		points[i].fpga->CellCountTransferReset.ClearTimestamp = 1;
        }
	splx(s);
	break;

    case CORAL_START:
	return point_start(p);
	break;

    case CORAL_STOP:
	point_stop(p);
	break;

    case CORAL_NEXTBLK:
	return point_nextblk(p, (int *)data, 0);
	break;
    
    case CORAL_NEXTBLK_NORELEASE:
	return point_nextblk(p, (int *)data, 1);
	break;
    
    case CORAL_RELEASE:
    	return point_release(p);
    	break;
    
    case POINT_LOAD_FIRMWARE:
	return point_load_fpga(p, (u_int *)data);
	break;

    default:
	log(LOG_ERR, "point%d: unknown ioctl (0x%lx)\n", p->pointi, cmd);
	break;
    }
/*  printf("point%d: finished ioctl (0x%x)\n", p->pointi, cmd); */

    return(0);
}


/* pointselect - if we've got data, then return an indication of that,
 *               otherwise stick the process on our p->s, to be woken
 *               when we get some.
 *
 */
static int pointselect(dev_t dev, int rw, struct proc *pr)
{
    point_622_atm *p = POINT_FROM_DEV(dev);
    int revents = 0;
    int intlevel;
    
#if __FreeBSD_version >= 300000
    if (rw != POLLRDNORM) {
#else
    if (rw != FREAD) {
#endif
	log(LOG_ERR, "select pooped out, rw:%d\n", rw);
	return 0;
    }
    
    /* 
     * If we have any filled blocks, signal the caller so.  Must all be done
     * exclusively in case the interrupt routine manages to give us a block
     * before we have recorded the process as sleeping on select.
     */
     intlevel=splhigh();
    if(block_pool_has_filled_blocks(&p->block_pool) || !(p->state & ST_CAPTURING)) {
#if __FreeBSD_version >= 300000
	revents = POLLIN | POLLRDNORM;
#else
	revents = TRUE;
#endif
    }
    
    /* We had no filled blocks, so save the caller to be woken up when we do. */
    else {
    	selrecord(pr, &p->s);
    }
    splx(intlevel);
    
    /* Return the select status. */
    return(revents);
}

/*
 * Mmap the card's cell buffer.
 */
#if __FreeBSD_version < 340000
static int pointmmap(dev_t dev, int offset, int prot)
#else
static int pointmmap(dev_t dev, vm_offset_t offset, int prot)
#endif
{
    point_622_atm *p;
    
    /* Sanity check arguments, must be in range and non-executable. */
    if(!(offset >= 0 && offset < POINT_CELLBUF_SIZE) || prot & PROT_EXEC) {
        return(-1);
    }

    /* Get the point structure corresponding to this device. */
    p = POINT_FROM_DEV(dev);
    
    /* Return the offset to our buffer. */
#ifdef __i386__
    return i386_btop(vtophys(p->buffer + offset));
#endif
#ifdef __alpha__
    return alpha_btop(vtophys(p->buffer + offset));
#endif
}
