/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 *
 */
/*
 * $Name: release-3-8-1 $
 * $Id: pat_func.cc,v 1.26 2007/06/06 18:17:43 kkeys Exp $
 */

extern "C" {
#include <sys/types.h>
#include <stdio.h>
#include <unistd.h>
#include <netinet/in.h>
#include <errno.h>
#include <sys/time.h>
#include <stdio.h>
  
  extern int errno;
}

#include <string>
#include <map>
#include <fstream>
#include <iomanip>

using namespace std;

#include "pat_func.h"

template <class Finder>
int _load_file_text(Finder * finder, const char * digested_bgp_filename)
{
    ifstream bgpFile;

    bgpFile.open(digested_bgp_filename);
    if (bgpFile.fail()) {
	fprintf(stderr,"open(%s) failed: %s\n",
		digested_bgp_filename,strerror(errno));
	return 0;
    }

    string dataline, chunk;

    finder->clear();

    getline(bgpFile, dataline);
    while (!bgpFile.eof()) {
	string net1, mask, as;
	string::size_type net2_start, mask_start, as_start, as_end, slash;

	net2_start = dataline.find('\t', 0) + 1;
	net1 = dataline.substr(0, net2_start-1);
	slash = net1.find('/');
	if (slash == string::npos) { // This is new-style
	    mask_start = net2_start; // Therefore there is no net2
	} else {
	    mask_start = dataline.find('\t', net2_start) + 1;
	    net1 = net1.substr(0, slash);
	}

	as_start = dataline.find('\t', mask_start) + 1;
	as_end = dataline.find_first_of("\t\n", as_start);

	mask = dataline.substr(mask_start, as_start-mask_start-1);
	as = dataline.substr(as_start, as_end-as_start);

	typename Finder::ipaddr_type addr;
#ifdef AF_INET6
	int conv_ok = inet_pton(Finder::family, net1.c_str(), &addr);
	if (conv_ok == 0) {
	    cerr << "Couldn't convert address: " << net1 << endl;
	} else if (conv_ok < 0) {
	    cerr << "System error with address conversion: " << strerror(errno)
		<< endl;
	}
#else
	assert(Finder::family == AF_INET);
	addr.s_addr = inet_addr(net1.c_str()); /* No inet_aton on Solaris */
#endif

	// network constructor masks off bits, as required by IpPrefixPatricia
	typename Finder::key_type network(addr, atoi(mask.c_str()));
	(*finder)[network] = as;

	getline(bgpFile, dataline);
    }
    bgpFile.close();
    return 1; // Perl treats 0 as an error value
}

template <class Finder>
const char * _get_as(Finder * finder, const char * ip_str, char * net,
			int * masklen)
{
    typename Finder::ipaddr_type converter;
#ifdef AF_INET6
    int conv_ok = inet_pton(Finder::family, ip_str, &converter);
    if (conv_ok == 0) {
	cerr << "Couldn't convert address: " << ip_str << endl;
    } else if (conv_ok < 0) {
	cerr << "System error with address conversion: " << strerror(errno)
	    << endl;
    }
#else
    assert(Finder::family == AF_INET);
    converter.s_addr = inet_addr(ip_str); /* No inet_aton on Solaris */
#endif
    return _get_as_raw(finder, converter, net, masklen);
}

template <class Finder>
const char * _get_as_raw(Finder * finder,
			    const typename Finder::ipaddr_type & ip,
			    char * net, int * masklen)
{
    typename Finder::iterator treeIter;
    if (!finder) {
	cerr << "Error, no ASFinder defined!\n";
	exit(1);
    }
    treeIter = finder->LongestMatch(ip);
    if (treeIter != finder->end()) {
	if (net) {
#ifdef AF_INET6
	    inet_ntop(Finder::family, &(*treeIter).first.net, net, 64);
#else
	    /* systems without AF_INET6 won't have inet_ntop() either */
	    assert(Finder::family == AF_INET);
	    strcpy(net, inet_ntoa((*treeIter).first.net));
#endif
	}
	if (masklen) {
	    *masklen = (*treeIter).first.maskLen;
	}
	return (*treeIter).second.c_str();
    } else {
	if (net) {
	    net[0] = '\0';
	}
	if (masklen) {
	    *masklen = 0;
	}
	return NULL;
    }
}

/* ASFinder (IPv4) functions */
ASFinder * new_as_finder()
{
    return new ASFinder;
}

int load_file_text(ASFinder * finder, const char * digested_bgp_filename)
{
    return _load_file_text(finder, digested_bgp_filename);
}

const char * get_as(ASFinder * finder, const char * ip_str, char * net,
			int * masklen)
{
    return _get_as(finder, ip_str, net, masklen);
}

const char * get_as_raw(ASFinder * finder, struct in_addr * ip,
			    char * net, int * masklen)
{
    return _get_as_raw(finder, *ip, net, masklen);
}

void delete_as_finder(ASFinder * finder)
{
    if (finder)
	delete finder;
}

#ifdef AF_INET6
/* ASFinder6 functions */
ASFinder6 * new_as_finder6()
{
    return new ASFinder6;
}

int load_file_text6(ASFinder6 * finder, const char * digested_bgp_filename)
{
    return _load_file_text(finder, digested_bgp_filename);
}

const char * get_as6(ASFinder6 * finder, const char * ip_str, char * net,
			int * masklen)
{
    return _get_as(finder, ip_str, net, masklen);
}

const char * get_as_raw6(ASFinder6 * finder, struct in6_addr * ip,
			    char * net, int * masklen)
{
    return _get_as_raw(finder, *ip, net, masklen);
}

void delete_as_finder6(ASFinder6 * finder)
{
    if (finder)
	delete finder;
}
#else /* Fake versions to allow compilation */
ASFinder6 * new_as_finder6() { return NULL; }
int load_file_text6(ASFinder6 * finder, const char * digested_bgp_filename)
{ return 0; }
const char * get_as6(ASFinder6 * finder, const char * ip_str, char * net,
			int * masklen) { return NULL; }
const char * get_as_raw6(ASFinder6 * finder, struct in6_addr * ip,
			    char * net, int * masklen) { return NULL; }
void delete_as_finder6(ASFinder6 * finder) {}
#endif /* AF_INET6 */
