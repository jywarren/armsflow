/*
 * Copyright 2002, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program.  Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 */
 
#include "config.h"
#include "coraldefs.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>
#include <assert.h>
#include <time.h>

#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <errno.h>
#ifdef HAVE_SYS_IOCCOM_H
#include <sys/ioccom.h>
#endif
#include <sys/ioctl.h>
#include <sys/mman.h>

#include "libcoral.h"
#include "libcoral_priv.h"

#ifdef HAVE_CORAL_OPTISTAR

#if !WORDS_BIGENDIAN
# define LITTLE_ENDIAN_HOST /* required by Sniffer.h... */
#endif
#ifdef __linux__
# define __Linux__ /* required by Sniffer.h... */
#endif
#include <Sniffer.h>
#ifdef HAVE_APPLIB_H
# define NO_GETOPT /* required by AppLib.h */
# include <AppLib.h>
#endif

#define OPTISTAR_POLLTIME 1 /* microseconds */

static const char RCSid[] = "$Id: coral_type_optistar.c,v 1.19 2007/06/06 18:17:55 kkeys Exp $";

/* from Lucent's MmapTest.c */
typedef enum {
    AS_INACTIVE,
    AS_WAIT_SEQ_NUMBERS_VALID,
    AS_PACKET_HEADER_VALID,
    AS_PROCESS_PACKET,
    AS_NEXT_PACKET
} ADAPTER_STATE;
/* end from MmapTest.c */

/* shorten some inconveniently long optistar field names */
#define MapAddr		MappedAddress
#define HeadBufNum	HeadBufferNumber
#define NextBufNum	NextBufferNumber
#define RecvBufSize	ReceiveBufferSize
#define SeqNum		SequenceNumber
#define HeadSeqNum	HeadSequenceNumber

#define ts_ctrl_len	4
#define clipsize	(128 - ts_ctrl_len)

typedef struct OptiStar {
    int AdapterNum;
    ADAPTER_STATE state;
    unsigned ExpectedSeqNum;
    SNIFFER_INFO Info;
    volatile SNIFFER_PACKET_HEADER *header0;
    volatile SNIFFER_PACKET_HEADER *header;
} OptiStar_t;

static int
coral_optistar_init(coral_source_t *src)
{
    coral_iface_t *iface;
    uint32_t bw = 0;
    coral_protocol_t phy = CORAL_PROTO_UNKNOWN, datalink = CORAL_PROTO_UNKNOWN;
    const char *p;
    SNIFFER_SETUP Setup;
#ifdef HAVE_APPLIB_H
    ADAPTER_INFO AdapterInfo;
    MI_INFO MiInfo;
#endif
    OptiStar_t *optistar;
    static int found_adapters = 0;
    int first_n;

    coral_diag(5, ("coral_optistar_init: %s\n", src->filename));
    iface = cinst[src->id[0]];

    /* XXX GetAdapterNumberUsingInstanceName() */
    p = src->filename + strlen(src->filename);
    while (p != src->filename) {
	p--;
	if (!isdigit(*p)) {
	    p++;
	    break;
	}
    }
    if (!isdigit(*p)) {
	coral_diag(0, ("can't determine adapter number of %s\n",
	    src->filename));
	return -1;
    }

    if (!(iface->statedata = optistar = malloc(sizeof(OptiStar_t)))) {
	coral_diag(0, ("out of memory\n"));
	return -1;
    }

    /* If any src->dev_config fields are still unset, use device defaults. */
    coral_set_dev_config_defaults(&src->dev_config,
	&coral_iface_type_optistar.default_config);

    optistar->AdapterNum = atoi(p);
    coral_diag(5, ("coral_optistar_init: adapter %d\n", optistar->AdapterNum));

    if (!found_adapters) {
	FindAdapters(); /* apparently required to initialize driver */
	found_adapters = 1;
    }
    memset(&Setup, 0, sizeof(Setup));
    Setup.PromiscuousMode = 1;
    Setup.UseTimestamp = 1;
    if (src->dev_config.iomode.first_n > clipsize ||
	src->dev_config.iomode.flags & CORAL_RX_USER_ALL)
    {
	Setup.Clip = 0;
	/* Setup.Truncate = 0; */
    } else {
	Setup.Clip = 1;
	/* Setup.Truncate = src->dev_config.iomode.first_n; */
    }
    Setup.ZeroCopy = 1;
    Setup.Filter = 0;

    coral_diag(5, ("SnifferSetup %d: "
	"promisc=%d, time=%d, clip=%d, trunc=%d, zerocopy=%d, filter=%d\n",
	optistar->AdapterNum,
	Setup.PromiscuousMode, Setup.UseTimestamp, Setup.Clip,
	Setup.Truncate, Setup.ZeroCopy, Setup.Filter));
    if (SnifferSetup(optistar->AdapterNum, &Setup) < 0) {
	coral_diag(0, ("%s: SnifferSetup failed\n", src->filename));
	return -1;
    }

#ifdef HAVE_APPLIB_H
    if (GetAdapterInfo(optistar->AdapterNum, &AdapterInfo) < 0) {
	/* ignore error */
    } else {
	switch (AdapterInfo.MiType) {
	case MI_TYPE_OC48:
	    bw = KBPS_OC48c;
	    phy = CORAL_PHY_POS;
	    break;
	case MI_TYPE_PM5357:
	    bw = KBPS_OC12c;
	    phy = CORAL_PHY_POS;
	    break;
	case MI_TYPE_ENET_FIBER:
	case MI_TYPE_ENET_CAT5:
	    datalink = CORAL_DLT_ETHER;
	    break;
	case MI_TYPE_UNKNOWN:
	default:
	}
    }

    if (GetMiInfo(optistar->AdapterNum, &MiInfo) < 0) {
	/* ignore error */
    } else {
	switch (MiInfo.LinkSpeed) {
	case 2500:
	    bw = KBPS_OC48c;
	    break;
	case 622:
	    bw = KBPS_OC12c;
	    break;
#if 0
	case 1000:
	    bw = KBPS_GIGE;
	    break;
	case 100:
	    bw = KBPS_EN100MB;
	    break;
	case 10:
	    bw = KBPS_EN10MB;
	    break;
#endif
	}
    }
#endif

    coral_diag(5, ("coral_optistar_init: %s is configured for %s %s\n",
	src->name, coral_bandwidth_fmt(bw), coral_proto_str(phy)));

    if (src->dev_config.bandwidth <= 0) {
	src->dev_config.bandwidth = bw;
    } else if (src->dev_config.bandwidth != bw) {
	coral_diag(0, ("coral: %s: unsupported bandwidth: %s\n",
	    src->filename, coral_bandwidth_fmt(src->dev_config.bandwidth)));
	goto fail;
    }

    if (src->dev_config.physical == CORAL_PROTO_UNKNOWN) {
	src->dev_config.physical = phy;
    } else if (src->dev_config.physical != phy) {
	coral_diag(0, ("coral: %s: illegal physical type: %s\n",
	    src->name, coral_proto_str(src->dev_config.physical)));
	goto fail;
    }

    if (src->dev_config.datalink == CORAL_PROTO_UNKNOWN) {
	src->dev_config.datalink = datalink;
    } else if (src->dev_config.datalink != datalink) {
	coral_diag(0, ("coral: %s: unsupported datalink: %s\n",
	    src->filename, coral_proto_str(src->dev_config.datalink)));
	goto fail;
    }

#define CORAL_OPTISTAR_MODES        (CORAL_RX)

    if (src->dev_config.iomode.flags & ~CORAL_OPTISTAR_MODES) {
        char iomode_buffer[CORAL_FORMAT_IOMODE_LEN];
        coral_format_iomode(iomode_buffer, &src->dev_config.iomode);
        coral_diag(0, ("%s: unsupported mode: %s\n",
            src->filename, iomode_buffer));
        goto fail;
    }

    if (SnifferMapReceiveBuffers(optistar->AdapterNum, &optistar->Info) < 0) {
	coral_diag(0, ("SnifferMapReceiveBuffers failed\n"));
	goto fail;
    }
    optistar->header0 = optistar->Info.MapAddr;
    src->ubase = optistar->Info.MapAddr;
    optistar->state = AS_WAIT_SEQ_NUMBERS_VALID;

    coral_diag(5, ("MappedAddress %08x\n", optistar->Info.MapAddr));
    coral_diag(5, ("ReceiveBuffers %d\n", optistar->Info.ReceiveBuffers));
    coral_diag(5, ("ReceiveBufferSize %d\n", optistar->Info.RecvBufSize));

    first_n = optistar->Info.RecvBufSize - ts_ctrl_len -
	sizeof(SNIFFER_PACKET_HEADER);
    if (Setup.Clip && first_n > clipsize)
	first_n = clipsize;
    if (src->dev_config.iomode.flags & CORAL_RX_USER_ALL ||
	src->dev_config.iomode.first_n > first_n)
    {
        coral_diag(1, ("warning: %s: can capture only first %d bytes\n",
            src->filename, first_n));
    }
    src->dev_config.iomode.first_n = first_n;
    src->dev_config.iomode.flags &= ~CORAL_RX_USER_ALL;

    iface->iface_info.hw_type	    = CORAL_TYPE_OPTISTAR;
    iface->iface_info.hw_version    = 0;
    iface->iface_info.fw_type       = 0;
    iface->iface_info.fw_version    = 0;
    iface->iface_info.iomode        = src->dev_config.iomode;
    iface->iface_info.capture_time  = 0; /* obsolete */
    iface->iface_info.bandwidth     = bw;
    iface->iface_info.time_is_le    = 0;
    iface->iface_type               = &coral_iface_type_optistar;
    iface->iface_info.datalink      = datalink;
    iface->iface_info.physical      = phy;
    iface->iface_info.tzoff         = 0; /* will be set in coral_start */
    iface->iface_info.capture_tv.tv_sec = 0;     /* set in coral_start */
    iface->iface_info.capture_tv.tv_usec = 0;    /* set in coral_start */

    if (!coral_config.user_polltime && (coral_config.polltime == 0 ||
	coral_config.polltime > OPTISTAR_POLLTIME))
    {
	coral_config.polltime = OPTISTAR_POLLTIME;
    }

    return 0;

fail:
    SnifferShutdown(optistar->AdapterNum);
    free(optistar);
    iface->statedata = NULL;
    return -1;
}

static coral_iface_t *
optistar_read_pkt(coral_iface_t *iface)
{
    OptiStar_t *optistar;

    optistar = iface->statedata;

    iface->pkt_stats.pkts_drop +=
	optistar->header->SeqNum - optistar->ExpectedSeqNum;
    optistar->ExpectedSeqNum = optistar->header->SeqNum + 1;

    iface->packetbuf.buf = (char*)optistar->header +
	sizeof(*optistar->header) + ts_ctrl_len;
    switch (optistar->header->PacketType) {
	case RAW_IP:
	    coral_diag(25, ("optistar_read_pkt: RAW_IP\n"));
	    iface->packetbuf.buf += 14;
	    iface->packetbuf.protocol = CORAL_NETPROTO_RAW_IP;
	    break;
	case RAW_MAC:
	    coral_diag(25, ("optistar_read_pkt: RAW_MAC\n"));
	    iface->packetbuf.buf += 2;
	    iface->packetbuf.protocol = CORAL_DLT_ETHER;
	    break;
	case RAW_POS:
	    coral_diag(25, ("optistar_read_pkt: RAW_POS\n"));
	    iface->packetbuf.protocol = CORAL_DLT_PPPoHDLC;
	    break;
	default:
	    coral_diag(25, ("optistar_read_pkt: unknown protocol\n"));
	    iface->packetbuf.protocol = CORAL_PROTO_UNKNOWN;
	    break;
    }

    iface->pkt_stats.pkts_recv++;
    iface->pkt_stats.ok_packet++;

    iface->packetbuf.caplen = optistar->Info.RecvBufSize - ts_ctrl_len -
	sizeof(SNIFFER_PACKET_HEADER);
    iface->packetbuf.totlen = optistar->header->PacketLength - ts_ctrl_len;
    if (iface->packetbuf.caplen > iface->packetbuf.totlen)
	iface->packetbuf.caplen = iface->packetbuf.totlen;
    iface->packetbuf.is_dynamic = 0;
    iface->packetbuf.passed = 0;

    iface->pkt_result.packet = &iface->packetbuf;
    iface->pkt_result.header = NULL;
    iface->pkt_result.trailer = NULL;
    iface->pkt_result.subiface = 0;
    iface->pkt_result.timestamp =
	(coral_timestamp_t*)&optistar->header->Timestamp;

    coral_set_latest_ts(iface, iface->pkt_result.timestamp);

    iface->synced = iface->period_end.tv_sec >= 0 &&
	timespeccmp(&iface->latest_ts, &iface->period_end, >=);
    if (iface->synced && timestamp_duration_ended(iface, &iface->latest_ts)) {
	iface->have_data = 0;
	errno = 0;
	return NULL;
    }

    iface->have_data = 1;
    optistar->state = AS_NEXT_PACKET;
    return iface;
}

static coral_iface_t *
coral_optistar_read_min(coral_iface_t *iface)
{
    OptiStar_t *optistar;

    iface->have_data = 0;
    if (!(optistar = iface->statedata)) {
	errno = 0;
	return NULL;
    }

    switch (optistar->state) {
    case AS_WAIT_SEQ_NUMBERS_VALID:
	coral_diag(25, ("coral_optistar_read_min: AS_WAIT_SEQ_NUMBERS_VALID\n"));
	/* wait for SequenceNumberingValid in first header */
	if (!optistar->header0->SequenceNumberingValid) {
	    errno = EAGAIN;
	    return NULL;
	}

#if 0
	coral_set_iface_capture_tv(iface, &now, NULL);
#else
	gettimeofday(&iface->iface_info.capture_tv, NULL);
	coral_diag(4, ("%s: set capture time %ld.%06ld\n",
	    iface->src->filename, 
	    iface->iface_info.capture_tv.tv_sec,
	    iface->iface_info.capture_tv.tv_usec));
	set_iface_duration(iface);
#endif

	coral_diag(25, ("coral_optistar_read_min: "
	    "HeadSeqNum=%u, HeadBufNum=%u\n",
	    optistar->header0->HeadBufNum, optistar->header0->HeadSeqNum));
	optistar->header = optistar->Info.MapAddr +
	    optistar->header0->HeadBufNum * optistar->Info.RecvBufSize;
	optistar->ExpectedSeqNum = optistar->header0->HeadSeqNum;
	optistar->state = AS_PACKET_HEADER_VALID;
	/* fall through */

    case AS_PACKET_HEADER_VALID:
    wait_packet_header_valid:
	coral_diag(25, ("coral_optistar_read_min: AS_PACKET_HEADER_VALID\n"));
	/* wait for Valid in current header */
	if (!optistar->header->Valid) {
	    if (!optistar->header->Valid) {
		errno = EAGAIN;
		return NULL;
	    }
	}

	if (optistar->header->SeqNum != optistar->ExpectedSeqNum) {
	    coral_diag(20, ("%s: packet out of sequence; expected %u, got %u\n",
		iface->src->filename, optistar->ExpectedSeqNum,
		optistar->header->SeqNum));
	}

	optistar->state = AS_PROCESS_PACKET;
	return optistar_read_pkt(iface);

    case AS_NEXT_PACKET:
	coral_diag(25, ("coral_optistar_read_min: AS_NEXT_PACKET\n"));
	/* wait for NextBufferNumberValid in current header */
	if (!optistar->header->NextBufferNumberValid) {
	    errno = EAGAIN;
	    return NULL;
	}
	coral_diag(25, ("coral_optistar_read_min: NextBufNum=%u\n",
	    optistar->header0->NextBufNum));
	optistar->header = optistar->Info.MapAddr +
	    optistar->header->NextBufNum * optistar->Info.RecvBufSize;
#if 1 /* MmapTest.c does it this way... */
	optistar->state = AS_PROCESS_PACKET;
	return optistar_read_pkt(iface);
#else /* but docs say to do it this way */
	optistar->state = AS_PACKET_HEADER_VALID;
	goto wait_packet_header_valid;
#endif

    default:
	coral_diag(0,
	    ("coral_optistar_read_min: internal error: invalid state %d\n",
	    optistar->state));
	errno = EINVAL;
	return NULL;
    }
}

static int coral_optistar_stop_close(coral_source_t *src, int final)
{
    int id = src->id[0];
    int result;
    OptiStar_t *optistar;

    if (!(optistar = cinst[id]->statedata))
	return 0;

    coral_mark_eof(cinst[src->id[0]]);
    result = SnifferShutdown(optistar->AdapterNum);
    free(optistar);
    cinst[id]->statedata = NULL;
    return result;
}

#endif /* HAVE_CORAL_OPTISTAR */

const coral_src_type_t coral_src_type_optistar = {
    CORAL_TYPE_OPTISTAR,
    "OptiStar",
#ifdef HAVE_CORAL_OPTISTAR
    1 /* is_live */,
    0 /* is_buffered */,
    0 /* is_block */,
    0 /* is_interleaved */,
    coral_optistar_init,
    NULL /* start */,
    NULL /* read_raw */,
    coral_optistar_read_min,
    coral_optistar_read_min,
    NULL /* nextblk */,
    NULL /* release */,
    coral_optistar_stop_close,
    coral_optistar_stop_close
#endif /* HAVE_CORAL_OPTISTAR */
};
