/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 * coral interface fxns for the point device.
 *
 *  $Id: coral_type_point.c,v 1.79 2007/06/06 18:17:55 kkeys Exp $
 */

#include "config.h"
#include "coraldefs.h"
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <sys/mman.h>

#include "drivers/coral_ioctl.h"
#include "libcoral.h"
#include "libcoral_priv.h"

static const char RCSid[] = "$Id: coral_type_point.c,v 1.79 2007/06/06 18:17:55 kkeys Exp $";

#ifdef HAVE_CORAL_POINT

static int point_download_firmware(int fd, char *buffer, const char *s,
    const char *path);


static int coral_point_init(coral_source_t *src)
{
/* #ifdef HAVE_CORAL_DEVICES */
    int id;
    coral_io_mode_t driver_mode;

    id = src->id[0];

    if (ioctl(src->fd, CORAL_RESET) < 0) {
	coral_diag(0, ("coral: reset: %s: %s\n", src->name, strerror(errno)));
	return -1;
    }

    /* If any src->dev_config fields are still unset, use device defaults. */
    coral_set_dev_config_defaults(&src->dev_config,
        &coral_iface_type_point.default_config);

    if (src->dev_config.physical != CORAL_PHY_ATM) {
	coral_diag(0, ("coral: %s: illegal physical type: %s\n",
	    src->name, coral_proto_str(src->dev_config.physical)));
	goto fail;
    }

    if (src->dev_config.bandwidth > 0 &&
	src->dev_config.bandwidth != cinst[id]->devinfo.bitrate)
    {
	coral_diag(0, ("coral: %s: unsupported bandwidth: %s\n",
	    src->filename, coral_bandwidth_fmt(src->dev_config.bandwidth)));
	goto fail;
    }

    if (point_download_firmware(src->fd, src->ubase, src->filename,
	src->dev_config.firmware) < 0)
    {
	/* coral_diag(0, ("coral: download_firmware", strerror(errno))); */
	goto fail;
    }
    driver_mode.flags = src->dev_config.iomode.flags;
    driver_mode.first_n = divup(src->dev_config.iomode.first_n,
	ATM_PAYLOAD_SIZE);
    if (ioctl(src->fd, CORAL_INIT, &driver_mode) < 0) {
	coral_diag(0, ("coral: failed to initialize card %s\n", src->filename));
	goto fail;
    }

    coral_init_atm_iface(cinst[id]);
    cinst[id]->iface_info.hw_type	= CORAL_TYPE_POINT;
    cinst[id]->iface_info.hw_version	= 0;
    cinst[id]->iface_info.fw_type	= 0;
    cinst[id]->iface_info.fw_version	= 0;
    cinst[id]->iface_info.iomode	= src->dev_config.iomode;
    cinst[id]->iface_info.capture_time	= 0; /* obsolete */
    cinst[id]->iface_info.bandwidth	= cinst[id]->devinfo.bitrate;
    cinst[id]->iface_info.time_is_le	= 1;
    cinst[id]->iface_type		= &coral_iface_type_point;
    cinst[id]->iface_info.datalink	= src->dev_config.datalink;
    cinst[id]->iface_info.physical	= CORAL_PHY_ATM;
    cinst[id]->iface_info.tzoff		= 0; /* will be set in coral_start */
    cinst[id]->iface_info.capture_tv.tv_sec = 0;     /* set in coral_start */
    cinst[id]->iface_info.capture_tv.tv_usec = 0;    /* set in coral_start */

    return 0;

 fail:
/* #endif */
    return -1;
}

static coral_iface_t *coral_point_nextblk(coral_source_t *src,
    coral_blk_info_t **binfop, coral_atm_cell_t **cellp, int endonly)
{
    int idx;
    int op = CORAL_NEXTBLK;
    coral_iface_t *iface;

    if (ioctl(src->fd, op, &idx) < 0) {
	return NULL;
    }
    if (idx < 0) {	/* device is stopped, return EOF indicator */
	errno = 0;
	return NULL;
    }
    iface = cinst[src->id[0]];
    *binfop = BLK_IDX_TO_INFO(idx, src->ubase, iface->devinfo.blk_size,
	iface->devinfo.num_blks);
    *cellp = (coral_atm_cell_t *)BLK_IDX_TO_ADR(idx, src->ubase,
	iface->devinfo.blk_size, iface->devinfo.num_blks);

    return iface;
}


/* #ifdef HAVE_CORAL_DEVICES */
static int point_download_firmware(int fd, char *buffer, const char *s,
    const char *path)
{
    int firmware_fd;
    int fw_len;
    int try = 3, e;

    coral_diag(5, ("coral: loading point firmware (%s)\n", path));

    if (0 > (firmware_fd = open(path, O_RDONLY, 0))) {
	coral_diag(0, ("coral: %s point_download_firmware: open %s: %s\n",
		s, path, strerror(errno)));
	return (-1);
    }
    /* better have mmapped the kmem in by now !
     * yea, this is kinda gross, but the limit of what
     * you can pass in through an ioctl is PAGE_SIZE
     */
    fw_len = read(firmware_fd, &POINT_DL_BYTE(0, buffer), 500000);
    if (fw_len < 0 || fw_len > 500000) {
	coral_diag(0, ("coral: problem reading file %s, (fw_len %d): %s\n", 
		s, fw_len, strerror(errno)));
	close(fd);
	return (-1);
    }

    coral_diag(6, ("coral: debug %x : %x; datalen = %d\n",
	    IOCPARM_LEN(POINT_LOAD_FIRMWARE), POINT_LOAD_FIRMWARE, fw_len));

    e = ioctl(fd, POINT_LOAD_FIRMWARE, &fw_len);
    while (e < 0 && --try > 0) {
	coral_diag(1, ("load (%d) failed (%s), trying again\n",
	    try, strerror(errno)));
	usleep(1000);
        e = ioctl(fd, POINT_LOAD_FIRMWARE, &fw_len);
    }
    if (e < 0) {
	coral_diag(0, ("coral (%s) couldn't load \"%s\" :%s\n", s, path,
		strerror(errno)));
	close(fd);
	return (-1);
    }

    return 0;
}
/* #endif */

#endif /* HAVE_CORAL_POINT */

const coral_src_type_t coral_src_type_point = {
    CORAL_TYPE_POINT,
    "point",
#ifdef HAVE_CORAL_POINT
    1 /* is_live */,
    1 /* is_buffered */,
    1 /* is_block */,
    0 /* is_interleaved */,
    coral_point_init,
    coral_coraldev_start,
    NULL /* read_raw */,
    coral_blk_read_min,
    coral_blk_read_min,
    coral_point_nextblk,
    NULL /* release */,
    coral_coraldev_stop,
    coral_blk_close
#endif /* HAVE_CORAL_POINT */
};

