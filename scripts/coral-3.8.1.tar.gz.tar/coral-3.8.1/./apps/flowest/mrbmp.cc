// Ken Keys, CAIDA
// based on code by cestan@cs.ucsd.edu 10/22/2001

/* Ladies and gentlemen, the world famous multiresolution bitmap! */

#include "config.h"
#include <stdlib.h>
#include <stdio.h>
//#include <cstddef>
#include <string.h>
#include <math.h>
#include <assert.h>

extern "C" {
#include "caida_t.h"
#include "crl_byteorder.h"
}

#include "bitmap.h"
#include "drbmp.h"
#include "mrbmp.h"

const double MultiResBmp_consts[][4] = {
//    rhomin    rhomax    errcoef
    { 1.337200, 2.674400, 0.636679, 0.918534 }, // 2
    { 0.975000, 2.925000, 1.031755, 0.939144 }, // 3
    { 0.785600, 3.142600, 1.346933, 0.971607 }, // 4
    { 0.666000, 3.330100, 1.619871, 1.006483 }, // 5
    { 0.582200, 3.493500, 1.867317, 1.042170 }, // 6
    { 0.519600, 3.637800, 2.097661, 1.077985 }, // 7
    { 0.470800, 3.766400, 2.315428, 1.113485 }, // 8
    { 0.431400, 3.882700, 2.524067, 1.148752 }, // 9
    { 0.398800, 3.988900, 2.725584, 1.183706 }, // 10
    { 0.371400, 4.086100, 2.920732, 1.218040 }, // 11
    { 0.348000, 4.176000, 3.110496, 1.251756 }, // 12
    { 0.327600, 4.259400, 3.296886, 1.285361 }, // 13
    { 0.309800, 4.337200, 3.478870, 1.318224 }, // 14
    { 0.294000, 4.410400, 3.658132, 1.350836 }, // 15
    { 0.279900, 4.479300, 3.834636, 1.383053 }  // 16
};
