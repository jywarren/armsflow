/* 
 * Copyright 1999, 2000, 2001, 2002, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 *
 * $Id: coral_proto.c,v 1.152 2007/06/06 18:17:54 kkeys Exp $
 *
 */

/* When parsing a buffer containing a protocol header, we can not assume the
 * buffer has any particular alignment.  So, while it is ok to cast the buffer
 * like "tcp = (struct tcp *)buf", it is not safe to use multibyte fields in
 * the struct like "seq = ntohl(tcp->th_seq)".  (gcc will warn about the cast,
 * even though it is really the field deref that is the problem.) Instead, we
 * must use the crl_nptoh{s,l} macros like "seq = crl_nptohl(&tcp->th_seq)";
 * these macros are safe to use on unaligned pointers.  A similar problem
 * occurs for bitfields, but there is no nice solution for them; the only
 * solutions are 1) copy the unaligned struct to an aligned struct, or
 * 2) extract the field by its offset (e.g. "ip_v = (uint8_t)ip[0] >> 4").
 */

#include "config.h"
#include "coraldefs.h"
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/time.h>
#include <errno.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/in_systm.h>
#include <netinet/ip.h>
#ifdef HAVE_INET6
# include <netinet/ip6.h>
# ifdef HAVE_NETINET_ICMP6_H
#  include <netinet/icmp6.h>
#  ifndef ICMP6_MEMBERSHIP_QUERY
#    define ICMP6_MEMBERSHIP_QUERY          130
#  endif
#  ifndef ICMP6_MEMBERSHIP_REPORT
#    define ICMP6_MEMBERSHIP_REPORT         131
#  endif
#  ifndef ICMP6_MEMBERSHIP_REDUCTION
#    define ICMP6_MEMBERSHIP_REDUCTION      132
#  endif
# endif
#endif
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <arpa/inet.h>

#include "libcoral.h"
#include "libcoral_priv.h"
#include "ethernet.h"
#include "ip_icmp.h"	/* XXX may not be portable */
#include "coral_lane.h"

/* RFC 3168: Explicit Congestion Notification (ECN) for IP */
#ifndef IPECN_MASK
# define IPECN_MASK 0x03
#endif
#ifndef IPECN_ECT1
# define IPECN_ECT1 0x01
#endif
#ifndef IPECN_ECT0
# define IPECN_ECT0 0x02
#endif
#ifndef IPECN_CE
# define IPECN_CE   0x03
#endif
#ifndef TH_ECE
# define TH_ECE	0x40
#endif
#ifndef TH_CWR
# define TH_CWR	0x80
#endif

/* TCP options */
#ifndef TCPOPT_WINDOW
# define TCPOPT_WINDOW		3	/* RFC 1323 */
#endif
#ifndef TCPOPT_SACK_PERMITTED
# define TCPOPT_SACK_PERMITTED	4	/* RFC 2018 */
#endif
#ifndef TCPOPT_SACK
# define TCPOPT_SACK		5	/* RFC 2018 */
#endif
#ifndef TCPOPT_TIMESTAMP
# define TCPOPT_TIMESTAMP	8	/* RFC 1323 */
#endif

/* PPP protocol numbers.  These are not portably defined in any standard
 * header, so we define them ourselves according to the RFCs.
 */
#define PPP_IP		0x0021
#define PPP_BRIDGED_LAN	0x0031  /* used at AIX */
#define PPP_IPv6	0x0057


static const char RCSid[] = "$Id: coral_proto.c,v 1.152 2007/06/06 18:17:54 kkeys Exp $";

/* stuff that may be missing from some systems' headers */
#if (IPPROTO_IPIP - 0 != 4)
# undef IPPROTO_IPIP
# define IPPROTO_IPIP 4
#endif
#if (IPPROTO_IPV6 - 0 != 41)
# undef IPPROTO_IPV6
# define IPPROTO_IPV6 41
#endif

#ifndef IP_OFFMASK
# define IP_OFFMASK	0x1fff		/* mask for fragmenting bits */
#endif
#ifndef IP_RF
# define IP_RF		0x8000		/* reserved fragment flag */
#endif
/* */

#define NLPID_SNAP	0x80
#define NLPID_IPv6	0x8E
#define NLPID_IP	0xCC
#define NLPID_PPP	0xCF

#define llc_test(llc, val)	X_llc_test(llc, val)
#define X_llc_test(llc, dsap, ssap, cntl) \
    ((llc)->llc_dsap == (dsap) && (llc)->llc_ssap == (ssap) && \
     (llc)->llc_cntl == (cntl))
#define LLC_HAS_SNAP	0xAA, 0xAA, 0x03
#define LLC_ROUTED_ISO	0xFE, 0xFE, 0x03
#define LLC_IEEE8021D	0x42, 0x42, 0x03  /* IEEE 802.1D bridge spanning tree */

#define snap_org_test(org, val)	X_snap_org_test(org, val)
#define X_snap_org_test(org, a, b, c) \
    (((uint8_t*)org)[0] == (a) && ((uint8_t*)org)[1] == (b) && \
	((uint8_t*)org)[2] == (c))
#define OUI_NONE	0x00, 0x00, 0x00
#define OUI_CISCO	0x00, 0x00, 0x0C
#define OUI_ATM_FORUM	0x00, 0xA0, 0x3E

#define LANE_MAX_LEN	(1536-1)

#define fits(ptr, field, len) coral_field_fits(ptr, field, len)

#define initdst(src, dst, skip) \
    do { \
	(dst)->protocol = CORAL_PROTO_UNKNOWN; \
	(dst)->buf = (src)->buf + (skip); \
	(dst)->caplen = (src)->caplen - (skip); \
	(dst)->totlen = (src)->totlen - (skip); \
    } while (0)


static inline coral_protocol_t ethertype_to_coral_proto(uint16_t ethertype)
{
    switch (ethertype) {
	case ETHERTYPE_IP:	    return CORAL_NETPROTO_IPv4;
	case ETHERTYPE_IPv6:	    return CORAL_NETPROTO_IPv6;
	case ETHERTYPE_ARP:	    return CORAL_NETPROTO_ARP;
	case ETHERTYPE_IPX:	    return CORAL_NETPROTO_IPX;
	case ETHERTYPE_APPLETALK:   return CORAL_NETPROTO_APPLETALK;
	case ETHERTYPE_AARP:	    return CORAL_NETPROTO_AARP;
	case ETHERTYPE_IPX_E:	    return CORAL_NETPROTO_IPX_E;
	case ETHERTYPE_PPP:	    return CORAL_DLT_PPP;
	case ETHERTYPE_PPPOES:	    return CORAL_DLT_PPPoES;
	case ETHERTYPE_PPPOED:	    return CORAL_DLT_PPPoED;
	case ETHERTYPE_MPLS:	    return CORAL_DLT_MPLS;
	default:		    return CORAL_PROTO_UNKNOWN;
    }
}

/* format only, no payload */
static int coral_get_atm_payload(const coral_pkt_buffer_t *src,
    coral_pkt_buffer_t *dst, char *dumpbuf, int buflen)
{
    union atm_hdr h = *(union atm_hdr*)src->buf;
    h.ui = ntohl(h.ui);
    crl_snprintf(&dumpbuf, &buflen, "%d:%d",
	get_vpvc_vp(h.h.vpvc), get_vpvc_vc(h.h.vpvc));
    dst->buf = NULL;
    dst->caplen = 0;
    dst->totlen = 0;
    return 0;
}

/* format only, no payload */
static int coral_get_aal5_payload(const coral_pkt_buffer_t *src,
    coral_pkt_buffer_t *dst, char *dumpbuf, int buflen)
{
    aal5_trailer_t *t = (aal5_trailer_t*)src->buf;
    crl_snprintf(&dumpbuf, &buflen, "len=%d", ntohs(t->length));
    dst->buf = NULL;
    dst->caplen = 0;
    dst->totlen = 0;
    return 0;
}

/* IEEE 802.2 (also RFC 1483/2684 LLC Encapsulation, RFC 1042) */
static int coral_get_llc_payload(const coral_pkt_buffer_t *src,
    coral_pkt_buffer_t *dst, char *dumpbuf, int buflen)
{
    coral_llcsnap_t *llc;
    int skip = 3;

    initdst(src, dst, skip);
    if (src->caplen < skip)
	return CORAL_ELENGTH;
    llc = (coral_llcsnap_t *)src->buf;

    if (dumpbuf) {
	crl_snprintf(&dumpbuf, &buflen, "LLC: %02x-%02x-%02x",
	    llc->llc_dsap, llc->llc_ssap, llc->llc_cntl);
    }

    if (llc_test(llc, LLC_HAS_SNAP)) {
	uint16_t ethertype;
	skip += 5; /* size of SNAP */
	initdst(src, dst, skip);

	if (!fits(llc, snap_org[2], src->caplen)) return CORAL_ELENGTH;
	if (dumpbuf) {
	    crl_snprintf(&dumpbuf, &buflen, " SNAP: OUI=%02x-%02x-%02x",
		llc->snap_org[0], llc->snap_org[1], llc->snap_org[2]);
	}
	if (!fits(llc, snap_type, src->caplen)) return CORAL_ELENGTH;
	ethertype = crl_nptohs(&llc->snap_type);
	if (dumpbuf)
	    crl_snprintf(&dumpbuf, &buflen, " type=%04x", ethertype);
	if (snap_org_test(llc->snap_org, OUI_NONE))
	    dst->protocol = ethertype_to_coral_proto(ethertype);

    } else if (llc_test(llc, LLC_ROUTED_ISO)) {
	uint8_t nlpid;
	nlpid = *(src->buf + skip);
	skip += 1; /* size of NLPID */
	initdst(src, dst, skip);
	if (src->caplen < skip) return CORAL_ELENGTH;

	switch (nlpid) {
	case NLPID_PPP:		/* RFC 2364: PPP over AAL5 */
	    dst->protocol = CORAL_DLT_PPP; break;
	case NLPID_IP:		/* shouldn't be used with ATM_RFC1483 */
	    dst->protocol = CORAL_NETPROTO_IPv4; break;
	case NLPID_IPv6:	/* shouldn't be used with ATM_RFC1483 */
	    dst->protocol = CORAL_NETPROTO_IPv6; break;
	default:
	    dst->protocol = CORAL_PROTO_UNKNOWN;
	}

    } else if (llc_test(llc, LLC_IEEE8021D)) {
	dst->protocol = CORAL_DLT_IEEE8021D;
    }

    return 0;
}

struct chdlc_header {
    uint8_t id;		/* 0f=unicast, 8f=broadcast */
    uint8_t control;	/* always 0 */
    uint16_t ethertype;	/* Ethernet type of the SDU */
};

/* Cisco encapsulation over HDLC, RFC 1547 section 4.3.1 */
static int coral_get_chdlc_payload(const coral_pkt_buffer_t *src,
    coral_pkt_buffer_t *dst, char *dumpbuf, int buflen)
{
    struct chdlc_header *head;
    int skip = sizeof(struct chdlc_header);
    uint16_t ethertype;

    initdst(src, dst, skip);

    head = (struct chdlc_header*)src->buf;
    if (!fits(head, id, src->caplen)) return CORAL_ELENGTH;

    if (dumpbuf) {
	if      (head->id == 0x0f) crl_snprintf(&dumpbuf, &buflen, "unicast");
	else if (head->id == 0x8f) crl_snprintf(&dumpbuf, &buflen, "broadcast");
	else crl_snprintf(&dumpbuf, &buflen, "id=%02x", head->id);
    }

    if (!fits(head, ethertype, src->caplen)) return CORAL_ELENGTH;
    ethertype = crl_nptohs(&head->ethertype);
    dst->protocol = ethertype_to_coral_proto(ethertype);
    if (dumpbuf) crl_snprintf(&dumpbuf, &buflen, ", type=%04x", ethertype);
    return 0;
}

/* Multiprotocol over Frame Relay - RFC 1490, 2427  */
/* Note: this was found in NLANR traces taken at University of Florida;
 * see http://pma.nlanr.net/PMA/Sites/UFL.html */
static int coral_get_mpofr_payload(const coral_pkt_buffer_t *src,
    coral_pkt_buffer_t *dst, char *dumpbuf, int buflen)
{
    uint8_t nlpid;

    if (src->caplen < 4) return CORAL_ELENGTH;

    if (src->buf[2] != 0x03)
	return CORAL_ESYNTAX;

    if (src->buf[3] == 0) { /* padding octet */
	if (src->caplen < 5) return CORAL_ELENGTH;
	initdst(src, dst, 5);
	nlpid = src->buf[4];
    } else {
	initdst(src, dst, 4);
	nlpid = src->buf[3];
    }

    switch (nlpid) {
    case NLPID_IP:
	dst->protocol = CORAL_NETPROTO_IPv4; break;
    case NLPID_IPv6:
	dst->protocol = CORAL_NETPROTO_IPv6; break;
    case NLPID_PPP:
	dst->protocol = CORAL_DLT_PPP; break; /* untested */
    /* TODO: NLPID_SNAP */
    default:
	dst->protocol = CORAL_PROTO_UNKNOWN;
    }

    if (dumpbuf) {
	uint16_t dlci =
	    (((uint8_t)src->buf[0] & 0xfc) << 2) |
	    (((uint8_t)src->buf[1] & 0xf0) >> 4);
	crl_snprintf(&dumpbuf, &buflen, "dlci=%u, ctrl=%02x, nlpid=%02x",
	    dlci, (uint8_t)src->buf[2], nlpid);
    }
    return 0;
}

/* Unknown protocol over PoS - we attempt to identify it as CHDLC or MPoFR */
static int coral_get_uopos_payload(const coral_pkt_buffer_t *src,
    coral_pkt_buffer_t *dst, char *dumpbuf, int buflen)
{
    struct chdlc_header *chdlc;

    if (src->caplen < 4) return CORAL_ELENGTH;

    chdlc = (struct chdlc_header*)src->buf;
    if ((chdlc->id == 0x0f || chdlc->id == 0x8f) && chdlc->control == 0) {
	if (dumpbuf)
	    crl_snprintf(&dumpbuf, &buflen, "%s: ",
		coral_proto_str(CORAL_DLT_CHDLC));
	return coral_get_chdlc_payload(src, dst, dumpbuf, buflen);
    } else if (src->buf[2] == 0x03) {
	if (dumpbuf)
	    crl_snprintf(&dumpbuf, &buflen, "%s: ",
		coral_proto_str(CORAL_DLT_MPoFR));
	return coral_get_mpofr_payload(src, dst, dumpbuf, buflen);
    } else {
	return CORAL_ESYNTAX;
    }
}

#ifndef NDEBUG /* hack - developer only */
/* FDDI */
static int coral_get_fddi_payload(const coral_pkt_buffer_t *src,
    coral_pkt_buffer_t *dst, char *dumpbuf, int buflen)
{
    dst->buf = src->buf + 16;
    dst->caplen = src->caplen - 16;
    dst->totlen = src->totlen - 16;
    dst->protocol = CORAL_DLT_ATM_RFC1483;
    return 0;
}
#endif

/* PPP Bridged LAN (RFC 1638, section 4.2) */
static int coral_get_bridgedlan_payload(const coral_pkt_buffer_t *src,
    coral_pkt_buffer_t *dst, char *dumpbuf, int buflen)
{
    int skip = 2;

    struct blan_header {
#if WORDS_BIGENDIAN
	unsigned fcs_present:1;
	unsigned lanid_present:1;
	unsigned zero_filled:1;
	unsigned zero:1;
	unsigned pads:4;
#else
	unsigned pads:4;
	unsigned zero:1;
	unsigned zero_filled:1;
	unsigned lanid_present:1;
	unsigned fcs_present:1;
#endif
	uint8_t mac_type;
    } *blan;

    initdst(src, dst, skip);
    blan = (struct blan_header*)src->buf;
    if (!fits(blan, mac_type, src->caplen)) return CORAL_ELENGTH;

    if (dumpbuf)
	crl_snprintf(&dumpbuf, &buflen, "mac type %02x", blan->mac_type);
    if (blan->lanid_present) {
	if (dumpbuf) {
	    const uint8_t *lanid = (uint8_t*)dst->buf;
	    crl_snprintf(&dumpbuf, &buflen, ", lan id %02x%02x%02x%02x",
		lanid[0], lanid[1], lanid[2], lanid[3]);
	}
	skip += 4;
	initdst(src, dst, skip);
    }

    switch (blan->mac_type) {
    case 1:	/* IEEE 802.3/Ethernet with canonical addresses */
	dst->protocol = CORAL_DLT_IEEE802;  return 0;
    case 2:	/* IEEE 802.4 with canonical addresses */
    case 3:	/* IEEE 802.5 with noncanonical addresses */
    case 4:	/* FDDI with noncanonical addresses */
    case 10:	/* IEEE 802.5 with canonical addresses */
    case 11:	/* FDDI with canonical addresses */
	return 0;
    default:	/* illegal value */
	return CORAL_ESYNTAX;
    }
}

/* Point-to-Point Protocol (RFC 1661) */
static int coral_get_ppp_payload(const coral_pkt_buffer_t *src,
    coral_pkt_buffer_t *dst, char *dumpbuf, int buflen)
{
    uint16_t pppproto;
    int skip = 1;

    initdst(src, dst, skip);
    if (src->caplen < 1) {
	return CORAL_ELENGTH;
    } else if (src->buf[0] & 1) {
	/* first byte is odd; proto is 1 byte (Protocol-Field-Compression). */
	pppproto = *(uint8_t*)src->buf;
	skip = 1;
    } else if (src->caplen < 2) {
	return CORAL_ELENGTH;
    } else if (src->buf[1] & 1) {
	/* first byte is even, second is odd; protocol is 2 bytes. */
	pppproto = crl_nptohs(src->buf);
	skip = 2;
	initdst(src, dst, skip);
    } else {
	/* illegal */
	return CORAL_ESYNTAX;
    }

    if (dumpbuf)
	crl_snprintf(&dumpbuf, &buflen, "proto %04" PRIx16, pppproto);

    switch (pppproto) {
	case PPP_IP:		dst->protocol = CORAL_NETPROTO_IPv4;	break;
	case PPP_IPv6:		dst->protocol = CORAL_NETPROTO_IPv6;	break;
	case PPP_BRIDGED_LAN:	dst->protocol = CORAL_DLT_BRIDGED_LAN;	break;
	default:		dst->protocol = CORAL_PROTO_UNKNOWN;	break;
    }

    return 0;
}

/* PPP in HDLC-like framing (RFC 1662) */
static int coral_get_pppohdlc_payload(const coral_pkt_buffer_t *src,
    coral_pkt_buffer_t *dst, char *dumpbuf, int buflen)
{
    coral_pkt_buffer_t tmp;
    uint8_t addr, ctrl;

    initdst(src, dst, 2);
    if (src->caplen < 2) return CORAL_ELENGTH;
    addr = src->buf[0];
    ctrl = src->buf[1];
    tmp.protocol = CORAL_DLT_PPP;

    if (addr == 0xff && ctrl == 0x03) {
	/* normal frame */
	if (dumpbuf)
	    crl_snprintf(&dumpbuf, &buflen, "addr %02x, ctrl %02x, ",
		addr, ctrl);
	tmp.buf = src->buf + 2;
	tmp.caplen = src->caplen - 2;
	tmp.totlen = src->totlen - 2;
	return coral_get_ppp_payload(&tmp, dst, dumpbuf, buflen);
    } else {
	/* Address-and-Control-Field-Compression */
	return coral_get_ppp_payload(src, dst, dumpbuf, buflen);
    }
}

/* PPP over Ethernet (RFC 2516) */
static int coral_get_pppoe_payload(const coral_pkt_buffer_t *src,
    coral_pkt_buffer_t *dst, char *dumpbuf, int buflen)
{
    struct pppoe_header {
#if WORDS_BIGENDIAN
	unsigned ver:4;
	unsigned type:4;
#else
	unsigned type:4;
	unsigned ver:4;
#endif
	uint8_t code;
	uint16_t session_id;
	uint16_t length;
    } *pppoe;
    int skip = sizeof(*pppoe);
    uint16_t len;

    initdst(src, dst, skip);
    if (src->caplen < skip) return CORAL_ELENGTH;
    pppoe = (struct pppoe_header*)src->buf;
    if (dumpbuf)
	crl_snprintf(&dumpbuf, &buflen, "ver=%01x type=%01x code=%02x ",
	    pppoe->ver, pppoe->type, pppoe->code);
    if (pppoe->ver != 1 || pppoe->type != 1 || pppoe->code != 0)
	return CORAL_ESYNTAX;
    len = crl_nptohs(&pppoe->length);
    if (dumpbuf)
	crl_snprintf(&dumpbuf, &buflen, "session_id=%04x len=%d",
	    crl_nptohs(&pppoe->session_id), len);
    if (dst->caplen > len)
	dst->caplen = len;
    if (dst->totlen > len)
	dst->totlen = len;
    return 0;
}

static int coral_get_pppoe_sess_payload(const coral_pkt_buffer_t *src,
    coral_pkt_buffer_t *dst, char *dumpbuf, int buflen)
{
    int result;
    if ((result = coral_get_pppoe_payload(src, dst, dumpbuf, buflen)) < 0)
	return result;
    dst->protocol = CORAL_DLT_PPP;
    return 0;
}

static int coral_get_pppoe_disc_payload(const coral_pkt_buffer_t *src,
    coral_pkt_buffer_t *dst, char *dumpbuf, int buflen)
{
    return coral_get_pppoe_payload(src, dst, dumpbuf, buflen);
}

/* ATM Forum NSAPA format */
static inline int format_nsap_addr(char **buf, int *len,
    const unsigned char *addr)
{
    return crl_snprintf(buf, len,
	"%02X.%02X%02X.%02X.%02X%02X%02X."
	"%02X%02X.%02X%02X.%02X%02X.%02X%02X.%02X%02X.%02X%02X.%02X",
	addr[0], addr[1], addr[2], addr[3],
	addr[4], addr[5], addr[6], addr[7],
	addr[8], addr[9], addr[10], addr[11],
	addr[12], addr[13], addr[14], addr[15],
	addr[16], addr[17], addr[18], addr[19],
	addr[20], addr[21], addr[22], addr[23],
	addr[24], addr[25], addr[26], addr[27],
	addr[28], addr[29], addr[30], addr[31],
	addr[32], addr[33], addr[34], addr[35],
	addr[36], addr[37], addr[38], addr[39]);
}

/* Ethernet */
static inline int format_ether_addr(char **buf, int *len,
    const unsigned char *ether_addr)
{
    /* ftp://ftp.isi.edu/in-notes/iana/assignments/ethernet-numbers */
    return crl_snprintf(buf, len, "%02X-%02X-%02X-%02X-%02X-%02X",
	ether_addr[0], ether_addr[1], ether_addr[2],
	ether_addr[3], ether_addr[4], ether_addr[5]);
}

/* Ethernet */
static inline int format_ether_addrs(char **buf, int *len,
    struct ether_header *ether_hdr, int hdrlen)
{
    if (hdrlen < 6) return 0;
    if (crl_snprintf(buf, len, "dst=") < 0) return -1;
    if (format_ether_addr(buf, len, ether_hdr->ether_dhost) < 0) return -1;
    if (crl_snprintf(buf, len, " ") < 0) return -1;
    if (hdrlen < 12) return 0;
    if (crl_snprintf(buf, len, "src=") < 0) return -1;
    if (format_ether_addr(buf, len, ether_hdr->ether_shost) < 0) return -1;
    if (crl_snprintf(buf, len, " ") < 0) return -1;
    return 0;
}

/* IEEE 802.3 or DIX Ethernet */
static int coral_get_ieee8023_or_ether_payload(const coral_pkt_buffer_t *src,
    coral_pkt_buffer_t *dst, char *dumpbuf, int buflen, int maxlen)
{
    struct ether_header *ether_hdr;
    uint16_t typelen;
    coral_pkt_buffer_t tmp;

    initdst(src, dst, sizeof(*ether_hdr));
    ether_hdr = (struct ether_header*)src->buf;
    if (dumpbuf)
	format_ether_addrs(&dumpbuf, &buflen, ether_hdr, src->caplen);

    if (!fits(ether_hdr, ether_type, src->caplen)) return CORAL_ELENGTH;

    typelen = crl_nptohs(&ether_hdr->ether_type);

    if (typelen > maxlen) {
	/* Ethernet */
	if (typelen == ETHERTYPE_VLAN) {
	    /* IEEE 802.1Q VLAN */
	    uint16_t tci; /* tag control information */
	    uint32_t vlan_id = 0;
	    uint8_t cfi = 0, pri = 0;
	    const char *p = src->buf + sizeof(*ether_hdr);
	    initdst(src, dst, sizeof(*ether_hdr) + 4);

	    if (dumpbuf)
		crl_snprintf(&dumpbuf, &buflen, "VLAN ");
	    if (src->caplen < sizeof(*ether_hdr) + 2) return CORAL_ELENGTH;
	    tci = crl_nptohs(p);
	    cfi = (tci >> 12) & 0x0001;
	    pri = (tci >> 13) & 0x0003;
	    vlan_id = tci & 0x0FFF;
	    if (dumpbuf) {
		crl_snprintf(&dumpbuf, &buflen, "%u ", vlan_id);
		if (pri) crl_snprintf(&dumpbuf, &buflen, "pri=%u ", pri);
		if (cfi) crl_snprintf(&dumpbuf, &buflen, "cfi=%u ", cfi);
	    }
	    if (src->caplen < sizeof(*ether_hdr) + 4) return CORAL_ELENGTH;
	    typelen = crl_nptohs(p+2);
	    dst->protocol = cfi ? CORAL_PROTO_UNKNOWN :
		ethertype_to_coral_proto(typelen);

	} else {
	    dst->protocol = ethertype_to_coral_proto(typelen);
	}

	if (dumpbuf)
	    crl_snprintf(&dumpbuf, &buflen, "type=%04x", typelen);

	return 0;

    } else {
	/* IEEE 802.3 */
	if (dumpbuf)
	    crl_snprintf(&dumpbuf, &buflen, "len=%u", typelen);

	tmp.buf = src->buf + sizeof(*ether_hdr);
	tmp.caplen = src->caplen - sizeof(*ether_hdr);

	if (src->totlen < 0) {
	    if (typelen == 0) /* shouldn't happen in 802.3, can in LANE */
		tmp.totlen = -1;
	    else
		tmp.totlen = typelen;
	} else {
	    tmp.totlen = src->totlen - sizeof(*ether_hdr);
	    if (typelen == 0) {
		/* shouldn't happen in 802.3, can in LANE */
	    } else if (typelen > tmp.totlen) {
		return CORAL_ESYNTAX; /* impossible */
	    } else if (tmp.totlen > typelen) { /* totlen may include padding */
		tmp.totlen = typelen;
	    }
	}

	if (typelen && tmp.caplen > typelen)   /* caplen may include padding */
	    tmp.caplen = typelen;
	if (dumpbuf)
	    crl_snprintf(&dumpbuf, &buflen, ", ");
	return coral_get_llc_payload(&tmp, dst, dumpbuf, buflen);
    }
}

/* RFC 3032 */
static int coral_get_mpls_payload(const coral_pkt_buffer_t *src,
    coral_pkt_buffer_t *dst, char *dumpbuf, int buflen)
{
    struct mpls_entry {
	union {
	    uint32_t i;
	    struct {
#if WORDS_BIGENDIAN
		unsigned label:20;
		unsigned reserved:3;
		unsigned bottom:1;
		unsigned ttl:8;
#else
		unsigned ttl:8;
		unsigned bottom:1;
		unsigned reserved:3;
		unsigned label:20;
#endif
	    } e;
	} u;
    } entry;

    initdst(src, dst, sizeof(entry));

    if (src->caplen < sizeof(entry)) return CORAL_ELENGTH;
    entry.u.i = crl_nptohl(src->buf);
    if (dumpbuf)
	crl_snprintf(&dumpbuf, &buflen, "label=%05x, exp=%d, TTL=%d ",
	    entry.u.e.label, entry.u.e.reserved, entry.u.e.ttl);

    if (!entry.u.e.bottom) {
	dst->protocol = CORAL_DLT_MPLS;
    } else {
	switch (entry.u.e.label) {
	case 0:
	    dst->protocol = CORAL_NETPROTO_IPv4;
	    break;
	case 2:
	    dst->protocol = CORAL_NETPROTO_IPv6;
	    break;
	default:
	    /* hack - see if payload looks like IPv4 or IPv6 */
	    if (dst->caplen >= 1) {
		if (dst->buf[0] >= 0x45 && dst->buf[0] <= 0x4F)
		    dst->protocol = CORAL_NETPROTO_IPv4;
		else if (dst->buf[0] >> 4 == 6)
		    dst->protocol = CORAL_NETPROTO_IPv6;
	    }
	    break;
	}
    }
    return 0;
}

/* af-lane-0084.000 */
static int coral_get_lane_ieee8023_payload(const coral_pkt_buffer_t *src,
    coral_pkt_buffer_t *dst, char *dumpbuf, int buflen)
{
    lane_ieee8023_t *lane;
    coral_pkt_buffer_t tmp;

    initdst(src, dst, sizeof(*lane));
    lane = (lane_ieee8023_t *)src->buf;
    if (!fits(lane, le_header, src->caplen)) return CORAL_ELENGTH;
    tmp.buf = src->buf + sizeof(lane->le_header);
    tmp.caplen = src->caplen - sizeof(lane->le_header);
    tmp.totlen = src->totlen - sizeof(lane->le_header);
    if (dumpbuf)
	crl_snprintf(&dumpbuf, &buflen, "lecid=%04x ",
	    crl_nptohs(&lane->le_header));
    return coral_get_ieee8023_or_ether_payload(&tmp, dst, dumpbuf, buflen,
	LANE_MAX_LEN);
}

/* af-lane-0084.000 */
static int coral_get_lane_llc_payload(const coral_pkt_buffer_t *src,
    coral_pkt_buffer_t *dst, char *dumpbuf, int buflen)
{
    lane_llc_t *lane;
    int skip = sizeof(lane_llc_t);
    coral_pkt_buffer_t tmp;

    initdst(src, dst, skip);
    if (src->caplen < skip) return CORAL_ELENGTH;
    lane = (lane_llc_t *)src->buf;
    if (!llc_test(&lane->llc, LLC_HAS_SNAP) ||
	!snap_org_test(lane->llc.snap_org, OUI_ATM_FORUM))
    {
	return CORAL_ESYNTAX;
    }
    initdst(src, &tmp, skip);

    switch (crl_nptohs(&lane->llc.snap_type)) {
	case LANETYPE_IEEE8023:
	    return coral_get_lane_ieee8023_payload(&tmp, dst, dumpbuf, buflen);
	case LANETYPE_IEEE8025:
#if 0	    /* not implemented */
	    return coral_get_lane_ieee8025_payload(&tmp, dst, dumpbuf, buflen);
#else
	    *dst = tmp;
	    dst->protocol = CORAL_DLT_LANE_IEEE8025;
	    return 0;
#endif
	default:
	    return CORAL_ESYNTAX;
    }
}

/* DEC Gigaswitch encapsulation?
 * All I know about this is that it seems to have a 16 byte header, a 4 byte
 * trailer, and (at least in the limited samples I've seen) always contains
 * ATM_RFC1483.
 */
static int coral_get_gigx_payload(const coral_pkt_buffer_t *src,
    coral_pkt_buffer_t *dst, char *dumpbuf, int buflen)
{
    int skip = 16;
    coral_pkt_buffer_t tmp;

    tmp.buf = src->buf + skip;
    tmp.totlen = src->totlen - skip - 4;
    tmp.caplen = src->caplen - skip;
    if (tmp.totlen >= 0 && tmp.caplen > tmp.totlen)
	tmp.caplen = tmp.totlen;

    return coral_get_llc_payload(&tmp, dst, dumpbuf, buflen);
}


/* prints a full or partial IPv4 address into *dumpbuf, and modifies dumpbuf
 * and buflen.  addr does not need to be aligned. */
static int coral_fmt_in_addr(char **dumpbuf, int *buflen,
    const void *addr, uint32_t len)
{
    switch (len) {
    case 1:
	return crl_snprintf(dumpbuf, buflen, "%d.?.?.?", ((uint8_t*)addr)[0]);
    case 2:
	return crl_snprintf(dumpbuf, buflen, "%d.%d.?.?", ((uint8_t*)addr)[0],
	    ((uint8_t*)addr)[1]);
    case 3:
	return crl_snprintf(dumpbuf, buflen, "%d.%d.%d.?", ((uint8_t*)addr)[0],
	    ((uint8_t*)addr)[1], ((uint8_t*)addr)[2]);
    default:
	return crl_snprintf(dumpbuf, buflen, "%d.%d.%d.%d", ((uint8_t*)addr)[0],
	    ((uint8_t*)addr)[1], ((uint8_t*)addr)[2], ((uint8_t*)addr)[3]);
    }
}

static void coral_fmt_pro_addr(char **dumpbuf, int *buflen, uint16_t pro,
    const void *addr, uint8_t len)
{
    switch (pro) {
    case ETHERTYPE_IP:
      {
	coral_fmt_in_addr(dumpbuf, buflen, addr, len);
	break;
      }
#ifdef HAVE_INET6
    case ETHERTYPE_IPv6:
      {
	struct in6_addr in6_addr;
	char addrbuf[INET6_ADDRSTRLEN+1];
	memcpy(&in6_addr, addr, sizeof(in6_addr));
	crl_snprintf(dumpbuf, buflen, "%s",
	    inet_ntop(AF_INET6, (char*)&in6_addr, addrbuf, INET6_ADDRSTRLEN));
	break;
      }
#endif
    default:
      {
        int i;
	crl_snprintf(dumpbuf, buflen, "%04x ", pro);
	for (i = 0; i < len; i++)
	    crl_snprintf(dumpbuf, buflen, "%02x", ((unsigned char*)addr)[i]);
	break;
      }
    }
}

/* http://www.iana.org/assignments/arp-parameters */
#define ARPHRD_ETHER	 1	/* RFC 826 */
#define ARPHRD_IEEE802	 6
#define ARPHRD_FRELAY	15
/*#define ARPHRD_ATM	16*/
#define ARPHRD_ATM	19	/* RFC 2225 */
/*#define ARPHRD_ATM	21*/

#define ATMARP_LEN_MASK 0x3F
#define ATMARP_TYPE_MASK 0x40

/* RFC 826 */
static int coral_get_arp_payload(const coral_pkt_buffer_t *src,
    coral_pkt_buffer_t *dst, char *dumpbuf, int buflen)
{
    uint16_t op = 0, hrd = 0, pro = 0;
    int i;
    const unsigned char *p;
    coral_protocol_t coral_proto = CORAL_PROTO_UNKNOWN;
    char proto_name_buf[5];
    const char *proto_name = "?";
    struct genericarp {
	uint16_t hrd; /* hardware addr space */
	uint16_t pro; /* protocol addr space */
	uint8_t c0;
	uint8_t c1;
	uint16_t op; /* opcode */
    } *genericarp = (struct genericarp*)src->buf;

    dst->protocol = CORAL_PROTO_UNKNOWN;
    dst->caplen = 0;
    dst->totlen = 0;
    dst->buf = NULL;

    if (!dumpbuf) return 0;

    if (!fits(genericarp, hrd, src->caplen))
	return CORAL_ELENGTH;
    hrd = crl_nptohs(&genericarp->hrd);

    if (fits(genericarp, pro, src->caplen)) {
	pro = crl_nptohs(&genericarp->pro);
	coral_proto = ethertype_to_coral_proto(pro);
	if (coral_proto == CORAL_PROTO_UNKNOWN ||
	    !(proto_name = coral_proto_abbr(coral_proto)))
	{
	    proto_name = proto_name_buf;
	    sprintf(proto_name_buf, "%04x", pro);
	}
    }

    if (fits(genericarp, op, src->caplen)) {
	op = crl_nptohs(&genericarp->op);
	/* http://www.iana.org/assignments/arp-parameters */
	switch (op) {						      /* RFC */
	case 1: crl_snprintf(&dumpbuf, &buflen, "Request ");   break; /* 826 */
	case 2: crl_snprintf(&dumpbuf, &buflen, "Reply ");     break; /* 826 */
	case 8: crl_snprintf(&dumpbuf, &buflen, "InRequest "); break; /* 1293 */
	case 9: crl_snprintf(&dumpbuf, &buflen, "InReply ");   break; /* 1293 */
	case 10: crl_snprintf(&dumpbuf, &buflen, "NAK ");      break; /* 2225 */
	default: crl_snprintf(&dumpbuf, &buflen, "op=%d ", op); break;
	}
    }

    switch (hrd) {
    case ARPHRD_ETHER: /* RFC 826, 1293 */
    case ARPHRD_IEEE802:
      {
	struct etherarp {
	    uint16_t hrd; /* hardware addr space */
	    uint16_t pro; /* protocol addr space */
	    uint8_t hln; /* hardware addr len */
	    uint8_t pln; /* protocol addr len */
	    uint16_t op; /* opcode */
	    /* source ethernet addr */
	    /* source protocol addr */
	    /* target ethernet addr */
	    /* target protocol addr */
	} *arp;

	arp = (struct etherarp*)genericarp;
	crl_snprintf(&dumpbuf, &buflen, "ETHER/%s ", proto_name);
	if (!fits(genericarp, pro, src->caplen)) return CORAL_ELENGTH;

	p = (const unsigned char *)src->buf + sizeof(struct etherarp);

	/* source hardware address */
	if ((const char *)p + arp->hln > src->buf + src->caplen)
	    return CORAL_ELENGTH;
	crl_snprintf(&dumpbuf, &buflen, "from ");
	format_ether_addr(&dumpbuf, &buflen, p);
	p += arp->hln;
	crl_snprintf(&dumpbuf, &buflen, " ");
	/* source protocol address */
	if ((const char *)p + arp->pln > src->buf + src->caplen)
	    return CORAL_ELENGTH;
	coral_fmt_pro_addr(&dumpbuf, &buflen, pro, p, arp->pln);
	p += arp->pln;

	/* target hardware address */
	if ((const char *)p + arp->hln > src->buf + src->caplen)
	    return CORAL_ELENGTH;
	crl_snprintf(&dumpbuf, &buflen, " to ");
	format_ether_addr(&dumpbuf, &buflen, p);
	p += arp->hln;
	crl_snprintf(&dumpbuf, &buflen, " ");
	/* target protocol address */
	if ((const char *)p + arp->pln > src->buf + src->caplen)
	    return CORAL_ELENGTH;
	coral_fmt_pro_addr(&dumpbuf, &buflen, pro, p, arp->pln);
	p += arp->pln;

	break;
      }
    
    case ARPHRD_ATM: /* RFC 2225 */
      {
	struct atmarp {
	    uint16_t hrd; /* hardware addr space */
	    uint16_t pro; /* protocol addr space */
	    uint8_t shtl; /* source ATM addr len */
	    uint8_t sstl; /* source ATM subaddr len */
	    uint16_t op; /* opcode */
	    uint8_t spln; /* source protocol addr len */
	    uint8_t thtl; /* target ATM addr len */
	    uint8_t tstl; /* target ATM subaddr len */
	    uint8_t tpln; /* target protocol addr len */
	    /* source ATM addr */
	    /* source ATM subaddr */
	    /* source protocol addr */
	    /* target ATM addr */
	    /* target ATM subaddr */
	    /* target protocol addr */
	} *arp;

	arp = (struct atmarp*)genericarp;
	crl_snprintf(&dumpbuf, &buflen, "ATM/%s ", proto_name);
	if (!fits(genericarp, pro, src->caplen)) return CORAL_ELENGTH;

#if 0 /* debugging */
	crl_snprintf(&dumpbuf, &buflen, "shtl=%d ", arp->shtl);
	crl_snprintf(&dumpbuf, &buflen, "sstl=%d ", arp->sstl);
	crl_snprintf(&dumpbuf, &buflen, "spln=%d ", arp->spln);
	crl_snprintf(&dumpbuf, &buflen, "thtl=%d ", arp->thtl);
	crl_snprintf(&dumpbuf, &buflen, "tstl=%d ", arp->tstl);
	crl_snprintf(&dumpbuf, &buflen, "tpln=%d ", arp->tpln);
#endif

	p = (const unsigned char *)src->buf + sizeof(struct atmarp);

	/* source hardware address */
	if ((const char *)p + arp->shtl > src->buf + src->caplen)
	    return CORAL_ELENGTH;
	crl_snprintf(&dumpbuf, &buflen, "from ");
	if (arp->shtl & ATMARP_LEN_MASK) {
	    if (!(arp->shtl & ATMARP_TYPE_MASK)) {
		format_nsap_addr(&dumpbuf, &buflen, p);
		p += arp->shtl & ATMARP_LEN_MASK;
	    } else {
		for (i = 0; i < (arp->shtl & ATMARP_LEN_MASK); i++, p++)
		    crl_snprintf(&dumpbuf, &buflen, "%02x", *p);
	    }
	    /* source hardware subaddress */
	    if ((const char *)p + arp->sstl > src->buf + src->caplen)
		return CORAL_ELENGTH;
	    if (arp->sstl & ATMARP_LEN_MASK) {
		crl_snprintf(&dumpbuf, &buflen, "[");
		for (i = 0; i < (arp->sstl & ATMARP_LEN_MASK); i++, p++)
		    crl_snprintf(&dumpbuf, &buflen, "%02x", *p);
		crl_snprintf(&dumpbuf, &buflen, "]");
	    }
	    crl_snprintf(&dumpbuf, &buflen, " ");
	}
	/* source protocol address */
	if ((const char *)p + arp->spln > src->buf + src->caplen)
	    return CORAL_ELENGTH;
	if (arp->spln) {
	    coral_fmt_pro_addr(&dumpbuf, &buflen, pro, p, arp->spln);
	    p += arp->spln;
	    crl_snprintf(&dumpbuf, &buflen, " ");
	}

	/* target hardware address */
	if ((const char *)p + arp->thtl > src->buf + src->caplen)
	    return CORAL_ELENGTH;
	crl_snprintf(&dumpbuf, &buflen, "to ");
	if (arp->thtl & ATMARP_LEN_MASK) {
	    if (!(arp->thtl & ATMARP_TYPE_MASK)) {
		format_nsap_addr(&dumpbuf, &buflen, p);
		p += arp->thtl & ATMARP_LEN_MASK;
	    } else {
		for (i = 0; i < (arp->thtl & ATMARP_LEN_MASK); i++, p++)
		    crl_snprintf(&dumpbuf, &buflen, "%02x", *p);
	    }
	    /* target hardware subaddress */
	    if ((const char *)p + arp->tstl > src->buf + src->caplen)
		return CORAL_ELENGTH;
	    if (arp->tstl & ATMARP_LEN_MASK) {
		crl_snprintf(&dumpbuf, &buflen, "[");
		for (i = 0; i < (arp->tstl & ATMARP_LEN_MASK); i++, p++)
		    crl_snprintf(&dumpbuf, &buflen, "%02x", *p);
		crl_snprintf(&dumpbuf, &buflen, "]");
	    }
	    crl_snprintf(&dumpbuf, &buflen, " ");
	}
	/* target protocol address */
	if ((const char *)p + arp->tpln > src->buf + src->caplen)
	    return CORAL_ELENGTH;
	if (arp->tpln) {
	    coral_fmt_pro_addr(&dumpbuf, &buflen, pro, p, arp->tpln);
	    p += arp->tpln;
	}
	break;
      }

    default:
	crl_snprintf(&dumpbuf, &buflen, "%04x/%s ", hrd, proto_name);
	if (!fits(genericarp, pro, src->caplen)) return CORAL_ELENGTH;
	break;
    }

    return 0;
}

/* RFC 791 */
static int coral_get_ip4_payload(const coral_pkt_buffer_t *src,
    coral_pkt_buffer_t *dst, char *dumpbuf, int buflen)
{
    struct ip *ip;
    int i, hdr_len;
    uint16_t ip_len, ip_off;
    uint8_t *opt, len, ip_hl, ip_v;

    initdst(src, dst, sizeof(*ip));
    if (src->caplen < 1) return CORAL_ELENGTH;
    ip = (struct ip *)src->buf;

    ip_v = ((char*)ip)[0] >> 4; /* ip->ip_v may not be alignment-safe */
    if (ip_v == 4) {
	ip_hl = ((char*)ip)[0] & 0x0F; /* ip->ip_hl may not be alignment-safe */
	if (ip_hl < 5)	/* impossible */
	    return CORAL_ESYNTAX;
	hdr_len = 4 * ip_hl;
	if (dumpbuf) {
	    if (src->protocol != CORAL_NETPROTO_IPv4) /* RAW_IP */
		crl_snprintf(&dumpbuf, &buflen, "v%u ", ip_v);
	    crl_snprintf(&dumpbuf, &buflen, "hl=%uB", hdr_len);
	}

	if (fits(ip, ip_len, src->caplen)) {
	    ip_len = crl_nptohs(&ip->ip_len);

	    if (ip_len < ip_hl) return CORAL_ESYNTAX;
	    initdst(src, dst, hdr_len);
	    if (dst->caplen > ip_len - hdr_len) /* src->caplen incl padding */
		dst->caplen = ip_len - hdr_len;
	    if (dst->totlen > ip_len - hdr_len || dst->totlen < 0)
		dst->totlen = ip_len - hdr_len;
	}

	if (fits(ip, ip_p, src->caplen)) {
	    ip_off = crl_nptohs(&ip->ip_off);
	    if (!(ip_off & IP_OFFMASK)) {
		switch (ip->ip_p) {
		case IPPROTO_IPIP:  dst->protocol = CORAL_NETPROTO_IPv4; break;
		case IPPROTO_IPV6:  dst->protocol = CORAL_NETPROTO_IPv6; break;
		default:	    dst->protocol = coral_mkproto(4, ip->ip_p);
		}
	    }
	    if (!dumpbuf) return 0;
	} else {
	    if (!dumpbuf) return CORAL_ELENGTH;
	}

	if (!fits(ip, ip_tos, src->caplen)) return CORAL_ELENGTH;
	if (ip->ip_tos) {
	    crl_snprintf(&dumpbuf, &buflen, " tos=%#02x", ip->ip_tos);
	    switch (ip->ip_tos & IPECN_MASK) {
	    case IPECN_ECT1: crl_snprintf(&dumpbuf, &buflen, " ECT(1)");
		break;
	    case IPECN_ECT0: crl_snprintf(&dumpbuf, &buflen, " ECT(0)");
		break;
	    case IPECN_CE: crl_snprintf(&dumpbuf, &buflen, " CE");
		break;
	    default: break;
	    }
	}
	if (!fits(ip, ip_len, src->caplen)) return CORAL_ELENGTH;
	crl_snprintf(&dumpbuf, &buflen, " len=%u", crl_nptohs(&ip->ip_len));
	if (!fits(ip, ip_id, src->caplen)) return CORAL_ELENGTH;
	crl_snprintf(&dumpbuf, &buflen, " id=%04x", crl_nptohs(&ip->ip_id));
	if (!fits(ip, ip_off, src->caplen)) return CORAL_ELENGTH;
	ip_off = crl_nptohs(&ip->ip_off);
	crl_snprintf(&dumpbuf, &buflen, "%s%s%s",
	    ip_off & IP_DF ? " DF" : "",
	    ip_off & IP_MF ? " MF" : "",
	    ip_off & IP_RF ? " RF" : "");
	if ((ip_off & IP_MF) || (ip_off & IP_OFFMASK))
	    crl_snprintf(&dumpbuf, &buflen, " off=%uB",
		(ip_off & IP_OFFMASK) * 8);
	if (!fits(ip, ip_ttl, src->caplen)) return CORAL_ELENGTH;
	crl_snprintf(&dumpbuf, &buflen, " ttl=%u", ip->ip_ttl);
	if (!fits(ip, ip_p, src->caplen)) return CORAL_ELENGTH;
	crl_snprintf(&dumpbuf, &buflen, " p=%u", ip->ip_p);
	if (coral_config.flags & CORAL_OPT_IP_CKSUM) {
	    if (!fits(ip, ip_sum, src->caplen)) return CORAL_ELENGTH;
	    crl_snprintf(&dumpbuf, &buflen, " sum=%04x", crl_nptohs(&ip->ip_sum));
	    if (hdr_len <= src->caplen) {
		unsigned long cksum = coral_in_cksum_add(0, ip, hdr_len);
		crl_snprintf(&dumpbuf, &buflen, "(%s)",
		    (coral_in_cksum_result(cksum) == 0) ? "pass" : "fail");
	    }
	}
	if (src->caplen <= offsetof(struct ip, ip_src)) return CORAL_ELENGTH;
	crl_snprintf(&dumpbuf, &buflen, " ");
	coral_fmt_in_addr(&dumpbuf, &buflen, &ip->ip_src,
	    src->caplen - offsetof(struct ip, ip_src));
	if (src->caplen <= offsetof(struct ip, ip_dst)) return CORAL_ELENGTH;
	crl_snprintf(&dumpbuf, &buflen, " > ");
	coral_fmt_in_addr(&dumpbuf, &buflen, &ip->ip_dst,
	    src->caplen - offsetof(struct ip, ip_dst));

	if (hdr_len > src->caplen) hdr_len = src->caplen;
	hdr_len -= sizeof(*ip);
	for (opt = (uint8_t*)src->buf + sizeof(*ip); hdr_len >= 2; ) {
	    if (*opt == IPOPT_EOL)
		break;
	    if (*opt == IPOPT_NOP) {
		crl_snprintf(&dumpbuf, &buflen, " NOP");
		opt++; hdr_len--; continue;
	    }
	    if ((len = opt[1]) < 2) { /* error */
		crl_snprintf(&dumpbuf, &buflen, " ?");
		break;
	    }
#if 0 /* debugging */
	    crl_snprintf(&dumpbuf, &buflen, " ");
	    for (i = 0; i < len && i < hdr_len; i++)
		crl_snprintf(&dumpbuf, &buflen, "%02x", opt[i]);
#endif
	    switch (*opt) {
	    case IPOPT_RR:
	    case IPOPT_LSRR:
	    case IPOPT_SSRR:
		crl_snprintf(&dumpbuf, &buflen, "; %sRR",
		    (*opt == IPOPT_LSRR) ? "LS" :
		    (*opt == IPOPT_SSRR) ? "SS" :
		    ""
		);
		if (*opt != IPOPT_RR)
		    crl_snprintf(&dumpbuf, &buflen, " seen");
		for (i = 3; i + 4 <= opt[2] && i + 4 <= hdr_len; i += 4) {
		    crl_snprintf(&dumpbuf, &buflen, " %d.%d.%d.%d",
			opt[i], opt[i+1], opt[i+2], opt[i+3]);
		}
		if (*opt != IPOPT_RR) {
		    crl_snprintf(&dumpbuf, &buflen, " next");
		    for (i = (opt[2] - 3) / 4 * 4 + 3;
			i + 4 <= len && i + 4 <= hdr_len; i += 4)
		    {
			crl_snprintf(&dumpbuf, &buflen, " %d.%d.%d.%d",
			    opt[i], opt[i+1], opt[i+2], opt[i+3]);
		    }
		}
		break;
	    default:
		crl_snprintf(&dumpbuf, &buflen, "; OPT %u%s", opt[0],
		    len > 2 ? "=0x" : "");
		for (i = 2; i < len && i < hdr_len; i++)
		    crl_snprintf(&dumpbuf, &buflen, "%02x", opt[i]);
		break;
	    }
	    opt += len;
	    hdr_len -= len;
	}

	return 0;

    } else {
	if (dumpbuf)
	    crl_snprintf(&dumpbuf, &buflen, "v%u", ip_v);
	return CORAL_ESYNTAX;
    }
}

#ifdef HAVE_INET6
/* RFC 2460, 2402, 2406 */
static int coral_get_ipexthdr_payload(const coral_pkt_buffer_t *src,
    coral_pkt_buffer_t *dst, char *dumpbuf, int buflen)
{
    int hdr_len, i, j;
    const uint8_t *p;
    uint8_t nxt, more = 0;
    uint16_t offset = 0;

    initdst(src, dst, 2);
    if (src->caplen < 2) return CORAL_ELENGTH;
    p = (uint8_t*)src->buf;

    if (src->protocol == CORAL_IPPROTO_ESP) {	/* encap security payload */
	initdst(src, dst, 8);
	if (dumpbuf) {
	    if (src->caplen < 4) return CORAL_ELENGTH;
	    crl_snprintf(&dumpbuf, &buflen, " spi=%08x", crl_nptohl(p+0));
	    if (src->caplen < 8) return CORAL_ELENGTH;
	    crl_snprintf(&dumpbuf, &buflen, " seq=%08x", crl_nptohl(p+4));
	}

    } else {
	/* All other headers start with 8-bit next_hdr and 8-bit ext_hdr_len */
	nxt = p[0];
	hdr_len = (p[1] + 1) * 8;
	initdst(src, dst, hdr_len);
	dst->protocol = coral_mkproto(4, nxt);

	switch (src->protocol) {
	case CORAL_IPPROTO_HOPOPTS:	/* hop-by-hop options */
	case CORAL_IPPROTO_DSTOPTS:	/* destination options */
	    if (dumpbuf) {
		for (i = 2; i < hdr_len; i += (p[i] == 0) ? 1 : 2 + p[i+1]) {
		    if (i >= src->caplen) return CORAL_ELENGTH;
		    switch(p[i]) {
		    case 0:
			crl_snprintf(&dumpbuf, &buflen, "pad1");
			break;
		    case 1:
			if (i >= src->caplen+1) return CORAL_ELENGTH;
			crl_snprintf(&dumpbuf, &buflen, "padN %d", p[i+1]);
			break;
		    default:
			crl_snprintf(&dumpbuf, &buflen, "opt %d: ", p[i]);
			for (j = i+2; j < i + 2 + p[i+1]; j++) {
			    if (j >= src->caplen) return CORAL_ELENGTH;
			    crl_snprintf(&dumpbuf, &buflen, "%02x ", p[j]);
			}
		    }
		    crl_snprintf(&dumpbuf, &buflen, "; ");
		}
	    }
	    break;
	case CORAL_IPPROTO_ROUTING:	/* routing header */
	    if (dumpbuf) {
		if (src->caplen < 3) return CORAL_ELENGTH;
		crl_snprintf(&dumpbuf, &buflen, "type=%02x ", p[2]);
		if (src->caplen < 4) return CORAL_ELENGTH;
		crl_snprintf(&dumpbuf, &buflen, "left=%02x ", p[3]);
		if (p[2] == 0) {
		    char addrbuf[INET6_ADDRSTRLEN+1];
		    for (i = 8; i < hdr_len; i += sizeof(struct in6_addr)) {
			if (i+sizeof(struct in6_addr) > src->caplen)
			    return CORAL_ELENGTH;
			crl_snprintf(&dumpbuf, &buflen, " %s",
			    inet_ntop(AF_INET6, (char*)(p+i), addrbuf,
				INET6_ADDRSTRLEN));
		    }
		} else {
		    for (i = 4; i < hdr_len; i++) {
			if (i >= src->caplen) return CORAL_ELENGTH;
			crl_snprintf(&dumpbuf, &buflen, "%02x ", p[i]);
		    }
		}
	    }
	    break;
	case CORAL_IPPROTO_FRAGMENT:	/* fragment header */
	    if (hdr_len != 8) return CORAL_ESYNTAX;
	    if (src->caplen >= 4) {
		offset = crl_nptohs(p+2);
		more = offset & 0x1;
		offset = offset >> 3;
	    }
	    if (src->caplen < 4 || offset) /* !first */
		dst->protocol = CORAL_PROTO_UNKNOWN;
	    if (dumpbuf) {
		if (src->caplen < 4) return CORAL_ELENGTH;
		crl_snprintf(&dumpbuf, &buflen, "off=%d ", offset >> 3);
		if (more) crl_snprintf(&dumpbuf, &buflen, "M ");
		if (src->caplen < 8) return CORAL_ELENGTH;
		crl_snprintf(&dumpbuf, &buflen, "id=%08x ", crl_nptohl(p+4));
	    }
	    break;
	case CORAL_IPPROTO_AH:		/* authentication header */
	    if (dumpbuf) {
		if (src->caplen < 8) return CORAL_ELENGTH;
		crl_snprintf(&dumpbuf, &buflen, "spi=%08x ",
		    crl_nptohl(p+4));
		if (src->caplen < 12) return CORAL_ELENGTH;
		crl_snprintf(&dumpbuf, &buflen, "seq=%08x ",
		    crl_nptohl(p+8));
		crl_snprintf(&dumpbuf, &buflen, "data=");
		for (i = 12; i < hdr_len; i++) {
		    if (i >= src->caplen) return CORAL_ELENGTH;
		    crl_snprintf(&dumpbuf, &buflen, "%02x ", p[i]);
		}
	    }
	    break;
	default:			/* unrecognized extension header */
	    return CORAL_ESYNTAX;
	}
    }

    return 0;
}

/* RFC 2460 */
static int coral_get_ip6_payload(const coral_pkt_buffer_t *src,
    coral_pkt_buffer_t *dst, char *dumpbuf, int buflen)
{
    struct ip6_hdr *ip6;
    int hdr_len, result;
    uint16_t plen;
    uint8_t tclass;
    char addrbuf[INET6_ADDRSTRLEN+1];

    hdr_len = sizeof(*ip6);
    initdst(src, dst, hdr_len);
    if (src->caplen < 1) return CORAL_ELENGTH;
    ip6 = (struct ip6_hdr *)src->buf;

    if ((ip6->ip6_vfc >> 4) == 6) {
	if (dumpbuf && (src->protocol != CORAL_NETPROTO_IPv6)) /* RAW_IP */
	    crl_snprintf(&dumpbuf, &buflen, "v%u ", ip6->ip6_vfc >> 4);
	if (fits(ip6, ip6_plen, src->caplen))
	    plen = crl_nptohs(&ip6->ip6_plen);

	if (src->totlen < 0 || hdr_len + plen < src->totlen)
	    dst->totlen = plen;
	if (dst->totlen >= 0 && dst->caplen > dst->totlen)
	    dst->caplen = dst->totlen;	/* caplen included padding */

	if (!fits(ip6, ip6_nxt, src->caplen)) {
	    dst->protocol = CORAL_PROTO_UNKNOWN;
	    result = CORAL_ELENGTH;
	} else {
	    switch (ip6->ip6_nxt) {
	    case IPPROTO_IPIP:	dst->protocol = CORAL_NETPROTO_IPv4; break;
	    case IPPROTO_IPV6:	dst->protocol = CORAL_NETPROTO_IPv6; break;
	    default:		dst->protocol = coral_mkproto(4, ip6->ip6_nxt);
	    }
	    result = 0;
	}

	if (dumpbuf) {
	    result = CORAL_ELENGTH;
	    if (!fits(ip6, ip6_flow, src->caplen)) goto ip6_print_done;
	    tclass = (crl_nptohl(&ip6->ip6_flow) & 0x0ff00000) >> 20;
	    crl_snprintf(&dumpbuf, &buflen, "tclass=%#02x ", tclass);
	    switch (tclass & IPECN_MASK) {
	    case IPECN_ECT1: crl_snprintf(&dumpbuf, &buflen, " ECT(1)");
		break;
	    case IPECN_ECT0: crl_snprintf(&dumpbuf, &buflen, " ECT(0)");
		break;
	    case IPECN_CE: crl_snprintf(&dumpbuf, &buflen, " CE");
		break;
	    default: break;
	    }
	    crl_snprintf(&dumpbuf, &buflen, "label=%#05x ",
		crl_nptohl(&ip6->ip6_flow) & 0x000fffff);
	    if (!fits(ip6, ip6_plen, src->caplen)) goto ip6_print_done;
	    crl_snprintf(&dumpbuf, &buflen, "plen=%u ", plen);
	    if (!fits(ip6, ip6_nxt, src->caplen)) goto ip6_print_done;
	    crl_snprintf(&dumpbuf, &buflen, "nxt=%u ", ip6->ip6_nxt);
	    if (!fits(ip6, ip6_hops, src->caplen)) goto ip6_print_done;
	    crl_snprintf(&dumpbuf, &buflen, "hops=%u ", ip6->ip6_hops);
	    if (!fits(ip6, ip6_src, src->caplen)) goto ip6_print_done;
	    crl_snprintf(&dumpbuf, &buflen, " %s",
		inet_ntop(AF_INET6, (char*)&ip6->ip6_src, addrbuf,
		    INET6_ADDRSTRLEN));
	    if (!fits(ip6, ip6_dst, src->caplen)) goto ip6_print_done;
	    crl_snprintf(&dumpbuf, &buflen, " > %s",
		inet_ntop(AF_INET6, (char*)&ip6->ip6_dst, addrbuf,
		    INET6_ADDRSTRLEN));
	    result = 0;
	}
	ip6_print_done:

	if (!(coral_config.flags & CORAL_OPT_IP_EXTHDR)) {
	    coral_pkt_buffer_t buf;
	    switch (dst->protocol) {
	    case CORAL_IPPROTO_HOPOPTS:
	    case CORAL_IPPROTO_ROUTING:
	    case CORAL_IPPROTO_FRAGMENT:
	    case CORAL_IPPROTO_DSTOPTS:
		if (dumpbuf)
		    crl_snprintf(&dumpbuf, &buflen, "; %s: ",
			coral_proto_str(dst->protocol));
		buf = *dst;
		return coral_get_ipexthdr_payload(&buf, dst, dumpbuf, buflen);
	    default:
		break;
	    }
	}

	return result;

    } else {
	if (dumpbuf)
	    crl_snprintf(&dumpbuf, &buflen, "v%u", ip6->ip6_vfc >> 4);
	return CORAL_ESYNTAX;
    }
}
#endif /* HAVE_INET6 */

static int coral_get_rawip_payload(const coral_pkt_buffer_t *src,
    coral_pkt_buffer_t *dst, char *dumpbuf, int buflen)
{
    initdst(src, dst, 1);
    if (src->caplen < 1) return CORAL_ELENGTH;
    if ((src->buf[0] >> 4) == 4)
	return coral_get_ip4_payload(src, dst, dumpbuf, buflen);
#ifdef HAVE_INET6
    if ((src->buf[0] >> 4) == 6)
	return coral_get_ip6_payload(src, dst, dumpbuf, buflen);
#endif
    return CORAL_ESYNTAX;
}

/* RFC 793 */
static int coral_get_tcp_payload(const coral_pkt_buffer_t *src,
    coral_pkt_buffer_t *dst, char *dumpbuf, int buflen)
{
    struct tcphdr *tcp;
    int hdr_len, i;
    const uint8_t *opt;
    uint8_t len, th_off;
    uint16_t sport = 0, dport = 0;

    tcp = (struct tcphdr*)src->buf;

    th_off = ((uint8_t*)tcp)[12] >> 4; /* tcp->th_off may be alignment-unsafe */
    hdr_len = (src->caplen < 13) ? sizeof(*tcp) : (th_off * 4);
    if (hdr_len < sizeof(*tcp))
	return CORAL_ESYNTAX;

    initdst(src, dst, hdr_len);

    if (fits(tcp, th_dport, src->caplen)) {
	sport = crl_nptohs(&tcp->th_sport);
	dport = crl_nptohs(&tcp->th_dport);

	if (dst->caplen >= 2 && (dport == 53 || sport == 53)
	    && crl_nptohs(dst->buf) == dst->totlen - 2)
	{
	    /* DNS over TCP begins with 16-bit length field.  If that doesn't
	     * match totlen, this packet is either not the first packet of
	     * the data stream, or is the first packet but is followed by more
	     * packets. */
	    dst->protocol = CORAL_PROTO_DNS;
	}
	if (!dumpbuf) return 0;
    } else {
	if (!dumpbuf) return CORAL_ELENGTH;
    }

    if (!fits(tcp, th_sport, src->caplen)) return CORAL_ELENGTH;
    crl_snprintf(&dumpbuf, &buflen, "src=%u ", crl_nptohs(&tcp->th_sport));
    if (!fits(tcp, th_dport, src->caplen)) return CORAL_ELENGTH;
    crl_snprintf(&dumpbuf, &buflen, "dst=%u ", crl_nptohs(&tcp->th_dport));
    if (!fits(tcp, th_seq, src->caplen)) return CORAL_ELENGTH;
    crl_snprintf(&dumpbuf, &buflen, "seq=%08x ", crl_nptohl(&tcp->th_seq));
    if (src->caplen < 13) return CORAL_ELENGTH;
    crl_snprintf(&dumpbuf, &buflen, "off=%luB ", th_off * 4);
    if (src->caplen < 14) return CORAL_ELENGTH;
    crl_snprintf(&dumpbuf, &buflen, "%s%s%s%s%s%s",
	tcp->th_flags & TH_FIN ? "FIN," : "",
	tcp->th_flags & TH_SYN ? "SYN," : "",
	tcp->th_flags & TH_RST ? "RST," : "",
	tcp->th_flags & TH_PUSH ? "PSH," : "",
	tcp->th_flags & TH_ECE ? "ECE," : "",
	tcp->th_flags & TH_CWR ? "CWR," : "");
    *--dumpbuf = '\0';
    buflen++;
    if (tcp->th_flags & TH_ACK) {
	crl_snprintf(&dumpbuf, &buflen, " ack=%08x", crl_nptohl(&tcp->th_ack));
    }
    if (tcp->th_flags & (TH_ACK|TH_SYN)) {
	if (!fits(tcp, th_win, src->caplen)) return CORAL_ELENGTH;
	crl_snprintf(&dumpbuf, &buflen, " win=%u", crl_nptohs(&tcp->th_win));
    }
    if (tcp->th_flags & TH_URG) {
	if (!fits(tcp, th_urp, src->caplen))
	    crl_snprintf(&dumpbuf, &buflen, " URG");
	else
	    crl_snprintf(&dumpbuf, &buflen, " urg=%04x",
		crl_nptohs(&tcp->th_urp));
    }

    if (hdr_len > src->caplen) hdr_len = src->caplen;
    hdr_len -= sizeof(*tcp);
    opt = (uint8_t*)src->buf + sizeof(*tcp);
    while (hdr_len >= 2) {
	if (*opt == TCPOPT_EOL)
	    break;
	if (*opt == TCPOPT_NOP) {
	    crl_snprintf(&dumpbuf, &buflen, " NOP");
	    opt++; hdr_len--; continue;
	}
	if ((len = opt[1]) < 2) { /* error */
	    crl_snprintf(&dumpbuf, &buflen, " ?");
	    break;
	}
	switch (*opt) {
	case TCPOPT_MAXSEG: /* MSS */
	    if (len != 4) goto raw_tcpopt;
	    crl_snprintf(&dumpbuf, &buflen, " MSS");
	    if (len <= hdr_len)
		crl_snprintf(&dumpbuf, &buflen, "=%u", crl_nptohs(opt+2));
	    break;
	case TCPOPT_WINDOW:
	    if (len != 3) goto raw_tcpopt;
	    crl_snprintf(&dumpbuf, &buflen, " WINDOWSCALE");
	    if (len <= hdr_len)
		crl_snprintf(&dumpbuf, &buflen, "=%u", opt[2]);
	    break;
	case TCPOPT_SACK_PERMITTED:
	    if (len != 2) goto raw_tcpopt;
	    crl_snprintf(&dumpbuf, &buflen, " SACK-PERMITTED");
	    break;
	case TCPOPT_SACK:
	    if ((len - 2) % 8) goto raw_tcpopt;
	    crl_snprintf(&dumpbuf, &buflen, " SACK");
	    for (i = 2; i < len && i + 8 <= hdr_len; i += 8) {
		crl_snprintf(&dumpbuf, &buflen, " %08x-%08x",
		    crl_nptohl(opt+i),
		    crl_nptohl(opt+i+4));
	    }
	    break;
	case TCPOPT_TIMESTAMP:
	    if (len != 10) goto raw_tcpopt;
	    crl_snprintf(&dumpbuf, &buflen, " TIMESTAMP");
	    if (hdr_len >= 6)
		crl_snprintf(&dumpbuf, &buflen, " %08x", crl_nptohl(opt+2));
	    if (hdr_len >= 10)
		crl_snprintf(&dumpbuf, &buflen, " %08x", crl_nptohl(opt+6));
	    break;
	default:
raw_tcpopt:
	    crl_snprintf(&dumpbuf, &buflen, " OPT %u%s", opt[0],
		len > 2 ? "=0x" : "");
	    for (i = 2; i < len && i < hdr_len; i++)
		crl_snprintf(&dumpbuf, &buflen, "%02x", opt[i]);
	    break;
	}
	opt += len;
	hdr_len -= len;
    }

    return 0;
}

/* RFC 768 */
static int coral_get_udp_payload(const coral_pkt_buffer_t *src,
    coral_pkt_buffer_t *dst, char *dumpbuf, int buflen)
{
    struct udphdr *udp;
    int skip = sizeof(struct udphdr), len;
    uint16_t sport = 0, dport = 0;

    initdst(src, dst, skip);
    udp = (struct udphdr*)src->buf;

    if (fits(udp, uh_dport, src->caplen)) {
	sport = crl_nptohs(&udp->uh_sport);
	dport = crl_nptohs(&udp->uh_dport);
	if (dport == 53 || sport == 53)
	    dst->protocol = CORAL_PROTO_DNS;
	else if (dport == 161)
	    dst->protocol = CORAL_PROTO_SNMP;

    } else {
	if (!dumpbuf) return CORAL_ELENGTH;
    }

    if (fits(udp, uh_ulen, src->caplen)) {
	len = crl_nptohs(&udp->uh_ulen);
	if (len < sizeof(*udp)) return CORAL_ESYNTAX;
	len -= sizeof(*udp);
	if (dst->caplen > len) dst->caplen = len;
	if (dst->totlen > len || dst->totlen < 0) dst->totlen = len;
	if (!dumpbuf) return 0;
    } else {
	if (!dumpbuf) return CORAL_ELENGTH;
    }

    if (!fits(udp, uh_sport, src->caplen)) return CORAL_ELENGTH;
    crl_snprintf(&dumpbuf, &buflen, "src=%u", crl_nptohs(&udp->uh_sport));
    if (!fits(udp, uh_dport, src->caplen)) return CORAL_ELENGTH;
    crl_snprintf(&dumpbuf, &buflen, " dst=%u", crl_nptohs(&udp->uh_dport));
    if (!fits(udp, uh_ulen, src->caplen)) return CORAL_ELENGTH;
    crl_snprintf(&dumpbuf, &buflen, " len=%u", crl_nptohs(&udp->uh_ulen));

    return 0;
}

/* RFC 792, 1122 */
static int coral_get_icmp4_payload(const coral_pkt_buffer_t *src,
    coral_pkt_buffer_t *dst, char *dumpbuf, int buflen)
{
    struct icmp *icmp;
    const char *atype = NULL, *acode = NULL;

    initdst(src, dst, 8);
    icmp = (struct icmp*)src->buf;
    if (!fits(icmp, icmp_type, src->caplen)) return CORAL_ELENGTH;

/* Avoid repeating code (at the cost of obfuscating the code a bit) */
#define set_atype(type)		case ICMP_##type:	    atype = #type
#define set_acode(type, code)	case ICMP_##type##_##code:  acode = #code

    switch (icmp->icmp_type) {
    set_atype(UNREACH);
	dst->protocol = CORAL_NETPROTO_IPv4;
	if (!dumpbuf) return 0;
	if (fits(icmp, icmp_code, src->caplen))
	    switch (icmp->icmp_code) {
	    set_acode(UNREACH, NET);			break;
	    set_acode(UNREACH, HOST);			break;
	    set_acode(UNREACH, PROTOCOL);		break;
	    set_acode(UNREACH, PORT);			break;
	    set_acode(UNREACH, NEEDFRAG);		break;
	    set_acode(UNREACH, SRCFAIL);		break;
	    set_acode(UNREACH, NET_UNKNOWN);		break;
	    set_acode(UNREACH, HOST_UNKNOWN);		break;
	    set_acode(UNREACH, ISOLATED);		break;
	    set_acode(UNREACH, NET_PROHIB);		break;
	    set_acode(UNREACH, HOST_PROHIB);		break;
	    set_acode(UNREACH, TOSNET);			break;
	    set_acode(UNREACH, TOSHOST);		break;
	    set_acode(UNREACH, FILTER_PROHIB);		break;
	    set_acode(UNREACH, HOST_PRECEDENCE);	break;
	    set_acode(UNREACH, PRECEDENCE_CUTOFF);	break;
	    }
	break;
    set_atype(REDIRECT);
	dst->protocol = CORAL_NETPROTO_IPv4;
	if (!dumpbuf) return 0;
	if (fits(icmp, icmp_code, src->caplen))
	    switch (icmp->icmp_code) {
	    set_acode(REDIRECT, NET);		break;
	    set_acode(REDIRECT, HOST);		break;
	    set_acode(REDIRECT, TOSNET);	break;
	    set_acode(REDIRECT, TOSHOST);	break;
	    }
	break;
    set_atype(TIMXCEED);
	dst->protocol = CORAL_NETPROTO_IPv4;
	if (!dumpbuf) return 0;
	if (fits(icmp, icmp_code, src->caplen))
	    switch (icmp->icmp_code) {
	    set_acode(TIMXCEED, INTRANS);	break;
	    set_acode(TIMXCEED, REASS);		break;
	    }
	break;
    set_atype(PARAMPROB);
	dst->protocol = CORAL_NETPROTO_IPv4;
	if (!dumpbuf) return 0;
	if (fits(icmp, icmp_code, src->caplen))
	    switch (icmp->icmp_code) {
	    set_acode(PARAMPROB, OPTABSENT);	break;
	    set_acode(PARAMPROB, LENGTH);	break;
	    }
	break;
    set_atype(SOURCEQUENCH);
	dst->protocol = CORAL_NETPROTO_IPv4;
	if (!dumpbuf) return 0;
	break;
    set_atype(PHOTURIS);
	if (!dumpbuf) return 0;
	if (fits(icmp, icmp_code, src->caplen))
	    switch (icmp->icmp_code) {
	    set_acode(PHOTURIS, BAD_SPI);	break;
	    set_acode(PHOTURIS, AUTHENT_FAIL);	break;
	    set_acode(PHOTURIS, DECOMP_FAIL);	break;
	    set_acode(PHOTURIS, DECRYPT_FAIL);	break;
	    set_acode(PHOTURIS, NEED_AUTHENT);	break;
	    set_acode(PHOTURIS, NEED_AUTHORIZ);	break;
	    }
	break;
    set_atype(ECHO);			break;
    set_atype(ECHOREPLY);		break;
    set_atype(ROUTERADVERT);		break;
    set_atype(ROUTERSOLICIT);		break;
    set_atype(TSTAMP);			break;
    set_atype(TSTAMPREPLY);		break;
    set_atype(IREQ);			break;
    set_atype(IREQREPLY);		break;
    set_atype(MASKREQ);			break;
    set_atype(MASKREPLY);		break;
    set_atype(TRACEROUTE);		break;
    set_atype(DGRAM_CONV_ERR);		break;
    set_atype(MOBILE_HOST_REDIR);	break;
    set_atype(WHERE_ARE_YOU);		break;
    set_atype(I_AM_HERE);		break;
    set_atype(MOBILE_REG_REQ);		break;
    set_atype(MOBILE_REG_REP);		break;
    set_atype(SKIP);			break;
    }

#undef set_atype
#undef set_acode

    if (!dumpbuf) return 0;

    if (atype)
	crl_snprintf(&dumpbuf, &buflen, "%s", atype);
    else
	crl_snprintf(&dumpbuf, &buflen, "type=%d", icmp->icmp_type);
    if (!fits(icmp, icmp_code, src->caplen)) return CORAL_ELENGTH;
    if (acode)
	crl_snprintf(&dumpbuf, &buflen, "_%s", acode);
    else if (icmp->icmp_code)
	crl_snprintf(&dumpbuf, &buflen, " code=%d", icmp->icmp_code);
    if (!fits(icmp, icmp_cksum, src->caplen)) return CORAL_ELENGTH;
    crl_snprintf(&dumpbuf, &buflen, " cksum=%04x",
	crl_nptohs(&icmp->icmp_cksum));

    if (!fits(icmp, icmp_hun, src->caplen)) return CORAL_ELENGTH;
    if (icmp->icmp_type == ICMP_UNREACH &&
	icmp->icmp_code == ICMP_UNREACH_NEEDFRAG)
    {
	crl_snprintf(&dumpbuf, &buflen, " nextmtu=%04x",
	    crl_nptohs(&icmp->icmp_hun.ih_pmtu.ipm_nextmtu));
    } else if (icmp->icmp_type == ICMP_REDIRECT) {
	crl_snprintf(&dumpbuf, &buflen, " gateway=");
	coral_fmt_in_addr(&dumpbuf, &buflen, &icmp->icmp_hun.ih_gwaddr, 4);
    } else if (icmp->icmp_type == ICMP_PARAMPROB) {
	crl_snprintf(&dumpbuf, &buflen, " offset=%04x",
	    crl_nptohs(&icmp->icmp_hun.ih_pptr));
    } else if (dst->protocol != CORAL_NETPROTO_IPv4) { /* not an error msg */
	crl_snprintf(&dumpbuf, &buflen, " id=%04x seq=%04x",
	    crl_nptohs(&icmp->icmp_hun.ih_idseq.icd_id),
	    crl_nptohs(&icmp->icmp_hun.ih_idseq.icd_seq));
    }

    return 0;
}

#ifdef HAVE_NETINET_ICMP6_H
/* RFC 2463 */
static int coral_get_icmp6_payload(const coral_pkt_buffer_t *src,
    coral_pkt_buffer_t *dst, char *dumpbuf, int buflen)
{
    struct icmp6_hdr *icmp6;
    const char *atype = NULL, *acode = NULL;

    initdst(src, dst, 8);

/* Avoid repeating code (at the cost of obfuscating the code a bit) */
#define set_atype6(type)	case ICMP6_##type:	    atype = #type
#define set_atype_np(type)	case type:		    atype = #type
#define set_acode6(type, code)	case ICMP6_##type##_##code:  acode = #code

    icmp6 = (struct icmp6_hdr*)src->buf;
    if (!fits(icmp6, icmp6_type, src->caplen)) return CORAL_ELENGTH;

    if (!(icmp6->icmp6_type & 0x80)) {
	dst->protocol = CORAL_NETPROTO_IPv6;
    }
    switch (icmp6->icmp6_type) {
    set_atype6(DST_UNREACH);
	if (!dumpbuf) return 0;
	if (fits(icmp6, icmp6_code, src->caplen))
	    switch (icmp6->icmp6_code) {
	    set_acode6(DST_UNREACH, NOROUTE);		break;
	    set_acode6(DST_UNREACH, ADMIN);		break;
	    /*set_acode6(DST_UNREACH, BEYONDSCOPE);	break;*/ /* not std */
	    set_acode6(DST_UNREACH, ADDR);		break;
	    set_acode6(DST_UNREACH, NOPORT);		break;
	    }
	break;
    set_atype6(TIME_EXCEEDED);
	if (!dumpbuf) return 0;
	if (fits(icmp6, icmp6_code, src->caplen))
	    switch (icmp6->icmp6_code) {
	    set_acode6(TIME_EXCEED, TRANSIT);		break;
	    set_acode6(TIME_EXCEED, REASSEMBLY);	break;
	    }
	break;
    set_atype6(PARAM_PROB);
	if (!dumpbuf) return 0;
	if (fits(icmp6, icmp6_code, src->caplen))
	    switch (icmp6->icmp6_code) {
	    set_acode6(PARAMPROB, HEADER);		break;
	    set_acode6(PARAMPROB, NEXTHEADER);		break;
	    set_acode6(PARAMPROB, OPTION);		break;
	    }
	break;
    set_atype6(PACKET_TOO_BIG);		break;
    set_atype6(ECHO_REQUEST);		break;
    set_atype6(ECHO_REPLY);		break;
    set_atype6(MEMBERSHIP_QUERY);	break;
    set_atype6(MEMBERSHIP_REPORT);	break;
    set_atype6(MEMBERSHIP_REDUCTION);	break;
    set_atype_np(ND_ROUTER_SOLICIT);	break;
    set_atype_np(ND_ROUTER_ADVERT);	break;
    set_atype_np(ND_NEIGHBOR_SOLICIT);	break;
    set_atype_np(ND_NEIGHBOR_ADVERT);	break;
    set_atype_np(ND_REDIRECT);		break;
    }

#undef set_atype6
#undef set_atype6_np
#undef set_acode6

    if (!dumpbuf) return 0;

    if (atype)
	crl_snprintf(&dumpbuf, &buflen, "%s", atype);
    else
	crl_snprintf(&dumpbuf, &buflen, "type=%d", icmp6->icmp6_type);
    if (!fits(icmp6, icmp6_code, src->caplen)) return CORAL_ELENGTH;
    if (acode)
	crl_snprintf(&dumpbuf, &buflen, "_%s", acode);
    else if (icmp6->icmp6_code)
	crl_snprintf(&dumpbuf, &buflen, " code=%d", icmp6->icmp6_code);
    if (!fits(icmp6, icmp6_cksum, src->caplen)) return CORAL_ELENGTH;
    crl_snprintf(&dumpbuf, &buflen, " cksum=%04x",
	crl_nptohs(&icmp6->icmp6_cksum));

    if (!fits(icmp6, icmp6_data32, src->caplen)) return CORAL_ELENGTH;
    if (icmp6->icmp6_type == ICMP6_PACKET_TOO_BIG) {
	crl_snprintf(&dumpbuf, &buflen, " mtu=%d",
	    crl_nptohl(&icmp6->icmp6_mtu));
    } else if (icmp6->icmp6_type == ICMP6_PARAM_PROB) {
	crl_snprintf(&dumpbuf, &buflen, " ptr=%d",
	    crl_nptohl(&icmp6->icmp6_pptr));
    } else if (icmp6->icmp6_type == ICMP6_ECHO_REQUEST ||
	icmp6->icmp6_type == ICMP6_ECHO_REPLY)
    {
	crl_snprintf(&dumpbuf, &buflen, " id=%04x seq=%04x",
	    crl_nptohs(&icmp6->icmp6_id), crl_nptohs(&icmp6->icmp6_seq));
    }

    return 0;
}
#endif /* HAVE_INET6 */

/* RFC 2784 */
static int coral_get_gre_payload(const coral_pkt_buffer_t *src,
    coral_pkt_buffer_t *dst, char *dumpbuf, int buflen)
{
    struct coral_grehdr {
#if WORDS_BIGENDIAN
	unsigned cksum_present:1;
	unsigned reserved0:12;
	unsigned version:3;
#else
	unsigned version:3;
	unsigned reserved0:12;
	unsigned cksum_present:1;
#endif
	uint16_t protocol_type;
	uint16_t checksum;
	uint16_t reserved1;
    } *gre = (struct coral_grehdr*)src->buf;
    int skip = 4;
    uint16_t ethertype = 0;

    if (src->caplen < 2) return CORAL_ELENGTH;
    if (gre->reserved0 & 0xF80) return CORAL_ESYNTAX; /* rfc 1701 */
    if (gre->version > 0) return CORAL_ESYNTAX;
    if (gre->cksum_present) skip += 4;
    initdst(src, dst, skip);
    if (src->caplen >= 4) {
	ethertype = crl_nptohs(&gre->protocol_type);
	dst->protocol = ethertype_to_coral_proto(ethertype);
    }

    if (!dumpbuf) return 0;

    crl_snprintf(&dumpbuf, &buflen, "ver=%d", gre->version);
    if (src->caplen < 4) return CORAL_ELENGTH;
    crl_snprintf(&dumpbuf, &buflen, " reserved0=%03x", gre->reserved0);
    crl_snprintf(&dumpbuf, &buflen, " type=%04x", ethertype);
    if (gre->cksum_present) {
	if (src->caplen < 6) return CORAL_ELENGTH;
	crl_snprintf(&dumpbuf, &buflen, " cksum=%04x", gre->checksum);
	crl_snprintf(&dumpbuf, &buflen, " reserved1=%04x", gre->reserved1);
    }

    return 0;
}


/* ATM Forum af-ilmi-0065.000.pdf; RFC 1157; ITU-T X.680, X.690 */
/* supports only SNMPv1 */
static int coral_get_snmp_payload(const coral_pkt_buffer_t *src,
    coral_pkt_buffer_t *dst, char *dumpbuf, int buflen,
    const char *community)
{
    const char *p = src->buf;
    uint32_t seqlen, comlen;
    int i;

    dst->caplen = -1;
    dst->totlen = -1;
    dst->protocol = CORAL_PROTO_UNKNOWN;

#define ASN1_TAG_INT		 2
#define ASN1_TAG_OCTSTR		 4
#define ASN1_TAG_SEQ		16
#define ASN1_TAG_HIGH		0x1F
#define ASN1_TAG(x)		((x) & 0x1F)
#define ASN1_PRIMITIVE		0x00
#define ASN1_CONSTRUCTED	0x20
#define ASN1_CLASS_UNIVERSAL	0x00
#define ASN1_CLASS_APPLICATION	0x40
#define ASN1_CLASS_CONTEXT	0x80
#define ASN1_CLASS_PRIVATE	0xC0

    /* SEQUENCE */
    if (p+1 > src->buf + src->caplen)
	return CORAL_ELENGTH;
    if (*p != (ASN1_CLASS_UNIVERSAL | ASN1_CONSTRUCTED | ASN1_TAG_SEQ))
	return CORAL_ESYNTAX;
    p++;
    if (p+1 > src->buf + src->caplen)
	return CORAL_ELENGTH;
    if (!(*p & 0x80)) { /* short form */
	seqlen = *(p++);
    } else if (*p & 0x7F) { /* long form */
	i = *p & 0x7F;
	p++;
	if (p+i > src->buf + src->caplen)
	    return CORAL_ELENGTH;
	for (seqlen = 0; i; i--, p++) {
	    seqlen = (seqlen << 8) + *(unsigned char*)p;
	}
    } else { /* indefinite form */
	return CORAL_ESYNTAX;
    }
    if (dumpbuf)
	crl_snprintf(&dumpbuf, &buflen, " len=%" PRIu32, seqlen);

    /* version INTEGER */
    if (p+3 > src->buf + src->caplen)
	return CORAL_ELENGTH;
    if (*p != (ASN1_CLASS_UNIVERSAL | ASN1_PRIMITIVE | ASN1_TAG_INT))
	return CORAL_ESYNTAX;
    p++;
    if (*p != 1) return CORAL_ESYNTAX;
    p++;
    if (*p != 0) return CORAL_ESYNTAX;
    if (dumpbuf)
	crl_snprintf(&dumpbuf, &buflen, " SNMPv1");
    p++;

    /* community OCTET STRING */
    if (p+2 > src->buf + src->caplen)
	return CORAL_ELENGTH;
    if (*p != (ASN1_CLASS_UNIVERSAL | ASN1_PRIMITIVE | ASN1_TAG_OCTSTR))
	return CORAL_ESYNTAX;
    p++;
    comlen = *(unsigned char*)p;
    p++;
    if (p+comlen > src->buf + src->caplen)
	return CORAL_ELENGTH;
    if (community) {
	if (comlen != strlen(community)) return CORAL_ESYNTAX;
	if (strncmp(p, community, comlen) != 0) return CORAL_ESYNTAX;
    } else {
	for (i = 0; i < comlen; i++)
	    if (!isprint(p[i]))
		return CORAL_ESYNTAX;
    }

#define litstrcmp(var, len, lit) \
    (len == sizeof(lit) - 1 && strncmp(var, lit, len) == 0)

    if (litstrcmp(p, comlen, "ILMI"))
	dst->protocol = CORAL_PROTO_ILMI_PDU;
    else
	dst->protocol = CORAL_PROTO_SNMP_PDU;

    if (dumpbuf) {
	crl_snprintf(&dumpbuf, &buflen, " community=\"");
	crl_sncat(&dumpbuf, &buflen, p, comlen, "\"");
	crl_snappend(&dumpbuf, &buflen, '"');
    }

    dst->buf = p + comlen;
    dst->totlen = seqlen - 5 - comlen;
    dst->caplen = src->caplen - (dst->buf - src->buf);
    if (dst->caplen > dst->totlen)
	dst->caplen = dst->totlen;
    return 0;
}

/* NULL */
static int coral_get_null_payload(const coral_pkt_buffer_t *src,
    coral_pkt_buffer_t *dst, char *dumpbuf, int buflen)
{
    uint32_t family;

    if (src->caplen < sizeof(family)) return CORAL_ELENGTH;
    initdst(src, dst, sizeof(family));
    family = *(uint32_t*)src->buf; /* yes, this really is host order */
    switch (family) {
	case AF_INET:       dst->protocol = CORAL_NETPROTO_IPv4;       break;
#ifdef AF_INET6
	case AF_INET6:      dst->protocol = CORAL_NETPROTO_IPv6;       break;
#endif
	case AF_APPLETALK:  dst->protocol = CORAL_NETPROTO_APPLETALK;  break;
	case AF_IPX:        dst->protocol = CORAL_NETPROTO_IPX;        break;
	default:            dst->protocol = CORAL_PROTO_UNKNOWN;       break;
    }
    return 0;
}

int coral_fmt_get_payload(const coral_pkt_buffer_t *src,
    coral_pkt_buffer_t *dst, char *dumpbuf, int buflen)
{
    if (dumpbuf && coral_proto_str(src->protocol))
	crl_snprintf(&dumpbuf, &buflen, "%s: ", coral_proto_str(src->protocol));
    
    dst->parent_proto = src->protocol;

    switch (src->protocol) {
    case CORAL_PHY_ATM:
	return coral_get_atm_payload(src, dst, dumpbuf, buflen);

    case CORAL_DLT_ATM_AAL5:
	return coral_get_aal5_payload(src, dst, dumpbuf, buflen);

    case CORAL_DLT_ATM_RFC1483:
	return coral_get_llc_payload(src, dst, dumpbuf, buflen);

    case CORAL_DLT_CHDLC:
	return coral_get_chdlc_payload(src, dst, dumpbuf, buflen);

    case CORAL_DLT_MPoFR:
	return coral_get_mpofr_payload(src, dst, dumpbuf, buflen);

    case CORAL_DLT_UoPOS:
	return coral_get_uopos_payload(src, dst, dumpbuf, buflen);

#ifndef NDEBUG /* hack - developer only */
    case CORAL_DLT_FDDI:
	return coral_get_fddi_payload(src, dst, dumpbuf, buflen);
#endif

    case CORAL_DLT_NULL:
	return coral_get_null_payload(src, dst, dumpbuf, buflen);

    case CORAL_DLT_ETHER:
    case CORAL_DLT_IEEE802:
	return coral_get_ieee8023_or_ether_payload(src, dst, dumpbuf, buflen,
	    ETHERMTU);

    case CORAL_DLT_LANE_IEEE8023:
	return coral_get_lane_ieee8023_payload(src, dst, dumpbuf, buflen);

    case CORAL_DLT_LANE_LLC:
	return coral_get_lane_llc_payload(src, dst, dumpbuf, buflen);

    case CORAL_DLT_GIGX:
	return coral_get_gigx_payload(src, dst, dumpbuf, buflen);

    case CORAL_DLT_BRIDGED_LAN:
	return coral_get_bridgedlan_payload(src, dst, dumpbuf, buflen);

    /* Note: coral_open() changes user-configured CORAL_DLT_PPP to
     * CORAL_DLT_PPPo* based on physical layer
     */
    case CORAL_DLT_PPPoHDLC:
	return coral_get_pppohdlc_payload(src, dst, dumpbuf, buflen);

    case CORAL_DLT_PPPoES:
	return coral_get_pppoe_sess_payload(src, dst, dumpbuf, buflen);

    case CORAL_DLT_PPPoED:
	return coral_get_pppoe_disc_payload(src, dst, dumpbuf, buflen);

    case CORAL_DLT_PPP:
	return coral_get_ppp_payload(src, dst, dumpbuf, buflen);

    case CORAL_DLT_MPLS:
	return coral_get_mpls_payload(src, dst, dumpbuf, buflen);

    case CORAL_DLT_ILMI: /* ATM Forum af-ilmi-0065.000.pdf (SNMPv1 only) */
	return coral_get_snmp_payload(src, dst, dumpbuf, buflen, "ILMI");

    case CORAL_NETPROTO_ARP:
	return coral_get_arp_payload(src, dst, dumpbuf, buflen);

    case CORAL_NETPROTO_RAW_IP:
	return coral_get_rawip_payload(src, dst, dumpbuf, buflen);

    case CORAL_NETPROTO_IPv4:
	return coral_get_ip4_payload(src, dst, dumpbuf, buflen);

#ifdef HAVE_INET6
    case CORAL_NETPROTO_IPv6:
	return coral_get_ip6_payload(src, dst, dumpbuf, buflen);

    case CORAL_IPPROTO_HOPOPTS:
    case CORAL_IPPROTO_ROUTING:
    case CORAL_IPPROTO_FRAGMENT:
    case CORAL_IPPROTO_ESP:
    case CORAL_IPPROTO_AH:
    case CORAL_IPPROTO_DSTOPTS:
	return coral_get_ipexthdr_payload(src, dst, dumpbuf, buflen);
#endif

#if 0
    case CORAL_NETPROTO_APPLETALK:
    case CORAL_NETPROTO_AARP:
    /* see:
      http://developer.apple.com/techpubs/mac/NetworkingOT/NetworkingWOT-58.html
      http://www.cisco.com/univercd/cc/td/doc/cisintwk/ito_doc/applet.htm
     */
#endif

    case CORAL_IPPROTO_TCP:
	return coral_get_tcp_payload(src, dst, dumpbuf, buflen);

    case CORAL_IPPROTO_UDP:
	return coral_get_udp_payload(src, dst, dumpbuf, buflen);

    case CORAL_IPPROTO_ICMP:
	return coral_get_icmp4_payload(src, dst, dumpbuf, buflen);

#ifdef HAVE_NETINET_ICMP6_H
    case CORAL_IPPROTO_ICMP6:
	return coral_get_icmp6_payload(src, dst, dumpbuf, buflen);
#endif

    case CORAL_IPPROTO_GRE:
	return coral_get_gre_payload(src, dst, dumpbuf, buflen);

#ifdef HAVE_ARPA_NAMESER_H
    case CORAL_PROTO_DNS:
	return coral_get_dns_payload(src, dst, dumpbuf, buflen);
#endif

    case CORAL_PROTO_SNMP:
	return coral_get_snmp_payload(src, dst, dumpbuf, buflen, NULL);

    default:
	return CORAL_ENOPROTO;
    }
}

/* defined as a macro for speed, and as a function in case a ptr is needed */
int (coral_get_payload)(const coral_pkt_buffer_t *src, coral_pkt_buffer_t *dst)
{
    return coral_get_payload(src, dst);
}

/* deprecated */
const char *coral_get_net_pkt(const coral_pkt_buffer_t *buffer, int *protocol)
{
    coral_pkt_buffer_t dst;

    if (coral_get_payload(buffer, &dst) < 0)
	return NULL;
    *protocol = dst.protocol;
    return dst.buf;
}

int coral_get_payload_by_proto(const coral_pkt_buffer_t *src,
    coral_pkt_buffer_t *dst, coral_protocol_t proto)
{
    int x = 0, result;
    coral_pkt_buffer_t buf[2], *ldst;
    const coral_pkt_buffer_t *lsrc;

    lsrc = src;
    ldst = &buf[x];
    while (lsrc->protocol != proto) {
	if ((result = coral_get_payload(lsrc, ldst)) < 0)
	    return result;
	/* swap buffers */
	x = !x;
	ldst = &buf[x];
	lsrc = &buf[!x];
    }

    *dst = *lsrc;
    return 0;
}

int coral_get_payload_by_layer(const coral_pkt_buffer_t *src,
    coral_pkt_buffer_t *dst, int layer)
{
    int retval;
    coral_pkt_buffer_t buf;
    coral_pkt_buffer_t *ldst = src; /* pretend the previous result is src */
    const coral_pkt_buffer_t *lsrc;

    /* In the common case of needing to call coral_get_payload() exactly one
     * time (or any other odd number), we won't need to copy a pkt_buffer.
     */
    while (1) {
	if (coral_proto_layer(ldst->protocol) >= layer) {
	    *dst = *ldst; /* ldst != dst, so we must copy */
	    return 0;
	}
	lsrc = ldst; /* read from previous result */
	ldst = dst; /* write into *dst */
	if ((retval = coral_get_payload(lsrc, ldst)) < 0)
	    return retval;

	if (coral_proto_layer(ldst->protocol) >= layer) {
	    /* ldst == dst, so we don't need to copy */
	    return 0;
	}
	lsrc = ldst; /* read from previous result */
	ldst = &buf; /* write into buf */
	if ((retval = coral_get_payload(lsrc, ldst)) < 0)
	    return retval;
    }
}

int coral_pkt_truncate(coral_pkt_buffer_t *pkt, int layer, int unknown,
    int payload)
{
    int x = 0, reached = 0, result = 0;
    coral_pkt_buffer_t buf[2], *ldst;
    const coral_pkt_buffer_t *lsrc;

    if (pkt->caplen <= 0)
	return 0;
    lsrc = pkt;
    ldst = &buf[x];
    while (1) {
	if (layer > 0 && coral_proto_layer(lsrc->protocol) == layer) {
	    reached = 1;
	} else if (reached) {
	    break;
	} else if (lsrc->protocol == CORAL_PROTO_UNKNOWN) {
	    if (unknown) break;
	    else return 0;
	}
	if ((result = coral_get_payload(lsrc, ldst)) < 0) {
	    if (unknown) break;
	    else return result;
	}
	if (ldst->caplen == 0) {
	    /* ldst->buf may not be valid */
	    payload = lsrc->caplen;
	    break;
	}
	/* swap buffers */
	lsrc = ldst;
	ldst = &buf[x=!x];
    }

    if (pkt->caplen > lsrc->buf - pkt->buf + payload)
	pkt->caplen = lsrc->buf - pkt->buf + payload;
    return result;
}

void coral_fmprint_pkt(FILE *file, coral_iface_t *iface,
    const coral_timestamp_t *timestamp, int minlayer, int maxlayer,
    coral_pkt_buffer_t *packet,
    coral_pkt_buffer_t *header, coral_pkt_buffer_t *trailer)
{
    struct timespec ts;
    int x = 0;
    coral_pkt_buffer_t buf[2], *src, *dst;
    char dumpbuf[4096];

    dst = &buf[x];

    if (iface) {
	fprintf(file, "interface: %d\n", coral_interface_get_number(iface));
	if (timestamp) {
	    coral_clock_timespec_inline_nf(iface, timestamp, &ts);
	    fprintf(file, "time:  %ld.%09ld\n", ts.tv_sec, ts.tv_nsec);
	}
    }

    /* Print physical name, unless there's a physical header to print */
    if (iface && iface->iface_info.physical != CORAL_PROTO_UNKNOWN &&
	coral_proto_layer(iface->iface_info.physical) >= minlayer &&
	coral_proto_layer(iface->iface_info.physical) <= maxlayer &&
	!(header && header->protocol == iface->iface_info.physical))
    {
	fprintf(file, "proto: %s\n",
	    coral_proto_str(iface->iface_info.physical));
    }

    /* Print header */
    if (header && header->protocol != CORAL_PROTO_UNKNOWN &&
	coral_proto_layer(header->protocol) >= minlayer &&
	coral_proto_layer(header->protocol) <= maxlayer)
    {
	coral_fmt_get_payload(header, dst, dumpbuf, sizeof(dumpbuf));
	fprintf(file, "proto: %s\n", dumpbuf);
    }

    /* Print trailer */
    if (trailer && trailer->protocol != CORAL_PROTO_UNKNOWN &&
	coral_proto_layer(trailer->protocol) >= minlayer &&
	coral_proto_layer(trailer->protocol) <= maxlayer)
    {
	coral_fmt_get_payload(trailer, dst, dumpbuf, sizeof(dumpbuf));
	fprintf(file, "proto: %s\n", dumpbuf);
    }

    src = packet;
    while (src->protocol != CORAL_PROTO_UNKNOWN && src->caplen > 0 &&
	coral_proto_layer(src->protocol) <= maxlayer)
    {
	int result;
	result = coral_fmt_get_payload(src, dst,
	    coral_proto_layer(src->protocol) >= minlayer ? dumpbuf : NULL,
	    sizeof(dumpbuf));
	if (result < 0 && result != CORAL_ELENGTH) {
	    dst = src;
	    break;
	}
	if (coral_proto_layer(src->protocol) >= minlayer) {
	    fprintf(file, "proto: %s", dumpbuf);
	    if (result == CORAL_ELENGTH) {
		fprintf(file, " (truncated at %d", src->caplen);
		if (src->totlen > 0) fprintf(file, " of %d", src->totlen);
		fprintf(file, " bytes)");
	    }
	    fprintf(file, "\n");
	}
	x = !x;
	src = dst;
	dst = &buf[x];
    }

    if (src->protocol != CORAL_PROTO_UNKNOWN || src->caplen > 0) {
	fprintf(file, "data:  ");
	if (src->protocol != CORAL_PROTO_UNKNOWN)
	    fprintf(file, "%s, ", coral_proto_str(src->protocol));
	fprintf(file, "%d bytes", src->caplen > 0 ? src->caplen : 0);
	if (src->totlen != src->caplen) {
	    fprintf(file, (src->totlen >= 0) ? " (of %d)" : " (of ?)",
		src->totlen);
	}
	fprintf(file, "\n");
	coral_fprint_data(file, 7, (u_char*)src->buf, src->caplen);
    }
    fprintf(file, "\n");
}

/* defined as a macro for speed, and as a function in case a ptr is needed */
void (coral_fprint_pkt)(FILE *file, coral_iface_t *iface,
    const coral_timestamp_t *timestamp, int maxlayer,
    coral_pkt_buffer_t *packet,
    coral_pkt_buffer_t *header, coral_pkt_buffer_t *trailer)
{
    coral_fprint_pkt(file, iface, timestamp, maxlayer, packet, header, trailer);
}

void coral_mprint_pkt(coral_iface_t *iface, const coral_timestamp_t *timestamp,
    void *layerp, coral_pkt_buffer_t *packet,
    coral_pkt_buffer_t *header, coral_pkt_buffer_t *trailer)
{
    coral_fmprint_pkt(stdout, iface, timestamp,
	((int*)layerp)[0], ((int*)layerp)[1], packet, header, trailer);
}

/* defined as a macro for speed, and as a function in case a ptr is needed */
void (coral_print_pkt)(coral_iface_t *iface, const coral_timestamp_t *timestamp,
    void *layerp, coral_pkt_buffer_t *packet,
    coral_pkt_buffer_t *header, coral_pkt_buffer_t *trailer)
{
    coral_print_pkt(iface, timestamp, layerp, packet, header, trailer);
}

/* assumes buf len is at least CORAL_FMT_SUBIF_LEN */
int coral_fmt_subif(char *buf, const coral_iface_t *iface, uint32_t subif)
{
    if (iface->iface_info.physical == CORAL_PHY_ATM) {
	return sprintf(buf, "%d:%d", get_vpvc_vp(subif), get_vpvc_vc(subif));
    } else if (iface->iface_info.datalink == CORAL_DLT_ETHER) {
	return sprintf(buf, "%d", subif);
    }
    buf[0] = '\0';
    return 0;
}

/* assumes buf len is at least CORAL_FMT_IF_SUBIF_LEN */
int coral_fmt_if_subif(char *buf, const coral_iface_t *iface, uint32_t subif)
{
    int len, subif_len;
    len = sprintf(buf, "%d", iface->id);
    buf[len++] = '[';
    subif_len = coral_fmt_subif(buf + len, iface, subif);
    if (!subif_len) {
	len--;
    } else {
	len += subif_len;
	buf[len++] = ']';
    }
    buf[len] = '\0';
    return len;
}

/*
 * Code to update checksums in packets after doing incremental updates.
 *
 * Inspired by code from OpenBSD's pf code, although updated with the
 * correct algorithm from RFC1624 (modified from the ALTQ code).
 *
 * David Watson, 29 March 2005
 */

/*
 * The core algorithm borrowed from RFC 1624.
 *
 * Returns the new checksum based on the previous cksum value,
 *  and a change of the 16 bit value from old to new.
 */
static uint16_t incr_cksum_change(uint16_t cksum, uint16_t old, uint16_t new)
{
     int32_t sum;

     /* HC' = HC - ~m - m' */

     sum = cksum - (~old & 0xffff) - new;
     sum = (sum >> 16) + (sum & 0xffff);
     sum += (sum >> 16);  /* add carry */

     return(sum);

} /* incr_cksum_change */

/*
 * Update a checksum given an IP address change.
 *  udp is a flag that is 1 when updating a UDP checksum.
 */
static void update_cksum(uint16_t *cksum, uint32_t old, uint32_t new,
			 int udp)
{
     if (udp && *cksum == 0) {
	  return;
     }

     *cksum = incr_cksum_change(*cksum, ((uint16_t*)&old)[0],
				((uint16_t*)&new)[0]);
     *cksum = incr_cksum_change(*cksum, ((uint16_t*)&old)[1],
				((uint16_t*)&new)[1]);

     if (udp && *cksum == 0) {
	  *cksum = 0xffff;
     }
} /* update_cksum */


/* Anonymize an (aligned, complete) IPv4 address */
uint32_t coral_anonymize(coral_anon_t *anon, uint32_t oldval) {
    uint32_t newval;
    switch (anon->alg) {
#ifdef HAVE_CRYPTOPAN
	case CORAL_ANON_ALG_CRYPTOPAN:
	    newval = coral_PAnonymize(anon->anonymizer, oldval);
	    break;
#endif /* HAVE_CRYPTOPAN */
	case CORAL_ANON_ALG_ZERO:
	    newval = 0;
	    break;
	case CORAL_ANON_ALG_NONE:
	    newval = oldval;
	    break;
    }
    return (newval & ~anon->keepmask) | (oldval & anon->keepmask);
}

/* Anonymize an IPv4 address that might be truncated */
static void coral_trunc_anon(coral_anon_t *anon, void *addr, size_t size,
			     uint32_t *old, uint32_t *new)
{
    uint32_t oldval = 0;

    if (size > 4)
	size = 4;

    /* addr may not be aligned, so we must copy; we must convert to host
     * order; and part of *addr may be missing, so crl_nptohl won't work
     * directly.
     * We handle all of these in one step instead of copying, padding, and
     * calling crl_nptohl.
     */
    switch (size) {
	case 4: oldval |= ((uint8_t*)addr)[3] << 0; /* fall through */
	case 3: oldval |= ((uint8_t*)addr)[2] << 8; /* fall through */
	case 2: oldval |= ((uint8_t*)addr)[1] << 16; /* fall through */
	case 1: oldval |= ((uint8_t*)addr)[0] << 24; /* fall through */
    }

    *old = htonl(oldval);
    *new = coral_anonymize(anon, oldval);
    *new = htonl(*new);
    memcpy(addr, new, size);
}

int coral_pkt_anonymize(coral_pkt_buffer_t *orig)
{
    int x = 0;
    coral_pkt_buffer_t buf[2], *pay, *pkt;
    uint32_t old_src, new_src;
    uint32_t old_dst, new_dst;
    int firstL3 = 1;

    /* Find outermost IPv4 header */
    if (coral_get_payload_by_layer(orig, &buf[0], 3) < 0)
	return coral_config.anon.keep;

    pkt = &buf[0];
    pay = &buf[1];

    if (pkt->protocol != CORAL_NETPROTO_IPv4 && !coral_config.anon.keep)
	return 0;

    while (pkt->protocol != CORAL_PROTO_UNKNOWN) {
	if (pkt->protocol == CORAL_NETPROTO_IPv4) {
	    struct ip *ip = (struct ip*)pkt->buf;
	    firstL3 = 0;

	    if (pkt->caplen <= offsetof(struct ip, ip_src)) return 1;
	    if (coral_config.anon.src) {
		coral_trunc_anon(&coral_config.anon, &ip->ip_src,
		    pkt->caplen - offsetof(struct ip, ip_src),
		    &old_src, &new_src);
		/* The checksum is before the src addr. */
		update_cksum(&ip->ip_sum, old_src, new_src, 0);
	    }

	    if (pkt->caplen <= offsetof(struct ip, ip_dst)) return 1;
	    if (coral_config.anon.dst) {
		coral_trunc_anon(&coral_config.anon, &ip->ip_dst,
		    pkt->caplen - offsetof(struct ip, ip_dst),
		    &old_dst, &new_dst);
		update_cksum(&ip->ip_sum, old_dst, new_dst, 0);
	    }

	} else if (pkt->protocol == CORAL_IPPROTO_UDP) {
	    struct udphdr *udp = (struct udphdr*)pkt->buf;
	    if (fits(udp, uh_sum, pkt->caplen) && udp->uh_sum != 0) {
		if (coral_config.anon.src)
		    update_cksum(&udp->uh_sum, old_src, new_src, 1);
		if (coral_config.anon.dst)
		    update_cksum(&udp->uh_sum, old_dst, new_dst, 1);
	    }

	} else if (pkt->protocol == CORAL_IPPROTO_TCP) {
	    struct tcphdr *tcp = (struct tcphdr*)pkt->buf;
	    if (fits(tcp, th_sum, pkt->caplen)) {
		if (coral_config.anon.src)
		    update_cksum(&tcp->th_sum, old_src, new_src, 0);
		if (coral_config.anon.dst)
		    update_cksum(&tcp->th_sum, old_dst, new_dst, 0);
	    }

	} else if (coral_proto_layer(pkt->protocol) == 3) {
	    /* non-anonynimizable layer 3 header */
	    if (firstL3 && !coral_config.anon.keep) {
		/* first layer 3 header: discard the packet */
		return 0;

	    } else if (!coral_config.anon.notrunc) {
		/* non-first or kept layer 3 header: truncate it */
		orig->caplen = pkt->buf - orig->buf;
		/* we know enough about IPv6 to keep stuff before first addr */
		if (pkt->protocol == CORAL_NETPROTO_IPv6)
		    orig->caplen += (pkt->caplen >= 8) ? 8 : pkt->caplen;
	    }
	}

	/* look for deeper IPv4 headers */
	if (coral_get_payload(pkt, pay) < 0)
	    return 1;
	pkt = pay;
	pay = &buf[x];
	x = !x;
    }
    return 1;
}

