package CAIDA::UserGuide::UserGuide;
require 5.004;
## $Id: UserGuide.pm,v 1.11 2007/06/06 18:17:52 kkeys Exp $ $Name: release-3-8-1 $
## -----------------------------------------------------------------------
## Perl module:UserGuide.pm
## 
## This Perl module (Traffic Human Computer Interface) provides a
## consistent framework displaying help and diagnostic messages from
## the CoralReef report generator.  It's may role as a module is
## partition code that doesn't belong in either main script or any
## other module and to standardize the format of help information.
## 
## Note: test routines require the Test.pm module or Perl 5.005
##
## Copyright 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
## All Rights Reserved 
##
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
##
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
##
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
##
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
##
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program. Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
##
## Contact: coral-info@caida.org
## ---------------------------------------------------------------------
use CAIDA::UserGuide::UserGuideElements;
# Set up object export condition.  No functions accessible directly.
use Exporter ();
@ISA       = qw(CAIDA::UserGuide::UserGuideElements);

# Define required CVS variables
$cvs_Id = '$Id: UserGuide.pm,v 1.11 2007/06/06 18:17:52 kkeys Exp $';
$cvs_Author = '$Author: kkeys $';
$cvs_Name = '$Name: release-3-8-1 $';
$cvs_Revision = '$Revision: 1.11 $';

# Enable error messages to come from calling script
use Carp;

# Force this module to adhere to safe programming practices.
use strict;
use Text::Wrap;

# argument count types
use constant SHORTCUT   => 0;
use constant DESCRIPTION  => 1;
use constant NOTES  => 2;


# Version of module
my $VERSION = 1.0;

# .   .   .   .   .  Internal object functions  .   .   .   .   .   .   .  

sub _initialize($ ) {
# ----------------------------------------------
# Initialization function for this class.  
# Calls the ancestor's initialization routine
# and then embellishes it.
# ----------------------------------------------
    my $HCI_object = shift;

    # Make initialization from ancestor.
    $HCI_object->SUPER::_initialize();

    # Add header attribute
    $HCI_object->{'HCI_Header'} = [];
    $HCI_object->{'HCI_general_message'} = "";

    # Return embellished object.
    return($HCI_object);
}

sub _print_all_helper ($@) {
# ---------------------------------------------
# Recursive helper function to descend through
# all the entries in the help object and
# print them using the inherited object 
# method.
# ---------------------------------------------
    my $HCI_object = shift;
    my @entries = @_;
    if (@entries) {
	my $entry = shift @entries;
	$HCI_object->format_help_entry($entry);
	$HCI_object->_print_all_helper(@entries);
    }
}


# .   .   .   .   .  User Method Subroutines  .   .   .   .   .   .   .   .  

sub new ($ ) {
# ----------------------------------------------
# Constructor for object that deals entire help
# session.  inherits from Entry object and then
# embellishes it.
# ----------------------------------------------
    # retrieve parameters
    my $class_name = shift;
    
    # allocate space for object and bless it.
    my	$HCI_object = {};
    bless $HCI_object, $class_name;

    $HCI_object->_initialize();
    
    # Return object reference
    return($HCI_object);
}

sub output_general_help($ ) {
# ----------------------------------------------
# This method displays general help information
# that might be given in respond to a -h -? or
# --help request.
# ----------------------------------------------
    my $HCI_object = shift;

    $HCI_object->
	format_help_text($HCI_object->{'HCI_general_message'} . 
			 " For more usage information enter $0 --help");

}



sub output_help_header($ ) {
# ----------------------------------------------
# This method returns the "header" for the help
# information.  This is assumed to have the same
# formatting as the help entries themselves.
# ----------------------------------------------
    my $HCI_object = shift;

    my $header_ref = $HCI_object->{'HCI_Header'};
    $HCI_object->SUPER::_row_help_print($header_ref->[0],
					$header_ref->[1],
					$header_ref->[2],
					$header_ref->[3]
				       );
    $HCI_object->SUPER::_row_divider_print();
}

sub list_arguments($ ) {
# ----------------------------------------------
# Accessor method to return a list of all the
# arguments available in the User Guide.
# ----------------------------------------------
    my $HCI_object = shift;

    return(sort(keys(%{$HCI_object->{'HCI_data'}})));
}

sub output_argument_list($ ) {
# ----------------------------------------------
# This method just spews out all avaiiable help
# information.  It will probably not be very 
# practical for most cases, but is provided for
# the desperate.
# ----------------------------------------------
    my $HCI_object = shift;
    my ($argument_list, $prompt);

    $HCI_object->output_general_help();
    print STDERR "\n";
    $argument_list = join(', ', $HCI_object->list_arguments());
    $prompt = join(' ', "List of available arguments follow.  For more",
		   "information on argument, type --help <argument>: "
		  );
    $HCI_object->format_help_text($prompt . $argument_list);
}

sub output_all_help($ ) {
# ----------------------------------------------
# This method just spews out all avaiiable help
# information.  It will probably not be very 
# practical for most cases, but is provided for
# the desperate.
# ----------------------------------------------
    my $HCI_object = shift;

    my @entries = $HCI_object->list_arguments();

    $HCI_object->output_general_help();
    print STDERR "\n";
    $HCI_object->output_help_header();
    $HCI_object->_print_all_helper(@entries);
}

sub output_help_entry($$ ) {
# ----------------------------------------------
# Simply produce the help information associated
# with a particular option.
# ----------------------------------------------
    my $HCI_object = shift;
    my $argument = shift;
    
    $HCI_object->output_help_header();
    $HCI_object->format_help_entry($argument);
}

sub process_request($$ ) {
# ----------------------------------------------
# Routine to provide generic handling of help
# requests.  If the name of a known argument
# is given, it displays the information on that
# item.  If the argument 'list' is given, 
# the entire list of arguments is provided.
# if the argument 'all' is given, then a 
# verbose listing is provided.
# ---------------------------------------------
    my $HCI_object = shift;
    my $request_value = shift;

    if ((not defined($request_value)) or ($request_value =~ /list/i)) {
	$HCI_object->output_argument_list();
   }
    elsif ($request_value =~ /all/i) {
	$HCI_object->output_all_help();
    }
    elsif (grep {$_ =~ /$request_value/i} $HCI_object->list_arguments()) {
	$HCI_object->output_help_entry($request_value);
    } else {
	print STDERR "ERROR: Unrecognized request for information\n";
	$HCI_object->output_general_help();
    }
}
		     
	
# =============================
# POD Documentation for Module

__END__

=head1 NAME

UserGuide.pm - Main class for providing usage information for t2_report

=head1 SYNOPSIS

    use CAIDA::UserGuide::UserGuide;

    # Create a sample object to store data and an object combine sets.
    my HCI_obj = new CAIDA::UserGuide::UserGuide();

    # Store general usage text
    HCI_obj->{'HCI_general_message'} = "$0 ....";
    HCI_obj->{'HCI_Header'} = ['header1', 'header2', ...];
    HCI_obj->{'HCI_data'} = {option1 => ['o', "Option text ..."],
			     ....
			    };

    # Process a help request
    HCI_obj->process_request($option);
	
=head1 DESCRIPTION

The UserGuide module classes are a preliminary attempt to manage usage
information about a complex set of command line options in a
systematic and general manner.  The scheme relies on two levels of
methods: at the UserGuideElment level, methods are intended to process
particular requests for information.  The UserGuide level handles the
general request and interprets it before handing off the work to the
lower object classes.

Presently data is stored directly in Perl data structures.  Eventually
this too will be abstracted away.  For simple applications, data can
be added by some global declarations at the top of the script.
However, one of the great advantages of the UserGuide module system is
the ability to create ancestor classes that contain all that
information in a unique place without cluttering either the main
script of the UserGuide modules.  An example of this in included in
CoralReef tree in the file ReportUserGuide.pm.  ReportUserGuide is an
instance of the class UserGuide, but presently doesn't overload any of
the methods (besides new.)

=head1 EXAMPLE

See synopsis and ReportUserGuide.pm for usage.  

=head1 AUTHOR

CoralReef Development team, CAIDA Group <coral-info@caida.org>

=head1 COPYRIGHT

Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
All Rights Reserved 

Permission to use, copy, modify and distribute any part of this
CoralReef software package for educational, research and non-profit
purposes, without fee, and without a written agreement is hereby
granted, provided that the above copyright notice, this paragraph
and the following paragraphs appear in all copies.

Those desiring to incorporate this into commercial products or use
for commercial purposes should contact the Technology Transfer
Office, University of California, San Diego, 9500 Gilman Drive, La
Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.

IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
THE POSSIBILITY OF SUCH DAMAGE.

THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
ANY PATENT, TRADEMARK OR OTHER RIGHTS.

The CoralReef software package is developed by the CoralReef
development team at the University of California, San Diego under
the Cooperative Association for Internet Data Analysis (CAIDA)
Program. Support for this effort is provided by the CAIDA grant
NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
N66001-01-1-8909, and by CAIDA members.

Report bugs and suggestions to coral-bugs@caida.org.

=cut

# .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   . 
1; ##must be last line in the file
