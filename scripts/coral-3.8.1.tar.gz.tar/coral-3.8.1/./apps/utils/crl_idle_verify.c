/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 * crl_idle_verify.c - the first realtime CORAL analysis program. it just
 *                 checks to make sure incoming atm cells are valid
 *                 idle cells.  does some stats on ones that arent.
 *
 * $Id: crl_idle_verify.c,v 1.73 2007/06/06 18:17:36 kkeys Exp $
 *
 */



static const char RCSid[]="$Id: crl_idle_verify.c,v 1.73 2007/06/06 18:17:36 kkeys Exp $";

#include "config.h"
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <sys/time.h>
#include <sys/errno.h>
#include <signal.h>
#include <errno.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netinet/in_systm.h>
#include <netinet/ip.h>

#include "libcoral.h"

int done = 0;

static void quit(int arg) {
    done = 1;
}

static void inline print_cell(unsigned int n, coral_atm_cell_t *cell,
    size_t size)
{
    printf("%-11d\n", n);
    coral_print_data(8, (u_char*)cell, size);
    printf("\n");
}

int main(int argc, char *argv[])
{
    coral_atm_cell_t *blk, *cell;
    size_t cell_size;
    int cell_count;
    u_int i, c_err = 0, last_bad = 0, tot_drp = 0;
    coral_iface_t *iface;
    coral_blk_info_t *binfo;
    coral_pkt_buffer_t linkpkt, netpkt;
    double lasttime = 0;
    double thistime;
    u_int cell_cnt = 1;
    struct timespec prev_end, dt;
    int verbosity;
    
    signal(SIGINT, quit);

    prev_end.tv_sec = 0;
    prev_end.tv_nsec = 0;

    coral_set_api(CORAL_API_BLOCK);
    coral_set_duration(0);

    if (coral_config_arguments(argc, argv) < 0)
	exit(-1);

    if (coral_open_all() <= 0)
	exit(-1);

    if (coral_start_all() < 0)
	exit(-1);

    verbosity = coral_get_verbosity();

    fprintf(stdout, "started gathering... \n");
    while (!done) {
#if 0
	gettimeofday(&start, 0);
#endif
	if (!(iface = coral_read_block_all(&binfo, &blk, NULL))) {
	    done = 1;
	} else {
	    binfo->tbegin.tv_sec = ntohl(binfo->tbegin.tv_sec);
	    binfo->tbegin.tv_nsec = ntohl(binfo->tbegin.tv_nsec);
	    binfo->tend.tv_sec = ntohl(binfo->tend.tv_sec);
	    binfo->tend.tv_nsec = ntohl(binfo->tend.tv_nsec);
/*
printf("0x%8.8x 0x%8.8x\n0x%8.8x 0x%8.8x\n", 
       binfo->tbegin.tv_sec,
       binfo->tbegin.tv_nsec,
       binfo->tend.tv_sec,
       binfo->tend.tv_nsec);
*/
	    /* inter block time lossage */
	    memcpy(&dt, &binfo->tbegin, sizeof(dt));
	    timespecsub(&dt, &prev_end);
	    prev_end.tv_sec = binfo->tend.tv_sec;
	    prev_end.tv_nsec = binfo->tend.tv_nsec;

	    cell_size = coral_cell_size(iface);
	    cell_count = ntohl(binfo->cell_count);

	    /* cell procesing */
	    for (i = 0; i < cell_count && !done; i++) {
		cell = (char*)blk + i * cell_size;
		thistime = coral_read_clock_double(iface,
		    coral_cell_time(iface, cell));

		if (thistime < lasttime)
		    printf("error dt: %f i: %d\n", thistime - lasttime, i);
		if (thistime > lasttime + 10.0)
		    printf("error dt: %f i: %d\n", thistime - lasttime, i);


		if ((thistime < lasttime) ||
		    !coral_cell_to_pkt(iface, cell, &linkpkt) ||
		    coral_get_payload_by_proto(&linkpkt, &netpkt, CORAL_NETPROTO_IP) < 0 ||
		    ((struct ip*)netpkt.buf)->ip_v != 4 ||
		    ((struct ip*)netpkt.buf)->ip_hl < 5)
		{
		    c_err++;
		    if (verbosity && verbosity <= 3) {
			printf("           time: %.7f\tdt:%.9f\n", thistime, 
			       thistime - lasttime);
			printf("d = %d  &header %p   &cell %p  dcb %#x\n", 
			       (cell_cnt + i) - last_bad, (void*)binfo, cell, 
			       (char*)cell - (char*)binfo);
			last_bad = cell_cnt + i;
			print_cell(cell_cnt + i, cell, cell_size);
		    }
		}
		lasttime = thistime;
		if (verbosity > 3) {
		    printf("           time: %f\n", thistime);
		    print_cell(cell_cnt + i, cell, cell_size);
		}
	    }
	    cell_cnt += ntohl(binfo->cell_count);
	    tot_drp += ntohl(binfo->cells_lost);
	    fprintf(stderr, "total %d / crap %d / bad %.4f%% / loss %d "
		    "/ %.4f dt:%.9f\n", 
		    cell_cnt, c_err, 
		    (float)c_err * 100 / (float)cell_cnt, 
		    (int)ntohl(binfo->cells_lost), 
		    (float)tot_drp / (float)cell_cnt, 
		    timespectodouble(&dt));

/*	    fprintf(stderr, "start %.9f\t end %.9f\n", 
		    timespectodouble(&binfo->tbegin)
		    timespectodouble(&binfo->tend));*/
	}
    }
    
    fprintf(stderr, "\n");
#if 0
    fprintf(stderr, "\n--------------------------------------------------------\n");
    fprintf(stderr, "total     calls: %d\n", b_tot);
    fprintf(stderr, "cumulative time: %d\n", b_cumu);
    fprintf(stderr, "average    time: %d\n", b_cumu/b_tot);
    fprintf(stderr, "max        time: %d\n", b_max);
    fprintf(stderr, "min        time: %d\n", b_min);
#endif
    fprintf(stderr, "total cells/cell errors/pct.bad %d / %d / %.4f\n", 
	    cell_cnt, c_err,
	    (float)c_err * 100 / (float)cell_cnt);
    coral_stop_all();
    coral_close_all();
    
    fprintf(stderr, ".... done ....\n");
    return 0;
}
