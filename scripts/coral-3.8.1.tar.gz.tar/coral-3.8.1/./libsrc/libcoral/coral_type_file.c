/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */


#include "config.h"
#include "coraldefs.h"
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <time.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
/* #include <sys/ioctl.h> */
#include <sys/mman.h>
#include <sys/stat.h>

#ifdef HAVE_LIBZ
# include <zlib.h>
#endif

#ifdef HAVE_LIBPCAP
# include <pcap.h>
#endif
#ifndef TCPDUMP_MAGIC
# define TCPDUMP_MAGIC 0xA1B2C3D4ul
#endif

#include "libcoral.h"
#include "libcoral_priv.h"

static const char RCSid[] = "$Id: coral_type_file.c,v 1.139 2007/06/06 18:17:55 kkeys Exp $";

/* Old MCI fmt had no file header and a 512 byte blk header starting with: */
struct mci_oc3_format {
    int32_t used;
    int16_t cardnum;
    int8_t cardidx;
};

/* Old NLANR fmt had no file header and a 512 byte blk header starting with: */
struct nlanr_oc3_format {
    uint16_t flag;
    uint16_t cellcount;
    uint16_t interface;
};

/* Seek forward len bytes on a readable file, by writing into buf if needed.
 * Returns number of bytes actually skipped, or -1 for error.
 */
static ssize_t coral_rseek(coral_source_t *src, void *buf, size_t want)
{
    /* note: gzseek is apparently buggy: SEEK_CUR acts like SEEK_SET. */
    if (src->can_seek) {
	off_t old, new;
	old = lseek(src->fd, 0, SEEK_CUR);
	new = lseek(src->fd, want, SEEK_CUR);
	if (new == (off_t)-1)
	    return -1;
	return new - old;
    } else {
	return coral_readall(src, buf, want);
    }
}

/* like read(), from a src, and never does a partial read unless EOF is reached. */
ssize_t coral_readall(coral_source_t *src, void *buf, size_t want)
{
    ssize_t have = 0;
    ssize_t len;

    while (want > 0) {
#ifdef HAVE_LIBZ
	if (src->file) {
	    len = gzread(src->file, (char*)buf + have, want);
	    if (len < 0) {
		if (!errno) /* gzread can fail w/o setting errno */
		    errno = CORAL_EGZIP;
		return len;
	    }
	} else
#endif
	{
	    len = read(src->fd, (char*)buf + have, want);
	    if (len < 0) return len;
	}

	if (len == 0) return have;
	have += len;
	want -= len;
    }
    return have;
}

int coral_file_common_init(coral_source_t *src, size_t bufsize)
{
    struct stat statbuf;

    if (!src->ubase && !(src->ubase = (char *)malloc(bufsize))) {
	coral_diag(0, ("coral_open: malloc buffer: %s\n", strerror(errno)));
	return -1;
    }

    src->can_seek = (lseek(src->fd, 0, SEEK_CUR) == 0);

    /* On FreeBSD 5.4 et al, lseek incorrectly reports success on a fifo. */
    fstat(src->fd, &statbuf);
    if (statbuf.st_mode & S_IFIFO)
	src->can_seek = 0;
#if 0
    coral_diag(1, ("%s: can_reopen=%d, can_seek=%d\n",
	src->filename, src->can_reopen, src->can_seek));
#endif

#ifdef HAVE_LIBZ
    {
	int need_gz = 0;
	int n;
	if (src->can_seek) {
	    /* If file is seekable, gzdopen would prevent seeking, so don't do
	     * it unless needed */
	    if ((n = read(src->fd, src->ubase, 2)) < 2) {
		coral_diag(0, ("%s: %s\n", src->filename,
		    n < 0 ? strerror(errno) : "empty"));
		return -1;
	    }
	    lseek(src->fd, 0, SEEK_SET);
	    need_gz = (memcmp(src->ubase, GZIP_MAGIC, 2) == 0);
	} else {
	    need_gz = 1;
	}
	if (need_gz) {
	    errno = CORAL_EGZIP;
	    src->file = gzdopen(src->fd, "rb");
	    if (!src->file) {
		coral_diag(0, ("%s: %s\n", src->filename, strerror(errno)));
		return -1;
	    }
	    src->can_seek = 0;
	}
	/* Do NOT set src->fd = -1; it's needed by coral_fd(). */
    }
#endif
    return 0;
}

int coral_infer_capture_time(coral_source_t *src)
{
    int i;
    char *p;
    struct tm *tm;
    char scratch[32];
    time_t cap_time = 0;
    long min = 883612800;   /* 1998-01-01, before HWB started taking
			     * traces with seconds in the filename */
    p = src->filename;
    while (*p) {
	if (!isdigit(*p)) { p++; continue; }
	cap_time = strtol(p, &p, 10);
	if (cap_time >= min && cap_time < time(NULL)) break;
	cap_time = 0;
    }
    if (cap_time) { 
	tm = gmtime(&cap_time);
	strftime(scratch, sizeof(scratch), "%Y-%m-%d %H:%M:%S", tm);
	coral_diag(1, ("%s: using capture time in filename: %s UTC\n",
	    src->filename, scratch));
	for (i = 0; i < src->iface_count; i++) {
	    coral_iface_t *iface = cinst[src->id[i]];
	    if (!iface->iface_info.capture_tv.tv_sec)
		iface->iface_info.capture_tv.tv_sec = cap_time;
	}
    }
    return !!cap_time;
}

/* Prepare to read from a coral trace file. */
/* Note on protocol rules:
 * Versions 33 and earlier contained only file-wide rules.
 * Versions 34 and later contain rules for each interface first, in the same
 * order as the iface_infos; the number of rules per iface is given in its
 * iface_info.  These are followed by the file-wide rules.
 */
static int coral_file_init(coral_source_t *src)
{
    int iface_count, rule_count, iface_rule_count, i, j;
    ssize_t need;	    /* signed so (len < need) works when (len == -1) */
    ssize_t len;
    int zero_cap_times = 0;
    const char *need_reopen = NULL;
    coral_iface_t *iface = NULL;
    coral_file_header_t *cfh;
    coral_proto_rule_t *rule;
    coral_proto_rulenode_t *node;
    coral_proto_rule_list_t *proto_rules;
    char *buffer;

    if (src->fd >= 0) {
	/* already open */
    } else if (strcmp(src->filename, "-") == 0) {
	src->fd = STDIN_FILENO;
    } else {
	if ((src->fd = open(src->filename, O_RDONLY, 0)) < 0) {
	    coral_diag(0, ("coral_open: %s: open: %s\n",
		src->filename, strerror(errno)));
	    return -1;
	}
	coral_diag(4, ("coral_open: %s: fd %d\n", src->filename, src->fd));
    }

    if (coral_file_common_init(src, CORAL_MAX_HBLK_SIZE) < 0)
	return -1;

    buffer = src->ubase;
    need = CORAL_FILE_HEADER_SIZE;
    len = coral_readall(src, buffer, need);

    if (src->type.coral_type == CORAL_TYPE_NONE) {
	/* Try to identify file of unknown type */
	if (*(u_int*)buffer == TCPDUMP_MAGIC ||
	    *(u_int*)buffer == crl_swapl(TCPDUMP_MAGIC))
	{
#ifdef HAVE_LIBPCAP
	    src->type = coral_src_type_pcap;
	    need_reopen = "pcap";
#else /* HAVE_LIBPCAP */
	    coral_diag(0, ("%s: pcap support is disabled\n", src->filename));
	    return -1;
#endif /* HAVE_LIBPCAP */
	} else if (coral_header_is_dagfile(buffer, len)) {
	    src->type = coral_src_type_dagfile;
	    need_reopen = "dag";
	}

	if (need_reopen) {
	    if (!src->can_reopen) {
		coral_diag(0, ("%s: To read %s format from a non regular file, "
		    "you must use the prefix \"%s:\".\n",
		    src->filename, need_reopen, need_reopen));
		return -1;
	    }
# ifdef HAVE_LIBZ
	    if (src->file)
		gzclose(src->file);
	    else
# endif /* HAVE_LIBZ */
		close(src->fd);
	    free(src->ubase);
	    src->ubase = NULL;
	    src->fd = -1;
	    src->file = NULL;
	    return src->type.init(src);
	}
	src->type.coral_type = CORAL_TYPE_FILE; /* crl file */
    }

    if (len < need) {
	coral_diag(0, ("%s: %s\n", src->filename,
	    len < 0 ? coral_strerror(src->file, errno) :
	    "premature EOF in main file header"));
	return -1;
    }

    cfh = (coral_file_header_t *)buffer;

    src->version = ntohl(cfh->version);

    if (ntohl(cfh->magic) != CORAL_MAGIC &&
	src->version != CORAL_VERSION_OLD_ANY)
    {
	coral_diag(0, ("%s: not a coral file (suggestion: run "
	    "\"crl_guess %s\" to figure out what kind of file it is)\n",
	    src->filename, src->filename));
	return -1;
    }

    /* figure out which format it's in */
    if (src->version == CORAL_VERSION_OLD_ANY) {
	/* hack to determine what type of old trace this is */
#if 0
	struct mci_oc3_format *mci = cfh;
	struct nlanr_oc3_format *nla = cfh;
#endif

	int32_t mci_used;	/* has to be < 0xffff0000 */
	int16_t mci_cardnum;	/* pci bus handle, > ?7? */
	int8_t  mci_cardidx;	/* 0-1 */
	uint16_t nla_flag;	/* either 0 or 0xffff */
	uint16_t nla_cellcount;	/* 17408 */
	uint16_t nla_interface;	/* 0-1 */

	mci_used = ntohl(((int32_t*)cfh)[0]);
	mci_cardnum = ntohs(((int16_t*)cfh)[2]);
	mci_cardidx = ntohs(((int8_t*)cfh)[6]);
	nla_flag = ((uint16_t*)cfh)[0];
	nla_cellcount = ntohs(((uint16_t*)cfh)[1]);
	nla_interface = ntohs(((uint16_t*)cfh)[2]);

	/* preread > 0 means we already have part of first blk */
        src->preread = len;

	/* old formats always had exactly 2 interfaces */
	while (src->iface_count < 2) {
	    if (coral_new_instance(src, src->iface_count) < 0)
		return -1;
	    src->iface_count++;
	}

	if (
	    /* things are false in mci traces */
	    (mci_cardnum < 6 || mci_cardidx > 4)
	    /* things are true for old nlanr/caida traces */
	    && (nla_flag == 0xffff /*|| nla_flag == 0*/)	
	    && nla_cellcount == 17408
	    && (nla_interface == 0 || nla_interface == 1))
	{
	    coral_diag(1, ("%s: guessing old nlanr format"
		    " (OC3 fatm, LE timestamps)\n", src->filename));
	    /* initialization specific to NLANR format */
	    src->version = CORAL_VERSION_OLD_NLANR;
	    for (i = 0; i < src->iface_count; i++) {
		iface = cinst[src->id[i]];
		iface->iface_info.sw_type       = SW_TYPE_NLANR;
		iface->iface_info.sw_version    = 0;
		iface->iface_info.time_is_le    = 1;
		/* iface->atm_header_is_le; might be true? */
	    }

	} else if (
	    /* things that are true for mci traces */
	    (mci_used < 20000 && mci_used > 0)
	    && (mci_cardidx >= 0 && mci_cardidx < 4))
	{
	    coral_diag(1, ("%s: guessing mci format"
		    " (OC3 fatm, BE timestamps)\n", src->filename));
	    /* initialization specific to MCI format */
	    src->version = CORAL_VERSION_OLD_MCI;
	    for (i = 0; i < src->iface_count; i++) {
		iface = cinst[src->id[i]];
		iface->iface_info.sw_type       = SW_TYPE_MCI;
		iface->iface_info.sw_version    = 0;
		iface->iface_info.time_is_le    = 0;
		/* iface->atm_header_is_le; might be true? */
	    }

	} else {
	    coral_diag(0, ("%s: invalid coral file\n", src->filename));
	    if (coral_verbosity >= 1)
		coral_fprint_data(coral_get_errfile(), 2, (u_char*)cfh, 16);
	    return -1;
	}

	/* initialization common to NLANR and MCI formats */
	for (i = 0; i < src->iface_count; i++) {
	    iface = cinst[src->id[i]];
	    coral_init_atm_iface(iface);
	    iface->iface_type = &coral_iface_type_fatm;
	    iface->iface_info.hw_type		= CORAL_TYPE_FATM;
	    iface->iface_info.hw_version	= 0;
	    iface->iface_info.fw_type		= 0;
	    iface->iface_info.fw_version	= 0;
	    iface->iface_info.iomode.flags	= CORAL_RX_UNKNOWN;
	    iface->iface_info.iomode.first_n	= ATM_PAYLOAD_SIZE;
	    iface->iface_info.capture_time	= 0;
	    iface->iface_info.bandwidth		= KBPS_OC3c;
	    iface->iface_info.datalink		= CORAL_PROTO_UNKNOWN;
	    iface->iface_info.physical		= CORAL_PHY_ATM;
	    iface->iface_info.tzoff		= 0;
	    iface->iface_info.capture_tv.tv_sec = 0;
	    iface->iface_info.capture_tv.tv_usec= 0;
	    zero_cap_times++;
	}

    } else if (CORAL_VERSION_IS_NEW(src->version)) {
	/* New versions are all very similar to each other */
	coral_iface_info_t *iinfo;
	size_t size;
	int badphy = 0;
	const char *label;
	/* preread < 0 means we must skip rest of file header to find 1st blk */
        src->preread = len - ntohl(cfh->header_size);
        iface_count = ntohs(cfh->iface_info_count);
        rule_count = ntohs(cfh->proto_rule_count);

	if (iface_count >= CORAL_MAXOPEN) {
	    coral_diag(0, ("%s contains %d interfaces, max is %d.\n",
		src->filename, iface_count, CORAL_MAXOPEN));
	    return -1;
	}

	if (*cfh->desc)
	    src->desc = strdup(cfh->desc);
	if (*cfh->encoding) {
	    src->encoding = strdup(cfh->encoding);
	    src->encoding_version = ntohl(cfh->encoding_version);
	}

	switch (src->version) {
	    case CORAL_VERSION_3:   size = CORAL_V3_IFACE_INFO_SIZE;  break;
	    case CORAL_VERSION_4:   size = CORAL_V4_IFACE_INFO_SIZE;  break;
	    case CORAL_VERSION_5:   size = CORAL_V5_IFACE_INFO_SIZE;  break;
	    case CORAL_VERSION_6:   size = CORAL_V6_IFACE_INFO_SIZE;  break;
	    case CORAL_VERSION_7:   size = CORAL_V7_IFACE_INFO_SIZE;  break;
	    case CORAL_VERSION_8:   size = CORAL_V8_IFACE_INFO_SIZE;  break;
	    case CORAL_VERSION_9:   size = CORAL_V9_IFACE_INFO_SIZE;  break;
	    case CORAL_VERSION_33:  size = CORAL_V33_IFACE_INFO_SIZE; break;
	    case CORAL_VERSION_34:  size = CORAL_V34_IFACE_INFO_SIZE; break;
	    default:		    size = sizeof(coral_iface_info_t);  break;
	}
	/* iface_count < CORAL_MAXOPEN, so we know they'll all fit in buffer. */
	need = iface_count * size;
	len = coral_readall(src, buffer, need);
	cfh = NULL;  /* *cfh was just overwritten; this will catch bad use */
	if (len < need) {
	    coral_diag(0, ("%s: %s\n", src->filename,
		len < 0 ? coral_strerror(src->file, errno) :
		"premature EOF in iface info"));
	    return -1;
	}
	src->preread += len;

	for (i = 0; i < iface_count; i++) {
	    if (i >= src->iface_count) {
		if (coral_new_instance(src, i) < 0)
		    return -1;
		src->iface_count++;
	    }
	    iinfo = (coral_iface_info_t*)(buffer + i * size);
	    iface = cinst[src->id[i]];
	    iface->iface_info.hw_type		= ntohl(iinfo->hw_type);
	    iface->iface_info.hw_version	= ntohl(iinfo->hw_version);
	    iface->iface_info.fw_type		= ntohl(iinfo->fw_type);
	    iface->iface_info.fw_version	= ntohl(iinfo->fw_version);
	    iface->iface_info.sw_type		= ntohl(iinfo->sw_type);
	    iface->iface_info.sw_version	= ntohl(iinfo->sw_version);
	    iface->iface_info.iomode.flags	= ntohl(iinfo->iomode.flags);
	    iface->iface_info.iomode.first_n	= ntohl(iinfo->iomode.first_n);
	    if (src->version < CORAL_VERSION_7) {
		iface->iface_info.iomode.first_n *= ATM_PAYLOAD_SIZE;
	    }
	    iface->iface_info.capture_time	= 0;/* replaced by capture_tv */
	    iface->iface_info.bandwidth		= ntohl(iinfo->bandwidth);
	    iface->iface_info.time_is_le	= ntohl(iinfo->time_is_le);

	    iface->iface_info.datalink = (src->version >= CORAL_VERSION_6) ?
		ntohl(iinfo->datalink) : CORAL_PROTO_UNKNOWN;

	    /* Old files said ATM_AAL5 when they should've said ATM_RFC1483 */
	    if (iface->iface_info.datalink == CORAL_DLT_ATM_AAL5)
		iface->iface_info.datalink = CORAL_PROTO_UNKNOWN;

	    iface->iface_info.tzoff = (src->version >= CORAL_VERSION_5) ?
		ntohl(iinfo->tzoff) : 0;

	    if (src->version >= CORAL_VERSION_9) {
		iface->iface_info.capture_tv.tv_sec =
		    ntohl(iinfo->capture_tv.tv_sec);
		iface->iface_info.capture_tv.tv_usec =
		    ntohl(iinfo->capture_tv.tv_usec);
	    } else {
		iface->iface_info.capture_tv.tv_sec =
		    ntohl(iinfo->capture_time);
		iface->iface_info.capture_tv.tv_usec = 0;
	    }
	    if (!iface->iface_info.capture_tv.tv_sec)
		zero_cap_times++;

	    if (src->version >= CORAL_VERSION_33) {
		iface->iface_info.physical = ntohl(iinfo->physical);
	    } else {
		iface->iface_info.physical = CORAL_PHY_ATM;
	    }

	    if (src->version >= CORAL_VERSION_34) {
		iface->iface_info.proto_rule_count =
		    ntohs(iinfo->proto_rule_count);
	    } else {
		iface->iface_info.proto_rule_count = 0;
	    }

	    switch (iface->iface_info.hw_type) {
	    case CORAL_TYPE_FATM:
		label = "fatm";
		if (iface->iface_info.physical != CORAL_PHY_ATM)
		    badphy++;
		iface->iface_type = &coral_iface_type_fatm;
		coral_init_atm_iface(iface);
		break;
	    case CORAL_TYPE_POINT:
		label = "point";
		if (iface->iface_info.physical != CORAL_PHY_ATM)
		    badphy++;
		iface->iface_type = &coral_iface_type_point;
		coral_init_atm_iface(iface);
		break;
	    case CORAL_TYPE_DAG:
		label = "dag";
		switch (iface->iface_info.physical) {
		case CORAL_PHY_ATM:
		    iface->iface_type = &coral_iface_type_dag_atm;
		    coral_init_atm_iface(iface);
		    break;
		case CORAL_PHY_POS:
		    iface->iface_type = &coral_iface_type_dag_pos;
		    break;
		default:
		    badphy++;
		}
		break;
	    default:
		coral_diag(0, ("%s interface %d: unknown hardware type: %d\n",
		    src->filename, i, iface->iface_info.hw_type));
		return -1;
	    }

	    if (badphy) {
		coral_diag(0, ("coral_open: %s[%d]: %s, illegal "
		    "physical layer %s\n", src->filename, i, label,
		    coral_proto_str(iface->iface_info.physical)));
		return -1;
	    }
	    coral_diag(4, ("coral_open: %s %d: %s\n", src->filename, i, label));

	}

	size = sizeof(coral_proto_rule_t);
	need = rule_count * size;
	len = coral_readall(src, buffer, need);
	if (len < need) {
	    coral_diag(0, ("%s: %s\n", src->filename,
		len < 0 ? coral_strerror(src->file, errno) :
		"premature EOF in vpvc rules"));
	    return -1;
	}
	src->preread += len;

	j = -1;
	iface_rule_count = 0;
	for (i = 0; i < rule_count; i++) {
	    rule = (coral_proto_rule_t*)(buffer + i * size);
	    node = malloc(sizeof(*node));
	    if (!node) {
		coral_diag(0, ("coral_open (%s): out of memory\n", src->filename));
		return -1;
	    }
	    node->rule.subif	= ntohl(rule->subif);
	    node->rule.subifmask= ntohl(rule->subifmask);
	    node->rule.protocol = ntohl(rule->protocol);
	    node->rule.allow    = rule->allow;
	    node->next = NULL;

	    /* If the count for the current iface has been reached,
	     * on to the next iface. */
	    while (!iface_rule_count && j+1 < iface_count) {
		iface_rule_count = cinst[src->id[++j]]->iface_info.proto_rule_count;
	    }

	    /* Append to current iface if there is one, to src if not. */
	    if (iface_rule_count) {
		proto_rules = &cinst[src->id[j]]->proto_rules;
		iface_rule_count--;
	    } else {
		proto_rules = &src->proto_rules;
	    }

	    if (proto_rules->tail)
		((coral_proto_rulenode_t*)proto_rules->tail)->next = node;
	    else
		proto_rules->head = node;
	    proto_rules->tail = node;
	}

    } else {
	coral_diag(0, ("%s: unknown coral version 0x%lx\n", 
	    src->filename, src->version));
	return -1;
    }

    if (iface->iface_type->init)
	iface->iface_type->init(iface);

    if (zero_cap_times)
	coral_infer_capture_time(src);

    coral_file_check_iomode(src);

    return 0;
}

/* Verify that <src>'s iomode is compatible with each of its interfaces.
 * If an iface's mode is unknown, default to src's. */
void coral_file_check_iomode(coral_source_t *src)
{
    coral_iface_t *iface;
    int i, src_n, iface_n;

#if 0
    coral_diag(1, ("%s: %s", src->filename,
	    coral_proto_str(src->dev_config.physical)));
    coral_diag(1, (", %s\n",
	    coral_proto_str(src->dev_config.datalink)));
#endif

    for (i = 0; i < src->iface_count; i++) {
	iface = cinst[src->id[i]];

#if 0
	coral_diag(1, ("%s[%d]: %s", src->filename, i,
		coral_proto_str(iface->iface_info.physical)));
	coral_diag(1, (", %s\n",
		coral_proto_str(iface->iface_info.datalink)));
#endif
	if (src->dev_config.physical != CORAL_PROTO_UNKNOWN &&
	    src->dev_config.physical != iface->iface_info.physical)
	{
	    if (iface->iface_info.physical != CORAL_PROTO_UNKNOWN)
		coral_diag(1, ("warning: overriding physical %s on %s[%d]\n",
		    coral_proto_str(iface->iface_info.physical), src->filename, i));
	    iface->iface_info.physical = src->dev_config.physical;
	}

	if (src->dev_config.datalink != CORAL_PROTO_UNKNOWN &&
	    src->dev_config.datalink != iface->iface_info.datalink)
	{
	    if (iface->iface_info.datalink != CORAL_PROTO_UNKNOWN)
		coral_diag(1, ("warning: overriding datalink %s on %s[%d]\n",
		    coral_proto_str(iface->iface_info.datalink), src->filename, i));
	    iface->iface_info.datalink = src->dev_config.datalink;
	}

	if (iface->iface_info.iomode.flags & CORAL_RX_UNKNOWN) {
	    coral_diag(1, ("%s: warning: unknown options used"
		" to record interface %d\n", src->filename, i));
	    continue;
	} else if (src->dev_config.iomode.flags & CORAL_RX_UNKNOWN) {
	    /* user didn't specify, we'll use whatever is in the file */
	    continue;
	}
	src_n = src->dev_config.iomode.first_n;
	iface_n = iface->iface_info.iomode.first_n;
	if (iface->iface_info.hw_type == CORAL_TYPE_FATM ||
	    iface->iface_info.hw_type == CORAL_TYPE_POINT ||
	    iface->iface_info.hw_type == CORAL_TYPE_DAG)
	{
	    src_n = divup(src_n, ATM_PAYLOAD_SIZE);
	    iface_n = divup(iface_n, ATM_PAYLOAD_SIZE);
	}
	if (((src->dev_config.iomode.flags ^ iface->iface_info.iomode.flags) &
		~(CORAL_TX | CORAL_RX | CORAL_RX_ECHO)) ||
	    (!(src->dev_config.iomode.flags & CORAL_RX_USER_ALL) &&
		src_n > iface_n))
	{
	    char iomode_buffer[CORAL_FORMAT_IOMODE_LEN];
	    coral_diag(1, ("warning: requested options do not match those used"
		" to record interface %d of %s\n", i, src->filename));
	    coral_format_iomode(iomode_buffer, &src->dev_config.iomode);
	    coral_diag(1, ("    (requested: %s)\n", iomode_buffer));
	    coral_format_iomode(iomode_buffer, &iface->iface_info.iomode);
	    coral_diag(1, ("    (recorded:  %s)\n", iomode_buffer));
	}
    }
}

#if 0
# define debug_file_offset(label, src, need) \
	coral_diag(0, ("nextblk %s: at %ld, need %ld\n", \
	    label, (long)lseek(src->fd, 0, SEEK_CUR), need))
#else
# define debug_file_offset(label, src, need)	do { /* empty */ } while (0)
#endif

static coral_iface_t *coral_file_nextblk(coral_source_t *src,
    coral_blk_info_t **binfop, coral_atm_cell_t **cellp, int endonly)
{
    ssize_t len;
    ssize_t need = 0;	    /* signed so (len < need) works when (len == -1) */
    int interface;	    /* interface number within src */
    int atm_header_needs_swapping;
    coral_iface_t *iface;
    char *result;
    coral_blk_info_t *binfo;
    uint32_t blk_size, cell_count;

retry:
    endonly = endonly && src->can_seek;

    /* If time-sorted reading api stole ubase, we must alloc a new one. */
    if (!src->ubase) {
	src->ubase = (char *)malloc(CORAL_MAX_HBLK_SIZE);
	if (!src->ubase) {
	    coral_diag(0, ("coral_nextblk: malloc: %s\n", strerror(errno)));
	    goto coral_file_nextblk_error;
	}
    }

    if (src->preread < 0) {
	/* ubase holds file header.  Skip to first block. */
	need = -src->preread;
	debug_file_offset("skip", src, need);
	len = coral_rseek(src, src->ubase, need);
	if (len < need) {
	    if (len > 0) goto coral_file_nextblk_bad_eof;
	    if (len == 0) goto coral_file_nextblk_boundary_eof;
	    coral_diag(0, ("coral_file_nextblk: %s: seek: %s\n", src->filename,
		strerror(errno)));
	    goto coral_file_nextblk_error;
	}
	src->preread = 0;
    }

    if (!CORAL_VERSION_IS_NEW(src->version)) {
	/* ubase may hold header of first block.  Keep it and read the data. */
	/* Old format blocks had fixed size. */
	need = CORAL_V0_BLK_HEADER_SIZE - src->preread;
    } else {
	/* We must read the header to find out how long the data block is. */
	need = sizeof(coral_blk_info_t);
    }

    /* Read block header */
    debug_file_offset("head", src, need);
    len = coral_readall(src, src->ubase + src->preread, need);
    if (len < need) {
	if (len > 0) goto coral_file_nextblk_bad_eof;
	if (len == 0) {
	    if (has_another_file(src)) {
	       if (!coral_next_compound_file(src))
		   goto coral_file_nextblk_error;
	       goto retry;
	    }
	    goto coral_file_nextblk_boundary_eof;
	}
	coral_diag(0, ("coral_file_nextblk: %s: %s\n",
	    src->filename, coral_strerror(src->file, errno)));
	goto coral_file_nextblk_error;
    }
    src->preread = 0;
    binfo = (coral_blk_info_t *)src->ubase;

    /* Parse the block header */
    if (src->version == CORAL_VERSION_OLD_NLANR) {
	/* Build a fake block header (in network order).  The old formats had
	 * 512 byte block headers, so it's safe for us to write into binfo. */
	uint16_t nla_interface;	/* 0-1 */

	interface = nla_interface = ntohs(((uint16_t*)binfo)[2]);
	if (interface < 0 || interface >= src->iface_count)
	    goto coral_file_nextblk_bad_interface;

	binfo->interface = htonl(nla_interface);
	blk_size = CORAL_V0_BLK_ENTRIES * CORAL_OLD_CELL_SIZE;
	binfo->blk_size = htonl(blk_size);
	cell_count = CORAL_V0_BLK_ENTRIES;
	binfo->cell_count = htonl(cell_count);

	binfo->cells_lost = htonl(0);
	binfo->unknown_vpi_vci = htonl(0);
	binfo->tbegin.tv_sec = htonl(0);
	binfo->tbegin.tv_nsec = htonl(0);
	binfo->tend.tv_sec = htonl(0);
	binfo->tend.tv_nsec = htonl(0);

        result = src->ubase + CORAL_V0_BLK_HEADER_SIZE;
	iface = cinst[src->id[interface]];
	atm_header_needs_swapping = 1;

    } else if (src->version == CORAL_VERSION_OLD_MCI) {
	/* Build a fake block header (in network order).  The old formats had
	 * 512 byte block headers, so it's safe for us to write into binfo. */
	int32_t mci_used;	/* has to be < 0xffff0000 */
	int16_t mci_cardnum;	/* pci bus handle, > ?7? */
	int8_t mci_cardidx;	/* 0-1 */
	    
	mci_used = ntohl(((int32_t*)binfo)[0]);
	mci_cardnum = ntohs(((int16_t*)binfo)[2]);
	interface = mci_cardidx = ntohs(((int8_t*)binfo)[6]);
	if (interface < 0 || interface >= src->iface_count)
	    goto coral_file_nextblk_bad_interface;

	binfo->interface = htonl(mci_cardidx);
	blk_size = CORAL_OLD_CELL_SIZE *
	   (CORAL_V0_BLK_ENTRIES > mci_used ? CORAL_V0_BLK_ENTRIES : mci_used);
	binfo->blk_size = htonl(blk_size);
	cell_count = mci_used;
	binfo->cell_count = htonl(cell_count);

	binfo->cells_lost = htonl(0);
	binfo->unknown_vpi_vci = htonl(0);
	binfo->tbegin.tv_sec = htonl(0);
	binfo->tbegin.tv_nsec = htonl(0);
	binfo->tend.tv_sec = htonl(0);
	binfo->tend.tv_nsec = htonl(0);

        result = src->ubase + CORAL_V0_BLK_HEADER_SIZE;
	iface = cinst[src->id[interface]];
	atm_header_needs_swapping = 1;

    } else {	/* all new CORAL_VERSIONs */
        interface = ntohl(binfo->interface);
	if (interface < 0 || interface >= src->iface_count)
	    goto coral_file_nextblk_bad_interface;
	iface = cinst[src->id[interface]];

	blk_size = ntohl(binfo->blk_size);
	cell_count = ntohl(binfo->cell_count);
	if (src->version < CORAL_VERSION_8) {
	    /* versions 3-7 stored cells_per_blk instead of blk_size */
	    blk_size *= coral_cell_size(iface);
	    binfo->blk_size = htonl(blk_size);
	}

        result = src->ubase + sizeof(coral_blk_info_t);
	atm_header_needs_swapping = (src->version < CORAL_VERSION_5 &&
	    iface->iface_info.hw_type == CORAL_TYPE_FATM);
    }


    /* Read the block data. */
    if (cell_count > 0) {
	need = endonly ?
	    coral_cell_size(iface) :		    /* first cell only */
	    cell_count * coral_cell_size(iface);    /* whole block */
	debug_file_offset("data", src, need);
	len = coral_readall(src, result, need);
	if (len < need) {
	    if (len >= 0) goto coral_file_nextblk_bad_eof;
	    coral_diag(0, ("coral_file_nextblk: %s: data: %s\n",
		src->filename, coral_strerror(src->file, errno)));
	    goto coral_file_nextblk_error;
	}
    }

    if (endonly && cell_count > 1) {		    /* read last cell */
	size_t offset = (cell_count - 2) * coral_cell_size(iface);
	need = coral_cell_size(iface);
	if (lseek(src->fd, offset, SEEK_CUR) == (off_t)-1) {
	    coral_diag(0, ("coral_file_nextblk: %s: seek: %s\n",
		src->filename, strerror(errno)));
	    goto coral_file_nextblk_error;
	}
	len = coral_readall(src, result + coral_cell_size(iface) + offset,
	    coral_cell_size(iface));
	if (len < need) {
	    if (len >= 0) goto coral_file_nextblk_bad_eof;
	    coral_diag(0, ("coral_file_nextblk: %s: data: %s\n",
		src->filename, coral_strerror(src->file, errno)));
	    goto coral_file_nextblk_error;
	}
    }

    /* Skip over padding.  Premature EOF is okay here. */
    need = blk_size - cell_count * coral_cell_size(iface);
    if (need > 0) {
	if (coral_rseek(src, result + len, need) < 0) {
	    coral_diag(0, ("coral_file_nextblk: %s: seek: %s\n",
		src->filename, strerror(errno)));
	    goto coral_file_nextblk_error;
	}
    }

    /* The fatm card returns atm headers in little endian order.  This is
     * corrected in libcoral format version 5; but libcoral versions 3 and 4
     * (and nlanr, and presumably mci) wrote the little endian headers to the
     * trace, so we must correct it here.
     */
    if (atm_header_needs_swapping) {
	int i;
	coral_fatm_atm_cell_t *cells = (coral_fatm_atm_cell_t*)result;
	if (endonly && cell_count > 1) {
	    cells[0].cu.ui = crl_swapl(cells[0].cu.ui);
	    cells[cell_count-1].cu.ui = crl_swapl(cells[cell_count-1].cu.ui);
	} else {
	    for (i = 0; i < cell_count; i++) {
		cells[i].cu.ui = crl_swapl(cells[i].cu.ui);
	    }
	}
    }

    debug_file_offset("end", src, 0);
    *binfop = binfo;
    *cellp = (coral_atm_cell_t*)result;

    return iface;

coral_file_nextblk_boundary_eof:
    errno = 0;
    goto coral_file_nextblk_error;

coral_file_nextblk_bad_eof:
    coral_diag(1, ("coral_file_nextblk: %s: incomplete block\n", src->filename));
    errno = CORAL_ETRUNCBLK;
    goto coral_file_nextblk_error;

coral_file_nextblk_bad_interface:
    coral_diag(0, ("coral_file_nextblk: %s: bad interface %d (of 0-%d)\n",
	src->filename, interface, src->iface_count - 1));
    errno = CORAL_EBADIFNUM;
    goto coral_file_nextblk_error;

coral_file_nextblk_error:
    *binfop = NULL;
    *cellp = NULL;
    return NULL;
}

/* Do the minimum read from target_iface to update its timestamp.
 * For each block we get that belongs to another iface, we stick it on that
 * iface's queue.
 */
coral_iface_t *coral_file_read_min(coral_iface_t *target)
{
    coral_iface_t *iface;

    while (target->u.blk.node.cell_count <= target->u.blk.node.index) {
	iface = coral_queue_nextblk(target->src, 0, 0);
	if (!iface) {
	    coral_mark_eof(target);
	    return NULL /* with errno */;
	}
	/* Steal buffer from iface->src. */
	iface->u.blk.tail->block = iface->src->ubase;
	iface->src->ubase = NULL;
    }
    target->have_data =
	target->u.blk.node.cell_count > target->u.blk.node.index;
    coral_new_current_block(target);
    return target;
}

/* release a held block */
void coral_file_release(coral_iface_t *iface)
{
    if (iface->u.blk.node.block) {
	free(iface->u.blk.node.block);
	iface->u.blk.node.block = NULL;
	iface->u.blk.node.cell_count = 0;
	iface->u.blk.node.binfo = NULL;
	iface->u.blk.node.data = NULL;
	iface->u.blk.node.next = NULL;
    }
}

/* clean up stuff we malloc'd or opened in coral_file_open */
int coral_file_close(coral_source_t *src, int final)
{
    if (final && src->ubase) {
	free(src->ubase);
    }
#ifdef HAVE_LIBZ
    if (src->file) {
	gzclose(src->file);
	src->file = NULL;
	src->fd = -1; /* gzclose() closed this fd */
    }
#endif

    return src->type.is_block ? coral_blk_close(src, final) : 0;
}

const coral_src_type_t coral_src_type_file = {
    CORAL_TYPE_FILE,
    "file",
    0 /* is_live */,
    0 /* is_buffered */,
    1 /* is_block */,
    0 /* is_interleaved */,
    coral_file_init,
    NULL /* start */,
    NULL /* read_raw */,
    coral_file_read_min,
    coral_file_read_min,
    coral_file_nextblk,
    coral_file_release,
    coral_mark_eof_src /* stop */,
    coral_file_close
};

