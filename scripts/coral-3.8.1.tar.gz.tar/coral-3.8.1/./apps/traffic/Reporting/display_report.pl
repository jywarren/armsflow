#!/usr/local/bin/perl -T
## $Id: display_report.pl,v 1.16 2007/06/06 18:17:34 kkeys Exp $ $Name: release-3-8-1 $
## 
## Copyright 2004, 2005, 2007
## The Regents of the University of California 
## All Rights Reserved 
## 
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
## 
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
## 
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
## 
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
## 
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program.  Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
## 
## Report bugs and suggestions to coral-bugs@caida.org.
## 

use strict;
no strict 'refs'; # For symbolic refs, to make code easier to follow.
use warnings;

my $coral_dir;
BEGIN { $coral_dir = "/usr/local/Coral"; } # This will be edited during build.
use lib "$coral_dir/lib"; # Main install directory
use lib "lib"; # Local directory, for just copying ReportSupport.pm for CGI
use CAIDA::Traffic2::ReportSupport;
use CGI qw(-nosticky);
use CGI::Carp qw(fatalsToBrowser warningsToBrowser);
my $cgi = new CGI;

my $group_pat = '\s*group\s*{'; # For config files
my $static_pat = '\s*static\s*{'; # For config files
my %main_config;
my %mon_config;
my %static_config;
my ($main_conf_file, $mon_conf_file) = ('cgi.conf', 'monitor.conf');

open MAIN_CONF, $main_conf_file or die "Couldn't open $main_conf_file: $!";
parse_config(\*MAIN_CONF, {$group_pat => \%main_config});
close MAIN_CONF;
my $mon_info = $main_config{'monitors'};
my $color_info = $main_config{'colors'};

my $warn_color = get_config_var($color_info, 'warn_color');
my $bg_color = get_config_var($color_info, 'bg_color');
my $highlight_color = get_config_var($color_info, 'highlight_color');
my $form_bg_color = get_config_var($color_info, 'form_bg_color');
my $mon_cur_color = get_config_var($color_info, 'mon_cur_color');
my $mon_bg_color = get_config_var($color_info, 'mon_bg_color');

# TODO At some point, these should be pulled outside and made more
# configurable, probably with some pattern indicating how they fit into an
# image/table filename.  Potentially using evals or another method of
# writing dynamic code.
my @param_values = ('sources', 'graphs', 'counters', 'timescales');
my %param_labels = (
	'sources' => 'Data sources',
	'graphs' => 'Graphs',
	'counters' => 'Counters',
	'timescales' => 'Timescales'
    );

my $curr_monitor = $cgi->param('monitor');
if (not $curr_monitor) {
    ($curr_monitor) = get_config_keys($mon_info);
}
open MON_CONF, "$curr_monitor/$mon_conf_file" or
		    die "Couldn't open $curr_monitor/$mon_conf_file: $!";
parse_config(\*MON_CONF, {$group_pat => \%mon_config,
			    $static_pat => \%static_config});
close MON_CONF;
my $general_options = $mon_config{'general'};
die "Need to have 'general' stanza in configuration file."
					    unless defined $general_options;
my $base_url = get_config_var($general_options, 'base_url') . "/$curr_monitor/";
die "Need to specify 'base_url' value in configuration file."
					    unless defined $base_url;
my $header_file = get_config_var($general_options, 'head');
my $use_dynamic = get_config_var($general_options, 'use_dynamic');
my $use_static = get_config_var($general_options, 'use_static');
my $default_static = get_config_var($general_options, 'default_static');
my $has_big = get_config_var($general_options, 'has_big');
my $title = get_config_var($general_options, 'title');
$title = 'Report Generator 2.0' unless defined $title;

print $cgi->header({-refresh => '300', -expires => '+30s'});
print $cgi->start_html({-bgcolor => $bg_color, -title => $title,
			-onLoad => 'updateMenus()'});

print "<style>\n";
print "  #warning { color: $warn_color }\n";
print "</style>\n";

if (defined $header_file and open HEAD, "$curr_monitor/$header_file") {
    while (<HEAD>) {
	print;
    }
    close HEAD;
}

if ($use_static and defined $default_static and not defined $cgi->param('row'))
{
    foreach my $name (get_config_keys(\%static_config)) {
	my $stanza = $static_config{$name};
	if ($default_static eq $name) {
	    my @pair_groups = get_config_keys($stanza);
	    foreach my $group (@pair_groups) {
		my @values = get_config_list($stanza, $group);
		$cgi->param(-name => $group, -values => \@values);
	    }
	    last;
	}
    }
}

my ($row_choose, $col_choose);
$row_choose = $cgi->param('row');
$col_choose = $cgi->param('col');
if (not defined $row_choose or not defined $col_choose or
						$row_choose eq $col_choose)
{
    $row_choose = 'timescales';
    $col_choose = 'graphs';
}
my @row_vals = $cgi->param($row_choose);
my @col_vals = $cgi->param($col_choose);

my $row_count = scalar(@row_vals);
my $col_count = scalar(@col_vals);

print "<style>\n";
foreach my $menu (@param_values) {
    my $menu_sing = $menu . '_sing';
    my $no_display = 'display: none;';
    my $display = 'display: inline;';
    my ($style1, $style2);
    if (defined $cgi->param($menu) or $menu eq $row_choose or
					$menu eq $col_choose)
    {
	$style1 = $no_display;
	$style2 = $display;
    } else {
	$style1 = $display;
	$style2 = $no_display;
    }
    print "  #$menu_sing { $style1 }\n";
    print "  #$menu { $style2 }\n";
}
print <<END;
</style>
<script language="javascript">
<!--

function singlifyMenus() {
END

foreach my $menu (@param_values) {
print <<END;
    document.myForm.${menu}_sing.style.display = 'inline';
    document.myForm.${menu}_sing.disabled = false;
    document.myForm.$menu.style.display = 'none';
    document.myForm.$menu.disabled = true;
END
}

print <<END;
    return true;
}

function updateMenus(what) {
    singlifyMenus();
END

foreach my $rc ('row', 'col') {
print <<END;
    var ${rc}_select = document.myForm.$rc;
    var $rc = ${rc}_select.options[${rc}_select.selectedIndex].value;
    document.getElementById($rc + '_sing').style.display = 'none';
    document.getElementById($rc + '_sing').disabled = true;
    document.getElementById($rc).style.display = 'inline';
    document.getElementById($rc).disabled = false;
END
}

print <<END;
    if (row == col) {
	document.myForm.submit.disabled = true;
	document.getElementById('warning').style.display = 'inline';
    } else {
	document.myForm.submit.disabled = false;
	document.getElementById('warning').style.display = 'none';
    }
    return true;
}

function checkSelected(id, key)
{
    var selected_found = 0;
    var i;
    var sel_obj = document.getElementById(id);
    for (i = 0; i < sel_obj.options.length; i++) {
	if (sel_obj.options[i].selected && sel_obj.options[i].value == key) {
	    selected_found = 1;
	    break;
	}
    }
    return selected_found;
}

function checkMap() {
    var uses_map = checkSelected('graphs', 'map') ||
		    checkSelected('graphs_sing', 'map');
    var uses_country = checkSelected('sources', 'src_country') ||
			checkSelected('sources', 'dst_country') ||
			checkSelected('sources_sing', 'src_country') ||
			checkSelected('sources_sing', 'src_country');
    if (uses_map && !uses_country) {
	alert("Warning, map selection is meaningless without a country selection.");
    }
}
// -->
</script>
<noscript>
<i>Note: enable Javascript for cleaner menu choices.</i>
  <style>
END

foreach my $menu (@param_values) {
print <<END;
    #$menu { display: inline; }
    #${menu}_sing { display: none; }
END
}

print <<END;
  </style>
</noscript>
END

warningsToBrowser(1);

print $cgi->p({-style => 'display:none'},
		$cgi->font({-color => $warn_color},
		"Style sheets are disabled, navigation may be difficult."));
print $cgi->start_table;
print $cgi->start_TR;

print $cgi->td('');
print $cgi->start_td({-colspan => $col_count});
print $cgi->start_table({-border => 1});
print $cgi->start_TR;
foreach my $monitor (get_config_keys($mon_info)) {
    my $url = $cgi->url();
    if ($monitor eq $curr_monitor) {
	print $cgi->td({-bgcolor => $mon_cur_color});
    } else {
	print $cgi->td({-bgcolor => $mon_bg_color});
    }
    if ($monitor eq $curr_monitor) {
	print get_config_var($mon_info, $monitor), " (current)";
    } else {
	print $cgi->a({-href => "$url?monitor=$monitor"},
			get_config_var($mon_info, $monitor));
    }
    print $cgi->end_td;
}
print $cgi->end_TR;
print $cgi->end_table;
print $cgi->end_td;
print $cgi->end_TR;

# Not 'my' because need to use symbolic reference to set it.
use vars qw($source $graph $counter $timescale);

print $cgi->start_TR({-valign => 'top'});
print $cgi->start_td({-rowspan => $row_count,
		    -valign => 'top',
		    -align => 'center',
		    -bgcolor => $form_bg_color});
print '&nbsp;' x 10, $cgi->br;
if ($use_static) {
    print "Quick links:<p />\n";
    foreach my $name (get_config_keys(\%static_config)) {
	my $stanza = $static_config{$name};
	my $url = $cgi->url();
	$url .= "?monitor=$curr_monitor";
	my @pair_groups = get_config_keys($stanza);
	foreach my $group (@pair_groups) {
	    my @values = get_config_list($stanza, $group);
	    foreach my $value (@values) {
		$url .= '&';
		$url .= "$group=$value";
	    }
	}
	print $cgi->a({-href => $url}, $name), $cgi->p;
    }
    print $cgi->hr;
}
if ($use_dynamic) {
    print "Choose a view:<p />\n";
    print $cgi->start_form(-name => 'myForm', -method => 'get',
			    -onSubmit => 'checkMap()'), "\n";
    print $cgi->hidden({-name => 'monitor', -value => $curr_monitor});
    print
	"Rows: ",
	$cgi->br,
	$cgi->popup_menu(
		    -name => 'row',
		    -values => \@param_values,
		    -labels => \%param_labels,
		    -default => $row_choose,
		    -onChange => 'updateMenus(this)',
		),
	$cgi->br,
	"Columns: ",
	$cgi->br,
	$cgi->popup_menu(
		    -name => 'col',
		    -values => \@param_values,
		    -labels => \%param_labels,
		    -default => $col_choose,
		    -onChange => 'updateMenus(this)',
		),
	$cgi->br,
	$cgi->p({-id => "warning", -style => 'display:none'},
		    "Row and column selections<br />must be different."),
	$cgi->p;
}

foreach my $menu (@param_values) {
    my $menu_sing = $menu . '_sing';
    (my $selected = $menu) =~ s/s$//;
    if (defined $cgi->param($menu_sing)) {
	$$selected = $cgi->param($menu_sing); # Single-select version
    } else {
	$$selected = $cgi->param($menu); # Multiple-select version
    }
    if ($use_dynamic) {
	my @values = get_config_keys($mon_config{$menu});
	my %labels = get_config_hash($mon_config{$menu});
	print "\n$param_labels{$menu}:", $cgi->br,
	    $cgi->popup_menu(
			-name => "$menu_sing",
			-id => "$menu_sing",
			-values => \@values,
			-labels => \%labels,
			-disabled => undef,
		    ),
	    $cgi->scrolling_list(
			-name => $menu,
			-id => $menu,
			-values => \@values,
			-labels => \%labels,
			-default => $values[0],
			-multiple => "true",
		    ),
	    $cgi->p;
    }
}

if ($use_dynamic) {
    print $cgi->submit(-id => "submit"),
	$cgi->p,
	$cgi->end_form;
}

print $cgi->end_td;
foreach my $row_val (@row_vals) {
    foreach my $col_val (@col_vals) {
	# Map $row_val and $col_val to proper names
	foreach my $choice (@param_values) {
	    (my $selected = $choice) =~ s/s$//;
	    if ($row_choose eq $choice) {
		$$selected = $row_val;
	    }
	    if ($col_choose eq $choice) {
		$$selected = $col_val;
	    }
	}
	# XXX This assumes we always want AVERAGE data.
	my @attributes = ($graph, $source, $counter, 'AVERAGE', $timescale);
	print $cgi->start_td;
	if ($graph eq 'anim') {
	    # XXX Do something here!
	} elsif ($graph eq 'table') {
	    print $cgi->start_table({-border => 1});
	    # XXX Should use a template of some sort instead of assuming
	    # filename syntax.
	    if (open TABLE, "$curr_monitor/" . join('_', @attributes) . '.txt')
	    {
		my $first = 1;
		my %sort_cols;
		while (<TABLE>) {
		    my $col = 0;
		    chomp;
		    my (@fields) = split /\t/;
		    print $cgi->start_TR;
		    foreach my $field (@fields) {
			$field =~ s/ /&nbsp;/g;
			if ($first) {
			    $sort_cols{$col}++ if $field =~ /$counter/;
			    print $cgi->th($cgi->b($field));
			} else {
			    my $opts = {};
			    if ($col != 0) {
				$opts->{-align} = 'right';
			    }
			    if ($sort_cols{$col}) {
				$opts->{-bgcolor} = $highlight_color;
			    }
			    print $cgi->td($opts, $field);
			}
			$col++;
		    }
		    print $cgi->end_TR;
		    $first = 0;
		}
		close TABLE;
	    }
	    print "\n";
	    print $cgi->end_table;
	} elsif ($graph eq 'pie') { # Create an HTML legend
	    my $url = $base_url . join('_', @attributes) . '.png';
	    print $cgi->start_table;
	    print $cgi->start_TR;
	    print $cgi->start_td;
	    print $cgi->img({-src => $url, -align => 'left'});
	    print $cgi->end_td;
	    print $cgi->start_td;
	    print $cgi->start_table;
	    if (open COLORS, "$curr_monitor/" . join('_', @attributes) . '.txt')
	    {
		while (<COLORS>) {
		    chomp;
		    my ($key, $color) = split /\t/;
		    print "\n";
		    print $cgi->start_TR;
		    print $cgi->td({-bgcolor => $color}, '&nbsp' x 4);
		    print $cgi->td($key);
		    print $cgi->end_TR;
		}
		close COLORS;
	    }
	    print $cgi->end_table;
	    print "\n";
	    print $cgi->end_td;
	    print $cgi->end_TR;
	    print $cgi->end_table;
	} else { # Normal image
	    my $norm_url = $base_url . join('_', @attributes) . '.png';
	    my $big_url = $base_url . 'big/' . join('_', @attributes) . '.png';
	    if ($has_big and $graph =~ /^ts/) {
		if (@col_vals > 1) {
		    print $cgi->a({-href => $big_url},
				    $cgi->img({-src => $norm_url}));
		} else {
		    print $cgi->img({-src => $big_url});
		}
	    } else {
		print $cgi->img({-src => $norm_url});
	    }
	}
	print $cgi->end_td, "\n";
    }
    print $cgi->end_TR;
    print $cgi->start_TR({-valign => 'top'})
				    unless $row_val eq $row_vals[$#row_vals];
}
print $cgi->end_table;

my $footer_file = get_config_var($general_options, 'foot');
if (defined $footer_file and open FOOT, "$curr_monitor/$footer_file") {
    while (<FOOT>) {
	print;
    }
    close FOOT;
}
print $cgi->end_html;
