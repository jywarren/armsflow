#! /usr/local/bin/perl -w
## parse_bgp_dump is a script for parsing a Cisco routing table dump into
##	a simple table, optionally adding AS and country information for each
##	network in the table
##
## USAGE: ./parse_bgp_dump <routing table dump> [<as to country map> <net to country map>]
##
## A collection of historical routing tables from Route Views is available
##	from <http://moat.nlanr.net/AS>.  Choose the `complete gzip-ed version
##	of the whole BGP dump' option from the first group of check boxes
##
## $Id: parse_bgp_dump.pl,v 1.29 2007/03/26 16:09:38 rkoga Exp $
##
## This software product is developed by Sean McCreary and David Moore,
## and copyrighted(C) 1998 by the University of California, San Diego
## (UCSD), with all rights reserved. UCSD administers the CAIDA grant,
## NCR-9711092, under which part of this code was developed.
##
## There is no charge for this software. You can redistribute it and/or
## modify it under the terms of the GNU General Public License, v. 2 dated
## June 1991 which is incorporated by reference herein. This software is
## distributed WITHOUT ANY WARRANTY, IMPLIED OR EXPRESS, OF MERCHANTABILITY
## OR FITNESS FOR A PARTICULAR PURPOSE or that the use of it will not
## infringe on any third party's intellectual property rights.
##
## You should have received a copy of the GNU GPL along with this program.
##
## Contact: coral-info@caida.org
##
##===========================================================================

use strict;
my $coral_dir;
BEGIN { $coral_dir = "/usr/local/Coral"; } # This will be edited during build.
use lib "$coral_dir/lib"; #coral global libdir#
use lib "../../lib"; #coral local libdir#
use Socket qw(inet_aton);
use Getopt::Std;
use ParseBGPDump qw(parse_table);

# assign $PNAME to the actual program name
use vars qw($PNAME);
($PNAME) = $0 =~ m,([^/]+)$,;

use vars qw($package);

$ParseBGPDump::debug = 0;

## Speed up parsing by turning off unneeded fields
%ParseBGPDump::parse_opts = (
    "status_code"       => 0,
    "prefix"            => 1,
    "nexthop"           => 0,
    "med"               => 0,
    "locprf"            => 0,
    "weight"            => 0,
    "aspath"            => 0,
    "nexthopAS"         => 0,
    "originAS"          => 1,
    "origin_code"       => 0,
    );

my $debug = 0;

my (%as, %bynet);

## helper functions

sub unique_set (@ ) {
    my (@set) = @_;
    my @result;

    @set = sort @set;

    my $last = shift @set;
    while (@set) {
	my $current = shift @set;
	if ($last ne $current) {
	    push @result, $last;
	    $last = $current;
	}
    }

    push @result, $last;

    return @result;
}


sub intersect_sets {
    my (@sets) = @_;
    my %seen;
    my @result;

    foreach my $set (@sets) {
	foreach my $element (@$set) {
	    $seen{$element}++;
	}
    }

    while (my ($element, $count) = each %seen) {
	if ($count == @sets) {
	    push @result, $element;
	}
    }

    return \@result;
}

## Sort prefixes by addresses and mask length
sub byprefix {
    if ( $bynet{$a}->[0] == $bynet{$b}->[0] ) {
## Longest mask first for identical prefixes
        return $bynet{$b}->[1] <=> $bynet{$a}->[1];
    } else {
## Otherwise, lowest prefix first
        return $bynet{$a}->[0] <=> $bynet{$b}->[0];
    }
}

## Global used to cache state between executions of process_route()
my ($netnum, $masklen);
my $net = "Unset";
sub process_route ($@) {
    my ($data_struct, $origin_as, $newnet, $newlen) = @_;

    if ( $newnet ne "CONT" ) {
## This must be the first line of a new prefix entry
        $net = "$newnet/$newlen";
        $netnum = unpack("N", inet_aton($newnet));
        $masklen = $newlen;
    }

## Save parsed data
    if( ! defined ${$data_struct->[0]}{$net} ) {
        warn "Updating entry for $net" if $debug > 1;
        ${$data_struct->[0]}{$net} = [ $netnum, $masklen ];
    }

## Skip this entry if it has no AS path
    if ( ! defined $origin_as ) {
        warn "No AS path found, skipping entry" if $debug > 1;
        return $data_struct;
    }

## If origin is a set, list the ASes in sorted order
    if ($origin_as =~ /\{/) {
        my (@ases);

        $origin_as =~ s/[{}]//g;
        @ases = split /,/, $origin_as;
        @ases = sort { $a <=> $b } @ases;
        $origin_as = "{" . join(",", @ases) . "}";
    }

## Increment per-AS histogram based on last element in AS path
    warn "Incrementing origin histogram for $net from $origin_as"
        if $debug > 1;
    ${$data_struct->[1]}{$net}{$origin_as}++;

    return $data_struct;
}

##===========================================================================
##
## Main

my ($version, $router);
my $data_struct = [ {}, {} ];

use vars qw($opt_c $opt_g);

getopts("cg");

## Check command-line arguments
if ( @ARGV != 1 ) { 
   print " Invalid number of command-line arguments.\n";
   print " Usage: ${PNAME} [-c|-g] <BGP Dump>\n";
   print " The options indicate how to deal with multiple-origin ASes.\n";
   print "        -c:  Add AS counts to each AS in MOAS list\n";
   print "        -g:  Pick the AS with the highest count; discard others\n";
   exit(0);
}

## Open route dump file
my $pipe_cmd = "cat ";
my $base_name = $ARGV[0];
if ($ARGV[0] =~ /(.*)\.gz$/) {
    $base_name = $1;
    $pipe_cmd = "gzip -dc";
} elsif ($ARGV[0] =~ /(.*)\.bz2$/) {
    $base_name = $1;
    $pipe_cmd = "bzip2 -dc";
}
open(ROUTES, "$pipe_cmd $ARGV[0] |") || die("Can't open $ARGV[0]\n");
($data_struct, $router, $version) = parse_table($data_struct,
    \&process_route, \*ROUTES);
close(ROUTES);
%bynet = %{$data_struct->[0]};
%as = %{$data_struct->[1]};

warn "Done reading routes" if $debug;

## Select best origin AS for each prefix
foreach my $net ( keys( %as ) )
{
    my ($netnum, $masklen) = @{$bynet{$net}}; 
## Pick best common subset of all AS-sets
    my @origin_as_list;
    my @all_ases = keys %{$as{$net}};
    foreach my $origin_as (@all_ases) {
	if ($origin_as =~ /\{/) {
	    (my $as_set = $origin_as) =~ s/[{}]//g;
	    my @origin_ases = split /,/, $as_set;
	    @origin_ases = unique_set(@origin_ases);
	    push @origin_as_list, \@origin_ases;
	} else {
	    push @origin_as_list, [ $origin_as ];
	}
    }

    my $result = intersect_sets(@origin_as_list);

    my $origin_as;
    if (@$result == 0) {
	# Sort by occurrence frequency.
	my @sorted = sort { $as{$net}{$b} <=> $as{$net}{$a} } @all_ases;
	if ($opt_g) { # Use the best guess
	    $origin_as = $sorted[0];
	} elsif ($opt_c) { # List all, including counts
	    foreach my $as (@sorted) {
		$origin_as .= "$as:" . $as{$net}{$as};
		$origin_as .= "_" unless $as eq $sorted[$#sorted];
	    }
	} else { # List all, no counts
	    $origin_as = join("_", @sorted);
	}
    } elsif (@$result == 1) {
	$origin_as = $result->[0];
    } else {
	my @origin_ases = sort { $a <=> $b } @$result;
	$origin_as = "{" . join(",", @origin_ases) . "}";
    }
    $bynet{$net} = [ $netnum, $masklen, $origin_as ];
} 
warn "Done selecting best origin AS" if $debug;

##===========================================================================
## Combine the tables to produce Network -> AS mapping

## Extract date BGP dump filename
my $bgpdump_date;
if ($ARGV[0] =~ /(\d+[\d_-]*\d+)/) {
    $bgpdump_date = $1;
} else {
    $bgpdump_date ="NO_DATE"; 
}

## Print out collapsed table
my $filename = $base_name . "_parsed.txt";
open(OUTFILE,">".$filename) || die("Can't create $filename!!\n");

foreach $net ( sort byprefix keys( %bynet ) )
{
    my ($netnum, $masklen, $origin_as) = @{$bynet{$net}};
    $net =~ s#/.*$##;
    printf OUTFILE "%s\t%d\t%s\n", $net, $masklen, $origin_as;
}

## Spit out a line to cover multicast IP traffic
printf OUTFILE "224.0.0.0\t4\tMCAST\n";

close(OUTFILE);
