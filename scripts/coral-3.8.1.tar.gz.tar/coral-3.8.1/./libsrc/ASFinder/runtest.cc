//===========================================================================
//  $Name: release-3-8-1 $
//  $Id: runtest.cc,v 1.6 2003/06/19 22:23:14 rkoga Exp $
//
//  Daniel W. McRobb
//  CAIDA
//  December 1998
//===========================================================================
extern "C" {
#include <sys/types.h>
#include <stdio.h>
#include <unistd.h>
#include <netinet/in.h>
#include <sys/time.h>
#include <stdio.h>
}

#include "pat_func.h"

/*-------------------------------------------------------------------------*
 *                     int main(int argc, char *argv[])                    *
 *.........................................................................*
 *                                                                         *
 *-------------------------------------------------------------------------*/
int main(int argc, char *argv[])
{
  ASFinder * trie_id;

  if (argc < 3) {
    fprintf(stderr,"usage: %s routefile ipaddr\n",argv[0]);
    exit(1);
  }

  trie_id = new_as_finder();
  load_file_text(trie_id, argv[1]);
  char closest_net[50];
  int masklen;
  const char * ret_val = get_as(trie_id, argv[2], closest_net, &masklen);
  
  if (ret_val) {
    printf("Found longest match for %s at %s/%d, with AS: %s\n", argv[2], 
		closest_net, masklen, ret_val);
  } else {
    printf("Match not found!\n");
  }

  delete_as_finder(trie_id);
  
  exit(0);
}
