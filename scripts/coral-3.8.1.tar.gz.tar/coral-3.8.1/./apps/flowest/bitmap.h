/* 
 * Copyright 2002, 2003, 2004, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 * $Id: bitmap.h,v 1.14 2007/06/06 18:17:28 kkeys Exp $
 *
 * Variable size bit map
 *
 * Bitmap is similar to a standard bitset, but its size is determined at
 * runtime.  Before using a Bitmap, you must define a class of Bitmaps of
 * size N:
 *     class my_tag {};
 *     Bitmap<my_tag>::nbits = N;
 * Because the tag class, not N, is the template parameter, N does not need
 * to be a compile-time constant.  Bitmaps that must be the same size must be
 * declared with the same tag.  Behavior is undefined if Bitmap<my_tag>::nbits
 * is not set when objects of type Bitmap<my_tag> are created or if it is
 * modified after any objects of type Bitmap<my_tag> are created.
 *
 * Bitmap is a variable sized structure which can only be created on free
 * store; you can not declare an object of type Bitmap, or derive other classes
 * from Bitmap.  There are only two ways to use a Bitmap class:
 *   - declare a pointer to a Bitmap
 *   - define a class whose last member is a Bitmap.  Such a class will
 *     inherit all the restrictions of Bitmap.
 * To create a standalone Bitmap object, you must call
 *     new Bitmap<my_tag>()
 *
 * Creating a class C that contains a Bitmap<my_tag> b requires a similar
 * call; class C must have defined an operator new() that allocates
 *     sizeof(C) + Bitmap<my_tag>::bytes()
 * bytes and initializes b by calling
 *     b.setmagic()
 * Note that (offsetof(C,b) + Bitmap<my_tag>::bytes()) is not legal, because
 * offsetof can not be used on a non-POD type.  (Of course, the flexible
 * array member is not legal in C++ either, but avoiding offsetof() may make
 * this code slightly less illegal, and eliminates warnings in g++).
 *
 * To create a class D that contains a C as its last member, the allocation is
 * the same:
 *     sizeof(D) + Bitmap<my_tag>::bytes()
 * This works because sizeof(D) counts all the normal members of D plus the
 * fixed members of C.
 */

#ifndef BITMAP_H
#define BITMAP_H

#include <iostream>
#include <memory>
#include <algorithm>
#include <cstdlib>

namespace Bitmap_helper {
    extern unsigned bitcount[];
}

template<class tag> class Bitmap;

template<class tag> std::ostream& operator<< (std::ostream& s, const Bitmap<tag>& b);

template<class tag> class Bitmap {
    // Class invariant:  pad bits beyond nbits are always 0.
    friend std::ostream& operator<< <>(std::ostream& s, const Bitmap<tag>& b);

    const static uint32_t magic = 0xa10ca7ed; // indicates our new was called
    uint8_t bits[];  // "flexible array member" allowed by ISO C, but not C++

    size_t idx(size_t i) const { return i / 8; }
    uint8_t bit(size_t i) const { return 0x80 >> (i % 8); }

    void masklast()
	{ if (nbits % 8) bits[idx(nbits-1)] &= (0xFF << (8 - (nbits % 8))); }

    void checkmagic()
    {
#ifndef NDEBUG
	if (nbits == 0) throw Uninitialized();
	if (*reinterpret_cast<uint32_t*>(this) != magic) throw Unalloced();
#endif
    }

public:
    struct Unalloced : public std::exception {
	const char *what() const throw()
	    { return "Bitmap objects can only be allocated with 'new'."; }
    };

    struct Uninitialized : public std::exception {
	const char *what() const throw()
	    { return "Bitmap::nbits is not initialized."; }
    };

    static size_t nbits; // number of bits in a Bitmap<tag>

    static size_t bytes() { return std::max((nbits + 7) / 8, sizeof(uint32_t)); }

    void setmagic()
    {
#ifndef NDEBUG
	*reinterpret_cast<uint32_t*>(this) = magic;
#endif
    }

    void *operator new(size_t unused)
    {
	void *ptr = malloc(bytes());
	(static_cast<Bitmap<tag>*>(ptr))->setmagic();
	return ptr;
    }

    void operator delete(void *ptr, size_t size) { free(ptr); }

    // default constructor
    Bitmap() { checkmagic(); reset(); }

    // copy constructor
    Bitmap(const Bitmap<tag>& v) {
	checkmagic();
	memcpy(bits, v.bits, bytes());
    }

    // construct from integer
    Bitmap(uint32_t v) {
	checkmagic();
	reset();
	for (size_t i = 0; i < bytes() && i < 4; i++)
	    bits[i] = (v >> ((3-i)*8)) & 0xFF;
	masklast();
    }

    // copy assignment
    Bitmap & operator= (const Bitmap<tag>& v) {
	memcpy(bits, v.bits, bytes());
	return *this;
    }

    // assignment from integer
    Bitmap & operator= (uint32_t v) {
	reset();
	for (size_t i = 0; i < bytes() && i < 4; i++)
	    bits[i] = (v >> ((3-i)*8)) & 0xFF;
	masklast();
	return *this;
    }

    Bitmap & set() { memset(bits, 0xFF, bytes()); masklast(); return *this; }
    Bitmap & set(size_t i) { bits[idx(i)] |= bit(i); return *this; }
    Bitmap & reset() { memset(bits, 0, bytes()); return *this; }
    Bitmap & reset(size_t i) { bits[idx(i)] &= ~bit(i); return *this; }
    bool test(size_t i) const { return bits[idx(i)] & bit(i); }

    Bitmap& operator &= (const Bitmap<tag> &rhs)
    {
	for (size_t i = 0; i <= idx(nbits-1); i++)
	    bits[i] &= rhs.bits[i];
	return *this;
    }

    Bitmap& operator |= (const Bitmap<tag> &rhs)
    {
	for (size_t i = 0; i <= idx(nbits-1); i++)
	    bits[i] |= rhs.bits[i];
	return *this;
    }

    Bitmap& operator ^= (const Bitmap<tag> &rhs)
    {
	for (size_t i = 0; i <= idx(nbits-1); i++)
	    bits[i] ^= rhs.bits[i];
	return *this;
    }

    // Bitmap& operator <<= (size_t n);
    // Bitmap& operator >>= (size_t n);

    Bitmap & flip() { for (size_t i = 0; i <= idx(nbits-1); i++) bits[i] = ~bits[i]; masklast(); return *this; }
    Bitmap size() const { return nbits; }

    bool any(size_t size = nbits) const
    {
	for (size_t i = 0; i <= idx(size-1); i++)
	    if (bits[i]) return true;
	return false;
    }

    bool none(size_t size = nbits) const { return !any(size); }

    size_t count(size_t size = nbits) const
    {
	// optimized for offset 0
	using namespace Bitmap_helper;
	size_t i, n = 0;
	for (i = 0; i < idx(size); i++)
	    n += bitcount[bits[i]];
	if (size % 8 > 0)
	    n += bitcount[bits[i] & (0xFF << (8 - size % 8))];
	return n;
    }

    size_t count(size_t size, size_t offset) const
    {
	using namespace Bitmap_helper;
	size_t i, end, n;
	i = idx(offset);
	end = idx(offset + size);
	if (i == end) {
	    n = bitcount[bits[i] & (0xFF >> (offset % 8)) &
		(0xFF << (8 - (offset + size) % 8))];
	} else {
	    n = bitcount[bits[i] & (0xFF >> (offset % 8))];
	    for (i++; i < end; i++)
		n += bitcount[bits[i]];
	    if ((offset + size) % 8 > 0)
		n += bitcount[bits[i] & (0xFF << (8 - (offset + size) % 8))];
	}
	return n;
    }

    size_t nzero(size_t n = nbits) const { return n - count(n); }
    size_t nzero(size_t n, size_t first) const { return n - count(n, first); }

    bool operator== (const Bitmap & rhs) const
	{ return (memcmp(this, &rhs, bytes()) == 0); }

    bool operator!= (const Bitmap & rhs) const { return !(*this == rhs); }
};

template<class tag> size_t Bitmap<tag>::nbits = 0;

template <class tag>
std::ostream& operator<<(std::ostream& s, const Bitmap<tag>& b)
{
    for (size_t i = 0; i < b.nbits; i++)
	s << (b.test(i) ? '1' : '0');
    return s;
}

#endif // BITMAP_H
