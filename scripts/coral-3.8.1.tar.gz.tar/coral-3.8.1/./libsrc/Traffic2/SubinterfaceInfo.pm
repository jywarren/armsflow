## 
## Copyright 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
## All Rights Reserved 
## 
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
## 
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
## 
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
## 
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
## 
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program. Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
## 
## Report bugs and suggestions to coral-bugs@caida.org.
## 

package CAIDA::Traffic2::SubinterfaceInfo;

use strict;
use Carp;

my $cvs_Id = '$Id: SubinterfaceInfo.pm,v 1.42 2007/06/06 18:17:51 kkeys Exp $';
my $cvs_Author = '$Author: kkeys $';
my $cvs_Name = '$Name: release-3-8-1 $';
my $cvs_Revision = '$Revision: 1.42 $';

use vars qw($DEBUG);

$DEBUG = 0;

# The first in the associated list is the preferred choice.
# Using a smaller table as a source is faster.
# Only sources that are in the file are chosen, thus avoiding recursive
# dependencies.
my %dependencies =  (
    'IP Matrix' => ['Tuple Table'],
    'Proto Ports Table' => ['Tuple Table', 'IP Proto Ports Table'],
    'src IP Table' => ['IP Matrix', 'Tuple Table'],
    'dst IP Table' => ['IP Matrix', 'Tuple Table'],
    'IP Table' => ['IP Proto Port Table', 'IP Proto Ports Table'],
    'src Proto Port Table' => ['Proto Ports Table', 'IP Proto Ports Table',
				'Tuple Table'],
    'dst Proto Port Table' => ['Proto Ports Table', 'IP Proto Ports Table',
				'Tuple Table'],
    'Proto Port Table' => ['IP Proto Port Table'],
    'Proto Table' => ['Proto Ports Table', 'Proto Port Table',
		    'src Proto Port Table', 'dst Proto Port Table',
		    'IP Proto Ports Table',
		    'src IP Proto Ports Table', 'dst IP Proto Ports Table',
		    'IP Proto Port Table',
		    'IP Proto src Port Table', 'IP Proto dst Port Table',
		    'src IP Proto src Port Table','src IP Proto dst Port Table',
		    'dst IP Proto src Port Table','dst IP Proto dst Port Table',
		    'Tuple Table'],
    'src IP Proto Ports Table' => ['Tuple Table'],
    'dst IP Proto Ports Table' => ['Tuple Table'],
    'src IP Proto src Port Table' => ['Tuple Table'],
    'src IP Proto dst Port Table' => ['Tuple Table'],
    'dst IP Proto src Port Table' => ['Tuple Table'],
    'dst IP Proto dst Port Table' => ['Tuple Table'],
    'IP Proto src Port Table' => ['IP Proto Ports Table'],
    'IP Proto dst Port Table' => ['IP Proto Ports Table'],
    'Port Matrix' => ['Proto Ports Table', 'Tuple Table'],
    'Port Table' => ['Proto Port Table', 'IP Proto Port Table'],
    'src Port Table' => ['Port Matrix', 'Proto Ports Table',
			    'IP Proto Ports Table', 'Tuple Table'],
    'dst Port Table' => ['Port Matrix', 'Proto Ports Table',
			    'IP Proto Ports Table', 'Tuple Table'],
    'AS Matrix' => ['IP Matrix', 'Tuple Table'],
    'src AS Table' => ['AS Matrix', 'IP Matrix', 'Tuple Table'],
    'dst AS Table' => ['AS Matrix', 'IP Matrix', 'Tuple Table'],
    'AS Table' => ['IP Table'],
    'Country Matrix' => ['IP Matrix', 'Tuple Table', 'AS Matrix'],
    'src Country Table' => ['Country Matrix', 'IP Matrix', 'Tuple Table',
			    'AS Matrix'],
    'dst Country Table' => ['Country Matrix', 'IP Matrix', 'Tuple Table',
			    'AS Matrix'],
    'Country Table' => ['IP Table', 'AS Table'],
    'src LatLon Table' => ['IP Matrix', 'Tuple Table', 'AS Matrix', 
			    'Country Matrix'],
    'dst LatLon Table' => ['IP Matrix', 'Tuple Table', 'AS Matrix',
			    'Country Matrix'],
    'LatLon Table' => ['IP Table', 'AS Table', 'Country Table'],
    # In this case, we prefer Tuple Table for finding apps.
    'App Table' => ['Tuple Table', 'Proto Ports Table'],
    # Etc...
		    );

my $id_pat = '^# ID: (.*)$';
my $unknown_encaps_pat = 'unknown_encaps: (.*)$';
my $ip_not_v4_pat = 'ip_not_v4: (.*)$';
my $pkts_pat = '#\s*pkts: (.*)$';
my $bytes_pat = '#\s*bytes: (.*)$';
my $flows_pat = '#\s*flows: (.*)$';
my $first_pat = '#\s*first: (.*)$';
my $latest_pat = '#\s*latest: (.*)$';
my $types_list_pat = 'Table types: (.*)$';
# These are not currently stored anywhere, but parsed out to avoid lots of
# warning messages.
my $flowest1 = 'actual pkts:';
my $flowest2 = 'min presampling:';
my $anf1 = 'est pkts:';
my $anf2 = 'est bytes:';
my $anf3 = 'est flows:';

sub new {
    my ($classname) = @_;
    my $self =  {
		    'id' => undef,
		    'unknown encapsulation' => undef,
		    'ip not v4' => undef,
		    'packets' => undef,
		    'bytes' => undef,
		    'flows' => undef,
		    'first' => undef,
		    'latest' => undef,
		    'save tables' => undef,
		    'desired tables' => undef,
		    'conv options' => {},
		    'table list' => [],
		    'table required' => {},
		    'table in file' => {},
		    'depend map' => {},
		    'expand map' => {},
		    'tables' => {},
		};
    return bless $self;
}

sub _initialize {
    my ($self, $id, $filehandle, $desired_tables, $conv_opts, $save_tables)= @_;
    if (not defined $id) {
	carp "Cannot create a SubinterfaceInfo without a name.";
	return 0;
    }
    if (not $filehandle) {
	carp "SubinterfaceInfo requires a file handle to read from.";
	return 0;
    }
    if (not defined $desired_tables) {
	carp "SubinterfaceInfo requires a list of desired tables.";
	return 0;
    }
    $self->{'conv options'} = $conv_opts;
    $self->{'id'} = $id;
    $self->{'save tables'} = $save_tables;
    $self->{'desired tables'} = { %$desired_tables }; # Make copy to modify
    $self->_read_header($filehandle);
    $self->_make_maps();
    $self->_make_table_list();
    return 1;
}

sub _make_maps {
    my ($self) = @_;
    my $desired_tables = $self->{'desired tables'};
    my $is_in_file = $self->{'table in file'};
    my $depend_map = $self->{'depend map'};
    my $expand_map = $self->{'expand map'};
    my $is_required = $self->{'table required'};
    # An empty request list means to return all in file.
    if (keys %$desired_tables == 0) {
	%$desired_tables = %$is_in_file;
    }
    my @types = keys %$desired_tables;
    # We expand all tables to include these attributes as a shortcut.
    foreach my $type (@types) {
	if ($type !~ / \(.*\)/) {
	    $desired_tables->{"$type (expired)"} = 1;
	    $desired_tables->{"$type (active)"} = 1;
	}
    }
    foreach my $type (keys %$desired_tables) {
	$is_required->{$type} = 1;
	next if $is_in_file->{$type}; # No need to worry about generation
	my $attribute = undef;
	my $src_dst = undef;
	my $strip_type = $type;
	if ($type =~ / \((.*)\)/) {
	    $attribute = $1;
	    $strip_type =~ s/ \(.*\)//;
	}
	my $base_type = $strip_type;
	if ($strip_type =~ /(src|dst) (.*)/) {
	    $src_dst = $1;
	    $base_type = $2;
	}
	# For src/dst tables, try to find either something that has both
	# src and dst, or find a pre-separated table to derive from.
	next unless (exists $dependencies{$base_type} or
		     exists $dependencies{$strip_type});
	my @source_list;
	# Placing larger tables (ie, matrices and Tuple_Table) before
	# pre-separated tables (ie, src_IP_Table -> src_AS_Table) is less
	# efficient (more aggregation) but is necessary to deal with the
	# particular case of country lookups, ie preferring IP->country
	# rather than IP->AS->Country.  This will particularly break if
	# a file contains something like AS_Matrix, src_IP_Table,
	# dst_IP_Table...the AS_Matrix will be preferred to create
	# a src_Country_Table.
	if (exists $dependencies{$strip_type}) {
	    push @source_list, @{$dependencies{$strip_type}};
	}
	if (defined $src_dst and exists $dependencies{$base_type}) {
	    foreach my $source (@{$dependencies{$base_type}}) {
		push @source_list, "$src_dst $source";
	    }
	}
	foreach my $source (@source_list) {
	    # This assumes that if any of the sources for this type
	    # cannot be created, then none can.
	    # Not necessarily true, but it is for current tables.
	    # ie, if table type A is in file, and type C is requested,
	    # but C can only be made from B, and B can be made from A,
	    # this will not work.  C MUST be able to be made from A.
	    # Must make sure %$dependencies reflects this.
	    if (defined $attribute) {
		$source .= " ($attribute)";
	    }
	    if ($is_in_file->{$source} or $desired_tables->{$source}) {
		$is_required->{$source} = 1;
		$depend_map->{$type} = $source;
		push @{$expand_map->{$source}}, $type;
		last;
	    }
	}
    }
}

sub _recurse_expand {
    my ($type, $desired_tables, $expand_map, $list_ref) = @_;
    if ($desired_tables->{$type}) {
	push @$list_ref, $type;
    }
    if (exists $expand_map->{$type}) {
	foreach my $expand_type (@{$expand_map->{$type}}) {
	    _recurse_expand($expand_type, $desired_tables, $expand_map, $list_ref);
	}
    }
}

sub _make_table_list {
    my ($self) = @_;
    my $desired_tables = $self->{'desired tables'};
    my $expand_map = $self->{'expand map'};
    my @actual_list;
    unless (%$desired_tables) { # No tables requested, return all in file
	foreach my $type (@{$self->{'table list'}}) {
	    $desired_tables->{$type} = 1;
	}
	return;
    }
    foreach my $type (@{$self->{'table list'}}) {
	_recurse_expand($type, $desired_tables, $expand_map, \@actual_list);
    }
    $self->{'table list'} = \@actual_list;
}

sub _read_header {
    my ($self, $filehandle) = @_;
    my $header_ok = 0;
    while (<$filehandle>) {
	chomp;

	if (/$id_pat/o) {
	    if ($1 ne $self->{'id'}) {
		warn "Error:  Did not find expected SubinterfaceInfo ID: " .
			$self->{'id'}. "\n";
		# Still try to carry on...
	    }
	    $header_ok = 1; 
	    next;
	}

	next unless $header_ok; # Skip all until we find correct header.
	last if /^\s*$/; # Legitimate end of header.

	if (/$unknown_encaps_pat/o) {
	    $self->{'unknown encapsulation'} = $1;
	} elsif (/$ip_not_v4_pat/o) {
	    $self->{'ip not v4'} = $1;
	} elsif (/$pkts_pat/o) {
	    $self->{'packets'} = $1;
	} elsif (/$bytes_pat/o) {
	    $self->{'bytes'} = $1;
	} elsif (/$flows_pat/o) {
	    $self->{'flows'} = $1;
	} elsif (/$first_pat/o) {
	    $self->{'first'} = $1;
	} elsif (/$latest_pat/o) {
	    $self->{'latest'} = $1;
	} elsif (/$types_list_pat/o) {
	    my @types = (split /,\s*/, $1);
	    $self->{'table list'} = \@types;
	    foreach my $type (@types) {
		$self->{'table in file'}{$type} = 1;
	    }
	} elsif (/$flowest1/o) { # Do nothing.
	} elsif (/$flowest2/o) { # Do nothing.
	} elsif (/$anf1/o) { # Do nothing.
	} elsif (/$anf2/o) { # Do nothing.
	} elsif (/$anf3/o) { # Do nothing.
	} else {
	    print STDERR "Unknown header: $_\n";
	}
    }
    return $header_ok;
}

sub _write_header {
    my ($self, $filehandle, $fake_header, $dump_types, $user_types) = @_;
    my @valid_types;
    my @dump_types = @$dump_types;
    print $filehandle "\n";
    print $filehandle "# ID: $self->{'id'}\n";
    print $filehandle "# unknown_encaps: $self->{'unknown encapsulation'}\n";
    print $filehandle "#      ip_not_v4: $self->{'ip not v4'}\n";
    if ($self->{'packets'} or $fake_header) {
	if ($self->{'packets'}) {
	    print $filehandle "#           pkts: $self->{'packets'}\n";
	    print $filehandle "#          bytes: $self->{'bytes'}\n";
	    print $filehandle "#          flows: $self->{'flows'}\n";
	    print $filehandle "#          first: $self->{'first'}\n";
	    print $filehandle "#         latest: $self->{'latest'}\n";
	}
	@valid_types = $self->_make_valid_list(@dump_types);
	if (defined $user_types) {
	    @valid_types = (@valid_types, @$user_types);
	}
	print $filehandle "# Table types: ", join(', ', @valid_types);
	print $filehandle "\n";
    }
    return \@valid_types;
}

# This validates that tables to be dumped actually do/will exist.
# Having an empty @dump_list means we want to dump everything we requested
# in FileReader.
sub _make_valid_list {
    my ($self, @dump_list) = @_;
    my @valid_types;
    foreach my $type (@dump_list) {
	if ($type !~ / \(.*\)/) {
	    push @dump_list, "$type (expired)";
	    push @dump_list, "$type (active)";
	}
    }
    if ($self->{'save tables'}) { # For a fully preloaded Interval...
	if (@dump_list == 0) {
	    @valid_types = $self->get_existing_types();
	} else {
	    foreach my $type (@dump_list) {
		push @valid_types, $type if exists $self->{'tables'}{$type};
	    }
	}
    } else { # For an expectant Interval...
	if (@dump_list == 0) {
	    # At this point, the table list is all valid requested tables,
	    # not all tables in file.
	    @valid_types = @{$self->{'table list'}};
	# The table list can be just as invalid as @dump_list.
	# ... But not if invalid tables aren't in list anymore
	} else {
	    foreach my $type (@dump_list) {
		push @valid_types, $type if $self->_will_exist($type);
	    }
	}
    }
    return @valid_types;
}

sub _name_to_func {
    my ($name) = @_;
    $name =~ s/ /_/g;
    $name =~ s/_\(active\)//g;
    $name =~ s/_\(expired\)//g;
    $name = "make_$name";
    return $name;
}

sub _name_to_class {
    my ($name) = @_;
    $name =~ s/ /_/g;
    $name =~ s/src_//g;
    $name =~ s/dst_//g;
    $name =~ s/_\(active\)//g;
    $name =~ s/_\(expired\)//g;
    return $name;
}

sub _generate_tables {
    my ($self, $base_table, $type) = @_;
    unless (defined $base_table) {
	warn "Undefined base type for autogeneration.";
	return;
    }
    my @expand_list = @{$self->{'expand map'}{$type}};
    foreach my $expand_type (@expand_list) {
	my $conv_type = $expand_type;
	# Only remove src/dst if original table had previously been broken
	# into src/dst.
	if ($type =~ /(src |dst )/) {
	    $conv_type =~ s/$1//;
	}
	print STDERR "Trying to generate $expand_type from $type.\n" if $DEBUG;
	my $func = _name_to_func($conv_type);
	my $derived_table = $base_table->$func($self->{'conv options'});
	$self->{'tables'}{$expand_type} = $derived_table;
    }
}

sub get_table_types {
    my ($self) = @_;
    return @{$self->{'table list'}};
}

sub get_existing_types {
    my ($self) = @_;
    return (keys %{$self->{'tables'}});
}

sub _is_required {
    my ($self, $type) = @_;
    return defined $self->{'table required'}{$type};
}

sub _is_desired {
    my ($self, $type) = @_;
    return defined $self->{'desired tables'}{$type};
}

sub _is_in_file {
    my ($self, $type) = @_;
    return defined $self->{'table in file'}{$type};
}

sub _set_table {
    my ($self, $type, $table) = @_;
    $self->{'tables'}{$type} = $table;
}

sub _get_table {
    my ($self, $type) = @_;
    my $ret_table = $self->{'tables'}{$type};
    # Even with 'save tables' in effect, we want to delete undesired
    # tables only used for generating other tables.
    delete $self->{'tables'}{$type} unless ($self->{'save tables'} and
					    $self->_is_desired($type));
    return $ret_table;
}

sub _get_source {
    my ($self, $type) = @_;
    if (exists $self->{'depend map'}{$type}) {
	return $self->{'depend map'}{$type};
    } else {
	return undef;
    }
}

sub _can_expand {
    my ($self, $type) = @_;
    my $dependents = $self->{'expand map'}{$type};
    return undef if not $dependents;
    foreach my $depend (@$dependents) {
	return 1 unless exists $self->{'tables'}{$depend};
    }
    return undef;
}

# XXX Predicting the future is always dangerous business.
# This checks if a requested type or a generating source is in the input.
sub _will_exist {
    my ($self, $type) = @_;
    return 1 if $self->_is_in_file($type);
    my $source = $type;
    # Since we allow recursive dependencies...
    while (defined ($source = $self->_get_source($source))) {
	return 1 if $self->_is_in_file($source);
    }
    return undef;
}

sub get_metadata {
    my ($self, $field) = @_;
    if (not exists $self->{$field}) {
	carp "Unknown metadata field '$field'";
	return undef;
    }
    return $self->{$field};
}

sub set_metadata {
    my ($self, $field, $value) = @_;
    if (not exists $self->{$field}) {
	carp "Unknown metadata field '$field'";
	return undef;
    }
    return $self->{$field} = $value;
}

# NB:  If $use_timestamps is undefined, then it defaults to TRUE.
sub _dump_table {
    my ($self, $filehandle, $type, $binary_mode, $use_timestamps, $table) = @_;
    # Pass in a table if we don't have it, otherwise we attempt to
    # use an existing one.
    if (not defined $table) {
	$table = $self->{'tables'}{$type};
    }
    if (defined $table) {
	print $filehandle "\n";
	my $nument = $table->num_entries();
	print $filehandle "# begin $type ID: $self->{'id'} ($nument entries)\n";
	if ($table->other->pkts > 0) {
	    print $filehandle "# other: ";
	    if (defined $use_timestamps) {
		print $filehandle $table->write_other($use_timestamps), "\n";
	    } else {
		print $filehandle $table->write_other(), "\n";
	    }
	}
	if ($binary_mode) {
	    print $filehandle "#binary data follows\n";
	    # Ugly because default arg for save_* != undef
	    if (defined $use_timestamps) {
		$table->save_binary($filehandle, $use_timestamps);
	    } else {
		$table->save_binary($filehandle);
	    }
	} else {
	    if ($use_timestamps or not defined $use_timestamps) {
		print $filehandle "#KEYS\tpkts\tbytes\tflows\tfirst\tlatest\n";
	    } else {
		print $filehandle "#KEYS\tpkts\tbytes\tflows\n";
	    }

	    # Ugly because default arg for save_* != undef
	    if (defined $use_timestamps) {
		$table->save_text($filehandle, $use_timestamps);
	    } else {
		$table->save_text($filehandle);
	    }
	}
    }
}

# This function adds another SubinterfaceInfo to the current one,
# merging them into one SubinterfaceInfo.  By necessity, this
# requires that both SubinterfaceInfos have been preloaded.
# Thus, 'desired tables', 'table required', etc will be invalid
# after calling this function.
# XXX It assumes that the two SubinterfaceInfos are contiguous, but makes no
# assumption of their order.
# XXX It also assumes that $other has at least basic data, whereas $self might
# have none.  (ie, $to_merge->add($with_data), not $with_data->add($empty))
sub _add {
    my ($self, $other, $deep_copy) = @_;
    $self->{'id'} = $other->{'id'};
    $self->{'unknown encapsulation'} += $other->{'unknown encapsulation'};
    $self->{'ip not v4'} += $other->{'ip not v4'};
    # A SubinterfaceInfo might not have any IP data:
    if (defined $other->{'packets'}) {
	$self->{'packets'} += $other->{'packets'};
	$self->{'bytes'} += $other->{'bytes'};
	# XXX This is not, in fact, the correct flow count, since that is a
	# set operation and not merely additive.  This does, however, give
	# an upper bound on the potential number of flows.
	$self->{'flows'} += $other->{'flows'};
    }
    if (not defined $self->{'first'} or (defined $other->{'first'} and
				    $other->{'first'} < $self->{'first'})) {
	$self->{'first'} = $other->{'first'};
    }
    if (not defined $self->{'latest'} or (defined $other->{'latest'} and
				    $other->{'latest'} > $self->{'latest'})) {
	$self->{'latest'} = $other->{'latest'};
    }

    if (not $other->{'save tables'}) {
	warn "Intervals must be preloaded to be added properly!";
	return $self;
    }
    $self->{'save tables'} = $other->{'save tables'};
    while (my ($type, $table) = each %{$other->{'tables'}}) {
	print STDERR "Merging a $type.\n" if $DEBUG;
	if (exists $self->{'tables'}{$type}) {
	    $self->{'tables'}{$type}->add($table);
	} else {
	    if ($deep_copy) {
		# XXX Making room for additional entries, really would like
		# auto-scaling backend to be more efficient.
		my $mangled_type = _name_to_class($type);
		my $new_table;
		eval "require CAIDA::Tables::$mangled_type;" .
		    "\$new_table = new CAIDA::Tables::$mangled_type(undef, " .
		    "{'table_size' => 500000} );";
		$self->{'tables'}{$type} = $new_table;
		$self->{'tables'}{$type}->add($table);
	    } else {
		$self->{'tables'}{$type} = $table;
	    }
	    push @{$self->{'table list'}}, $type;
	}
    }

    return $self;
}

sub add {
    my ($self, $other) = @_;
    return $self->_add($other, 1);
}

sub nadd {
    my ($self, $other) = @_;
    return $self->_add($other, 0);
}

1;
