/*
 * Part 2 of template for caida_t.h.  This is a separate file so it can be
 * included by a ./configure test for integer formats before ./configure has
 * generated caida_t.h.  The original form of this file must be valid C.
 * During the configure test, the HAVE macros are defined automatically by
 * AC_TRY_RUN; in normal usage, this file is embedded in caida_t.h, and the
 * HAVE macros are defined by part 1, which was generated from caida_t.1.in.
 */

#if defined(__cplusplus) && !defined(__STDC_FORMAT_MACROS)
# define __STDC_FORMAT_MACROS /* Makes <inttypes.h> in C++ define fmt macros */
#endif

#if (HAVE_INTTYPES_H)
  #include <inttypes.h>
#endif

#if (HAVE_STDINT_H)
  #include <stdint.h>
#endif

#if (HAVE_MACHINE_TYPES_H)
  #include <machine/types.h>
#endif

#if (HAVE_SYS_TYPES_H)
  #include <sys/types.h>
#endif

#if (HAVE_UINT8_T == 0)
  typedef unsigned char	    uint8_t;
#endif

#if (HAVE_INT8_T == 0)
  typedef signed char	    int8_t;
#endif

#if (HAVE_UINT16_T == 0)
  #if (HAVE_U_INT16_T)
    typedef u_int16_t	    uint16_t;
  #elif (SIZEOF_SHORT == 2)
    typedef unsigned short  uint16_t;
  #endif
#endif

#if (HAVE_INT16_T == 0)
  #if (SIZEOF_SHORT == 2)
    typedef short           int16_t;
  #endif
#endif

#if (HAVE_UINT32_T == 0)
  #if (HAVE_U_INT32_T)
    typedef u_int32_t	    uint32_t;
  #elif (SIZEOF_INT == 4)
    typedef unsigned int    uint32_t;
  #elif (SIZEOF_LONG == 4)
    typedef unsigned long   uint32_t;
  #endif
#endif

#if (HAVE_INT32_T == 0)
  #if (SIZEOF_INT == 4)
    typedef int             int32_t;
  #elif (SIZEOF_LONG == 4)
    typedef long            int32_t;
  #endif
#endif

#if (HAVE_UINT64_T == 0)
  #if (HAVE_U_INT64_T)
    typedef u_int64_t	    uint64_t;
  #elif (SIZEOF_LONG_LONG == 8)
    typedef unsigned long long  uint64_t;
  #endif
#endif

#if (HAVE_INT64_T == 0)
  #if (SIZEOF_LONG_LONG == 8)
    typedef long long       int64_t;
  #endif
#endif

#ifndef UINT16_MAX
# define UINT16_MAX  0xFFFF
#endif
#ifndef INT16_MAX
# define INT16_MAX  0x7FFF
#endif

#ifndef UINT32_MAX
# define UINT32_MAX  0xFFFFFFFFul
#endif
#ifndef INT32_MAX
# define INT32_MAX  0x7FFFFFFFl
#endif

#ifndef UINT64_MAX
# define UINT64_MAX  0xFFFFFFFFFFFFFFFFull
#endif
#ifndef UINT64_MAX
# define UINT64_MAX  0x7FFFFFFFFFFFFFFFll
#endif
