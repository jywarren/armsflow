/* 
 * Copyright 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 * Common functions and data structures for coral drivers.
 *
 * This contains the struct block and struct block_pool code.  Use the
 * block_pool struct to handle storing and retreiving blocks of a certain
 * type.  The types supported are: free, locked, filling, and filled.  The
 * functions you'll be interested in are block_* and block_pool_*.  The
 * routines here currently handle locking by setting interrupt levels. 
 * Ideally, they will use spinlocks someday.
 *
 * For example, initialize your block_pool structure with
 * block_pool_initialize.  Create some blocks using block_create, add them
 * to the free block queue with block_pool_free_set.
 */

#include <sys/param.h>
#include <sys/kernel.h>
#include <sys/malloc.h>
#include <sys/conf.h>
#include <sys/systm.h>
#include <sys/errno.h>
#include <sys/mman.h>
#include <sys/fcntl.h>
#include <sys/socket.h>
#include <sys/sockio.h>
#include <sys/proc.h>
#include <sys/syslog.h>
#include <machine/clock.h> 

#include <pci/coral_common.h>


/* 
 * Initialize a block queue. 
 */
void block_queue_initialize(struct block_queue *block_queue) {
    int intlevel;
	
    /* Disable interrupts to prevent list corruption. */
    intlevel=splhigh();
    
    /* Clear both pointers to NULL to indicate emptyness. */
    block_queue->head=NULL;
    block_queue->tail=NULL;
	
    /* Enable interrupts. */
    splx(intlevel);
    
    return;
}


/* 
 * Insert to a block queue.  Inserts at the tail of the queue.
 */
void block_queue_insert(struct block_queue *block_queue, struct block *block) {
    int intlevel;
    
    /* Disable interrupts to prevent list corruption. */
    intlevel=splhigh();
    
    /* 
     * If we have no tail, the entire queue is empty.  Add this as the first
     * block.  Head and tail will point to us, and there is no next block.
     */
    if(!block_queue->tail) {
	block_queue->head=block;
	block_queue->tail=block;
	block->next=NULL;
    }
    
    /* 
     * Otherwise if we had a tail, we set the old tail to point to us next
     * and set ourselves as the new tail.
     */
    else {
    	block_queue->tail->next=block;
    	block_queue->tail=block;
    	block->next=NULL;
    }
    
    /* Enable interrupts. */
    splx(intlevel);
    
    return;
}


/* 
 * Remove from a block queue.  Removes at the head of a queue.
 */
struct block *block_queue_remove(struct block_queue *block_queue) {
    struct block *block;
    int intlevel;
    
    /* Disable interrupts to prevent list corruption. */
    intlevel=splhigh();
    
    /* If we have no head we are empty so the block returned is NULL. */
    if(!block_queue->head) {
    	block=NULL;
    }
    
    /* Otherwise, we have a block to remove. */
    else {
	
	/* Save the head block we will be returning. */
	block=block_queue->head;
    
	/* If this is the last block in the list, set head and tail to NULL. */
	if(!block->next) {
	    block_queue->head=NULL;
	    block_queue->tail=NULL;
	}

	/* Otherwise, we have another block, just move up the head. */
	else {
	    block_queue->head=block->next;
	    
	    /* 
	     * Set the next link in the block we return to NULL just to be
	     * safe that we don't later confuse the driver by passing in
	     * single blocks with stale next links.
	     */
	    block->next=NULL;
	}
    }
    
    /* Enable interrupts. */
    splx(intlevel);
    
    /* Return the removed block or NULL if we had none. */
    return(block);
}


/* 
 * Check if a queue is empty.  Returns TRUE/FALSE. 
 */
int block_queue_is_empty(struct block_queue *block_queue) {
    int intlevel;
    int retval;
    
    /* Disable interrupts to prevent list corruption. */
    intlevel=splhigh();
    
    /* If the head of the queue is NULL, the queue is empty. */
    retval = !block_queue->head;
    
    /* Enable interrupts. */
    splx(intlevel);
    
    /* Return the result. */
    return(retval);
}


/*
 * Initialize a new block_pool.
 */
void block_pool_initialize(struct block_pool *block_pool) {
    
    /* Initialize all the queues. */
    block_queue_initialize(&block_pool->block_free);
    block_queue_initialize(&block_pool->block_filled);
    block_queue_initialize(&block_pool->block_locked);
    block_queue_initialize(&block_pool->block_filling);
    
    return;
}


/*
 * Initializes a block; clears the header info.
 *
 * Do not mess with the next pointer in this routine.  Block initialize is
 * called on blocks that might already be in a list.
 */
void block_initialize(struct block *block, int interface,
    u_int blk_size)
{
    
    /* Initialize the header. */
    block->header->interface=htonl(interface);
    block->header->blk_size=htonl(blk_size);
    block->header->cell_count=htonl(0);
    block->header->cells_lost=htonl(0);
    block->header->unknown_vpi_vci=htonl(0);
    bzero(&block->header->tbegin, sizeof(struct timeval));
    bzero(&block->header->tend, sizeof(struct timeval));
    
    return;
}


/*
 * Reset the block_pool so all blocks are free and have sane settings.
 */
void block_pool_reset(struct block_pool *block_pool, int interface,
    u_int blk_size)
{
    struct block *block;
    struct block_queue *clearqueues[]={&block_pool->block_filled, &block_pool->block_locked, &block_pool->block_filling};
    int i;
    int intlevel;
    
    /*
     * This code must be done exclusively to be sure the interrupt routine
     * doesn't screw up our newly formatted blocks.
     */
    intlevel=splhigh();
    
    /* Move all blocks to the free queue. */
    for(i=0; i < sizeof(clearqueues) / sizeof(struct queue *); i++) {
    	while((block=block_queue_remove(clearqueues[i])) != NULL) {
    	    block_queue_insert(&block_pool->block_free, block);
    	}
    }
    
    /* Loop through all the free blocks, initializing each. */
    for(block=block_pool->block_free.head; block != NULL; block=block->next) {
        block_initialize(block, interface, blk_size);
    }
    
    /* Restore interrupts. */
    splx(intlevel);
    
    return;
}


/* 
 * Create a new block given memory to use for the raw block and header.
 */
struct block *block_create(char *raw_block, coral_blk_info_t *header, int index) {
    struct block *block;
    
    /* Create a block to hold the raw block. */
    block=malloc(sizeof(struct block), M_DEVBUF, M_WAITOK);
    
    /* Save the raw block, header, and index. */
    block->raw_block=raw_block;
    block->header=header;
    block->index=index;
    
    return(block);
}
