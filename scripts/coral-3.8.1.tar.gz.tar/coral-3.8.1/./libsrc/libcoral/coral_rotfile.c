/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

static const char RCSid[]="$Id: coral_rotfile.c,v 1.29.4.1 2007/07/02 19:35:26 kkeys Exp $";

#include "config.h"
#include "coraldefs.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <limits.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <assert.h>
#include <sys/types.h>
#include <time.h>
#include <sys/time.h>

#ifndef HAVE_PWD_H
# undef HAVE_GETPWNAM
#else
# ifdef HAVE_GETPWNAM
#  include <pwd.h>      /* getpwnam() */
# endif
#endif

#ifdef HAVE_LIBZ
# include <zlib.h>
#endif

#include "libcoral.h"
#include "libcoral_priv.h"

coral_rotfile_t *autorothead = NULL; /* list of auto rotating files */

/* Like coral_filename(), plus coral_strftime() expansion. */
char *coral_tfilename(const char *str, char *dst, size_t len, const struct timeval *tvp, int i)
{
    int is_dynamic = 0;
    struct timeval tv;
    char fmt[PATH_MAX];

    if ((is_dynamic = !dst) && !(dst = malloc(len)))
	return NULL;
    if (!coral_filename(str, fmt, PATH_MAX))
	return NULL;

    if (!tvp) {
	gettimeofday(&tv, NULL);
	tvp = &tv;
    }
    if (coral_strftime(dst, len, fmt, tvp, NULL, i) < 0) {
	if (is_dynamic) free(dst);
	return NULL;
    }
    return dst;
}

int coral_rf_start(coral_rotfile_t *rf, const struct timeval *tvp)
{
    const char *name;
    char *lastname = NULL;
    if (!rf->rotatable)
	return 0;

    if (rf->safety)
	*rf->safety = '\0'; /* truncate old safety suffix */
    lastname = rf->name;

    rf->name = coral_tfilename(rf->basename, NULL, PATH_MAX, tvp, rf->i);
    if (!rf->name) {
	coral_diag(0, ("%s: %s\n", "coral_rf_open", strerror(errno)));
	return -1;
    }
    if (lastname && strcmp(rf->name, lastname) == 0) {
	if (!(rf->flags & CORAL_ROT_UNSAFE)) {
	    rf->safety = strchr(rf->name, '\0');
	    if (rf->safety - rf->name > PATH_MAX - 10)
		rf->safety -= 10; /* avoid buffer overflow */
	    sprintf(rf->safety, ".%i", rf->i);
	} else {
	    coral_diag(1, ("warning: overwriting rotating file %s\n",
		rf->name));
	}
	free(lastname);
    }
    if (strcmp(rf->name, "-") == 0) {
	rf->rotatable = 0;
    }
    name = rf->tempname ? rf->tempname : rf->name;
    if (rf->open(name, rf->name, rf->info) < 0) return -1;

    rf->started = 1;
    return 0;
}

int coral_rf_end(coral_rotfile_t *rf)
{
    if (!rf->rotatable || !rf->started)
	return 0;
    rf->started = 0;
    if (rf->close(rf->info) < 0) return -1;
    if (rf->tempname)
	if (rename(rf->tempname, rf->name) != 0)
	    return -1;
    rf->i++;
    return 0;
}

static void coral_rf_autorot_remove(coral_rotfile_t *rf)
{
    coral_rotfile_t **pp;
    for (pp = &autorothead; *pp; pp = &(*pp)->next) {
	if (*pp == rf) {
	    *pp = rf->next;
	    break;
	}
    }
}

int coral_rf_close(coral_rotfile_t *rf)
{
    int result = 0;
    if (rf->info) {
	rf->rotatable = 1; /* so coral_rf_end() will work */
	result = coral_rf_end(rf);
    }

    if (rf->flags & CORAL_ROT_AUTO) /* remove from auto rotation list */
	coral_rf_autorot_remove(rf);

    if (rf->tempname) free(rf->tempname);
    free(rf->name);
    free((char*)rf->basename);
    free(rf);
    return result;
}

coral_rotfile_t *coral_rf_open(void *info,
    const char *path, const char *temp, int flags,
    int (*rfopen)(const char *name, const char *realname, void *info),
    int (*rfclose)(void *info))
{
    coral_rotfile_t *rf;
    static int tempid = 0;
    int i;

    rf = calloc(1, sizeof(*rf));
    if (!rf) {
	coral_diag(0, ("%s %s: %s\n", "coral_rf_open", path, strerror(errno)));
	return NULL;
    }
    rf->basename = strdup(path);
    rf->rotatable = 1;
    rf->flags = flags;
    rf->info = info;
    rf->open = rfopen;
    rf->close = rfclose;

    if (!temp || strcmp(path, "-") == 0) {
	rf->tempname = NULL;
    } else if (*temp) {
	rf->tempname = strdup(temp);
    } else {
	const char *p = strrchr(rf->basename, '/');
	p = p ? p + 1 : rf->basename;
	rf->tempname = malloc(p - rf->basename + 20);
	sprintf(rf->tempname, "%.*stmp%ld.%x",
	    p - rf->basename, rf->basename, (long)getpid(), tempid++);
    }

    i = rf->basename ? strlen(rf->basename) : -1;

    if (rf->flags & CORAL_ROT_AUTO) {
	rf->next = autorothead;
	autorothead = rf;
    } else {
	rf->next = NULL;
    }

    /* This is AFTER the addition to the autorot list, so even files without
     * "%" in their names will be auto-started in the first interval. */
    if (!strchr(path, '%'))
	rf->flags &= ~CORAL_ROT_AUTO;

    return rf;
}

/* shortcut functions */
coral_rotfile_t *coral_rf_open_fd(int *fdp,
    const char *path, const char *temp, int flags)
{
    return coral_rf_open(fdp, path, temp, flags,
	coral_rf_cb_open_fd, coral_rf_cb_close_fd);
}

coral_rotfile_t *coral_rf_open_file(FILE **filep,
    const char *path, const char *temp, int flags)
{
    return coral_rf_open(filep, path, temp, flags,
	coral_rf_cb_open_file, coral_rf_cb_close_file);
}

#ifdef HAVE_LIBZ
coral_rotfile_t *coral_rf_open_gzfile(coral_rf_info_gz_t *fp,
    const char *path, const char *temp, int flags)
{
    return coral_rf_open(fp, path, temp, flags,
	coral_rf_cb_open_gzfile, coral_rf_cb_close_gzfile);
}
#endif

coral_rotfile_t *coral_rf_open_ogzfile(coral_rf_info_ogz_t *fp,
    const char *path, const char *temp, int flags)
{
    if (!(coral_config.api & CORAL_API_WRITE)) {
	coral_diag(1, ("Programmer: To allow the -Cgzip option, you should "
	    "call coral_set_api() with CORAL_API_WRITE before parsing coral "
	    "options.\n"));
    }
    return coral_rf_open(fp, path, temp, flags,
	coral_rf_cb_open_ogzfile, coral_rf_cb_close_ogzfile);
}

#ifdef HAVE_LIBPCAP
coral_rotfile_t *coral_rf_open_pcap_dump(void *fp,
    const char *path, const char *temp, int flags)
{
    return coral_rf_open(fp, path, temp, flags,
	coral_rf_cb_open_pcap_dump, coral_rf_cb_close_pcap_dump);
}
#endif

void coral_rf_auto_start(struct timeval *tv)
{
    coral_rotfile_t *rf, *next;
    for (rf = autorothead; rf; rf = next) {
	next = rf->next;
	coral_rf_start(rf, tv);
	if (!(rf->flags & CORAL_ROT_AUTO))
	    coral_rf_autorot_remove(rf);
    }
}

void coral_rf_auto_end(void)
{
    coral_rotfile_t *rf;
    for (rf = autorothead; rf; rf = rf->next)
	coral_rf_end(rf);
}

/* predefined open and close callbacks for several useful file types */

int coral_rf_cb_open_fd(const char *name, const char *realname, void *vinfo)
{
    int *fdp = vinfo;
    coral_diag(8, ("coral_rf_cb_open_fd %s, %d\n", name ? name : "NULL", *fdp));
    if (strcmp(name, "-") == 0) {
	*fdp = STDOUT_FILENO;
    } else {
	*fdp = open(name, O_WRONLY | O_CREAT | O_TRUNC,
	    S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP | S_IROTH | S_IWOTH);
	if (*fdp < 0) {
	    coral_diag(0, ("%s: %s\n", name, strerror(errno)));
	    return -1;
	}
    }
    return 0;
}

int coral_rf_cb_close_fd(void *vinfo)
{
    int *fdp = vinfo;
    if (*fdp >= 0)
	if (close(*fdp) < 0) return -1;
    *fdp = -1;
    return 0;
}

int coral_rf_cb_open_file(const char *name, const char *realname, void *vinfo)
{
    FILE **filep = vinfo;
    int fd;
    coral_diag(8, ("coral_rf_cb_open_file %s, %p\n", name ? name : NULL, *filep));
    if (coral_rf_cb_open_fd(name, realname, &fd) < 0) return -1;
    *filep = fdopen(fd, "w");
    if (!*filep) {
	coral_diag(0, ("%s: %s\n", name, strerror(errno)));
	return -1;
    }
    return 0;
}

int coral_rf_cb_close_file(void *vinfo)
{
    FILE **filep = vinfo;
    if (*filep)
	if (fclose(*filep) != 0) return -1;
    *filep = NULL;
    return 0;
}

/* returns pointer to static buffer! */
const char *coral_gzmode(const char *gzmode)
{
    static char buf[16];
    if (!gzmode)
	gzmode = coral_config.gzip && *coral_config.gzip ?
	    coral_config.gzip : "1";
    sprintf(buf, "wb%.13s", gzmode);
    return buf;
}

#ifdef HAVE_LIBZ
int coral_rf_cb_open_gzfile(const char *name, const char *realname, void *vinfo)
{
    coral_rf_info_gz_t *info = vinfo;
    int fd;
    if (coral_rf_cb_open_fd(name, realname, &fd) < 0) return -1;
    info->gzfile = gzdopen(fd, coral_gzmode(info->gzmode));
    if (!info->gzfile) {
	coral_diag(0, ("%s: %s\n", name, "gzdopen error"));
	return -1;
    }
    return 0;
}

int coral_rf_cb_close_gzfile(void *vinfo)
{
    coral_rf_info_gz_t *info = vinfo;
    if (info->gzfile)
	if (gzclose(info->gzfile) != 0) return -1;
    info->gzfile = NULL;
    return 0;
}
#endif /* HAVE_LIBZ */

int coral_rf_cb_open_ogzfile(const char *name, const char *realname, void *vinfo)
{
    coral_rf_info_ogz_t *info = vinfo;
    int fd, i;
    if (coral_rf_cb_open_fd(name, realname, &fd) < 0) return -1;

    info->file = NULL;
    info->gzfile = NULL;
    i = name ? strlen(name) : -1;
    if (coral_config.gzip || (i > 3 && strcmp(realname + i - 3, ".gz") == 0)) {
#ifdef HAVE_LIBZ
	info->gzfile = gzdopen(fd, coral_gzmode(NULL));
	if (!info->gzfile) {
	    coral_diag(0, ("%s: %s\n", name, "gzdopen error (bad mode?)"));
	    return -1;
	}
#else
	coral_diag(0, ("%s: gzip output was not compiled into CoralReef.\n",
	    name));
	return -1;
#endif
    } else {
	info->file = fdopen(fd, "w");
	if (!info->file) {
	    coral_diag(0, ("%s: %s\n", name, strerror(errno)));
	    return -1;
	}
    }
    return 0;
}

int coral_rf_cb_close_ogzfile(void *vinfo)
{
    coral_rf_info_ogz_t *info = vinfo;
    if (info->file)
	if (fclose(info->file) != 0) return -1;
#ifdef HAVE_LIBZ
    if (info->gzfile)
	if (gzclose(info->gzfile) != 0) return -1;
#endif
    info->file = NULL;
    info->gzfile = NULL;
    return 0;
}

int coral_rf_ogz_write(coral_rf_info_ogz_t *info, const void *buf, size_t len)
{
    if (info->file)
	return fwrite(buf, 1, len, info->file);
#ifdef HAVE_LIBZ
    if (info->gzfile)
	return gzwrite(info->gzfile, buf, len);
#endif
    return -1;
}

int coral_rf_ogz_seek(coral_rf_info_ogz_t *info, long offset, int whence)
{
    int result;
    static char zerobuf[16];

    if (info->file) {
	result = fseek(info->file, offset, whence);
	if (result == 0 || errno != ESPIPE || whence != SEEK_CUR || offset < 0)
	    return result; /* success or unfixable error */
	/* simulate seek */
	for ( ; offset > 0; offset -= 16) {
	    size_t len = (offset-1)%16+1;
	    if (fwrite(zerobuf, 1, len, info->file) < len)
		return -1;
	}
	return 0;
    }
#ifdef HAVE_LIBZ
    if (info->gzfile)
	return gzseek(info->gzfile, offset, whence); /* XXX buggy? */
#endif
    return -1;
}

int coral_rf_ogz_flush(coral_rf_info_ogz_t *info)
{
    if (info->file)
	return fflush(info->file);
#ifdef HAVE_LIBZ
    if (info->gzfile)
	return gzflush(info->gzfile, Z_SYNC_FLUSH);
#endif
    return -1;
}

/* TODO: coral_rf_ogz_{printf,puts,putc,eof}() */

