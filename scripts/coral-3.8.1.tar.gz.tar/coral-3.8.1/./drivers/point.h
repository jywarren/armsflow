/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 * point.h - defineitions for freebsd point driver for applied telecom oc12 
 *           pci interface card.
 *
 * $Id: point.h,v 1.34 2007/06/06 18:17:42 kkeys Exp $
 *
 */

#ifndef POINT_H
#define POINT_H

#define CDEV_MAJOR 210		/* /dev/point? */

#define NPOINT 2

#define APPTEL_VENDOR_ID             0x6A61
#define APPTEL_PCI_622_DEVICE_ID     0x0622

/*#define APPTEL_POINT_OC3_REV_ID            0x81*/
/*#define APPTEL_POINT_OC12_REV_ID           0x21*/

#include <pci/pcivar.h>

#include <pci/point_amcc.h>
#include <pci/point_fpga.h>
#include <pci/point_suni.h>
#include <pci/point_cpld.h>
#include <pci/coral_ioctl.h>
#include <pci/coral_common.h>

#include <sys/select.h>

#define POINT_CELL_SIZE		60
#define POINT_BLK_SIZE		(1048576 - CORAL_BLK_HEADER_SIZE)		
#define POINT_NUM_BLKS		16
#define POINT_CELLS_PER_BLK	(POINT_BLK_SIZE / POINT_CELL_SIZE)
#define POINT_CELLBUF_SIZE	((CORAL_BLK_HEADER_SIZE + POINT_BLK_SIZE) * \
				    POINT_NUM_BLKS)

typedef struct {
    volatile amcc_regs *amcc;	/* pointers to card's mem mapped registers */
    volatile fpga_regs *fpga;
    volatile suni_regs *suni;
    volatile cpld_regs *cpld;

#define ST_OPEN			0x00000001
#define ST_FPGALOADED		0x00000002
#define ST_FPGAINITED		0x00000004
#define ST_CAPTURING		0x00000008
    u_int state;
    char losing;

    coral_io_mode_t iomode;
    u_int pointi;		/* index of this struct/associated card */

    struct selinfo s;
    pcici_t config_id;
    
    /* Bitrate of this card; KBPS_OC3c or KBPS_OC12c. */
    u_int bitrate;
    
    /* Partitions the raw memory buffer into blocks and keeps track of it. */
    struct block_pool block_pool;

    /* The raw memory used by the driver, card, and applications. */
    char *buffer;

/* stats */
    u_int rx_errors;
    u_int interrupts;
    
    /* Holds the pid of the process that opened the device. */
    pid_t pid;
    
    /* 
     * The checksum of the firmware that is currently loaded.  Used to tell
     * us if the new firmware being loaded is different, meaning we need to
     * send it to the card.
     */
    int firmware_checksum;
    
} point_622_atm;

extern point_622_atm points[];

#ifdef MODULE
#define MODUNIQ(str) mod_##str
#else
#define MODUNIQ(str) str
#endif

#define POINT_FROM_DEV(x) (points+minor(x))

void MODUNIQ(point_attach)(point_622_atm *p, int unit);
void MODUNIQ(point_interrupt)(point_622_atm *p);

#endif /* POINT_H */
