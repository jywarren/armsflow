/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/* $Id: crl_ipmatrix.c,v 1.30 2007/06/06 18:17:32 kkeys Exp $ */


static const char RCSid[]="$Id: crl_ipmatrix.c,v 1.30 2007/06/06 18:17:32 kkeys Exp $";

#include "config.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <assert.h>
#include <limits.h>
#include <sys/types.h>
#include DB_H
#include <sys/stat.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <netinet/in_systm.h>
#include <netinet/ip.h>

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>	/* inet_ntoa() */


/* Get the special structures used for handling coral format files:
   coral_atm_cell_t, hblock and dblock. */
#include "libcoral.h"


/* "key" structure for hashtable mapping src/dst pairs to packet/byte
   counts. */
struct ip_pair {
    struct in_addr	ip_src;
    struct in_addr	ip_dst;
};


/* #### unsigned long long would be better for overflow, but was
   having trouble with either the `rawdata.bytes +=' or the `%llf'
   printf format. */
struct raw_data {
    unsigned long packets;
    unsigned long bytes;
};


/* #### These should probably be unsigned long long too. */
static double total_packets;
static double total_bytes;


static int dumpRate = 0;

static u_int blockCount = 0;
static DB *matrix = NULL;
static HASHINFO hashinfo;


static int rawDB_insert(DB *rawDB, coral_pkt_buffer_t *pkt)
{
    DBT keyDBT;
    DBT dataDBT;
    struct ip_pair key;
    struct raw_data rawdata;
    u_short ip_len;
    int result;
    coral_pkt_buffer_t ip_pkt;
    struct ip *ip_header;

    if (coral_get_payload_by_proto(pkt, &ip_pkt, CORAL_NETPROTO_IP) < 0)
	return 0;

    ip_header = (struct ip*)ip_pkt.buf;

    /* Set the key to the source/destination address pair. */
    key.ip_src = ip_header->ip_src;
    key.ip_dst = ip_header->ip_dst;
    keyDBT.data = &key;
    keyDBT.size = sizeof(key);

    /* Read the current value out of the database. */
    result = rawDB->get(rawDB, &keyDBT, &dataDBT, 0);
    if (result == 0 && dataDBT.size == sizeof(rawdata)) {
	/* already existing entry */
	memcpy(&rawdata, dataDBT.data, sizeof(rawdata));
    } else if (result == 1) {
	/* new entry */
	rawdata.packets = 0;
	rawdata.bytes = 0;
    } else {
	/* error case */
	fprintf(stderr, "rawDB->get failed: %s\n",
		strerror(errno));
	return -1;
    }

    /* Increment the counters. */
    ip_len = ntohs(ip_header->ip_len);
    rawdata.packets++;
    rawdata.bytes += ip_len;
    total_packets++;
    total_bytes += ip_len;

    /* Write it out. */
    dataDBT.data = &rawdata;
    dataDBT.size = sizeof(rawdata);
    result = rawDB->put(rawDB, &keyDBT, &dataDBT, 0);
    if (result != 0) {
	fprintf(stderr, "rawDB->put failed: %s\n",
		strerror(errno));
	return -1;
    }

    return 0;
}


static int dumpDB(DB *rawDB, FILE *outFile)
{
    DBT keyDBT;
    DBT dataDBT;
    u_int which = R_FIRST;
    struct ip_pair *key_ptr;
    struct raw_data *rawdata_ptr;
    int result;

    /* Dump the total packet and byte counts, only if we aren't doing
       periodic dumping. */
    if (!dumpRate) {
	fprintf(outFile, "%f\n%f\n", total_packets, total_bytes);
    }

    while ((result = rawDB->seq(rawDB, &keyDBT, &dataDBT, which)) == 0) {
	/* #### should check the lengths are right. */
	key_ptr = keyDBT.data;
	rawdata_ptr = dataDBT.data;

	fprintf(outFile, "%s\t", inet_ntoa(key_ptr->ip_src));
	fprintf(outFile, "%s\t", inet_ntoa(key_ptr->ip_dst));
	fprintf(outFile, "%lu\t%lu\n",
	       rawdata_ptr->packets, rawdata_ptr->bytes);

	/* Get the next database item. */
	which = R_NEXT;
    }

    if (result != 1) {
	fprintf(stderr, "rawDB->seq failed: %s\n",
		strerror(errno));
	return -1;
    }

    return 0;
}

static int closeDB(DB **rawDB_ptr)
{
    DB *rawDB = *rawDB_ptr;
    int result = 0;

    if (rawDB && rawDB->close(rawDB) == -1) {
        fprintf(stderr, "rawDB->close failed: %s\n",
                strerror(errno));
        result = -1;
    }
    
    *rawDB_ptr = NULL;
    return result;    
}

static void pkthandler(coral_iface_t *iface, const coral_timestamp_t *ts,
    void *user, coral_pkt_buffer_t *pkt, coral_pkt_buffer_t *header,
    coral_pkt_buffer_t *trailer)
{
    if (matrix && dumpRate && (blockCount % dumpRate == 0)) {
	if (dumpDB(matrix, stdout) == -1) exit(errno);
	if (closeDB(&matrix) == -1) exit(errno);
    }

    /* Setup hash table for this set of blocks, if needed. */
    if (!matrix) {
	matrix = dbopen(NULL, O_RDWR|O_CREAT, 0644, DB_HASH, &hashinfo);
    }

    blockCount++;

    /* Add packet to the summary. */
    if (rawDB_insert(matrix, pkt) == -1) {
	exit(errno);
    }

    /* matrix->sync(matrix, 0); */
}

int main (int argc, char *argv[])
{
    int retval = 0;
    coral_source_t *src;

    coral_set_api(CORAL_API_PKT);
    /* coral_set_iomode(0, CORAL_RX, 1, 1); */
    coral_set_options(0, CORAL_OPT_PARTIAL_PKT);
    coral_set_duration(0);
    coral_set_max_sources(1);
    if (coral_config_arguments(argc, argv) < 0)
        exit(-1);
    if (!(src = coral_next_source(NULL)))
        exit(-1);
    if (coral_open(src) < 0)
        exit(-1);

    total_packets = 0;
    total_bytes = 0;

    /* Create an in-memory temporary db to hold a mapping from ip_pair's
       to raw_data's.  We use all of the default values, except increase
       the cachesize to 10M and set nelem to 100000. */
    /* XXX proceeding comment now lies.  db package seems to crash on
       certain datasets when I don't play with the bsize and ffactor, don't
       know why. */
    hashinfo.bsize = 256;
hashinfo.bsize = 4096;
    hashinfo.ffactor = 8;
hashinfo.ffactor = 128;
    hashinfo.nelem = 1;
    hashinfo.cachesize = 10*1024*1024;
    hashinfo.hash = NULL;
    hashinfo.lorder = 0;

    if (coral_start(src) < 0)
        exit(0);

    if (coral_read_pkts(src, NULL, pkthandler, NULL, NULL, 0, NULL) < 0)
	retval = errno;

    /* Dump and close any partial remaing db. */
    if (matrix) {
        if (dumpDB(matrix, stdout) == -1) exit(errno);
        if (closeDB(&matrix) == -1) exit(errno);
    }

    coral_stop_all();
    coral_close_all();
    exit(retval);
}
