## 
## Copyright 2004, 2005, 2006, 2007 The Regents of the University of California 
## All Rights Reserved 
## 
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
## 
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
## 
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
## 
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
## 
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program. Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
## 
## Report bugs and suggestions to coral-bugs@caida.org.
## 
package CAIDA::Tables::make_App_Table;
require Exporter;
@ISA = qw(Exporter);
@EXPORT = qw(&make_App_Table);

# Define required CVS variables
$cvs_Id = '$Id: make_App_Table.pm,v 1.6 2007/06/06 18:17:48 kkeys Exp $';
$cvs_Author = '$Author: kkeys $';
$cvs_Name = '$Name: release-3-8-1 $';
$cvs_Revision = '$Revision: 1.6 $';

use CAIDA::AppPorts;
use strict;

sub _name_unknown {
    my ($proto, $ports_ok, $src_port, $dst_port) = @_;
    my $str = "UNKNOWN_$proto";
    if ($ports_ok) {
	$str .= "_($src_port,$dst_port)";
    }
    return $str;
}

sub make_App_Table (@) {
    my ($self, $arg_hash_ref) = @_;
    my $app_ports = $arg_hash_ref->{'app_ports'};
    my $name_func = $arg_hash_ref->{'name_func'};
    unless (ref($self) =~ /Tuple_Table/ or ref($self) =~ /Proto_Ports_Table/) {
	die "make_App_Table() requires protocol and ports for app lookups";
    }
    unless ($app_ports) {
	die "Need AppPorts object to be able to do app lookups.";
    }
    require CAIDA::Tables::App_Table;
    my $app_table = new CAIDA::Tables::App_Table();
    unless (defined $name_func) {
	$name_func = \&_name_unknown;
    }

    while (my ($opaque_key, $counter) = each %{ $self->data() }) {
	# XXX This only works because the key fields for Tuple_Table and
	# Proto_Ports_Table exactly match the two argument lists for
	# match_rule().  Quite handy, though.
	my @fields = $self->get_key_fields($opaque_key);
	my $rule_ref = $app_ports->match_rule(@fields);
	my $app;
	if (defined $rule_ref) {
	    $app = $rule_ref->name();
	} else {
	    if (ref($self) =~ /Tuple_Table/) { # Toss IPs
		shift @fields;
		shift @fields;
	    }
	    $app = &$name_func(@fields);
	}
	$app_table->entry_add($app, $counter);
    }
    $app_table->total->add($self->other);
    $app_table->other->add($self->other);
    return $app_table;
}

1;
