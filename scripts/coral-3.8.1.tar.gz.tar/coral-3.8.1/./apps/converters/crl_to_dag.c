/* 
 * Copyright 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 *
 * $Id: crl_to_dag.c,v 1.18 2007/06/06 18:17:27 kkeys Exp $
 *
 */


static const char RCSid[]="$Id: crl_to_dag.c,v 1.18 2007/06/06 18:17:27 kkeys Exp $";

#include "config.h"
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <signal.h>
#include <errno.h>
#include <sys/types.h>

#include "libcoral.h"
#include "coral_dag.h"
#include "crl_byteorder.h"

static coral_dag_erf_hdr_t hdr;
static int varlen = -1;
static int slen = 0; /* XXX default to some non-zero for live interfaces? */
static coral_rf_info_ogz_t outfile;
static int trunc_layer = 0;
static int trunc_keep = 0;
static int trunc_payload = 0;
static uint8_t hdr_flags = 0;

static void quit(int sig)
{
    coral_pkt_done = 1;
}

static inline ssize_t calc_rlen(ssize_t len)
{
    ssize_t rlen;
    rlen = sizeof(coral_dag_erf_hdr_t) + len;
    if (hdr.type == DAG_TYPE_ETH) {
	rlen += 2; /* offset and pad */
    } else if (hdr.type == DAG_TYPE_AAL5) {
	rlen += 4; /* ATM header */
    }
    return crl_htons(rlen);
}

static void pkt_handler(coral_iface_t *iface,
    const coral_timestamp_t *timestamp, void *mydata,
    coral_pkt_buffer_t *packet, coral_pkt_buffer_t *header,
    coral_pkt_buffer_t *trailer)
{
    size_t caplen;

    coral_timestamp_to_dag_clock(iface, timestamp, &hdr.t);

    if (coral_interface_get_type(iface) == CORAL_TYPE_DAG) {
	hdr.lctr = ((coral_dag_erf_hdr_t*)timestamp)->lctr;
    } else {
	hdr.lctr = 0;
    }

    if (trunc_layer || trunc_payload)
	coral_pkt_truncate(packet, trunc_layer, !trunc_keep, trunc_payload);

    caplen = slen > 0 && packet->caplen > slen ? slen : packet->caplen;
    if (varlen) {
	hdr.rlen = calc_rlen(caplen);
    }
    hdr.wlen = crl_htons(packet->totlen);
    hdr.flags = hdr_flags | coral_interface_get_number(iface);

    if (coral_rf_ogz_write(&outfile, &hdr, sizeof(hdr)) < sizeof(hdr))
	goto error;
    if (hdr.type == DAG_TYPE_ETH) {
	/* offset and pad */
	if (coral_rf_ogz_seek(&outfile, 2, SEEK_CUR) < 0)
	    goto error;
    } else if (hdr.type == DAG_TYPE_AAL5) {
	/* ATM header */
	if (header) {
	    if (coral_rf_ogz_write(&outfile, header->buf, 4) < 4)
		goto error;
	} else {
	    if (coral_rf_ogz_seek(&outfile, 4, SEEK_CUR) < 0)
		goto error;
	}
    }
    if (coral_rf_ogz_write(&outfile, packet->buf, caplen) < caplen)
	goto error;
    if (!varlen && slen > caplen)
	if (coral_rf_ogz_seek(&outfile, slen - caplen, SEEK_CUR) < 0)
	    goto error;
    return;

error:
    coral_diag(0, ("write: %s", strerror(errno))); // XXX show filename
    coral_pkt_done = 1;
}

static void usage(const char *name)
{
    coral_usage(name, "[options] <source>...\n"
	"Options:\n"
	"-o<file>  write to <file>; may be gzipped (default: stdout)\n"
	"-l<n>     copy only up to protocol layer <n> and discard unknown protocols\n"
	"-p<n>     with -l, keep <n> bytes of payload past the last requested header\n"
	"-k        with -l, keep protocols unknown to CoralReef\n"
	"The next three options control the output, and should only be used if\n"
	"you want it to be different than the input (e.g. when converting a file):\n"
	"-V        write variable length (varlen) records\n"
	"          (but use -Cm=varlen to set this on input)\n"
	"-F        write fixed length (novarlen) records\n"
	"          (but use -Cm=!varlen to set this on input)\n"
	"-s<slen>  write at most <slen> bytes of packet; 0 means unlimited. [%d]\n"
	"          (but use -Cm=first=N to set this on input)\n"
	"\n"
	"If the input is a single DAG device, the -F, -V, and -s options default\n"
	"to the iomode of the device.\n"
	"\n"
	"If interval is nonzero and the output filename contains '%%',\n"
	"the output file will rotate every interval.\n",
	slen);
}

int main(int argc, char *argv[])
{
    int n, opt;
    coral_protocol_t phy, dlt;
    coral_iface_t *iface;
    struct timeval interval = {0,0}; /* for file rotation */
    const char *ofname = NULL;
    coral_rotfile_t *rf;

    hdr_flags = 0;
    signal(SIGINT, quit);

    coral_set_api(CORAL_API_PKT|CORAL_API_WRITE);
    coral_set_iomode(0, CORAL_RX_UNKNOWN, -1, 0);
    coral_set_duration(0);
    coral_set_interval(&interval);

    while ((opt = getopt(argc, argv, "C:o:VFs:l:p:k")) >= 0) {
	switch (opt) {
	case 'C':
            if (coral_config_command(optarg) < 0) {
		usage(argv[0]);
                exit(-1);
	    }
	    break;
	case 'o':
	    ofname = strdup(optarg);
	    break;
	case 'V':
	    varlen = 1;
	    break;
	case 'F':
	    varlen = 0;
	    break;
	case 's':
	    slen = atoi(optarg);
	    break;
	case 'l':
	    trunc_layer = atoi(optarg);
	    break;
	case 'p':
	    trunc_payload = atoi(optarg);
	    break;
	case 'k':
	    trunc_keep = 1;
	    break;
	default:
	    usage(argv[0]);
            exit(-1);
	}
    }

    if (varlen == 1)
	coral_set_iomode(0, CORAL_RX_VARLEN, -1, 0);
    if (slen > 0)
	coral_set_iomode(0, 0, slen, 0);

    while (optind < argc) {
        if (!coral_new_source(argv[optind]))
            exit(-1);
        optind++;
    }

    if ((n = coral_open_all()) < 0)
        exit(-1);
    if (n > 4) {
	coral_diag(0, ("%s: unable to convert more than 4 interfaces.\n",
	    argv[0]));
	exit(0);
    }

    if ((n = coral_get_source_count()) == 0) {
	coral_diag(0, ("%s: no sources\n", argv[0]));
	exit(0);
    } else if (n == 1) {
	/* default to same varlen and slen as source */
	coral_source_t *src = coral_next_source(NULL);
	const coral_io_mode_t *iomode = coral_source_get_iomode(src);
	if (varlen < 0)
	    varlen = (coral_source_get_type(src) != CORAL_TYPE_DAG) ||
		(iomode->flags & CORAL_RX_VARLEN);
	if (slen == 0)
	    slen = iomode->first_n;
    } else {
	if (varlen < 0)
	    varlen = 1;
    }

    coral_get_interval(&interval);

    if (coral_start_all() < 0)
        exit(-1);

    iface = coral_next_interface(NULL);

    phy = coral_interface_get_physical(iface);
    dlt = coral_interface_get_datalink(iface);
    if (phy == CORAL_PHY_POS) {
	hdr.type = DAG_TYPE_HDLC_POS;
    } else if (phy == CORAL_PHY_ATM) {
	hdr.type = DAG_TYPE_AAL5;
    } else if (dlt == CORAL_DLT_ETHER) {
	hdr.type = DAG_TYPE_ETH;
    } else if (dlt == CORAL_DLT_ATM_RFC1483) {
	hdr.type = DAG_TYPE_AAL5;
    } else {
	coral_diag(0, ("unable to convert %s/%s to dag format.\n",
	    coral_proto_str(phy), coral_proto_str(dlt)));
	exit(-1);
    }

    while ((iface = coral_next_interface(iface))) {
	if (phy != coral_interface_get_physical(iface) ||
	    dlt != coral_interface_get_datalink(iface))
	{
	    coral_diag(0, ("%s: all input interfaces must have the same "
		"physical and datalink type.\n",
		argv[0]));
	    exit(0);
	}
    }

    if (varlen) {
	hdr_flags |= DAG_FLAG_VARLEN;
    } else {
	if (!slen) {
	    coral_diag(0, ("You must specify at least one of -V or -s.\n"));
	    exit(-1);
	}
	hdr.rlen = calc_rlen(slen);
    }

    if (!ofname)
	ofname = "-";
    rf = coral_rf_open_ogzfile(&outfile, ofname, NULL, CORAL_ROT_AUTO);
    if (!rf)
	exit(-1);

    if (coral_read_pkts(NULL,NULL, pkt_handler, NULL,NULL, &interval, NULL) < 0)
	exit(-1);

    coral_stop_all();
    coral_close_all();
    coral_rf_close(rf);
    return 0;
}
