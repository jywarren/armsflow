package CAIDA::Traffic2::CustomCaidaHTML;
require 5.004;
## $Id: CustomCaidaHTML.pm,v 1.17 2007/06/06 18:17:50 kkeys Exp $ $Name: release-3-8-1 $
##
## -----------------------------------------------------------------------
## Perl module:CustomCaidaHTML.pm
## 
## This Perl module to provide the Caida styled web pages used for
## demonstration and research purposes.  Provided to the public only 
## as an example of how to customize the CustomCaidaHTML class.
##
## Note: test routines require the Test.pm module or Perl 5.005
##
## Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
## All Rights Reserved 
##
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
##
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
##
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
##
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
##
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program. Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
##
## Contact: coral-info@caida.org
## ---------------------------------------------------------------------

# Set up object export condition.  No functions accessible directly.
use CAIDA::Traffic2::CustomBaseHTML;
@ISA       = qw(CAIDA::Traffic2::CustomBaseHTML);

# Define required CVS variables
$cvs_Id = '$Id: CustomCaidaHTML.pm,v 1.17 2007/06/06 18:17:50 kkeys Exp $';
$cvs_Author = '$Author: kkeys $';
$cvs_Name = '$Name: release-3-8-1 $';
$cvs_Revision = '$Revision: 1.17 $';

# Enable error messages to come from calling script
use Carp;

# Force this module to adhere to safe programming practices.
use strict;

# Version of module
my $VERSION = 1.0;

# Customized global variables
# Caida logo URL
my $logo_url = "http://www.caida.org/images/logo_caida.gif";

# .   .   .   .   .  Internal object functions  .   .   .   .   .   .   .  

sub _is_blank_line($ ) {
# ---------------------------------------------------
# Small helper function (predicate) to determine if 
# the argument is an empty line
# ---------------------------------------------------
    my $data_line = shift;
    
    return($data_line =~ /^\s*$/);
}


# .   .   .   .   .  User Method Subroutines  .   .   .   .   .   .   .   .  

sub new($ ) {
# -----------------------------------------------
# Create new object.  Object oriented features
# exist mainly to have multiple report styles.
# -----------------------------------------------
    # retrieve parameters
    my $class_name = shift;
    
    # allocate space for object and bless it.
    my	$sample_object = {};
    bless $sample_object, $class_name;
    
    #    $sample_object->reset();
    
    # Return object reference
    return($sample_object);
}
	
sub html_header($$$$) {
# -------------------------------------
# Generic HTML header for report
# -------------------------------------
    my $obj_ref = shift;
    my $filehdl_ref = shift;
    my $refresh_http = shift;
    my $title = shift;
    
    # Make page expire immediately since anytime the reload button is hit
    # The page is obsolete.
    my $expires = gmtime;
    
    # Use "here-document" to include standard Caida HTML header
    print $filehdl_ref <<"EOH";
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2//EN">
<!-- **************************************** -->
<!-- Template for Traffic2 report generator . -->
<!-- HTML page output.  This is formatted ... -->
<!-- ONLY for use by the CAIDA Group!! ...... -->
<!-- Feel free to use this as an example, but -->
<!-- do not use this class for your own web . -->
<!-- pages!  Instead, either customize this . -->
<!-- to your own needs or use the ........... -->
<!-- CustomBaseHTML.pm class instead. ....... -->
<!-- **************************************** -->
<HTML>
<HEAD>
    <TITLE>
    $title
    </TITLE>

    <META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=iso-8859-1">
    <META NAME="resource-type" CONTENT="document">
    <META NAME="description" CONTENT="$title">
    <META NAME="pragma" CONTENT="no-cache">
    <!-- Set page to expire immediately.  Reload should go back to server -->
    <META HTTP-EQUIV="expires" CONTENT="$expires GMT"> 
    <!-- Force page to reload after 5 minutes -->
    <META HTTP-EQUIV="refresh" CONTENT=300>
</HEAD>

<BODY BGCOLOR="#FFFFFF">
    <!-- Standard Caida Title with organizational logo -->
	<TABLE BORDER=0 CELLSPACING=0 CELLPADDING=0>
		<TR>
			<TD>

				<A HREF="http://www.caida.org">
				<FONT COLOR="#FFFFFF">
				<IMG ALT="Cooperative Association for Internet Data Analysis" 
					 SRC="$logo_url"
				>
				</FONT>
				</A>

			</TD>
			<TD ALIGN="CENTER" WIDTH="100%">
				<FONT FACE="arial, helvetica" SIZE=+3>
				  $title
				</FONT>
			</TD>
		</TR>
	</TABLE>

	<!-- Body of HTML document starts here -->
	<HR>
	<FONT FACE="arial, helvetica">
	<P>
EOH

} # End sub html_header

sub html_footer ($$) {
# ----------------------------------------
# Method to produce an HTML footer in the
# standard Caida style.  Use this 
# subroutine as an example of how to
# to create your own custom HTML reports.
# ----------------------------------------
    my $obj_ref = shift;
    my $filehdl_ref = shift;
    my $sample_obj = shift;
    
    print $filehdl_ref <<"EOT";
	</P>
	</FONT>
	<HR>

	<!-- Standard Caida HTML Footer -->
	<!-- Use JavaScript to give Caida email, location and date -->
	<!-- Note, this depends on folks having JavaScript enabled -->
	<!-- ..... Server-side includes are a more reliable solution -->
	<TABLE WIDTH="100%" BORDER=0>
		<TR>
			<TD ALIGN="left">
			  <FONT FACE="arial, helvetica">
			  <I> For more information: </I>
			  &nbsp;
			  <!-- Give email address to reach group -->
			  info @ caida.org
			  </FONT>
			</TD>

			<TD ALIGN="right">
			  <FONT FACE="arial, helvetica">
			  <I> last update: </I> 
			  &nbsp;
			    <!-- Insert time/date of last change -->
				<SCRIPT>
				  <!--
					document.write(document.lastModified);
				  //  -->
				</SCRIPT>
			  </FONT>
			</TD>

		</TR>
		<TR>

			<TD ALIGN="center" COLSPAN=2>
			  <FONT FACE="arial, helvetica">
			  <I> this page: </I>
			  <!-- Insert URL of document for reference -->
			  &nbsp;
				<SCRIPT>
				  <!--
					document.write(document.location);
				  //  -->
				</SCRIPT>
			  </FONT>
			</TD>

		</TR>
	</TABLE>

</BODY>
</HTML>
EOT

} # End sub html_footer


# =============================
# POD Documentation for Module

__END__

=head1 NAME

CustomCaidaHTML.pm - Caida class for Custom HTML in Traffic2 reports.

=head1 SYNOPSIS

    use CAIDA::Traffic2::CustomBaseHTML;

    # Create a sample object to store data and an object combine sets.
    my html_obj = new CAIDA::Traffic2::CustomBaseHTML();

	# Create HTML header
	html_obj->html_header($obj_ref, $filehdl_ref, $refresh_http, $title);
	
	# Create HTML footer
	html_obj->html_header($obj_ref, $filehdl_ref);
	
=head1 DESCRIPTION

CustomCaidaHTML.pm is a class of customized HTML that inherits from
CustomBaseHTML.pm.  It is an example of how one can build custom HTML
reports by overwriting the methods in the base class.

=head1 EXAMPLE

See synopsis above for usage.  This file can be used as an example of how
to overwrite the base class.


=head1 AUTHOR

CoralReef Development team, CAIDA Group <coral-info@caida.org>

=head1 COPYRIGHT

Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
All Rights Reserved 

Permission to use, copy, modify and distribute any part of this
CoralReef software package for educational, research and non-profit
purposes, without fee, and without a written agreement is hereby
granted, provided that the above copyright notice, this paragraph
and the following paragraphs appear in all copies.

Those desiring to incorporate this into commercial products or use
for commercial purposes should contact the Technology Transfer
Office, University of California, San Diego, 9500 Gilman Drive, La
Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.

IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
THE POSSIBILITY OF SUCH DAMAGE.

THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
ANY PATENT, TRADEMARK OR OTHER RIGHTS.

The CoralReef software package is developed by the CoralReef
development team at the University of California, San Diego under
the Cooperative Association for Internet Data Analysis (CAIDA)
Program. Support for this effort is provided by the CAIDA grant
NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
N66001-01-1-8909, and by CAIDA members.

Report bugs and suggestions to coral-bugs@caida.org.

=cut

# .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   . 
1; ##must be last line in the file
