## 
## Copyright 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
## All Rights Reserved 
## 
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
## 
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
## 
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
## 
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
## 
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program. Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
## 
## Report bugs and suggestions to coral-bugs@caida.org.
## 

package CAIDA::Traffic2::Interval;

require CAIDA::Traffic2::SubinterfaceInfo;
use strict;
use Carp;

my $cvs_Id = '$Id: Interval.pm,v 1.35 2007/06/07 18:44:14 rkoga Exp $';
my $cvs_Author = '$Author: rkoga $';
my $cvs_Name = '$Name: release-3-8-1 $';
my $cvs_Revision = '$Revision: 1.35 $';

use vars qw($DEBUG);

$DEBUG = 0;

my $final_sample_prob_pat = 'final .* sample prob: 1/(.*)$';
my $begin_interval_pat = 'begin trace interval: (.*)$';
my $pseudo_interval_pat = '# active flows pseudo-interval';
my $duration_pat = 'trace interval duration: (.*) s$';
my $ip_pat = 'IP: (.*) Mbit/s$';
my $nonip_pat = 'Non-IP: (.*) pkts/s$';
my $pdu_pat = 'Layer 2 PDUs dropped: (.*)$';
my $pkt_pat = 'Packets dropped: (.*)$';
my $ids_pat = 'Table IDs: (.*)$';
my $begin_table_pat = 'begin (.*) ID: (.*?)( \(.*\))?$';
my $entries_pat = '\((.*) entries\)$';
my $end_table_pat = 'end of (text|binary) table';
my $other_pat = '^# other:\s*(.*)$';
my $binary_pat = '^#binary';
my $end_interval_pat = 'end trace interval';

sub new {
    my ($classname) = @_;
    my $self =  {
		    'start' => undef,
		    'duration' => undef,
		    'end' => undef,
		    'file' => undef,
		    'ip' => undef,
		    'non-ip' => undef,
		    'dropped pdu' => 0, # In case of older formats.
		    'dropped pkt' => 0,
		    'ids' => [],
		    'id info' => {},
		};
    return bless $self;
}

sub _initialize {
    my ($self, $filehandle, $desired_tables, $conv_opts, $save_tables) = @_;
    if (not $filehandle) {
	carp "Interval requires a file handle to read from.\n";
	return 0;
    }
    $self->{'file'} = $filehandle;
    my $header_ok;
    $header_ok = $self->_read_header($filehandle);
    return 0 if not $header_ok;

    foreach my $id (@{$self->{'ids'}}) {
	my $info = new CAIDA::Traffic2::SubinterfaceInfo;
	my $info_okay = $info->_initialize($id, $filehandle, $desired_tables,
					    $conv_opts, $save_tables);
	if (not $info_okay) {
	    carp "Didn't get correct SubinterfaceInfo back.";
	    next;
	}
	$self->{'id info'}{$id} = $info;
    }

    return 1;
}

sub _read_header {
    my ($self, $filehandle) = @_;
    my $header_ok = 0;
    while (<$filehandle>) {
	chomp;
	if (/$begin_interval_pat/o) {
	    $self->{'start'} = $1;
	    $header_ok = 1;
	    next;
	} elsif (/$pseudo_interval_pat/o) {
	    $header_ok = 1;
	    next;
	}

	next unless $header_ok; # Skip all until we find correct header.
	last if /^\s*$/; # Legitimate end of header.

	if (/$duration_pat/o) {
	    $self->{'duration'} = $1;
	} elsif (/$ip_pat/o) {
	    $self->{'ip'} = $1;
	} elsif (/$nonip_pat/o) {
	    $self->{'non-ip'} = $1;
	} elsif (/$pdu_pat/o) {
	    $self->{'dropped pdu'} = $1;
	} elsif (/$pkt_pat/o) {
	    $self->{'dropped pkt'} = $1;
	} elsif (/$ids_pat/o) {
	    $self->{'ids'} = [(split /,\s*/, $1)];
	} else {
	    print STDERR "Unknown header: $_\n";
	}
    }
    if (defined $self->{'start'} and defined $self->{'duration'}) {
	$self->{'end'} = $self->{'start'} + $self->{'duration'};
    }
    return $header_ok;
}

sub _write_header {
    my ($self, $filehandle) = @_;
    my $fake_header;
    print $filehandle "\n";
    # XXX We assume here that only pseudo-intervals have start == 0;
    if ($self->{'start'}) {
	print $filehandle "# begin trace interval: $self->{'start'}\n";
	print $filehandle "# trace interval duration: $self->{'duration'} s\n";
	print $filehandle "# Layer 2 PDUs dropped: $self->{'dropped pdu'}\n";
	print $filehandle "# Packets dropped: $self->{'dropped pkt'}\n";
	printf $filehandle "# IP: %.4f Mbit/s\n", $self->{'ip'};
	printf $filehandle "# Non-IP: %.4f pkts/s\n", $self->{'non-ip'};
	$fake_header = 0;
    } else {
	print $filehandle "$pseudo_interval_pat\n";
	$fake_header = 1;
    }
    print $filehandle "# Table IDs: ", join(', ', @{$self->{'ids'}}), "\n";
    return $fake_header;
}

sub _write_footer {
    my ($self, $filehandle) = @_;
    print $filehandle "\n";
    print $filehandle "# end trace interval\n";
}

sub _skip_table {
    my ($filehandle) = @_;
    while (<$filehandle>) {
	last if /$end_table_pat/o;
    }
}

sub _read_table {
    my ($self, $filehandle, $type, $id) = @_;
    my $error = 0;
    my $table_found = 0;
    my $multiplier = 1;
    while (<$filehandle>) {
	chomp;
	if (/$begin_interval_pat/o or /$pseudo_interval_pat/o) {
	    warn "Incorrectly started reading next interval!";
	    $error = 1;
	    last;
	}
	if (/$final_sample_prob_pat/o) {
	    $multiplier = $1;
	}
	if (/$begin_table_pat/o) {
	    my $found_type = $1;
	    my $found_id = $2;
	    my $num_entries = $3;
	    my $id_info = $self->{'id info'}{$found_id};
	    if ($found_type eq $type and $found_id eq $id) {
		$table_found = 1;
	    } elsif (not defined $id_info) {
		warn "Error, unknown table found: $found_type for $found_id";
		$error = 1;
		_skip_table($filehandle);
		next;
	    } elsif (not $id_info->_is_required($found_type)) {
		print STDERR "Skipping $found_type for $found_id\n" if $DEBUG;
		_skip_table($filehandle);
		next;
	    }

	    my $new_table;
	    my $mangled_type =
		CAIDA::Traffic2::SubinterfaceInfo::_name_to_class($found_type);
	    my $flow_count;
	    if (defined $num_entries and $num_entries =~ /$entries_pat/o) {
		$flow_count = $1;
	    } else {
		$flow_count = $id_info->get_metadata('flows');
		$flow_count /= 10 if $mangled_type !~ /Tuple_Table/;
	    }
	    if ($flow_count) {
		eval "require CAIDA::Tables::$mangled_type;" .
		    "\$new_table = new CAIDA::Tables::$mangled_type(undef, " .
		    "{'table_size' => $flow_count} );";
	    } else {
		# This is unlikely to happen.
		eval "require CAIDA::Tables::$mangled_type;" .
		    "\$new_table = new CAIDA::Tables::$mangled_type;";
	    }
	    if ($@) {
		warn "Error creating $mangled_type: $@";
		$error = 1;
		next;
	    }

	    while (<$filehandle>) { # Parse out optional fields
		if (/$other_pat/o) {
		    $new_table->read_other($1);
		} elsif (/$binary_pat/o) {
		    if ($multiplier > 1) {
			$new_table->load_binary($filehandle, $multiplier);
			$multiplier = 1; # reset for next table
		    } else {
			$new_table->load_binary($filehandle);
		    }
		    last;
		} else {
		    if ($multiplier > 1) {
			$new_table->load_text($filehandle, $multiplier);
			$multiplier = 1; # reset for next table
		    } else {
			$new_table->load_text($filehandle);
		    }
		    last;
		}
	    }
	    $id_info->_set_table($found_type, $new_table);
	    next;
	}

	# Only stop when we find what we want or interval is over.
	last if /$end_interval_pat/o;
	last if /^\s*$/ and $table_found;
    }
    return not $error;
}

sub get_id_infos {
    my ($self) = @_;
    my @ret_val;
    # We want to keep the same order, so no using 'keys' or 'values'.
    foreach my $id (@{$self->{'ids'}}) {
	push @ret_val, $self->{'id info'}{$id};
    }
    return @ret_val;
}

sub get_table {
    my ($self, $id_info, $type) = @_;
    $type =~ s/_/ /g;
    # Try once, if it's not there, we must read it in or generate it,
    # and try again.
    my $ret_table = $id_info->_get_table($type);
    if (not defined $ret_table) {
	if ($id_info->_is_in_file($type)) {
	    $self->_read_table($self->{'file'}, $type,
				$id_info->get_metadata('id'));
	} else {
	    my $base_type = $id_info->_get_source($type);
	    if (defined $base_type) {
		# This will automatically generate all dependent tables.
		my $base_table = $self->get_table($id_info, $base_type);
		if ($id_info->_is_desired($base_type) and defined $base_table) {
		    # A little ugly, but necessary to save desired sources.
		    $id_info->_set_table($base_type, $base_table);
		}
	    } else {
	        print STDERR "Warning: unknown type $type\n" if $DEBUG;
	    }
	}
	$ret_table = $id_info->_get_table($type);
    }
    if (defined $ret_table and $id_info->_can_expand($type)) {
	$id_info->_generate_tables($ret_table, $type);
    }
    return $ret_table;
}

# This function adds another Interval to the current one, merging them into
# one Interval.  By necessity, this requires that both Intervals have been
# preloaded.  Behavior in other cases is undefined and probably very bad.
# XXX This assumes that the two Intervals are contiguous, but makes no
# assumption of their order.
# Perhaps obviously, the two Intervals must also be running on the same link,
# as adding them otherwise has no meaning.
sub _add {
    my ($self, $other, $deep_copy) = @_;
    if (not defined $self->{'start'} or (defined $other->{'start'} and
				    $other->{'start'} < $self->{'start'}))
    {
	$self->{'start'} = $other->{'start'};
    }
    $self->{'duration'} = 0 if not defined $self->{'duration'};
    $self->{'ip'} = 0 if not defined $self->{'ip'};
    $self->{'non-ip'} = 0 if not defined $self->{'non-ip'};
    my $duration_sum = $self->{'duration'} + $other->{'duration'};
    $self->{'ip'} = ($self->{'ip'} * $self->{'duration'} +
		     $other->{'ip'} * $other->{'duration'}) /
			$duration_sum;
    $self->{'non-ip'} = ($self->{'non-ip'} * $self->{'duration'} +
		     $other->{'non-ip'} * $other->{'duration'}) /
			$duration_sum;
    $self->{'duration'} = $duration_sum;
    if (defined $self->{'start'} and defined $self->{'duration'}) {
	$self->{'end'} = $self->{'start'} + $self->{'duration'};
    }

    while (my ($id, $id_info) = each %{$other->{'id info'}}) {
	if (exists $self->{'id info'}{$id}) {
	    $self->{'id info'}{$id}->_add($id_info, $deep_copy);
	} else {
	    if ($deep_copy) {
		$self->{'id info'}{$id} = new CAIDA::Traffic2::SubinterfaceInfo;
		$self->{'id info'}{$id}->_add($id_info, $deep_copy);
	    } else {
		$self->{'id info'}{$id} = $id_info;
	    }
	    push @{$self->{'ids'}}, $id;
	}
    }

    return $self;
}

sub add {
    my ($self, $other) = @_;
    return $self->_add($other, 1);
}

sub nadd {
    my ($self, $other) = @_;
    return $self->_add($other, 0);
}

sub get_metadata {
    my ($self, $field) = @_;
    if (not exists $self->{$field}) {
	carp "Unknown metadata field '$field'";
	return undef;
    }
    return $self->{$field};
}

sub set_metadata {
    my ($self, $field, $value) = @_;
    if (not exists $self->{$field}) {
	carp "Unknown metadata field '$field'";
	return undef;
    }
    return $self->{$field} = $value;
}

1;
