#!/usr/local/bin/perl
# $Id: crl_perl_pkt_example.pl,v 1.2 2005/06/29 17:49:17 kkeys Exp $
# Example of program using Coral packet API.
# This code contains a lot of stuff you may not need in a simple program
# in order to illustrate many of the possibilities of Coral.

use strict;
use warnings;
use Getopt::Long;
use POSIX qw(:errno_h);
use IO::File;

my $coral_dir;
BEGIN { $coral_dir = "/usr/local/Coral"; }
use lib "$coral_dir/lib"; #coral global libdir#
use CRL;

my %config = (
		'doubletime' => undef,	# option -d: use double for timestamps
		'outfilename' => undef,	# option -o<name>
	     );

my %stats = (
		'pkts' => 0,
		'ip' => 0,
		'ip_bytes' => 0,
		'udp' => 0,
		'tcp' => 0,
		'tcp_syn' => 0,
		'tcp_rst' => 0,
		'min_inter' => 0,
	    );

my $interrupted = 0;
my $last_t;

my $ip_unpack = new Unpacker("ip", ["ip_len", "ip_p", "ip_offset"]);
my $tcp_unpack = new Unpacker("tcp", ["syn", "rst"]);

my ($last_doub, $last_sec, $last_nsec) = (0, 0, 0);

sub count_pkt {
    my ($iface, $pkt_result) = @_;
    my $netpkt = new Coral::Pkt_buffer;
    my $netpayload = new Coral::Pkt_buffer;

    if ($config{'doubletime'}) {
	# Example of using floating-point time.  The code is slightly
	# simpler, but rounding error is introduced.
	my $doub = Coral::read_clock_double($iface, $pkt_result->timestamp);
	if ($stats{'pkts'} > 0) { # this is not the first packet
	    # calculate interarrival time
	    my $diff = $doub - $last_doub;
	    if ($stats{'pkts'} == 1 or $diff < $stats{'double_min_inter'}) {
		$stats{'min_inter'} = $diff;
	    }
	}
	$last_doub = $doub; # remember time for next iteration

    } else {
	# Example of using seconds and nanoseconds.  The code is slightly more
	# complex, but there's no rounding error.
	my ($sec, $nsec) = Coral::read_clock_sec_nsec($iface,
						    $pkt_result->timestamp);
	if ($stats{'pkts'} > 0) { # this is not the first packet
	    # calculate interarrival time
	    my $diff = [$sec-$last_sec, $nsec-$last_nsec];
	    my $time_cmp;
	    if ($diff->[0] != $stats{'min_inter'}->[0]) {
		$time_cmp = $diff->[0] <=> $stats{'min_inter'}->[0];
	    } else {
		$time_cmp = $diff->[1] <=> $stats{'min_inter'}->[1];
	    }
	    if ($stats{'pkts'} == 1 or $time_cmp < 0) {
		$stats{'min_inter'} = $diff;
	    }
	} else {
	    $stats{'min_inter'} = [0,0];
	}
	$last_sec = $sec; # remember time for next iteration
	$last_nsec = $nsec;
    }

    # count the packet
    $stats{'pkts'}++;

    # Find Network Layer (Layer 3) or give up
    if (Coral::get_payload_by_layer($pkt_result->packet, $netpkt, 3) < 0) {
	return;
    }

    #If layer 3 is not IPv4, give up
    if ($netpkt->protocol != $Coral::NETPROTO_IPv4) {
	return;
    }

    # count the ip packet
    $stats{'ip'}++;
    my $ip = $netpkt->buf;
    my ($ip_len, $ip_p, $ip_fragment_offset) = $ip_unpack->unpack($ip);
    $stats{'ip_bytes'} += $ip_len;

    # Now we use Coral::get_payload() to get whatever is inside the IP packet,
    # no matter what "layer" it is.  If we had used Coral::get_payload(..., 4),
    # and the IP packet contained IPIP which in turn contained TCP, it would
    # find the TCP packet, when what we really want is the second IP packet.
    Coral::get_payload($netpkt, $netpayload);

    # If this is not a fragment or is the first fragment, look at it.
    # (Non-first fragments do not have a next-level header.)
    if ($ip_fragment_offset == 0) {
        if ($ip_p == 6) {
	    my $tcp = $netpayload->buf;
	    my ($syn, $rst) = $tcp_unpack->unpack($tcp);
	    $stats{'tcp'}++;
	    # If tcp flags were actually captured, look at them
	    $stats{'tcp_syn'}++ if $syn;
	    $stats{'tcp_rst'}++ if $rst;

	} elsif ($ip_p == 17) {
	    $stats{'udp'}++;
	}
    }
}

sub stop {
    my ($sig) = @_;
    # Don't abort immediately because of a ^C; instead, set the interrupted
    # flag, and let the main loop shut down gracefully.
    $interrupted = 1;
}

my $default_interval = [300, 0];

# Initialize default values of options
$config{'outfilename'} = "-"; # Default to STDOUT
$config{'doubletime'} = 0; # Default to timespec

Coral::set_api($Coral::API_PKT);
Coral::set_duration(0); # allow -Cd option, and default to unlimited
Coral::set_interval($default_interval); # allow -Ci, and set default
# Coral::set_max_sources(1);
# Coral::set_iomode(0, $Coral::RX, 48, 0);
# Coral::set_options(0, $Coral::OPT_SORT_TIME);

# handle command line options
my %opts;
my $error = !GetOptions(\%opts, "C=s@", "d!", "o=s");

foreach my $opt (keys %opts) {
    if ($opt eq 'C') {
	foreach my $command (@{$opts{$opt}}) {
	    # standard coral option
	    if (Coral::config_command($command) < 0) {
		$error++;
	    }
	}
    } elsif ($opt eq 'd') {
	$config{'doubletime'} = 1;
    } elsif ($opt eq 'o') {
	$config{'outfilename'} = $opts{$opt};
    }
}

if ($error) {
    # Coral::usage() documents all the valid -C options in addition to
    # printing the text we give here.
    Coral::usage($0, "[-d] [-o<file>] <source>...\n" .
	"-d         use double timestamps instead of timespec\n" .
	"-o<file>   specify the name of the output file (default: -)\n" .
"<file> is the name of the output file, which may contain %% specifiers\n" .
"    like strftime() for formatting a timestamp, plus:\n" .
"        %%s   number of (whole) seconds since 1970-01-01 00:00:00 UTC\n" .
"        %%f   fractional part of seconds (6 decimal places)\n" .
"        %%F   equivalent to %%Y-%%m-%%d\n" .
"    Except for %%f, all specifiers may contain printf-style modifiers\n" .
"    (e.g., \"%%010s\").\n" .
"    The filename '-' means standard output.\n"
	);
    exit -1;
}

# initialize the <source>s from the command line
foreach my $source (@ARGV) {
    if (!Coral::new_source($source)) {
	exit -1;
    }
}

my $verbosity = Coral::get_verbosity();
if (!Coral::next_source(undef) and $verbosity <= 1) {
    Coral::puts("$0: warning: no sources specified.\n");
}

# your initialization code here

# open the sources
if (Coral::open_all() <= 0) {
    exit -1;
}

# start the sources
if (Coral::start_all() < 0) {
    exit -1;
}

$SIG{INT} = \&stop;

my ($already_set, @interval) = Coral::get_interval();
if ($already_set == -1) { # Will never happen, as we set it above.
    @interval = (0, 0);
}

my $duration = Coral::get_duration();
if ($duration and $verbosity <= 2) {
    Coral::puts("collection duration max set to $duration second(s)\n");
}

# initialize libcoral packet reader
Coral::read_pkt_init(undef, undef, \@interval);

my $outfile = new IO::File;
my $rf = Coral::rf_open_filehandle($outfile, $config{'outfilename'}, undef,
				    $Coral::ROT_AUTO);
exit 1 if not $rf;

my $pkt_result = new Coral::Pkt_result;
my $interval_result = new Coral::Interval_result;
my $first_time = 1;

while (1) {
    if ($interrupted) {
	# We got an interrupt signal.  Don't break the loop; instead,
	# shut down all sources cleanly, and continue looping until all
	# sources indicate EOF.  (When a live source is shut down, it
	# will continue to return any buffered packets, but will not read
	# any new packets; tracefile sources will stop returning packets
	# immediately.)  After Coral::read_pkt() returns the last packet,
	# it will return one last end-of-interval before returning EOF.
	Coral::stop_all();
	$interrupted = 0;
    }
    my $iface = Coral::read_pkt($pkt_result, $interval_result);

    if (not defined $iface) {
	next if $! == EINTR or $! == EAGAIN;
	last;
    }

    if ($pkt_result->packet) {
	# Got packet.  Count it.
	count_pkt($iface, $pkt_result);

    } elsif (not defined $interval_result->stats) {
	# Beginning of interval.  Clear stats.
	foreach my $key (%stats) {
	    $stats{$key} = 0;
	}
	unless ($config{'outfilename'} eq '-' and not $first_time) {
	    # Print header to rotated file.
	    printf $outfile "%17s %7s %7s %10s %7s %7s %5s %12s\n",
		"", "", "", "", "", "", "", "minimum";
	    printf $outfile "%17s %7s %7s %10s %7s %7s %5s %12s\n",
		"start", "pkts", "ip", "bytes", "tcp", "SYN", "RST",
		"interarrival";
	    $first_time = 0;
	}

    } else {
	# End of interval.  Print stats.
	printf $outfile "%10d.%06d %7d %7d %10d %7d %7d %5d",
		($interval_result->begin),
		$stats{'pkts'}, $stats{'ip'}, $stats{'ip_bytes'},
		$stats{'tcp'}, $stats{'tcp_syn'}, $stats{'tcp_rst'};
	if ($stats{'pkts'} < 2) {
	    printf $outfile " %12s\n", "-";
	} elsif ($config{'doubletime'}) {
	    printf $outfile " %12.9f\n", $stats{'min_inter'};
	} else {
	    printf $outfile " %2d.%09d\n", @{$stats{'min_inter'}};
	}
    }
}

Coral::rf_close($rf); # close the output file
Coral::stop_all(); # shut down input sources
