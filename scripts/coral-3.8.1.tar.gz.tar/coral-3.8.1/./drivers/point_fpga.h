/* 
 * This is partially based on code written by Joel Apisdorf.
 */

/*
 * point_fpga.h - layout of fpgas on apptel point622
 *
 * the fpga's on the point card, there are 2, one for rx, one for tx.
 * we only use the rx one for now, as we dont have any firmware for
 * transmission / cell generation.  the fpga implements cell filtering
 * and such, ie it does the work to get only the first cell of a packet.
 *
 * $Id: point_fpga.h,v 1.8 2000/07/11 19:13:26 kkeys Exp $
 *
 */

#ifndef POINT_FPGA
#define POINT_FPGA

struct RxControl1_register {
    /* active low
     * generates a reset to external FIFO's, which causes them
     * to set their read and write pointers to location zero
     * defaults to active on powerup, so startup code must
     * release it to allow cells to be written to FIFO */
    u_char UnResetExternalFifo    : 1;

    /* enables cells to be read from S/UNI-622 */
    u_char EnableCells            : 1;
    u_char EnableFifoWrite        : 1;
    /* Enables external FIFO's to write to FIFO interface
     * of AMCC S5933Q "matchmaker" PCI bus interface */
    u_char EnableAmccWrite        : 1;
    /* active low */
    u_char UnLoadFifoLevels       : 1;
    u_char CopyTimestampsToHost   : 1;
    u_char CopyAtmHeadersToHost   : 1;
    u_char CopyAtmPayloadsToHost  : 1;
};

struct RxStatus1_register {
    /* all are Read only */
    u_char FifoEmpty              : 1;

    /* default setup of external FIFO's means this signal
     * will be asserted when they have 8 or fewer words
     * filled */
    u_char FifoAlmostEmpty        : 1;

    /* default setup of external FIFO's means this signal
     * will be asserted when they have 8 or fewer words
     * available */
    u_char FifoAlmostFull        : 1;

    /* note: when the external FIFO gets full, the RX FPGA
     * discards data until the FIFO is not full */
    u_char FifoFull               : 1;

    /* read only, cleared upon read
     * has FifoAlmostFull field above ever been TRUE? */
    u_char FifoEverAlmostFull     : 1;

    /* read only, cleared upon read
     * has FifoFull field above ever been TRUE? */
    u_char FifoEverFull           : 1;

    /* read only, cleared upon read
     * Has the 16-bit data from the AIM622
     * ever not matched its 2-bit parity? */
    u_char AimEverRxParityError   : 1;

    u_char Reserved               : 1;
};

struct RxControl2_register {
    /* 0  means only VPI[7:0] and VCI[15:0] used for state indexing
     * 1  means VPI8  (GFC0) replaces VCI15
     * 2  means VPI9  (GFC1) replaces VCI14
     * 3  means VPI10 (GFC2) replaces VCI13
     * 4  means VPI12 (GFC3) replaces VCI12
     * 5-7 mean same as 0 */
    u_char NumVciBitsStolenForVpi : 3;

    u_char PassAllAAL5Cells       : 1;

    u_char PassOamRmCells         : 1;

    u_char PassAllLastCells       : 1;

    /* valid range: 0 to 3 */
    u_char NumAAL5CellsToPass     : 2;

};

struct RxMatchUnusedBits_register {
    /* bit 0 matched against VPI8  (or VCI15 if 0<NumVciBitsStolenForVpi<5)
     * bit 1 matched against VPI9  (or VCI14 if 1<NumVciBitsStolenForVpi<5)
     * bit 2 matched against VPI10 (or VCI13 if 2<NumVciBitsStolenForVpi<5)
     * bit 3 matched against VPI11 (or VCI12 if 3<NumVciBitsStolenForVpi<5) */
    u_char Value                  : 4;
    u_char Mask                   : 4;
};

struct RxSramAddress2Control_register {
    /* holds bits 19:16 of address presented to SRAM for host */
    u_char Value                  : 4;
    u_char Reserved               : 2;
    u_char CycleIsWrite           : 1;
    /* set by host to initiate an SRAM cycle
     * cleared by FPGA when cycle is done */
    u_char DoCycle                : 1;
};

struct RxCellCountTransferReset_register {
    /* set by host to initiate the transfer and clearing
     * cleared by FPGA when operation is done */
    u_char LatchAndClear          : 1;
    u_char ClearTimestamp         : 1;	/* undocumented */
    u_char Reserved               : 6;
};


typedef struct {
/* tx fpga regs */
    u_char tx_rw;
    u_char tpad0[3];

    u_int reserved1[29];

    u_char tx_diag; /* just a scratchpad to read from or write to during early hw testing */
    u_char tpad30[3];

    u_char tx_xor;  /* used for early hardware testing */
    u_char tpad31[3];

    u_int reserved2[224];

/* rx fpga regs */

    struct RxControl1_register Control1;
    u_char pad0[3];
    
    struct RxStatus1_register Status1;
    u_char pad1[3];

    u_char FifoLevelWrite;
    u_char pad2[3];

    struct RxControl2_register Control2;
    u_char pad3[3];

    struct RxMatchUnusedBits_register MatchUnusedBits;
    u_char pad4[3];

    u_char SramAddress0;
    u_char pad5[3];

    u_char SramAddress1;
    u_char pad6[3];

    struct RxSramAddress2Control_register SramAddress2Control;
    u_char pad7[3];

    u_char SramData0;
    u_char pad8[3];

    u_char SramData1;
    u_char pad9[3];

    u_char SramData2;
    u_char pad10[3];

    u_char SramData3;
    u_char pad11[3];

    struct RxCellCountTransferReset_register CellCountTransferReset;
    u_char pad12[3];

    u_char OamRmCellCountRead0;
    u_char pad13[3];

    u_char OamRmCellCountRead1;
    u_char pad14[3];

    u_char OamRmCellCountRead2;
    u_char pad15[3];

    u_char OamRmCellCountRead3;
    u_char pad16[3];

    u_char NniMismatchCountRead0;
    u_char pad17[3];

    u_char NniMismatchCountRead1;
    u_char pad18[3];

    u_char NniMismatchCountRead2;
    u_char pad19[3];

    u_char NniMismatchCountRead3;
    u_char pad20[3];

    u_char CellDropCountRead0;
    u_char pad21[3];

    u_char CellDropCountRead1;
    u_char pad22[3];

    u_char CellDropCountRead2;
    u_char pad23[3];

    u_char CellDropCountRead3;
    u_char pad24[3];

    u_int Reserved1[ 5 ];

    u_char rx_diag; /* just a scratchpad to read from or write to during early hw testing */
    u_char rpad0[3];

    u_char rx_xor;  /* used for early hardware testing */
    u_char rpad1[3];

    u_int Reserved2[ 224 ];

} fpga_regs;

#endif POINT_FPGA
