package ParseBGPDump;
require Exporter;

## ParseBGPDump is a package for parsing a Cisco routing table dump
##
## A collection of historical routing tables from Route Views is available
##	from <http://moat.nlanr.net/AS>.  Choose the `complete gzip-ed version
##	of the whole BGP dump' option from the first group of check boxes
##
## $Id: ParseBGPDump.pm,v 1.12 2004/12/21 19:38:01 rkoga Exp $
##
##===========================================================================

$VERSION = 1.0;

@ISA = qw(Exporter);
@EXPORT_OK = qw(
		&class2mask
		&parse_table_line
		&parse_table
                &parse_AS_path
                &clean_AS_path
                &AS_path_length
                &get_next_hop_AS
                &get_origin_AS
                );

use strict;
use Carp;
use Socket qw(inet_aton);
use vars qw($package $cvs_Id $cvs_Author $cvs_Name $cvs_Revision
            $debug %parse_opts
           );

$cvs_Id = '$Id: ParseBGPDump.pm,v 1.12 2004/12/21 19:38:01 rkoga Exp $';
$cvs_Author = '$Author: rkoga $';
$cvs_Name = '$Name: release-3-8-1 $';
$cvs_Revision = '$Revision: 1.12 $';

$debug = 0;                     # turn debug mesg off by default

## Options for parsing routine
##     Currently the full parsing routine is way too slow, this hash
##     Allows the user to disable parsing of unneeded fields
##             1 = parse field
##             0 = ignore field
%parse_opts = (
    "status_code"	=> 1,
    "prefix"		=> 1,
    "nexthop"		=> 1,
    "med"		=> 1,
    "locprf"		=> 1,
    "weight"		=> 1,
    "aspath"		=> 1,
    "nexthopAS"		=> 1,
    "originAS"		=> 1,
    "origin_code"	=> 1,
    );

## Check class of network, set netmask length 
sub class2mask($) {
    my $prefix = shift;
    my ($netnum, $masklen);

    ($netnum) = $prefix =~ /^(\d+)/;
    if ( ! ( $netnum & 0x80 ) ) {
## First bit is zero => Class A
##	Check for default route
        if ( $prefix eq "0.0.0.0" ) {
            $masklen = 0;
        } else {
            $masklen = 8;
        }
    } elsif ( ! ( $netnum & 0x40 ) ) {
## First bit is one, and second bit is zero => Class B
        $masklen = 16;
    } elsif ( ! ( $netnum & 0x20 ) ) {
## First and second bits are one, third is zero => Class C
        $masklen = 24;
    } else {
## First, second, and third bits are one => Multicast or experimental
        carp "Whoa!  $netnum is not a valid unicast IP address...\n";
        $masklen = -1;
    }
    return $masklen;
}

## Calculate the number of AS entries in an AS path
sub AS_path_length ($) {
    my $aspath = shift;

    my @parsed_path = split /[\s{},]+/, $aspath;

    return scalar @parsed_path;
}

## Parse out elements of AS path
##     Returns a list of all the ASes in the input path
sub parse_AS_path ($) {
    my $aspath = shift;

    my @parsed_path = split /\s+/, $aspath;

    return @parsed_path;
}

##
## Removes effects of AS path prepending
##	(filters out dup AS numbers in AS path)
##
sub clean_AS_path(@) {
    my @path = @_;
    my $last_as = "";
    my @clean_path;

    foreach my $as ( @path ) {
        if ( ( $as ne $last_as ) && ( $as ne "NAP" ) ) {
            push @clean_path, $as;
        }
        $last_as = $as;
    }

    return @clean_path;
}

## Extract next hop AS from an AS path
sub get_next_hop_AS ($) {
    my $aspath = shift;

    my ($nexthopAS) =  $aspath =~ /^([0-9{},]+)/;
    if ( ! defined $nexthopAS ) {
        carp "Couldn't parse next hop AS out of \$$aspath\$";
    }
    return $nexthopAS;
}

## Extract origin AS from an AS path
sub get_origin_AS ($) {
    my $aspath = shift;

    my ($originAS) =  $aspath =~ /([0-9{},]+)$/;
    if ( ! defined $originAS ) {
        carp "Couldn't parse origin AS out of \$$aspath\$";
    }
    return $originAS;
}

## Extract prefix, mask length, origin AS, next hop, and AS path from a
##	Cisco BGP table line
sub parse_table_line($) {

    my ($prefix, $masklen, $originAS, $nexthop, $nexthopAS, $aspath);
    my ($origin_code, $status_code, $med, $locprf, $weight);

## Status code is the first three characters
    if ( $parse_opts{"status_code"} ) {
        carp "Parsing status code" if $debug;
        ($status_code) = /^(...)/;
        if ( ! defined $status_code ) {
            carp "Status code not found: $_\$";
        }
    }

## Check for new prefix
    if ( $parse_opts{"prefix"} ) {
	if (/(\d+\.\d+\.\d+\.\d+)(\/\d+)?\s*$/ or
	    /\d+\.\d+\.\d+\.\d+.*\d+\.\d+\.\d+\.\d+/) {
            carp "Starting new prefix record" if $debug;
            ($prefix,$masklen) = m,(\d+\.\d+\.\d+\.\d+)(?:/|)(\d*),;
            if ( ! defined $prefix ) {
                carp "Prefix not found: $_\$";            
            } elsif ( $masklen eq "" ) {
## Set length based on class of prefix
                $masklen = class2mask($prefix);
                if ( $masklen == -1 ) {
                    carp "Unable to guess length for $prefix";
                } else {
                    carp "Guessing length $masklen for $prefix" if $debug;
                }
            }
        } else {
## This line must be the continuation of the previous prefix entry
            $prefix = "CONT";
            $masklen = "CONT";
        }
    }
        
## Parse out the next hop address (don't match prefix addresses!)
    if ( $parse_opts{"nexthop"} ) {
        ($nexthop) = /\s+(\d+\.\d+\.\d+\.[1-9]\d*|0\.0\.0\.0)\s+/;
        if ( ! defined $nexthop ) {
            carp "Nexthop not found: $_\$";
        }
    }

## Parse metric (MED), Local Preference, Weight
    if ( $parse_opts{"med"} || $parse_opts{"locprf"} ||
            $parse_opts{"weight"} ) {
## XXX This just spits out character ranges, doesn't parse anything
        ($med, $locprf, $weight) =
            /^.{35}((?:\d|\s){11})((?:\d|\s){7})((?:\d|\s){7})/;
        if ( ! defined $med ) {
            carp "Metric not found: $_\$";
        } else {
## XXX Convert string to numeric value
            $med = (++$med)-1;
        }
        if ( ! defined $locprf ) {
            carp "Local Preference not found: $_\$";
        } else {
## XXX Convert string to numeric value
            $locprf = (++$locprf)-1;
        }
        if ( ! defined $weight ) {
            carp "Weight not found: $_\$";
        } else {
## XXX Convert string to numeric value
            $weight = (++$weight)-1;
        }
    }

## Parse out AS path
    if ( $parse_opts{"aspath"} || $parse_opts{"nexthopAS"} ||
            $parse_opts{"originAS"} ) {
        ($aspath) =
            /\s+((?:[1-9]\d*|\{[\d,]+\})(?: [1-9]\d*| \{[\d,]+\})*) (?:e|i|\?)/;
        if ( ! defined $aspath ) {
            carp "AS path not found: $_\$" if $debug;
        } else {

## Parse out next hop AS
            if ( $parse_opts{"nexthopAS"} ) {
                $nexthopAS = get_next_hop_AS($aspath);
            }

## Parse out origin AS
            if ( $parse_opts{"originAS"} ) {
                $originAS = get_origin_AS($aspath);
            }
        }
    }

# Parse origin code
    if ( $parse_opts{"origin_code"} ) {
        ($origin_code) = /(e|i|\?)\s*$/;
        if ( ! defined $origin_code ) {
            carp "Origin code not found: $_\$";
        }
    }

    return ($originAS, $prefix, $masklen, $nexthop, $nexthopAS, $aspath,
		$status_code, $origin_code, $med, $locprf, $weight);
}

## This procedure parses a Cisco BGP dump from `show ip bgp'
##    It takes a file handle to read from and a procedure to store the
##    parsed data in a data structure
sub parse_table ($$$) {
    my ($data_struct, $process_data, $filehandle) = @_;

    my ($version, $router, $got_prompt);

## Skip over file header
    while(<$filehandle>) { last if /^BGP table version is /; }
    if (eof($filehandle)) {
        carp "Beginning of BGP dump not found, exiting...";
        return undef;
    }

## Save table ID
    ($version, $router) = /^BGP table version is (\d+), local router ID is (\d+\.\d+\.\d+\.\d+)/;
    if (! defined $version ) {
        carp "Failed to parse table version from: $_";
    }
    if (! defined $router ) {
        carp "Failed to parse router IP address from: $_";
    }

## Skip lines before actual data
    while(<$filehandle>) { last if /^   Network/; }
    if (eof($filehandle)) {
	carp "Premature end of dump, exiting...";
        return undef;
    }

    $got_prompt = 0;
    while(<$filehandle>) {
        my ($origin_as, $newnet, $newlen, $nexthop);

        print STDERR $_ if $debug;
	# Leading 'r' (for a RIB failure) is allowed.
	if (/^[A-Za-z0-9\.\-]+(?:>|#)/ and not /^r(>)?\s+/) {
            $got_prompt = 1;
            last;
        } else {
## Send the parsed output to user-supplied routine
            $data_struct = &{$process_data}( $data_struct, parse_table_line($_) );
        }
    }
    if (! $got_prompt) {
        carp "Possible truncated file, end-of-dump prompt not found\n";
    }

    return ( $data_struct, $router, $version );
}

## From http://www.cisco.com/univercd/cc/td/doc/product/software/ios120/12cgcr/np1_c/1cprt1/1cbgp.htm
##
##The following process summarizes how Cisco's BGP chooses the best route.
##   1. If the next hop is inaccessible, do not consider it. 
##   2. If the path is internal, synchronization is enabled, and the rout
##      is not in the IGP, do not consider the route.
##   3. Prefer the path with the largest weight (weight is a Cisco
##      proprietary parameter).
##   4. If the routes have the same weight, prefer the route with the
##	largest local preference.
##   5. If the routes have the same local preference, prefer the route that
##	was originated by the local router. 
##   6. If the local preference is the same, or if no route was originated
##	by the local router, prefer the route with the shortest autonomous
##	system path. 
##   7. If the autonomous system path length is the same, prefer the route
##	with the lowest origin code (IGP < EGP < INCOMPLETE). 
##   8. If the origin codes and neighboring autonomous system are the same,
##	prefer the route with the lowest Multi Exit Discriminator (MED)
##	metric attribute.  Routes without the MED attribute are treated as
##	having a MED of 0.
##   9. If the routes have the same MED, prefer the external (EBGP) path
##	over the internal (IBGP) path.
##  10. Prefer the route that can be reached through the closest IGP
##	neighbor (the lowest IGP metric).
##  11. If the following conditions are all true, insert the route for
##	this path into the IP routing table: 
##        - Both the best route and this route are external.
##        - Both the best route and this route are from the same
##		neighboring autonomous system.
##        - maximum-paths is enabled.
##  12. If multipath is not enabled, prefer the route with the lowest IP
##	address value for the BGP router ID.
##
## This routine ignores steps 1, 2, 10, and 11 due to insufficient
##	 available information from `sho ip bgp' output

1;
