/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 * coral_pkt.h - libcoral packet structure definitions
 * NOTE: this file is also used by libsrc/CRL, and should contain only
 * those defintions needed by libsrc/CRL.
 *
 * $Id: coral_pkt.h,v 1.82 2007/06/06 18:17:54 kkeys Exp $
 */

#ifndef CORAL_PKT_H
#define CORAL_PKT_H

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    int caplen;			/* length of data actually captured in buf */
    int totlen;			/* total length of pkt (negative if unknown) */
    char is_dynamic;		/* 1 if buf is dynamically allocated */
    char passed;		/* already passed bpf filter? */
    coral_protocol_t protocol;	/* protocol */
    const char *buf;		/* data */
    int size;			/* allocated size of buf */
    coral_protocol_t parent_proto;	/* protocol of lower layer packet */
} coral_pkt_buffer_t;

typedef struct {
    /* Apparently a bug in the linux kernel can give negative pkts_drop
     * followed by a positive pkts_drop of the same magnitude (or vice versa).
     * We can't fix the bug, but we can at least make pkts_drop signed instead
     * of unsigned, so it's more obvious what happened when you get e.g.
     * -4 and 4 instead of 4294967292 and 4.
     */ 
    int64_t l2_recv;		/* Layer 2 PDUs received */
    int64_t l2_drop;		/* Layer 2 PDUs dropped */
    int64_t pkts_recv;		/* packets received */
    int64_t pkts_drop;		/* packets dropped */
    int64_t truncated;		/* packets truncated by insufficient capture */
    int64_t driver_corrupt;	/* cell looks bad from the capture device */
    int64_t too_many_vpvc;	/* too many simultaneous vpvc pairs */
    int64_t buffer_overflow;	/* AAL5 cell stream > MAX_PACKET_SIZE */
    int64_t aal5_trailer;	/* AAL5 trailer had bad length
				   probably caused by driver_corrupt drops */
    int64_t ok_packet;
} coral_pkt_stats_t;

typedef struct {
    const coral_timestamp_t *timestamp;	/* time packet was read */
    coral_pkt_buffer_t *packet;		/* link or sub-network layer packet */
    coral_pkt_buffer_t *header;		/* link layer header (eg, ATM) */
    coral_pkt_buffer_t *trailer;	/* link layer trailer (eg, AAL5) */
    uint32_t subiface;			/* subinterface identifier */
} coral_pkt_result_t;

typedef struct {
    struct timeval begin;		/* beginning of interval */
    struct timeval end;			/* end of interval */
    coral_pkt_stats_t *stats;		/* statistics for interval */
} coral_interval_result_t;

#ifdef __cplusplus
}
#endif

#endif /* CORAL_PKT_H */
