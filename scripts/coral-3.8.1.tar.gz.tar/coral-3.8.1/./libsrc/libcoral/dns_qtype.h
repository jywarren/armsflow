/* 
 * Copyright 2002, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 *
 * $Id: dns_qtype.h,v 1.10 2007/06/06 18:17:56 kkeys Exp $
 *
 */

/* from http://www.iana.org/assignments/dns-parameters as of 2006-08-16 */
defqtype(1, A)
defqtype(2, NS)
defqtype(3, MD)
defqtype(4, MF)
defqtype(5, CNAME)
defqtype(6, SOA)
defqtype(7, MB)
defqtype(8, MG)
defqtype(9, MR)
defqtype(10, NULL)
defqtype(11, WKS)
defqtype(12, PTR)
defqtype(13, HINFO)
defqtype(14, MINFO)
defqtype(15, MX)
defqtype(16, TXT)
defqtype(17, RP)
defqtype(18, AFSDB)
defqtype(19, X25)
defqtype(20, ISDN)
defqtype(21, RT)
defqtype(22, NSAP)
defqtype(23, NSAP_PTR)
defqtype(24, SIG)
defqtype(25, KEY)
defqtype(26, PX)
defqtype(27, GPOS)
defqtype(28, AAAA)
defqtype(29, LOC)
defqtype(30, NXT)
defqtype(31, EID)
defqtype(32, NIMLOC)
defqtype(33, SRV)
defqtype(34, ATMA)
defqtype(35, NAPTR)
defqtype(36, KX)
defqtype(37, CERT)
defqtype(38, A6)
defqtype(39, DNAME)
defqtype(40, SINK)
defqtype(41, OPT)	/* RFC 2671 */
defqtype(42, APL)	/* RFC 3123 */
defqtype(43, DS)	/* RFC 3658 */

defqtype(44, SSHFP)	/* RFC 4255 */
defqtype(46, RRSIG)	/* RFC 3755 */
defqtype(47, NSEC)	/* RFC 3755 */
defqtype(48, DNSKEY)	/* RFC 3755 */
defqtype(49, DHCID)	/* RFC-ietf-dnsext-dhcid-rr-13.txt */

defqtype(99, SPF)	/* RFC4408 */
defqtype(100, UINFO)	/* IANA-Reserved */
defqtype(101, UID)	/* IANA-Reserved */
defqtype(102, GID)	/* IANA-Reserved */
defqtype(103, UNSPEC)	/* IANA-Reserved */

defqtype(249, TKEY)
defqtype(250, TSIG)
defqtype(251, IXFR)
defqtype(252, AXFR)
defqtype(253, MAILB)
defqtype(254, MAILA)
defqtype(255, ANY)
