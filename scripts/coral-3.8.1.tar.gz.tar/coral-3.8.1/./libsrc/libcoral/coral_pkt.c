/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 *
 * $Id: coral_pkt.c,v 1.233 2007/06/06 18:17:54 kkeys Exp $
 *
 */

#include "config.h"
#include "coraldefs.h"
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/time.h>
#include <errno.h>

#ifdef HAVE_LIBPCAP
# include <pcap.h>
# if defined(linux) && defined(HAVE_PCAP_INT_H)
#  include <pcap-int.h>	/* for warning message. not essential. */
# endif
#endif

#include "libcoral.h"
#include "libcoral_priv.h"
#include "ethernet.h"

static const char RCSid[] = "$Id: coral_pkt.c,v 1.233 2007/06/06 18:17:54 kkeys Exp $";
 
static pkt_info_t pi[1];
static const struct timeval tvzero = { 0, 0 };
static const struct timespec tszero = { 0, 0 };

coral_iface_t *(*coral_read_pkt)(coral_pkt_result_t *pkt_result,
    coral_interval_result_t *interval_result);

#define MAX_PKTS_SINCE_READ 1000
#define is_pkt_iface(I) \
    ((I) && (pi->iface ? (I) == pi->iface : pi->src ? (I)->src == pi->src : 1))

/* After a successful read, the poll timer is set to 0, because more data may
 * be available immediately.  But if nothing is available, the poll timer is
 * set to coral_config.polltime.
 */

static void reset_stats(coral_pkt_stats_t *stats)
{
    stats->l2_recv = 0;
    stats->l2_drop = 0;
    stats->pkts_recv = 0;
    stats->pkts_drop = 0;
    stats->truncated = 0;
    stats->driver_corrupt = 0;
    stats->too_many_vpvc = 0;
    stats->buffer_overflow = 0;
    stats->aal5_trailer = 0;
    stats->ok_packet = 0;
}

static void begin_iface_interval(coral_iface_t *iface, void *param)
{
    reset_stats(&iface->pkt_stats);
    iface->synced = 0;
    iface->period_end = *(struct timespec*)param;
    iface->have_interval = (iface->period_end.tv_sec >= 0);
    if (iface->src->type.is_block && iface->u.blk.node.data) {
	/* scan the current block for end-of-interval */
	coral_check_block_interval(iface);
    } else if (!iface->eof) {
	/* iface->eof may be true for ifaces with no more data before duration
	 * expires, and eof ifaces should not count towards pi->synced. */
	if (iface->have_data) {
	    struct timespec *ts;
	    assert(iface->ts_is_valid);
	    ts = iface->src->is_interleaved ? &iface->src->ts : &iface->latest_ts;
	    iface->synced = iface->have_interval &&
		timespeccmp(ts, &iface->period_end, >=);
	} else {
	    /* no data on iface (because interval expired in realtime) */
	    iface->synced = 0;
	}
    }
    if (iface->synced)
	pi->synced++; /* don't add src->iface_count even if is_interleaved */

    /* do this last so passing duration_end does not count towards pi->synced */
    if (iface->duration_end.tv_sec >= 0 &&
	(!iface->have_interval ||
	timespeccmp(&iface->duration_end, &iface->period_end, <)))
    {
	iface->period_end = iface->duration_end;
    }
    if (iface->period_end.tv_sec >= 0 && iface->iface_type->clock_native) {
	iface->iface_type->clock_native(iface, &iface->period_end,
	    &iface->native_period_end);
    }
}

static void accum_iface_stats(coral_iface_t *iface, void *param)
{
    pkt_info_t *pip = param;
    if (iface->iface_type->update_pkt_stats)
	iface->iface_type->update_pkt_stats(iface);

#define accum_and_msg(field, fmt) \
    do { \
	if (iface->pkt_stats.field) \
	    coral_diag(1, ("warning: interval %ld.%06ld: iface %d: " fmt "\n", \
		pip->begin.tv_sec, pip->begin.tv_nsec / 1000, \
		iface->id, iface->pkt_stats.field)); \
	pi->stats.field += iface->pkt_stats.field; \
    } while (0)

    pi->stats.l2_recv		+= iface->pkt_stats.l2_recv;
    pi->stats.pkts_recv		+= iface->pkt_stats.pkts_recv;
    pi->stats.ok_packet		+= iface->pkt_stats.ok_packet;
    pi->stats.truncated		+= iface->pkt_stats.truncated;

    accum_and_msg(l2_drop,	    "dropped %" PRId64 " layer 2 PDUs");
    accum_and_msg(pkts_drop,	    "dropped %" PRId64 " packets");
    accum_and_msg(driver_corrupt,   "%" PRId64 " driver corruptions");
    accum_and_msg(too_many_vpvc,    "%" PRId64 " VPVC table overflows");
    accum_and_msg(buffer_overflow,  "%" PRId64 " buffer overflows");
    accum_and_msg(aal5_trailer,	    "%" PRId64 " bad AAL5 trailers");
}

const coral_pkt_stats_t *coral_get_iface_stats(coral_iface_t *iface)
{
    return &iface->pkt_stats;
}

/* Apply func to each iface */
static void coral_iface_loop(void (*func)(coral_iface_t *iface, void *),
    void *param)
{
    int i;

    for (i = 0; i < coral_max_iface; i++) {
	/* XXX is this really necessary? */
	if (cinst[i] && (!pi->iface || cinst[i] == pi->iface) &&
	    (!pi->src || cinst[i]->src == pi->src))
	{
	    func(cinst[i], param);
	}
    }
}

volatile int coral_pkt_done;

static void begin_interval(pkt_info_t *pip,
    coral_pkt_result_t *pkt_result, coral_interval_result_t *int_result)
{
    struct timeval tvbegin;

    if (pip->state == PKTST_NEW) {
	/* Begin first interval */
	pip->begin = pip->itime;
    } else {
	/* Begin new interval at end of last interval */
	coral_rf_auto_end();
	pip->begin = pip->end;
    }
    pi->synced = 0;
    tvbegin.tv_sec = pip->begin.tv_sec;
    tvbegin.tv_usec = pip->begin.tv_nsec / 1000;

    if (!(coral_config.flags & CORAL_OPT_NO_AUTOROTATE_ERRFILE))
	coral_rotate_errfile(&tvbegin);

    if (timespeccmp(&pip->interval, &tszero, >)) {
	pip->end = pip->begin;
	timespecadd(&pip->end, &pip->interval);
	if (pip->end.tv_sec < 0) {
	    /* wrapped */
	    pip->end.tv_sec = INT_MAX;
	    pip->end.tv_nsec = 999999999;
	} else {
	    if (pip->state == PKTST_NEW &&
		coral_config.flags & CORAL_OPT_ALIGNINT)
		    coral_align_interval(&pip->end, &pip->interval);
	}
    } else {
	pip->end.tv_sec = -1;
	pip->end.tv_nsec = -1;
    }
    coral_iface_loop(begin_iface_interval, &pip->end);
    reset_stats(&pip->stats);

    pip->state = PKTST_BEGAN_INT;

    pkt_result->timestamp = NULL;
    pkt_result->packet = NULL;
    pkt_result->header = NULL;
    pkt_result->trailer = NULL;

    if (int_result) {
	int_result->begin = tvbegin;
	int_result->end.tv_sec = 0;
	int_result->end.tv_usec = 0;
	int_result->stats = NULL;
    }
    coral_rf_auto_start(&tvbegin);
}

static void end_interval(pkt_info_t *pip,
    coral_pkt_result_t *pkt_result, coral_interval_result_t *int_result)
{
    pip->state = PKTST_ENDED_INT;

    pkt_result->timestamp = NULL;
    pkt_result->packet = NULL;
    pkt_result->header = NULL;
    pkt_result->trailer = NULL;

    coral_iface_loop(accum_iface_stats, pip);
    if (int_result) {
	int_result->begin.tv_sec = pip->begin.tv_sec;
	int_result->begin.tv_usec = pip->begin.tv_nsec / 1000;
	int_result->end.tv_sec = pip->end.tv_sec;
	int_result->end.tv_usec = pip->end.tv_nsec / 1000;
	int_result->stats = &pip->stats;
    }

    if (timespeccmp(&pi->interval, &tszero, >))
	coral_diag(8, ("interval end: %u.%09u\n",
	    pip->begin.tv_sec, pip->begin.tv_nsec));

    /* Don't call coral_rf_auto_end() or coral_rf_end(coral_config.err_rf)
     * til beginning of next interval, so end-of-interval and between-interval
     * messages go to previous interval's file.
     */
}


static void check_iomode_USERALL(const coral_iface_t *iface)
{
    const coral_io_mode_t *iomode = &iface->iface_info.iomode;
    if (!(coral_config.flags & CORAL_OPT_PARTIAL_PKT ||
	iomode->flags & CORAL_RX_USER_ALL))
    {
	coral_diag(1, ("warning: coral_read_pkts (%s): interface %d "
	    "may not include all cells of every packet\n",
	    iface->src->filename, iface->id));
    }
}

static void check_src_iomode_USERALL(const coral_source_t *src)
{
    int j;

    for (j = 0; j < CORAL_MAXOPEN; j++) {
	if (src->id[j] >= 0)
	    check_iomode_USERALL(cinst[src->id[j]]);
    }
}

/* Consume the timestamp and packet for iface, and try to update the timestamp
 * and packet using data already stored on iface.  Returns 1 if it was able
 * to update the TIMESTAMP, 0 if not.
 */
static inline int coral_consume_pkt(coral_iface_t *iface)
{
    errno = 0; /* no errors yet */
    if (iface->pkt_result.packet) {
	iface->pkt_result.timestamp = NULL;
	iface->pkt_result.packet = NULL;
	iface->pkt_result.header = NULL;
	iface->pkt_result.trailer = NULL;
	if (iface->iface_type->consume_pkt)
	    iface->iface_type->consume_pkt(iface);
    }
    return coral_consume(iface, CORAL_WANT_PKT);
}

static int current_pkt_passes_filter(coral_iface_t *iface)
{
#ifdef HAVE_BPF_FILTER
    static int filter_warned = 0;
    static int filter_warning_count = 0;

    if (!filter_warned && iface->bpfprog
#if 1
	&& !iface->ip_bpfprog
#endif
	)
    {
	coral_pkt_buffer_t nextpdu;
	coral_pkt_buffer_t *pkt = iface->pkt_result.packet;
	if (coral_proto_layer(pkt->protocol) != 2) {
	    /* do nothing */
	} else if (pkt->protocol == CORAL_DLT_CHDLC) {
	    if (coral_get_payload(pkt, &nextpdu) == 0 &&
		nextpdu.protocol == CORAL_DLT_MPLS)
	    {
		coral_diag(1, ("warning: filter may not work on %s/%s.  "
		    "Consider using 'ipfilter'.\n",
		    coral_proto_abbr(pkt->protocol),
		    coral_proto_abbr(nextpdu.protocol)));
		filter_warned = 1;
	    }
	} else if (!iface->src->dev_config.vlan_hack &&
	    (iface->iface_info.datalink == CORAL_DLT_ETHER ||
	    iface->iface_info.datalink == CORAL_DLT_IEEE802) &&
	    ((struct ether_header*)pkt)->ether_type == ETHERTYPE_VLAN)
	{
	    coral_diag(1, ("warning: pcap filter may not work on %s/VLAN.  "
		"Consider using 'ipfilter'.\n",
		coral_proto_abbr(pkt->protocol)));
	    filter_warned = 1;
	}

	if (++filter_warning_count >= 1000) {
	    /* If no candidates have occured by now, it's unlikely any ever
	     * will, so don't waste any more cycles testing for them. */
	    filter_warned = 1;
	}
    }

    if (iface->bpfprog && !iface->pkt_result.packet->passed &&
	!coral_pkt_filter(iface, iface->internal_pcap, iface->bpfprog,
	    iface->pkt_result.packet))
		return 0;

    if (iface->ip_bpfprog &&
	!coral_pkt_filter(iface, iface->ip_pcap, iface->ip_bpfprog,
	    iface->pkt_result.packet))
		return 0;
#endif
    return 1;
}

static int current_pkt_should_be_kept(coral_iface_t *iface)
{
    if (coral_config.mintime.tv_sec > 0) {
	struct timeval tv;
	CORAL_TIMESTAMP_TO_TIMEVAL(iface, iface->pkt_result.timestamp, &tv);
	if (timercmp(&tv, &coral_config.mintime, <))
	{
	    coral_diag(20, ("pkt %"PRIu64" < mintime\n", coral_config.pkts-1));
	    return 0;
	}
    }

    if (coral_config.maxtime.tv_sec > 0) {
	struct timeval tv;
	CORAL_TIMESTAMP_TO_TIMEVAL(iface, iface->pkt_result.timestamp, &tv);
	if (timercmp(&tv, &coral_config.maxtime, >))
	{
	    coral_mark_eof(iface);
	    coral_diag(20, ("pkt %"PRIu64" > maxtime\n", coral_config.pkts-1));
	    return 0;
	}
    }

    if (!current_pkt_passes_filter(iface)) {
	coral_diag(20, ("pkt %" PRIu64 " filtered\n", coral_config.pkts-1));
	return 0;
    }

    return 1;
}

static inline void set_subif(coral_iface_t *iface,
    coral_pkt_result_t *pkt_result)
{
    if ((iface->iface_info.datalink == CORAL_DLT_ETHER ||
	iface->iface_info.datalink == CORAL_DLT_IEEE802) &&
	pkt_result->subiface == 0)
	/* subiface==0 is normally redundant, but is needed by crl_guess */
    {
	struct ether_header *ether_hdr;
	uint16_t ethertype;

	ether_hdr = (struct ether_header*)pkt_result->packet->buf;
	ethertype = ntohs(ether_hdr->ether_type);

	if (ethertype == ETHERTYPE_VLAN) {
	    /* IEEE 802.1Q VLAN */
	    uint16_t tci; /* tag control information */
	    tci = ntohs(*(uint16_t*)(ether_hdr + 1));
	    pkt_result->subiface = tci & 0x0FFF;    /* vlan id */
	} else {
	    pkt_result->subiface = 0;
	}
    }
}

/* Many apps expect IPv4 packets to be labelled IPv4, not RAW_IP. */
static inline void set_ip_version(coral_pkt_result_t *pkt_result)
{
    if (pkt_result->packet->protocol == CORAL_NETPROTO_RAW_IP &&
	pkt_result->packet->caplen > 0)
    {
	switch (pkt_result->packet->buf[0] >> 4) {
	case 4: pkt_result->packet->protocol = CORAL_NETPROTO_IPv4; break;
	case 6: pkt_result->packet->protocol = CORAL_NETPROTO_IPv6; break;
	}
    }
}

static coral_iface_t *coral_find_latest_iface(coral_source_t *src)
{
    int i;
    coral_iface_t *iface = NULL;	/* NULL means none was found yet */

    if (src) {
	for (i = 0; i < src->iface_count; i++) {
	    int id = src->id[i];
	    if (cinst[id]) {
		coral_update_latest_ts(cinst[i]);
		if (!iface ||
		    timespeccmp(&cinst[id]->latest_ts, &iface->latest_ts, >))
			iface = cinst[id];
	    }
	}

    } else {
	for (i = 0; i < coral_max_iface; i++) {
	    if (cinst[i]) {
		coral_update_latest_ts(cinst[i]);
		if (!iface ||
		    timespeccmp(&cinst[i]->latest_ts, &iface->latest_ts, >))
			iface = cinst[i];
	    }
	}
    }

    return iface;
}

static void coral_update_latest_ts_func(coral_iface_t *iface, void *param)
{
    coral_update_latest_ts(iface);
}

static coral_iface_t *coral_pkt_read_done(
    coral_pkt_result_t *pkt_result, coral_interval_result_t *int_result)
{
    coral_iface_t *iface;

    pi->src ? coral_stop(pi->src) : coral_stop_all();

    coral_iface_loop(coral_update_latest_ts_func, NULL);
    if (pi->state < PKTST_DONE && pi->last_iface) {
	/* End last interval.  If caller didn't ask for intervals, we still
	 * calculate the stats (which may print a warning), treating the entire
	 * run as one interval; we just never return an int_result. */
	coral_diag(8, ("input end at pkt %" PRIu64 "\n", coral_config.pkts-1));
	end_interval(pi, pkt_result, int_result);
	pi->state = PKTST_DONE;	    /* next time: end */
	if (timespeccmp(&pi->interval, &tszero, >)) {
	    /* Use the earliest of:  interval end, duration end, latest
	     * interface timestamp. */
	    struct timespec *ts;
	    iface = (pi->iface || coral_config.flags & CORAL_OPT_SORT_TIME) ?
		pi->last_iface : coral_find_latest_iface(pi->src);
	    assert(iface->ts_is_valid);
	    ts = &iface->latest_ts;
	    assert(iface->period_end.tv_sec >= 0);
	    if (timespeccmp(&iface->period_end, &iface->latest_ts, <))
		ts = &iface->period_end;
	    int_result->end.tv_sec = ts->tv_sec;
	    int_result->end.tv_usec = ts->tv_nsec / 1000;
	    return pi->last_iface;
	}
    }

    pkt_result->timestamp = NULL;
    pkt_result->packet = NULL;
    pkt_result->header = NULL;
    pkt_result->trailer = NULL;

    if (timespeccmp(&pi->interval, &tszero, >)) {
	/* int_result->begin = NULL; */
	/* int_result->end = NULL; */
	int_result->stats = NULL;
    }

    errno = 0;
    return NULL;	/* EOF */
}

/* End an intermediate interval with the packet from iface */
static coral_iface_t *end_intermediate_interval(coral_iface_t *iface,
    pkt_info_t *pip, coral_pkt_result_t *pkt_result,
    coral_interval_result_t *int_result)
{
    int i;

    coral_diag(8, ("interval end at pkt %" PRIu64 "\n", coral_config.pkts-1));
    if (iface) {
	/* Duration was tested by coral_*_read_min, but coral_file_read_min
	 * is optimized assuming timestamps are monotonically increasing, so
	 * we do a sanity check here (once per interval, not every packet)
	 * so garbage data doesn't screw us up.
	 */
	coral_update_latest_ts(iface);
	if (iface->duration_end.tv_sec >= 0 &&
	    (iface->src->iface_count == 1 || iface->src->is_interleaved) &&
	    timespeccmp(&iface->latest_ts, &iface->duration_end, >))
	{
	    coral_diag(0, ("%s: invalid data (non-monotonically-increasing "
		"timestamp)\n", iface->src->filename));
	    errno = CORAL_EBADTIME;
	    return NULL;
	}
	/* If timestamp is too far past the end of the interval, assume the
	 * source is corrupt and the timestamp is bogus.
	 */
	if (iface->latest_ts.tv_sec - pi->end.tv_sec > 86400 /* 1 day */) {
	    coral_diag(0, ("%s: invalid data (timestamp unexpectedly large)\n",
		iface->src->filename));
	    errno = CORAL_EBADTIME;
	    return NULL;
	}
    }
    end_interval(pi, pkt_result, int_result);

    for (i = 0; i < coral_max_iface; i++)
	if (cinst[i])
	    cinst[i]->synced = 0;
    pi->synced = 0;

    return pi->last_iface;
}

/* coral_read_pkt_sort()
 * Reads time-sorted packets.
 * Waits until all ifaces have timestamps or timeouts, then returns with
 * the earliest packet, or with end-of-interval if all timestamps and timeouts
 * are > interval end, or with EOF if all ifaces are at EOF.
 */
static coral_iface_t *coral_read_pkt_sort(
    coral_pkt_result_t *pkt_result, coral_interval_result_t *int_result)
{
    coral_iface_t *iface;
    int i, readable, nbuffered;
    fd_set rfds;    /* fd's that are readable */
    fd_set mfds;    /* fd's that are missing data */
    fd_set pfds;    /* fd's that are pollable (readable without select) */
    int need_reload;
    static struct timeval polltime = { 0, 0 };

    if (coral_config.max_pkts && coral_config.pkts >= coral_config.max_pkts)
	return coral_pkt_read_done(pkt_result, int_result); /* EOF */
start:	/* control returns here after filtering a packet or duration expired */
    if (!coral_total_ifaces)
	return coral_pkt_read_done(pkt_result, int_result); /* EOF */
    readable = pi->iface ? 1 : pi->src ? pi->src->iface_count :
	coral_total_ifaces;

    if (pi->state == PKTST_CONSUME) {	/* most common case */
	/* Try to update the timestamp on the iface we used last.
	 * If all other ifaces are files or buffered, they'll already
	 * have_data.  */
	iface = NULL;
	if (!coral_consume_pkt(pi->last_iface)) {
	    pi->missing++;
	    FD_ZERO(&mfds);
	    if (pi->last_iface->src->type.is_live) {
		/* need_select++ is not conditional on src->fd >= 0, because
		 * we must use select() for polling delay even on
		 * non-selectable live ifaces */
		pi->need_select++;
		coral_copy_fd_set(coral_select_fd_max+1, &mfds,
		    &coral_select_fds);
	    }
	}
	if (pi->last_iface->src->pktq_size == pi->last_iface->src->pktq_max - 1) {
	    /* src's pktq is no longer full.  Any ifaces of same src that
	     * !have_data should now be counted as missing so we will try to
	     * read them again. */
	    coral_source_t *src = pi->last_iface->src;
	    for (i = 0; i < src->iface_count; i++) {
		if (!cinst[src->id[i]]->eof && !cinst[src->id[i]]->have_data) {
		    pi->missing++;
		}
	    }
	}

    } else if (pi->state == PKTST_RETRY) {
	iface = NULL;
    } else if (pi->state == PKTST_NEW) {
	/* First call; must update all ifaces. */
	iface = NULL;
	pi->missing = readable;
	/* Use coral_live_ifaces, not coral_select_count, because we must use
	 * select() for polling delay even on non-selectable live ifaces */
	pi->need_select = coral_live_ifaces;
	coral_copy_fd_set(coral_select_fd_max+1, &mfds, &coral_select_fds);
    } else if (pi->state == PKTST_BEGAN_INT) {
	/* We already have data from all ifaces and know which is earliest. */
	iface = pi->last_iface;
	assert(iface);
    } else if (pi->state == PKTST_ENDED_INT) {
	begin_interval(pi, pkt_result, int_result);
	return pi->last_iface;
    } else /* PKTST_DONE */ {
	return coral_pkt_read_done(pkt_result, int_result);
    }

reload:
    if (coral_pkt_done)
	return coral_pkt_read_done(pkt_result, int_result);
    /* Read until every iface has data or non-buffered timeout */
    while (pi->missing) {
	FD_ZERO(&pfds);
	if (pi->need_select) {
	    nbuffered = 0;
	    for (i = 0; i < coral_max_iface; i++) {
		if (!cinst[i] ||
		    (cinst[i]->src->fd >= 0 &&
			!FD_ISSET(cinst[i]->src->fd, &mfds)))
		{
		    continue;
		}
		if (!cinst[i]->src->type.is_buffered) {
		    if (cinst[i]->src->fd >= 0) {
			FD_SET(cinst[i]->src->fd, &pfds);
			FD_CLR(cinst[i]->src->fd, &mfds);
		    }
		} else {
		    nbuffered++;
		}
	    }
	}
	if (pi->need_select) {
	    int n;
	    struct timeval tv, *tvp;
	    struct timeval zero = { 0, 0 };
	    /* A pcaplive iface will only select as readable after its
	     * in-kernel bpf buffer fills, but we can read even if the
	     * buffer isn't full; if there's _anything_ in the buffer we'll
	     * get it, otherwise it will timeout.  So we try to read it
	     * at least once per second, for near-human-realtime results.
	     */

	    /* If we already have some readable ifaces, don't block. */
	    if (pi->missing > pi->need_select)
		tvp = &zero;
	    else
		tvp = calculate_timeout(nbuffered ? NULL : &polltime, &tv);

	    coral_diag(24, ("selecting %d of %d live ifaces",
		coral_select_count, coral_live_ifaces));
	    if (tvp)
		coral_diag(24, (" for %u.%09u s\n", tvp->tv_sec, tvp->tv_usec));
	    else
		coral_diag(24, (", no timeout\n"));
	    coral_copy_fd_set(coral_select_fd_max+1, &rfds, &mfds);
	    n = select(coral_select_fd_max+1, &rfds, NULL, NULL, tvp);
	    if (n < 0) {
		coral_diag(1, ("select: %s\n", strerror(errno)));
		return NULL;
	    }
	    coral_diag(24, ("select returned %d\n", n));
	    /* note: must check realtime_duration first, otherwise it might
	     * never get checked if sources are continuously active */
	    if (realtime_duration_ended(NULL) &&
		!(n || pi->missing > pi->need_select))
	    {
		/* Nothing WAS readable, but sources are now stopped, so
		 * they will return their buffered data or EOF immediately. */
		pi->state = PKTST_RETRY;
		goto start;
	    }
	    coral_or_fd_set(coral_select_fd_max+1, &rfds, &pfds);
	} else {
	    coral_copy_fd_set(coral_select_fd_max+1, &rfds, &pfds);
	}
	pi->missing = coral_freshen_iface(pi->src, pi->iface,
	    CORAL_WANT_PKT, &rfds, &mfds, &pi->need_select);
	if (pi->missing < 0)
	    return NULL;
    } /* while (pi->missing) */

    /* At this point, all ifaces have_data or are unbuffered and empty.
     * For each iface with data but without a packet, repeatedly prep_pkt
     * and consume until we get a packet or run out of data.  If we run
     * out of data on a non-live or buffered live iface, we must return to
     * the top of the outer loop to get more (after gathering all ifaces
     * that don't have packets).
     */
    need_reload = 0;
    pi->need_select = 0;
    for (i = 0; i < coral_max_iface; i++) {
	if (!is_pkt_iface(cinst[i])) continue;
	if (cinst[i]->src->is_interleaved ?
	    cinst[i]->src->current_iface->pkt_result.packet :
	    cinst[i]->pkt_result.packet)
	{
	    continue;
	}
	if (cinst[i]->eof && !cinst[i]->have_data)
	    continue;
	if (!cinst[i]->have_data) {
	    assert(!cinst[i]->src->type.is_buffered);
	    if (cinst[i]->src->pktq_max &&
		cinst[i]->src->pktq_size >= cinst[i]->src->pktq_max)
	    {
		/* do not count as missing */
	    } else if (cinst[i]->src->type.is_live) {
		if (cinst[i]->src->fd >= 0)
		    pi->need_select++;
		pi->missing++;
	    } else {
		assert(!"(live or full pktq)");
	    }
	    continue;
	}
	while (1) {
	    if (cinst[i]->iface_type->prep_pkt(cinst[i]) < 0) {
		coral_mark_eof(cinst[i]);
		if (!errno) errno = -1;
		return NULL;
	    }

	    if (cinst[i]->eof ||
		(cinst[i]->src->is_interleaved ?
		cinst[i]->src->current_iface->pkt_result.packet :
		cinst[i]->pkt_result.packet))
	    {
		break;
	    }

	    if (!coral_consume(cinst[i], CORAL_WANT_PKT)) {
		if (!cinst[i]->eof) {
		    pi->missing++;
		    if (cinst[i]->src->type.is_live) {
			pi->need_select++;
			FD_SET(cinst[i]->src->fd, &mfds);
			if (cinst[i]->src->type.is_buffered) {
			    /* may have buffered data */
			    need_reload++;
			} else {
			    /* there really is no more data */
			}
		    } else {
			/* file not at eof must have more data */
			need_reload++;
		    }
		}
		break;
	    }
	}
    }
    if (need_reload) {
	polltime.tv_usec = coral_config.polltime;
	goto reload;
    }
    /* next packet may follow this one immediately, so zero poll timer */
    polltime.tv_usec = 0;

    if (!coral_total_ifaces)
	return coral_pkt_read_done(pkt_result, int_result);

    if (pi->iface) {
	iface = pi->iface->have_data ? pi->iface : NULL;
	coral_update_latest_ts(iface);
    } else {
	iface = coral_find_earliest_iface(pi->src);
	if (!iface) {
	    coral_diag(25, ("no earliest iface\n"));
	    polltime.tv_usec = coral_config.polltime;
	}
    }
    if (!iface) goto reload;

    pi->itime = iface->latest_ts;
    pi->last_iface = iface;

    if (pi->state == PKTST_NEW) {
	/* Begin first interval.  Even if caller didn't ask for intervals, we
	 * must still init the stats; we just don't return an int_result. */
	begin_interval(pi, pkt_result, int_result);
	if (timespeccmp(&pi->interval, &tszero, >)) {
	    return iface;
	} else {
	    pi->end.tv_sec = INT_MAX;
	    pi->end.tv_nsec = 999999999;
	}

    } else if (iface->synced) {
	/* End interval */
	coral_diag(8, ("iface %d is synced (sort)\n", iface->id));
	return end_intermediate_interval(iface, pi, pkt_result, int_result);
    }

    coral_config.pkts++;
    assert (iface->pkt_result.packet);

    pi->state = PKTST_CONSUME;

    if (!current_pkt_should_be_kept(iface))
	goto start; /* restart as if we'd returned and been called again. */
    *pkt_result = iface->pkt_result;
    set_subif(iface, pkt_result);
    set_ip_version(pkt_result);
    if (coral_config.anon.alg != CORAL_ANON_ALG_NONE)
	if (!coral_pkt_anonymize(pkt_result->packet))
	    goto start; /* discard un-anonymizable packet */
    return iface;
}

/* Of interfaces that have_data, return one of them.
 * If src is not NULL, it searches only interfaces of src,
 * otherwise it searches all interfaces.
 */
static inline coral_iface_t *coral_find_unsynced_iface_with_data(coral_source_t *src)
{
    int i;

    if (src) {
	for (i = 0; i < src->iface_count; i++) {
	    int id = src->id[i];
	    if (cinst[id] && cinst[id]->have_data && !cinst[id]->synced)
		return cinst[id];
	}

    } else {
	/* optimized: unrolled loop for common cases of 1 or 2 interfaces */
	switch (coral_max_iface) {
	case 2:
	    if (cinst[1] && cinst[1]->have_data && !cinst[1]->synced)
		return cinst[1];
	    /* fall through */
	case 1:
	    if (cinst[0] && cinst[0]->have_data && !cinst[0]->synced)
		return cinst[0];
	    return NULL;
	default:
	    for (i = 0; i < coral_max_iface; i++) {
		if (cinst[i] && cinst[i]->have_data && !cinst[i]->synced)
		    return cinst[i];
	    }
	}
    }

    return NULL;
}

/* coral_read_pkt_nosort()
 * Optimized for unsorted packets.
 * Returns with a packet as soon as it finds _any_ iface with a packet, or
 * returns with end-of-interval when all valid ifaces are past the interval
 * end, or returns with EOF if all ifaces are at EOF.  An iface is past the
 * interval end if 1) we've seen a timestamp > interval end, or 2) the iface
 * is live and non-buffered and real time > interval end.
 */
static coral_iface_t *coral_read_pkt_nosort(
    coral_pkt_result_t *pkt_result, coral_interval_result_t *int_result)
{
    coral_iface_t *iface;
    int i, readable, nbuffered, stop;
    fd_set rfds;    /* fd's that are readable */
    int passed_interval_in_realtime;
    static struct timeval polltime = { 0, 0 };

    if (coral_config.max_pkts && coral_config.pkts >= coral_config.max_pkts)
	return coral_pkt_read_done(pkt_result, int_result); /* EOF */
start:	/* control returns here after filtering a packet or duration expired */
    if (!coral_total_ifaces)
	return coral_pkt_read_done(pkt_result, int_result); /* EOF */
    readable = pi->iface ? 1 : pi->src ? pi->src->iface_count :
	coral_total_ifaces;

    if (pi->state == PKTST_CONSUME) {	/* most common case */
	if (coral_consume_pkt(pi->last_iface)) {
	    if (coral_live_ifaces && pi->pkts_since_read > MAX_PKTS_SINCE_READ)
	    {
		iface = NULL;
		goto read;
	    }
	    iface = pi->last_iface;
	    goto have_data;
	}
	iface = NULL;
	if (errno && errno != EAGAIN) return NULL; /* error during consume */
    } else if (pi->state == PKTST_RETRY) {
	iface = NULL;
    } else if (pi->state == PKTST_NEW) {
	pi->synced = 0;
	/* must begin interval with earliest packet */
	return coral_read_pkt_sort(pkt_result, int_result);
    } else if (pi->state == PKTST_BEGAN_INT) {
	if (pi->synced >= coral_total_ifaces) {
	    assert (pi->synced == coral_total_ifaces);
	    /* in the case of empty interval, all ifaces are already synced */
	    coral_diag(8, ("began interval with all %d ifaces synced\n",
		pi->synced));
	    return end_intermediate_interval(NULL, pi, pkt_result, int_result);
	}
	if ((iface = pi->last_iface)) {
	    if (iface->pkt_result.packet) goto have_pkt;
	    if (iface->have_data) goto have_data;
	    iface = NULL;
	}
    } else if (pi->state == PKTST_ENDED_INT) {
	begin_interval(pi, pkt_result, int_result);
	return pi->last_iface;
    } else /* PKTST_DONE */ {
	return coral_pkt_read_done(pkt_result, int_result);
    }

reload:
    if (coral_pkt_done)
	return coral_pkt_read_done(pkt_result, int_result);

    if ((iface = coral_find_unsynced_iface_with_data(pi->src)))
	goto have_data;

read:
    pi->pkts_since_read = 0;
    if (coral_live_ifaces) {
	nbuffered = 0;
	stop = i = pi->last_iface ? pi->last_iface->id : coral_max_iface - 1;
	do {
	    if (++i >= coral_max_iface) i = 0;
	    if (!cinst[i] || cinst[i]->eof || cinst[i]->synced)
		continue;
	    if (cinst[i]->have_data) {
		iface = cinst[i];
		goto have_data;
	    }
	    if (!cinst[i]->src->type.is_buffered) {
		/* read_any() may read from ANY iface of cinst[i]->src */
		if ((iface = coral_read_any(cinst[i]))) {
		    if (iface->synced) {
			pi->synced++;
		    } else {
			iface->have_data = 1;
			goto have_data;
		    }
		} else if (errno && errno != EAGAIN) {
		    return NULL;
		}
	    } else {
		nbuffered++;
	    }
	} while (i != stop);
	/* if none of the live interfaces have buffered data... */
	{
	    int n;
	    struct timeval zero = { 0, 0 };
	    struct timeval tv, *tvp;
	    /* A pcaplive iface will only select as readable after its
	     * in-kernel bpf buffer fills, but we can read even if the
	     * buffer isn't full; if there's _anything_ in the buffer we'll
	     * get it, otherwise it will timeout.  So we try to read it
	     * at least once per second, for near-human-realtime results.
	     */

	    /* If we already have some readable ifaces, don't block. */
	    if (coral_offline_ifaces)
		tvp = &zero;
	    else
		tvp = calculate_timeout(nbuffered ? NULL : &polltime, &tv);

#ifdef NDEBUG
	    coral_diag(24, ("selecting %d of %d live ifaces\n",
		coral_select_count, coral_live_ifaces));
	    if (tvp)
		coral_diag(24, (" for %u.%09u s\n", tvp->tv_sec, tvp->tv_usec));
	    else
		coral_diag(24, (", no timeout\n"));
#endif
	    coral_copy_fd_set(coral_select_fd_max+1, &rfds, &coral_select_fds);
	    n = select(coral_select_fd_max+1, &rfds, NULL, NULL, tvp);
	    if (n < 0) {
		coral_diag(1, ("select: %s\n", strerror(errno)));
		return NULL;
	    }
#ifdef NDEBUG
	    coral_diag(24, ("select returned %d\n", n));
#endif
	    /* note: must check realtime_duration first, otherwise it might
	     * never get checked if sources are continuously active */
	    if (realtime_duration_ended(NULL) && !(n || coral_offline_ifaces)) {
		/* we may have EOF'd all ifaces */
		if (!coral_total_ifaces) {
		    coral_diag(8, ("all ifaces ended\n"));
		    return coral_pkt_read_done(pkt_result, int_result);
		}
		/* we may have EOF'd all unsynced ifaces blocking global sync */
		if (pi->synced == coral_total_ifaces) {
		    coral_diag(8, ("all %d ifaces synced\n", pi->synced));
		    return end_intermediate_interval(NULL, pi, pkt_result,
			int_result);
		}
		/* Nothing WAS readable, but sources are now stopped, so
		 * they will return their buffered data or EOF immediately. */
		pi->state = PKTST_RETRY;
		coral_diag(8, ("pi->synced=%d; coral_total_ifaces=%d\n",
		    pi->synced, coral_total_ifaces));
		goto start;
	    }
	}
    }

    passed_interval_in_realtime = -1; /* -1 indicates tvnow hasn't been set */

    for (i = 0; i < coral_max_iface; i++) {
	if (!cinst[i] || cinst[i]->eof || cinst[i]->synced)
	    continue;
	if (!cinst[i]->src->type.is_buffered ||
	    FD_ISSET(cinst[i]->src->fd, &rfds))
	{
	    if (cinst[i]->have_data) {
		iface = cinst[i];
		goto have_data;
	    }
	    /* read_any() may read from ANY iface of cinst[i]->src */
	    iface = coral_read_any(cinst[i]);
	    if (iface) {
		if (iface->synced) {
		    pi->synced++;
		} else {
		    iface->have_data = 1;
		    goto have_data;
		}
	    } else if (errno && errno != EAGAIN) {
		return NULL;
	    } else if (!errno) {
		continue;
	    }
	}
	/* If an unbuffered source has no data, it really has no data, and we
	 * can timeout if realtime passes the end of the interval.  But a
	 * buffered source may just be buffering its data, so we must wait for
	 * the buffer to be sure we're not missing an earlier packet. */
	if (cinst[i]->src->type.is_live && !cinst[i]->src->type.is_buffered &&
	    !cinst[i]->synced)
	{
	    if (passed_interval_in_realtime < 0) {
		const int fudge = 1; /* in case src & cpu clocks are unsynced */
		struct timeval tvnow;
		struct timespec tsnow;
		gettimeofday(&tvnow, NULL);
		tsnow.tv_sec = tvnow.tv_sec - fudge;
		tsnow.tv_nsec = tvnow.tv_usec * 1000;
		passed_interval_in_realtime = timespeccmp(&tsnow, &pi->end, >);
		if (passed_interval_in_realtime) {
		    coral_diag(8, ("passed interval end %ld.%09ld "
			"in realtime (%ld.%09ld + %d)\n",
			pi->end.tv_sec, pi->end.tv_nsec,
			tsnow.tv_sec, tsnow.tv_nsec, fudge));
		}
	    }
	    if (passed_interval_in_realtime) {
		coral_diag(8, ("iface %d passed interval end %ld.%09ld "
		    "in realtime\n",
		    cinst[i]->id, pi->end.tv_sec, pi->end.tv_nsec));
		cinst[i]->synced = 1;
		pi->synced++;
	    }
	}
    }

    /* coral_total_ifaces has changed if a source
     * hit eof in the freshen loop above.  pi->synced has changed if there
     * are live unbuffered iface and the interval expired in realtime. */
    if (!coral_total_ifaces)
	return coral_pkt_read_done(pkt_result, int_result);
    if (pi->synced == coral_total_ifaces) {
	coral_diag(8, ("all %d ifaces synced\n", pi->synced));
	return end_intermediate_interval(iface, pi, pkt_result, int_result);
    }
    /* must have unsynced live ifaces */
    polltime.tv_usec = coral_config.polltime;
    goto reload;

have_data:
    /* next packet may follow this one immediately, so zero poll timer */
    polltime.tv_usec = 0;

    if (iface->pkt_result.packet)
	goto have_pkt;
    while (1) {
	if (iface->iface_type->prep_pkt(iface) < 0) {
	    coral_mark_eof(iface);
	    if (!errno) errno = -1;
	    return NULL;
	}

	if (!iface->src->is_interleaved) {
	    if (iface->pkt_result.packet)
		goto have_pkt;
	} else {
	    if (iface->src->current_iface->pkt_result.packet) {
		iface = iface->src->current_iface;
		goto have_pkt;
	    }
	}

	if (iface->eof)
	    goto reload;
	if (!coral_consume(iface, CORAL_WANT_PKT)) {
	    /* Ran out of data while consuming:  we must reload, even for
	     * live unbuffered interfaces. */
	    goto reload;
	}
    }

have_pkt:
    pi->last_iface = iface;
    pi->pkts_since_read++;

    /* PKTST_NEW was handled by coral_read_pkt_sort() */
    if (iface->synced) {
	coral_source_t *src = iface->src;
	coral_update_latest_ts(iface);
	pi->itime = iface->latest_ts;
	coral_diag(8, ("iface->ts %ld.%06ld >= pi->end %ld.%06ld\n",
	    iface->latest_ts.tv_sec, iface->latest_ts.tv_nsec,
	    pi->end.tv_sec, pi->end.tv_nsec));
	pi->synced += src->is_interleaved ||
	    (src->pktq_max && src->pktq_size >= src->pktq_max) ?
	    src->iface_count : 1;
	if (pi->synced >= coral_total_ifaces) {
	    coral_diag(8, ("iface %d is synced, and all %d ifaces synced\n",
		iface->id, pi->synced));
	    assert (pi->synced == coral_total_ifaces);
	    return end_intermediate_interval(iface, pi, pkt_result, int_result);
	} else {
	    iface = NULL;
	    goto reload;
	}
    }

    assert(iface->pkt_result.packet);
    coral_config.pkts++;

    pi->state = PKTST_CONSUME;

    if (!current_pkt_should_be_kept(iface))
	goto start; /* restart as if we'd returned and been called again. */
    *pkt_result = iface->pkt_result;
    set_subif(iface, pkt_result);
    set_ip_version(pkt_result);
    if (coral_config.anon.alg != CORAL_ANON_ALG_NONE)
	if (!coral_pkt_anonymize(pkt_result->packet))
	    goto start; /* discard un-anonymizable packet */
    return iface;
}

int coral_read_pkt_init(coral_source_t *src, coral_iface_t *iface,
    struct timeval *interval)
{
    int sd, i;

    coral_config.pkts = 0;
    pi->synced = 0;
    pi->pkts_since_read = 0;

    coral_read_pkt = (coral_config.flags & CORAL_OPT_SORT_TIME) ?
	coral_read_pkt_sort : coral_read_pkt_nosort;

    if (iface) {
	validate_iface(iface, "coral_read_pkt_init", -1);
	check_iomode_USERALL(iface);
	pi->src = iface->src;
	pi->iface = iface;
	/* close all other ifaces on this source */
	for (i = 0; i < iface->src->iface_count; i++) {
	    if (iface->src->id[i] == iface->id) continue;
	    coral_mark_eof(cinst[iface->src->id[i]]);
	}
	coral_read_pkt = coral_read_pkt_nosort; /* optimize */

    } else if (src) {
	validate_src(src, "coral_read_pkt_init", -1);
	check_src_iomode_USERALL(src);
	pi->src = src;
	pi->iface = NULL;
	if (src->iface_count <= 1 || src->is_interleaved)
	    coral_read_pkt = coral_read_pkt_nosort; /* optimize */

    } else {
	pi->src = NULL;
	pi->iface = NULL;
	for (sd = 0; sd < coral_max_src; sd++) {
	    if ((src = csource[sd])) {
		validate_src(src, "coral_read_pkt_init", -1);
		check_src_iomode_USERALL(src);
	    }
	}
	/* If there's only one interface, or only one sorted source,
	 * use the optimized coral_read_pkt_nosort(). */
	if (coral_total_ifaces <= 1) {
	    coral_read_pkt = coral_read_pkt_nosort;
	} else if (coral_config.source_count == 1) {
	    src = coral_next_source(NULL);
	    if (src->iface_count <= 1 || src->is_interleaved)
		coral_read_pkt = coral_read_pkt_nosort;
	}
    }

    pi->last_iface = NULL;

    pi->pkthandler = NULL;
    pi->preinthandler = NULL;
    pi->postinthandler = NULL;

    normalize_if_needed(pi->src, pi->iface);

    if (interval) {
	pi->interval.tv_sec = interval->tv_sec;
	pi->interval.tv_nsec = interval->tv_usec * 1000;
    } else {
	pi->interval = tszero;
    }
    pi->parameter = NULL;

    reset_stats(&pi->stats);
    pi->begin.tv_sec = 0;
    pi->begin.tv_nsec = 0;
    pi->end.tv_sec = 0;
    pi->end.tv_nsec = 0;
    pi->state = PKTST_NEW;
    coral_pkt_done = 0;

    coral_diag(6, ("coral_pkt_init: polltime = %d\n", coral_config.polltime));
    return 0;
}

int coral_read_pkts(coral_source_t *src, coral_iface_t *iface,
			  coral_pkt_handler pkthandler, 
			  coral_pre_interval_handler preinthandler,
			  coral_post_interval_handler postinthandler,
			  struct timeval *interval,
			  void *param)
{
    coral_pkt_result_t pkt_result;
    coral_interval_result_t int_result;
    int result = 0;
    struct timeval start_time, end_time;

    coral_read_pkt_init(src, iface, interval);
    pi->pkthandler = pkthandler;
    if (interval && timercmp(interval, &tvzero, >)) {
	pi->preinthandler = preinthandler;
	pi->postinthandler = postinthandler;
	pi->parameter = param;
    }

    gettimeofday(&start_time, NULL);

    while (!coral_pkt_done) {
	iface = coral_read_pkt(&pkt_result, &int_result);
	if (!iface) {
	    if (errno) result = -1;
	    break;
	} else if (pkt_result.packet) {
	    pkthandler(iface, pkt_result.timestamp, param,
		pkt_result.packet, pkt_result.header, pkt_result.trailer);
	} else if (!int_result.stats) {
	    if (preinthandler)
		preinthandler(iface, &int_result.begin, param);
	} else {
	    if (postinthandler)
		postinthandler(iface, &int_result.begin, &int_result.end,
		    param, int_result.stats);
	}
    }

    gettimeofday(&end_time, NULL);
#if 0 /* XXX */
    coral_diag(20, ("ATM reassembly time: %f\n",
	(end_time.tv_sec + end_time.tv_usec / 1000000.0) -
	(start_time.tv_sec + start_time.tv_usec / 1000000.0)));
#endif

    return result;
}

#if 0
int coral_pkt_select(int nfds, fd_set *rfds, fd_set *wfds, fd_set *efds,
    struct timeval *timeout)
{
    int i, count, total = 0, have_pkt = 0;
    coral_source_t *src;
    fd_set rwant, wwant, ewant;
    fd_set rsel, wsel, esel;
    fd_set mfds;

    coral_copy_fd_set(nfds, &rwant, rfds);
    coral_copy_fd_set(nfds, &wwant, wfds);
    coral_copy_fd_set(nfds, &ewant, efds);

    coral_copy_fd_set(coral_select_fd_max+1, &mfds, &coral_select_fds);
    coral_or_fd_set(coral_select_fd_max+1, &rwant, &mfds);

    FD_ZERO(rfds);
    FD_ZERO(wfds);
    FD_ZERO(efds);

    if (coral_pkt_poll()) {
	FD_CLR(coral_pkt_fd, &rwant);
	FD_SET(coral_pkt_fd, rfds);
	have_pkt = 1;
    }

    if (total > 0)
	timeout = &tvzero;

    do {
	coral_copy_fd_set(nfds, &rsel, &rwant);
	coral_copy_fd_set(nfds, &wsel, &wwant);
	coral_copy_fd_set(nfds, &esel, &ewant);

	if (!have_pkt) {
	    for (i = 0; i < coral_max_src; i++) {
		if (!csource[i]) continue;
		if (/* XXX csource[i] does not have a pkt */) {
		    FD_SET(&rsel, csource[i]->fd);
		    if (csource[i]->fd >= nfds)
			nfds = csource[i]->fd + 1;
		}
	    }
	}

	count = select(&rsel, &wsel, &esel, timeout);
	if (count < 0) /* error */
	    return count;

	if (count > 0) {
	    for (i = 0; i < nfds; i++) {
		if (FD_ISSET(i, &rsel)) {
		    src = coral_fd_table[i];
		    if (!src || coral_pkt_poll(src)) {
			total++;
			FD_CLR(i, &rwant);
			FD_SET(i, rfds);
		    }
		}
		if (FD_ISSET(i, &wsel)) {
		    total++;
		    FD_CLR(i, &wwant);
		    FD_SET(i, wfds);
		}
		if (FD_ISSET(i, &esel)) {
		    total++;
		    FD_CLR(i, &ewant);
		    FD_SET(i, efds);
		}
	    }
	}
    } while (!have_pkt && !total)

    return total + have_pkt;
}
#endif

#ifdef HAVE_BPF_FILTER
int coral_pcap_compile_verbose(coral_iface_t *iface, pcap_t *pcap,
    struct bpf_program *fp, char *str, int optimize, uint32_t netmask)
{
    int result;

    result = pcap_compile(pcap, fp, str, optimize, netmask);
    if (result < 0) {
        coral_diag(0, ("pcap expression on interface %d: %s\n",
	    iface->id, pcap_geterr(pcap)));
    }
    return result;
}

int coral_pcap_compile(coral_iface_t *iface, struct bpf_program *fp,
    char *str, int optimize, uint32_t netmask)
{
    char *buf = NULL;
    int result;

    if (!iface->internal_pcap)
	iface->internal_pcap = coral_iface_to_alloced_pcapp(iface, 0);
    if (!iface->internal_pcap) {
        coral_diag(0, ("%s\n", strerror(errno)));
        return -1;
    }

    if (iface->src->dev_config.vlan_hack) {
	buf = malloc(strlen(str) + strlen("vlan and ()") + 1);
	if (!buf) return -1;
	sprintf(buf, "vlan and (%s)", str);
	str = buf;
    }

    result = coral_pcap_compile_verbose(iface, iface->internal_pcap, fp, str,
	optimize, netmask);
    if (buf) free(buf);
    return result;
}

/* compile for a DLT_RAW pcap */
int coral_pcap_compile_raw(coral_iface_t *iface, struct bpf_program *fp,
    char *str, int optimize, uint32_t netmask)
{
    if (!iface->ip_pcap)
	iface->ip_pcap = coral_iface_to_alloced_pcapp(iface, 1);
    if (!iface->ip_pcap) {
        coral_diag(0, ("%s\n", strerror(errno)));
        return -1;
    }
    return coral_pcap_compile_verbose(iface, iface->ip_pcap, fp, str,
	optimize, netmask);
}

int coral_pcap_setprefilter(coral_iface_t *iface, struct bpf_program *fp)
{
    if (iface->iface_info.physical != CORAL_PHY_ATM) {
	coral_diag(1, ("interface %d: prefilter is ignored on non-ATM "
	    "interfaces\n", iface->id));
	return 0;
    }
    if (!iface->internal_pcap)
	iface->internal_pcap = coral_iface_to_alloced_pcapp(iface, 0);
    if (!iface->internal_pcap) {
        coral_diag(0, ("%s\n", strerror(errno)));
        return -1;
    }

    if (iface->prebpfprog) /* prebpfprog is always private */
	free(iface->prebpfprog);
    iface->prebpfprog = fp;
    return 0;
}

int coral_pcap_setfilter(coral_iface_t *iface, struct bpf_program *fp)
{
    if (!iface->internal_pcap)
	iface->internal_pcap = coral_iface_to_alloced_pcapp(iface, 0);
    if (!iface->internal_pcap) {
        coral_diag(0, ("%s\n", strerror(errno)));
        return -1;
    }

    if (iface->bpfprog && iface->bpfprog_is_private)
	free(iface->bpfprog);
    iface->bpfprog = fp;
    if (iface->src->type.coral_type == CORAL_TYPE_PCAP ||
        iface->src->type.coral_type == CORAL_TYPE_PCAPLIVE)
    {
	if (pcap_setfilter(iface->internal_pcap, fp) < 0) {
	    coral_diag(0, ("pcap_setfilter on interface %d: %s\n",
		iface->id, pcap_geterr(iface->internal_pcap)));
	    return -1;
	}
#if defined(linux) && defined(HAVE_PCAP_INT_H)
	{
	    static int warned = 0;
	    if (!warned && !iface->internal_pcap->md.use_bpf) {
		coral_diag(0, ("warning: BPF filters will run in user space.  "
		    "For greater efficiency, enable the CONFIG_FILTER kernel "
		    "option.\n", iface->id));
		warned = 1;
	    }
	}
#endif
    }
    return 0;
}

int coral_pcap_setipfilter(coral_iface_t *iface, struct bpf_program *fp)
{
    if (!iface->ip_pcap)
	iface->ip_pcap = coral_iface_to_alloced_pcapp(iface, 1);
    if (!iface->ip_pcap) {
        coral_diag(0, ("%s\n", strerror(errno)));
        return -1;
    }

    if (iface->ip_bpfprog) /* ip_bpfprog is always private */
	free(iface->ip_bpfprog);
    iface->ip_bpfprog = fp;
    return 0;
}
#endif

