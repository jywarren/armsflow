// The expression alignmentof(TYPE) returns the minimum alignment required for
// an object of type TYPE.  The maximum alignment it can detect is 16 bytes.

#ifndef ALIGNMENTOF_H
#define ALIGNMENTOF_H

template<class C, int N> class aligntest { C data; char pad[N]; };

#define alignmentof(type) ( \
    (sizeof(aligntest<type,1>) > sizeof(type)) ? (sizeof(aligntest<type,1>) - sizeof(type)) : \
    (sizeof(aligntest<type,2>) > sizeof(type)) ? (sizeof(aligntest<type,2>) - sizeof(type)) : \
    (sizeof(aligntest<type,4>) > sizeof(type)) ? (sizeof(aligntest<type,4>) - sizeof(type)) : \
    (sizeof(aligntest<type,8>) > sizeof(type)) ? (sizeof(aligntest<type,8>) - sizeof(type)) : \
    16)

#endif // ALIGNMENTOF_H
