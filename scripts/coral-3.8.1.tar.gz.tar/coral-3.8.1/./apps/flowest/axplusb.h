// based on code by cestan@cs.ucsd.edu 09/10/2002

/* An AXplusB implements a hash function based on the formula
   (a*X+b)mod p. The data X this is computed on is opaque to us here:
   we see it as a chunk of memory of a certain size pointed to by a
   void*. To obtain a 32 bit hash key, we actually use two different
   functions for the lower and upper 2 bytes, with random primes p
   between 2^24 and 2^32 and random a's and b's (a's non-zero).*/

// WARNING: Make sure there are no uninitialized holes in the first length
// bytes of data, for example if data points to a structure that contains
// padding needed to align the fields.

#ifndef AXPLUSB_H
#define AXPLUSB_H

class AXplusB {
    uint32_t a,b,p;
public:
    AXplusB();
    inline uint32_t operator() (const void* data, int length) const; // Computes hash on data
};

inline uint32_t AXplusB::operator() (const void* data, int length) const
{
    const unsigned char *cdata = (const unsigned char *)data;
    uint64_t r;
    for (r = 0; length > 0; length--) {
        r = (r * 256 + *cdata * (uint64_t)a) % p;
        cdata++;
    }
    r = (r+b) % p;
    return r;
}

#endif /* AXPLUSB_H */
