/* 
 * Copyright 2003, 2004, 2005, 2007
 * The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program.  Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

#ifndef TRBMP_H
#define TRBMP_H

#include <cmath>
#include <math.h>
#include <memory>
#include "poolallocator.h"
#include "alignmentof.h"
#include "intmath.h"

// d is # of bits in direct bitmap
// g is # of bits that must be set in direct bitmap to trigger MultiResBmp
// c, b, k are as in MultiResBmpParam

template<class tag, class Key> class TriggeredBmp {
    typedef TriggeredBmp<tag, Key> Self_t;
    class subtag {};
    typedef MultiResBmp<subtag, Key> MRB_t;
    typedef DirectBmp<subtag, Key> DRB_t;

    MRB_t *mrbmp;
    DRB_t drbmp; // variable size - must be last member

public:
    friend class Param;
    class Param {
	friend class TriggeredBmp;
	unsigned d;
	unsigned g;
	mutable PoolAllocator alloc;
	static double drbmp_err(unsigned d, unsigned g)
	    { return DRB_t::p->err(DRB_t::estimate(d,d-g)/d, d); }
	void init() {
	    DRB_t::p = new typename DRB_t::Param(d);
	    alloc = PoolAllocator(bytes(), alignmentof(TriggeredBmp));
	}

    public:
	Param(unsigned pd, unsigned pg, unsigned pc, unsigned pb) :
	    d(pd), g(pg)
	{
	    if (g > 0 && g > d)
		throw std::domain_error("TriggeredBmp: g must be less than d");
	    MRB_t::p = new typename MRB_t::Param(0, 0, pc, pb);
	    init();
	}

	Param(uint64_t N, double E)
	{
	    for (d = 32; d <= 64; d += 32) {
		for (g = (d+3)/4; g >= (d+7)/8; g--) {
		    if (drbmp_err(d,g) <= E * (d - 0.9*(d-g)) / g)
			goto done_bmp;
		}
	    }
	    d -= 32; g++;
	    done_bmp:
	    // error allowed by mrb is whatever is leftover from drbmp
	    double mrbE = (d * E - g * drbmp_err(d,g)) / (d - g);
	    if (mrbE < 0) {
		throw std::domain_error("that accuracy is impractical/impossible");
	    }
	    MRB_t::p = new typename MRB_t::Param(N, mrbE);
	    init();
	}

	std::string namestr() const { return "TriggeredBmp::Param"; }
	std::string paramstr() const
	{
	    char buf[64]; // XXX Someday, stringstream is the way to go here
	    std::string ret_val;
	    sprintf(buf, "d=%u, g=%u, ", d, g);
	    ret_val += buf;
	    ret_val += MRB_t::p->paramstr();
	    return ret_val;
	}

	size_t varbytes() const
	    { return DRB_t::p->varbytes(); } /* size of variable part */
	size_t bytes() const
	    { return sizeof(Self_t) + varbytes(); } /* total size */
	void stats() const { alloc.stats(); MRB_t::p->stats(); }
    };

    static const Param *p;

    void setmagic() { drbmp.setmagic(); }

    void *operator new(size_t size)
    {
	void *ptr = p->alloc();
	(static_cast<TriggeredBmp*>(ptr))->setmagic();
	return ptr;
    }

    TriggeredBmp() : mrbmp(), drbmp() {}
    ~TriggeredBmp() { if (mrbmp) delete mrbmp; }
    void operator delete(void *ptr, size_t size) { p->alloc.free(ptr); }
    inline void set(Key key);
    inline double estimate() const;
    void reset() { if (mrbmp) delete mrbmp; mrbmp = 0; drbmp.reset(p->d); }
    bool have_mrbmp() const { return mrbmp != 0; }
};

template<class tag, class Key> const typename TriggeredBmp<tag, Key>::Param *TriggeredBmp<tag, Key>::p = 0;

template<class tag, class Key> inline void TriggeredBmp<tag, Key>::set(Key key)
{
    // incorrect??
    if (drbmp.test(key)) {
	/* do nothing */
    } else if (mrbmp) {
	mrbmp->set(key);
    } else if (drbmp.count() >= p->g) {
	mrbmp = new typename Self_t::MRB_t(); // create and initialize
	mrbmp->set(key);
    } else {
	drbmp.set(key);
    }
}

template<class tag, class Key> inline double TriggeredBmp<tag, Key>::estimate() const
{
    // incorrect??
    double est = drbmp.estimate();
    if (mrbmp)
	est += mrbmp->estimate() * p->d / (p->d - p->g);
    return est;
}

#endif // TRBMP_H
