/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 * Note:  This program in for use by crl_hist, and subject to arbitrary
 *	changes without notice.  Use by programs other than crl_hist
 *	is not supported.
 */

/*
 * $Id: crl_hist_helper.c,v 2.19 2007/06/06 18:17:32 kkeys Exp $
 */


static const char RCSid[]="$Id: crl_hist_helper.c,v 2.19 2007/06/06 18:17:32 kkeys Exp $";

#include "config.h"
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <sys/time.h>
#include <sys/errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <signal.h>
#include <errno.h>
#include <math.h>   /* modf() */

#include <netinet/in.h>
#include <netinet/in_systm.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <netinet/ip_icmp.h>
#include <netinet/igmp.h>
#include <arpa/inet.h>
#include <netdb.h>

#include <assert.h>

#include "libcoral.h"
#include "crl_byteorder.h"
#include "hashtab.h"

#define OUTPUT_VERSION "1.0"

#if !PATH_MAX
# define PATH_MAX 1024
#endif

#define ALG_NONE	'\0'	/* default */
#define ALG_FIXED	'f'
#define ALG_MULT	'm'
/* TODO: NetFlow-like expiry on TCP FIN */

struct {
    double start_time;
    double end_time;
    uint64_t notIP;
    uint64_t opcount;
    uint64_t nofragcount;
} totals;

struct {
    u_char stats;
    u_char expire_on_interval;
    const char * outfilename;
    FILE * outfile;
    char algorithm; /* timeout algorithm */
    int p1;	    /* timeout algorithm parameter 1 */
    int p2;	    /* timeout algorithm parameter 2 */
} config;

const char *fmt_rheader, *fmt_right;

struct {
    uint64_t ipbytes;
    uint64_t notIP;
    coral_pkt_stats_t *pkt_stats;
    double begin;
    double end;
} interval_data;

#define VPVC_HASH_TABLE_SIZE	229
#define FLOW_HASH_TABLE_SIZE	97843

struct subif_stats;

typedef struct flow {
/* flow key data */
    struct subif_stats *parent;
    //struct in_addr src;
    //struct in_addr dst;
    u_char	ip_proto;
    u_char	ports_ok;
    u_short	sport;
    u_short	dport;
    u_short     plen;

/* flow data */
    uint64_t	pkts;
    uint64_t	bytes;
    struct timespec first;
    struct timespec latest;
    struct timespec gap;

/* operational data */
    struct flow	*next, *prev;
} flow;

typedef struct subif_stats {
    coral_iface_t *iface;
    u_int iface_id;
    u_int subif_id;
    uint64_t pkts;
    uint64_t bytes;
    uint64_t flows;
    uint64_t unknown_encaps;
    uint64_t ip_not_v4;
    struct timespec first;
    struct timespec latest;
    flow *active_flows;		/* linked list of active flows for this subif */
    flow *expired_flows;	/* linked list of expired flows for this subif */
} subif_stats;

hash_tab *subif_hash;
hash_tab *flow_hash;

int interrupted = 0;
int delete_flow_flag = 1;
const char rotating_filename[] = "%010s.%f.t2";

/* ---- hash table per subif fxns begin ---- */
/* -- per subif hash table fxns -- */

/* return 0 if the same - for use by the hashtable */
static int compare_subif_stats(const void *entry1, const void *entry2)
{
    const subif_stats *foo1 = entry1;
    const subif_stats *foo2 = entry2;

    return (foo1->subif_id != foo2->subif_id ||
	    foo1->iface_id != foo2->iface_id);
}

/* make a hash of an entry - for use by the hashtable */
static unsigned long make_key_subif_stats(const void *entry)
{
    const subif_stats *what = entry;

    return (unsigned) what->subif_id * 425879 + what->iface_id;
}

/* free mem of an entry - for use by the hashtable */
static void delete_subif_stats(void *entry)
{
    subif_stats *what = entry;
    if (!what) return;
    free(what);
}
/* -- end of subif type hash table fxns -- */


/* ---- stuff that is per (flow)hash table ---- */

/* return 0 if the same - for use by the hashtable */
static int compare_flow(const void *entry1, const void *entry2)
{
    const flow *foo1 = entry1;
    const flow *foo2 = entry2;

    return (foo1->parent != foo2->parent ||
            foo1->plen != foo2->plen ||
	    foo1->ip_proto != foo2->ip_proto ||
	    foo1->sport != foo2->sport ||
	    foo1->dport != foo2->dport ||
	    foo1->ports_ok != foo2->ports_ok);
}

/* make a hash of an entry - for use by the hashtable */
static unsigned long make_key_flow(const void *entry)
{
    const flow *what = entry;
    
    return ((unsigned)what->parent)+
        ((unsigned) what->plen << 16) +
	what->ip_proto + ((unsigned)what->dport<<16) + what->sport;
}

/* free mem of an entry - for use by the hashtable */
static void delete_flow(void *entry)
{
    flow *what = entry;
    if (!what || !delete_flow_flag) return;
    free(what);
}
/* ---- hash table fxns end ---- */

static int is_expired(flow *flowrec, const struct timespec *ts, int is_pkt)
{
    struct timespec gap;
    struct timespec thresh;
    int result;
    double intpart, fracpart;

    gap = *ts;
    timespecsub(&gap, &flowrec->latest);

    switch(config.algorithm) {
    case ALG_NONE:
	return 0;
    case ALG_FIXED:
	return (gap.tv_sec >= config.p1);
    case ALG_MULT:
	fracpart = modf(timespectodouble(&flowrec->gap) * config.p1, &intpart);
	thresh.tv_nsec = 1000000000.0 * fracpart;
	thresh.tv_sec = intpart;
	result = timespeccmp(&gap, &thresh, >= );
	if (is_pkt) {
	    /* only adjust the gap if the timestamp was from a new
	       packet in this same flow, not if it was a time tick
	       from seeing an interval edge */
	    flowrec->gap = gap;
	}
	return result;
    }
    return 0;
}

static void expire_flow(flow *flowrec)
{
    /* remove from hash table */
    delete_flow_flag = 0; /* don't let the hash table free our flow */
    clear_hash_entry(flow_hash, flowrec);
    delete_flow_flag = 1;

    /* remove from subif's active flow list */
    assert(!flowrec->next || flowrec->next->prev == flowrec);
    if (flowrec->next)
	flowrec->next->prev = flowrec->prev;
    assert(flowrec->prev ? flowrec->prev->next == flowrec : flowrec->parent->active_flows == flowrec);
    *(flowrec->prev ? &flowrec->prev->next : &flowrec->parent->active_flows) =
	flowrec->next;

    /* add to expired flow list */
    flowrec->prev = NULL;
    flowrec->next = flowrec->parent->expired_flows;
    if (flowrec->parent->expired_flows)
	flowrec->parent->expired_flows->prev = flowrec;
    flowrec->parent->expired_flows = flowrec;

    assert(!flowrec->next || flowrec->next->prev == flowrec);
    assert(flowrec->prev ? flowrec->prev->next == flowrec : flowrec->parent->expired_flows == flowrec);
}

static void count_flow(subif_stats *subif, coral_iface_t *iface,
    const struct timespec *ts, const coral_pkt_buffer_t * netpkt)
{
    flow tmp;
    flow *flowrec;
    short offset;
    struct ip * ip;
    coral_pkt_buffer_t payload;

    ip = (struct ip*)netpkt->buf;
    offset = ntohs(ip->ip_off) & IP_OFFMASK;

    if (ip->ip_hl > 5) {
	totals.opcount++;
    }
    if (ntohs(ip->ip_off) & IP_DF) {
	totals.nofragcount++;
    }

    /* Set the key to the source/destination address pair. */
    tmp.parent = subif;
    tmp.ip_proto = ip->ip_p;
    tmp.ports_ok = 0;
    tmp.sport = 0;
    tmp.dport = 0;
    tmp.plen = ntohs(ip->ip_len);

    coral_get_payload(netpkt, &payload);
    /* NOT get_payload_by_layer(..., 4); we want the payload, no matter what
     * layer it claims to be.  (Specifically, we don't want to go through
     * IPIP encapsulations.)
     */

    /* extract port info - make sure we aren't non-first fragments */
    if (offset == 0) {
        if (ip->ip_p == IPPROTO_TCP) {
	    if (payload.caplen >= 4) {
	        struct tcphdr *t = (struct tcphdr*)payload.buf;
		tmp.sport = ntohs(t->th_sport);
		tmp.dport = ntohs(t->th_dport);
		tmp.ports_ok = 1;
	    }
	} else if (ip->ip_p == IPPROTO_UDP) {
	    if (payload.caplen >= 4) {
	        struct udphdr *u = (struct udphdr*)payload.buf;
		tmp.sport = ntohs(u->uh_sport);
		tmp.dport = ntohs(u->uh_dport);
		tmp.ports_ok = 1;
	    }
	} else if (ip->ip_p == IPPROTO_ICMP) {
	    if (payload.caplen >= 2) {
	        struct icmp *icmp = (struct icmp*)payload.buf;
		tmp.sport = icmp->icmp_type;
		tmp.dport = icmp->icmp_code;
		tmp.ports_ok = 1;
	    }
	} else if  (ip->ip_p == IPPROTO_IGMP) {
	    if (payload.caplen >= 2) {
		struct igmp *u = (struct igmp*)payload.buf;
		tmp.sport = (u_short) u->igmp_type;
		tmp.dport = (u_short) u->igmp_code;
		tmp.ports_ok = 1;
	    }
	}
    }

    /* bit 1 of ports_ok means ports are ok. */
    /* bit 2 of ports_ok means frag */
    if ((ntohs(ip->ip_off) & IP_MF) || offset != 0) {
	tmp.ports_ok |= 0x2;
    }


    /* Read the current value out of the database. */
    if ((flowrec = (flow*)find_hash_entry(flow_hash, &tmp))) {
	if (is_expired(flowrec, ts, 1)) {
	    expire_flow(flowrec);
	    flowrec = NULL;
	} else {
	    flowrec->pkts++;
	    flowrec->bytes += ntohs(ip->ip_len);
	}
    }

    if (!flowrec) {
	flowrec = (flow*)malloc(sizeof(flow));
	if (flowrec == NULL) {
	    fprintf(stderr, "can't malloc port_stats.\n");
	    abort();
	}

	*flowrec = tmp;
	flowrec->pkts = 1;
	flowrec->bytes = ntohs(ip->ip_len);
	flowrec->first = *ts;
	flowrec->gap.tv_sec = config.p2;
	flowrec->gap.tv_nsec = 0;
	flowrec->prev = NULL;
	flowrec->next = subif->active_flows;
	if (flowrec->next)
	    flowrec->next->prev = flowrec;
	subif->active_flows = flowrec;
	subif->flows++;

	assert(!flowrec->next || flowrec->next->prev == flowrec);
	assert(flowrec->prev ? flowrec->prev->next == flowrec : flowrec->parent->active_flows == flowrec);

	add_hash_entry(flow_hash, flowrec);
    }

    flowrec->latest = *ts;
}


static void dump_text_flow_table(const char *iface_str, flow *flowlist)
{
    flow *flowrec;

    for (flowrec = flowlist; flowrec; flowrec = flowrec->next) {
	if (flowrec->pkts) {
	    fprintf(config.outfile, 
		    "%s\t%u\t%u\t%u\t%u\t%u\t%" PRIu64 "\n",
		    iface_str,
		    flowrec->ip_proto, flowrec->ports_ok, 
		    flowrec->sport, flowrec->dport, 
		    flowrec->plen,
		    flowrec->pkts);
	}
    }

    fflush(config.outfile);
}


/* 
 * keep track of some subif related stats, and count_flow().
 */
static void count_subif_stats(coral_iface_t *iface,
    coral_pkt_result_t *pkt_result)
{
    subif_stats *subifrec;
    subif_stats tmp;
    coral_pkt_buffer_t netpkt;
    struct ip *ip;
    double timestamp;

    tmp.iface = iface;
    tmp.iface_id = coral_interface_get_number(iface);
    tmp.subif_id = pkt_result->subiface;

    if (!(subifrec = (subif_stats*)find_hash_entry(subif_hash, &tmp))) {
	subifrec = (subif_stats*)malloc(sizeof(subif_stats));
	if (subifrec == NULL) {
	    fprintf(stderr, "can't malloc subif_stats.\n");
	    abort();
	}
	subifrec->subif_id = tmp.subif_id;
	subifrec->iface = tmp.iface;
	subifrec->iface_id = tmp.iface_id;
	subifrec->pkts = 0;
	subifrec->bytes = 0;
	subifrec->flows = 0;
	subifrec->unknown_encaps = 0;
	subifrec->ip_not_v4 = 0;
	subifrec->active_flows = NULL;
	subifrec->expired_flows = NULL;
	CORAL_TIMESTAMP_TO_TIMESPEC(iface, pkt_result->timestamp,
	    &subifrec->latest);
	subifrec->first = subifrec->latest;
        add_hash_entry(subif_hash, subifrec);
    } else {
	/* Every new interval needs a new first */
	if (!subifrec->first.tv_sec && !subifrec->first.tv_nsec) {
	    subifrec->first = subifrec->latest;
	}
	CORAL_TIMESTAMP_TO_TIMESPEC(iface, pkt_result->timestamp,
	    &subifrec->latest);
    }

    if (coral_get_payload_by_layer(pkt_result->packet, &netpkt, 3) < 0) {
	subifrec->unknown_encaps++;
	return;
    }

    if (netpkt.protocol != CORAL_NETPROTO_IP) {
	interval_data.notIP++;
	totals.notIP++;
	return;
    }

    ip = (struct ip*)netpkt.buf;
    if (ip->ip_v != 4) {
	subifrec->ip_not_v4++;
	fprintf(stderr, "unexpected ip version: %d\n", (int)ip->ip_v);
	return;
    }

    timestamp = coral_read_clock_double(iface, pkt_result->timestamp);
    if ( ( totals.start_time == -1 ) || ( timestamp < totals.start_time ) )
	totals.start_time = timestamp;
    if ( ( totals.end_time == -1 ) || ( timestamp > totals.end_time ) )
	totals.end_time = timestamp;


    /* do stats --- */
    subifrec->pkts++;
    subifrec->bytes += ntohs(ip->ip_len);
    interval_data.ipbytes += ntohs(ip->ip_len);

    count_flow(subifrec, iface, &subifrec->latest, &netpkt);
}

static void init_hashes(void)
{
    subif_hash = init_hash_table("# hashes entries for each subif",
			       compare_subif_stats, make_key_subif_stats,
			       delete_subif_stats, VPVC_HASH_TABLE_SIZE);
    flow_hash = init_hash_table("# hashes entries for each flow",
			       compare_flow, make_key_flow,
			       delete_flow, FLOW_HASH_TABLE_SIZE);
}
/* ---- per subif stuff ends ---- */


static void dump_hash_stats(void)
{
    dump_hashtab_stats(subif_hash);
    dump_hashtab_stats(flow_hash);
}

static void dump_data(int dump_active)
{
    const subif_stats *subifrec;
    /*flow *flowrec;*/
    double begin;
    double end;

    begin = interval_data.begin;
    end = interval_data.end;

#define needs_tuple_table(subifrec) \
    ((subifrec)->expired_flows || ((subifrec)->active_flows && dump_active))

    init_hash_walk(subif_hash);
    while ((subifrec = next_hash_walk(subif_hash))) {
	if (needs_tuple_table(subifrec)) {
	    char buf[32];
	    coral_fmt_if_subif(buf, subifrec->iface, subifrec->subif_id);
	    if (subifrec->expired_flows) {
		dump_text_flow_table(buf, subifrec->expired_flows);
	    }
	    if (subifrec->active_flows && dump_active) {
		dump_text_flow_table(buf, subifrec->active_flows);
	    }
	}
    }
    fflush(config.outfile);
}

static void clear_data(void)
{
    subif_stats *subifrec;
    flow *flowrec;
    interval_data.ipbytes = 0;
    interval_data.notIP = 0;

    init_hash_walk(subif_hash);
    while ((subifrec = next_hash_walk(subif_hash))) {
	/* delete expired flows */
	while (subifrec->expired_flows) {
	    flowrec = subifrec->expired_flows->next;
	    delete_flow(subifrec->expired_flows);
	    /*flowrec->prev = NULL;*/ /* not necessary */
	    subifrec->expired_flows = flowrec;
	}
	/* If subif has no active flows, delete it */
	if (!subifrec->active_flows) {
	    clear_hash_entry(subif_hash, subifrec);
	} else { /* Otherwise, reset metadata counters */
	    subifrec->pkts = 0;
	    subifrec->bytes = 0;
	    subifrec->flows = 0;
	    subifrec->unknown_encaps = 0;
	    subifrec->ip_not_v4 = 0;
	    subifrec->first.tv_sec = 0;
	    subifrec->first.tv_nsec = 0;
	    subifrec->latest.tv_sec = 0;
	    subifrec->latest.tv_nsec = 0;
	}
    }
}

static void stop(int sig)
{
    interrupted = 1;
}

int main(int argc, char *argv[])
{
    int retval = 0;
    coral_iface_t *iface;
    coral_pkt_result_t pkt_result;
    coral_interval_result_t interval_result;
    struct timeval interval = { 300, 0 };
    u_int duration;
    int opt;
    int error = 0;
    flow *flowrec;
    struct timespec ts;

    config.outfilename = "-"; /* Default to stdout */

    coral_set_api(CORAL_API_PKT);
    coral_set_duration(0);
    coral_set_interval(&interval);
    coral_set_iomode(0, CORAL_RX, 48, 0);
    coral_set_options(0, CORAL_OPT_PARTIAL_PKT | CORAL_OPT_NORMALIZE_TIME);

    while (!error && (opt = getopt(argc, argv, "C:p:aAsBbhO:o:rT:I")) != -1) {
	switch (opt) {
	case 'C':
	    if (coral_config_command(optarg) < 0)
		error++;
	    break;
	case 's':
	    config.stats = 1;
	    break;
	case 'o':
	    config.outfilename = strdup(optarg);
	    break;
	case 'I':
	    config.expire_on_interval = 1;
	    break;
	case 'T':
	    switch(optarg[0]) {
		case 'f':
		    config.algorithm = ALG_FIXED;
		    if (sscanf(optarg+1, "%u", &config.p1) != 1)
			error++;
		    break;
		case 'm':
		    config.algorithm = ALG_MULT;
		    if (sscanf(optarg+1, "%u,%u", &config.p1, &config.p2) != 2)
			error++;
		    break;
		case 'N':
		    config.algorithm = ALG_NONE;
		    break;
		default:
		    error++;
		    break;
	    }
	    if (error)
		fprintf(stderr, "invalid timeout algorithm\n");
	    break;
	default:
	    error++;
	    break;
	}
    }

    if (error) {
	coral_usage(argv[0], "[-o<file>] [-I] [-T<timeout>] <source>...\n"
	    "-A         print active flows in addition to expired flows every interval\n"
	    "           (otherwise, still-active flows will be printed at end of run)\n"
	    "-s         print hash table statistics\n"
	    "-o<file>   specify the name of the output file (default: -)\n"
	    "-I         expire all flows at end of interval\n"
	    "-T         expiry timeout algorithm\n"
	    "           f<N>       fixed <N> seconds (ala NetFlow)\n"
	    "           m<M>,<I>   <M> times the gap, with gap initially set to <I> seconds\n"
	    "           N          no expiry (default)\n"
"<file> is the name of the output file, which may contain %% specifiers\n"
"    for formatting a timestamp.  For -o, the timestamp is the beginning of\n"
"    the trace; for -O, the timestamp is the beginning of the interval.\n"
"    The %% specifiers are any of those allowed by strftime(), plus:\n"
"        %%s   number of (whole) seconds since 1970-01-01 00:00:00 UTC\n"
"        %%f   fractional part of seconds (6 decimal places)\n"
"        %%F   equivalent to %%Y-%%m-%%d\n"
"    Except for %%f, all specifiers may contain printf-style modifiers\n"
"    (e.g., \"%%010s\").\n"
"    For -o, '-' means standard output.\n",
	    rotating_filename);
	exit(-1);
    }

    while (optind < argc) {
	if (!coral_new_source(argv[optind]))
	    exit(-1);
	optind++;
    }

    if (!config.expire_on_interval && config.algorithm == ALG_NONE) {
	coral_diag(1, ("%s: warning: no expiry mechanism specified.\n",
	    argv[0]));
    }

    if (!coral_next_source(NULL)) {
	coral_diag(1, ("%s: warning: no sources specified.\n", argv[0]));
    }

    init_hashes();
    totals.start_time = -1;
    totals.end_time = 1;
    totals.notIP = 0;
    totals.opcount = 0;
    totals.nofragcount = 0;

    if (coral_open_all() <= 0)
	exit(-1);

    if (coral_start_all() < 0)
	exit(-1);

    signal(SIGINT, stop);

    coral_get_interval(&interval);
    interval_data.begin = 0;
    interval_data.end = 0;
    interval_data.pkt_stats = NULL;

    duration = coral_get_duration();
    if (duration)
	coral_diag(2, ("collection duration max set to %d second(s)\n", 
		       duration));

    coral_read_pkt_init(NULL, NULL, &interval);

    if (config.outfilename[0] == '-' && config.outfilename[1] == '\0') {
	config.outfile = stdout;
    } else {
	char new_file[PATH_MAX+1];
	coral_tfilename(config.outfilename, new_file,
		       sizeof(new_file), &interval_result.begin, 0);
	config.outfile = fopen(new_file, "w");
	if (!config.outfile) {
	    coral_diag(0, ("%s: %s\n", new_file, strerror(errno)));
	    exit(1);
	}
    }

    while (1) {
	if (interrupted) {
	    coral_stop_all();
	    interrupted = 0;
	}
	iface = coral_read_pkt(&pkt_result, &interval_result);

	if (!iface) {
	    if (errno == EINTR || errno == EAGAIN) continue;
	    retval = errno;
	    break;
	}

	if (!pkt_result.packet && !interval_result.stats) {
	    /* beginning of interval */
	    interval_data.begin = timevaltodouble(&interval_result.begin);
	} else if (pkt_result.packet) {
	    /* got packet */
	    count_subif_stats(iface, &pkt_result);

	} else if (!pkt_result.packet && interval_result.stats) {
	    struct timeval tv1, tv2;
	    /* end of interval */
	    interval_data.end = timevaltodouble(&interval_result.end);
	    interval_data.pkt_stats = interval_result.stats;

	    gettimeofday(&tv1, NULL);

	    if (config.expire_on_interval || config.algorithm != ALG_NONE) {
		ts.tv_sec = interval_result.end.tv_sec;
		ts.tv_nsec = interval_result.end.tv_usec * 1000;
		init_hash_walk(flow_hash);
		while ((flowrec = next_hash_walk(flow_hash))) {
		    if (config.expire_on_interval || is_expired(flowrec,&ts,0))
			expire_flow(flowrec);
		}
	    }

	    dump_data(0);
	    clear_data();
	    gettimeofday(&tv2, NULL);
	    timersub(&tv2, &tv1, &tv1);
	    coral_diag(2, ("crl_flow: closed %f s interval in %d.%06d s\n",
		interval_data.end - interval_data.begin,
		tv1.tv_sec, tv1.tv_usec));

	    /* reset the interval time, and other timers */
	    interval_data.begin = 0;
	    interval_data.end = 0;
	    interval_data.pkt_stats = NULL;
	}
    }

    if (!config.expire_on_interval) {
	/* There may be undumped active flows.  Dump them. */
	dump_data(1);
    }

    fprintf(stdout, "#\n");
    fprintf(stdout, "#$Id: crl_hist_helper.c,v 2.19 2007/06/06 18:17:32 kkeys Exp $\n");
    fprintf(stdout, "#$Author: kkeys $\n");
    fprintf(stdout, "#$Name: release-3-8-1 $\n");
    fprintf(stdout, "#$Revision: 2.19 $\n");
    fprintf(stdout, "#\n");
    fprintf(stdout, "%.10f\t# start_time\t= Earliest timestamp\n",
	    totals.start_time);
    fprintf(stdout, "%.10f\t# end_time\t= Latest timestamp\n",
	    totals.end_time);
    fprintf(stdout, "%" PRIu64 "\t# nonip\t= Non-IP packets\n",
	    totals.notIP);
    fprintf(stdout, "%" PRIu64 "\t# opcount\t= IP packets with options\n",
	    totals.opcount);
    fprintf(stdout, "%" PRIu64 "\t# nofragcount\t= IP packets with DF set\n",
	    totals.nofragcount);
    fprintf(stdout, "#\n");

    coral_stop_all();

    /* clean up stuff */
    if (config.stats) dump_hash_stats();
#if 0
    clear_hash_table(subif_hash);
    clear_hash_table(flow_hash);
#endif
    return retval;
}
