// interactive test tool for IpPrefixPatricia
// usage:  testpatricia {4|6}
// commands:
//    insert prefix:             p{pfx} {text}
//    lookup address:            a{addr}
//    find ALL matches of addr:  A{addr}
//    erase from pfx1 to pfx2:   e{pfx1} {pfx2}
//    erase from pfx1 to end:    E{pfx1}
//    clear all prefixes:        c
//    dump prefix table:         d
//    dump a single prefix:      d{pfx}
//    addr1 > addr2:             >{addr1} {addr2}
//    addr1 < addr2:             <{addr1} {addr2}

extern "C" {
#include <stdio.h>
#include <sys/types.h>
#include <netdb.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <syslog.h>
#include <fcntl.h>
#include <sys/param.h>
#include <sys/socket.h>
#include <errno.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <time.h>

    extern int errno;
}

#include <string>
#include <map>
#include <fstream.h>

#include "Ipv4Network.hh"
#include "Ipv6Network.hh"
#include "IpPrefixPatricia.hh"

IpPrefixPatricia<Ipv4Network, char *> pfxmap4;
IpPrefixPatricia<Ipv6Network, char *> pfxmap6;

int pton(const char *str, ipv4addr_t *addr)
{
    struct in_addr inaddr;
    int result = inet_pton(AF_INET, str, &inaddr);
    *addr = inaddr.s_addr;
    return result;
}

int pton(const char *str, struct in6_addr *addr)
{
    return inet_pton(AF_INET6, str, addr);
}

template<class IpNetwork>
void dump_prefixes(IpPrefixPatricia<IpNetwork, char *> & pfxmap)
{
    IpPrefixPatricia<IpNetwork, char *>::const_iterator it;
    cerr << "# Prefixes:" << endl;
    for (it = pfxmap.begin(); it != pfxmap.end(); it++) {
	cerr << (*it).first << '\t' << (*it).second << endl;
    }
}

#define e_pton(str, addr) \
    do { if (!pton(str, addr)) { die("address error"); } } while (0)

#define die(str) \
    do { cerr << str << ", line " << line << endl; exit(1); } while (0)

template<class IpNetwork>
void stuff(FILE *file, IpPrefixPatricia<IpNetwork, char *>pfxmap)
{
    typename IpNetwork::ipaddr_type addr, addr2;
    int line;
    char buf[80];
    char addrstr[16], addrstr2[16], str[81];
    int len, len2;
    IpPrefixPatricia<IpNetwork, char *>::const_iterator cit;
    IpPrefixPatricia<IpNetwork, char *>::iterator it, it2;
    IpPrefixPatricia<IpNetwork, char *>::const_match_iterator mit;

    line = 1;
    while (fgets(buf, sizeof(buf), file)) {
	char *p = buf+1;
	buf[strlen(buf)-1] = '\0';
	switch (buf[0]) {
	case '#':
	case '\0':
	    break;

	case 'p':
	    if (sscanf(p, "%15[a-fA-F0-9.:]/%d %80[^\n]", addrstr, &len, str) != 3) {
		cerr << "syntax error" << endl;
		continue;
	    }
	    {
		e_pton(addrstr, &addr);
		IpNetwork net(addr, len);
		cerr << "prefix: " << net << endl;
		pfxmap[net] = strdup(str);
	    }
	    break;

	case 'a':
	    e_pton(p, &addr);
	    cit = pfxmap.LongestMatch(addr);
	    cerr << addr << '\t';
	    if (cit == pfxmap.end()) {
		cerr << "NO MATCH" << endl;
	    } else {
		cerr << (*cit).first << '\t' << (*cit).second << endl;
	    }
	    break;

	case 'A':
	    e_pton(p, &addr);
	    mit = pfxmap.ShortestMatchIt(addr);
	    if (mit == pfxmap.endMatchIt()) {
		cerr << addr << '\t';
		cerr << "NO MATCH" << endl;
	    } else {
		while (mit != pfxmap.endMatchIt()) {
		    cerr << addr << '\t';
		    cerr << (*mit).first << '\t' << (*mit).second << endl;
		    ++mit;
		}
	    }
	    break;

	case 'd':
	    if (!*p) {
		dump_prefixes(pfxmap);
	    } else if (sscanf(p, "%15[a-fA-F0-9.:]/%d", addrstr, &len) == 2) {
		e_pton(addrstr, &addr);
		IpNetwork net(addr, len);
		cerr << net << " " << pfxmap[net] << endl;
	    } else {
		cerr << "syntax error" << endl;
		continue;
	    }
	    break;

	case 'e':
	    if (sscanf(p, "%15[a-fA-F0-9.:]/%d", addrstr, &len) != 2) {
		cerr << "syntax error" << endl;
		continue;
	    }
	    {
		e_pton(addrstr, &addr);
		IpNetwork net(addr, len);
		cerr << "erase " << net << ":";
		it = pfxmap.find(net);
		if (it == pfxmap.end()) {
		    cerr << "NO MATCH" << endl;
		} else {
		    pfxmap.erase(it);
		    cerr << "ok" << endl;
		}
	    }
	    break;

	case 'R':
	    if (sscanf(p, "%15[a-fA-F0-9.:]/%d %15[a-fA-F0-9.:]/%d",
		    addrstr, &len, addrstr2, &len2) != 4)
	    {
		cerr << "syntax error" << endl;
		continue;
	    }
	    {
		e_pton(addrstr, &addr);
		e_pton(addrstr2, &addr2);
		IpNetwork net(addr, len);
		IpNetwork net2(addr2, len2);
		cerr << "erase from " << net << " to " << net2 << ": ";
		it = pfxmap.find(net);
		it2 = pfxmap.find(net2);
		if (it == pfxmap.end() || it2 == pfxmap.end()) {
		    cerr << "NO MATCH" << endl;
		} else {
		    pfxmap.erase(it, it2);
		    cerr << "ok" << endl;
		}
	    }
	    break;

        case 'E':
            if (sscanf(p, "%15[a-fA-F0-9.:]/%d", addrstr, &len) != 2) {
                cerr << "syntax error" << endl;
		continue;
	    }
            {
		e_pton(addrstr, &addr);
                IpNetwork net(addr, len);
		cerr << "erase from " << net << " to end: ";
                it = pfxmap.find(net);
                if (it == pfxmap.end()) {
		    cerr << "NO MATCH" << endl;
                } else {
                    pfxmap.erase(it, pfxmap.end());
		    cerr << "ok" << endl;
                }
            }
            break;

	case 'c':
	    cerr << "clear" << endl;
	    pfxmap.clear();
	    break;

	case '>':
	    if (sscanf(p, "%15[a-fA-F0-9.:] %15[a-fA-F0-9.:]",
		    addrstr, addrstr2) != 2)
	    {
		cerr << "syntax error" << endl;
		continue;
	    }
	    e_pton(addrstr, &addr);
	    e_pton(addrstr2, &addr2);
	    cerr << addr << " > " << addr2 << "? " << (addr > addr2) << endl;
	    break;

	case '<':
	    if (sscanf(p, "%15[a-fA-F0-9.:] %15[a-fA-F0-9.:]",
		    addrstr, addrstr2) != 2)
	    {
		cerr << "syntax error" << endl;
		continue;
	    }
	    e_pton(addrstr, &addr);
	    e_pton(addrstr2, &addr2);
	    cerr << addr << " < " << addr2 << "? " << (addr < addr2) << endl;
	    break;

	default:
	    cerr << "unknown command '" << buf[0] << "'" << endl;
	    break;
	}
	line++;
    }
}

int main(int argc, char *argv[])
{
    if (argc == 2 && strcmp(argv[1], "4") == 0)
	stuff(stdin, pfxmap4);
    else if (argc == 2 && strcmp(argv[1], "6") == 0)
	stuff(stdin, pfxmap6);
    else {
	cerr << "usage: " << argv[0] << " {4|6}" << endl;
	exit(1);
    }
    return 0;
}
