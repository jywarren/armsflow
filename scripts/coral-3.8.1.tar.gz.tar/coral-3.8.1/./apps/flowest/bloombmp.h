/* 
 * Copyright 2003, 2004, 2005, 2007
 * The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program.  Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

#ifndef BLOOMBMP_H
#define BLOOMBMP_H

#include <memory>
#include <cmath>
#include <stdexcept>
#include "intmath.h"
#include "poolallocator.h"

template<class tag, class Key> class BloomBmp {
    typedef Bitmap<tag> BMP_t;
    BMP_t bmp;

public:
    friend class Param;
    class Param {
	friend class BloomBmp;
	unsigned b;
	unsigned bshift;
	mutable PoolAllocator alloc;
    public:
	Param(unsigned pb);
	//Param(uint64_t N, double E);

	std::string namestr() const { return "BloomBmp::Param"; }
	std::string paramstr() const
	{
	    char buf[64]; // XXX Someday, stringstream is the way to go here
	    std::string ret_val;
	    sprintf(buf, "b=%u", b);
	    ret_val += buf;
	    return ret_val;
	}

	void init();
	unsigned nbits() const { return b; }
	size_t bytes() const { return BMP_t::bytes(); }
	void stats() const { alloc.stats(); }
	static double err(double rho, unsigned pb)
	    { return sqrt(exp(rho) - rho - 1) / (rho * sqrt(pb)); }
    };

    static const Param *p;

    void setmagic() { bmp.setmagic(); }

    void *operator new(size_t size)
    {
	void *ptr = p->alloc();
	(static_cast<BloomBmp*>(ptr))->setmagic();
	return ptr;
    }

    void operator delete(void *ptr, size_t size) { p->alloc.free(ptr); }
    BloomBmp() : bmp() {}
    BloomBmp & clear() { bmp.reset(); return *this; }
    bool set(Key key1, Key key2) {
	Key index1 = key1 >> p->bshift;
	Key index2 = key2 >> p->bshift;
	if (bmp.test(index1) && bmp.test(index2))
	    return true;
	bmp.set(index1);
	bmp.set(index2);
	return false;
    }
    bool test(Key key) { return bmp.test(key % p->b); }
    static double estimate(unsigned b, unsigned z) { return b * log(double(b)/z) / 2; }
    double estimate() const { return estimate(p->b, bmp.nzero()); }
};

template<class tag, class Key> void BloomBmp<tag, Key>::Param::init()
{
    BMP_t::nbits = nbits();
    alloc = PoolAllocator(bytes(), alignmentof(BloomBmp));
}

template<class tag, class Key> BloomBmp<tag, Key>::Param::Param(unsigned pb)
{
    b = 1 << (sizeof(Key) * 8 - 1);
    if (pb < 8 || pb > b)
	throw std::domain_error("BloomBmp b must be >= 8 and <= 2^(H-1)");
    for (bshift = 1; b > pb; bshift++, b = b >> 1);
    init();
}

#if 0
template<class tag, class Key> BloomBmp<tag, Key>::Param::Param(uint64_t N, double E)
{
    if (E >= 1.0)
	throw std::domain_error("BloomBmp error must be < 1.0");
    ...
    init();
}
#endif

template<class tag, class Key> const typename BloomBmp<tag, Key>::Param *BloomBmp<tag, Key>::p = 0;

#endif // BLOOMBMP_H
