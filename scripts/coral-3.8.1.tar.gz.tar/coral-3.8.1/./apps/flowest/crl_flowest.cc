/* 
 * Copyright 2003, 2004, 2007 The Regents of the University of California
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */
/*
 * $Id: crl_flowest.cc,v 1.78 2007/06/06 18:17:29 kkeys Exp $
 */
/*
 * Each version of this program builds a src_IP_Table, dst_IP_Table, and
 * Proto_Ports_Table, using different means to calculate flow counts.
 * All are smaller and faster than crl_flow because they do not need
 * to handle alternate expiry mechanisms.
 *
 * TUPLE
 * Maintains a hash_set of tuples; increments flow count on each entry if a
 * packet's tuple was not already in the set, producing an exact count.
 *
 * EST
 * Each table entry has a Bitmap Estimator for flow count.
 *
 * BLOOM
 * Like TUPLE, except using a Bloom Filter instead of a hash_set, saving
 * memory at the cost of some accuracy.
 */

static const char RCSid[]="$Id: crl_flowest.cc,v 1.78 2007/06/06 18:17:29 kkeys Exp $";

#if !defined(TUPLE) && !defined(BLOOM) && !defined(EST)
# define EST
# define EST_LTRB
#endif

#include "config.h"
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <cstddef>
#include <string.h>
#include <ctype.h>
#include <sys/time.h>
#include <sys/errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <signal.h>
#include <errno.h>
#include <stdexcept>

#include <netinet/in.h>
#include <netinet/in_systm.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <netinet/ip_icmp.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/resource.h> // getrusage

#include "libcoral.h"
#include "crl_byteorder.h"
#include "hashtab.h"

#include <utility>
#include "flowest_table.h"

#if defined(HAVE_HASH_SET)	// TUPLE
# include <hash_set>
#elif defined(HAVE_EXT_HASH_SET)
# include <ext/hash_set>
#else
# error "Cannot build without hash_set"
#endif
#include "h3.h"
#include "bitmap.h"		// EST, BLOOM
#include "bloombmp.h"		// BLOOM
#include "drbmp.h"		// EST
#include "mrbmp.h"		// EST
#include "trbmp.h"		// EST
#include "ltrbmp.h"		// EST
#include "alignmentof.h"	// EST, BLOOM

using namespace std;
#ifdef HAVE_EXT_HASH_SET // XXX Hackery in assuming ext/hash_set is GCC 3.x
using namespace __gnu_cxx;
#endif

#define OUTPUT_VERSION "1.1"
#define EST_OVERFLOW UINT64_MAX	// EST

#define PORTS_NONE   0x00 // port fields are not valid
#define PORTS_LEGACY 0x01 // dport and sport have valid values (old format ONLY)
#define PORTS_DPORT  0x02 // dport is a valid dst port
#define PORTS_SPORT  0x04 // sport is a valid src port
#define PORTS_PORTS  (PORTS_SPORT | PORTS_DPORT)
#define PORTS_OTHER  0x08 // "ports" are really other proto-dependent values
			  // (icmp: type/code)

#if !PATH_MAX
# define PATH_MAX 1024
#endif

/* Solaris crap */
#ifndef IP_OFFMASK
#define IP_OFFMASK 0x1FFF
#endif

#define PSH_MAX	    0x7FFFFFFFul // assume random() returns >= 31 bits
#define FSH_MAX	    0x0000FFFFul

typedef uint16_t sample_hashval_t;	// for FSH or DSH sampling
typedef uint32_t table_hashval_t;	// for table insertion
typedef uint64_t est_hashval_t;		// for Estimator bitmap
// typedef uint32_t tuple_hashval_t;	// for tuple_set XXX not used --rkoga
typedef uint32_t bloom_hashval_t;	// for bloom filter tuple set

#if defined(TUPLE) || defined(BLOOM)
typedef uint64_t flow_t;
#endif // TUPLE || BLOOM
#ifdef EST
typedef double flow_t;
#endif

static const char *hostname(const struct in_addr *addr);

class Procstats
{
    const char *firstheap;
    const char *lastheap;
    struct timeval firstrtime, lastrtime, utime, stime;
public:
    Procstats() {
	firstheap = lastheap = (char*)sbrk(0);
	gettimeofday(&firstrtime, NULL);
	lastrtime = firstrtime;
    }
    ~Procstats() {
#ifndef NDEBUG
	(*this)("end app");
#endif
    }
    void operator()(const char *label) {
	if (coral_verbosity < 2) return;
	struct rusage ru;
	struct timeval now, rdiff, udiff, sdiff;
	const char *thisheap = (char*)sbrk(0);
	getrusage(RUSAGE_SELF, &ru);
	gettimeofday(&now, NULL);
	timersub(&now, &firstrtime, &rdiff);
	coral_printf(
	    "# %s: heap %ld KB, real %ld.%03lds, user %ld.%03lds, sys %ld.%03lds ",
	    label,
	    (thisheap - firstheap) / 1024,
	    rdiff.tv_sec, rdiff.tv_usec/1000,
	    ru.ru_utime.tv_sec, ru.ru_utime.tv_usec/1000,
	    ru.ru_stime.tv_sec, ru.ru_stime.tv_usec/1000);
	timersub(&now, &lastrtime, &rdiff);
	timersub(&ru.ru_utime, &utime, &udiff);
	timersub(&ru.ru_stime, &stime, &sdiff);
	coral_printf(
	    "(+%ld KB, +%ld.%03lds, +%ld.%03lds, +%ld.%03lds)\n",
	    (thisheap - lastheap) / 1024,
	    rdiff.tv_sec, rdiff.tv_usec/1000,
	    udiff.tv_sec, udiff.tv_usec/1000,
	    sdiff.tv_sec, sdiff.tv_usec/1000
	    );
	lastheap = thisheap;
	lastrtime = now;
	utime = ru.ru_utime;
	stime = ru.ru_stime;
    }
    void mem(const struct timespec *ts);
} procstats;

class coral_fetime : public fetime
{
public:
    coral_iface_t *iface;
    const coral_timestamp_t *ts;
    virtual double operator()() const { return coral_read_clock_double(iface, ts); }
};

struct {
    double dinterval;
#ifdef EST
    unsigned d, g, c, b;
    uint64_t N;
    double E;
#endif // EST
#ifdef BLOOM
    unsigned b;
    u_char correction;
#endif // BLOOM
    u_int netmask;
    uint32_t psh;
    uint32_t fsh;
    size_t max_size;
    int tables;
    u_char mem;
    uint32_t adapt_sampling;
    int rmark;
    u_char fixed_sampling;
    u_char sampling;
    u_char cnames;
    u_char stats;
    u_char binary;
    u_char pretty;  /* non-pretty isn't needed if apps can read pretty format */
    u_char rotate_files;
    u_char skip_ephemeral_ports;
    u_char flowprec;
    u_char hostdegree;
    u_char srchost, dsthost, protoports, protoport; // XXX
    const char *outfilename;
    coral_rotfile_t *rf;
    FILE *file;
} config;

const char *fmt_rheader, *fmt_right, *fmt_degree;
int width_flows = 0;
double presample_correction = 1; // XXX should be per-interface
double min_presample = 1;

struct {
    double ipbytes;
    double notIP;
    coral_pkt_stats_t *pkt_stats;
    double begin;
    double end;
} interval_data;

#define VPVC_HASH_TABLE_SIZE	229
#define FLOW_HASH_TABLE_SIZE	199999
#define TUPLE_HASH_TABLE_SIZE	1999999		// TUPLE

struct subif_stats;

struct tuple_key {
    struct in_addr src, dst;
    uint16_t sport;
    uint16_t dport;
    uint8_t proto;
    uint8_t ports_ok;

#ifdef TUPLE
    bool operator== (const tuple_key &b) const	// needed for hash_set
    {
	return
	    src.s_addr == b.src.s_addr &&
	    dst.s_addr == b.dst.s_addr &&
	    sport == b.sport && dport == b.dport &&
	    proto == b.proto && ports_ok == b.ports_ok;
    }
#endif // TUPLE
};

template<class T>
struct tuple_key_hash {
    const H3<T, 13> h;
    tuple_key_hash() : h() {};

    T operator()(const tuple_key &key) const
    {
	return h(&key, 13, 0); /* ports_ok doesn't help much, so skip it */
    }
};

static const tuple_key_hash<sample_hashval_t> sample_hash;
static const tuple_key_hash<table_hashval_t> table_hash;
/* XXX Not used --rkoga
#ifdef TUPLE
static const tuple_key_hash<tuple_hashval_t> tuple_hash;
#endif
*/
#ifdef EST
static const tuple_key_hash<est_hashval_t> est_hash;
#endif
#ifdef BLOOM
static const tuple_key_hash<bloom_hashval_t> bloom_hash[2];
#endif

struct hostdegree_key {
    struct in_addr src, dst;
#ifdef TUPLE
    bool operator== (const hostdegree_key &b) const     // needed for hash_set
    {
        return src.s_addr == b.src.s_addr && dst.s_addr == b.dst.s_addr;
    }
#endif // TUPLE
};

#ifdef TUPLE
template<> struct hash<tuple_key> {
    size_t operator()(const tuple_key & key) const
    {
	return /* (size_t)(key.parent) ^ */ // XXX must include if/subif
	    ((size_t)(key.src.s_addr) * 59) ^
	    ((size_t)(key.dst.s_addr)) ^
	    ((size_t)(key.sport) << 16) ^
	    ((size_t)(key.dport)) ^
	    ((size_t)(key.proto));
    }
};

template<> struct hash<hostdegree_key> {
    size_t operator()(const hostdegree_key & key) const
    {
        return /* (size_t)(key.parent) ^ */ // XXX must include if/subif
            ((size_t)(key.src.s_addr) * 59) ^
            ((size_t)(key.dst.s_addr));
    }
};
#endif // TUPLE

struct ip_key {
    struct subif_stats *parent;
    struct in_addr addr;
    static const char *fmt_lheader, *fmt_left;
    ip_key() : parent(), addr() {}
    ip_key(subif_stats *p, in_addr a) : parent(p), addr(a) {}
    bool operator== (const ip_key &b) const	// needed for hash_map
	{ return (addr.s_addr == b.addr.s_addr && parent == b.parent); }
    static int header()
	{ return fprintf(config.file, fmt_lheader, "IP"); }
    int dump_text() const
	{ return fprintf(config.file, fmt_left, hostname(&addr)); }
    void dump_binary() const {
	uint8_t length = sizeof(addr);
	uint8_t full_save = 0; // there are no first and latest timestamps
	fwrite(&length, sizeof(length), 1, config.file);
	fwrite(&full_save, sizeof(full_save), 1, config.file);
	fwrite(&addr, sizeof(addr), 1, config.file);
    }
    static void notes() {}
};

struct ports_key {
    struct subif_stats *parent;
    uint8_t proto;
    uint8_t ports_ok;
    uint16_t sport;
    uint16_t dport;
    static const char *fmt_lheader, *fmt_left;
    ports_key() : parent(), proto(), ports_ok(), sport(), dport() {}
    ports_key(subif_stats *p, uint8_t pro, uint8_t pok, uint16_t sp, uint16_t dp) :
	parent(p), proto(pro), ports_ok(pok), sport(sp), dport(dp)
	{
	    if (config.skip_ephemeral_ports && ports_ok == PORTS_PORTS) {
		// If exactly 1 port is in well-known range, ignore the other.
		if (sport < 1024 && dport >= 1024) {
		    dport = 0;
		    ports_ok &= ~PORTS_DPORT;
		} else if (dport < 1024 && sport >= 1024) {
		    sport = 0;
		    ports_ok &= ~PORTS_SPORT;
		}
	    }
	}
    bool operator== (const ports_key &b) const	// needed for hash_map
	{ return (sport == b.sport && dport == b.dport && proto == b.proto && ports_ok == b.ports_ok); }
    static int header()
	{ return fprintf(config.file, fmt_lheader, "pro", "ok", "sport", "dport"); }
    int dump_text() const
	{ return fprintf(config.file, fmt_left, proto, ports_ok, sport, dport); }
    void dump_binary() const {
	uint8_t length = sizeof(proto) + sizeof(ports_ok) + sizeof(sport) + sizeof(dport);
	uint8_t full_save = 0; // there are no first and latest timestamps
	uint16_t nsport = htons(sport);
	uint16_t ndport = htons(dport);
	fwrite(&length, sizeof(length), 1, config.file);
	fwrite(&full_save, sizeof(full_save), 1, config.file);
	fwrite(&proto, sizeof(proto), 1, config.file);
	fwrite(&ports_ok, sizeof(ports_ok), 1, config.file);
	fwrite(&nsport, sizeof(nsport), 1, config.file);
	fwrite(&ndport, sizeof(ndport), 1, config.file);
    }
    static void notes() {
	if (config.skip_ephemeral_ports)
	    fprintf(config.file, "# ephemeral ports are folded\n");
    }
};

struct port_key {
    struct subif_stats *parent;
    uint8_t proto;
    uint8_t ports_ok;
    uint16_t port;
    static const char *fmt_lheader, *fmt_left;
    port_key() : parent(), proto(), ports_ok(), port() {}
    port_key(subif_stats *p, uint8_t pro, uint8_t pok, uint16_t pt) :
	parent(p), proto(pro), ports_ok(pok), port(pt)
	{}
    bool operator== (const port_key &b) const	// needed for hash_map
	{ return (port == b.port && proto == b.proto && ports_ok == b.ports_ok); }
    static int header()
	{ return fprintf(config.file, fmt_lheader, "pro", "ok", "port"); }
    int dump_text() const
	{ return fprintf(config.file, fmt_left, proto, ports_ok, port); }
    void dump_binary() const {
	uint8_t length = sizeof(proto) + sizeof(ports_ok) + sizeof(port);
	uint8_t full_save = 0; // there are no first and latest timestamps
	uint16_t nport = htons(port);
	fwrite(&length, sizeof(length), 1, config.file);
	fwrite(&full_save, sizeof(full_save), 1, config.file);
	fwrite(&proto, sizeof(proto), 1, config.file);
	fwrite(&ports_ok, sizeof(ports_ok), 1, config.file);
	fwrite(&nport, sizeof(nport), 1, config.file);
    }
    static void notes() {
	if (config.skip_ephemeral_ports)
	    fprintf(config.file, "# ephemeral ports are folded\n");
    }
};

struct src_key : public ip_key {
    src_key() : ip_key() {}
    src_key(subif_stats *p, in_addr a) : ip_key(p, a) {}
};
struct dst_key : public ip_key {
    dst_key() : ip_key() {}
    dst_key(subif_stats *p, in_addr a) : ip_key(p, a) {}
};
struct sport_key : public port_key {
    sport_key() : port_key() {}
    sport_key(subif_stats *p, uint8_t pro, uint8_t pok, uint16_t pt) :
	port_key(p, pro, pok, pt)
	{}
};
struct dport_key : public port_key {
    dport_key() : port_key() {}
    dport_key(subif_stats *p, uint8_t pro, uint8_t pok, uint16_t pt) :
	port_key(p, pro, pok, pt)
	{}
};

#define hashfield(keyfield, tuplefield) \
    table_hash.h(&key.keyfield, sizeof(key.keyfield), \
	offsetof(tuple_key, tuplefield))

#ifdef HAVE_EXT_HASH_SET // XXX Hackery in assuming ext/hash_set is GCC 3.x
namespace __gnu_cxx {
#endif
template<> struct hash<src_key> {
    size_t operator()(const src_key & key) const
	{ return (size_t)(key.parent) ^ hashfield(addr, src); }
};

template<> struct hash<dst_key> {
    size_t operator()(const dst_key & key) const
	{ return (size_t)(key.parent) ^ hashfield(addr, dst); }
};

template<> struct hash<ports_key> {
    size_t operator()(const ports_key & key) const
    {
	return (size_t)(key.parent) ^ hashfield(proto, proto) ^
	    hashfield(sport, sport) ^ hashfield(dport, dport);
    }
};

template<> struct hash<sport_key> {
    size_t operator()(const sport_key & key) const
    {
	return (size_t)(key.parent) ^ hashfield(proto, proto) ^
	    hashfield(port, sport);
    }
};

template<> struct hash<dport_key> {
    size_t operator()(const dport_key & key) const
    {
	return (size_t)(key.parent) ^ hashfield(proto, proto) ^
	    hashfield(port, dport);
    }
};
#ifdef HAVE_EXT_HASH_SET // XXX Hackery in assuming ext/hash_set is GCC 3.x
}
#endif

#ifdef EST
class totalflowtag {};
typedef MultiResBmp<totalflowtag, est_hashval_t> totalflow_t;
#endif // EST
#ifdef TUPLE
typedef hash_set<tuple_key> tuple_set_t;
typedef hash_set<hostdegree_key> hostdegree_set_t;
#endif // TUPLE

class flow_data; // forward declaration

typedef flowest_table<src_key, flow_data*> src_hashmap_t;
typedef flowest_table<dst_key, flow_data*> dst_hashmap_t;
typedef flowest_table<ports_key, flow_data*> ports_hashmap_t;
typedef flowest_table<sport_key, flow_data*> sport_hashmap_t;
typedef flowest_table<dport_key, flow_data*> dport_hashmap_t;

struct flow_data {
#ifdef EST
#ifdef EST_MRB
    typedef MultiResBmp<flow_data, est_hashval_t> Estimator;
#endif
#ifdef EST_TRB
    typedef TriggeredBmp<flow_data, est_hashval_t> Estimator;
#endif
#ifdef EST_LTRB
    typedef ListTrigBmp<flow_data, est_hashval_t> Estimator;
#endif
    struct Param {
	mutable PoolAllocator alloc;
	Param(unsigned d, unsigned g, unsigned c, unsigned b)
	{
	    Estimator::p = new Estimator::Param(d, g, c, b);
	    alloc = PoolAllocator(bytes(), alignmentof(flow_data));
	}
	Param(uint64_t N, double E)
	{
	    Estimator::p = new Estimator::Param(N, E);
	    alloc = PoolAllocator(bytes(), alignmentof(flow_data));
	}
	size_t varbytes() const
	    { return Estimator::p->varbytes(); } /* size of variable part */
	size_t bytes() const
	    { return sizeof(flow_data) + varbytes(); } /* total size */
	void stats() const
	    { alloc.stats(); }

	std::string namestr() const { return Estimator::p->namestr(); }
	std::string paramstr() const { return Estimator::p->paramstr(); }
    };

    static const Param *p;
#endif // EST

    double pkts;	// must be 8-byte aligned on some architectures
    double bytes;	// must be 8-byte aligned on some architectures
#if defined(TUPLE) || defined(BLOOM)
    uint64_t flows;	// must be 8-byte aligned on some architectures
    uint64_t degree;	// must be 8-byte aligned on some architectures
#endif // TUPLE || BLOOM
#ifdef EST
    Estimator flows;	// variable size - must be last data member

// functions
    void *operator new(size_t size)
    {
	void *ptr = p->alloc();
	(static_cast<flow_data*>(ptr))->flows.setmagic();
	return ptr;
    }
    void operator delete(void *ptr, size_t size) { p->alloc.free(ptr); }
#endif // EST

    ~flow_data() {}
#if defined(TUPLE) || defined(BLOOM)
    flow_data() : pkts(), bytes(), flows(), degree() {}
#else
    flow_data() : pkts(), bytes(), flows() {}
#endif
#ifdef EST
    void set(est_hashval_t hashval) { flows.set(hashval); }
    double estimate() { return flows.estimate(); }
#endif // EST
};

#ifdef EST
const flow_data::Param *flow_data::p = 0;
template <> const totalflow_t::Param *totalflow_t::p = 0;
#endif // EST

#ifdef BLOOM
class tupletag {};
typedef BloomBmp<tupletag, bloom_hashval_t> tuple_set_t;
template <> const tuple_set_t::Param *tuple_set_t::p = 0;
tuple_set_t *tuple_set;

class hostdegreetag {};
typedef BloomBmp<hostdegreetag, bloom_hashval_t> hostdegree_set_t;
template <> const hostdegree_set_t::Param *hostdegree_set_t::p = 0;
hostdegree_set_t *hostdegree_set;
#endif // BLOOM

#ifdef TUPLE
tuple_set_t *tuple_set = NULL;
hostdegree_set_t *hostdegree_set = NULL;
#endif // TUPLE

template<class C> inline void cleartable(C*& c)
{
    typename C::iterator it;
    for (it = c->begin(); it != c->end(); ++it)
	delete it->second;
    c->clear();
    if (c->other) delete c->other;
    delete c;
    c = NULL;
}

struct subif_stats {
// key
    coral_iface_t *iface;
    u_int iface_id;
    u_int subif_id;

// data
    uint64_t recv_pkts;
    double pkts;
    double bytes;
    uint64_t unknown_encaps;
    uint64_t ip_not_v4;
#if defined(TUPLE) || defined(BLOOM)
    uint64_t flows;
#endif // TUPLE || BLOOM
#ifdef EST
    totalflow_t *flows;
#endif // EST
    src_hashmap_t *srcip_tab;
    dst_hashmap_t *dstip_tab;
    ports_hashmap_t *ports_tab;
    sport_hashmap_t *sport_tab;
    dport_hashmap_t *dport_tab;

    subif_stats(coral_iface_t *p_iface, u_int p_iface_id, u_int p_subif_id) :
	iface(p_iface), iface_id(p_iface_id), subif_id(p_subif_id),
	recv_pkts(), pkts(), bytes(), unknown_encaps(), ip_not_v4(),
	flows(),
	srcip_tab(), dstip_tab(),
	ports_tab(), sport_tab(), dport_tab()
	{}

    void clear() {
	if (srcip_tab) cleartable(srcip_tab);
	if (dstip_tab) cleartable(dstip_tab);
	if (ports_tab) cleartable(ports_tab);
	if (sport_tab) cleartable(sport_tab);
	if (dport_tab) cleartable(dport_tab);
    }

    ~subif_stats() { clear(); }
};

hash_tab *subif_hash = NULL;

void Procstats::mem(const struct timespec *ts) {
    static const struct subif_stats *subifrec = NULL; // XXX hack, assumes only one subif
    if (!subifrec) {
	init_hash_walk(subif_hash);
	subifrec = (const subif_stats*)next_hash_walk(subif_hash);
    }
    const char *thisheap = (char*)sbrk(0);
    coral_printf("# %ld.%06ld\t%ld\t%ld\t%ld\t%ld\t%ld\n",
	ts->tv_sec, ts->tv_nsec/1000,
	(thisheap - firstheap) / 1024,
	subifrec->srcip_tab->size(),
	subifrec->dstip_tab->size(),
	subifrec->sport_tab->size(),
	subifrec->dport_tab->size());
}

int interrupted = 0;
const char rotating_filename[] = "%010s.%f.t2";
const char *ip_key::fmt_lheader, *ip_key::fmt_left;
const char *ports_key::fmt_lheader, *ports_key::fmt_left;
const char *port_key::fmt_lheader, *port_key::fmt_left;


/* ---- hash table per subif fxns begin ---- */
/* -- per subif hash table fxns -- */

/* return 0 if the same - for use by the hashtable */
static int compare_subif_stats(const void *entry1, const void *entry2)
{
    const subif_stats *foo1 = (const subif_stats *)entry1;
    const subif_stats *foo2 = (const subif_stats *)entry2;

    return (foo1->subif_id != foo2->subif_id ||
	    foo1->iface_id != foo2->iface_id);
}

/* make a hash of an entry - for use by the hashtable */
static unsigned long make_key_subif_stats(const void *entry)
{
    const subif_stats *what = (const subif_stats *)entry;

    return (unsigned) what->subif_id * 425879 + what->iface_id;
}

/* free mem of an entry - for use by the hashtable */
static void delete_subif_stats(void *entry)
{
    subif_stats *what = (subif_stats *)entry;
    if (!what) return;
    free(what);
}
/* -- end of subif type hash table fxns -- */


/* ---- hash table fxns end ---- */

template<class K, class D, class H>
static D* count_pkt_by_key(const K &key, flowest_table<K,D*,H>& table,
    double bytes, bool &newentry, uint32_t psh_val, uint32_t fsh_val,
    const fetime &now)
{
    D **dpp;
    bool needflowupdate = true;
    typename flowest_table<K,D*,H>::iterator flowit;

    if ((flowit = table.find(key)) != table.end()) {
	dpp = &flowit->second;
    } else {
	int sample_decisions = !config.sampling;
	bool do_psh, do_fsh;
	if ((do_psh = table.psh.sampleP(psh_val))) sample_decisions++;
	if ((do_fsh = table.fsh.sampleP(fsh_val))) sample_decisions++;
	if (sample_decisions > 0 && table.size() < config.max_size) {
	    dpp = &table[key];
	    if (config.adapt_sampling) {
		if (do_psh) table.psh.update(sample_decisions, now);
		if (do_fsh) table.fsh.update(sample_decisions, now);
	    }
	} else {
	    dpp = &table.other;
	    needflowupdate = (sample_decisions > 0);
	}
    }

    if (!*dpp) {
	newentry = true;
	*dpp = new D;
	if (!*dpp) {
	    fprintf(stderr, "can't alloc flow record.\n");
	    abort();
	}
    }

    (*dpp)->pkts += presample_correction;
    (*dpp)->bytes += bytes;

    return needflowupdate ? *dpp : NULL;
}

static void count_packet(subif_stats *subif, coral_iface_t *iface,
    const coral_pkt_buffer_t *netpkt, const coral_timestamp_t *ts)
{
    short offset;
    struct ip * ip;
    coral_pkt_buffer_t payload;
    uint16_t sport, dport;

    tuple_key flowid;

    ip = (struct ip*)netpkt->buf;
    offset = ntohs(ip->ip_off) & IP_OFFMASK;

    flowid.src.s_addr = config.netmask & ip->ip_src.s_addr;
    flowid.dst.s_addr = config.netmask & ip->ip_dst.s_addr;
    flowid.proto = ip->ip_p;
    flowid.ports_ok = 0;
    sport = flowid.sport = 0;
    dport = flowid.dport = 0;
    bool newentry = false;

    coral_get_payload(netpkt, &payload);
    /* NOT get_payload_by_layer(..., 4); we want the payload, no matter what
     * layer it claims to be.  (Specifically, we don't want to go through
     * IPIP encapsulations.)
     */

    /* extract port info */
    if (offset != 0) {
	// non-first fragment, no layer 4 header
    } else if (ip->ip_p == IPPROTO_TCP) {
	if (payload.caplen >= 4) {
	    struct tcphdr *t = (struct tcphdr*)payload.buf;
	    sport = flowid.sport = ntohs(t->th_sport);
	    dport = flowid.dport = ntohs(t->th_dport);
	    flowid.ports_ok = PORTS_PORTS;
	}
    } else if (ip->ip_p == IPPROTO_UDP) {
	if (payload.caplen >= 4) {
	    struct udphdr *u = (struct udphdr*)payload.buf;
	    sport = flowid.sport = ntohs(u->uh_sport);
	    dport = flowid.dport = ntohs(u->uh_dport);
	    flowid.ports_ok = PORTS_PORTS;
	}
    } else if (ip->ip_p == IPPROTO_ICMP) {
	if (payload.caplen >= 2) {
	    struct icmp *icmp = (struct icmp*)payload.buf;
	    flowid.sport = icmp->icmp_type;
	    flowid.dport = icmp->icmp_code;
	    sport = dport = (icmp->icmp_type << 8) | icmp->icmp_code;
	    flowid.ports_ok = PORTS_OTHER;
	}
#if 0
    } else if (ip->ip_p == IPPROTO_IGMP) {
	    ...
	    flowid.sport = igmp->igmp_type;
	    flowid.dport = igmp->igmp_code;
	    flowid.ports_ok = PORTS_OTHER;
#endif
    }

    double bytes = ntohs(ip->ip_len) * presample_correction;
    flow_data *portsflow_data = NULL;
    flow_data *sportflow_data = NULL, *dportflow_data = NULL;
    flow_data *srcipflow_data = NULL, *dstipflow_data = NULL;

    uint32_t psh_val, fsh_val;
    if (config.sampling) {
	psh_val = uint32_t(random()) & PSH_MAX;
	fsh_val = sample_hash(flowid);
#if 0 // hostdegree
	dsh_val = sample_hash.hostdegree(hostdegreeid);
#endif
    }
    coral_fetime now;
    now.iface = iface;
    now.ts = ts;

    if (config.protoports) {
	portsflow_data =
	    count_pkt_by_key(ports_key(subif, flowid.proto, flowid.ports_ok, flowid.sport, flowid.dport),
	    *subif->ports_tab, bytes, newentry, psh_val, fsh_val, now);
    }
    if (config.protoport) {
	sportflow_data =
	    count_pkt_by_key(sport_key(subif, flowid.proto, flowid.ports_ok, sport),
	    *subif->sport_tab, bytes, newentry, psh_val, fsh_val, now);
	dportflow_data =
	    count_pkt_by_key(dport_key(subif, flowid.proto, flowid.ports_ok, dport),
	    *subif->dport_tab, bytes, newentry, psh_val, fsh_val, now);
    }
    if (config.srchost) {
	srcipflow_data =
	    count_pkt_by_key(src_key(subif, flowid.src),
	    *subif->srcip_tab, bytes, newentry, psh_val, fsh_val, now);
    }
    if (config.dsthost) {
	dstipflow_data =
	    count_pkt_by_key(dst_key(subif, flowid.dst),
	    *subif->dstip_tab, bytes, newentry, psh_val, fsh_val, now);
    }

    {
#if defined(TUPLE) || defined(BLOOM)
# ifdef BLOOM
	bool newtuple = !tuple_set->set(bloom_hash[0](flowid),
	    bloom_hash[1](flowid));
# endif // BLOOM
# ifdef TUPLE
	pair<tuple_set_t::iterator, bool> P;
	P = tuple_set->insert(flowid);
	bool newtuple = P.second;
# endif // TUPLE
	if (newtuple || (newentry && !config.sampling)) {
	    // newtuple means new flow.
	    // if not sampling, newentry also means new flow.
            // XXX TODO: if a new entry was created and the FLOW sampling
            // criterion was met, this IS a new flow, so we should increment
            // all entries.
	    subif->flows++;
	    if (portsflow_data) portsflow_data->flows++;
	    if (sportflow_data) sportflow_data->flows++;
	    if (dportflow_data) dportflow_data->flows++;
	    if (srcipflow_data) srcipflow_data->flows++;
	    if (dstipflow_data) dstipflow_data->flows++;
	} else if (newentry) {
	    // If sampling, newentry means new flow only to the new entry,
	    // not necessarily for the old entries.
	    if (portsflow_data && portsflow_data->flows == 0)
		portsflow_data->flows = 1;
	    if (sportflow_data && sportflow_data->flows == 0)
		sportflow_data->flows = 1;
	    if (dportflow_data && dportflow_data->flows == 0)
		dportflow_data->flows = 1;
	    if (srcipflow_data && srcipflow_data->flows == 0)
		srcipflow_data->flows = 1;
	    if (dstipflow_data && dstipflow_data->flows == 0)
		dstipflow_data->flows = 1;
	}
#endif // defined(TUPLE) || defined(BLOOM)
#ifdef EST
	est_hashval_t hashval = est_hash(flowid);
	subif->flows->set(hashval);
	if (portsflow_data) portsflow_data->set(hashval);
	if (sportflow_data) sportflow_data->set(hashval);
	if (dportflow_data) dportflow_data->set(hashval);
	if (srcipflow_data) srcipflow_data->set(hashval);
	if (dstipflow_data) dstipflow_data->set(hashval);
#endif // EST

#if 0 // hostdegree
#if defined(TUPLE) || defined(BLOOM)
	if (config.hostdegree) {
	    hostdegree_key hostdegreeid;
	    hostdegreeid.src = flowid.src;
	    hostdegreeid.dst = flowid.dst;
# ifdef BLOOM
	    bool newhostdegree =
		!hostdegree_set->set(tuplehash[0].hostdegree(hostdegreeid),
		    tuplehash[1].hostdegree(hostdegreeid));
# endif // BLOOM
# ifdef TUPLE
	    pair<hostdegree_set_t::iterator, bool> P;
	    P = hostdegree_set->insert(hostdegreeid);
	    bool newhostdegree = P.second;
# endif // TUPLE
	    if (newhostdegree /* XXX || new srcip entry || new dstip entry */) {
		if (srcipflow_data) srcipflow_data->degree++;
		if (dstipflow_data) dstipflow_data->degree++;
	    }
	}
#endif // defined(TUPLE) || defined(BLOOM)
#endif // hostdegree
    }
}

/* NB: returns a pointer to static data */
static const char *hostname(const struct in_addr *addr)
{
    struct hostent *h;
    if (config.cnames &&
	(h = gethostbyaddr((char*)addr, sizeof(struct in_addr), AF_INET)))
    {
	return h->h_name;
    } else {
	return inet_ntoa(*addr);
    }
}

template<class K, class D, class H>
static void dump_binary_flow_table(flowest_table<K,D*,H>& hashtab,
    double correction, bool degreeflag)
{
    typename flowest_table<K,D*,H>::iterator flowit;

    /* TODO: this format could be more compact.
     * simple changes:
     *   length is unnecessary afaict.
     *   If !ports_ok, omit sport and dport.
     *   uint64_t fields could use write_binary_int() from crl_dnsstat.c
     *     so they'd usually take only <=4 bytes instead of 8.
     *   These could reduce size by ~30%.
     * -kkeys
     */

    fputs("#binary data follows\n", config.file);

    // FIXME: dump "other" entry
    for (flowit = hashtab.begin(); flowit != hashtab.end(); ++flowit) {
	if (flowit->second->pkts) {
	    uint64_t pkts = crl_hton64(uint64_t(flowit->second->pkts+.5));
	    uint64_t bytes = crl_hton64(uint64_t(flowit->second->bytes+.5));
	    uint64_t flows;
#if defined(TUPLE)
	    flows = flowit->second->flows;
#endif // TUPLE
#if defined(BLOOM)
	    flows = config.correction ?
		(uint64_t)(flowit->second->flows * correction + 0.5) :
		flowit->second->flows;
#endif // BLOOM
#ifdef EST
	    try {
		flows = (uint64_t)(flowit->second->estimate() + 0.5);
	    } catch (overflow_error &e) {
		flows = EST_OVERFLOW; // XXX
	    }
#endif // EST
	    flows = crl_hton64(flows);

	    flowit->first.dump_binary();
	    fwrite(&pkts, sizeof(pkts), 1, config.file);
	    fwrite(&bytes, sizeof(bytes), 1, config.file);
	    fwrite(&flows, sizeof(flows), 1, config.file);
#if defined(TUPLE) || defined(BLOOM)
            if (degreeflag) {
                uint64_t degree = crl_hton64(flowit->second->degree);
                fwrite(&degree, sizeof(degree), 1, config.file);
            }
#endif // defined(TUPLE) || defined(BLOOM)
	}
    }
    fwrite("\0", 1, 1, config.file); // table trailer
    fputs("\n# end of binary table\n\n", config.file);

    fflush(config.file);
}

template<class D>
static void dump_text_flow(D *counter, double correction, bool degreeflag,
    double& total_pkts, double& total_bytes, flow_t& total_flows)
{
    total_pkts += counter->pkts;
    total_bytes += counter->bytes;
    fprintf(config.file, fmt_right,
	counter->pkts, counter->bytes);
#if defined(TUPLE)
    uint64_t flows = counter->flows;
    fprintf(config.file, "%*" PRIu64, width_flows, flows);
#endif // TUPLE
#if defined(BLOOM)
    uint64_t flows = config.correction ?
	(uint64_t)(counter->flows * correction + 0.5) : counter->flows;
    fprintf(config.file, "%*" PRIu64, width_flows, flows);
#endif // BLOOM
#ifdef EST
    double flows = 0;
    try {
	flows = counter->estimate();
	fprintf(config.file, "%*.*f", width_flows, config.flowprec, flows);
    } catch (overflow_error &e) {
	total_flows = -1; // indicates overflow
	fprintf(config.file, "%*s", width_flows, "overflow");
    }
#endif // EST
#if defined(BLOOM) || defined(TUPLE)
    if (degreeflag) {
        fprintf(config.file, fmt_degree, width_flows, counter->degree);
    }
#endif // defined(BLOOM) || defined(TUPLE)
    fputc('\n', config.file);
    if (total_flows >= 0) total_flows += flows;
}

template<class K, class D, class H>
static void dump_text_flow_table(flowest_table<K,D*,H>& hashtab,
    double correction, bool degreeflag)
{
    typename flowest_table<K,D*,H>::iterator flowit;
#ifdef EST
    uint32_t m = 0; // XXX
#endif // EST
    double total_pkts = 0, total_bytes = 0;
    flow_t total_flows = 0;

    if (hashtab.other) {
	fprintf(config.file, "# other:\t");
	dump_text_flow(hashtab.other, correction, degreeflag,
	    total_pkts, total_bytes, total_flows);
    }

    K::header();
    fprintf(config.file, fmt_rheader, "pkts", "bytes", "flows",
	degreeflag ? "degree" : "");

    for (flowit = hashtab.begin(); flowit != hashtab.end(); ++flowit) {
	if (flowit->second->pkts > 0) {
	    flowit->first.dump_text();
	    dump_text_flow(flowit->second, correction, degreeflag,
		total_pkts, total_bytes, total_flows);
	}
#ifdef EST
	if (flowit->second->flows.have_mrbmp()) m++; // XXX
#endif // EST
    }
    fputs("# end of text table\n", config.file);
    fprintf(config.file, "# pkts=%.0f bytes=%.0f", total_pkts, total_bytes);
#if defined(TUPLE) || defined(BLOOM)
    fprintf(config.file, " flows=%" PRIu64 "\n", total_flows);
#endif // defined(TUPLE) || defined(BLOOM)
#ifdef EST
    if (total_flows < 0)
	fprintf(config.file, " flows=overflow\n");
    else
	fprintf(config.file, " flows=%.*f\n", config.flowprec, total_flows);
    fprintf(config.file, "# mrbmps=%d\n", m); // XXX
#endif // EST
    fputs("\n", config.file);

    fflush(config.file);
}

template<class K, class D, class H>
static void dump_flow_table(const subif_stats *subifrec,
    flowest_table<K,D*,H>& hashtab, const char *label, double correction,
    bool degreeflag = false)
{
    if (hashtab.empty()) return;
    char buf[32];
    coral_fmt_if_subif(buf, subifrec->iface, subifrec->subif_id);

    // before "# begin" line to avoid choking parser
    K::notes();
    if (config.adapt_sampling) {
	fprintf(config.file, "# final PSH rate: %10.6f %%\n",
	    hashtab.psh.get_rate() * 100);
	fprintf(config.file, "# final FSH rate: %10.6f %%\n",
	    hashtab.fsh.get_rate() * 100);
    }

    fprintf(config.file, "# begin %s Table ID: %s (%d entries)\n",
	label, buf, hashtab.size());
    if (config.binary) {
	dump_binary_flow_table(hashtab, correction, degreeflag);
    } else {
	dump_text_flow_table(hashtab, correction, degreeflag);
    }
}

/* 
 * keep track of some subif related stats, and count_packet().
 */
static void count_subif_stats(coral_iface_t *iface,
    coral_pkt_result_t *pkt_result)
{
    subif_stats *subifrec;
    subif_stats tmp(iface, coral_interface_get_number(iface), pkt_result->subiface);
    coral_pkt_buffer_t netpkt;
    struct ip *ip;

    if (!(subifrec = (subif_stats*)find_hash_entry(subif_hash, &tmp))) {
	size_t size = FLOW_HASH_TABLE_SIZE;
	subifrec = new subif_stats(tmp.iface, tmp.iface_id, tmp.subif_id);
	if (subifrec == NULL) {
	    fprintf(stderr, "can't allocate subif_stats.\n");
	    abort();
	}
	sample_parms_t sample_parms;
	sample_parms.psh = config.psh;
	sample_parms.fsh = config.fsh;
	sample_parms.entries = 0;
	if (config.adapt_sampling) {
	    sample_parms.entries = config.adapt_sampling / (2 * config.tables);
	    sample_parms.begin = interval_data.begin;
	    sample_parms.interval = config.dinterval;
	    sample_parms.rmark = config.rmark;
	}
#ifdef EST
	subifrec->flows = new totalflow_t();
#endif // EST
	if (config.adapt_sampling)
	    size = config.adapt_sampling / config.tables;
	if (config.max_size < size)
	    size = config.max_size;
	if (config.srchost) {
	    subifrec->srcip_tab = new src_hashmap_t(sample_parms,
		"src IP", PSH_MAX, FSH_MAX, size);
	}
	if (config.dsthost) {
	    subifrec->dstip_tab = new dst_hashmap_t(sample_parms,
		"dst IP", PSH_MAX, FSH_MAX, size);
	}
	if (config.protoports) {
	    subifrec->ports_tab = new ports_hashmap_t(sample_parms,
		"Proto Ports", PSH_MAX, FSH_MAX, size);
	}
	if (config.protoport) {
	    subifrec->sport_tab = new sport_hashmap_t(sample_parms,
		"src Proto Port", PSH_MAX, FSH_MAX, size);
	    subifrec->dport_tab = new dport_hashmap_t(sample_parms,
		"dst Proto Port", PSH_MAX, FSH_MAX, size);
	}
        add_hash_entry(subif_hash, subifrec);
#ifndef NDEBUG
	procstats("init hash");
#endif
    }

    if (coral_get_payload_by_layer(pkt_result->packet, &netpkt, 3) < 0) {
	subifrec->unknown_encaps++;
	return;
    }

    if (!coral_proto_is_IP(netpkt.protocol)) {
	interval_data.notIP++;
	return;
    }

    ip = (struct ip*)netpkt.buf;
    if (ip->ip_v != 4) {
	subifrec->ip_not_v4++;
	return;
    }

    /* do stats --- */
    double bytes = ntohs(ip->ip_len) * presample_correction;
    subifrec->recv_pkts++;
    subifrec->pkts += presample_correction;
    subifrec->bytes += bytes;
    interval_data.ipbytes += bytes;
    count_packet(subifrec, iface, &netpkt, pkt_result->timestamp);
}

static void init_hashes(void)
{
    subif_hash = init_hash_table("# subif hash",
			       compare_subif_stats, make_key_subif_stats,
			       delete_subif_stats, VPVC_HASH_TABLE_SIZE);
#ifdef TUPLE
    tuple_set = new tuple_set_t(TUPLE_HASH_TABLE_SIZE);
    if (config.hostdegree)
        hostdegree_set = new hostdegree_set_t(TUPLE_HASH_TABLE_SIZE);
#endif // TUPLE
}


static void dump_hash_stats(void)
{
    dump_hashtab_stats(subif_hash);
}

static void dump_data(void)
{
    const subif_stats *subifrec;
    double begin;
    double end;
    int count;
#ifdef BLOOM
    double correction = 1;
#else
#   define correction 1
#endif

    begin = interval_data.begin;
    end = interval_data.end;

    /* Normal (possibly empty) interval */
    fprintf(config.file, "\n# begin trace interval: %f\n", begin);
    fprintf(config.file, "# trace interval duration: %f s\n"
		    "# Layer 2 PDUs dropped: %" PRIu64 "\n"
		    "# IP: %.4f Mbit/s\n"
		    "# Non-IP: %.4f pkts/s\n",
	(end - begin), 
	interval_data.pkt_stats->l2_drop,
	interval_data.ipbytes * 8 / (1000 * 1000 * (end - begin)),
	interval_data.notIP/(end - begin));

    fputs("# Table IDs: ", config.file);
    init_hash_walk(subif_hash);
    count = 0;
    while ((subifrec = (const subif_stats*)next_hash_walk(subif_hash))) {
	if (subifrec->srcip_tab || subifrec->dstip_tab ||
	    subifrec->ports_tab ||
	    subifrec->sport_tab || subifrec->dport_tab ||
	    subifrec->unknown_encaps || subifrec->ip_not_v4)
	{
	    char buf[32];
	    if (count++)
		fputs(", ", config.file);
	    coral_fmt_if_subif(buf, subifrec->iface, subifrec->subif_id);
	    fprintf(config.file, "%s", buf);
	}
    }
    fputs("\n\n", config.file);

#ifdef BLOOM
    if (config.correction) {
	init_hash_walk(subif_hash);
	uint64_t flowcnt = 0;
	while ((subifrec = (const subif_stats*)next_hash_walk(subif_hash))) {
	    flowcnt += subifrec->flows;
	}
	double flowest = tuple_set->estimate();
	if (flowest >= flowcnt) {
	    correction = flowest/flowcnt;
	} else {
	    coral_diag(1, ("warning: Bloom filter estimate < count\n"));
	}
	fprintf(config.file, "# flow cnt: %" PRIu64, flowcnt);
	fprintf(config.file, ", flow est: %f", flowest);
	fprintf(config.file, ", correction: %f\n", correction);
    }
#endif // BLOOM

    init_hash_walk(subif_hash);
    while ((subifrec = (const subif_stats*)next_hash_walk(subif_hash))) {
	if (subifrec->srcip_tab || subifrec->dstip_tab ||
	    subifrec->ports_tab ||
	    subifrec->sport_tab || subifrec->dport_tab ||
	    subifrec->unknown_encaps || subifrec->ip_not_v4)
	{
	    char buf[32];
	    coral_fmt_if_subif(buf, subifrec->iface, subifrec->subif_id), 
	    fprintf(config.file, "# ID: %s\n"
		    "# unknown_encaps: %" PRIu64 "\n"
		    "#      ip_not_v4: %" PRIu64 "\n",
		    buf,
		    subifrec->unknown_encaps,
		    subifrec->ip_not_v4);
	    if (subifrec->pkts > 0) {
		fprintf(config.file, "#           pkts: %.0f\n",
		    subifrec->pkts);
		fprintf(config.file, "#    actual pkts: %.0 " PRIu64 "\n",
		    subifrec->recv_pkts);
		fprintf(config.file, "#          bytes: %.0f\n",
		    subifrec->bytes);
#if defined(TUPLE)
		fprintf(config.file, "#          flows: %" PRIu64 "\n",
		    subifrec->flows);
#endif // defined(TUPLE)
#if defined(BLOOM)
		fprintf(config.file, "#          flows: %.*f\n",
		    config.flowprec, subifrec->flows * correction);
#endif // defined(BLOOM)
#ifdef EST
		try {
		    double flows = subifrec->flows->estimate();
		    fprintf(config.file, "#          flows: %.*f\n",
				config.flowprec, subifrec->flows->estimate());
		} catch (overflow_error &e) {
		    fprintf(config.file, "#          flows: %.*f\n",
				width_flows, "overflow");
		}
#endif // EST
		//fprintf(config.file,
			//"#        src IPs: %" PRIu64 "\n"
			//"#        dst IPs: %" PRIu64 "\n",
			//subifrec->srcip_tab.size(),
			//subifrec->dstip_tab.size());
		fprintf(config.file,
			"#            first: 0\n"
			"#           latest: 0\n"); // XXX
		fprintf(config.file,
			"#  min presampling: %f\n", min_presample);
		fputs("# Table types:", config.file);
		string s;
		if (subifrec->srcip_tab) s += " src IP Table,";
		if (subifrec->dstip_tab) s += " dst IP Table,";
		if (subifrec->ports_tab) s += " Proto Ports Table,";
		if (subifrec->sport_tab) s += " src Proto Port Table,";
		if (subifrec->dport_tab) s += " dst Proto Port Table,";
		s[s.length() - 1] = '\n'; // replace trailing comma
		fputs(s.c_str(), config.file);
	    }
	    fputs("\n", config.file); 
	}
    }

    init_hash_walk(subif_hash);
    while ((subifrec = (const subif_stats*)next_hash_walk(subif_hash))) {
	if (config.srchost) // XXX
	    if (subifrec->srcip_tab)
		dump_flow_table(subifrec, *subifrec->srcip_tab,
		    "src IP", correction, config.hostdegree);
	if (config.dsthost) // XXX
	    if (subifrec->dstip_tab)
		dump_flow_table(subifrec, *subifrec->dstip_tab,
		    "dst IP", correction, config.hostdegree);
	if (config.protoports) // XXX
	    if (subifrec->ports_tab)
		dump_flow_table(subifrec, *subifrec->ports_tab,
		    "Proto Ports", correction);
	if (config.protoport) { // XXX
	    if (subifrec->sport_tab)
		dump_flow_table(subifrec, *subifrec->sport_tab,
		    "src Proto Port", correction);
	    if (subifrec->dport_tab)
		dump_flow_table(subifrec, *subifrec->dport_tab,
		    "dst Proto Port", correction);
	}
    }
    fputs("# end trace interval\n", config.file);
    fflush(config.file);
}

static void clear_data(void)
{
    subif_stats *subifrec;

    interval_data.ipbytes = 0;
    interval_data.notIP = 0;

    init_hash_walk(subif_hash);
    while ((subifrec = (subif_stats*)next_hash_walk(subif_hash))) {
	subifrec->clear();
    }
#if defined(TUPLE) || defined(BLOOM)
    tuple_set->clear();
    if (config.hostdegree)
	hostdegree_set->clear();
#endif // defined(TUPLE) || defined(BLOOM)
    clear_hash_table(subif_hash);
}

static void stop(int sig)
{
    interrupted = 1;
}

int main(int argc, char *argv[])
{
    int retval = 0;
    int i;
    coral_iface_t *iface;
    coral_pkt_result_t pkt_result;
    coral_interval_result_t interval_result;
#   define CIDR_LEN 32
    u_int cidr_len = CIDR_LEN;
    struct timeval interval = { 300, 0 };
    u_int duration;
    int opt;
    int error = 0, first = 1, seeded = 0;
    char file_header[1024], *p;

    config.outfilename = "-"; /* Default to stdout */

    coral_set_api(CORAL_API_PKT);
    coral_set_duration(0);
    coral_set_interval(&interval);
    coral_set_iomode(0, CORAL_RX, 48, 0);
    coral_set_options(0, CORAL_OPT_PARTIAL_PKT | CORAL_OPT_NORMALIZE_TIME);

    config.max_size = UINT32_MAX;
    config.rmark = 2;

#ifdef TUPLE
    const char *options = "D"
#endif // TUPLE
#ifdef EST
    const char *options = "d:g:c:b:N:E:f"
#endif // EST
#ifdef BLOOM
    const char *options = "b:cD"
#endif // BLOOM
	"C:p:asBhO:o:rS:eHP:A:M:K:F:mu:<>";

    while (!error && (opt = getopt(argc, argv, options)) != -1) {
	switch (opt) {
	case 'C':
	    if (coral_config_command(optarg) < 0)
		error++;
	    break;
	case 'p':
	    cidr_len = atoi(optarg);
	    if (cidr_len > 32 || cidr_len < 8) {
		fprintf(stderr,
			"%s: valid CIDR prefix lengths are between 8 and 32\n",
			argv[0]);
		error++;
	    }
	    break;
	case 'a':
	    config.cnames = 1;
	    break;
	case 's':
	    config.stats = 1;
	    break;
	case 'B':
	    // XXX Remove when binary output is valid.
	    coral_puts("Binary output is not yet fully supported.");
	    exit(1);
	    config.binary = 1;
	    break;
#ifdef EST
	case 'd':
	    config.d = atoi(optarg);
	    break;
	case 'g':
	    config.g = atoi(optarg);
	    break;
	case 'c':
	    config.c = atoi(optarg);
	    break;
	case 'b':
	    config.b = atoi(optarg);
	    break;
	case 'N':
	    config.N = atol(optarg); // XXX 64 bits
	    break;
	case 'E':
	    config.E = atof(optarg);
	    break;
	case 'f':
	    config.flowprec = 6;
	    break;
#endif // EST
#ifdef BLOOM
	case 'b':
	    config.b = atoi(optarg);
	    break;
	case 'c':
	    config.correction = 1;
	    break;
#endif // BLOOM
#if defined(TUPLE) || defined(BLOOM)
        case 'D':
            config.hostdegree = 1;
            break;
#endif // defined(TUPLE) || defined(BLOOM)
	case 'm':
	    config.mem = 1;
	    break;
	case 'M':
	    config.max_size = atoi(optarg);
	    break;
	case 'S': // XXX
	    seeded++;
	    srandom(atoi(optarg)); // XXX
	    break;
	case 'h':
	    config.pretty = 1;
	    break;
	case 'r':
	    config.rotate_files = 1;
	    config.outfilename = rotating_filename;
	    break;
	case 'O':
	    config.rotate_files = 1;
	    /* fall through */
	case 'o':
	    config.outfilename = strdup(optarg);
	    break;
	case 'K':
	    opt = atoi(optarg);
	    if (opt >= 16) {
		error++;
		coral_diag(0, ("-K value too large"));
	    }
	    config.psh = 1 << opt;
	    config.fixed_sampling = config.sampling = 1;
	    break;
	case 'F':
	    opt = atoi(optarg);
	    if (opt >= 16) {
		error++;
		coral_diag(0, ("-F value too large"));
	    }
	    config.fsh = 1 << opt;
	    config.fixed_sampling = config.sampling = 1;
	    break;
	case 'A':
	    config.sampling = 1;
	    config.adapt_sampling = atoi(optarg);
	    break;
	case 'u':
	    config.rmark = atoi(optarg);
	    break;
	case 'e': // XXX
	    config.skip_ephemeral_ports = 1;
	    break;
	case 'H': // XXX
	    config.srchost = config.dsthost = 1;
	    break;
	case '<': // XXX
	    config.srchost = 1;
	    break;
	case '>': // XXX
	    config.dsthost = 1;
	    break;
	case 'P': // XXX
	    switch (atoi(optarg)) {
	    case 1: config.protoports = 1; break;
	    case 2: config.protoport = 1; break;
	    default: error++;
	    }
	    break;
	default:
	    error++;
	    break;
	}
    }

    if (config.adapt_sampling && config.fixed_sampling) {
	coral_diag(0,
	    ("Fixed sampling and adaptive sampling can not be combined.\n\n"));
	error++;
    }

    if (error) {
	coral_usage(argv[0], "[<options>] <source>...\n"
	    "Options:\n"
	    "-p<n>      use <n> as length of CIDR prefix (default %d)\n"
	    "-a         resolve IP addresses to hostnames (only makes sense with -p32)\n"
	    "-s         print hash table statistics\n"
//	    "-B         print binary table data\n"
	    "-h         print human readable table data\n"
	    "-o<file>   specify the name of the output file (default: -)\n"
	    "-r         rotate the output file every interval (requires a filename with\n"
	    "           %% specifiers; the default filename with -r is '%s')\n"
	    "-O<file>   equivalent to -r -o<file>\n\n"
#ifdef EST
	    "Bitmap parameters:\n"
	    "-d<d> -g<g> -c<c> -b<b>\n"
	    "-N<N> -E<E>   maximum number of flows, and acceptable error\n"
#endif // EST
#ifdef BLOOM
	    "Bitmap parameters:\n"
	    "-b<b>      size of Bloom filter (will be rounded up to power of 2)\n"
	    "-c         apply bitmap correction factor to Bloom filter counts\n"
#endif // BLOOM
#if defined(TUPLE) || defined(BLOOM)
/* Not currently used
	    "Other parameters:\n"
	    "-D         hostdegree\n"
*/
#endif // defined(TUPLE) || defined(BLOOM)
	    "Performance parameters:\n"
	    "-e	        \"fold\" ephemeral ports\n"
	    "-H	        generate srcip and dstip tables\n"
	    "-P1        generate proto/sport/dport table\n"
	    "-P2        generate proto/sport and proto/dport tables\n"
	    "-M<max>    do not allow tables to have more than <max> entries\n"
	    "-K<N>      sample only 1 in 2^N packets\n" // XXX
	    "-F<N>      sample only 1 in 2^N flows\n" // XXX
	    "-A<N>      sample pkts/flows adaptively to stay within N entries\n"
	    "-u<N>      with -A, update rates after reaching 1/N of entry limit [2]\n"
	    "Testing:\n"
	    "-m         periodically print memory usage to stderr\n" // XXX
	    "\n"
"    <file> is the name of the output file, which may contain %% specifiers\n"
"    for formatting a timestamp.  For -o, the timestamp is the beginning of\n"
"    the trace; for -O, the timestamp is the beginning of the interval.\n"
"    The %% specifiers are any of those allowed by strftime(), plus:\n"
"        %%s   number of (whole) seconds since 1970-01-01 00:00:00 UTC\n"
"        %%f   fractional part of seconds (6 decimal places)\n"
"        %%F   equivalent to %%Y-%%m-%%d\n"
"    Except for %%f, all specifiers may contain printf-style modifiers\n"
"    (e.g., \"%%010s\").\n"
"    For -o, '-' means standard output.\n",
	    CIDR_LEN,
	    rotating_filename);
	exit(-1);
    }

    if (!config.srchost && !config.dsthost && !config.protoports && !config.protoport)
	config.srchost = config.dsthost = config.protoport = 1;
    if (!seeded) srandom(time(NULL) ^ getpid()); /* XXX use /dev/random */
    if (config.srchost) config.tables += 1;
    if (config.dsthost) config.tables += 1;
    if (config.protoports) config.tables += 1;
    if (config.protoport) config.tables += 2;

    std::string parameter_str;

#ifdef EST
    try {
	if (config.N > 0 && config.E > 0) {
	    char buf[64];
	    totalflow_t::p = new totalflow_t::Param(config.N*10000, config.E); //XXX choose better parameters
	    flow_data::p = new flow_data::Param(config.N, config.E);
	    parameter_str += "# ";
	    parameter_str += totalflow_t::p->namestr() + "(";
	    parameter_str += totalflow_t::p->paramstr() + ", N=";
	    sprintf(buf, "%u", config.N);
	    parameter_str += buf;
	    parameter_str += ")\n";
	    parameter_str += "# ";
	    parameter_str += flow_data::p->namestr() + "(";
	    parameter_str += flow_data::p->paramstr() + ", N=";
	    sprintf(buf, "%u", config.N);
	    parameter_str += buf;
	    parameter_str += ")\n";
	} else if (config.c > 0 && config.b > 0) {
	    totalflow_t::p = new totalflow_t::Param(0, 0, config.c*2, config.b); //XXX choose better parameters
	    flow_data::p = new flow_data::Param(config.d, config.g, config.c, config.b);
	    parameter_str += "# ";
	    parameter_str += totalflow_t::p->namestr() + "(";
	    parameter_str += totalflow_t::p->paramstr() + ")\n";
	    parameter_str += "# ";
	    parameter_str += flow_data::p->namestr() + "(";
	    parameter_str += flow_data::p->paramstr() + ")\n";
	} else {
	    coral_diag(0, ("You must specify parameters (N,E) or (d,g,c,b).\n"));
	    exit(-1);
	}
    } catch (domain_error& e) {
	coral_diag(0, ("%s\n", e.what()));
	exit(-1);
    }
#endif // EST
#ifdef BLOOM
    try {
	tuple_set_t::p = new tuple_set_t::Param(config.b);
	parameter_str += "# ";
	parameter_str += tuple_set_t::p->namestr() + "(";
	parameter_str += tuple_set_t::p->paramstr() + ")\n";
	tuple_set = new tuple_set_t();
	if (config.hostdegree) {
	    hostdegree_set_t::p = new hostdegree_set_t::Param(config.b);
	    parameter_str += "# ";
	    parameter_str += hostdegree_set_t::p->namestr() + "(";
	    parameter_str += hostdegree_set_t::p->paramstr() + ")\n";
	    hostdegree_set = new hostdegree_set_t();
	}
    } catch (domain_error& e) {
	coral_diag(0, ("%s\n", e.what()));
	exit(-1);
    }
#endif // BLOOM

    while (optind < argc) {
	if (!coral_new_source(argv[optind]))
	    exit(-1);
	optind++;
    }

    if (!coral_next_source(NULL)) {
	coral_diag(1, ("%s: warning: no sources specified.\n", argv[0]));
    }

    init_hashes();

    /* generate a netmask from the cidr length */
    config.netmask = 0xFFFFFFFF << (32 - cidr_len);

    /* corrected for endianess */
    config.netmask = ntohl(config.netmask);

    int num_interfaces = coral_open_all();
    if (num_interfaces <= 0)
	exit(-1);

    if (coral_start_all() < 0)
	exit(-1);

    signal(SIGINT, stop);

    coral_get_interval(&interval);
    config.dinterval = timevaltodouble(&interval);
    interval_data.begin = 0;
    interval_data.end = 0;
    interval_data.pkt_stats = NULL;

    duration = coral_get_duration();
    if (duration)
	coral_diag(2, ("collection duration max set to %d second(s)\n", 
		       duration));

    coral_read_pkt_init(NULL, NULL, &interval);

    if (config.fsh)
	coral_diag(1, ("flow sample rate: 1/%d\n", config.fsh));
    if (config.psh)
	coral_diag(1, ("pkt sample rate: 1/%d\n", config.psh));
    if (config.adapt_sampling)
	coral_diag(1, ("adaptive sampling: %d\n", config.adapt_sampling));

    p = file_header;
    p += sprintf(p, "# crl_flowest output version: %s (%s format)\n",
	    OUTPUT_VERSION,
	    config.binary ? "binary" : config.pretty ? "pretty" : "text" );
    p += sprintf(p, "# generated by: ");
    for (i = 0; i < argc; i++)
	p += sprintf(p, " %s", argv[i]);
    sprintf(p, "\n");

    if (!config.binary) {
	if (!config.pretty) {
	    ip_key::fmt_lheader = "#%s";
	    ports_key::fmt_lheader = "#%s\t%s\t%s\t%s";
	    port_key::fmt_lheader = "#%s\t%s\t%s";
	    fmt_rheader = "\t%s\t%s\t%s\t%s\n";
	    ip_key::fmt_left = "%s\t";
	    ports_key::fmt_left = "%u\t%u\t%u\t%u\t";
	    port_key::fmt_left = "%u\t%u\t%u\t";
	    fmt_right = "%.0f\t%.0f\t"; // "%f\n";
	    fmt_degree = "\t%*" PRIu64;
	    width_flows = 0;
	} else {
	    if (config.cnames) {
		ip_key::fmt_lheader = "#%-29s";
		ip_key::fmt_left = "%-30s ";
	    } else {
		ip_key::fmt_lheader = "#%-14s";
		ip_key::fmt_left = "%-15s ";
	    }
	    ports_key::fmt_lheader = "#%3s %2s %5s %5s";
	    port_key::fmt_lheader = "#%3s %2s %5s";
	    ports_key::fmt_left = "%4u %2u %5u %5u ";
	    port_key::fmt_left = "%4u %2u %5u ";
	    fmt_rheader = " %13s %15s %9s %9s\n";
	    fmt_right = "%13.0f %15.0f "; // "%9.2f\n";
	    fmt_degree = " %" PRIu64;
	    width_flows = 9;
	}
    }

    config.rf = coral_rf_open_file(&config.file, config.outfilename, "", 0);
    if (!config.rf)
	exit(1);
#ifndef NDEBUG
    procstats("start loop");
#endif

    while (1) {
	if (interrupted) {
	    coral_stop_all();
	    interrupted = 0;
	}
	iface = coral_read_pkt(&pkt_result, &interval_result);

	if (!iface) {
	    if (errno == EINTR || errno == EAGAIN) continue;
	    retval = errno;
	    break;
	}

	if (!pkt_result.packet && !interval_result.stats) {
	    /* beginning of interval */
#ifndef NDEBUG
	    procstats("start int");
#endif
	    double begin = timevaltodouble(&interval_result.begin);
	    interval_data.begin = begin;
	    if (config.rotate_files || first) {
		coral_rf_start(config.rf, &interval_result.begin);
		fputs(file_header, config.file);
		fputs(parameter_str.c_str(), config.file);
		first = 0;
	    }
	    min_presample = 1.0/presample_correction;

	} else if (pkt_result.packet) {
	    /* got packet */
	    if (pkt_result.packet->totlen == 4) {
		// fake meta-info packet
		struct timeval tv;
		presample_correction = double(0x80000000) /
				(uint32_t)crl_nptohl(pkt_result.packet->buf);
		double prob = 1.0/presample_correction;
		if (min_presample > prob)
		    min_presample = prob;
		subif_stats *subifrec;
		init_hash_walk(subif_hash);
		while ((subifrec = (subif_stats*)next_hash_walk(subif_hash))) {
		    if (subifrec->srcip_tab) {
			subifrec->srcip_tab->psh.presample_adjust(prob);
		    }
		    if (subifrec->dstip_tab) {
			subifrec->dstip_tab->psh.presample_adjust(prob);
		    }
		    if (subifrec->ports_tab) {
			subifrec->ports_tab->psh.presample_adjust(prob);
		    }
		    if (subifrec->sport_tab) {
			subifrec->sport_tab->psh.presample_adjust(prob);
		    }
		    if (subifrec->dport_tab) {
			subifrec->dport_tab->psh.presample_adjust(prob);
		    }
		}
		if (presample_correction > 1 && num_interfaces > 1) {
		    // presample_correction is global, but can't be applied
		    // to all interfaces.
		    coral_diag(1, ("Cannot use presample correction with"
				    "more than one interface\n"));
		    exit(-1);
		}
		CORAL_TIMESTAMP_TO_TIMEVAL(iface, pkt_result.timestamp, &tv);
		coral_diag(1, ("%10d.%06d: presample %.9f\n",
		    tv.tv_sec, tv.tv_usec, prob));

	    } else {
		count_subif_stats(iface, &pkt_result);
		if (config.mem) {
		    static uint64_t n = 0;
		    if (n++ % 10000 == 0) {
			struct timespec ts;
			coral_read_clock_timespec(iface, pkt_result.timestamp, &ts);
#ifndef NDEBUG
			procstats.mem(&ts);
#endif
		    }
		}
	    }

	} else if (!pkt_result.packet && interval_result.stats) {
	    /* end of interval */
	    struct timeval tv1, tv2;
#ifndef NDEBUG
	    procstats("end int");
#endif
	    interval_data.end = timevaltodouble(&interval_result.end);
	    interval_data.pkt_stats = interval_result.stats;

	    gettimeofday(&tv1, NULL);

	    dump_data();
	    if (config.rotate_files)
		coral_rf_end(config.rf);
	    clear_data();
	    gettimeofday(&tv2, NULL);
	    timersub(&tv2, &tv1, &tv1);
	    coral_diag(3, ("crl_flowest: closed %f s interval in %d.%06d s\n",
		interval_data.end - interval_data.begin,
		tv1.tv_sec, tv1.tv_usec));

	    /* reset the interval time, and other timers */
	    interval_data.begin = 0;
	    interval_data.end = 0;
	    interval_data.pkt_stats = NULL;
	}
    }

    coral_rf_close(config.rf);
    coral_stop_all();

    /* clean up stuff */
    if (config.stats) dump_hash_stats();
#if 0
    clear_hash_table(subif_hash);
    srcip_tab.clear();
    dstip_tab.clear();
#endif

    return retval;
}
