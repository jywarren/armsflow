/*
 * $Id: crl_pkt_example.c,v 1.6.4.1 2007/07/02 19:35:25 kkeys Exp $
 */
/*
 * Example of program using libcoral packet API.
 * This code contains a lot of stuff you may not need in a simple program
 * in order to illustrate many of the possibilities of libcoral.
 */


static const char RCSid[]="$Id: crl_pkt_example.c,v 1.6.4.1 2007/07/02 19:35:25 kkeys Exp $";

/*#include "coral-config.h"*/

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <sys/time.h>
#include <sys/errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <signal.h>
#include <errno.h>
#include <netinet/in.h>		/* IPPROTO_*, etc. */
#include <netinet/in_systm.h>	/* needed for network header structures */
#include <netinet/ip.h>		/* struct ip */
#include <netinet/tcp.h>	/* struct tcphdr */
#include <netinet/udp.h>	/* struct udphdr */
#include <netinet/ip_icmp.h>	/* struct icmp */
#include <arpa/inet.h>		/* inet_addr(), etc. */
#include <netdb.h>		/* gethostbyname(), gethostbyaddr(), etc. */
#include <limits.h>		/* LONG_MAX, etc. */
#include <float.h>		/* DBL_MAX, etc. */

#include <assert.h>		/* assert() */

#include "coral-config.h"	/* WORDS_BIGENDIAN, needed by crl_byteorder.h */
#include "libcoral.h"
#include "crl_byteorder.h"	/* crl_ntohl64(), etc. */
/*#include "hashtab.h"*/

struct {
    uint8_t doubletime;		/* option -d: use double for timestamps */
    const char *outfilename;	/* option -o<name> */
} config;

coral_rotfile_t *rf;
FILE *outfile;

struct {
    uint64_t pkts;
    uint64_t ip;
    uint64_t ip_bytes;
    uint64_t udp;
    uint64_t tcp;
    uint64_t tcp_syn;
    uint64_t tcp_rst;
    double double_min_inter;
    struct timespec int_min_inter;
} stats;

int interrupted = 0;


static void count_pkt(coral_iface_t *iface, coral_pkt_result_t *pkt_result)
{
    coral_pkt_buffer_t netpkt;
    coral_pkt_buffer_t netpayload;
    struct ip *ip;
    short ip_fragment_offset;

    if (config.doubletime) {
	/* Example of using floating-point time.  The code is slightly
	 * simpler, but rounding error is introduced.
	 */
	double t, diff;
	static double last_t = 0;
	t = coral_read_clock_double(iface, pkt_result->timestamp);
	if (stats.pkts > 0) { /* this is not the first packet */
	    /* calculate interarrival time */
	    diff = t - last_t;
	    if (stats.pkts == 1 || diff < stats.double_min_inter)
		stats.double_min_inter = diff;
	}
	last_t = t; /* remember time for next iteration */

    } else {
	/* Example of using struct timespec.  The code is slightly more
	 * complex, but there's no rounding error.
	 */
	struct timespec t, diff;
	static struct timespec last_t = {0,0};
	coral_read_clock_timespec(iface, pkt_result->timestamp, &t);
	if (stats.pkts > 0) { /* this is not the first packet */
	    /* calculate interarrival time */
	    diff = t;
	    timespecsub(&diff, &last_t);
	    if (stats.pkts == 1 || timespeccmp(&diff, &stats.int_min_inter, <))
		stats.int_min_inter = diff;
	}
	last_t = t; /* remember time for next iteration */
    }

    /* count the packet */
    stats.pkts++;

    /* Find Network Layer (Layer 3) or give up */
    if (coral_get_payload_by_layer(pkt_result->packet, &netpkt, 3) < 0) {
	return;
    }

    /* If layer 3 is not IPv4, give up */
    if (netpkt.protocol != CORAL_NETPROTO_IPv4) {
	return;
    }

    /* count the ip packet */
    stats.ip++;
    ip = (struct ip*)netpkt.buf;
    stats.ip_bytes += ntohs(ip->ip_len);
    ip_fragment_offset = ntohs(ip->ip_off) & IP_OFFMASK;

    /* Now we use coral_get_payload() to get whatever is inside the IP packet,
     * no matter what "layer" it is.  If we had used coral_get_payload(..., 4),
     * and the IP packet contained IPIP which in turn contained TCP, it would
     * find the TCP packet, when what we really want is the second IP packet.
     */
    coral_get_payload(&netpkt, &netpayload);

    /* If this is not a fragment or is the first fragment, look at it.
     * (Non-first fragments do not have a next-level header.)
     */
    if (ip_fragment_offset == 0) {
        if (ip->ip_p == IPPROTO_TCP) {
	    struct tcphdr *tcp = (struct tcphdr*)netpayload.buf;
	    stats.tcp++;
	    /* If tcp flags were actually captured, look at them */
	    if (coral_field_fits(tcp, th_flags, netpayload.caplen)) {
		if (tcp->th_flags & TH_SYN) stats.tcp_syn++;
		if (tcp->th_flags & TH_RST) stats.tcp_rst++;
	    }

	} else if (ip->ip_p == IPPROTO_UDP) {
	    stats.udp++;
	}
    }
}

static void stop(int sig)
{
    /* Don't abort immediately because of a ^C; instead, set the interrupted
     * flag, and let the main loop shut down gracefully.
     */
    interrupted = 1;
}

/* open the an instance of the output file and write the header */
static int open_outfile(const char *name, const char *realname, void *info)
{
    FILE *file;
    if (coral_rf_cb_open_file(name, realname, info) < 0) return -1;
    file = *(FILE**)info;
    fprintf(file, "%17s %7s %7s %10s %7s %7s %5s %12s\n",
	"", "", "", "", "", "", "", "minimum");
    fprintf(file, "%17s %7s %7s %10s %7s %7s %5s %12s\n",
	"start", "pkts", "ip", "bytes", "tcp", "SYN", "RST", "interarrival");
    return 0;
}

int main(int argc, char *argv[])
{
    int retval = 0;
    coral_iface_t *iface;
    coral_pkt_result_t pkt_result;
    coral_interval_result_t interval_result;
    const struct timeval default_interval = { 300, 0 };
    struct timeval interval;
    long duration;
    int opt;
    int error = 0;

    /* Initialize default values of options */
    config.outfilename = "-"; /* Default to stdout */
    config.doubletime = 0; /* Default to timespec */

    coral_set_api(CORAL_API_PKT);
    coral_set_duration(0); /* allow -Cd option, and default to unlimited */
    coral_set_interval(&default_interval); /* allow -Ci, and set default */
    /*coral_set_max_sources(1);*/
    /*coral_set_iomode(0, CORAL_RX, 48, 0);*/

    /* To calculate interarrival times for packets from multiple interfaces,
     * the packets must be sorted. */
    coral_set_options(0, CORAL_OPT_SORT_TIME);

    /* handle command line options */
    while (!error && (opt = getopt(argc, argv, "C:do:")) != -1) {
	switch (opt) {
	case 'C':
	    /* standard coral option */
	    if (coral_config_command(optarg) < 0)
		error++;
	    break;
	case 'd':
	    config.doubletime = 1;
	    break;
	case 'o':
	    config.outfilename = strdup(optarg);
	    break;
	default:
	    error++;
	    break;
	}
    }

    if (error) {
	/* coral_usage() documents all the valid -C options in addition to
	 * printing the text we give here.
	 */
	coral_usage(argv[0], "[-d] [-o<file>] <source>...\n"
	    "-d         use double timestamps instead of timespec\n"
	    "-o<file>   specify the name of the output file (default: -)\n"
"<file> is the name of the output file, which may contain %% specifiers\n"
"    like strftime() for formatting a timestamp, plus:\n"
"        %%s   number of (whole) seconds since 1970-01-01 00:00:00 UTC\n"
"        %%f   fractional part of seconds (6 decimal places)\n"
"        %%F   equivalent to %%Y-%%m-%%d\n"
"    Except for %%f, all specifiers may contain printf-style modifiers\n"
"    (e.g., \"%%010s\").\n"
"    The filename '-' means standard output.\n"
	    );
	exit(-1);
    }

    /* initialize the <source>s from the command line */
    while (optind < argc) {
	if (!coral_new_source(argv[optind]))
	    exit(-1);
	optind++;
    }

    if (!coral_next_source(NULL)) {
	coral_diag(1, ("%s: warning: no sources specified.\n", argv[0]));
    }

    /* your initialization code here */

    /* open the sources */
    if (coral_open_all() <= 0)
	exit(-1);

    /* start the sources */
    if (coral_start_all() < 0)
	exit(-1);

    signal(SIGINT, stop);

    coral_get_interval(&interval);

    duration = coral_get_duration();
    if (duration)
	coral_diag(2, ("collection duration max set to %d second(s)\n", 
	   duration));

    /* initialize libcoral packet reader */
    coral_read_pkt_init(NULL, NULL, &interval);

    rf = coral_rf_open(&outfile, config.outfilename, NULL, CORAL_ROT_AUTO,
	open_outfile, coral_rf_cb_close_file);
    if (!rf)
	exit(1);

    while (1) {
	if (interrupted) {
	    /* We got an interrupt signal.  Don't break the loop; instead,
	     * shut down all sources cleanly, and continue looping until all
	     * sources indicate EOF.  (When a live source is shut down, it
	     * will continue to return any buffered packets, but will not read
	     * any new packets; tracefile sources will stop returning packets
	     * immediately.)  After coral_read_pkt() returns the last packet,
	     * it will return one last end-of-interval before returning EOF.
	     */
	    coral_stop_all();
	    interrupted = 0;
	}
	iface = coral_read_pkt(&pkt_result, &interval_result);

	if (!iface) {
	    if (errno == EINTR || errno == EAGAIN) continue;
	    retval = errno;
	    break;
	}

	if (pkt_result.packet) {
	    /* Got packet.  Count it. */
	    count_pkt(iface, &pkt_result);

	} else if (!interval_result.stats) {
	    /* Beginning of interval.  Clear stats. */
	    memset(&stats, 0, sizeof(stats));

	} else {
	    /* End of interval.  Print stats. */
	    fprintf(outfile, "%10ld.%06ld"
		" %7" PRIu64 " %7" PRIu64 " %10" PRIu64
		" %7" PRIu64 " %7" PRIu64 " %5" PRIu64,
		interval_result.begin.tv_sec, interval_result.begin.tv_usec,
		stats.pkts, stats.ip, stats.ip_bytes,
		stats.tcp, stats.tcp_syn, stats.tcp_rst);
	    if (stats.pkts < 2) {
		fprintf(outfile, " %12s\n", "-");
	    } else if (config.doubletime) {
		fprintf(outfile, " %12.9f\n", stats.double_min_inter);
	    } else {
		fprintf(outfile, " %2ld.%09ld\n",
		    stats.int_min_inter.tv_sec,
		    stats.int_min_inter.tv_nsec);
	    }
	}
    }

    coral_rf_close(rf); /* close the output file */
    coral_stop_all(); /* shut down input sources */

    return retval;
}
