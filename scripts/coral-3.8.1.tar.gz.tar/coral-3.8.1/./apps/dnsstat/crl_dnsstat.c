/* 
 * Copyright 2000, 2001, 2002, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 */

/*
 * $Id: crl_dnsstat.c,v 1.44 2007/06/08 18:08:17 kkeys Exp $
 */
/*
 * Keep statistics on DNS usage.
 */


static const char RCSid[]="$Id: crl_dnsstat.c,v 1.44 2007/06/08 18:08:17 kkeys Exp $";

#include "config.h"
#include <sys/param.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <sys/time.h>
#include <sys/errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <signal.h>
#include <errno.h>
#include <limits.h>

#include <netinet/in.h>
#include <netinet/in_systm.h>
#include <netinet/ip.h>
#include <arpa/inet.h>
#include <netdb.h>

#include "libcoral.h"
#include "crl_byteorder.h"
#include "hashtab.h"
#include "dns.h" /* ../../libsrc/libcoral */

#include "dnsstat.h"

config_t config;
col_id_t columns;
interval_data_t interval_data;

#define FLOW_HASH_TABLE_SIZE		229	/* XXX */
#define QUERY_HASH_TABLE_SIZE		97843	/* XXX */


static hash_tab *query_hash;
static hash_tab *flow_hash;
static int interrupted = 0, stopped = 0, overlimit = 0;
static flowstats_t overflow_flowrec;
static coral_rotfile_t *rf;
static FILE *outfile;

/* ---- hash table per flow fxns begin ---- */
/* -- per flow hash table fxns -- */

/* return 0 if the same - for use by the hashtable */
static int compare_flowstats(const void *entry1, const void *entry2)
{
    const flowstats_t *f1 = entry1;
    const flowstats_t *f2 = entry2;

    return (f1->ip_proto != f2->ip_proto ||
	    f1->src.s_addr != f2->src.s_addr ||
	    f1->dst.s_addr != f2->dst.s_addr);
}

/* make a hash of an entry - for use by the hashtable */
static unsigned long make_key_flowstats(const void *entry)
{
    const flowstats_t *f = entry;

    return (f->ip_proto << 16) + (f->src.s_addr * 59) + (f->dst.s_addr);
}

/* free mem of an entry - for use by the hashtable */
static void delete_flowstats(void *entry)
{
    if (!entry) return;
    free(entry);
}
/* -- end of flowstats_t hash table fxns -- */


/* ---- stuff that is per querystat hash table ---- */

/* return 0 if the same - for use by the hashtable */
static int compare_querystats(const void *entry1, const void *entry2)
{
    const querystats_t *q1 = entry1;
    const querystats_t *q2 = entry2;

    return (q1->flowstat != q2->flowstat ||
	    q1->opcode != q2->opcode ||
	    q1->truncated != q2->truncated ||
	    q1->qtype != q2->qtype ||
	    q1->qclass != q2->qclass);
}

/* make a hash of an entry - for use by the hashtable */
static unsigned long make_key_querystats(const void *entry)
{
    const querystats_t *q = entry;
    
    return ((unsigned)q->flowstat) +
	((q->opcode<<24) | (q->qclass<<16) | (q->qtype));
}

/* free mem of an entry - for use by the hashtable */
static void delete_querystats(void *entry)
{
    if (!entry) return;
    free(entry);
}
/* ---- hash table fxns end ---- */

/* NB: returns a pointer to static data */
static const char *hostname(const struct in_addr *addr)
{
    struct hostent *h;
    if (config.names &&
	(h = gethostbyaddr((const char*)addr, sizeof(struct in_addr), AF_INET)))
    {
	return h->h_name;
    } else {
	return inet_ntoa(*addr);
    }
}

static void init_flowrec(flowstats_t *flowrec, struct timespec *ts)
{
    flowrec->src.s_addr = 0;
    flowrec->dst.s_addr = 0;
    flowrec->ip_proto = 0;

    flowrec->qmessages = 0;
    flowrec->qqueries = 0;
    flowrec->rmessages = 0;
    flowrec->rqueries = 0;
    flowrec->recursion = 0;
    flowrec->multiqueries = 0;
    flowrec->zeroqueries = 0;
    flowrec->qdswapped = 0;
    /*flowrec->bytes = 0;*/
    flowrec->qL4_errs = 0;
    flowrec->qhtrunc = 0;
    flowrec->rL4_errs = 0;
    flowrec->rhtrunc = 0;
    flowrec->querylist = NULL;

    if (ts) {
	flowrec->first = *ts;
    } else {
	flowrec->first.tv_sec = 0;
	flowrec->first.tv_nsec = 0;
    }
    flowrec->latest = flowrec->first;
}

static void count_flowstats(coral_iface_t *iface,
    coral_pkt_result_t *pkt_result)
{
    flowstats_t *flowrec;
    flowstats_t fkey;
    coral_pkt_buffer_t L3pdu;	/* network layer datagram (IP) */
    coral_pkt_buffer_t L4pdu;	/* transport layer packet (TCP/UDP) */
    coral_pkt_buffer_t dnspdu;	/* DNS message */
    querystats_t qkey;
    querystats_t *queryrec;
    dnshdr_t *dnshdr;
    int i, offset, unusual = 0, swapped = 0;
    uint16_t qdcount;
    struct ip *ip;
    struct timespec ts;

    if (coral_get_payload_by_layer(pkt_result->packet, &L3pdu, 3) < 0) {
	/*interval_data.L2_err++;*/
	return;
    }
    ip = (struct ip*)L3pdu.buf;
    if (coral_get_payload(&L3pdu, &L4pdu) < 0) {
	/*interval_data.L3_err++;*/
	return;
    }
    if (coral_get_payload(&L4pdu, &dnspdu) < 0) {
	/*flowrec->L4_errs++;*/
	return;
    }
    if (dnspdu.protocol != CORAL_PROTO_DNS)  /* in case of no pcap filters */
	return;
    if (dnspdu.caplen < sizeof(dnshdr_t)) {
	/*flowrec->htrunc++;*/
	return;
    }

    /*flowrec->bytes += ntohs(ip->ip_len);*/
    /*interval_data.ipbytes += ntohs(ip->ip_len);*/

    dnshdr = (dnshdr_t*)dnspdu.buf;
    offset = sizeof(dnshdr_t);

    if (dnshdr->qr) {
	if (config.no_responses) return;
	fkey.dst.s_addr = config.nosrc ? 0 : ip->ip_src.s_addr & config.ip_mask.s_addr;
	fkey.src.s_addr = config.nodst ? 0 : ip->ip_dst.s_addr & config.ip_mask.s_addr;
    } else {
	if (config.no_requests) return;
	fkey.src.s_addr = config.nosrc ? 0 : ip->ip_src.s_addr & config.ip_mask.s_addr;
	fkey.dst.s_addr = config.nodst ? 0 : ip->ip_dst.s_addr & config.ip_mask.s_addr;
    }
    fkey.ip_proto = config.noproto ? 0 : ip->ip_p;

    CORAL_TIMESTAMP_TO_TIMESPEC(iface, pkt_result->timestamp, &ts);

    if ((flowrec = (flowstats_t*)find_hash_entry(flow_hash, &fkey))) {
	CORAL_TIMESTAMP_TO_TIMESPEC(iface, pkt_result->timestamp,
	    &flowrec->latest); /* XXX unneeded */
    } else if (overlimit) {
	flowrec = &overflow_flowrec;
    } else if (config.max_entries > 0 &&
	num_hash_entries(flow_hash) >= config.max_entries)
    {
	fprintf(stderr, "Found %ld entries.\n", num_hash_entries(flow_hash));
	fprintf(stderr, "Ignoring new entries for remainder of interval.\n");
	overlimit = 1;
	init_flowrec(&overflow_flowrec, &ts);
	flowrec = &overflow_flowrec;
    } else if ((flowrec = (flowstats_t*)malloc(sizeof(flowstats_t)))) {
	init_flowrec(flowrec, &ts);
	flowrec->src = fkey.src;
	flowrec->dst = fkey.dst;
	flowrec->ip_proto = fkey.ip_proto;
	CORAL_TIMESTAMP_TO_TIMESPEC(iface, pkt_result->timestamp,
	    &flowrec->latest); /* XXX unneeded */
	flowrec->first = ts;
        add_hash_entry(flow_hash, flowrec);
    } else {
	fprintf(stderr, "Can't malloc flowrec.\n");
	fprintf(stderr, "Ignoring new entries for remainder of interval.\n");
	overlimit = 1;
	init_flowrec(&overflow_flowrec, &ts);
	flowrec = &overflow_flowrec;
    }
    flowrec->latest = ts;

    qdcount = ntohs(dnshdr->qdcount);

    if (dnshdr->qr) {
	/* response */
	interval_data.rmessages++;
	flowrec->rmessages++;
	interval_data.rqueries += qdcount;
	flowrec->rqueries += qdcount;

    } else {
	/* request */
	if (qdcount != 1) {
	    if (!config.no_swap && qdcount > 100 && crl_swaps(qdcount) <= 100) {
		/* Assumption: no real message would have more than 100 queries.
		 * When UDP is being used, the 512 byte payload size limitation
		 * sets an upper bound of 100 queries.  And realistically, even
		 * that is ridiculously high.
		 */
		swapped = 1;
		flowrec->qdswapped++;
		qdcount = crl_swaps(qdcount);
		if (config.print_unusual)
		    fprintf(stderr, "message with byte-swapped QDCOUNT (%d)\n",
			qdcount);
	    }
	    if (qdcount == 0) {
		interval_data.zeroqueries++;
		flowrec->zeroqueries++;
		if (config.print_unusual)
		    fprintf(stderr, "message with %d queries\n", qdcount);
	    } else if (qdcount > 1) {
		interval_data.multiqueries++;
		flowrec->multiqueries++;
		if (config.print_unusual)
		    fprintf(stderr, "message with %d queries\n", qdcount);
	    }
	    unusual++;
	}

	interval_data.qmessages++;
	flowrec->qmessages++;
	interval_data.qqueries += qdcount;
	flowrec->qqueries += qdcount;
	if (dnshdr->rd) {
	    interval_data.recursion++;
	    flowrec->recursion++;
	}
    }

    if (config.notypes)
	goto end_count_flowstats;

    qkey.flowstat = flowrec;
    qkey.opcode = dnshdr->opcode;

    /* Header is followed by <qdcount> question sections.  A question section
     * contains an arbitrary length zero-terminated QNAME, a 2-octet QTYPE,
     * and a 2-octet QCLASS.  Note that the length of QNAME may be odd, so
     * QTYPE and QCLASS might not be short-aligned.
     */
    for (i = 0; i < qdcount; i++) {
	/* skip QNAME */
	while (dnspdu.buf[offset++] && offset < dnspdu.caplen);
	/* get QTYPE and QCLASS */
	if (offset + 2 * sizeof(short) > dnspdu.totlen) {
	    break;
	} else if (offset + 2 * sizeof(short) > dnspdu.caplen) {
	    qkey.truncated = 1;
	    qkey.qtype = 0;
	    qkey.qclass = 0;
	    i = qdcount; /* make this the last iteration */
	} else {
	    qkey.truncated = 0;
	    qkey.qtype = crl_nptohs(dnspdu.buf + offset);
	    offset += 2;
	    qkey.qclass = crl_nptohs(dnspdu.buf + offset);
	    offset += 2;
	}

	if (!qkey.truncated && config.print_unusual) {
	    if (qkey.qtype > T_ANY || !coral_dns_qtype_label(qkey.qtype)) {
		unusual++;
		fprintf(stderr, "query %d has qtype %d\n", i, qkey.qtype);
	    }
	    if (qkey.qclass > C_ANY || !coral_dns_qclass_label(qkey.qclass)) {
		unusual++;
		fprintf(stderr, "query %d has qclass %d\n", i, qkey.qclass);
	    }
	}

	if (overlimit)
	    continue;

	/* Read the current value out of the database. */
	if (!(queryrec = (querystats_t*)find_hash_entry(query_hash, &qkey))) {
	    queryrec = (querystats_t*)malloc(sizeof(querystats_t));
	    if (!queryrec) {
		fprintf(stderr, "can't malloc queryrec.\n");
		fprintf(stderr, "Ignoring new entries for remainder of interval.\n");
		overlimit = 1;
		continue;
	    }

	    queryrec->flowstat = qkey.flowstat;
	    queryrec->opcode = qkey.opcode;
	    queryrec->truncated = qkey.truncated;
	    queryrec->qtype = qkey.qtype;
	    queryrec->qclass = qkey.qclass;

	    queryrec->qqueries = 0;
	    queryrec->rqueries = 0;
	    queryrec->recursion = 0;
	    queryrec->qdswapped = 0;
	    /*queryrec->bytes = 0;*/
	    queryrec->next = flowrec->querylist;
	    flowrec->querylist = queryrec;
	    queryrec->first = flowrec->latest;
	    add_hash_entry(query_hash, queryrec);
	}
	if (dnshdr->qr) {
	    /* response */
	    queryrec->rqueries++;
	} else {
	    /* request */
	    queryrec->qqueries++;
	    if (dnshdr->rd)
		queryrec->recursion++;
	    if (swapped)
		queryrec->qdswapped++;
	}
	/*queryrec->bytes += ntohs(ip->ip_len);*/
	queryrec->latest = flowrec->latest;
    }

end_count_flowstats:
    if (config.print_unusual && unusual) {
	coral_fmprint_pkt(stderr, iface, pkt_result->timestamp, 3, 5,
	    pkt_result->packet, NULL, NULL);
    }
}
/* ---- per flow stuff ends ---- */

static void init_hashes(void)
{
    query_hash = init_hash_table("# hashes entries for each query type",
			       compare_querystats, make_key_querystats,
			       delete_querystats, QUERY_HASH_TABLE_SIZE);
    flow_hash = init_hash_table("# hashes entries for each flow",
			       compare_flowstats, make_key_flowstats,
			       delete_flowstats, FLOW_HASH_TABLE_SIZE);
}

static void dump_hash_stats(void)
{
    dump_hashtab_stats(query_hash);
    dump_hashtab_stats(flow_hash);
}

static void dump_header(FILE *file)
{
    columns = COL_ALL;
    if (config.nosrc) columns &= ~COL_SRC;
    if (config.nodst) columns &= ~COL_DST;
    if (config.noproto) columns &= ~COL_PROTO;
    if (config.notypes) columns &= ~(COL_OP | COL_TYPE | COL_CLASS);
    if (config.no_requests) columns &= ~COL_REQS;
    if (config.no_responses) columns &= ~COL_RESPS;
    /*if (!config->no_swap) columns &= ~COL_SWAP;*/

    if (config.binary_out) {
	dump_binary_config(file, columns);

    } else {
	fputs("# dnsstat output version: 0.5\n", file);
	fputs("# columns:\n", file);
	if (!config.nosrc)
	    fputs("#   src:  source (client) address\n", file);
	if (!config.nodst)
	    fputs("#   dst:  destination (server) address\n", file);
	if (!config.noproto)
	    fputs("#   pro:  IP protocol\n", file);
	if (!config.notypes) {
	    fputs("#   op:  DNS opcode\n", file);
	    fputs("#   type:  DNS query type\n", file);
	    fputs("#   class:  DNS query class\n", file);
	}
	fputs("#   req?s:  number of queries in requests (after correcting byte-swap)\n", file);
	fputs("#   reqs:  number of requests\n", file);
	fputs("#   resp?s:  number of queries in responses\n", file);
	fputs("#   resps:  number of responses\n", file);
	if (!config.no_rd)
	    fputs("#   rd:  number of requests with recursion desired\n", file);
	fputs("#   notes:  unusual characteristics:\n", file);
      /*fputs("#       qL4err=N    N msgs had errors in transport header\n", file);*/
      /*fputs("#       rL4err=N    N msgs had errors in transport header\n", file);*/
	fputs("#       qhtrunc=N   N requests were truncated in DNS header\n", file);
	fputs("#       rhtrunc=N   N responses were truncated in DNS header\n", file);
	if (!config.no_swap)
	    fputs("#       swap=N     N requests had byte-swapped QDCOUNT\n", file);
	fputs("#       mq=N       N requests had multiple queries (after correcting byte-swap)\n", file);
	fputs("#       zq=N       N requests had zero queries\n", file);
	if (!config.no_rd)
	    fputs("#       rd!=reqs   some (not all) request messages had RD\n", file);
	fputs("#\n", file);
	if (config.ip_mask.s_addr != 0xFFFFFFFFul)
	    fprintf(file, "# netmask: %s\n", inet_ntoa(config.ip_mask));
	if (config.no_swap)
	    fprintf(file, "# correction of byte-swapped QDCOUNT is disabled.\n");
	if (config.caplen)
	    fprintf(file, "# truncate: %d\n", config.caplen);
	fputs("\n", file);
    }
}

static void dump_interval(FILE *file, const interval_data_t *int_data)
{
    double begin, end, intduration;

    if (config.binary_out) {
	dump_binary_interval(file, &interval_data);
	return;
    }

    begin = timevaltodouble(&int_data->begin);
    end = timevaltodouble(&int_data->end);

    if (end && begin) {
	intduration = end - begin;
	fprintf(file, "# begin trace interval at %f, duration %f\n",
	    begin, intduration);
	if (!config.no_requests)
	    fprintf(file, "# DNS requests: %" PRIu64 " (%f/s); "
		"DNS request queries: %" PRIu64 " (%f/s)\n", 
		int_data->qmessages, int_data->qmessages / intduration,
		int_data->qqueries, int_data->qqueries / intduration);
	if (!config.no_responses)
	    fprintf(file, "# DNS responses: %" PRIu64 " (%f/s); "
		"DNS response queries: %" PRIu64 " (%f/s)\n", 
		int_data->rmessages, int_data->rmessages / intduration,
		int_data->rqueries, int_data->rqueries / intduration);

	fprintf(file, "\n#"); 
	if (!config.nosrc)
	    fprintf(file, config.names ? "%-27s " : "%-15s ", "src");
	if (!config.nodst)
	    fprintf(file, config.names ? "%-27s " : "%-15s ", "dst");
	if (!config.noproto)
	    fprintf(file, "%3s ", "pro");
	if (!config.notypes)
	    fprintf(file, "%3s %-5s %-5s ", "op", "type", "class");
	if (!config.no_requests)
	    fprintf(file, "%7s %7s ", "req?s", "reqs");
	if (!config.no_responses)
	    fprintf(file, "%7s %7s ", "resp?s", "resps");
	if (!config.no_rd)
	    fprintf(file, "%7s ", "rd");
	fprintf(file, "%s\n", "notes");
    } else {
	fprintf(file, "\n# no data processed during interval\n");
    }
}

static void dump_flowrec(FILE *file, const flowstats_t *flowrec)
{
    if (config.binary_out) {
	dump_binary_flowrec(file, flowrec);
	return;
    }

    fprintf(file, " "); 
    if (!config.nosrc)
	fprintf(file, config.names ? "%-27s " : "%-15s ", hostname(&flowrec->src));
    if (!config.nodst)
	fprintf(file, config.names ? "%-27s " : "%-15s ", hostname(&flowrec->dst));
    if (!config.noproto)
	fprintf(file, "%3d ", flowrec->ip_proto);
    if (!config.notypes)
	fprintf(file, "%3s %-5s %-5s ", "-", "-", "-");

    if (!config.no_requests)
	fprintf(file, "%7" PRIu64 /*" %15" PRIu64*/ " %7" PRIu64 " ",
	    flowrec->qqueries /*, queryrec->bytes */, flowrec->qmessages);
    if (!config.no_responses)
	fprintf(file, "%7" PRIu64 /*" %15" PRIu64*/ " %7" PRIu64 " ",
	    flowrec->rqueries /*, queryrec->bytes */, flowrec->rmessages);
    if (!config.no_rd)
	fprintf(file, "%7" PRIu64, flowrec->recursion);
    if (flowrec->qL4_errs > 0)
	fprintf(file, " qL4err=%" PRIu64, flowrec->qL4_errs);
    if (flowrec->rL4_errs > 0)
	fprintf(file, " rL4err=%" PRIu64, flowrec->rL4_errs);
    if (flowrec->qhtrunc > 0)
	fprintf(file, " qhtrunc=%" PRIu64, flowrec->qhtrunc);
    if (flowrec->rhtrunc > 0)
	fprintf(file, " rhtrunc=%" PRIu64, flowrec->rhtrunc);
    if (flowrec->qdswapped > 0)
	fprintf(file, " swap=%" PRIu64, flowrec->qdswapped);
    if (flowrec->multiqueries > 0)
	fprintf(file, " mq=%" PRIu64, flowrec->multiqueries);
    if (flowrec->zeroqueries > 0)
	fprintf(file, " zq=%" PRIu64, flowrec->zeroqueries);
    if (!config.no_rd && flowrec->recursion &&
	flowrec->recursion != flowrec->qmessages)
	    fprintf(file, " rd!=reqs");
    fprintf(file, "\n");
}

static void dump_queryrec(FILE *file, const querystats_t *queryrec)
{
    if (config.binary_out) {
	dump_binary_queryrec(file, queryrec);
	return;
    }

    fprintf(file, " "); 
    if (!config.nosrc)
	fprintf(file, config.names ? "%-27s " : "%-15s ",
	    config.human ? "\"" : hostname(&queryrec->flowstat->src));
    if (!config.nodst)
	fprintf(file, config.names ? "%-27s " : "%-15s ",
	    config.human ? "\"" : hostname(&queryrec->flowstat->dst));
    if (!config.noproto) {
	if (config.human)
	    fprintf(file, "%3s ", "\"");
	else
	    fprintf(file, "%3d ", queryrec->flowstat->ip_proto);
    }

    fprintf(file, "%3d ", queryrec->opcode);
    if (queryrec->truncated) {
	fprintf(file, "%-5s %-5s", "?", "?");
    } else {
	fprintf(file, "%-5s %-5s",
	    coral_dns_qtype_to_str(queryrec->qtype),
	    coral_dns_qclass_to_str(queryrec->qclass));
    }

    if (!config.no_requests)
	fprintf(file, " %7" PRIu64 " %7s", queryrec->qqueries, "-");
    if (!config.no_responses)
	fprintf(file, " %7" PRIu64 " %7s", queryrec->rqueries, "-");
    if (!config.no_rd)
	fprintf(file, " %7" PRIu64, queryrec->recursion);
    if (queryrec->qdswapped)
	fprintf(file, " swap=%" PRIu64, queryrec->qdswapped);

    fprintf(file, "\n");
}

static void dump_eoi(FILE *file, const interval_data_t *int_data)
{
    if (config.binary_out)
	dump_binary_eoi(file, int_data);
    else
	fprintf(file, "# end trace interval\n\n");
}

static void dump_data(void)
{
    const flowstats_t *flowrec;
    querystats_t *queryrec;

    dump_interval(outfile, &interval_data);

    init_hash_walk(flow_hash);

    while ((flowrec = next_hash_walk(flow_hash))) {
	dump_flowrec(outfile, flowrec);

	/* flowrec->querylist is empty if config.notypes */
	for (queryrec=flowrec->querylist; queryrec; queryrec=queryrec->next) {
	    /*if (!queryrec->messages) continue;*/
	    dump_queryrec(outfile, queryrec);
	}
    }
    if (overflow_flowrec.qmessages || overflow_flowrec.rmessages) {
	dump_flowrec(outfile, &overflow_flowrec);
	for (queryrec=overflow_flowrec.querylist; queryrec;
	    queryrec=queryrec->next)
	{
	    /*if (!queryrec->messages) continue;*/
	    dump_queryrec(outfile, queryrec);
	}
    }

    dump_eoi(outfile, &interval_data);
    fflush(outfile);
}

static void clear_data(void)
{
    /*interval_data.ipbytes = 0;*/
    /*interval_data.notIP = 0;*/
    interval_data.qmessages = 0;
    interval_data.rmessages = 0;
    interval_data.qqueries = 0;
    interval_data.rqueries = 0;
    interval_data.recursion = 0;
    interval_data.multiqueries = 0;
    interval_data.zeroqueries = 0;
    clear_hash_table(query_hash);
    clear_hash_table(flow_hash);
}

static void read_dnsstat_input(void)
{
    flowstats_t flowrec;
    querystats_t queryrec;
    rec_type_t type;
    dnsstat_file_t *df;
    int first_iteration = 1;

    if (!(df = open_dnsstat_file("-")))
	return;

    while (1) {
	type = read_dnsstat_record(df, &config, &interval_data,
	    &flowrec, &queryrec);

	switch(type) {
	case TYPE_COLUMNS:
	    break;

	case TYPE_INTERVAL:
	    if (first_iteration || config.rotating) {
		if (coral_rf_start(rf, &interval_data.begin) < 0)
		    return;
		dump_header(outfile);
		first_iteration = 0;
	    }
	    dump_interval(outfile, &interval_data);
	    break;

	case TYPE_EOI:
	    dump_eoi(outfile, &interval_data);
	    if (config.rotating)
		coral_rf_end(rf);
	    break;

	case TYPE_FLOW:
	    dump_flowrec(outfile, &flowrec);
	    break;

	case TYPE_QUERY:
	    queryrec.flowstat = &flowrec;
	    dump_queryrec(outfile, &queryrec);
	    break;

	case TYPE_EOF:
	case TYPE_ERR:
	    return;
	}
    }
}

static void stop(int sig)
{
    interrupted++;
}

int main(int argc, char *argv[])
{
    int retval = 0, coral_opt = 0;
    int len, opt;
    coral_iface_t *iface;
    coral_pkt_result_t pkt_result;
    coral_interval_result_t interval_result;
    struct timeval interval = { 300, 0 };
    unsigned int duration;
    const char *filter;
    int first_iteration = 1;

    coral_set_api(CORAL_API_PKT);
    coral_set_duration(0);
    coral_set_interval(&interval);
    coral_set_iomode(0, CORAL_RX, 14+20+8+512, 0);
    coral_set_options(0, CORAL_OPT_PARTIAL_PKT | CORAL_OPT_NORMALIZE_TIME);
    config.ip_mask.s_addr = 0xFFFFFFFFul;
    config.outfilename = "-";

    while ((opt = getopt(argc, argv, "C:O:o:p:asSDQPurcd:nhN:t:bi")) != -1) {
	switch (opt) {
	case 'C':
	    coral_opt++;
	    if (coral_config_command(optarg) < 0)
		exit(-1);
	    break;
	case 'O':
	    config.rotating = 1;
	    /* fall through */
	case 'o':
	    config.outfilename = strdup(optarg);
	    break;
	case 'a':
	    config.names = 1;
	    break;
	case 'p':
	    len = atoi(optarg);
	    if (len < 8 || len > 32) {
		fprintf(stderr, "cidr prefix must be between 8 and 32.\n");
		exit(-1);
	    }
	    config.ip_mask.s_addr = 0xFFFFFFFFul << (32 - len);
	    config.ip_mask.s_addr = htonl(config.ip_mask.s_addr);
	    break;
	case 'n':
	    config.nolabels = 1;
	    break;
	case 'S':
	    config.nosrc = 1;
	    break;
	case 'D':
	    config.nodst = 1;
	    break;
	case 'Q':
	    config.notypes = 1;
	    break;
	case 'P':
	    config.noproto = 1;
	    break;
	case 'r':
	    config.no_rd = 1;
	    break;
	case 'c':
	    config.no_swap = 1;
	    break;
	case 'd':
	    if (strcmp(optarg, "q") == 0) {
		config.no_requests = 0;
		config.no_responses = 1;
	    } else if (strcmp(optarg, "r") == 0) {
		config.no_requests = 1;
		config.no_responses = 0;
	    } else if (strcmp(optarg, "qr") == 0) {
		config.no_requests = 0;
		config.no_responses = 0;
	    } else {
		coral_diag(0, ("-d option requires 'q' or 'r' argument\n"));
		exit(1);
	    }
	    break;
	case 'u':
	    config.print_unusual = 1;
	    break;
	case 'h':
	    config.human = 1;
	    break;
	case 's':
	    config.hashstats = 1;
	    break;
	case 'b':
	    config.binary_out = 1;
	    break;
	case 'i':
	    config.dnsstat_in = 1;
	    break;
#if 1
	case 't':
	    config.caplen = atoi(optarg);
	    break;
#endif
	case 'N':
	    config.max_entries = atoi(optarg);
	    break;
	default:
	    coral_usage(argv[0], "[-p<len>] [-N<max>] [-anSDQhru] <source>...\n"
		"-o<file> write output to <file> (default: \"-\")\n"
		"-O<file> write output to <file>, and rotate every interval\n"
		"         <file> should contain one or more \"%%\" conversions:\n"
		"         \"%%i\" rotation counter\n"
		"         \"%%s\" seconds\n"
		"         \"%%f\" 6 digits of fractional seconds\n"
		"         or any \"%%\" conversions allowed by strftime().\n"
		"         Conversions may also contain modifiers allowed in %%s by printf.\n"
		"-p<len>  aggregate hosts by CIDR prefix length <len> (default: 32)\n"
		"-a       resolve IP addresses to hostnames (requires -p32)\n"
		"-n       print DNS code numbers, not symbols\n"
		"-S       ignore IP address of client (query Source)\n"
		"-D       ignore IP address of server (query Destination)\n"
		"-Q       don't count by query opcode/class/type\n"
		"-h       print in more human-friendly format\n"
		"-r       do not count msgs with RD set\n"
		"-c       do not correct byte-swapped QDCOUNT\n"
		"-dq      record requests only (default: requests and responses)\n"
		"-dr      record responses only (default: requests and responses)\n"
		"-b       write results in binary\n"
		"-i       read binary input from dnsstat -b on stdin\n"
		"-u       print contents of unusual msgs to stderr\n"
		"-N<max>  keep data for at most <max> src/dst/proto entries\n"
		"-s       print information on hash table usage\n"
		);
	    exit(-1);
	}
    }

    while (optind < argc) {
	if (!coral_new_source(argv[optind]))
	    exit(-1);
	optind++;
    }

    if (!(rf = coral_rf_open_file(&outfile, config.outfilename, NULL, 0)))
	return -1;

    if (config.dnsstat_in) {
	if (coral_opt || coral_next_source(NULL)) {
	    fprintf(stderr, "%s: -i can not be used with -C options or coral "
		"sources\n", argv[0]);
	    return -1;
	}
	read_dnsstat_input();
	return 0;
    }

    if (config.no_responses) {
	filter = "udp dst port 53";
    } else if (config.no_requests) {
	filter = "udp src port 53";
    } else {
	filter = "udp port 53";
    }
    if (coral_add_pcap_filter(filter) < 0) {
	coral_diag(1, ("warning: without pcap filters, performance will be "
	    "suboptimal.\n"));
    }

    init_hashes();
    config.noproto = 1;	/* Only UDP is supported, so there's no point */ 

    if (config.ip_mask.s_addr != 0xFFFFFFFF)
	config.names = 0;

    if (coral_open_all() <= 0)
	exit(-1);

    if (coral_start_all() < 0)
	exit(-1);

    signal(SIGINT, stop);

    coral_get_interval(&interval);
    interval_data.begin.tv_sec = 0;
    interval_data.begin.tv_usec = 0;
    interval_data.end.tv_sec = 0;
    interval_data.end.tv_usec = 0;

    duration = coral_get_duration();
    if (duration)
	coral_diag(2, ("collection duration max set to %d second(s)\n", 
		       duration));

    if (interval.tv_sec == 0 && interval.tv_usec == 0) {
	/* Set to "infinite" so read_pkt returns interval's beginning and end */
	interval.tv_sec = INT_MAX;
    }
    coral_read_pkt_init(NULL, NULL, &interval);

    while (1) {
	if (interrupted) {
	    if (!stopped) {
		coral_stop_all();
		stopped = 1;
	    }
	    if (interrupted > 1)
		break;
	}
	iface = coral_read_pkt(&pkt_result, &interval_result);

	if (!iface) {
	    if (errno == EINTR || errno == EAGAIN) continue;
	    retval = errno;
	    break;
	}

	if (!pkt_result.packet && !interval_result.stats) {
	    /* beginning of interval */
	    interval_data.begin = interval_result.begin;
	    init_flowrec(&overflow_flowrec, NULL);
	    overlimit = 0;

	    if (first_iteration || config.rotating) {
		if (coral_rf_start(rf, &interval_result.begin) < 0)
		    return -1;
		dump_header(outfile);
		first_iteration = 0;
	    }

	} else if (pkt_result.packet) {
	    /* got packet */
#if 1
	    if (config.caplen && pkt_result.packet->caplen > config.caplen)
		pkt_result.packet->caplen = config.caplen;
#endif
	    count_flowstats(iface, &pkt_result);

	} else if (!pkt_result.packet && interval_result.stats) {
	    /* end of interval */
	    interval_data.end = interval_result.end;

	    dump_data();
	    clear_data();

	    /* reset the interval time, and other timers */
	    interval_data.begin.tv_sec = 0;
	    interval_data.begin.tv_usec = 0;
	    interval_data.end.tv_sec = 0;
	    interval_data.end.tv_usec = 0;

	    if (config.rotating)
		coral_rf_end(rf);
	}
    }

    coral_stop_all();
    coral_rf_close(rf);

    /* clean up stuff */
    if (config.hashstats) dump_hash_stats();
/*    clear_data();*/
    return retval;
}
