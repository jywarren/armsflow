/* 
 * This is partially based on code written by Joel Apisdorf.
 */

/*
 * point_cpld.h - layout of cpld on apptel point622
 *
 * this file has registers for both the aim unit and the cpld
 * the aim is an abstraction to the physical interface.
 * and the cpld is a chip that is used to load images into the fpgas.
 *
 * $Id: point_cpld.h,v 1.6 1999/11/03 23:09:42 swbrown Exp $
 *
 */
#ifndef POINT_CPLD_H
#define POINT_CPLD_H

struct CpldControl1_register {
    u_short ProgramNot        : 1;	/* R/W */
    u_short Done              : 1;	/* R/O */
    u_short Reserved1         : 8;
    u_short ConfigErrorNot    : 1;	/* R/O */
    u_short Reserved2         : 5;
};

typedef struct {

#define S_UNI_155L  0
#define S_UNI_622   3
    struct {
	u_char DeviceType     : 4;
	u_char Reserved       : 4;
    } Module1;
    u_char pad0[3];


    enum AimLineInterface {
	MultiMode,
	SingleMode
    };
    struct {
	u_char RevisionAndCustomizationLevel      : 4;
	u_char LineInterfaceType                  : 4;
    } Module2;
    u_char pad1[3];
    

    enum AimClockSelect {
	InternalOscillator,
	ExternalTimingReference,
	InternalOscillatorAlias,
	ReceivedClock
    };
    enum AimClockMode {
	Forced,		/* always as specified by clock select */
	Revertive,	/* sel. clock until failure, then int., 
			 * go back when sel. comes back */
	NonRevertive	/* sel. clock until failure, then stay 
			 * with int. even if sel. comes back */
    };
    struct {
	u_char ClockSelect                    : 2;
	u_char ClockMode                      : 2;
	u_char InternalOscillatorIsActive     : 1;
	u_char Reserved                       : 3;
    } aim_Control1;
    u_char pad2[3];

    struct {
	u_char LostExternalClockTransition    : 1;    /* latched until read */
	u_char LostReceivedDataTransition     : 1;    /* latched until read */
	u_char Reserved1                      : 2;
	u_char LostExternalClock              : 1;
	u_char LostReceivedData               : 1;
	u_char Reserved2                      : 2;
    } Status1;
    u_char pad3[3];

    struct {
	/* when cleared, (power on and FPGA configured) drives active LED
	 * when set, software controls the active LED */
	u_char EnableActiveLedControl         : 1;

	/* set by software when active LED should be on
	 * ???never affected by hardware */
	u_char ActiveLedState                 : 1;

	/* when cleared, (FPGA not configured) drives fault LED
	 * when set, software controls the fault LED */
	u_char EnableFaultLedControl          : 1;

	/* set by software when fault LED should be on
	 * ???never affected by hardware */
	u_char FaultLedState                  : 1;

	/* when cleared, (LOS or LOF) drives active LED
	 * when set, software controls the active LE */
	u_char EnableLineLedControl           : 1;

	/* set by software when line LED should be on
	 * ???never affected by hardware */
	u_char LineLedState                   : 1;

	u_char Reserved                       : 2;
    } Control2;
    u_char pad4[3];
    
    /* note: since the *INT line from the AIM-622 is not wired
     * to anything on the POINT (PCI card), this register is
     * irrelevant to OC12MON */
    struct {
	u_char LostExternalClockTransition    : 1;
	u_char LostReceivedDataTransition     : 1;
	u_char Reserved                       : 6;
    } InterruptEnable;
    u_char pad5[3];


    enum AimOverhead0Selection {
	Sts3Number1,
	Sts3Number2,
	Sts3Number3,
	Sts3Number4,
    };
    struct {
	u_char Port0Select    : 2;
	u_char Reserved       : 6;
    } OverheadPortControl1;
    u_char pad6[3];


    enum AimOverhead2Or3Select {
	NoOverhead,
	SectionDDC,
	SectionOrderwire,
	SectionUserChannel,
	LineDDC,
	LineOrderwire,
	LineAutomaticProtectSwitching
    };
    struct {
	u_char Port2Select    : 4;
	u_char Port3Select    : 4;
    } OverheadPortControl2;
    u_char pad7[3];


    enum LoopbackSelection {
	NoLoopback,
	Equipment,	/* both world and me RX what I TX */
	Facility,	/* both world and me RX what world TX */
	Split		/* world RX what world TX, I RX what I TX */
    };
    struct {
	u_char Select     : 2;
	u_char Reserved   : 6;
    } LoopbackControl;
    u_char pad8[3];

    u_int Reserved1[ 15 ];

    struct {
	/* hold the XOR of address bits 9:2 for the previous
	 * passthru read or write that selected the RX FPGA */
	u_char Value              : 1;

	u_char Reserved           : 7;
    } AddressXor;
    u_char pad24[3];

    u_char Diagnostic;
    u_char pad25[3];

    u_int AimReserved2[ 230 ];

/* cpld regs */    
    struct CpldControl1_register cpld_Control1;
    u_char cpldpad0[2];

    u_int Reserved[254];
} cpld_regs;

#endif
