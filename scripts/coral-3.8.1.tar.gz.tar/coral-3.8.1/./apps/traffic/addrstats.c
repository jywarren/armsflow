/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 * $Id: addrstats.c,v 1.13 2007/06/06 18:17:33 kkeys Exp $
 */


static const char RCSid[]="$Id: addrstats.c,v 1.13 2007/06/06 18:17:33 kkeys Exp $";

#include "config.h"
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>

#include "hashtab/hashtab.h"

#include <netdb.h>
#include <netinet/in.h>
#include <netinet/in_systm.h>
#include <netinet/ip.h>
#include <arpa/inet.h>

extern u_int netmask;
extern u_char cnames;
extern u_char stats;

/* ---- stuff that is per (srcdst)hash table ---- */

typedef struct {
    struct in_addr src;
    struct in_addr dst;
    u_int pkts;
    u_int bytes;
} srcdst;

/* hash table fxns *
 ******************/

/* return 0 if the same - for use by the hashtable */
static int compare_srcdst(const void *entry1, const void *entry2)
{
    const srcdst *foo1 = entry1;
    const srcdst *foo2 = entry2;

    return (foo1->src.s_addr != foo2->src.s_addr ||
	    foo1->dst.s_addr != foo2->dst.s_addr);
}

/* make a hash of an entry - for use by the hashtable */
static unsigned long make_key_srcdst(const void *entry)
{
    const srcdst *what = entry;

    return (unsigned) what->src.s_addr * 37 + what->dst.s_addr;
}

/* free mem of an entry - for use by the hashtable */
static void delete_srcdst(void *entry)
{
    srcdst *what = entry;

    if (!what) return;

    free(what);
}
/* ---- hash table fxns end ---- */

hash_tab *new_srcdst_table(u_int ht_size, char *label)
{
    return init_hash_table(label, compare_srcdst, make_key_srcdst,
			   delete_srcdst, ht_size);
}

/* called for each cell.
 * ups the respective counters.
 * returns -1 on failure, 0 on success.
 */
int count_srcdst(hash_tab *ht, struct ip *ip)
{
    srcdst *rec;
    srcdst tmp;

    /* mask out what we're interested in. */
    tmp.src.s_addr = netmask & ip->ip_src.s_addr;
    tmp.dst.s_addr = netmask & ip->ip_dst.s_addr;

    if ((rec = find_hash_entry(ht, &tmp))) {
	rec->pkts++;
	rec->bytes += ntohs(ip->ip_len);
    } else {
	rec = (srcdst *)malloc(sizeof(srcdst));

	if (rec == NULL) {
	    fprintf(stderr, "can't malloc srcdst.\n");
	    return -1;
	}
	*rec = tmp;
	rec->pkts = 1;
	rec->bytes = ntohs(ip->ip_len);
	add_hash_entry(ht, rec);
    }

    return 0;
}

void dump_srcdst_table(hash_tab *ht)
{
    const srcdst *rec;
    struct hostent *h;

    init_hash_walk(ht);
    
    fprintf(stdout, "#%-20s %-20s %-9s %3.3s %-9s %3.3s\n", 
	    "src", "dst", "pkts", "f", "bytes", "f");

    while ((rec = next_hash_walk(ht))) {
	char tmpsrc[80];
	char tmpdst[80];

	if (cnames) {
	    h = gethostbyaddr((char*)&rec->src, 
			      sizeof(struct in_addr), AF_INET);
	    if (h)
		strcpy(tmpsrc, h->h_name);
	    else
		strcpy(tmpsrc, inet_ntoa(rec->src));

	    h = gethostbyaddr((char*)&rec->dst, 
			      sizeof(struct in_addr), AF_INET);
	    if (h)
		strcpy(tmpdst, h->h_name);
	    else
		strcpy(tmpdst, inet_ntoa(rec->dst));
	} else {
	    strcpy(tmpsrc, inet_ntoa(rec->src));
	    strcpy(tmpdst, inet_ntoa(rec->dst));
	}
	
	fprintf(stdout, " %-20.20s %-20.20s %-9d %.1f %-9d %.1f\n", 
		tmpsrc, tmpdst, rec->pkts, (double)0, rec->bytes, (double)0);
    }

    fflush(stdout);
}
