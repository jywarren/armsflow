package CAIDA::UserGuide::UserGuideElements;
require 5.004;
## $Id: UserGuideElements.pm,v 1.10 2007/06/06 18:17:52 kkeys Exp $ $Name: release-3-8-1 $
## -----------------------------------------------------------------------
## Perl module: UserGuideElements.pm
## 
## This Perl module (Traffic Human Computer Interface) provides a
## consistent framework displaying help and diagnostic messages from
## the CoralReef report generator.  It's may role as a module is
## partition code that doesn't belong in either main script or any
## other module and to standardize the format of help information.
## 
## Note: test routines require the Test.pm module or Perl 5.005
##
## Copyright 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
## All Rights Reserved 
##
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
##
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
##
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
##
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
##
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program. Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
##
## Contact: coral-info@caida.org
## ---------------------------------------------------------------------

# Set up object export condition.  No functions accessible directly.
use Exporter ();
@ISA       = qw(Exporter);
@EXPORT    = qw();
@EXPORT_OK = qw();

# Define required CVS variables
$cvs_Id = '$Id: UserGuideElements.pm,v 1.10 2007/06/06 18:17:52 kkeys Exp $';
$cvs_Author = '$Author: kkeys $';
$cvs_Name = '$Name: release-3-8-1 $';
$cvs_Revision = '$Revision: 1.10 $';

# Enable error messages to come from calling script
use Carp;

# Force this module to adhere to safe programming practices.
use strict;
use Text::Wrap;

# argument count types
use constant SHORTCUT   => 0;
use constant DESCRIPTION  => 1;
use constant NOTES  => 2;


# Version of module
my $VERSION = 1.0;

# .   .   .   .   .  Internal object functions  .   .   .   .   .   .   .  

sub _initialize($ ) {
# -----------------------------------------------
# Perform initialization for new object.  Create
# reference to the array of items that will be 
# stored to provide help for the user.
# -----------------------------------------------
    my $HCI_object = shift;

    # Create entry.
    $HCI_object->{'HCI_data'} = {};
    
    # Return object reference
    return($HCI_object);
}

sub _entry_help_print($$$$$ ) {
# -----------------------------------------------
# Internal method to print help information in a
# fixed format.  This is the ONLY place there 
# actual formatting information is stored.  
# Don't try to change the formatting elsewhere!
# -----------------------------------------------
    my $HCI_object = shift;

    my $argument = shift;
    my $shortcut = shift;
    my $description = shift;
    my $notes = shift;

    $HCI_object->_row_help_print(join('','--',$argument), 
				 join('','(-',$shortcut,')'),
				 $description, $notes);
}

sub _row_divider_print($ ) {
# -----------------------------------------------
# Method to print a row dashes to separate header
# from command line arguments
# -----------------------------------------------
    my $HCI_object = shift;

    $HCI_object->_row_help_print('-'x13, '-'x4, '-'x40,'');
}


sub _row_help_print($$$$$ ) {
# -----------------------------------------------
# Internal method to lay out data in appropriate
# spacings.  Can be used for either the column
# headers or an actual data entry.
# -----------------------------------------------
    my $HCI_object = shift;

    my $argument = shift;
    my $shortcut = shift;
    my $description = shift;
    my $notes = shift;

    print STDERR wrap('', ' 'x24, 
		      sprintf("%s%13s %4s %s", ' 'x4, $argument,
			      $shortcut),
		      $description), "\n";
}

# .   .   .   .   .  User Method Subroutines  .   .   .   .   .   .   .   .  

sub new($ ) {
# -----------------------------------------------
# Create new object.  All objects work on arrays
# of four element lists.
# -----------------------------------------------
    # retrieve parameters
    my $class_name = shift;
    
    # allocate space for object and bless it.
    my	$HCI_object = {};
    bless $HCI_object, $class_name;

    $HCI_object->_initialize();
    
    # Return object reference
    return($HCI_object);
}

sub format_help_entry ($$ ) {
# ----------------------------------------------
# This method outputs a single entry in "open"
# text.  This style of output is approprate for
# help from the command line.
# ----------------------------------------------
    my $HCI_object = shift;
    my $argument = shift;

    my $entry = $HCI_object->{'HCI_data'}->{$argument};

    $HCI_object->_entry_help_print($argument, 
			      $entry->[SHORTCUT],
			      $entry->[DESCRIPTION],
			      $entry->[NOTES]
			     );

}

sub format_help_text($$ ) {
# ---------------------------------------------
# This method outputs arbitrary text in a 
# format consistent with the displaying of 
# particular help items.
# ---------------------------------------------
    my $HCI_object = shift;
    my $text = shift;

    print STDERR wrap(' 'x4, ' 'x11, $text), "\n";
}

# =============================
# POD Documentation for Module

__END__

=head1 NAME

UserGuideElements.pm - Base class providing uniform user information
	
=head1 DESCRIPTION

UserGuideElements.pm is the base class for the UserGuide system.  It
should not be used on its own unless a complete rewrite of the modules
is contemplated.  Instead overload the methods through UserGuide.pm.
See UserGuide.pm for more information.

=head1 AUTHOR

CoralReef Development team, CAIDA Group <coral-info@caida.org>

=head1 COPYRIGHT

Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
All Rights Reserved 

Permission to use, copy, modify and distribute any part of this
CoralReef software package for educational, research and non-profit
purposes, without fee, and without a written agreement is hereby
granted, provided that the above copyright notice, this paragraph
and the following paragraphs appear in all copies.

Those desiring to incorporate this into commercial products or use
for commercial purposes should contact the Technology Transfer
Office, University of California, San Diego, 9500 Gilman Drive, La
Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.

IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
THE POSSIBILITY OF SUCH DAMAGE.

THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
ANY PATENT, TRADEMARK OR OTHER RIGHTS.

The CoralReef software package is developed by the CoralReef
development team at the University of California, San Diego under
the Cooperative Association for Internet Data Analysis (CAIDA)
Program. Support for this effort is provided by the CAIDA grant
NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
N66001-01-1-8909, and by CAIDA members.

Report bugs and suggestions to coral-bugs@caida.org.

=cut

# .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   . 
1; ##must be last line in the file
