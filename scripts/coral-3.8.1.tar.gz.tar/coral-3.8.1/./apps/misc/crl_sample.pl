#! /usr/local/bin/perl -w
## 
## Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
## All Rights Reserved 
## 
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
## 
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
## 
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
## 
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
## 
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program. Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
## 
## Report bugs and suggestions to coral-bugs@caida.org.
## 

## $Id: crl_sample.pl,v 1.34 2007/06/06 18:17:30 kkeys Exp $
## $Author: kkeys $
## $Name: release-3-8-1 $
## $Revision: 1.34 $

use strict;			# require variable declaration
my $coral_dir;
BEGIN { $coral_dir = "/usr/local/Coral"; } # This will be edited during build.
use lib "$coral_dir/lib"; #coral global libdir#
use lib "../../lib"; #coral local libdir#
use CRL;

# basic coral header and cell variables
use vars qw($interface $blk_count $cell_count $cflag $header_info_ref);

# ip specific variables set in handle_ip
use vars qw($ip_v_hl $ip_tos $ip_len
	    $ip_id $ip_off
	    $ip_ttl $ip_p $ip_sum
	    $ip_src
	    $ip_dst);
use vars qw($ip_v $ip_hl $ip_df $ip_mf $ip_offset $ip_payload $ip_frag $ihl);

# tcp specific variables set in handle_tcp
use vars qw($th_sport $th_dport
	    $th_seq 
	    $th_ack
	    $th_off_x2 $th_flags $th_win
	    $th_sum $th_urp);
use vars qw($th_off $th_x2 $fin $syn $rst $psh $ack $urg);

# udp specific variables set in handle_udp
use vars qw($uh_sport $uh_dport
	    $uh_ulen $uh_sum);

# encapsulation variables set in main loop
use vars qw($llc_dsap $llc_ssap $llc_cntl $snap_org $snap_type);

# cell information set in main loop
use vars qw($timestamp $fifo);

# Unpack objects
use vars qw($ip_unpk $tcp_unpk $udp_unpk $llcsnap_unpk);

# tcp/ip/protocol counter vars
use vars qw($ip_count $ip_bytes $tcp_count $tcp_bytes $ack_count $psh_count);
use vars qw(%proto_count %proto_bytes);

##===========================================================================


##===========================================================================

# Stevens vol 2 page 211.
# this function splits up IP datagram according to its layout in the structure.
# ihl is the actual header length (ip_hl * 4).  ip_dt, ip_mf, and ip_offset
# are subfields within ip_off.

sub handle_ip {
    my ($record_ip) = @_;
    
    ($ihl, $ip_v, $ip_hl, $ip_tos, $ip_len, $ip_id, $ip_off, $ip_ttl,
     $ip_p, $ip_sum, $ip_src, $ip_dst, $ip_df, $ip_mf, $ip_offset,
     $ip_frag) = $ip_unpk->unpack($record_ip);
    
    # payload is pointing to whatever it is that we have after 
    # the IP headers+options
    $ip_payload = substr($record_ip, $ihl);
    
    ## ******
    ## PUT CODE HERE THAT NEEDS TO RUN ON ALL IP PACKETS
    ## ******
    $ip_count++;
    $ip_bytes += $ip_len;
    $proto_count{$ip_p}++;
    $proto_bytes{$ip_p} += $ip_len;

    ## if tcp packet call tcp routine if udp call udp routine
    
    if ($ip_offset == 0) {
	if ($ip_p == 6) { handle_tcp ($ip_payload); }
	if ($ip_p == 17) { handle_udp ($ip_payload); }
    }
}


##===========================================================================
## This routine uses the settings of the $llc_* and $snap_* variables from
## the main loop.
##===========================================================================

sub handle_non_ip {
    my ($buffer) = @_;
    
    ## ******
    ## PUT CODE HERE THAT NEEDS TO RUN ON ALL NON-IP PACKETS
    ## ******
    
    ## For example:
    if ($buffer->protocol == $Coral::NETPROTO_ARP) {
	# ARP-specific routines.
    }
}



##===========================================================================
#page 801 stevens vol. 2
# fin, syn, rst, psh, ack and urg are flags in th_flags
##===========================================================================
sub handle_tcp {
    my ($record_tcp) = @_;

    # For this example, all fields are being extracted, although this is
    # usually unnecessary (and wasteful).
    ($th_sport, $th_dport, $th_seq, $th_ack, $th_off, $th_x2, $th_flags,
     $th_win, $th_sum, $th_urp, $th_off, $fin, $syn, $rst, $psh, $ack,
     $urg) = $tcp_unpk->unpack($record_tcp);
    
    ## ******
    ## This is where you would put code that needs to run on all udp packets
    ## ******
    
    # These are very simple counters put in to demonstrate field analysis
    $tcp_count++;
    $tcp_bytes += $ip_len;
    # if the header has been truncated, unpack_tcp (and all unpack_* functions
    # will return undef for inaccessible variables/flags
    if (defined $ack and $ack != 0) { $ack_count++; }
    if (defined $psh and $psh != 0) { $psh_count++; }
}


##===========================================================================
sub handle_udp {
    my ($record_udp) = @_;

    ($uh_sport, $uh_dport, $uh_ulen, $uh_sum) =
	$udp_unpk->unpack($record_udp);

    ## ******
    ## This is where you would put code that needs to run on all udp packets
    ## ******
}


##===========================================================================

$ip_unpk = new Unpacker("ip", ["ihl", "ip_v", "ip_hl", "ip_tos",
			       "ip_len", "ip_id", "ip_off", "ip_ttl",
			       "ip_p", "ip_sum", "ip_src", "ip_dst",
			       "ip_df", "ip_mf", "ip_offset", "ip_frag"]);
$tcp_unpk = new Unpacker("tcp", ["th_sport", "th_dport", "th_seq", "th_ack",
				 "th_off", "th_x2", "th_flags", "th_win",
				 "th_sum", "th_urp", "th_off",
				 "fin", "syn", "rst", "psh", "ack", "urg"]);
$udp_unpk = new Unpacker("udp", ["uh_sport", "uh_dport", "uh_ulen",
				 "uh_sum"]);
$llcsnap_unpk = new Unpacker("llcsnap", ["llc_dsap", "llc_ssap", "llc_cntl",
					 "snap_org", "snap_type"]);

my @interval = ( 0, 0 );
Coral::set_interval(\@interval);    # enable "-Cinterval" command line option

Coral::quick_start(0);
@interval = Coral::get_interval();
shift @interval;
Coral::read_pkt_init(undef, undef, \@interval);

my $packet = new Coral::Pkt_result;
my $interval_result = new Coral::Interval_result;
my $iface;

while (defined($iface = Coral::read_pkt($packet, $interval_result))) {
    if (not defined $packet->packet) {
	my $stats = $interval_result->stats;
	if (defined $stats) {
	    print "Interval ended at ";
	    my ($sec, $usec) = $interval_result->end;
	    printf "%d.%.6d\n", $sec, $usec;
	    print "Stats:\n";
	    print "Layer2 PDUs received: ", $stats->l2_recv, "\n";
	    print "Layer2 PDUs dropped: ", $stats->l2_drop, "\n";
	    print "Packets received: ", $stats->pkts_recv, "\n";
	    print "Packets dropped: ", $stats->pkts_drop, "\n";
	    print "Packets truncated: ", $stats->truncated, "\n";
	    print "Driver corrupt errors: ", $stats->driver_corrupt, "\n";
	    print "Too many vpvc errors: ", $stats->too_many_vpvc, "\n";
	    print "Buffer overflows: ", $stats->buffer_overflow, "\n";
	    print "AAL5 trailer errors: ", $stats->aal5_trailer, "\n";
	    print "Good packets: ", $stats->ok_packet, "\n";
	} else {
	    print "Interval starting at ";
	    my ($sec, $usec) = $interval_result->begin;
	    printf "%d.%.6d\n", $sec, $usec;
	}
	next;

    } else {
	$interface = Coral::interface_get_number($iface);
	my $payload = $packet->packet->buf;
	    
	# For example purposes, all fields are being extracted from llc/snap
	# header, but are not used.
	if ($packet->packet->protocol == $Coral::DLT_ATM_RFC1483) {
	    ($llc_dsap, $llc_ssap, $llc_cntl, $snap_org, $snap_type) = 
		$llcsnap_unpk->unpack($payload);
	}

	my $ip_record = Coral::get_ip($iface, $packet->packet);
	#This is equivalent to the following code, assuming the packet API:
	#my $ip_buffer = new Coral::Pkt_buffer;
	#my $error = Coral::get_payload_by_proto($packet->packet, $ip_buffer,
	#						$Coral::NETPROTO_IP);
	#if ($error) {
	#	$ip_record = undef;
	#} else {
	#	$ip_record = $ip_buffer->buf;
	#	($ihl, $ip_v) = $ip_unpk->unpack($ip_record);
	#	if ($ip_v != 4) {
	#	    $ip_record = undef;
	#	}
	#}
	
	#This is skipping over the coral timestamps and ATM headers
	#which are in the first 5 words of what we capture
	#hence we start reading 20 bytes into the data and pass it
	#to the functions that deal with ip or else.
	
	if ($ip_record) {
	    handle_ip($ip_record);
	} else {
	    my $non_ip_buffer = new Coral::Pkt_buffer;
	    Coral::get_payload_by_layer($packet->packet, $non_ip_buffer, 3);
	    handle_non_ip($non_ip_buffer);
	}
    }
}

# Here we spit out the results of our (very simple) analysis.
print "number of IP packets: $ip_count\n";
print "number of IP bytes: $ip_bytes\n";
print "number of TCP packets: $tcp_count\n";
print "number of TCP bytes: $tcp_bytes\n";
print "number of TCP acks: $ack_count\n";
print "number of TCP push: $psh_count\n";
foreach my $proto (sort {$a <=> $b} keys %proto_count) {
    print "packets of protocol $proto: $proto_count{$proto}\n";
}
foreach my $proto (sort {$a <=> $b} keys %proto_bytes) {
    print "bytes for protocol $proto:  $proto_bytes{$proto}\n";
}

