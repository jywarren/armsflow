/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 * point_pci.c - pci bookkeeping for applied telecom point 622
 *               card
 *
 * $Id: point_pci.c,v 1.45 2007/06/06 18:17:42 kkeys Exp $
 *
 */


#include <sys/param.h>
#include <sys/systm.h>
#include <sys/kernel.h>
#include <sys/conf.h>
#include <vm/vm.h>
#include <vm/pmap.h>
#include <vm/vm_extern.h>
#include <sys/syslog.h>

#include <pci/pcivar.h>
#include <pci/pcireg.h>
#include <pci/point.h>
#include <pci/coral_common.h>

static void point_pci_attach(pcici_t config_id, int unit);
static pci_probe_return_t point_pci_probe(pcici_t config_id,pcidi_t device_id);
static void point_pci_shutdown(void *q);

#define AMCC_BASE_ADDR_REG            0 /* l m */
#define FPGA_BASE_ADDR_REG            1 /* l m */
#define SLAVE_BURST_BASE_ADDR_REG     2 /* l  */
#define SUNI_BASE_ADDR_REG            3 /* l m */
#define AIM_AND_CPLD_BASE_ADDR_REG    4 /* l m */

#define REG_INDEX_TO_OFFSET(i) ((i*4)+0x10)

/* config stuff, should do elsewhere */
#ifndef MODULE
/* #define MODSTUB */			/* if you're doing a loadable module */
#endif

#ifndef MODULE
point_622_atm points[NPOINT];
#endif

static u_long point_pci_count;

struct pci_device MODUNIQ(pointdevice) = {
    "point",
    point_pci_probe,
    point_pci_attach,
    &point_pci_count,
    (void *)point_pci_shutdown,
};

static struct {
    u_char revid;
    pci_probe_return_t description;
    u_int bitrate;
} rev_info[] = {
    { 0x11, "Applied Telecom POINT-622, V3.2 CPLD",	KBPS_OC12c },
    { 0x20, "Applied Telecom POINT-622, V4.0 CPLD",	KBPS_OC12c },
    { 0x21, "Applied Telecom POINT-622, V4.4 CPLD",	KBPS_OC12c },
    { 0x22, "Applied Telecom POINT-622, V4.5 CPLD",	KBPS_OC12c },
    { 0x81, "Applied Telecom POINT-155X, V4.4 CPLD",	KBPS_OC3c },
    { 0x82, "Applied Telecom POINT-155X, V4.5 CPLD",	KBPS_OC3c },
    { 0,    NULL,					0 }
};

/* here is a little bit of cleverness.  we never want anyone to
 * interrupt us when we are in point_interrupt()  no matter what.
 * nothing is more important than our data.
 * so this is our private little interrupt mask.  we register
 * point_interrupt with it so that it is installed whenever we're
 * running.  it should mask everything except other point interrupts.
 * XXX how can we add other hardware interrupts to it without
 *  masking ourselves?
 */

#if __FreeBSD_version < 300000
static unsigned point_imask = SWI_MASK;
#endif

static void point_pci_attach(pcici_t config_id, int unit)
{
    vm_offset_t pa_csrs;
    point_622_atm *p;
    u_int retval;
    int i;
    struct block *block;
    unsigned char revid;
    
#ifdef CORAL_DEBUG
    printf("point%d: point_pci_attach\n", unit);
#endif

    if (unit >= NPOINT || unit < 0) {
	printf("this kernel only has support for %d POINT cards (%d)\n",
		 NPOINT, unit);
	return;
    }

    p = &points[unit];

    /* Initialize the buffer. */
    block_pool_initialize(&p->block_pool);

    /* maybe check the old values of these here? */
    p->config_id = config_id;

    /* Save if it's an OC12 or OC3 card by checking the PCI revision id. */
    revid=pci_conf_read(config_id, PCI_CLASS_REG) & 0xff;
    for (i = 0; rev_info[i].revid && rev_info[i].revid != revid; i++);
    p->bitrate = rev_info[i].bitrate;


    if (!(retval = pci_map_mem(config_id,
			       REG_INDEX_TO_OFFSET(AMCC_BASE_ADDR_REG),
			       (vm_offset_t *)&p->amcc, &pa_csrs))) {
	printf("point (amcc) pci memory map failed: %d\n", retval);
	return;
    }
    if (!(retval = pci_map_mem(config_id,
			       REG_INDEX_TO_OFFSET(FPGA_BASE_ADDR_REG),
			       (vm_offset_t *)&p->fpga, &pa_csrs))) {
	printf("point (fpga) pci memory map failed: %d\n", retval);
	return;
    }
    if (!(retval = pci_map_mem(config_id,
			       REG_INDEX_TO_OFFSET(SUNI_BASE_ADDR_REG),
			       (vm_offset_t *)&p->suni, &pa_csrs))) {
	printf("point (suni) pci memory map failed: %d\n", retval);
	return;
    }
    if (!(retval = pci_map_mem(config_id,
			       REG_INDEX_TO_OFFSET(AIM_AND_CPLD_BASE_ADDR_REG),
			       (vm_offset_t *)&p->cpld, &pa_csrs))) {
	printf("point (cpld) pci memory map failed: %d\n", retval);
	return;
    }

    if (!pci_map_int(config_id, (void *)MODUNIQ(point_interrupt), (void*)p,
#if __FreeBSD_version < 300000
		     &point_imask
#else
		     &tty_imask
#endif
	)) {
	printf("point %d: couldn't map interrupt\n", unit);
	return;
    }

    /* Allocate space for the blocks and the headers. */
    if (!p->buffer) {
	p->buffer = (void *) vm_page_alloc_contig(POINT_CELLBUF_SIZE,
						  0,
						  0xffffffff,
						  PAGE_SIZE);
    
	/* Record each raw block as an available free block. */
	for(i=0; i < POINT_NUM_BLKS; i++) {
	
	    /* Create the new block to hold the raw block. */
	    block=block_create(BLK_IDX_TO_ADR(i, p->buffer, POINT_BLK_SIZE, POINT_NUM_BLKS), BLK_IDX_TO_INFO(i, p->buffer, POINT_BLK_SIZE, POINT_NUM_BLKS), i);
	
	    /* Register this block as being free. */
	    block_pool_free_set(&p->block_pool, block);
	}
    
#ifdef CORAL_DEBUG
	printf("point%d: allocated %ld bytes at 0x%x\n", unit,
		p->buffer ? (long)POINT_CELLBUF_SIZE : 0, 
		(int)p->buffer);
#endif
    } else {
	printf("point%d: already have p->buffer at %p\n", unit,
	       p->buffer);
    }

    MODUNIQ(point_attach)(p, unit);
}


static void point_pci_shutdown(void *q)
{
    log(LOG_DEBUG, "point: point_pci_shutdown called\n");

    /* unregister our interrupt handler */
/*    pci_unmap_int(p->config_id);*/

}


static pci_probe_return_t point_pci_probe(pcici_t config_id, pcidi_t device_id)
{
    unsigned char revid;
    int i;
    
    /* If it's not an Apptel card we know, we don't need to do anything else. */
    if ((device_id & 0xffff) != APPTEL_VENDOR_ID) {
	return(NULL);
    }
    else if (((device_id >> 16) & 0xffff) != APPTEL_PCI_622_DEVICE_ID) {
	return(NULL);
    }

    /* Check if it's an OC12 or OC3 card by checking the PCI revision id. */
    revid=pci_conf_read(config_id, PCI_CLASS_REG) & 0xff;
    for (i = 0; rev_info[i].revid && rev_info[i].revid != revid; i++);
    return rev_info[i].description;
}

#if __FreeBSD_version < 400000
DATA_SET (pcidevice_set, MODUNIQ(pointdevice));
#else
COMPAT_PCI_DRIVER (points, MODUNIQ(pointdevice));
#endif

