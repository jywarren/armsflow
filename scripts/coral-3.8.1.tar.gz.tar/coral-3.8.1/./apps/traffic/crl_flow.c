/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 * $Id: crl_flow.c,v 1.68.4.1 2007/07/27 19:58:17 kkeys Exp $
 */
/*
 * traffic counts.  this came from netnet and is striving
 * to be something like (and more than) crl_portsummary.
 */


static const char RCSid[]="$Id: crl_flow.c,v 1.68.4.1 2007/07/27 19:58:17 kkeys Exp $";

#include "config.h"
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <sys/time.h>
#include <sys/errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <signal.h>
#include <errno.h>
#include <math.h>   /* modf() */

#include <netinet/in.h>
#include <netinet/in_systm.h>	/* needed for network header structures */
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <netinet/ip_icmp.h>
#include <arpa/inet.h>
#include <netdb.h>

#include <assert.h>

#include "libcoral.h"
#include "crl_byteorder.h"
#include "hashtab.h"

#define OUTPUT_VERSION "1.1"

#define FLAG_FIRST_LATEST   0x01
#define FLAG_PORTS_OK	    0x02

#if !PATH_MAX
# define PATH_MAX 1024
#endif

/* Solaris crap */
#ifndef IP_OFFMASK
#define IP_OFFMASK 0x1FFF
#endif

#define ALG_NONE	'\0'	/* default */
#define ALG_FIXED	'f'
#define ALG_MULT	'm'
/* TODO: NetFlow-like expiry on TCP FIN */

#define ACCUM_INTERVAL 001
#define ACCUM_LIFETIME 002

/* Don't print flows that had no traffic (during interval) */
#define printable_flow(flowrec) (config.include_zero || flowrec->pkts)

struct {
    u_int netmask;
    u_char cnames;
    u_char stats;
    u_char binary;
    u_char pretty;  /* non-pretty isn't needed if apps can read pretty format */
    u_char expire_on_interval;
    u_char rotate_files;
    u_char dump_active;
    u_char include_zero;
    u_char merge_ifaces;
    const char *outfilename;
    char algorithm; /* timeout algorithm */
    char accum;	    /* accumulation type */
    int p1;	    /* timeout algorithm parameter 1 */
    int p2;	    /* timeout algorithm parameter 2 */
    coral_anon_t *anon;
} config;

coral_rotfile_t *rf;
FILE *outfile;

const char *fmt_lheader, *fmt_rheader, *fmt_addr, *fmt_right;

struct {
    uint64_t ipbytes;
    uint64_t notIP;
    coral_pkt_stats_t *pkt_stats;
    double begin;
    double end;
} interval_data;

#define VPVC_HASH_TABLE_SIZE	229
#define FLOW_HASH_TABLE_SIZE	97843

struct subif_stats;

typedef struct flow {
/* flow key data */
    struct subif_stats *parent;
    struct in_addr src;
    struct in_addr dst;
    u_char	ip_proto;
    u_char	ports_ok;
    u_short	sport;
    u_short	dport;

/* flow data */
    uint64_t	pkts;
    uint64_t	bytes;
    struct timespec first;
    struct timespec latest;
    struct timespec gap;

/* operational data */
    struct flow	*next, *prev;
} flow;

typedef struct subif_stats {
    coral_iface_t *iface;
    u_int iface_id;
    u_int subif_id;
    uint64_t pkts;
    uint64_t bytes;
    uint64_t flows;		/* number of active flows */
    uint64_t n_expired_flows;	/* number of expired flows */
    uint64_t unknown_encaps;
    uint64_t ip_not_v4;
    struct timespec first;
    struct timespec latest;
    flow *active_flows;		/* linked list of active flows for this subif */
    flow *expired_flows;	/* linked list of expired flows for this subif */
} subif_stats;

hash_tab *subif_hash;
hash_tab *flow_hash;

int interrupted = 0;
int delete_flow_flag = 1;
const char rotating_filename[] = "%010s.%f.t2";

static void (*dump_flow_table)(flow *flowlist);

/* ---- hash table per subif fxns begin ---- */
/* -- per subif hash table fxns -- */

/* return 0 if the same - for use by the hashtable */
static int compare_subif_stats(const void *entry1, const void *entry2)
{
    const subif_stats *foo1 = entry1;
    const subif_stats *foo2 = entry2;

    return (foo1->subif_id != foo2->subif_id ||
	    foo1->iface_id != foo2->iface_id);
}

/* make a hash of an entry - for use by the hashtable */
static unsigned long make_key_subif_stats(const void *entry)
{
    const subif_stats *what = entry;

    return (unsigned) what->subif_id * 425879 + what->iface_id;
}

/* free mem of an entry - for use by the hashtable */
static void delete_subif_stats(void *entry)
{
    subif_stats *what = entry;
    if (!what) return;
    free(what);
}
/* -- end of subif type hash table fxns -- */


/* ---- stuff that is per (flow)hash table ---- */

/* return 0 if the same - for use by the hashtable */
static int compare_flow(const void *entry1, const void *entry2)
{
    const flow *foo1 = entry1;
    const flow *foo2 = entry2;

    return (foo1->parent != foo2->parent ||
            foo1->src.s_addr != foo2->src.s_addr ||
	    foo1->dst.s_addr != foo2->dst.s_addr ||
	    foo1->ip_proto != foo2->ip_proto ||
	    foo1->sport != foo2->sport ||
	    foo1->dport != foo2->dport ||
	    foo1->ports_ok != foo2->ports_ok);
}

/* make a hash of an entry - for use by the hashtable */
static unsigned long make_key_flow(const void *entry)
{
    const flow *what = entry;
    
    return ((unsigned)what->parent)+
        (unsigned) what->src.s_addr * 59 + what->dst.s_addr +
	what->ip_proto + ((unsigned)what->dport<<16) + what->sport;
}

/* free mem of an entry - for use by the hashtable */
static void delete_flow(void *entry)
{
    flow *what = entry;
    if (!what || !delete_flow_flag) return;
    free(what);
}
/* ---- hash table fxns end ---- */

static int is_expired(flow *flowrec, const struct timespec *ts, int is_pkt)
{
    struct timespec gap;
    struct timespec thresh;
    int result;
    double intpart, fracpart;

    gap = *ts;
    timespecsub(&gap, &flowrec->latest);

    switch(config.algorithm) {
    case ALG_NONE:
	return 0;
    case ALG_FIXED:
	return (gap.tv_sec >= config.p1);
    case ALG_MULT:
	fracpart = modf(timespectodouble(&flowrec->gap) * config.p1, &intpart);
	thresh.tv_nsec = 1000000000.0 * fracpart;
	thresh.tv_sec = intpart;
	result = timespeccmp(&gap, &thresh, >= );
	if (is_pkt) {
	    /* only adjust the gap if the timestamp was from a new
	       packet in this same flow, not if it was a time tick
	       from seeing an interval edge */
	    flowrec->gap = gap;
	}
	return result;
    }
    return 0;
}

static void expire_flow(flow *flowrec)
{
    /* remove from hash table */
    delete_flow_flag = 0; /* don't let the hash table free our flow */
    clear_hash_entry(flow_hash, flowrec);
    delete_flow_flag = 1;

    /* remove from subif's active flow list */
    assert(!flowrec->next || flowrec->next->prev == flowrec);
    if (flowrec->next)
	flowrec->next->prev = flowrec->prev;
    assert(flowrec->prev ? flowrec->prev->next == flowrec : flowrec->parent->active_flows == flowrec);
    *(flowrec->prev ? &flowrec->prev->next : &flowrec->parent->active_flows) =
	flowrec->next;

    /* add to expired flow list */
    flowrec->prev = NULL;
    flowrec->next = flowrec->parent->expired_flows;
    if (flowrec->parent->expired_flows)
	flowrec->parent->expired_flows->prev = flowrec;
    flowrec->parent->expired_flows = flowrec;
    flowrec->parent->n_expired_flows++;
    flowrec->parent->flows--;

    assert(!flowrec->next || flowrec->next->prev == flowrec);
    assert(flowrec->prev ? flowrec->prev->next == flowrec : flowrec->parent->expired_flows == flowrec);
}

static void count_flow(subif_stats *subif, coral_iface_t *iface,
    const struct timespec *ts, const coral_pkt_buffer_t * netpkt)
{
    flow tmp;
    flow *flowrec;
    short offset;
    struct ip * ip;
    coral_pkt_buffer_t payload;

    ip = (struct ip*)netpkt->buf;
    offset = ntohs(ip->ip_off) & IP_OFFMASK;

    /* Set the key to the source/destination address pair. */
    tmp.parent = subif;
    tmp.src.s_addr = config.netmask & ip->ip_src.s_addr;
    tmp.dst.s_addr = config.netmask & ip->ip_dst.s_addr;
    tmp.ip_proto = ip->ip_p;
    tmp.ports_ok = 0;
    tmp.sport = 0;
    tmp.dport = 0;

    coral_get_payload(netpkt, &payload);
    /* NOT get_payload_by_layer(..., 4); we want the payload, no matter what
     * layer it claims to be.  (Specifically, we don't want to go through
     * IPIP encapsulations.)
     */

    /* extract port info - make sure we aren't non-first fragments */
    if (offset == 0) {
        if (ip->ip_p == IPPROTO_TCP) {
	    if (payload.caplen >= 4) {
	        struct tcphdr *t = (struct tcphdr*)payload.buf;
		tmp.sport = ntohs(t->th_sport);
		tmp.dport = ntohs(t->th_dport);
		tmp.ports_ok = 1;
	    }
	} else if (ip->ip_p == IPPROTO_UDP) {
	    if (payload.caplen >= 4) {
	        struct udphdr *u = (struct udphdr*)payload.buf;
		tmp.sport = ntohs(u->uh_sport);
		tmp.dport = ntohs(u->uh_dport);
		tmp.ports_ok = 1;
	    }
	} else if (ip->ip_p == IPPROTO_ICMP) {
	    if (payload.caplen >= 2) {
	        struct icmp *icmp = (struct icmp*)payload.buf;
		tmp.sport = icmp->icmp_type;
		tmp.dport = icmp->icmp_code;
		tmp.ports_ok = 1;
	    }
	}
    }

    /* Read the current value out of the database. */
    if ((flowrec = (flow*)find_hash_entry(flow_hash, &tmp))) {
	if (is_expired(flowrec, ts, 1)) {
	    expire_flow(flowrec);
	    flowrec = NULL;
	} else {
	    flowrec->pkts++;
	    flowrec->bytes += ntohs(ip->ip_len);
	}
    }

    if (!flowrec) {
	flowrec = (flow*)malloc(sizeof(flow));
	if (flowrec == NULL) {
	    fprintf(stderr, "can't malloc port_stats.\n");
	    abort();
	}

	*flowrec = tmp;
	flowrec->pkts = 1;
	flowrec->bytes = ntohs(ip->ip_len);
	flowrec->first = *ts;
	flowrec->gap.tv_sec = config.p2;
	flowrec->gap.tv_nsec = 0;
	flowrec->prev = NULL;
	flowrec->next = subif->active_flows;
	if (flowrec->next)
	    flowrec->next->prev = flowrec;
	subif->active_flows = flowrec;
	subif->flows++;

	assert(!flowrec->next || flowrec->next->prev == flowrec);
	assert(flowrec->prev ? flowrec->prev->next == flowrec : flowrec->parent->active_flows == flowrec);

	add_hash_entry(flow_hash, flowrec);
    }

    flowrec->latest = *ts;
}

/* NB: returns a pointer to static data */
static const char *hostname(struct in_addr *addr)
{
    struct hostent *h;

    if (config.anon) {
	struct in_addr newaddr;
	newaddr.s_addr = coral_anonymize(config.anon, ntohl(addr->s_addr));
	newaddr.s_addr = htonl(newaddr.s_addr);
	return inet_ntoa(newaddr);
    }
    if (config.cnames &&
	(h = gethostbyaddr((char*)addr, sizeof(struct in_addr), AF_INET)))
    {
	return h->h_name;
    } else {
	return inet_ntoa(*addr);
    }
}


static void dump_compact_binary_flow_table(flow *flowlist)
{
    flow *flowrec;

    fputs("#compact binary data follows\n", outfile);

    for (flowrec = flowlist; flowrec; flowrec = flowrec->next) {
	if (!printable_flow(flowrec))
	    continue;

	{
	    /* compact binary:
	     * Omits length; 
	     * If !ports_ok, omits sport and dport;
	     * If !full_save, omits first and latest;
	     * ports_ok and full_save are bits within a single "flags" byte;
	     * uint64_t fields usually fit in <= 4 bytes, but can actually
	     *   hold only 62-bit values;
	     * uint{8,16,32}_t fields are written in full.
	     * 
	     * TODO, maybe:
	     * timestamps could be measured relative to some nearby time (say,
	     *   beginning of interval), which would make them smaller values,
	     *   which could then be written more compactly.
	     */
	    uint64_t flows = 1;
	    uint8_t flags = FLAG_FIRST_LATEST;
	    if (flowrec->ports_ok) flags |= FLAG_PORTS_OK;
	    coral_fwrite_binint(outfile, &flags);
	    fwrite(&flowrec->src, sizeof(struct in_addr), 1, outfile);
	    fwrite(&flowrec->dst, sizeof(struct in_addr), 1, outfile);
	    coral_fwrite_binint(outfile, &flowrec->ip_proto);
	    if (flags & FLAG_PORTS_OK) {
		coral_fwrite_binint(outfile, &flowrec->sport);
		coral_fwrite_binint(outfile, &flowrec->dport);
	    }
	    coral_fwrite_binint(outfile, &flowrec->pkts);
	    coral_fwrite_binint(outfile, &flowrec->bytes);
	    coral_fwrite_binint(outfile, &flows);
	    if (flags & FLAG_FIRST_LATEST) {
		coral_fwrite_binint(outfile, &flowrec->first.tv_sec);
		coral_fwrite_binint(outfile, &flowrec->first.tv_nsec);
		coral_fwrite_binint(outfile, &flowrec->latest.tv_sec);
		coral_fwrite_binint(outfile, &flowrec->latest.tv_nsec);
	    }
	}
    }
    fwrite("\0\n", 1, 2, outfile);
    fputs("# end of binary table\n\n", outfile);

    fflush(outfile);
}


static void dump_binary_flow_table(flow *flowlist)
{
    flow *flowrec;

    fputs("#binary data follows\n", outfile);

    for (flowrec = flowlist; flowrec; flowrec = flowrec->next) {
	if (!printable_flow(flowrec))
	    continue;

	{
	    /* old binary */
	    uint8_t length = 2*sizeof(struct in_addr) + 2*sizeof(uint8_t) +
		2*sizeof(uint16_t);
	    const uint8_t full_save = 1; /* We output first and latest */
	    uint16_t sport = htons(flowrec->sport);
	    uint16_t dport = htons(flowrec->dport);
	    uint64_t pkts = crl_hton64(flowrec->pkts);
	    uint64_t bytes = crl_hton64(flowrec->bytes);
	    uint64_t flows = crl_hton64(1);
	    uint32_t first_sec = htonl(flowrec->first.tv_sec);
	    uint32_t first_nsec = htonl(flowrec->first.tv_nsec);
	    uint32_t latest_sec = htonl(flowrec->latest.tv_sec);
	    uint32_t latest_nsec = htonl(flowrec->latest.tv_nsec);

	    fwrite(&length, sizeof(uint8_t), 1, outfile);
	    fwrite(&full_save, sizeof(uint8_t), 1, outfile);
	    fwrite(&flowrec->src, sizeof(struct in_addr), 1, outfile);
	    fwrite(&flowrec->dst, sizeof(struct in_addr), 1, outfile);
	    fwrite(&flowrec->ip_proto, sizeof(uint8_t), 1, outfile);
	    fwrite(&flowrec->ports_ok, sizeof(uint8_t), 1, outfile);
	    fwrite(&sport, sizeof(uint16_t), 1, outfile);
	    fwrite(&dport, sizeof(uint16_t), 1, outfile);
	    fwrite(&pkts, sizeof(uint64_t), 1, outfile);
	    fwrite(&bytes, sizeof(uint64_t), 1, outfile);
	    fwrite(&flows, sizeof(uint64_t), 1, outfile);
	    if (full_save) {
		fwrite(&first_sec, sizeof(uint32_t), 1, outfile);
		fwrite(&first_nsec, sizeof(uint32_t), 1, outfile);
		fwrite(&latest_sec, sizeof(uint32_t), 1, outfile);
		fwrite(&latest_nsec, sizeof(uint32_t), 1, outfile);
	    }
	}
    }
    fwrite("\0\n", 1, 2, outfile);
    fputs("# end of binary table\n\n", outfile);

    fflush(outfile);
}

static void dump_text_flow_table(flow *flowlist)
{
    flow *flowrec;

    fprintf(outfile, fmt_lheader, "src", "dst");
    fprintf(outfile, fmt_rheader, "proto", "ok", "sport", "dport",
	"pkts", "bytes", "flows", "first", "latest");

    for (flowrec = flowlist; flowrec; flowrec = flowrec->next) {
	if (printable_flow(flowrec)) {
	    fprintf(outfile, fmt_addr, hostname(&flowrec->src));
	    fprintf(outfile, fmt_addr, hostname(&flowrec->dst));
	    fprintf(outfile, fmt_right,
		flowrec->ip_proto, flowrec->ports_ok, 
		flowrec->sport, flowrec->dport, 
		flowrec->pkts, flowrec->bytes, 1, /* Flows == 1 */
		flowrec->first.tv_sec, flowrec->first.tv_nsec,
		flowrec->latest.tv_sec, flowrec->latest.tv_nsec);
	}
    }

    fputs("# end of text table\n\n", outfile);
    fflush(outfile);
}


/* 
 * keep track of some subif related stats, and count_flow().
 */
static void count_subif_stats(coral_iface_t *iface,
    coral_pkt_result_t *pkt_result)
{
    subif_stats *subifrec;
    subif_stats tmp;
    coral_pkt_buffer_t netpkt;
    struct ip *ip;

    if (config.merge_ifaces) {
	tmp.iface = NULL;
	tmp.iface_id = 0;
	tmp.subif_id = 0;
    } else {
	tmp.iface = iface;
	tmp.iface_id = coral_interface_get_number(iface);
	tmp.subif_id = pkt_result->subiface;
    }

    if (!(subifrec = (subif_stats*)find_hash_entry(subif_hash, &tmp))) {
	subifrec = (subif_stats*)malloc(sizeof(subif_stats));
	if (subifrec == NULL) {
	    fprintf(stderr, "can't malloc subif_stats.\n");
	    abort();
	}
	subifrec->subif_id = tmp.subif_id;
	subifrec->iface = tmp.iface;
	subifrec->iface_id = tmp.iface_id;
	subifrec->pkts = 0;
	subifrec->bytes = 0;
	subifrec->flows = 0;
	subifrec->n_expired_flows = 0;
	subifrec->unknown_encaps = 0;
	subifrec->ip_not_v4 = 0;
	subifrec->active_flows = NULL;
	subifrec->expired_flows = NULL;
	CORAL_TIMESTAMP_TO_TIMESPEC(iface, pkt_result->timestamp,
	    &subifrec->latest);
	subifrec->first = subifrec->latest;
        add_hash_entry(subif_hash, subifrec);
    } else {
	/* Every new interval needs a new first */
	if (!subifrec->first.tv_sec && !subifrec->first.tv_nsec) {
	    subifrec->first = subifrec->latest;
	}
	CORAL_TIMESTAMP_TO_TIMESPEC(iface, pkt_result->timestamp,
	    &subifrec->latest);
    }

    if (coral_get_payload_by_layer(pkt_result->packet, &netpkt, 3) < 0) {
	subifrec->unknown_encaps++;
	return;
    }

    if (netpkt.protocol != CORAL_NETPROTO_IP) {
	interval_data.notIP++;
	return;
    }

    ip = (struct ip*)netpkt.buf;
    if (ip->ip_v != 4) {
	subifrec->ip_not_v4++;
	return;
    }

    /* do stats --- */
    subifrec->pkts++;
    subifrec->bytes += ntohs(ip->ip_len);
    interval_data.ipbytes += ntohs(ip->ip_len);

    count_flow(subifrec, iface, &subifrec->latest, &netpkt);
}

static void init_hashes(void)
{
    subif_hash = init_hash_table("# hashes entries for each subif",
			       compare_subif_stats, make_key_subif_stats,
			       delete_subif_stats, VPVC_HASH_TABLE_SIZE);
    flow_hash = init_hash_table("# hashes entries for each flow",
			       compare_flow, make_key_flow,
			       delete_flow, FLOW_HASH_TABLE_SIZE);
}
/* ---- per subif stuff ends ---- */


static void dump_hash_stats(void)
{
    dump_hashtab_stats(subif_hash);
    dump_hashtab_stats(flow_hash);
}

static void dump_data(int dump_active)
{
    const subif_stats *subifrec;
    /*flow *flowrec;*/
    double begin;
    double end;
    int count;

    begin = interval_data.begin;
    end = interval_data.end;

#define needs_tuple_table(subifrec) \
    ((subifrec)->expired_flows || ((subifrec)->active_flows && dump_active))

    if (end && begin) {
	/* Normal (possibly empty) interval */
	fprintf(outfile, "\n# begin trace interval: %f\n", begin);
	fprintf(outfile, "# trace interval duration: %f s\n"
			"# Layer 2 PDUs dropped: %" PRIu64 "\n"
			"# Packets dropped: %" PRIu64 "\n"
			"# IP: %.4f Mbit/s\n"
			"# Non-IP: %.4f pkts/s\n",
	    (end - begin), 
	    interval_data.pkt_stats->l2_drop,
	    interval_data.pkt_stats->pkts_drop,
	    (double)interval_data.ipbytes * 8 / (1000 * 1000 * (end - begin)),
	    (double)(interval_data.notIP)/(end - begin));
    } else {
	/* This must be a final dump of active flows. */
	fprintf(outfile, "\n# active flows pseudo-interval\n");
    }
    fputs("# Table IDs: ", outfile);
    init_hash_walk(subif_hash);
    count = 0;
    while ((subifrec = next_hash_walk(subif_hash))) {
	if (needs_tuple_table(subifrec) || subifrec->unknown_encaps ||
	    subifrec->ip_not_v4)
	{
	    char buf[32] = "0";
	    if (count++)
		fputs(", ", outfile);
	    if (!config.merge_ifaces)
		coral_fmt_if_subif(buf, subifrec->iface, subifrec->subif_id);
	    fprintf(outfile, "%s", buf);
	}
    }
    fputs("\n\n", outfile);

    init_hash_walk(subif_hash);
    while ((subifrec = next_hash_walk(subif_hash))) {
	if (needs_tuple_table(subifrec) ||
	    subifrec->unknown_encaps || subifrec->ip_not_v4)
	{
	    char buf[32] = "0";
	    if (!config.merge_ifaces)
		coral_fmt_if_subif(buf, subifrec->iface, subifrec->subif_id);
	    fprintf(outfile, "# ID: %s\n", buf);
	    fprintf(outfile,
		    "# unknown_encaps: %" PRIu64 "\n"
		    "#      ip_not_v4: %" PRIu64 "\n",
		    subifrec->unknown_encaps,
		    subifrec->ip_not_v4);
	    if (needs_tuple_table(subifrec)) {
		fprintf(outfile,
			"#           pkts: %" PRIu64 "\n"
			"#          bytes: %" PRIu64 "\n"
			"#          flows: %" PRIu64 "\n"
			"#          first: %lu.%09lu\n"
			"#         latest: %lu.%09lu\n"
			"# Table types: ",
			subifrec->pkts, subifrec->bytes,
			subifrec->flows + subifrec->n_expired_flows,
			subifrec->first.tv_sec, subifrec->first.tv_nsec,
			subifrec->latest.tv_sec, subifrec->latest.tv_nsec);
		if (subifrec->expired_flows) {
		    fprintf(outfile, "Tuple Table (expired)");
		}
		if (subifrec->active_flows && dump_active) {
		    if (subifrec->expired_flows) {
			fputs(", ", outfile);
		    }
		    fprintf(outfile, "Tuple Table (active)");
		}
		fputs("\n", outfile); 
	    }
	    fputs("\n", outfile); 
	}
    }

    init_hash_walk(subif_hash);
    while ((subifrec = next_hash_walk(subif_hash))) {
	if (needs_tuple_table(subifrec)) {
	    char buf[40] = " ID: 0";
	    if (!config.merge_ifaces)
		coral_fmt_if_subif(buf+5, subifrec->iface, subifrec->subif_id);
	    if (subifrec->expired_flows) {
		fprintf(outfile,
			"# begin Tuple Table (expired)%s\n", buf);
		dump_flow_table(subifrec->expired_flows);
	    }
	    if (subifrec->active_flows && dump_active) {
		fprintf(outfile,
			"# begin Tuple Table (active)%s\n", buf);
		dump_flow_table(subifrec->active_flows);
	    }
	}
    }
    fputs("# end trace interval\n", outfile);
    fflush(outfile);
}

static void clear_data(void)
{
    subif_stats *subifrec;
    flow *flowrec;
    interval_data.ipbytes = 0;
    interval_data.notIP = 0;

    init_hash_walk(subif_hash);
    while ((subifrec = next_hash_walk(subif_hash))) {
	/* delete expired flows */
	while (subifrec->expired_flows) {
	    flowrec = subifrec->expired_flows->next;
	    delete_flow(subifrec->expired_flows);
	    /*flowrec->prev = NULL;*/ /* not necessary */
	    subifrec->expired_flows = flowrec;
	}
	/* If subif has no active flows, delete it */
	if (!subifrec->active_flows) {
	    clear_hash_entry(subif_hash, subifrec);
	} else { /* Otherwise, reset metadata counters */
	    subifrec->pkts = 0;
	    subifrec->bytes = 0;
	    /* DO NOT: subifrec->flows = 0; */
	    subifrec->n_expired_flows = 0;
	    subifrec->unknown_encaps = 0;
	    subifrec->ip_not_v4 = 0;
	    subifrec->first.tv_sec = 0;
	    subifrec->first.tv_nsec = 0;
	    subifrec->latest.tv_sec = 0;
	    subifrec->latest.tv_nsec = 0;
	}
    }

    if (config.accum & ACCUM_INTERVAL) {
	/* Reset per-flow counters */
	init_hash_walk(flow_hash);
	while ((flowrec = next_hash_walk(flow_hash))) {
	    flowrec->pkts = 0;
	    flowrec->bytes = 0;
	}
    }
}

static void stop(int sig)
{
    interrupted = 1;
}

int main(int argc, char *argv[])
{
    int retval = 0, no_expiry = 1;
    int i;
    coral_iface_t *iface;
    coral_pkt_result_t pkt_result;
    coral_interval_result_t interval_result;
#   define CIDR_LEN 32
    u_int cidr_len = CIDR_LEN;
    struct timeval interval = { 300, 0 };
    u_int duration;
    int opt;
    int error = 0, first = 1;
    flow *flowrec;
    struct timespec ts;
    char file_header[1024], *p;

    config.outfilename = "-"; /* Default to stdout */
    config.accum = ACCUM_LIFETIME; /* default */

    coral_set_api(CORAL_API_PKT);
    coral_set_duration(0);
    coral_set_interval(&interval);
    coral_set_iomode(0, CORAL_RX, 48, 0);
    coral_set_options(0, CORAL_OPT_PARTIAL_PKT | CORAL_OPT_NORMALIZE_TIME);

    while (!error && (opt = getopt(argc, argv, "C:p:aAsBbhO:o:rT:Ic:zm")) != -1) {
	switch (opt) {
	case 'C':
	    if (coral_config_command(optarg) < 0)
		error++;
	    break;
	case 'p':
	    cidr_len = atoi(optarg);
	    if (cidr_len > 32 || cidr_len < 8) {
		fprintf(stderr,
			"%s: valid CIDR prefix lengths are between 8 and 32\n",
			argv[0]);
		error++;
	    }
	    break;
	case 'a':
	    config.cnames = 1;
	    break;
	case 'A':
	    config.dump_active = 1;
	    break;
	case 's':
	    config.stats = 1;
	    break;
	case 'B':
	    config.binary = 2; /* compact binary */
	    coral_diag(1, ("%s: warning: no application can read -B format; "
		"you probably want -b.\n", argv[0]));
	    break;
	case 'b':
	    config.binary = 1;
	    break;
	case 'h':
	    config.pretty = 1;
	    break;
	case 'r':
	    config.rotate_files = 1;
	    config.outfilename = rotating_filename;
	    break;
	case 'O':
	    config.rotate_files = 1;
	    /* fall through */
	case 'o':
	    config.outfilename = strdup(optarg);
	    break;
	case 'I':
	    no_expiry = 0;
	    config.expire_on_interval = 1;
	    break;
	case 'T':
	    no_expiry = 0;
	    switch(optarg[0]) {
		case 'f':
		    config.algorithm = ALG_FIXED;
		    if (sscanf(optarg+1, "%d", &config.p1) != 1)
			error++;
		    break;
		case 'm':
		    config.algorithm = ALG_MULT;
		    if (sscanf(optarg+1, "%d,%d", &config.p1, &config.p2) != 2)
			error++;
		    break;
		case 'N':
		    config.algorithm = ALG_NONE;
		    break;
		default:
		    error++;
		    break;
	    }
	    if (error)
		fprintf(stderr, "invalid timeout algorithm\n");
	    break;
	case 'c':
	    if (strcmp(optarg, "i") == 0)
		config.accum = ACCUM_INTERVAL;
	    else if (strcmp(optarg, "l") == 0)
		config.accum = ACCUM_LIFETIME;
	    else
		error++;
	    break;
	case 'z':
	    config.include_zero = 1;
	    break;
	case 'm':
	    config.merge_ifaces = 1;
	    break;
	default:
	    error++;
	    break;
	}
    }

    if (error) {
	coral_usage(argv[0], "[<other_options>] <source>...\n"
	    "Other options:\n"
	    "-p<n>      use <n> as length of CIDR prefix (default %d)\n"
	    "-a         resolve IP addresses to hostnames (only makes sense with -p32)\n"
	    "-A         print active flows in addition to expired flows every interval\n"
	    "           (otherwise, still-active flows will be printed only at end of run)\n"
	    "-s         print hash table statistics\n"
	    "-b         print binary table data\n"
	    "-B         print compact binary table data (experimental: nothing can read it)\n"
	    "-h         print human readable table data\n"
	    "-o<file>   specify the name of the output file (default: -)\n"
	    "-r         rotate the output file every interval (requires a filename with\n"
	    "           %% specifiers; the default filename with -r is '%s')\n"
	    "-O<file>   equivalent to -r -o<file>\n"
	    "-I         expire all flows at end of interval\n"
	    "-T         expiry timeout algorithm\n"
	    "           f<N>       fixed <N> seconds (ala NetFlow)\n"
	    "           m<M>,<I>   <M> times the gap, with gap initially set to <I> seconds\n"
	    "           N          no expiry\n"
	    "-ci        with -I -A, report counts for the interval only\n"
	    "-cl        with -I -A, report counts for the lifetime of the flow (default)\n"
	    "-z         with -I -A -ci, include flows with zero packets in report\n"
	    "-m         merge streams of multiple interfaces (and subinterfaces) into one\n"
	    "\n"
"<file> is the name of the output file, which may contain %% specifiers\n"
"    for formatting a timestamp.  For -o, the timestamp is the beginning of\n"
"    the trace; for -O, the timestamp is the beginning of the interval.\n"
"    The %% specifiers are any of those allowed by strftime(), plus:\n"
"        %%s   number of (whole) seconds since 1970-01-01 00:00:00 UTC\n"
"        %%f   fractional part of seconds (6 decimal places)\n"
"        %%F   equivalent to %%Y-%%m-%%d\n"
"    Except for %%f, all specifiers may contain printf-style modifiers\n"
"    (e.g., \"%%010s\").\n"
"    For -o, '-' means standard output.\n"
"    If neither -I nor -T is given, -I is assumed.\n",
	    CIDR_LEN,
	    rotating_filename);
	exit(-1);
    }

    if (config.merge_ifaces) {
	/* We must sort in order to track first and latest timestamps, and
	 * to handle time-based expiry mechanisms. */
	coral_set_options(0, CORAL_OPT_SORT_TIME);
    }

    if ((config.anon = coral_get_anonymizer())) {
	if (config.cnames) {
	    coral_diag(1, ("can not mix -a and -Canon options\n"));
	    exit(-1);
	}
	coral_set_anonymizer(NULL);
    }

    while (optind < argc) {
	if (!coral_new_source(argv[optind]))
	    exit(-1);
	optind++;
    }

    if (no_expiry) {
	coral_diag(1, ("%s: no expiry mechanism specified; defaulting to -I.\n",
	    argv[0]));
	config.expire_on_interval = 1;
    }

    if (config.accum == ACCUM_INTERVAL && !config.expire_on_interval &&
	!config.dump_active)
    {
	coral_diag(0, ("%s: -ci does not make sense without -I or -A.\n",
	    argv[0]));
	exit(-1);
    }

    if (!coral_next_source(NULL)) {
	coral_diag(1, ("%s: warning: no sources specified.\n", argv[0]));
    }

    init_hashes();

    /* generate a netmask from the cidr length */
    for (i = 32 - cidr_len; i < 32; i++)
	config.netmask |= (1 << i);

    /* corrected for endianess */
    config.netmask = htonl(config.netmask);

    if (coral_open_all() <= 0)
	exit(-1);

    if (coral_start_all() < 0)
	exit(-1);

    signal(SIGINT, stop);

    coral_get_interval(&interval);
    interval_data.begin = 0;
    interval_data.end = 0;
    interval_data.pkt_stats = NULL;

    duration = coral_get_duration();
    if (duration)
	coral_diag(2, ("collection duration max set to %d second(s)\n", 
		       duration));

    coral_read_pkt_init(NULL, NULL, &interval);

    p = file_header;
    p += sprintf(p, "# crl_flow output version: %s (%s format)\n",
	    OUTPUT_VERSION,
	    config.binary == 2 ? "compact binary" :
	    config.binary ? "binary" :
	    config.pretty ? "pretty" :
	    "text" );
    p += sprintf(p, "# generated by: ");
    for (i = 0; i < argc; i++)
	p += sprintf(p, " %s", argv[i]);
    sprintf(p, "\n");

    if (config.binary) {
	if (config.binary > 1)
	    dump_flow_table = dump_compact_binary_flow_table;
	else
	    dump_flow_table = dump_binary_flow_table;
    } else {
	dump_flow_table = dump_text_flow_table;
	if (!config.pretty) {
	    fmt_lheader = "#%s\t%s";
	    fmt_rheader = "\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n";
	    fmt_addr = "%s\t";
	    fmt_right = "%u\t%u\t%u\t%u\t%" PRIu64 "\t%" PRIu64
		"\t%u\t%lu.%09lu\t%lu.%09lu\n";
	} else {
	    if (config.cnames) {
		fmt_lheader = "#%-29s %-30s";
		fmt_addr = "%-30s ";
	    } else {
		fmt_lheader = "#%-14s %-15s";
		fmt_addr = "%-15s ";
	    }
	    fmt_rheader = " %-5s %-2s %5s %5s %13s %15s %9s %20s %20s\n";
	    fmt_right = "%5u %2u %5u %5u %13" PRIu64 " %15" PRIu64
		" %9u %10lu.%09lu %10lu.%09lu\n";
	}
    }

    rf = coral_rf_open_file(&outfile, config.outfilename, "", 0);
    if (!rf)
	exit(1);

    while (1) {
	if (interrupted) {
	    coral_stop_all();
	    interrupted = 0;
	}
	iface = coral_read_pkt(&pkt_result, &interval_result);

	if (!iface) {
	    if (errno == EINTR || errno == EAGAIN) continue;
	    retval = errno;
	    break;
	}

	if (!pkt_result.packet && !interval_result.stats) {
	    /* beginning of interval */
	    interval_data.begin = timevaltodouble(&interval_result.begin);
	    if (config.rotate_files || first) {
		coral_rf_start(rf, &interval_result.begin);
		fputs(file_header, outfile);
		first = 0;
	    }

	} else if (pkt_result.packet) {
	    /* got packet */
	    count_subif_stats(iface, &pkt_result);

	} else if (!pkt_result.packet && interval_result.stats) {
	    struct timeval tv1, tv2;
	    /* end of interval */
	    interval_data.end = timevaltodouble(&interval_result.end);
	    interval_data.pkt_stats = interval_result.stats;

	    gettimeofday(&tv1, NULL);

	    /* Expire all flows that need to be expired */
	    if (config.expire_on_interval || config.algorithm != ALG_NONE) {
		ts.tv_sec = interval_result.end.tv_sec;
		ts.tv_nsec = interval_result.end.tv_usec * 1000;
		init_hash_walk(flow_hash);
		while ((flowrec = next_hash_walk(flow_hash))) {
		    if (config.expire_on_interval || is_expired(flowrec,&ts,0))
			expire_flow(flowrec);
		}
	    }

	    /* Print tables */
	    dump_data(config.dump_active);

	    if (config.rotate_files)
		coral_rf_end(rf);
	    clear_data();
	    gettimeofday(&tv2, NULL);
	    timersub(&tv2, &tv1, &tv1);
	    coral_diag(2, ("crl_flow: closed %f s interval in %d.%06d s\n",
		interval_data.end - interval_data.begin,
		tv1.tv_sec, tv1.tv_usec));

	    /* reset the interval time, and other timers */
	    interval_data.begin = 0;
	    interval_data.end = 0;
	    interval_data.pkt_stats = NULL;
	}
    }

    /* Dump any remaining active flows. */
    {
	subif_stats *subifrec;
	init_hash_walk(subif_hash);
	while ((subifrec = next_hash_walk(subif_hash))) {
	    if (subifrec->active_flows) {
		/* There is at least one subif with undumped active flows. */
		if (config.rotate_files || !outfile)
		    coral_rf_start(rf, &interval_result.end);
		dump_data(1);
		break;
	    }
	}
    }

    coral_rf_close(rf);
    coral_stop_all();

    /* clean up stuff */
    if (config.stats) dump_hash_stats();
#if 0
    clear_hash_table(subif_hash);
    clear_hash_table(flow_hash);
#endif
    return retval;
}
