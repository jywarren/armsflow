/* These aren't portably defined in any system header, so we just define
 * them ourselves according to the RFCs.
 */

#define ETHERTYPE_PUP		0x0200	/* PUP protocol */
#define ETHERTYPE_IP		0x0800	/* IP protocol v4 */
#define ETHERTYPE_ARP		0x0806	/* Address resolution protocol */
#define ETHERTYPE_REVARP	0x8035	/* Reverse addr. resolution protocol */
#define ETHERTYPE_IPX		0x8037	/* Novell IPX */
#define ETHERTYPE_APPLETALK	0x809B	/* AppleTalk */
#define ETHERTYPE_AARP		0x80F3	/* AppleTalk ARP */
#define ETHERTYPE_VLAN		0x8100	/* IEEE 802.1Q VLAN tagging */
#define ETHERTYPE_IPX_E		0x8137	/* Novell IPX (old, ECONFIG E option) */
#define ETHERTYPE_SNMP		0x814C	/* RFC 1089 SNMP over Ethernet */
#define ETHERTYPE_IPv6		0x86DD	/* IP protocol v6 */
#define ETHERTYPE_PPP		0x880B	/* PPP */
#define ETHERTYPE_MPLS		0x8847	/* MPLS unicast */
#define ETHERTYPE_PPPOED	0x8863	/* RFC 2516 PPP over Ethernet */
#define ETHERTYPE_PPPOES	0x8864	/* RFC 2516 PPP over Ethernet */
#define ETHERTYPE_LOOPBACK	0x9000	/* used to test interfaces */

#define ETHERMTU        1500
#define ETHER_ADDR_LEN  6

struct  ether_header {
        uint8_t  ether_dhost[ETHER_ADDR_LEN];
        uint8_t  ether_shost[ETHER_ADDR_LEN];
        uint16_t ether_type;
};

