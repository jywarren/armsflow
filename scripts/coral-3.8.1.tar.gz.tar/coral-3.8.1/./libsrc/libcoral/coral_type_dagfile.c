/* 
 * Copyright 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

#include "config.h"
#include "coraldefs.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <assert.h>

#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <sys/time.h>
#include <errno.h>

#include "libcoral.h"
#include "libcoral_priv.h"
#include "coral_dag.h"
#include "ethernet.h" /* for ETHERMTU */
#ifdef HAVE_LIBZ
# include <zlib.h>
#endif

static const char RCSid[] = "$Id: coral_type_dagfile.c,v 1.69 2007/06/06 18:17:55 kkeys Exp $";

int coral_dag_common_init(coral_source_t *src, int ifcount, int is_first)
{
    coral_iface_t *iface0 = cinst[src->id[0]];
    int max_first_n = 1536; /* XXX ? */

    iface0->iface_info.hw_version    = 0;	/* default */
    iface0->iface_info.fw_version    = 0;	/* default */

    /* DAG supports ATM and POS.  If physical was not set, infer from datalink.
     * Do NOT just default to ATM; we want to force user to specify a protocol,
     * especially for dagfiles.
     */
    if (src->dev_config.physical == CORAL_PROTO_UNKNOWN) {
	switch (src->dev_config.datalink) {
	    case CORAL_DLT_ATM_RFC1483:
	    case CORAL_DLT_LANE_IEEE8023:
	    case CORAL_DLT_LANE_IEEE8025:
	    case CORAL_DLT_LANE_LLC:
	    case CORAL_DLT_GIGX:
		src->dev_config.physical = CORAL_PHY_ATM;
		break;
	    case CORAL_DLT_UoPOS:
	    case CORAL_DLT_CHDLC:
	    case CORAL_DLT_MPoFR:
	    case CORAL_DLT_PPP:
		src->dev_config.physical = CORAL_PHY_POS;
		break;
	    default:
		src->dev_config.physical = CORAL_PROTO_UNKNOWN;
		break;
	}
    }

    if (src->dev_config.physical == CORAL_PHY_ATM) {
	if (!iface0->iface_type) /* not ERF */
	    iface0->iface_type = objdup(&coral_iface_type_dag_atm);
	/* user must specify iomode */
	max_first_n = ATM_PAYLOAD_SIZE * 15;
	coral_init_atm_iface(iface0);

    } else if (src->dev_config.physical == CORAL_PHY_POS) {
	if (!iface0->iface_type) { /* not ERF */
	    iface0->iface_type = objdup(&coral_iface_type_dag_pos);
	    /* user must specify iomode */
	}
	max_first_n = 1536; /* per dag docs */

    } else if (src->dev_config.datalink == CORAL_DLT_ETHER) {
	if (!iface0->iface_type) { /* not ERF */
	    coral_diag(0, ("coral: %s: "
		"dag legacy ethernet format not supported\n",
		src->filename));
	    goto fail;
	}

    } else if (!iface0->iface_type) {
	coral_diag(0, ("coral: %s: "
	    "you must specify iomode phy and/or proto for legacy dag formats\n",
	    src->filename));
	goto fail;
    }

    if (src->dev_config.iomode.flags & CORAL_RX_UNKNOWN) {
	/* user didn't specify, we'll use whatever is in the file */
	src->dev_config.iomode = iface0->iface_info.iomode;
    }

    /* If this is a device and any src->dev_config fields are still unset,
     * use defaults for DAG and physical type.
     */
    if (coral_type_is_driver(src->type.coral_type)) {
	coral_set_dev_config_defaults(&src->dev_config,
	    &iface0->iface_type->default_config);
    }

    if (src->dev_config.iomode.flags & CORAL_RX_USER_ALL) {
	src->dev_config.iomode.first_n = MAX_PACKET_SIZE;
	src->dev_config.iomode.flags &= ~CORAL_RX_USER_ALL;
    }
    if (src->dev_config.iomode.flags & ~(CORAL_RX | CORAL_RX_VARLEN)) {
	char iomode_buffer[CORAL_FORMAT_IOMODE_LEN];
	coral_format_iomode(iomode_buffer, &src->dev_config.iomode);
	coral_diag(0, ("%s: unsupported mode: %s\n",
	    src->filename, iomode_buffer));
	goto fail;
    }

    /* As of this writing, dag_configure() gives no error for slen too large;
     * the card just drops all packets.  We warn the user, so it's not a
     * complete surprise.  But we don't prevent it, because we don't want to
     * get in the way if we are wrong about the exact limit. */
    if (max_first_n && src->dev_config.iomode.first_n > max_first_n) {
	coral_diag(1, ("warning: attempt to capture more than %d bytes on %s "
	    "may not work\n", max_first_n, src->filename));
    }

    if (src->dev_config.bandwidth > 0) {
	switch (src->dev_config.bandwidth) {
	case KBPS_OC3c:
	case KBPS_OC12c:
	case KBPS_OC48c:
	case KBPS_ETH10M:
	case KBPS_ETH100M:
	case KBPS_ETH1000M:
	    break;
	default:
	    coral_diag(0, ("%s: unsupported bandwidth %s\n",
		src->filename, coral_bandwidth_fmt(src->dev_config.bandwidth)));
	    goto fail;
	}
    }

    iface0->iface_info.hw_type			= CORAL_TYPE_DAG;
    iface0->iface_info.fw_type			= 0;
    /*iface0->iface_info.iomode			= src->dev_config.iomode;*/
    iface0->iface_info.capture_time		= 0;
    iface0->iface_info.bandwidth		= src->dev_config.bandwidth;
    iface0->iface_info.time_is_le		= 1;
    iface0->iface_info.datalink			= src->dev_config.datalink;
    iface0->iface_info.physical			= src->dev_config.physical;
    iface0->iface_info.tzoff			= 0;
    iface0->iface_info.capture_tv.tv_sec	= 0;
    iface0->iface_info.capture_tv.tv_usec	= 0;

    /* ERF sources may have multiple interfaces */
    if (ifcount > 1) {
	int i;
	while (src->iface_count < ifcount) {
	    if (coral_new_instance(src, src->iface_count) < 0)
		return -1;
	    i = src->id[src->iface_count];
	    /* copy everything from iface0 */
	    *cinst[i] = *iface0;
	    /* restore unique fields */
	    cinst[i]->id = i;
	    cinst[i]->sid = src->iface_count;
	    assert(!cinst[i]->statedata);
	    src->iface_count++;
	}
	if (is_first) {
	    /* Allocate freelist of pktq_nodes.  Allocate 50 nodes for each
	     * additional iface, under the assumption that no iface will ever
	     * get more than 50 pkts behind another. */
	    src->pktq_max = 50 * (ifcount - 1); /* XXX */
	    src->pktq_freelist = malloc(src->pktq_max *
		sizeof(coral_pktq_node_t));
	    for (i = 0; i < src->pktq_max - 1; i++)
		src->pktq_freelist[i].srcnext = &src->pktq_freelist[i+1];
	    src->pktq_freelist[i].srcnext = NULL;
	}
    } else {
	/* If there's only 1 iface, we need exactly 1 node, which will be used
	 * by read_iface (which is called for all pkts of the sorting api, and
	 * for the first pkt of the nonsorting api). */
	src->pktq_max = 1;
	if (!src->pktq_freelist) {
	    src->pktq_freelist = malloc(sizeof(coral_pktq_node_t));
	    src->pktq_freelist[0].srcnext = NULL;
	}
    }

    return 0;

fail:
    return -1;
}

#define DAG_BLK_SIZE	(1024*1024) /* from dag.c */
#define DAG_RECORD_SIZE	(64)

typedef struct dag_blk_and_info {
    char data[DAG_BLK_SIZE];
    coral_blk_info_t binfo;
} dag_blk_and_info_t;

static int coral_dagfile_init(coral_source_t *src)
{
    ssize_t len, rlen, wlen;
    ssize_t payloadstart = -1, L2hdrstart = -1;
    coral_iface_t *iface0 = cinst[src->id[0]];
    coral_dag_erf_hdr_t *hdr;
    const char *dagtype = "LEGACY";
    int unsupp = 0, erf = 0, ifcount, i;
    coral_protocol_t userphy, userdlt;
    int is_first = !src->ubase;

    if (src->fd >= 0) {
	/* already open */
    } else if (strcmp(src->filename, "-") == 0) {
	src->fd = STDIN_FILENO;
	iface0->devinfo.type = CORAL_TYPE_FILE; /* XXX ? */
    } else {
	if ((src->fd = open(src->filename, O_RDONLY, 0)) < 0) {
	    coral_diag(0, ("coral_open: %s: open: %s\n",
		src->filename, strerror(errno)));
	    return -1;
	}
	coral_diag(4, ("coral_open: %s: fd %d\n", src->filename, src->fd));
    }

    if (coral_file_common_init(src, sizeof(dag_blk_and_info_t)) < 0)
	return -1;

    iface0->iface_info.sw_type = SW_TYPE_DAG;

    /* check first record header for LEGACY, ERF, varlen, rlen */
    /* DAG_HDR_SIZE includes type-specific fields beyond coral_dag_erf_hdr_t */
    while (src->preread < DAG_HDR_SIZE) {
	len = coral_readall(src, src->ubase, DAG_HDR_SIZE - src->preread);
	if (!len) {
	    return 0;
	} else if (len < 0) {
	    coral_diag(0, ("coral: %s: %s\n", src->filename,
		coral_strerror(src->file, errno)));
	    return -1;
	}
	src->preread += len;
    }
    hdr = (coral_dag_erf_hdr_t*)src->ubase;
    rlen = crl_ntohs(hdr->rlen);
    wlen = crl_ntohs(hdr->wlen);

    userphy = src->dev_config.physical;
    userdlt = src->dev_config.datalink;
    ifcount = src->dev_config.num_ifaces;

    /* If user specified an iomode and ERF header is inconsistent with it,
     * assume the source is a legacy format, not ERF */
    if (userphy == CORAL_PHY_POS) {
	/* Legacy POS format is compatible with ERF */
    } else if (userphy == CORAL_PHY_ATM || userdlt == CORAL_DLT_ATM_RFC1483) {
	if (!(hdr->type == DAG_TYPE_ATM && rlen == 68 && wlen == 52))
	    goto end_erf;
    } else if (userdlt == CORAL_DLT_ETHER) {
	if (!(hdr->type == DAG_TYPE_ETH && rlen > 18 && wlen <= ETHERMTU))
	    goto end_erf;
    }

    /* interpret ERF header  */

    /* Check dag header for phy, and make sure it agrees with the phy
     * given in the mode option (if any). */
    switch (hdr->type) {
	case DAG_TYPE_LEGACY:
	    dagtype = "LEGACY";
	    if (!ifcount) ifcount = 1;
	    iface0->iface_info.iomode.flags = CORAL_RX;
	    iface0->iface_info.iomode.first_n = 48;
	    /* user must specify phy, dlt */
	    break;

	case DAG_TYPE_HDLC_POS:
	    dagtype = "HDLC_POS";
	    if (!ifcount) ifcount = 1;
	    payloadstart = sizeof(coral_dag_erf_hdr_t);
	    iface0->iface_type = (hdr->flags & DAG_FLAG_VARLEN || ifcount > 1) ?
		&coral_iface_type_dag_erf_varlen :
		&coral_iface_type_dag_erf_novarlen;
	    src->dev_config.physical = CORAL_PHY_POS;
	    /* DAG doesn't care about the HDLC layer; it works just as
	     * well on POS with any datalink type.  So if the user specified a
	     * datalink type, we use it, but if not we default to CHDLC. */
	    if (userdlt == CORAL_PROTO_UNKNOWN)
		src->dev_config.datalink = CORAL_DLT_CHDLC;
	    iface0->iface_info.iomode.flags = CORAL_RX;
	    iface0->iface_info.iomode.first_n = hdr->flags & DAG_FLAG_VARLEN ?
		-1 : rlen - payloadstart;
	    break;

	case DAG_TYPE_ETH:
	    dagtype = "ETH";
	    if (!ifcount) ifcount = 2;
	    payloadstart = 18; /* NB: sizeof(coral_dag_erf_ether_hdr_t) is padded */
	    if (((coral_dag_erf_ether_hdr_t*)src->ubase)->pad != 0) {
		/* DAG 3.5E filled offset and pad with garbage; ignore it */
	    } else if (((coral_dag_erf_ether_hdr_t*)src->ubase)->offset != 0) {
		/* This is not fatal, so we don't reject 3.5E files that
		 * pass the test above */
		coral_diag(0, ("warning: %s: no support for DAG ETH format "
		    "with nonzero offset\n", src->filename));
	    }
	    iface0->iface_type = (hdr->flags & DAG_FLAG_VARLEN || ifcount > 1) ?
		&coral_iface_type_dag_erf_varlen :
		&coral_iface_type_dag_erf_novarlen;
	    src->dev_config.physical = CORAL_PROTO_UNKNOWN;
	    src->dev_config.datalink = CORAL_DLT_ETHER;
	    iface0->iface_info.iomode.flags = CORAL_RX;
	    iface0->iface_info.iomode.first_n = hdr->flags & DAG_FLAG_VARLEN ?
		-1 : rlen - payloadstart;
	    break;

	case DAG_TYPE_ATM:
	    dagtype = "ATM";
	    if (!ifcount) ifcount = 1;
	    if (hdr->flags & DAG_FLAG_VARLEN) {
		coral_diag(0, ("%s: no support for DAG ATM format "
		    "with variable length records\n", src->filename));
		errno = CORAL_ERROR;
		return -1;
	    }
	    L2hdrstart = sizeof(coral_dag_erf_hdr_t);
	    payloadstart = sizeof(coral_dag_erf_hdr_t) + sizeof(union atm_hdr);
	    src->dev_config.physical = CORAL_PHY_ATM;
	    /* don't override user's setting of src->dev_config.datalink; and
	     * if user didn't set it, the default will be decided by vpvc. */
	    iface0->iface_info.iomode.flags = CORAL_RX;
	    iface0->iface_type = &coral_iface_type_dag_erf_atm;
	    coral_init_atm_iface(iface0);
	    break;

	case DAG_TYPE_AAL5:
	    dagtype = "AAL5";
	    if (!ifcount) ifcount = 1;
	    payloadstart = sizeof(coral_dag_erf_hdr_t) + sizeof(union atm_hdr);
	    L2hdrstart = sizeof(coral_dag_erf_hdr_t);
	    src->dev_config.physical = CORAL_PHY_ATM;
	    src->dev_config.datalink = CORAL_DLT_ATM_RFC1483;
	    iface0->iface_info.iomode.flags = CORAL_RX;
	    iface0->iface_type = (hdr->flags & DAG_FLAG_VARLEN || ifcount > 1) ?
		&coral_iface_type_dag_erf_varlen :
		&coral_iface_type_dag_erf_novarlen;
	    iface0->iface_info.iomode.first_n = hdr->flags & DAG_FLAG_VARLEN ?
		-1 : rlen - payloadstart;
            coral_init_atm_iface(iface0);
	    break;

	default:
	    coral_diag(0, ("coral: %s: unknown type %d in DAG ERF header.  "
		"If this is a legacy DAG format, "
		"you must specify iomode phy and/or proto.\n",
		src->filename, hdr->type));
	    errno = CORAL_ENOPROTO;
	    return -1;
    }

    if (unsupp) {
	coral_diag(0, ("coral: %s: DAG %s format not supported\n",
	    src->filename, dagtype));
	errno = CORAL_ENOPROTO;
	iface0->iface_type = NULL;
	return -1;
    }
    if (userphy != CORAL_PROTO_UNKNOWN && userphy != src->dev_config.physical) {
	coral_diag(0, ("coral: %s: specified physical type %s "
	    "does not agree with recorded physical type %s\n",
	    src->filename, coral_proto_str(userphy),
	    coral_proto_str(src->dev_config.physical)));
	errno = CORAL_ERROR;
	iface0->iface_type = NULL;
	return -1;
    }
    if (userdlt != CORAL_PROTO_UNKNOWN && userdlt != src->dev_config.datalink) {
	coral_diag(0, ("coral: %s: specified datalink type %s "
	    "does not agree with recorded datalink type %s\n",
	    src->filename, coral_proto_str(userdlt),
	    coral_proto_str(src->dev_config.datalink)));
	errno = CORAL_ERROR;
	iface0->iface_type = NULL;
	return -1;
    }

    if (rlen <= sizeof(coral_dag_erf_hdr_t)) {
	coral_diag(0, ("coral: %s: invalid rlen %d in DAG ERF header.  "
	    "If this is a legacy DAG format, "
	    "you must specify iomode phy and/or proto.\n",
	    src->filename, rlen));
	errno = CORAL_ESYNTAX;
	iface0->iface_type = NULL;
	return -1;
    }

    if (hdr->flags & DAG_FLAG_VARLEN)
	iface0->iface_info.iomode.flags |= CORAL_RX_VARLEN;

    /* make copy of iface_type so we can alter it */
    if (iface0->iface_type)
	iface0->iface_type = objdup(iface0->iface_type);

    if (hdr->type != DAG_TYPE_LEGACY) {
	/* ERF: fill in iface_type offsets */
	erf = 1;
	coral_cell_field_offset(iface0, PAYLOAD) = payloadstart;
	coral_cell_field_offset(iface0, HEADER) = L2hdrstart;
	if (hdr->flags & DAG_FLAG_VARLEN || ifcount > 1) {
	    /* ERF varlen or multi iface */
	    /* TODO: use simplified code for varlen with single iface */
	    src->type = coral_src_type_dagfilevar;
	    if (is_first) {
		iface0->u.vblk.end = src->preread;
		iface0->u.vblk.current = iface0->u.vblk.block = src->ubase;
	    }
	    coral_diag(19, ("%s: dag ERF, varlen and/or multi iface\n",
		src->filename));
	} else {
	    /* ERF novarlen, single iface: fill in iface_type size */
	    coral_cell_size(iface0) = rlen;
	    coral_diag(19, ("%s: dag ERF, single iface, fixed record size %d\n",
		src->filename, coral_cell_size(iface0)));
	}
    }

end_erf:
    coral_diag(2, ("coral: %s: dag type %s\n", src->filename, dagtype));

    if (coral_dag_common_init(src, ifcount, is_first) < 0)
	return -1;
    coral_file_check_iomode(src);

    coral_set_ts(iface0, &hdr->t);
    for (i = 0; i < src->iface_count; i++) {
	if (!cinst[src->id[i]]->iface_info.capture_tv.tv_sec)
	    coral_set_iface_capture_tv(cinst[src->id[i]], &iface0->latest_ts,
		NULL);
    }

    return 0;
}

static int coral_dagfile_close(coral_source_t *src, int final)
{
    void *iface_type = (void*)cinst[src->id[0]]->iface_type;
    int result;

    result = coral_file_close(src, final);
#if 0
    /* coral_close still needs iface_type->close, so we can't free here */
    if (iface_type)
	free(iface_type);
#else
    /* XXX minor memory leak */
#endif
    return result;
}

static coral_iface_t *
coral_dagfile_nextblk(coral_source_t *src, coral_blk_info_t **binfop,
    coral_atm_cell_t **cellp, int endonly)
{
    ssize_t len, need, recsize, blksize;
    coral_iface_t *iface0 = cinst[src->id[0]];

    /* If time-sorted reading api stole ubase, we must alloc a new one. */
    if (!src->ubase) {
        src->ubase = (char *)malloc(sizeof(dag_blk_and_info_t));
        if (!src->ubase) {
            coral_diag(0, ("coral_nextblk: malloc: %s\n", strerror(errno)));
            goto coral_dagfile_nextblk_error;
        }
    }

    endonly = endonly && src->can_seek;
    recsize = coral_cell_size(iface0);
    blksize = (DAG_BLK_SIZE / recsize) * recsize; /* round to record boundary */

retry:
    need = (endonly ? recsize : blksize) - src->preread;
    len = coral_readall(src, src->ubase + src->preread, need);
    if (!len) {
	goto coral_dagfile_nextblk_eof;
    } else if (len < 0) {
	coral_diag(0, ("coral: %s: %s\n", src->filename,
	    coral_strerror(src->file, errno)));
	goto coral_dagfile_nextblk_error;
    }
    len += src->preread;
    src->preread = 0;
    if (recsize > 0 && len % recsize) {
	coral_diag(1, ("warning: %s: unexpected EOF; discarding %d-byte "
	    "truncated record.\n", src->filename, (len % recsize)));
    }
    if (endonly) {
	off_t old, new;
	need = blksize - 2 * recsize;
	old = lseek(src->fd, 0, SEEK_CUR);
	new = lseek(src->fd, need, SEEK_CUR);
	if (new == (off_t)-1) {
            coral_diag(0, ("coral_nextblk: seek: %s\n", strerror(errno)));
            goto coral_dagfile_nextblk_error;
	}
	if (new - old != need)
	    goto reset;
	len = coral_readall(src, src->ubase + blksize - recsize, recsize);
	if (len < 0) {
	    coral_diag(0, ("coral: %s: %s\n", src->filename,
		coral_strerror(src->file, errno)));
	    goto coral_dagfile_nextblk_error;
	} else if (len != recsize) {
	    goto reset;
	}
	len = blksize;
	goto ok;
reset:
	endonly = 0;
	lseek(src->fd, old - recsize, SEEK_SET);
	goto retry;
    }
ok:
    *binfop = &((dag_blk_and_info_t*)src->ubase)->binfo;
    (*binfop)->interface = htonl(0);
    (*binfop)->blk_size = htonl(blksize);
    (*binfop)->cell_count = htonl(len / recsize);
    (*binfop)->tbegin.tv_sec = (*binfop)->tbegin.tv_nsec = htonl(0);
    (*binfop)->tend.tv_sec = (*binfop)->tend.tv_nsec = htonl(0);

    *cellp = (coral_atm_cell_t*)src->ubase;

    errno = 0;
    return cinst[src->id[0]];

coral_dagfile_nextblk_eof:
    errno = 0;
coral_dagfile_nextblk_error:
    *binfop = NULL;
    *cellp = NULL;
    return NULL;
}

static int coral_dagfilevar_read(coral_source_t *src)
{
    ssize_t len, need, blksize, move_size, preread;
    coral_iface_t *iface0;

    if (src->eof) return 0;
    assert(src->ubase);
    blksize = DAG_BLK_SIZE;

    iface0 = cinst[src->id[0]];

    if (iface0->u.vblk.end > blksize / 2) {
	/* move truncated record to beginning of ubase */
	move_size = iface0->u.vblk.block + iface0->u.vblk.end -
	    iface0->u.vblk.current;
	assert(src->preread == 0);
	if (move_size > 0) {
	    /* copying isn't very expensive:  the amount copied is on average
	     * less than half a record per 1MB block. */
	    coral_diag(19, ("%s: copying %d bytes of blk tail\n",
		src->filename, move_size));
	    memmove(src->ubase, iface0->u.vblk.current, move_size);
	}
	iface0->u.vblk.current = src->ubase;
	preread = move_size;
	if (src->pktq_head) {
	    /* don't overwrite unprocessed packets */
	    need = src->pktq_head->rec - iface0->u.vblk.block;
	} else {
	    need = blksize;
	}
	need -= preread;
    } else {
	/* leave unprocessed pkts and truncated record in place */
	/* iface0->u.vblk.current = iface0->u.vblk.current; */
	preread = iface0->u.vblk.end;
	need = blksize - preread;
    }
retry:
    len = coral_readall(src, src->ubase + preread, need);
    if (!len) {
	coral_diag(19, ("%s: eof\n", src->filename));
	if (has_another_file(src)) {
	    src->ubase += preread; /* next compound file will write here */
	    if (!coral_next_compound_file(src)) {
		src->ubase -= preread; /* restore */
		goto error;
	    }
	    src->ubase -= preread; /* restore */
	    iface0->u.vblk.end += src->preread;
	    preread += src->preread;
	    need -= src->preread;
	    src->preread = 0;
	    goto retry;
	}
	goto error;
    } else if (len < 0) {
	coral_diag(0, ("coral: %s: %s\n", src->filename,
	    coral_strerror(src->file, errno)));
	goto error;
    } else if (len < sizeof(coral_dag_erf_hdr_t)) { /* XXX */
	errno = CORAL_ETRUNCBLK;
	goto error;
    }
    coral_diag(19, ("%s: read %d bytes\n", src->filename, len));
    iface0->u.vblk.end = preread + len;
    src->preread = 0;

    return 1;

error:
    coral_mark_eof_src(src);

    iface0->u.vblk.end = 0;
    return 0;
}

/* DAG file with 1 iface and fixed length records:  uses common block-optimized
 * code */
const coral_src_type_t coral_src_type_dagfile = {
    CORAL_TYPE_DAGFILE,
    "dagfile (novarlen, 1 iface)",
    0 /* is_live */,
    0 /* is_buffered */,
    1 /* is_block */,
    0 /* is_interleaved */,
    coral_dagfile_init,
    NULL /* start */,
    NULL /* read_raw */,
    coral_file_read_min,
    coral_file_read_min,
    coral_dagfile_nextblk,
    coral_file_release,
    NULL /* stop */,
    coral_dagfile_close
};

/* DAG file with variable length records:  must use custom code for variable
 * length.
 * (Multiple interfaces with fixed length records could use custom block-
 * optimized code, but that would require writing, testing, and maintaining
 * custom code just for that.)
 */
const coral_src_type_t coral_src_type_dagfilevar = {
    CORAL_TYPE_DAGFILE,
    "dagfile (varlen or multi-iface)",
    0 /* is_live */,
    0 /* is_buffered */,
    0 /* is_block */,
    0 /* is_interleaved */,
    coral_dagfile_init,
    NULL /* start */,
    coral_dagfilevar_read,
    coral_dagerf_read_any,
    coral_dagerf_read_iface,
    NULL /* nextblk */,
    NULL /* release */,
    NULL /* stop */,
    coral_dagfile_close
};

