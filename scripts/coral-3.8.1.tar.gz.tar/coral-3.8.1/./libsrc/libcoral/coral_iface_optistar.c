/*
 * Copyright 2002, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/* High-level functions for Lucent OptiStar interfaces.
 *
 *  $Id: coral_iface_optistar.c,v 1.14 2007/06/06 18:17:53 kkeys Exp $
 *
 */

#include "config.h"
#include "coraldefs.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/param.h>

#include "libcoral.h"
#include "libcoral_priv.h"
#include "coral_clock.h"

#define OPTISTAR_SEC_PER_TICK	    12.5e-9


static const char RCSid[] = "$Id: coral_iface_optistar.c,v 1.14 2007/06/06 18:17:53 kkeys Exp $";

/* always big endian */
static inline void optistar_clock_order(const coral_iface_t *iface,
    const coral_timestamp_t *src, coral_timestamp_t *dst)
{
    dst->i[0] = crl_betohl(src->i[0]);
    dst->i[1] = crl_betohl(src->i[1]);
}

static inline double coral_optistar_clock_double(const coral_iface_t *iface,
    const coral_timestamp_t *t)
{
    coral_timestamp_t to;

    optistar_clock_order(iface, t, &to);
    return (4294967296.0 * to.i[0] + to.i[1]) * OPTISTAR_SEC_PER_TICK;
}

static inline void coral_optistar_clock_timespec(const coral_iface_t *iface,
    const coral_timestamp_t *t, struct timespec *tspec)
{
    double d;

    d = coral_optistar_clock_double(iface, t);
    tspec->tv_sec = d;
    tspec->tv_nsec = (d - tspec->tv_sec) * 1000000000 + 0.5;
}


static void optistar_iface_init(coral_iface_t *iface)
{
    iface->time_is_normal = 0;
}

static int optistar_consume(coral_iface_t *iface, int want)
{
    iface->src->type.read_min(iface);
    return iface->have_data;
}


const coral_iface_type_t coral_iface_type_optistar = {
    { -1, -1, -1, -1, -1, -1, -1, -1 }, /* doesn't have ATM cells */
    "optistar",
    CORAL_API_PKT,
    optistar_iface_init,
    optistar_clock_order,
    coral_optistar_clock_double,
    coral_optistar_clock_timespec,
    NULL /* correct_clock */,
    NULL /* clock_native */,
    optistar_consume,
    NULL /* consume_pkt */,
    NULL /* prep_pkt */,
    NULL /* update_pkt_stats */,
    NULL /* close */,
    { { CORAL_RX, 124 }, 0, CORAL_PROTO_UNKNOWN, CORAL_PROTO_UNKNOWN, NULL }
};

