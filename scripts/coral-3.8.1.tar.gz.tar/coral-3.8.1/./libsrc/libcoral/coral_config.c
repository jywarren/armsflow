/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

static const char RCSid[]="$Id: coral_config.c,v 1.161 2007/06/06 18:17:53 kkeys Exp $";

#include "config.h"
#include "coraldefs.h"
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>  /* open(), for cryptopan */

#include "libcoral.h"
#include "libcoral_priv.h"

#define CORAL_DEFAULT_CONFIG_INITIALIZER \
{ \
    CORAL_MAXOPEN,			/* maxsrc */ \
    { \
	{ CORAL_RX_UNKNOWN, -1 },	/* iomode */ \
	0,				/* bandwidth */ \
	CORAL_PROTO_UNKNOWN,		/* physical */ \
	CORAL_PROTO_UNKNOWN,		/* datalink */ \
	NULL,				/* firmware */ \
    },					/* dev_config */ \
    CORAL_OPT_PARTIAL_PKT | CORAL_OPT_NORMALIZE_TIME,	/* flags */ \
    -1,					/* duration */ \
    { -1, -1 }				/* interval */ \
    /* remaining fields default to 0 */ \
}

const coral_config_t coral_default_config = CORAL_DEFAULT_CONFIG_INITIALIZER;
coral_config_t coral_config = CORAL_DEFAULT_CONFIG_INITIALIZER;
/* We use a macro initializer because at least some versions of gcc don't allow:
   coral_config_t coral_config = coral_default_config;
 */

static const char *config_filename = NULL;
static int config_linenum = 0;
static const struct timeval tvzero = { 0, 0 };

static struct { const char *name; int32_t bw; } bwtab[] = {
    { "unknown",	0 },
    { "OC3c",		KBPS_OC3c },
    { "OC12c",		KBPS_OC12c },
    { "OC48c",		KBPS_OC48c },
    { "ETH10M",		KBPS_ETH10M },
    { "ETH100M",	KBPS_ETH100M },
    { "ETH1000M",	KBPS_ETH1000M },
    { NULL,		-1 }
};

#define coral_config_diag(level, args) \
    do { \
	if (config_filename) coral_diag(level, ("%s: ", config_filename)); \
	if (config_linenum) coral_diag(level, ("%d: ", config_linenum)); \
	coral_diag(level, args); \
    } while (0)

const char *coral_bandwidth_fmt(int32_t bw)
{
    static char buf[32];
    int i = 0;
    for (i = 0; bwtab[i].name && bwtab[i].bw != bw; i++);
    if (bwtab[i].name)
	sprintf(buf, "%s (%" PRIu32 " Kbps)", bwtab[i].name, bw);
    else
	sprintf(buf, "%" PRIu32 " Kbps", bw);
    return buf;
}

static uint32_t coral_str_to_bandwidth(const char *str)
{
    int i = 0;
    for (i = 0; bwtab[i].name && cstrcmp(bwtab[i].name, str) != 0; i++);
    return bwtab[i].bw;
}

void coral_config_defaults(void)
{
    coral_config = coral_default_config;
}

int coral_set_api(int api)
{
    if (coral_config.api != CORAL_API_NONE)
	return -1;
    coral_config.api = (api & CORAL_API_WRITE);
    switch (api & ~CORAL_API_WRITE) {
	case CORAL_API_BLOCK:
	case CORAL_API_CELL:
	case CORAL_API_PKT:
	    coral_config.api |= api;
	    return 0;
	default:
	    return -1;
    }
}

int coral_set_max_sources(int n)
{
    if (n < 0 || n > CORAL_MAXOPEN) {
	errno = EINVAL;
	return -1;
    }
    coral_config.maxsrc = n;
    return 0;
}

int coral_get_max_sources(void)
{
    return coral_config.maxsrc;
}

static int set_iomode(coral_io_mode_t *iomode, int off, int on, int first)
{
    if (on & CORAL_RX_UNKNOWN) {
	iomode->flags = CORAL_RX_UNKNOWN;
	iomode->first_n = 0;
    } else {
	if (first >= 0) {
	    iomode->first_n = first;
	    iomode->flags &= ~CORAL_RX_USER_ALL;
	}
	iomode->flags &= ~(off | CORAL_RX_UNKNOWN);
	iomode->flags |= on;
    }
    return 0;
}

int coral_set_iomode(int off, int on, int first, int fixed)
{
    if (fixed >= 0)
	coral_config.iomode_is_fixed = fixed;
    return set_iomode(&coral_config.dev_config.iomode, off, on, first);
}

const coral_io_mode_t *coral_get_iomode(void)
{
    return &coral_config.dev_config.iomode;
}

int coral_source_set_iomode(coral_source_t *src, int off, int on, int first)
{
    validate_unopen_src(src, "coral_source_set_iomode", -1);
    return set_iomode(&src->dev_config.iomode, off, on, first);
}

int coral_source_set_iomode_all(int off, int on, int first)
{
    int sd;

    for (sd = 0; sd < CORAL_MAXOPEN; sd++) {
	if (csource[sd])
	    coral_source_set_iomode(csource[sd], off, on, first);
    }
    return 0;
}

const coral_io_mode_t *coral_source_get_iomode(const coral_source_t *src)
{
    return &src->dev_config.iomode;
}

const coral_io_mode_t *coral_iface_get_iomode(const coral_iface_t *iface)
{
    return &iface->iface_info.iomode;
}

int coral_source_set_firmware(coral_source_t *src, const char *firmware)
{
    validate_unopen_src(src, "coral_source_set_firmware", -1);
    if (src->dev_config.firmware)
	free((void*)src->dev_config.firmware);
    src->dev_config.firmware = coral_filename(firmware, NULL, PATH_MAX);
    return src->dev_config.firmware ? 0 : -1;
}

int coral_source_set_firmware_all(const char *firmware)
{
    int sd;

    for (sd = 0; sd < CORAL_MAXOPEN; sd++) {
	if (csource[sd])
	    coral_source_set_firmware(csource[sd], firmware);
    }
    return 0;
}

int coral_source_set_special_firmware(coral_source_t *src, const char *which,
    const char *name)
{
    const char **pp;
    validate_unopen_src(src, "coral_source_set_special_firmware", -1);
    if (!which || strcmp(which, "firmware") == 0)
	pp = &src->dev_config.firmware;
    else
	return -1;
    if (*pp)
	free((void*)*pp);
    *pp = coral_filename(name, NULL, PATH_MAX);
    return *pp ? 0 : -1;
}

int coral_source_set_special_firmware_all(const char *which, const char *name)
{
    int sd;

    for (sd = 0; sd < CORAL_MAXOPEN; sd++) {
	if (csource[sd])
	    coral_source_set_special_firmware(csource[sd], which, name);
    }
    return 0;
}

int coral_get_options(void)
{
    return coral_config.flags;
}

int coral_set_options(int off, int on)
{
    coral_config.flags &= ~off;
    coral_config.flags |= on;
    coral_read_cell_all_common = (coral_config.flags & CORAL_OPT_SORT_TIME) ?
	coral_read_cell_sorttime : coral_read_cell_natural;
    return 0;
}

FILE *coral_get_errfile(void)
{
    return coral_errfile ? coral_errfile : stderr;
}

int coral_set_errfile(FILE *file)
{
    if (coral_errfile == file)
	return 0;
    if (coral_config.errfile_is_private) {
	if (coral_config.err_rf) {
	    coral_rf_close(coral_config.err_rf);
	    coral_config.err_rf = NULL;
	} else if (coral_errfile != stderr) {
	    fclose(coral_errfile);
	}
    }
    coral_errfile = file;
    coral_config.errfile_is_private = 0;
    return 0;
}

int coral_set_errfilename(const char *filename)
{
    char expanded[PATH_MAX];

    if (coral_config.errfile_is_private && coral_errfile &&
	coral_errfile != stderr)
	    fclose(coral_errfile);
    if (!filename) {
	return coral_set_errfile(NULL);
    } else if (strcmp(filename, "-") == 0) {
	return coral_set_errfile(stdout);
    }
    if (!coral_filename(filename, expanded, sizeof(expanded)))
	return -1;
    coral_config.errfile_is_private = 1;
    if (strchr(expanded, '%')) {
	coral_config.err_rf = coral_rf_open_file(&coral_errfile, expanded, NULL,
	    0);
	if (!coral_config.err_rf) return -1;
	coral_errfile = NULL; /* will use stderr until an interval begins */
    } else {
	coral_config.err_rf = NULL;
	coral_errfile = fopen(expanded, "w");
	if (!coral_errfile) {
	    coral_config_diag(0, ("%s: %s\n", expanded, strerror(errno)));
	    return -1;
	}
    }
    return 0;
}

int coral_rotate_errfile(const struct timeval *tv)
{
    if (!coral_config.err_rf) return 0;
    coral_rf_end(coral_config.err_rf);
    if (coral_rf_start(coral_config.err_rf, tv) < 0) {
	coral_set_errfile(stderr);
	return -1;
    }
    return 0;
}

int coral_get_verbosity(void)
{
    return coral_verbosity;
}

int coral_set_verbosity(int verbosity)
{
    coral_verbosity = verbosity;
    return 0;
}

const char *coral_get_comment(void)
{
    return coral_config.comment;
}

int coral_set_comment(const char *comment)
{
    if (coral_config.comment)
	free(coral_config.comment);
    coral_config.comment = comment ? strdup(comment) : NULL;
    return 0;
}

int coral_get_interval(struct timeval *interval)
{
    *interval = coral_config.interval;
    return coral_config.interval.tv_sec < 0 ? -1 : 0;
}

int coral_set_interval(const struct timeval *interval)
{
    coral_config.interval = *interval;
    return 0;
}

long coral_get_duration(void)
{
    return coral_config.duration < 0 ? 0 : coral_config.duration;
}

int coral_set_duration(long d)
{
    coral_config.duration = d;
    return 0;
}

int coral_get_mintime(struct timeval *mintime)
{
    *mintime = coral_config.mintime;
    return coral_config.mintime.tv_sec < 0 ? -1 : 0;
}

int coral_set_mintime(const struct timeval *mintime)
{
    coral_config.mintime = *mintime;
    return 0;
}

int coral_get_maxtime(struct timeval *maxtime)
{
    *maxtime = coral_config.maxtime;
    return coral_config.maxtime.tv_sec < 0 ? -1 : 0;
}

int coral_set_maxtime(const struct timeval *maxtime)
{
    coral_config.maxtime = *maxtime;
    return 0;
}

int coral_set_gzip(const char *str)
{
    if (coral_config.gzip) free((void*)coral_config.gzip);
    coral_config.gzip = str ? strdup(str) : str;
    return 0;
}

coral_anon_t *coral_get_anonymizer(void)
{
    coral_anon_t *anon = malloc(sizeof(*anon));
    *anon = coral_config.anon;
    return anon;
}

int coral_set_anonymizer(coral_anon_t *anon)
{
    if (!anon)
	memset(&coral_config.anon, 0, sizeof(*anon));
    else
	coral_config.anon = *anon;
    return 0;
}

int coral_set_max_pkts(uint64_t n) { coral_config.max_pkts = n; return 0; }
int coral_set_max_blks(uint64_t n) { coral_config.max_blks = n; return 0; }
int coral_set_max_cells(uint64_t n) { coral_config.max_cells = n; return 0; }

uint64_t coral_get_max_pkts(void) { return coral_config.max_pkts; }
uint64_t coral_get_max_blks(void) { return coral_config.max_blks; }
uint64_t coral_get_max_cells(void) { return coral_config.max_cells; }

int coral_get_source_count(void)
{
    return coral_config.source_count;
}

/* returns pointer to beginning of first token in *strp, writes '\0' at
 * end of token, and advances *strp to character after the end of token
 * (or NULL if end of string is reached).
 */
char *coral_strsep(char **strp, const char *delim)
{
    char *start;

    if (!strp || !*strp) return NULL;
    while (isspace(**strp)) ++*strp;
    start = *strp;
    if (!*start) return NULL;
    *strp += strcspn(*strp, delim);
    if (**strp) {
	**strp = '\0';
	++*strp;
    } else {
	*strp = NULL;
    }
    return start;
}

void coral_delete_proto_rules(coral_source_t *src, coral_iface_t *iface)
{
    coral_proto_rule_list_t *list;
    coral_proto_rulenode_t *node;

    list = iface ? &iface->proto_rules :
	src ? &src->proto_rules :
	&coral_proto_rules;

    while ((node = list->head)) {
	list->head = ((coral_proto_rulenode_t*)list->head)->next;
	free(node);
    }
    list->head = list->tail = NULL;
}

int coral_set_proto_rule(coral_source_t *src, coral_iface_t *iface, int op,
    uint32_t subif, uint32_t subifmask, coral_protocol_t proto)
{
    coral_proto_rulenode_t *node = NULL;
    coral_proto_rule_list_t *list;
    coral_protocol_t physical = CORAL_PROTO_UNKNOWN;

    if ((op == 'd') && !(coral_config.api & (CORAL_API_CELL|CORAL_API_PKT))) {
	coral_config_diag(0, ("deny rules are not allowed.\n"));
	return -1;
    }

    physical = iface ? iface->iface_info.physical :
	src ? src->dev_config.physical :
	coral_config.dev_config.physical;
    if (physical == CORAL_PROTO_UNKNOWN)
	physical = CORAL_PHY_ATM;

    if (subifmask && physical != CORAL_PHY_ATM) {
	coral_config_diag(0, ("illegal subinterface specification.\n"));
	return -1;
    }

    node = malloc(sizeof(*node));
    if (!node) {
	coral_config_diag(0, ("set_proto_rule: %s\n", strerror(errno)));
	return -1;
    }

    node->rule.subif = subif;
    node->rule.subifmask = subifmask;
    node->rule.allow = (op != 'd');
    node->rule.protocol = proto;

    node->next = NULL;
    list = iface ? &iface->proto_rules :
	src ? &src->proto_rules :
	&coral_proto_rules;
    if (list->tail)
	list->tail = ((coral_proto_rulenode_t *)list->tail)->next = node;
    else
	list->tail = list->head = node;
    return 0;
}

static int parse_rule(coral_source_t *src, const char *name, char *cmd)
{
    char *vpstr, *vcstr, *subifstr, *protostr, *arg1, *arg2;
    const char *syntax = "error";
    coral_dev_config_t *dev_config;
    uint32_t n;
    uint32_t subif = 0, subifmask = 0;

    dev_config = src ? &src->dev_config : &coral_config.dev_config;

    switch (*name) {
    case 'a': syntax = "allow=<vpi>:<vci>[=<protocol>]";  break;
    case 'd': syntax = "deny=<vpi>:<vci>[=<protocol>]";   break;
    case 'p': syntax = "proto=[<vpi>:<vci>=]<protocol>";  break;
    }

#define reqtoken(token, src, delim, msg) \
    do { \
	token = coral_strsep(src, delim); \
	if (!token) { \
	    coral_config_diag(0, ("Syntax error.  Expected:  %s\n", msg)); \
	    return -1; \
	} \
    } while (0)

    reqtoken(arg1, &cmd, "= \t\n", syntax);
    arg2 = coral_strsep(&cmd, "\n");
    if (*name == 'p' && !arg2) {
	/* No subif was given, so don't make a rule, just set datalink. */
	const coral_protolabel_t *pl;
	protostr = arg1;
	if (!(pl = coral_protolabel_by_name(protostr))) {
	    coral_config_diag(0, ("unknown protocol: %s\n", protostr));
	    return -1;
	} else if (!pl->proto_ok) {
	    coral_config_diag(1, ("warning: probable nonsense protocol: %s\n",
		protostr));
	}
	dev_config->datalink = pl->id;
	return 0;
    }
    subifstr = arg1;
    protostr = arg2;

    /* TODO: This should be generalized to inverse coral_fmt_subif */

    vpstr = subifstr;
    vcstr = strchr(subifstr, ':');
    if (!vcstr) goto rule_error;
    *(vcstr++) = '\0';

    if (strcmp(vpstr, "*") != 0) {
	n = strtol(vpstr, &vpstr, 0);
	if (n < 0 || n > 0xFF || *vpstr) {
	    coral_config_diag(0, ("%s: invalid vpi\n", name));
	    goto rule_exit;
	}
	set_vpvc_vp(subif, n);
	set_vpvc_vp(subifmask, -1);
    }

    if (strcmp(vcstr, "*") != 0) {
	n = strtol(vcstr, &vcstr, 0);
	if (n < 0 || n > 0xFFFF || *vcstr) {
	    coral_config_diag(0, ("%s: invalid vci\n", name));
	    goto rule_exit;
	}
	set_vpvc_vc(subif, n);
	set_vpvc_vc(subifmask, -1);
    }

    return coral_set_proto_rule(src, NULL, *name, subif, subifmask,
	protostr ? coral_proto_id(protostr) : CORAL_PROTO_UNKNOWN);

rule_error:
    coral_config_diag(0, ("Syntax error.  Expected:  %s\n", syntax));
rule_exit:
    return -1;

#undef reqtoken
}

/* Anything not set here will be set to a default value in coral_open()
 * or the device-specific init function.
 */
static int parse_iomode(char *str, coral_source_t *src)
{
    char *token, *arg;
    int not;
    int on = 0, off = 0;
    int first = -1, errors = 0;
    coral_dev_config_t *dev_config;

    dev_config = src ? &src->dev_config : &coral_config.dev_config;

    while ((token = coral_strsep(&str, ", \t\n"))) {
	if ((not = (*token == '!')))
	    token++;
	if (strcmp(token, "tx") == 0) {
	    *(not ? &off : &on) |= CORAL_TX;
	} else if (strcmp(token, "rx") == 0) {
	    *(not ? &off : &on) |= CORAL_RX;
	} else if (strcmp(token, "last") == 0) {
	    *(not ? &off : &on) |= CORAL_RX_LAST;
	} else if (strcmp(token, "user") == 0) {
	    *(not ? &off : &on) |= CORAL_RX_USER_ALL;
	} else if (strcmp(token, "idle") == 0) {
	    *(not ? &off : &on) |= CORAL_RX_IDLE;
	} else if (strcmp(token, "ctrl") == 0) {
	    *(not ? &off : &on) |= CORAL_RX_OAM;
	} else if (strcmp(token, "echo") == 0) {
	    *(not ? &off : &on) |= CORAL_RX_ECHO;
	} else if (strcmp(token, "varlen") == 0) {
	    *(not ? &off : &on) |= CORAL_RX_VARLEN;
	} else if (strcmp(token, "all") == 0) {
	    *(not ? &off : &on) =
		CORAL_RX_USER_ALL | CORAL_RX_OAM | CORAL_RX_IDLE;
	} else if (strcmp(token, "vlan") == 0) {
	    dev_config->vlan_hack = !not;
	} else if ((arg = strchr(token, '='))) {
	    *arg++ = '\0';
	    if (not) {
		errors++;  /* "!" can not be used with these */
	    } else if (strcmp(token, "first") == 0) {
		if (!isdigit(*arg)) {
		    coral_config_diag(0,
			("Bad 'first' specification '%s'.\n", arg));
		    return -1;
		}
		first = atoi(arg);
	    } else if (strcmp(token, "fw") == 0) {
		if (dev_config->firmware)
		    free((void*)dev_config->firmware);
		dev_config->firmware = coral_filename(arg, NULL, PATH_MAX);
	    } else if ((strcmp(token, "bandwidth") == 0) ||
		(strcmp(token, "bw") == 0))
	    {
		if ((dev_config->bandwidth = coral_str_to_bandwidth(arg)) < 0) {
		    int i;
		    coral_config_diag(0,
			("Bad bandwidth specification '%s'.\n", arg));
		    coral_config_diag(0, ("Bandwidth must be one of: "));
		    for (i = 0; bwtab[i].name; i++)
			coral_config_diag(0, (" %s", bwtab[i].name));
		    coral_config_diag(0, ("\n"));
		    return -1;
		}
	    } else if (strcmp(token, "physical") == 0 ||
		strcmp(token, "phy") == 0)
	    {
		dev_config->physical = coral_proto_id(arg);
		if (coral_proto_layer(dev_config->physical) != 1 &&
		    dev_config->physical != CORAL_PROTO_UNKNOWN)
		{
		    coral_config_diag(0, ("bad physical layer '%s'\n", arg));
		    return -1;
		}
	    } else if (strcmp(token, "proto") == 0 ||
		strcmp(token, "allow") == 0 || strcmp(token, "deny") == 0)
	    {
		if (parse_rule(src, token, arg) < 0)
		    return -1;
	    } else if (strcmp(token, "nif") == 0) {
		if (!isdigit(*arg)) {
		    coral_config_diag(0,
			("Bad 'nif' specification '%s'.\n", arg));
		    return -1;
		}
		dev_config->num_ifaces = atoi(arg);
	    } else {
		errors++; 
	    }
	} else if (isdigit(*token)) {
	    /* "<N>" is shorthand for "first=<N>" */
	    first = atoi(token);
	} else {
	    errors++; 
	}
	if (errors) {
	    coral_config_diag(0, ("bad iomode option '%s'\n", token));
	    return -1;
	}
    }

    if (first >= 0 || off || on) {
	/* first, off, and on can't be changed if fixed, but other parts of
	 * dev_config can be. */
	if (coral_config.iomode_is_fixed) {
	    char iomode_buffer[CORAL_FORMAT_IOMODE_LEN];
	    coral_format_iomode(iomode_buffer, &coral_config.dev_config.iomode);
	    coral_config_diag(0,
		("This program uses iomode '%s', it is not configurable.\n",
		iomode_buffer));
	    return -1;
	}
	return set_iomode(&dev_config->iomode, off, on, first);
    }
    return 0;
}

const char *coral_get_pcap_filter(void)
{
    if (!(coral_config.api & CORAL_API_PKT))
	return NULL;
#ifdef HAVE_BPF_FILTER
    errno = 0;
    return coral_config.bpf_filter_text;
#else
    errno = ENOSYS; /* ? */
    return NULL;
#endif
}

const char *coral_get_pcap_ipfilter(void)
{
    if (!(coral_config.api & CORAL_API_PKT))
	return NULL;
#ifdef HAVE_BPF_FILTER
    errno = 0;
    return coral_config.bpf_ipfilter_text;
#else
    errno = ENOSYS; /* ? */
    return NULL;
#endif
}

const char *coral_get_pcap_prefilter(void)
{
    if (!(coral_config.api & CORAL_API_PKT))
	return NULL;
#ifdef HAVE_BPF_FILTER
    errno = 0;
    return coral_config.bpf_prefilter_text;
#else
    errno = ENOSYS; /* ? */
    return NULL;
#endif
}

static int coral_add_pcap_filter_text(const char *expr, char **textp)
{
    if (!(coral_config.api & CORAL_API_PKT)) {
	coral_config_diag(0, ("user-defined pcap filters are not allowed.\n"));
	return -1;
    }
#ifdef HAVE_BPF_FILTER
    if (!expr) {
	if (*textp) {
	    free(*textp);
	    *textp = NULL;
	}
    } else if (*textp) {
	char *old = *textp;
	*textp = malloc(strlen(old) + strlen(expr) + sizeof("() and ()"));
	if (!*textp) {
	    *textp = old;
	    return -1;
	}
	sprintf(*textp, "(%s) and (%s)", old, expr);
	free(old);
    } else {
	*textp = strdup(expr);
	if (!*textp)
	    return -1;
    }
    coral_config_diag(3, ("pcap %sfilter: %s\n",
	textp == &coral_config.bpf_filter_text ? "pre" : "",
	*textp ?  *textp : "[none]"));
    return 0;
#else
    if (!expr) return 0;
    coral_config_diag(0, ("Pcap filters are not supported in this instance of "
	"CoralReef.\n"));
    errno = ENOSYS; /* ? */
    return -1;
#endif
}

int coral_add_pcap_filter(const char *expr)
{
    return coral_add_pcap_filter_text(expr, &coral_config.bpf_filter_text);
}

int coral_add_pcap_ipfilter(const char *expr)
{
    return coral_add_pcap_filter_text(expr, &coral_config.bpf_ipfilter_text);
}

int coral_add_pcap_prefilter(const char *expr)
{
    return coral_add_pcap_filter_text(expr, &coral_config.bpf_prefilter_text);
}

/* return 0 for success, -1 for failure */
static int parse_tv(char *src, struct timeval *tv, const char *label)
{
    int n;
    char *start = src;

    tv->tv_usec = 0;
    tv->tv_sec = strtol(src, &src, 10);
    if (*src == ':') {
	if (tv->tv_sec > 596523) /* will wrap when *3600 */
	    goto time_overflow;
	tv->tv_sec *= 3600;
	src++;
	if (isdigit(*src)) {
	    long fieldval;
	    fieldval = strtol(src, &src, 10);
	    if (fieldval > 35791394) /* will wrap when *60 */
		goto time_overflow;
	    fieldval *= 60;
	    tv->tv_sec += fieldval;
	    if (tv->tv_sec < 0) /* wrapped */
		goto time_overflow;
	    if (*src == ':') {
		++src;
		if (isdigit(*src)) {
		    fieldval = strtol(src, &src, 10);
		    if (fieldval == LONG_MAX && errno) /* wrapped */
			goto time_overflow;
		    tv->tv_sec += fieldval;
		    if (tv->tv_sec < 0) /* wrapped */
			goto time_overflow;
		}
		goto time_fraction;
	    }
	}
	goto time_end;
    }

time_fraction:
    if (*src == '.') {
	start = ++src;
	tv->tv_usec = strtol(src, &src, 10);
	n = 6 - (src - start);
#if 0
	tv->tv_usec *= pow(10, n);  /* this would require linking with -lm */
#else
	for ( ; n > 0; n--)
	    tv->tv_usec *= 10;
	for ( ; n < 0; n++)
	    tv->tv_usec /= 10;
#endif
    } else {
	tv->tv_usec = 0;
    }

time_end:
    if (*src) {
	coral_diag(0, ("trailing garbage after %s value: %s\n", label, src));
	return -1;
    }
    return 0;

time_overflow:
    coral_diag(0, ("%s value too large: %s\n", label, start));
    return -1;
}

int coral_config_command(const char *command)
{
    char *token, *arg;
    coral_source_t *src;
    int result = 0;
    char *copy = NULL, *str;
    char buf[80];

#define tokmatch(token, full, abbr) \
    (strcmp(token, full) == 0 || strcmp(token, abbr) == 0)

/* fail if required token is not present */
#define reqtoken(token, srcp, delim, msg) \
    do { \
	token = coral_strsep(srcp, delim); \
	if (!token) { \
	    coral_config_diag(0, ("Syntax error.  Expected:  %s\n", msg)); \
	    result = -1; \
	    goto coral_config_command_exit; \
	} \
    } while (0)

/* fail if a token is present */
#define notoken(src, msg) \
    do { \
	if (src && *src) { \
	    coral_config_diag(0, ("Syntax error.  Expected:  %s\n", msg)); \
	    result = -1; \
	    goto coral_config_command_exit; \
	} \
    } while (0)

/* fail if required condition is not true */
#define reqcond(expr, desc) \
    do { \
	if (!(expr)) { \
	    coral_config_diag(0, (desc " is not allowed.\n")); \
	    return -1; \
	} \
    } while (0)

/* fail if required API is not set */
#define reqapi(req, desc) reqcond(coral_config.api & (req), desc)

    if (*command == '#') {
	/* comment */
	goto coral_config_command_exit;
    }

    str = copy = strdup(command);
    token = coral_strsep(&str, " =\t\n");
    if (!token) {
	/* blank command */
	goto coral_config_command_exit;
    }

    coral_config_diag(3, ("coral command: \"%s\"\n", command));

    if (strcmp(token, "version") == 0) {
	notoken(str, token);
	coral_printf("CoralReef package version: %s\n",
	    CORALREEF_LONG_VERSION);
	coral_printf("current CRL file format version: %s\n",
	    coral_file_version(NULL));
#if defined(HAVE_PCAP_LIB_VERSION)
	coral_printf("libpcap version: %s\n", pcap_lib_version());
#elif defined(HAVE_LIBPCAP)
	coral_printf("libpcap version: %s\n", "unknown");
#endif
	coral_printf("\n");

    } else if (strcmp(token, "iomode") == 0 || strcmp(token, "m") == 0) {
	if (parse_iomode(str, NULL) < 0) {
	    result = -1;
	    goto coral_config_command_exit;
	}
	coral_format_iomode(buf, &coral_config.dev_config.iomode);
	coral_diag(6, ("global iomode: %s\n", buf));

    } else if (tokmatch(token, "source", "src")) {
	reqtoken(token, &str, ", \t\n", "source <filename> [<option>]...");

	src = coral_new_source(token);
	if (!src) {
	    result = -1;
	    goto coral_config_command_exit;
	}

	if (parse_iomode(str, src) < 0) {
	    result = -1;
	    goto coral_config_command_exit;
	}
	coral_format_iomode(buf, &src->dev_config.iomode);
	coral_diag(6, ("%s iomode: %s\n", src->name, &src->dev_config.iomode));

    } else if (strcmp(token, "proto") == 0 || strcmp(token, "allow") == 0 ||
	strcmp(token, "deny") == 0)
    {
	if ((result = parse_rule(NULL, token, str)) < 0)
	    goto coral_config_command_exit;

    } else if (tokmatch(token, "config", "f")) {
	reqtoken(arg, &str, "\n", "{config|f}=<filename>");
	if ((result = coral_config_file(arg)) < 0)
	    goto coral_config_command_exit;

    } else if (strcmp(token, "comment") == 0) {
	reqtoken(arg, &str, "\n", "comment=<text>");
	coral_set_comment(arg);

    } else if (strcmp(token, "filter") == 0) {
	reqcond(!(coral_config.flags & CORAL_OPT_NO_FILTER), "a pcap filter");
	reqtoken(arg, &str, "\n", "filter=<text>");
	if ((result = coral_add_pcap_filter(arg)) < 0)
	    goto coral_config_command_exit;

    } else if (strcmp(token, "ipfilter") == 0) {
	reqcond(!(coral_config.flags & CORAL_OPT_NO_FILTER), "a pcap filter");
	reqtoken(arg, &str, "\n", "ipfilter=<text>");
	if ((result = coral_add_pcap_ipfilter(arg)) < 0)
	    goto coral_config_command_exit;

    } else if (strcmp(token, "prefilter") == 0) {
	reqcond(!(coral_config.flags & CORAL_OPT_NO_FILTER), "a pcap filter");
	reqtoken(arg, &str, "\n", "prefilter=<text>");
	if ((result = coral_add_pcap_prefilter(arg)) < 0)
	    goto coral_config_command_exit;

    } else if (tokmatch(token, "interval", "i") &&
	timercmp(&coral_config.interval, &tvzero, >=))
    {
	reqtoken(arg, &str, "\n", "i[nterval]=<interval>");
	if ((result = parse_tv(arg, &coral_config.interval, "interval")) < 0)
	    goto coral_config_command_exit;
	coral_diag(6, ("interval: %d.%06d\n",
	    coral_config.interval.tv_sec, coral_config.interval.tv_usec));

    } else if (tokmatch(token, "duration", "d") && coral_config.duration >= 0) {
	struct timeval tv;
	reqtoken(arg, &str, "\n", "d[uration]=<duration>");
	if ((result = parse_tv(arg, &tv, "duration")) < 0)
	    goto coral_config_command_exit;
	if (tv.tv_usec) {
	    coral_diag(0, ("duration does not allow fractional seconds\n"));
	    result = -1;
	    goto coral_config_command_exit;
	}
	coral_config.duration = tv.tv_sec;
	coral_diag(6, ("duration: %d\n", coral_config.duration));

    } else if (strcmp(token, "mintime") == 0 && coral_config.duration >= 0) {
	reqtoken(arg, &str, "\n", "mintime=<time>");
	if ((result = parse_tv(arg, &coral_config.mintime, "mintime")) < 0)
	    goto coral_config_command_exit;
	coral_diag(6, ("mintime: %d.%06d\n",
	    coral_config.mintime.tv_sec, coral_config.mintime.tv_usec));

    } else if (strcmp(token, "maxtime") == 0 && coral_config.duration >= 0) {
	reqtoken(arg, &str, "\n", "maxtime=<time>");
	if ((result = parse_tv(arg, &coral_config.maxtime, "maxtime")) < 0)
	    goto coral_config_command_exit;
	coral_diag(6, ("maxtime: %d.%06d\n",
	    coral_config.maxtime.tv_sec, coral_config.maxtime.tv_usec));

    } else if (tokmatch(token, "packets", "p")) {
	reqapi(CORAL_API_PKT, "a packet count");
	reqtoken(arg, &str, "\n", "p[ackets]=<N>");
	sscanf(arg, "%" SCNu64, &coral_config.max_pkts);

    } else if (tokmatch(token, "cells", "c")) {
	reqapi(CORAL_API_CELL, "a cell count");
	reqtoken(arg, &str, "\n", "c[ells]=<N>");
	sscanf(arg, "%" SCNu64, &coral_config.max_cells);

    } else if (tokmatch(token, "blocks", "b")) {
	reqapi(CORAL_API_BLOCK | CORAL_API_CELL, "a block count");
	reqtoken(arg, &str, "\n", "b[locks]=<N>");
	sscanf(arg, "%" SCNu64, &coral_config.max_blks);

    } else if (tokmatch(token, "verbosity", "v")) {
	reqtoken(arg, &str, "\n", "v[erbosity]=<verbosity>");
	coral_verbosity = atoi(arg);

    } else if (tokmatch(token, "normalize", "norm")) {
	if (!(arg = coral_strsep(&str, "\n")) || !!atoi(arg))
	    coral_set_options(0, CORAL_OPT_NORMALIZE_TIME);
	else
	    coral_set_options(CORAL_OPT_NORMALIZE_TIME, 0);

    } else if (tokmatch(token, "alignint", "ai") &&
	timercmp(&coral_config.interval, &tvzero, >=))
    {
	if (!(arg = coral_strsep(&str, "\n")) || !!atoi(arg))
	    coral_set_options(0, CORAL_OPT_ALIGNINT);
	else
	    coral_set_options(CORAL_OPT_ALIGNINT, 0);

    } else if (tokmatch(token, "polltime", "poll")) {
	reqtoken(arg, &str, "\n", "poll[time]=<microseconds>");
	coral_config.user_polltime = 1;
	coral_config.polltime = atoi(arg);

    } else if (tokmatch(token, "errfile", "e")) {
	reqtoken(arg, &str, "\n", "e[rrfile]=<filename>");
	coral_set_errfilename(arg);

    } else if (tokmatch(token, "sort", "sort")) {
	notoken(str, token);
	coral_set_options(0, CORAL_OPT_SORT_TIME);

    } else if (tokmatch(token, "ignore_time_err", "ite")) {
	notoken(str, token);
	coral_set_options(0, CORAL_OPT_IGNORE_TIME_ERR);

    } else if (tokmatch(token, "gzip", "gz")) {
	reqapi(CORAL_API_WRITE, "gzip");
	coral_set_gzip(str ? str : "");

    } else if (tokmatch(token, "anonymize", "anon")) {
	int errors = 0, bits = 32;
	coral_anon_t anon;
	char filename[PATH_MAX] = "/dev/random";

	reqapi(CORAL_API_PKT, "anonymize");
	memset(&anon, 0, sizeof(anon));

	if (!str) {
	    anon.alg = CORAL_ANON_ALG_CRYPTOPAN;
	} else {
	    token = coral_strsep(&str, ",");
	    if (strcmp(token, "ipzero") == 0) {
		anon.alg = CORAL_ANON_ALG_ZERO;
	    } else if (strcmp(token, "cryptopan") == 0) {
		anon.alg = CORAL_ANON_ALG_CRYPTOPAN;
	    } else if (str) {
		coral_config_diag(0, ("invalid anonymization algorithm '%s'\n",
		    token));
		result = -1;
		goto coral_config_command_exit;
	    } else {
		anon.alg = CORAL_ANON_ALG_CRYPTOPAN;
		coral_filename(token, filename, sizeof(filename));
	    }

	    while ((token = coral_strsep(&str, ","))) {
		if (strcmp(token, "src") == 0) {
		    anon.src = 1;
		} else if (strcmp(token, "dst") == 0) {
		    anon.dst = 1;
		} else if (strcmp(token, "keep") == 0) {
		    anon.keep = 1;
		} else if (strcmp(token, "notrunc") == 0) {
		    anon.notrunc = 1;
		} else if ((arg = strchr(token, '='))) {
		    *arg++ = '\0';
		    if (strcmp(token, "bits") == 0) {
			bits = atoi(arg);
		    } else if (strcmp(token, "keyfile") == 0) {
			if (anon.alg != CORAL_ANON_ALG_CRYPTOPAN)
			    errors++;
			else
			    coral_filename(arg, filename, sizeof(filename));
		    } else {
			errors++;
		    }
		} else if (isdigit(*token) || *token == '-') {
		    /* "<N>" is short for "bits=<N>" */
		    bits = atoi(token);
		} else {
		    errors++; 
		}
		if (errors) {
		    coral_config_diag(0, ("bad anonymize parameter '%s'\n",
			token));
		    result = -1;
		    goto coral_config_command_exit;
		}
	    }
	}

	if (!anon.src && !anon.dst)
	    anon.src = anon.dst = 1;

	if (bits == 0 || bits > 32 || bits < -32) {
	    coral_config_diag(0, ("anonymize: bits must be "
		"between 1 and 32 or -1 and -32.\n"));
	    result = -1;
	    goto coral_config_command_exit;
	} else if (bits == 32 || bits == -32) {
	    anon.keepmask = 0;
	} else if (bits > 0) {
	    anon.keepmask = 0xFFFFFFFF >> bits;
	} else if (bits < 0) {
	    anon.keepmask = 0xFFFFFFFF << -bits;
	}

	if (anon.alg == CORAL_ANON_ALG_CRYPTOPAN) {
#ifdef HAVE_CRYPTOPAN
	    char keybuf[32];
	    int keyfile, n, tot;

	    if ((keyfile = open(filename, O_RDONLY)) < 0) {
		coral_diag(0, ("%s: %s\n", filename, strerror(errno)));
		result = -1;
		goto coral_config_command_exit;
	    }
	    for (tot = 0; tot < 32; tot += n) {
		if ((n = read(keyfile, keybuf+tot, 32-tot)) < 0) {
		    coral_diag(0, ("%s: %s\n", filename, strerror(errno)));
		    result = -1;
		    goto coral_config_command_exit;
		}
		if (n == 0) {
		    coral_diag(0, ("%s: key must be 32 bytes.\n", filename));
		    result = -1;
		    goto coral_config_command_exit;
		}
	    }
	    anon.anonymizer = coral_new_PAnonymizer((uint8_t*)keybuf);
#else
	    coral_diag(0,
		("CryptoPAn is not enabled in this copy of CoralReef.\n"));
	    result = -1;
	    goto coral_config_command_exit;
#endif
	}

	coral_config.anon = anon;

    } else {
	coral_config_diag(0, ("unknown or illegal command '%s'\n", token));
	result = -1;
	goto coral_config_command_exit;
    }

coral_config_command_exit:
    if (copy) free(copy);
    return result;
}

#undef reqtoken

int coral_config_file(const char *filename)
{
    FILE *file;
    char command[1024];
    char expanded[PATH_MAX];
    int result = 0;
    static int depth = 0;
    const char *saved_filename;
    int saved_linenum;

    if (depth > 100) {
        coral_config_diag(0, ("probable config file loop detected\n"));
        return -1;
    }

    coral_filename(filename, expanded, sizeof(expanded));
    file = fopen(expanded, "r");
    if (!file) {
	coral_config_diag(0, ("%s: %s\n", expanded, strerror(errno)));
	return -1;
    }

    saved_filename = config_filename;
    saved_linenum = config_linenum;
    config_filename = expanded;
    config_linenum = 0;
    depth++;

    while (fgets(command, sizeof(command), file)) {
	size_t len;
	config_linenum++;
	len = strlen(command);
	while (len > 0 && isspace(command[--len]))
	    command[len] = '\0'; /* strip trailing whitespace (incl \n) */
	if (coral_config_command(command) < 0) {
	    result = -1;
	    break;
	}
    }

    if ((result < 0) && ferror(file)) {
	coral_config_diag(0, ("%s: %s\n", expanded, strerror(errno)));
	result = -1;
    }

    depth--;
    fclose(file);
    config_filename = saved_filename;
    config_linenum = saved_linenum;
    return result;
}

static void usage_fmt(int *n, const char *fmt, ...)
{
    va_list ap;
    int result;
    char buf[80];

    va_start(ap, fmt);
    result = vsprintf(buf, fmt, ap);
    va_end(ap);
    if (strlen(buf) > 36) {
	if (*n) fputc('\n', stderr);
	fprintf(stderr, "    %s\n", buf);
	*n = 0;
    } else if (*n > 0) {
	fprintf(stderr, "    %s\n", buf);
	*n = 0;
    } else {
	fprintf(stderr, "    %-36s", buf);
	++*n;
    }
}

void coral_usage(const char *appname, const char *argsyntax, ...)
{
    char iomode_buffer[CORAL_FORMAT_IOMODE_LEN];
    int n = 0;

    fprintf(stderr, "\nUsage:  %s [-C'<coral_command>']... ",
	appname);
    if (argsyntax) {
	va_list ap;
	va_start(ap, argsyntax);
	vfprintf(stderr, argsyntax, ap);
	va_end(ap);
    }
    fprintf(stderr, "\nPossible values of <coral_command>, with default "
	"values in parentheses:\n");
    usage_fmt(&n, "version");
    usage_fmt(&n, "{config|f}=<filename>");

    if (coral_config.iomode_is_fixed) {
	coral_format_iomode(iomode_buffer, &coral_config.dev_config.iomode);
	usage_fmt(&n, "(iomode is not configurable:  %s)",
	    iomode_buffer);
	usage_fmt(&n, "source=<filename>");
    } else {
	usage_fmt(&n, "{iomode|m}=<mode_options>");
	usage_fmt(&n, "source=<filename>[,<mode_options>]");
    }
    usage_fmt(&n, "proto=[<subif>=]<proto>");
    usage_fmt(&n, "allow=<subif>[=<proto>]");
    if (coral_config.api & (CORAL_API_CELL | CORAL_API_PKT)) {
	usage_fmt(&n, "deny=<subif>[=<proto>]");
    }
    if (coral_config.api & CORAL_API_PKT)
	usage_fmt(&n, "prefilter=<expr>");
	usage_fmt(&n, "filter=<expr>");
	usage_fmt(&n, "ipfilter=<expr>");

    if (coral_config.api & CORAL_API_PKT)
	usage_fmt(&n, "p[ackets]=<N>  (%" PRIu64 ")",
	    coral_config.max_pkts);
    if (coral_config.api & CORAL_API_CELL)
	usage_fmt(&n, "c[ells]=<N>  (%" PRIu64 ")",
	    coral_config.max_cells);
    if (coral_config.api & (CORAL_API_BLOCK | CORAL_API_CELL))
	usage_fmt(&n, "b[locks]=<N>  (%" PRIu64 ")",
	    coral_config.max_blks);

    if (coral_config.duration >= 0)
	usage_fmt(&n, "mintime=<seconds>  (%ld.%06ld)",
	    coral_config.mintime.tv_sec, coral_config.mintime.tv_usec);
    if (coral_config.duration >= 0)
	usage_fmt(&n, "maxtime=<seconds>  (%ld.%06ld)",
	    coral_config.maxtime.tv_sec, coral_config.maxtime.tv_usec);
    if (coral_config.duration >= 0)
	usage_fmt(&n, "d[uration]=<seconds>  (%ld)",
	    coral_config.duration);
    if (timercmp(&coral_config.interval, &tvzero, >=)) {
	usage_fmt(&n, "i[nterval]=<seconds>  (%ld.%06ld)",
	    coral_config.interval.tv_sec, coral_config.interval.tv_usec);
	if (coral_config.flags & CORAL_OPT_ALIGNINT)
	    usage_fmt(&n, "{alignint|ai}=0  (aligned intervals)");
	else
	    usage_fmt(&n, "{alignint|ai}  (unaligned intervals)");
    }
    usage_fmt(&n, "v[erbosity]=<level>  (%d)", coral_verbosity);
    if (coral_config.flags & CORAL_OPT_NORMALIZE_TIME)
	usage_fmt(&n, "norm[alize]=0  (normalize)");
    else
	usage_fmt(&n, "norm[alize]  (do not normalize)");
    if (coral_config.api & CORAL_API_WRITE)
	usage_fmt(&n, "comment=<string>");
    usage_fmt(&n, "e[rrfile]=<filename>");
    if (!(coral_config.flags & CORAL_OPT_SORT_TIME))
	usage_fmt(&n, "sort  (do not sort)");
    if (!(coral_config.flags & CORAL_OPT_IGNORE_TIME_ERR))
	usage_fmt(&n, "ignore_time_err  (abort on time error)");
    if (coral_config.api & CORAL_API_WRITE)
	usage_fmt(&n, "gz[ip][=<level>]  (%s)",
	    coral_config.gzip ? coral_config.gzip : "do not gzip");
    if ((coral_config.api & CORAL_API_PKT))
	usage_fmt(&n, "anon[ymize]={cryptopan|ipzero}"
	    "[,src][,dst][,bits=<N>][,keyfile=<file>]");
    if (n) fputc('\n', stderr);
    fputc('\n', stderr);

    fprintf(stderr, "<mode_options> is a comma-separated list of any of:\n"
	"    nif=<N>          [first=]<N>      [!]last          [!]user\n"
	"    [!]ctrl          [!]idle          [!]all           [!]echo\n"
	"    [!]varlen        fw=<name>        phy=<type>       bw=<bandwidth>\n"
	"    proto=[<subif>=]<proto>\n"
	"    allow=<subif>[=<proto>]\n"
	);
    if (coral_config.api & (CORAL_API_CELL | CORAL_API_PKT)) {
	fprintf(stderr, "    deny=<subif>[=<proto>]\n");
    }
    fprintf(stderr, "    (default: ");
    if (coral_config.dev_config.iomode.flags & CORAL_RX_UNKNOWN) {
	int i;
	fprintf(stderr, "%-9.9s: all contents", "files");
	for (i = 0; coral_iface_types[i]; i++) {
	    if (!(coral_iface_types[i]->default_config.iomode.flags &
		CORAL_RX_UNKNOWN))
	    {
		coral_format_iomode(iomode_buffer,
		    &coral_iface_types[i]->default_config.iomode);
		fprintf(stderr, ";\n              %-9.9s: %s",
		    coral_iface_types[i]->name, iomode_buffer);
	    }
	}
	fprintf(stderr, ")\n");
    } else {
	coral_format_iomode(iomode_buffer, &coral_config.dev_config.iomode);
	fprintf(stderr, "%s)\n", iomode_buffer);
    }

    fprintf(stderr, "\n");
}

void coral_set_argv(int argc, char *argv[])
{
    int i;
    if (coral_config.argv) {
	for (i = 0; i < coral_config.argc; i++) {
	    if (coral_config.argv[i])
		free(coral_config.argv[i]);
	}
	free(coral_config.argv);
    }
    coral_config.argc = 0;
    coral_config.argv = malloc((argc+1) * sizeof(char*));
    if (!coral_config.argv) return;
    coral_config.argc = argc;
    for (i = 0; i < coral_config.argc; i++)
	coral_config.argv[i] = strdup(argv[i]);
    coral_config.argv[i] = NULL;
}

int coral_config_options(int argc, char *argv[], const char *argsyntax)
{
    int opt;

    coral_set_argv(argc, argv);
    while ((opt = getopt(argc, argv, "C:")) != -1) {
	if (opt == '?')
	    goto coral_config_options_error;
	if (coral_config_command(optarg) < 0)
	    goto coral_config_options_error;
    }

    if (!argsyntax && optind != argc)
	goto coral_config_options_error;
    return optind;

coral_config_options_error:
    coral_usage(argv[0], "%s", argsyntax);
    return -1;
}

int coral_config_arguments(int argc, char *argv[])
{
    int i;

    i = coral_config_options(argc, argv, coral_config.maxsrc == 0 ? NULL :
	coral_config.maxsrc == 1 ? "[<source>]" : "[<source>]...");
    if (i < 0)
	return i;
    while (i < argc) {
	if (!coral_new_source(argv[i++]))
	    return -1;
    }
    return i;
}

