/* 
 * Copyright 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 * $Id: crl_stats.c,v 1.11 2007/06/06 18:17:37 kkeys Exp $
 */

static const char RCSid[]="$Id: crl_stats.c,v 1.11 2007/06/06 18:17:37 kkeys Exp $";

#include "config.h"
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <sys/time.h>
#include <sys/errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <signal.h>
#include <errno.h>

#include <netinet/in.h>
#include <netinet/in_systm.h>	/* needed for network header structures */
#include <netinet/ip.h>
#ifdef HAVE_INET6
#include <netinet/ip6.h>
#endif
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <netinet/ip_icmp.h>
#include <arpa/inet.h>
#include <netdb.h>

#include "libcoral.h"
#include "crl_byteorder.h"
#include "hashtab.h"

/* Solaris crap */
#ifndef IP_OFFMASK
#define IP_OFFMASK 0x1FFF
#endif

#define BIG_TABLE_SIZE		1500007
#define SMALL_TABLE_SIZE	65609

typedef struct flow {
    struct in_addr src;
    struct in_addr dst;
    u_char	ip_proto;
    u_char	ports_ok;
    u_short	sport;
    u_short	dport;
} flow;

int pretty_output = 0;
int count_flows = 1;

uint64_t ipv4_pkts = 0;
uint64_t ipv4_bytes = 0;
#ifdef HAVE_INET6
uint64_t ipv6_pkts = 0;
uint64_t ipv6_bytes = 0;
#endif
uint64_t non_ip_pkts = 0;
uint64_t unknown_encaps = 0;
struct timespec first = {0,0};
struct timespec latest = {0,0};

hash_tab *flow_hash;
hash_tab *ip_hash;
hash_tab *src_ip_hash;
hash_tab *dst_ip_hash;
hash_tab *tcp_src_port_hash;
hash_tab *tcp_dst_port_hash;
hash_tab *udp_src_port_hash;
hash_tab *udp_dst_port_hash;
hash_tab *icmp_hash;
hash_tab *non_ip_proto_hash;

static void usage(const char *name)
{
    coral_usage(name, "[-h] [-f] <source>...\n"
		"Gives summary statistics on IP information in file.\n"
		"-h         print human readable output\n"
		"-f         don't count flows (uses less memory)\n"
	    );
}

/* return 0 if the same - for use by the hashtable */
static int compare_flow(const void *entry1, const void *entry2)
{
    const flow *flow1 = entry1;
    const flow *flow2 = entry2;

    return (flow1->src.s_addr != flow2->src.s_addr ||
	    flow1->dst.s_addr != flow2->dst.s_addr ||
	    flow1->ip_proto != flow2->ip_proto ||
	    flow1->sport != flow2->sport ||
	    flow1->dport != flow2->dport ||
	    flow1->ports_ok != flow2->ports_ok);
}

/* make a hash of an entry - for use by the hashtable */
static unsigned long make_key_flow(const void *entry)
{
    const flow *what = entry;
    
    return (unsigned) what->src.s_addr * 59 + what->dst.s_addr +
	what->ip_proto + ((unsigned)what->dport<<16) + what->sport;
}

/* free mem of an entry - for use by the hashtable */
static void delete_flow(void *entry)
{
    flow *what = entry;
    if (!what) return;
    free(what);
}


/* IP hash functions */
static int compare_ip(const void *entry1, const void *entry2)
{
    const struct in_addr * ip1 = entry1;
    const struct in_addr * ip2 = entry2;
    return ip1->s_addr != ip2->s_addr;
}

static unsigned long make_key_ip(const void *entry)
{
    return ((struct in_addr *)entry)->s_addr;
}

static void delete_ip(void *entry)
{
    struct in_addr * ip = entry;
    if (!ip) return;
    free(ip);
}


/* Number hash functions */
static int compare_num(const void *entry1, const void *entry2)
{
    return *(int*)entry1 != *(int*)entry2;
}

static unsigned long make_key_num(const void *entry)
{
    return *(int*)entry;
}

static void delete_num(void *entry)
{
    int * num = entry;
    if (!num) return;
    free(num);
}

#define COUNT_ENTRY(TYPE, hash, entry) \
    if (!find_hash_entry(hash, &entry)) { \
	TYPE * new_rec; \
	new_rec = (TYPE *)malloc(sizeof(TYPE)); \
	if (new_rec == NULL) { \
	    fprintf(stderr, "Out of memory\n"); \
	    abort(); \
	} \
	*new_rec = entry; \
	add_hash_entry(hash, new_rec); \
    }


static void pkt_handler(coral_iface_t *iface,
    const coral_timestamp_t *timestamp, void *mydata,
    coral_pkt_buffer_t *packet, coral_pkt_buffer_t *header,
    coral_pkt_buffer_t *trailer)
{
    coral_pkt_buffer_t ippkt;
    struct ip *ip;
    flow current_flow;
    short offset;
    coral_pkt_buffer_t payload;

    CORAL_TIMESTAMP_TO_TIMESPEC(iface, timestamp, &latest);
    if (!first.tv_sec && !first.tv_nsec) {
	first = latest;
    }

    if (coral_get_payload_by_layer(packet, &ippkt, 3) < 0) {
	unknown_encaps++;
	return;
    }
    if (ippkt.protocol != CORAL_NETPROTO_IPv4) {
	if (ippkt.protocol == CORAL_NETPROTO_IPv6) {
#ifdef HAVE_INET6
	    struct ip6_hdr * ip6 = (struct ip6_hdr*)ippkt.buf;
	    ipv6_pkts++;
	    ipv6_bytes += ntohs(ip6->ip6_plen) + 40;
#endif
	} else {
	    COUNT_ENTRY(int, non_ip_proto_hash, ippkt.protocol);
	    non_ip_pkts++;
	}
	return;
    }
    ip = (struct ip*)ippkt.buf;

    ipv4_pkts++;
    ipv4_bytes += ntohs(ip->ip_len);

    if (!coral_field_fits(ip,ip_src,ippkt.caplen)) return;
    COUNT_ENTRY(struct in_addr, src_ip_hash, ip->ip_src);
    COUNT_ENTRY(struct in_addr, ip_hash, ip->ip_src);

    if (!coral_field_fits(ip,ip_dst,ippkt.caplen)) return;
    COUNT_ENTRY(struct in_addr, dst_ip_hash, ip->ip_dst);
    COUNT_ENTRY(struct in_addr, ip_hash, ip->ip_dst);

    offset = ntohs(ip->ip_off) & IP_OFFMASK;

    /* Set the key to the source/destination address pair. */
    current_flow.src.s_addr = ip->ip_src.s_addr;
    current_flow.dst.s_addr = ip->ip_dst.s_addr;
    current_flow.ip_proto = ip->ip_p;
    current_flow.ports_ok = 0;
    current_flow.sport = 0;
    current_flow.dport = 0;

    coral_get_payload(&ippkt, &payload);
    /* NOT get_payload_by_layer(..., 4); we want the payload, no matter what
     * layer it claims to be.  (Specifically, we don't want to go through
     * IPIP encapsulations.)
     */

    /* extract port info - make sure we aren't non-first fragments */
    if (offset == 0) {
        if (ip->ip_p == IPPROTO_TCP) {
	    if (payload.caplen >= 4) {
	        struct tcphdr *t = (struct tcphdr*)payload.buf;
		current_flow.sport = ntohs(t->th_sport);
		current_flow.dport = ntohs(t->th_dport);
		current_flow.ports_ok = 1;
	    }
	} else if (ip->ip_p == IPPROTO_UDP) {
	    if (payload.caplen >= 4) {
	        struct udphdr *u = (struct udphdr*)payload.buf;
		current_flow.sport = ntohs(u->uh_sport);
		current_flow.dport = ntohs(u->uh_dport);
		current_flow.ports_ok = 1;
	    }
	} else if (ip->ip_p == IPPROTO_ICMP) {
	    if (payload.caplen >= 2) {
	        struct icmp *icmp = (struct icmp*)payload.buf;
		current_flow.sport = icmp->icmp_type;
		current_flow.dport = icmp->icmp_code;
		current_flow.ports_ok = 1;
	    }
	}
    }
    if (current_flow.ports_ok) {
	if (ip->ip_p == IPPROTO_ICMP) {
	    /* Squish together since we only care about total count */
	    int typecode = (current_flow.sport<<16) + current_flow.dport;
	    COUNT_ENTRY(int, icmp_hash, typecode);
	} else if (ip->ip_p == IPPROTO_TCP) {
	    COUNT_ENTRY(int, tcp_src_port_hash, current_flow.sport);
	    COUNT_ENTRY(int, tcp_dst_port_hash, current_flow.dport);
	} else if (ip->ip_p == IPPROTO_UDP) {
	    COUNT_ENTRY(int, udp_src_port_hash, current_flow.sport);
	    COUNT_ENTRY(int, udp_dst_port_hash, current_flow.dport);
	}
    }

    if (count_flows) {
	COUNT_ENTRY(flow, flow_hash, current_flow);
    }
}

static void init_hashes(void)
{
    if (count_flows) {
	flow_hash = init_hash_table("flows", compare_flow, make_key_flow,
				    delete_flow, BIG_TABLE_SIZE);
    }
    ip_hash = init_hash_table("all IPs", compare_ip, make_key_ip,
				delete_ip, BIG_TABLE_SIZE);
    src_ip_hash = init_hash_table("source IPs", compare_ip, make_key_ip,
				delete_ip, BIG_TABLE_SIZE);
    dst_ip_hash = init_hash_table("dest IPs", compare_ip, make_key_ip,
				delete_ip, BIG_TABLE_SIZE);
    tcp_src_port_hash = init_hash_table("TCP source ports", compare_num,
				make_key_num, delete_num, SMALL_TABLE_SIZE);
    tcp_dst_port_hash = init_hash_table("TCP dest ports", compare_num,
				make_key_num, delete_num, SMALL_TABLE_SIZE);
    udp_src_port_hash = init_hash_table("UDP source ports", compare_num,
				make_key_num, delete_num, SMALL_TABLE_SIZE);
    udp_dst_port_hash = init_hash_table("UDP dest ports", compare_num,
				make_key_num, delete_num, SMALL_TABLE_SIZE);
    icmp_hash = init_hash_table("ICMP type/code", compare_num, make_key_num,
				delete_num, SMALL_TABLE_SIZE);
    non_ip_proto_hash = init_hash_table("non-IP protocols", compare_num,
				make_key_num, delete_num, SMALL_TABLE_SIZE);
}

static void stop(int sig)
{
    coral_pkt_done = 1;
}

static char * format_time(const struct timespec * thistime)
{
    static char time_str[100];
    if (pretty_output) {
	strftime(time_str, sizeof(time_str), "%c %Z",
					gmtime(&thistime->tv_sec));
    } else {
	snprintf(time_str, sizeof(time_str), "%lu.%09lu",
					thistime->tv_sec, thistime->tv_nsec);
    }
    return time_str;
}

static char * format_num(const uint64_t num, int base_2)
{
    static char num_str[100];
    if (pretty_output) {
	if (num > 1000000000) {
	    if (base_2) {
		snprintf(num_str, sizeof(num_str), "%.1fGi", num/1073741824.0);
	    } else {
		snprintf(num_str, sizeof(num_str), "%.1fG", num/1000000000.0);
	    }
	} else if (num > 1000000) {
	    if (base_2) {
		snprintf(num_str, sizeof(num_str), "%.1fMi", num/1048576.0);
	    } else {
		snprintf(num_str, sizeof(num_str), "%.1fM", num/1000000.0);
	    }
	} else if (num > 10000) {
	    if (base_2) {
		snprintf(num_str, sizeof(num_str), "%.1fKi", num/1024.0);
	    } else {
		snprintf(num_str, sizeof(num_str), "%.1fK", num/1000.0);
	    }
	} else {
	    snprintf(num_str, sizeof(num_str), "%" PRIu64, num);
	}
    } else {
	snprintf(num_str, sizeof(num_str), "%" PRIu64, num);
    }
    return num_str;
}

int main(int argc, char *argv[])
{
    int result = 0;
    int n, opt;
    coral_iface_t * iface = NULL;
    coral_pkt_result_t pkt_result;

    coral_set_api(CORAL_API_PKT);
    coral_set_duration(0);

    while ((opt = getopt(argc, argv, "hfC:")) >= 0) {
        if (opt == 'h') {
	    pretty_output = 1;
        } else if (opt == 'f') {
	    count_flows = 0;
	} else if (opt == 'C') {
            if (coral_config_command(optarg) < 0) {
		usage(argv[0]);
                exit(-1);
	    }
        } else {
	    usage(argv[0]);
            exit(-1);
        }
    }

    while (optind < argc) {
        if (!coral_new_source(argv[optind]))
            exit(-1);
        optind++;
    }

    signal(SIGINT, stop);

    if ((n = coral_open_all()) < 0)
        exit(-1);
    if (n == 0) {
	coral_diag(0, ("no sources.\n"));
	exit(0);
    }

    if (coral_start_all() < 0)
        exit(-1);

    init_hashes();

    coral_read_pkt_init(NULL, NULL, NULL);
    while (!coral_pkt_done) {
        iface = coral_read_pkt(&pkt_result, NULL);
        if (!iface) {
            if (errno) result = -1;
            break;
        } else if (pkt_result.packet) {
            pkt_handler(iface, pkt_result.timestamp, NULL,
                pkt_result.packet, pkt_result.header, pkt_result.trailer);
        }
    }

    iface = NULL;
    while ((iface = coral_next_interface(iface))) {
	    char snaplen[100];
	    const coral_io_mode_t * iomode = coral_iface_get_iomode(iface);

	    if (iomode->flags & CORAL_RX_USER_ALL) {
		strcpy(snaplen, "all");
	    } else if (iomode->first_n <= 0) {
		strcpy(snaplen, "unknown");
	    } else {
		snprintf(snaplen, sizeof(snaplen), "%d", iomode->first_n);
	    }
	    printf("Maximum capture length for interface %d:\t%17s\n",
		    coral_interface_get_number(iface), snaplen);
    }

    coral_stop_all();
    coral_close_all();

    printf("First timestamp:%41s\n", format_time(&first));
    printf("Last timestamp:%42s\n", format_time(&latest));
    printf("Unknown encapsulation:%35s\n", format_num(unknown_encaps, 0));
    printf("IPv4 bytes:%46s\n", format_num(ipv4_bytes, 1));
    printf("IPv4 pkts:%47s\n", format_num(ipv4_pkts, 0));
    if (count_flows) {
	printf("IPv4 flows:%46s\n", format_num(num_hash_entries(flow_hash), 0));
    }
    printf("Unique IPv4 addresses:%35s\n",
			    format_num(num_hash_entries(ip_hash), 0));
    printf("Unique IPv4 source addresses:%28s\n",
			    format_num(num_hash_entries(src_ip_hash), 0));
    printf("Unique IPv4 destination addresses:%23s\n",
			    format_num(num_hash_entries(dst_ip_hash), 0));
    printf("Unique IPv4 TCP source ports:%28s\n",
			    format_num(num_hash_entries(tcp_src_port_hash), 0));
    printf("Unique IPv4 TCP destination ports:%23s\n",
			    format_num(num_hash_entries(tcp_dst_port_hash), 0));
    printf("Unique IPv4 UDP source ports:%28s\n",
			    format_num(num_hash_entries(udp_src_port_hash), 0));
    printf("Unique IPv4 UDP destination ports:%23s\n",
			    format_num(num_hash_entries(udp_dst_port_hash), 0));
    printf("Unique IPv4 ICMP type/codes:%29s\n",
			    format_num(num_hash_entries(icmp_hash), 0));
#ifdef HAVE_INET6
    printf("IPv6 pkts:%47s\n", format_num(ipv6_pkts, 0));
    printf("IPv6 bytes:%46s\n", format_num(ipv6_bytes, 1));
#endif
    printf("non-IP protocols:%40s\n",
			    format_num(num_hash_entries(non_ip_proto_hash), 0));
    printf("non-IP pkts:%45s\n", format_num(non_ip_pkts, 0));

    if (result != 0) {
	coral_diag(0, ("\n# WARNING: An error has occurred.  The above statistics describe only the data before the error.\n"));
    }
    return result;
}
