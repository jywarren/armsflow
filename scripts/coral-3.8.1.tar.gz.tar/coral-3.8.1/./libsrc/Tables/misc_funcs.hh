#ifndef MISC_FUNCS_H
#define MISC_FUNCS_H
#include <cstdlib>
#include <cstdio>
#include <new>
#include <ctype.h>

void out_of_mem() {
    fprintf(stderr, "Out of memory (in C++ backend).\n");
    exit(1);
}

int null_compare(char * blank1, char * blank2)
{
    return 0;
}

int num_compare(int64_t num1, int64_t num2)
{
    if (num1 < num2)
	return -1;
    else if (num1 > num2)
	return 1;
    else
	return 0;
}

int dbl_compare(double num1, double num2)
{
    if (num1 < num2)
	return -1;
    else if (num1 > num2)
	return 1;
    else
	return 0;
}

int as_compare(char * as1, char * as2)
{
    if (!as1) return -1;
    if (!as2) return 1;
    if (isdigit(as1[0]) && isdigit(as2[0])) {
	return num_compare(atoi(as1), atoi(as2));
    } else {
	return strcmp(as1, as2);
    }
}

#endif
