/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/* $Id: crl_time.c,v 1.39 2007/06/06 18:17:37 kkeys Exp $ */
/* Compares ATM timestamps for development */


static const char RCSid[]="$Id: crl_time.c,v 1.39 2007/06/06 18:17:37 kkeys Exp $";

#include "config.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "libcoral.h"

#define NIF 16

static coral_iface_t *get_cell_time(const coral_timestamp_t **tsp)
{
    coral_iface_t *iface;
    coral_atm_cell_t *cell;

    iface = coral_read_cell_all(NULL, &cell, NULL);
    if (!iface) return NULL;
    *tsp = coral_cell_time(iface, cell);
    return iface;
}

static coral_iface_t *get_pkt_time(const coral_timestamp_t **tsp)
{
    coral_iface_t *iface;
    coral_pkt_result_t pkt_result;
    coral_interval_result_t int_result;

retry:
    iface = coral_read_pkt(&pkt_result, &int_result);
    if (!iface) return NULL;
    if (pkt_result.packet) {
	*tsp = pkt_result.timestamp;
	return iface;
    }
    if (!int_result.stats)
	printf("# begin interval: %10ld.%06ld\n", int_result.begin.tv_sec, int_result.begin.tv_usec);
    else {
	struct timeval diff;
	timersub(&int_result.end, &int_result.begin, &diff);
	printf("# end interval: %10ld.%06ld - %10ld.%06ld (%4ld.%06ld)\n",
	    int_result.begin.tv_sec, int_result.begin.tv_usec,
	    int_result.end.tv_sec, int_result.end.tv_usec,
	    diff.tv_sec, diff.tv_usec);
    }
    goto retry;
}

static void usage(const char *name)
{
    coral_usage(name, "[-i<n>] [-rsp] <source>...\n"
	"-i<n>    read only from interface <n>\n"
	"-r       display raw (uncorrected) time\n"
	"-s       sort by time, diff across ifaces (same as '-Csort')\n"
	"-p       use packet timestamps (default: use ATM cell timestamps)\n"
	"-q       quiet: print only records with a timestamp anomaly\n"
	"-Q       quit after finding a timestamp error\n");
}

int main (int argc, char *argv[])
{
    coral_iface_t *iface;
    u_int count = 0;
    int i, in, opt, sort, requested_in = -1, pkt_flag = 0, quiet_flag = 0, quit_flag = 0;
    const coral_timestamp_t *rts;
    coral_timestamp_t ts, old_ts[NIF];
    long badwrap = 0;
    struct timespec diff, now, then[NIF];
    const struct timespec ts_zero = { 0, 0 };
    const struct timespec ts_small = { 0, 80 };
    const struct timespec ts_large = { 0, 8000000 };
    struct timeval interval = { 0, 0 };
    char buf[80];
    char *s = buf;
    int anomalies, total_anomalies = 0;

    const char *label = "cell";
    coral_iface_t *(*get_time)(const coral_timestamp_t **tsp) = get_cell_time;

    extern char *optarg;
    extern int optind;

    for (i = 0; i < NIF; i++) {
	old_ts[i].i[0] = old_ts[i].i[1] = -1;
	then[i].tv_sec = then[i].tv_nsec = 0;
    }

    coral_set_iomode(0, CORAL_RX_UNKNOWN, -1, 0);
    coral_set_duration(0);
    coral_set_interval(&interval);
    coral_set_options(0, CORAL_OPT_IGNORE_TIME_ERR);

    while ((opt = getopt(argc, argv, "C:ri:spqQ")) != -1) {
        switch (opt) {
        case 'C':
            if (coral_config_command(optarg) < 0) {
		usage(argv[0]);
                exit(-1);
	    }
            break;
        case 'r':
	    coral_set_options(0, CORAL_OPT_RAW_TIME);
            break;
        case 'i':
	    requested_in = atoi(optarg);
            break;
        case 's':
	    /* note: this could also be set by -Csort */
	    coral_set_options(0, CORAL_OPT_SORT_TIME);
	    break;
        case 'p':
	    pkt_flag = 1;
	    coral_set_api(CORAL_API_PKT); /* allow pkt-only options */
	    break;
        case 'q':
	    quiet_flag = 1;
	    break;
        case 'Q':
	    quit_flag = 1;
	    break;
        default:
	    usage(argv[0]);
            exit(-1);
        }
    }

    while (optind < argc) {
        if (!coral_new_source(argv[optind]))
            exit(-1);
        optind++;
    }
    coral_get_interval(&interval);
    sort = coral_get_options() & CORAL_OPT_SORT_TIME;

    if (coral_open_all() < 0)
        exit(-1);

    if (coral_start_all() < 0)
        exit(0);

    iface = NULL;
    if (requested_in >= 0) {
	while ((iface = coral_next_interface(iface))) {
	    in = coral_interface_get_number(iface);
	    if (in == requested_in)
		break;
	}
	if (!iface) {
	    fprintf(stderr, "no interface %d\n", requested_in);
	    exit(1);
	}
    }

    if (iface) {
	pkt_flag = (coral_interface_get_physical(iface) != CORAL_PHY_ATM);
    } else {
	while ((iface = coral_next_interface(iface))) {
	    if (coral_interface_get_physical(iface) != CORAL_PHY_ATM) {
		pkt_flag = 1;
		break;
	    }
	}
	iface = NULL;
    }
    if (pkt_flag) {
	get_time = get_pkt_time;
	coral_set_api(CORAL_API_PKT);
	label = "pkt";
	coral_read_pkt_init(NULL, iface, &interval);
    } else {
	coral_set_api(CORAL_API_CELL);
    }

    printf("%2s %6s  %17s %20s %12s  comment\n",
	"if", label, "native timestamp", "seconds      ", "difference");
    while ((iface = get_time(&rts))) {
	*(s = buf) = '\0';
	anomalies = 0;
	in = coral_interface_get_number(iface);
	if (requested_in >= 0 && in != requested_in)
	    continue;
	i = sort ? 0 : in;
	CORAL_TIMESTAMP_TO_TIMESPEC(iface, rts, &now);
	coral_read_clock_order(iface, rts, &ts);
	if (then[i].tv_sec != 0 || then[i].tv_nsec != 0) {
	    diff = now;
	    timespecsub(&diff, &then[i]);
	    if (diff.tv_sec >= 0 && diff.tv_nsec >= 0)
		s += sprintf(s, " %2ld.%09ld", diff.tv_sec, diff.tv_nsec);
	    else if (diff.tv_sec > 0 && diff.tv_nsec < 0)
		s += sprintf(s, " %2ld.%09ld", diff.tv_sec - 1, 1000000000 + diff.tv_nsec);
	    else if (diff.tv_sec < 0 && diff.tv_nsec > 0)
		s += sprintf(s, " -%ld.%09ld", -diff.tv_sec - 1, 1000000000 - diff.tv_nsec);
	    else
		s += sprintf(s, " -%ld.%09ld", -diff.tv_sec, -diff.tv_nsec);
	    if (timespeccmp(&diff, &ts_zero, <)) {
		s += sprintf(s, "  XXX major error: negative diff");
		if (quit_flag) quit_flag++;
		anomalies++;
	    } else if (old_ts[i].i[0] >= 0) {
		if (timespeccmp(&diff, &ts_zero, ==)) {
		    s += sprintf(s, "  XXX error: diff zero");
		    if (quit_flag) quit_flag++;
		    anomalies++;
		} else if (timespeccmp(&diff, &ts_zero, <)) {
		    s += sprintf(s, "  XXX error: diff negative");
		    if (quit_flag) quit_flag++;
		    anomalies++;
		} else if (timespeccmp(&diff, &ts_small, <)) {
		    s += sprintf(s, "  XXX error: diff too small");
		    if (quit_flag) quit_flag++;
		    anomalies++;
		} else if (timespeccmp(&diff, &ts_large, >)) {
		    s += sprintf(s, "  XXX warning: large diff");
		    anomalies++;
		}
		if (ts.i[0] != old_ts[i].i[0]) {
		    badwrap = 0;
		    s += sprintf(s, "  high stamp %+d",
			ts.i[0] - old_ts[i].i[0]);
		} else if (ts.i[1] < old_ts[i].i[1]) {
		    badwrap++;
		    s += sprintf(s, "  XXX wrap error #%ld", badwrap);
		    if (quit_flag) quit_flag++;
		    anomalies++;
		}
	    }
	}
	if (anomalies || !quiet_flag) {
	    printf("%2d %6d: %08x %08x %10ld.%09ld%s\n",
		in, count, ts.i[0], ts.i[1], now.tv_sec, now.tv_nsec, buf);
	    if (anomalies)
		total_anomalies++;
	}
	count++;
	old_ts[i] = ts;
	then[i] = now;
	if (quit_flag > 1)
	    break;
    }

    if (errno) return(errno);
    coral_stop_all();
    coral_close_all();
    printf("# %d anomalous records found.\n", total_anomalies);
    exit(total_anomalies ? 1 : 0);
}
