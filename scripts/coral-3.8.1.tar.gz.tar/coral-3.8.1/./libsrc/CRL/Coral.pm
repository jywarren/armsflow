## 
## Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
## All Rights Reserved 
## 
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
## 
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
## 
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
## 
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
## 
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program. Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, and by CAIDA
## members.
## 
## Report bugs and suggestions to coral-bugs@caida.org.
## 

## $Id: Coral.pm,v 1.2 2007/06/06 18:17:44 kkeys Exp $

package Coral;
require Exporter;
require DynaLoader;
@ISA = qw(Exporter DynaLoader);
bootstrap Coral;
$VERSION = 1.00;
@EXPORT    = qw();
@EXPORT_OK = ();

use strict;

# Used to access members of structures filled in by libcoral.
package _p_coral_atm_cell_t;
*timestamp = \&Coral::cell_time;
*header = \&Coral::cell_header;
*payload = \&Coral::cell_payload;
*hec = \&Coral::cell_hec;

# Used to access members of structures filled in by libcoral.
package _p_coral_pkt_result_t;
*timestamp = \&Coral::coral_pkt_result_t_timestamp_get;
*packet = \&Coral::coral_pkt_result_t_packet_get;
*header = \&Coral::coral_pkt_result_t_header_get;
*trailer = \&Coral::coral_pkt_result_t_trailer_get;
*subiface = \&Coral::coral_pkt_result_t_subiface_get;

# User-level creation, makes an object named _p_pkt_result_t, for passing
# to Coral::read_pkt()
package Coral::Pkt_result;
use vars qw(@ISA);
@ISA = qw(_p_coral_pkt_result_t);
sub new {
    return Coral::new_mortal_pkt_result_t();
}

# SWIG-level creation, made by Pkt_result package, for auto-deletion only.
package _p_mortal_pkt_result_t;
use vars qw(@ISA);
@ISA = qw(_p_coral_pkt_result_t);
*DESTROY = \&Coral::delete_mortal_pkt_result_t;

# Used to access members of structures filled in by libcoral.
package _p_coral_pkt_buffer_t;
*caplen = \&Coral::coral_pkt_buffer_t_caplen_get;
*totlen = \&Coral::coral_pkt_buffer_t_totlen_get;
*buf = \&Coral::buffer_buf_get; # Special func to convert to byte string
*protocol = \&Coral::coral_pkt_buffer_t_protocol_get;

# Used when creating our own buffers, eg for use in Coral::get_payload()
package Coral::Pkt_buffer;
use vars qw(@ISA);
@ISA = qw(_p_coral_pkt_buffer_t);
sub new {
    return Coral::new_mortal_pkt_buffer_t();
}

# SWIG-level creation, made by Pkt_buffer package, for auto-deletion only.
package _p_mortal_pkt_buffer_t;
use vars qw(@ISA);
@ISA = qw(_p_coral_pkt_buffer_t);
*DESTROY = \&Coral::delete_mortal_pkt_buffer_t;

package Coral::Pkt_stats;

sub new {
    Coral::puts("Cannot manually create a Coral::Pkt_stats object.");
    return undef;
}

# Used to access members of structures filled in by libcoral.
package _p_coral_pkt_stats_t;
*l2_recv = \&Coral::coral_pkt_stats_t_l2_recv_get;
*l2_drop = \&Coral::coral_pkt_stats_t_l2_drop_get;
*pkts_recv = \&Coral::coral_pkt_stats_t_pkts_recv_get;
*pkts_drop = \&Coral::coral_pkt_stats_t_pkts_drop_get;
*truncated = \&Coral::coral_pkt_stats_t_truncated_get;
*driver_corrupt = \&Coral::coral_pkt_stats_t_driver_corrupt_get;
*too_many_vpvc = \&Coral::coral_pkt_stats_t_too_many_vpvc_get;
*buffer_overflow = \&Coral::coral_pkt_stats_t_buffer_overflow_get;
*aal5_trailer = \&Coral::coral_pkt_stats_t_aal5_trailer_get;
*ok_packet = \&Coral::coral_pkt_stats_t_ok_packet_get;

# Used to access members of structures filled in by libcoral.
package _p_coral_interval_result_t;
*begin = \&Coral::coral_interval_result_t_begin_get;
*end = \&Coral::coral_interval_result_t_end_get;
*stats = \&Coral::coral_interval_result_t_stats_get;
*DESTROY = \&Coral::delete_coral_interval_result_t;

# User-level creation, makes an object named _p_coral_interval_result_t,
# for passing to Coral::read_pkt()
package Coral::Interval_result;
use vars qw(@ISA);
@ISA = qw(_p_coral_interval_result_t);
sub new {
    return Coral::new_coral_interval_result_t();
}

package Coral;

sub quick_start {
    my ($time_sort, $partial_pkt, $api) = @_;

    if (defined $time_sort and $time_sort != 0) {
	if (Coral::set_options(0, $Coral::OPT_SORT_TIME) < 0) {
	    Coral::puts("Warning: could not set time-sorting option!");
	}
    } elsif (Coral::set_options($Coral::OPT_SORT_TIME, 0) < 0) {
	Coral::puts("Warning: could not unset time-sorting option!");
    }

    if (defined $partial_pkt and $partial_pkt == 0) {
	if (Coral::set_options($Coral::OPT_PARTIAL_PKT, 0) < 0) {
	    Coral::puts("Warning: could not unset partial packeting option!");
	}
    } elsif (Coral::set_options(0, $Coral::OPT_PARTIAL_PKT) < 0) {
	Coral::puts("Warning: could not set partial packeting option!");
    }

    if (defined $api) {
	if (Coral::set_api($api) < 0) {
	    Coral::puts("Warning: could not specify api!");
	}
    } elsif (Coral::set_api($Coral::API_PKT) < 0) {
	Coral::puts("Warning: could not specify packet api!");
    }

    if (Coral::config_arguments(scalar(@ARGV), \@ARGV) < 0) {
	Coral::puts("Error: could not parse command-line options!");
	exit(1);
    }
    if (Coral::open_all() <= 0) { # no openable sources is considered an error
	Coral::puts("Error: could not open any sources!");
	exit(1);
    }
    if (Coral::start_all() < 0) {
	Coral::puts("Error: could not start any sources!");
	exit(1);
    }
}

use Unpack;
my $get_ip_ip_opts = new Unpacker("ip", ["ip_v"]);

sub get_ip($$) {
    my ($iface, $cell) = @_;
    my ($llcpacket, $ip_record, $header, $trailer);
    my $ippacket = new Coral::Pkt_buffer;

    if (ref($cell) eq "_p_coral_atm_cell_t") {
	$llcpacket = new Coral::Pkt_buffer;
	Coral::cell_to_pkt($iface,$cell, $llcpacket);
    } elsif (ref($cell) eq "_p_pkt_buffer_t" or
		ref($cell) eq "_p_coral_pkt_buffer_t") {
	$llcpacket = $cell; # No conversion needed.
    } else {
	return undef;
    }

    my $error = Coral::get_payload_by_proto($llcpacket, $ippacket,
					    $Coral::NETPROTO_IP);
    if ($error) { return undef; }

    $ip_record = $ippacket->buf;
    my ($ip_v) = $get_ip_ip_opts->unpack($ip_record);
    if ($ip_v != 4) { return undef; }

    return $ip_record;
}

1;
