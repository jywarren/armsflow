#!/usr/local/bin/perl -w
## 
## Copyright 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
## All Rights Reserved 
## 
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
## 
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
## 
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
## 
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
## 
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program. Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
## 
## Report bugs and suggestions to coral-bugs@caida.org.
## 

use strict;
use IO::Handle; # For flush()
use Getopt::Std;
use File::Basename;
use vars qw($opt_S $opt_d $opt_M);

if (!getopts("S:M:d") or @ARGV != 1) {
    print STDERR "Usage: $0 [-S <statefile>] [-M <dir>] [-d] <glob pattern>\n",
	"Waits forever for files ",
	"matching <glob pattern> in current directory\n",
	"    and sends them to stdout\n",
	"Options:\n",
	"  -S:  use <statefile> to remember last read file\n",
	"  -M:  move file into <dir> after reading it\n",
	"  -d:  delete file after reading it\n";
    exit;
}
my ($glob_pat) = @ARGV;

my $last_file;
if ($opt_S and open(STATE, $opt_S)) {
    $last_file = <STATE>;
    chomp $last_file;
    close STATE;
}

while (1) {
    my @files = glob $glob_pat;
    while (my $file = shift @files) {
	next if defined $last_file and $file le $last_file;
	my $decompress = "cat";
	if ($file =~ /.gz$/) {
	    $decompress = "gzip -dc";
	} elsif ($file =~ /.bz2$/) {
	    $decompress = "bzip2 -dc";
	} elsif ($file =~ /.lzo$/) {
	    $decompress = "lzop -dc";
	}
	open FILE, "$decompress $file |" or warn "Cannot open $file";
	while (<FILE>) {
	    print;
	}
	flush STDOUT;
	close FILE;
	$last_file = $file;
	if ($opt_S and open(STATE, ">$opt_S")) {
	    print STATE "$file\n";
	    close STATE;
	}
	# Make sure that the link worked before removing original
	if (defined $opt_M) {
	    my ($short_name) = fileparse($file);
	    if (link $file, "$opt_M/$short_name") {
		unlink $file;
	    } else {
		print STDERR "Couldn't move $file to $opt_M/$short_name: $!\n";
	    }
	}
	unlink $file if $opt_d;
    }
    sleep 5;
}
