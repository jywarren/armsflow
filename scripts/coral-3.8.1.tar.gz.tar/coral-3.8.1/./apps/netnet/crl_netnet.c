/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 * $Id: crl_netnet.c,v 1.59 2007/06/06 18:17:31 kkeys Exp $
 */


static const char RCSid[]="$Id: crl_netnet.c,v 1.59 2007/06/06 18:17:31 kkeys Exp $";

#include "config.h"
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <sys/time.h>
#include <sys/errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <signal.h>
#include <errno.h>

#include <netinet/in.h>
#include <netinet/in_systm.h>
#include <netinet/ip.h>
#include <arpa/inet.h>
#include <netdb.h>

#include "libcoral.h"
#include "hashtab.h"

static int done = 0;
static u_int netmask;
static u_char cnames = 0;
static u_char stats = 0;

static void quit(int arg) {
    fprintf(stderr, "got sig %d \n", arg);
    done = 1;
}



/* ---- stuff that is per (srcdst)hash table begins ---- */
#define HASH_TABLE_SIZE		97843
#define SUBIF_HASH_TABLE_SIZE	229

typedef struct {
    struct in_addr src;
    struct in_addr dst;
    u_int pkts;
    u_int bytes;
} srcdst;

static void dump_srcdst_table(hash_tab *ht)
{
    const srcdst *rec;
    struct hostent *h;

    init_hash_walk(ht);
    
    fprintf(stdout, "#%-20s %-20s %-9s %3.3s %-9s %3.3s\n", 
	    "src", "dst", "pkts", "f", "bytes", "f");

    while ((rec = next_hash_walk(ht))) {
	char tmpsrc[80];
	char tmpdst[80];

	if (cnames) {
	    h = gethostbyaddr((char*)&rec->src, 
			      sizeof(struct in_addr), AF_INET);
	    if (h)
		strcpy(tmpsrc, h->h_name);
	    else
		strcpy(tmpsrc, inet_ntoa(rec->src));

	    h = gethostbyaddr((char*)&rec->dst, 
			      sizeof(struct in_addr), AF_INET);
	    if (h)
		strcpy(tmpdst, h->h_name);
	    else
		strcpy(tmpdst, inet_ntoa(rec->dst));
	} else {
	    strcpy(tmpsrc, inet_ntoa(rec->src));
	    strcpy(tmpdst, inet_ntoa(rec->dst));
	}
	
	fprintf(stdout, " %-20.20s %-20.20s %-9d %.1f %-9d %.1f\n", 
		tmpsrc, tmpdst, rec->pkts, (double)0, rec->bytes, (double)0);
    }

    fflush(stdout);
}

/* return 0 if the same - for use by the hashtable */
static int compare_srcdst(const void *entry1, const void *entry2)
{
    const srcdst *foo1 = entry1;
    const srcdst *foo2 = entry2;

    return (foo1->src.s_addr != foo2->src.s_addr ||
	    foo1->dst.s_addr != foo2->dst.s_addr);
}

/* make a hash of an entry - for use by the hashtable */
static unsigned long make_key_srcdst(const void *entry)
{
    const srcdst *what = entry;

    return (unsigned) what->src.s_addr * 37 + what->dst.s_addr;
}

/* free mem of an entry - for use by the hashtable */
static void delete_srcdst(void *entry)
{
    srcdst *what = entry;

    if (!what) return;

    free(what);
}

/* ---- hash table fxns end ---- */

/* ---- hash table per subif fxns begin ---- */

/* -- per subif hash table fxns -- */
typedef struct {
    coral_iface_t *iface;
    u_int subif;
    u_int pkts;
    u_int bytes;
    char *name;
    hash_tab *hash;
} subif_stats;

/* return 0 if the same - for use by the hashtable */
/* return 0 if the same - for use by the hashtable */
static int compare_subif_stats(const void *entry1, const void *entry2)
{
    const subif_stats *foo1 = entry1;
    const subif_stats *foo2 = entry2;

    return (foo1->iface != foo2->iface) || (foo1->subif != foo2->subif);
}

/* make a hash of an entry - for use by the hashtable */
static unsigned long make_key_subif_stats(const void *entry)
{
    const subif_stats *what = entry;

    return (coral_interface_get_number(what->iface) << 12) | what->subif;
}

/* free mem of an entry - for use by the hashtable */
static void delete_subif_stats(void *entry)
{
    subif_stats *what = entry;

    if (!what) return;

    free(what->name);
    free(what);
}
/* -- end of subif type hash table fxns -- */

hash_tab *subifhash;
inline static hash_tab *fetch_subif_hash(coral_iface_t *iface, u_int subif, struct ip *ip)
{
    subif_stats *rec;
    subif_stats tmp;
    char buf[32];

    tmp.iface = iface;
    tmp.subif = subif;
    if ((rec = (subif_stats*)find_hash_entry(subifhash, &tmp))) {
	rec->pkts++;
	rec->bytes += ntohs(ip->ip_len);
	return rec->hash;
    } else {
	rec = malloc(sizeof(subif_stats));
	if (rec == NULL) {
	    fprintf(stderr, "can't malloc subif_stats.\n");
	    return NULL;
	}
	*rec = tmp;

	rec->name = malloc(80);
	if (rec == NULL) {
	    fprintf(stderr, "can't malloc subif_stats.name\n");
	    return NULL;
	}
	coral_fmt_if_subif(buf, rec->iface, rec->subif);
	sprintf(rec->name, "# src dst pkt and byte counter for %s", buf);
	rec->pkts = 1;
	rec->bytes = ntohs(ip->ip_len);
	rec->hash = init_hash_table(rec->name,
				    compare_srcdst, make_key_srcdst,
				    delete_srcdst, HASH_TABLE_SIZE);
	if (rec->hash) {
	    add_hash_entry(subifhash, rec);
	    return rec->hash;
	} else
	    delete_subif_stats(rec);
    }
    return NULL;
}

static void init_subif_hashes(void)
{
    subifhash = init_hash_table("# hashes entries for each subif",
			       compare_subif_stats, make_key_subif_stats,
			       delete_subif_stats, SUBIF_HASH_TABLE_SIZE);
}
static void dump_hash_stats(void)
{
    const subif_stats *rec;

    init_hash_walk(subifhash);
    
    while ((rec = next_hash_walk(subifhash))) {
	dump_hashtab_stats(rec->hash);
    }
    dump_hashtab_stats(subifhash);
}

static void dump_data(void)
{
    const subif_stats *rec;
    char buf[32];

    init_hash_walk(subifhash);
    
    while ((rec = next_hash_walk(subifhash))) {
	coral_fmt_if_subif(buf, rec->iface, rec->subif);
	fprintf(stdout, "\n# for %11s  pkts: %d  bytes: %d\n",
	    buf, rec->pkts, rec->bytes);
	dump_srcdst_table(rec->hash);
    }
    fflush(stdout);
}


static void clear_data(void)
{
    const subif_stats *rec;

    init_hash_walk(subifhash);
    
    while ((rec = next_hash_walk(subifhash))) {
	clear_hash_table(rec->hash);
    }
}

/* ---- per subif stuff ends ---- */

/* called for each packet.
 * ups the respective counters.
 * returns -1 on failure, 0 on success.
 */
static int count_srcdst(coral_iface_t *iface, u_int subif,
    coral_pkt_buffer_t *netpkt)
{
    srcdst *rec;
    srcdst tmp;
    hash_tab *ht;
    struct ip *ip;

    ip = (struct ip*)netpkt->buf;
    if (!(ht = fetch_subif_hash(iface, subif, ip))) {
	fprintf(stderr, "subif hash table error (?)\n");
	return 0;
    }

    /* mask out what we're interested in. */
    tmp.src.s_addr = netmask & ip->ip_src.s_addr;
    tmp.dst.s_addr = netmask & ip->ip_dst.s_addr;

    if ((rec = find_hash_entry(ht, &tmp))) {
	rec->pkts++;
	rec->bytes += ntohs(ip->ip_len);
    } else {
	rec = malloc(sizeof(srcdst));

	if (rec == NULL) {
	    fprintf(stderr, "can't malloc srcdst.\n");
	    return -1;
	}
	*rec = tmp;
	rec->pkts = 1;
	rec->bytes = ntohs(ip->ip_len);
	add_hash_entry(ht, rec);
    }

    return 0;
}

int main(int argc, char *argv[])
{
    int i;
    coral_iface_t *iface;
    u_int cidr_len = 16;
    u_int unknown_encaps = 0, non_ip = 0;
    struct timeval default_interval = { 180, 0 };
    struct timeval interval;
    int opt;

    coral_pkt_buffer_t *linkpkt;
    coral_pkt_buffer_t netpkt;
    coral_pkt_result_t pkt_result;
    coral_interval_result_t interval_result;

    double lasttime = 0;
    double thistime;

    coral_set_api(CORAL_API_PKT);
    coral_set_interval(&default_interval);
    coral_set_duration(-1);

    while ((opt = getopt(argc, argv, "C:p:as")) != -1) {
	switch (opt) {
	case 'C':
	    if (coral_config_command(optarg) < 0)
		exit(-1);
	    break;
	case 'p':
	    cidr_len = atoi(optarg);
	    if (cidr_len > 32 || cidr_len < 8) {
		fprintf(stderr,
			"%s: valid CIDR prefix lengths are between 8 and 32\n",
			argv[0]);
		exit(-1);
	    }
	    break;
	case 'a':
	    cnames = 1;
	    break;
	case 's':
	    stats = 1;
	    break;
	default:
	    coral_usage(argv[0], "[-p <cidr_length>] [-a] [-s] [<source>]...\n"
		"-pN   use CIDR prefix length N (default %d)\n"
		"-a    resolve IP addresses to hostnames\n"
		"-s    print hash table statistics (for debugging)\n",
		cidr_len);
	    exit(-1);
	}
    }

    while (optind < argc) {
	if (!coral_new_source(argv[optind]))
	    exit(-1);
	optind++;
    }

    init_subif_hashes();

    /* generate a netmask from the cidr length */
    for (i = 32 - cidr_len; i < 32; i++)
	netmask |= (1 << i);

    /* corrected for endianess */
    netmask = ntohl(netmask);

    coral_set_options(0, CORAL_OPT_PARTIAL_PKT);

    fprintf(stderr, "cidr_len: %d netmask: 0x%x ", cidr_len, netmask);

    if (coral_open_all() <= 0)
	exit(-1);

    if (coral_start_all() < 0)
	exit(-1);


    signal(SIGINT, quit);

    if (coral_get_interval(&interval) < 0)
	interval = default_interval;

    coral_diag(2, ("collection interval set to %ld.%06ld second(s)\n",
	interval.tv_sec, interval.tv_usec));
    coral_read_pkt_init(NULL, NULL, &interval);

    while (!done && (iface = coral_read_pkt(&pkt_result, &interval_result))) {
	if (!pkt_result.packet && !interval_result.stats) {
	    /* beginning of interval */
	} else if (pkt_result.packet) {
	    /* got packet */
	    thistime = CORAL_TIMESTAMP_TO_DOUBLE(iface,
			pkt_result.timestamp);
	    linkpkt = pkt_result.packet;

	    if (thistime < lasttime) {
		continue;
	    }

	    if (coral_get_payload_by_layer(linkpkt, &netpkt, 3) < 0) {
		unknown_encaps++;
		continue;
	    }

	    if (netpkt.protocol != CORAL_NETPROTO_IP) {
		non_ip++;
		continue;
	    }

	    /* record this packet */
	    count_srcdst(iface, pkt_result.subiface, &netpkt);

	    lasttime = thistime;
	} else if (!pkt_result.packet && interval_result.stats) {
	    /* end of interval */
	    dump_data();
	    clear_data();
	}
    }

    coral_stop_all();

    /* printf out our data */
    fprintf(stdout, "# done\n");
    fprintf(stdout, "# packets with unknown encapsulation: %d\n", unknown_encaps);
    fprintf(stdout, "# non IP packets: %d\n", non_ip);
    fprintf(stdout, "# \n");

/*    dump_data(); */

    /* clean up stuff */
    if (stats) dump_hash_stats();
    clear_data();
    return 0;
}
