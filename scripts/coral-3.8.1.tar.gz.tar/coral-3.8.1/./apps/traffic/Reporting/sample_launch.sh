#!/bin/sh
# Sample shell command to use the t2_report.pl script.
# Example gleened from Caida - localize to your site
./crl_traffic2 -C 'interval 60' -p 32 /dev/point0 | \
ssh -C your_server.net "./t2_report' \
-C 'html_dir public_html/html_dir/point0'"
