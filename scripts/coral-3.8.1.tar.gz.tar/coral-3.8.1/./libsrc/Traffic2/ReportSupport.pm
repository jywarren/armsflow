## $Id: ReportSupport.pm,v 1.6 2007/06/06 18:17:51 kkeys Exp $ $Name: release-3-8-1 $
## 
## Copyright 2005, 2006, 2007
## The Regents of the University of California 
## All Rights Reserved 
## 
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
## 
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
## 
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
## 
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
## 
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program.  Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
## 
## Report bugs and suggestions to coral-bugs@caida.org.
## 

# This package provides basic config-file parsing for all components of the
# report generator.

package CAIDA::Traffic2::ReportSupport;

use Exporter ();
@ISA       = qw(Exporter);
@EXPORT    = qw(parse_fields get_config_list get_config_var get_config_keys
		get_config_hash get_best_list get_best_var parse_config);
@EXPORT_OK = qw();

use strict;

my $special_key = '__INTERNAL__';

sub parse_fields {
    my ($filehandle, $config_ref) = @_;

    my %stanza;
    while (<$filehandle>) {
	chomp;
	next if /^\s*(#.*)?$/;
	last if /}/;
	my ($key, $value) = split /:/, $_, 2;
	if ($key =~ /^\s*(.*)\s*$/) {
	    $key = $1;
	}
	if ($value =~ /^\s*(.*[^\s])\s*$/) {
	    $value = $1;
	}
	if ($key eq 'name') {
	    $config_ref->{$value} = \%stanza;
	    push @{$config_ref->{$special_key}}, $value;
	} else {
	    $stanza{$key} = $value;
	    push @{$stanza{$special_key}}, $key;
	}
    }
}

sub get_config_var ($$) {
    my ($ref, $var) = @_;
    if (defined $ref and exists $ref->{$var}) {
	return $ref->{$var};
    } else {
	return undef;
    }
}

sub get_config_list ($$) {
    my ($ref, $var) = @_;
    if (defined $ref and exists $ref->{$var}) {
	return split /,\s*/, $ref->{$var};
    } else {
	return ();
    }
}

# Variants of get_config_var and get_config_list that choose from the
# first stanza, but can be overridden by the second, used for implementing
# default values.
sub get_best_var($$$) {
    my ($default_stanza, $override_stanza, $field_name) = @_;
    my $default = get_config_var($default_stanza, $field_name);
    my $override = get_config_var($override_stanza, $field_name);
    if (defined $override) {
	return $override;
    } else {
	return $default;
    }
}

sub get_best_list($$$) {
    my ($default_stanza, $override_stanza, $field_name) = @_;
    my @default = get_config_list($default_stanza, $field_name);
    my @override = get_config_list($override_stanza, $field_name);
    if (@override > 0) {
	return @override;
    } else {
	return @default;
    }
}

# Works on both top-level hash and per-stanza hash.
sub get_config_keys ($) { # Maintains original order
    my ($ref) = @_;
    if (defined $ref and exists $ref->{$special_key}) {
	return @{$ref->{$special_key}};
    } else {
	return ();
    }
}

# Works on both top-level hash and per-stanza hash.
sub get_config_hash ($) { # For direct access, removes special keys
    my ($ref) = @_;
    if (defined $ref) {
	my %ret_val = %$ref;
	delete $ret_val{$special_key};
	return %ret_val;
    } else {
	return ();
    }
}

# Takes a hash ref mapping patterns -> config hashes.
sub parse_config {
    my ($filehandle, $config_patterns_ref) = @_;

    while (<$filehandle>) {
	next if /^\s*(#.*)?$/;
	foreach my $pattern (keys %$config_patterns_ref) {
	    if (/$pattern/) {
		parse_fields($filehandle, $config_patterns_ref->{$pattern});
	    }
	}
    }
}

1;
