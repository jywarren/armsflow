## 
## Copyright 2004, 2005, 2006, 2007 The Regents of the University of California 
## All Rights Reserved 
## 
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
## 
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
## 
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
## 
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
## 
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program. Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
## 
## Report bugs and suggestions to coral-bugs@caida.org.
## 
package CAIDA::Tables::make_LatLon_Table;
require Exporter;
@ISA = qw(Exporter);
@EXPORT = qw(&make_LatLon_Table &make_src_LatLon_Table &make_dst_LatLon_Table);

# Define required CVS variables
$cvs_Id = '$Id: make_LatLon_Table.pm,v 1.8 2007/06/06 18:17:48 kkeys Exp $';
$cvs_Author = '$Author: kkeys $';
$cvs_Name = '$Name: release-3-8-1 $';
$cvs_Revision = '$Revision: 1.8 $';

use Carp;
use CAIDA::Tables::get_Country;
use strict;

sub make_src_LatLon_Table {
    return make_LatLon_Table(shift, shift, 'src');
}

sub make_dst_LatLon_Table {
    return make_LatLon_Table(shift, shift, 'dst');
}

sub make_LatLon_Table {
    my ($self, $args, $src_dst) = @_;
    my $netacq = $args->{'netacq'};
    my $countries = $args->{'countries'};
    my $netgeo = $args->{'netgeo'};
    my $as_finder = $args->{'as_finder'};
    my ($has_ip, $uses_ip, $uses_as, $uses_country, $from_matrix);
    $uses_as = 1 if ref($self) =~ /AS_/;
    if (ref($self) =~ /Tuple_Table/ or ref($self) =~ /IP_/) {
	$has_ip = 1;
	if ($netacq) {
	    $uses_ip = 1;
	} else {
	    $uses_as = 1;
	}
    }
    # XXX Super-super hack because of SWIG and aliasing.
    $uses_country = 1 if ref($self) =~ /Country_/ or ref($self) =~ /String_/;
    $from_matrix = 1 if ref($self) =~ /Tuple_Table/ or ref($self) =~ /Matrix/;
    if ($uses_as and $has_ip and not $as_finder) {
	die "Need an ASFinder object to do lat/lon lookups.";
    } elsif ($uses_country and not $countries) {
	die "Need a Countries object to do lat/lon lookups.";
    } elsif ($uses_as and not $netgeo) {
	die "Need a NetGeoClient object to do lat/lon lookups.";
    }
    if ($from_matrix and not defined $src_dst) {
	die "make_LatLon_Table() is not supported by this class.\n" .
		"Please use make_{src|dst}_LatLon_Table().";
    }

    require CAIDA::Tables::LatLon_Table;
    my $latlon_table = new CAIDA::Tables::LatLon_Table();
    my $desired_table;
    if ($uses_ip) {
	$desired_table = 'IP_Table';
    } elsif ($uses_as) {
	$desired_table = 'AS_Table';
    } else { # Only option left is Country.
	$desired_table = 'Country_Table';
    }
    # Convert intermediate table.
    my $temp_table;
    if ($from_matrix) {
	eval "\$temp_table = \$self->make_${src_dst}_$desired_table(\$args);";
	die "Can't create $desired_table: $@" if $@;
    } elsif (ref($self) =~ /$desired_table/ or $uses_country) {
	$temp_table = $self;
    } else {
	eval "\$temp_table = \$self->make_$desired_table(\$args);";
	die "Can't create $desired_table: $@" if $@;
    }
    # Loop over table elements, collecting keys
    my @keys;
    foreach my $opaque_key (keys %{ $temp_table->data() }) {
	my ($key) = $temp_table->get_key_fields($opaque_key);
	push @keys, $key;
    }
    my $key_to_loc_ref;
    # Do table key -> latlon conversion
    if ($uses_ip) {
	$key_to_loc_ref = _get_locs_byIP($netacq, undef, undef, @keys);
    } elsif ($uses_as) {
	$key_to_loc_ref = _get_locs_byAS($netgeo, undef, undef, @keys);
    } else { # Only option left is Country.
	$key_to_loc_ref = _get_locs_byCountry($countries, @keys);
    }
    # Loop over table elements, making LatLon Table
    while (my ($opaque_key, $counts) = each %{ $temp_table->data() }) {
	my ($key) = $temp_table->get_key_fields($opaque_key);
	my $loc_ref = $key_to_loc_ref->{$key};
	my ($lat, $lon) = (0, 0);
	if (defined $loc_ref) { # Should always be true, but...
	    (undef, $lat, $lon) = @{$key_to_loc_ref->{$key}};
	}
	$latlon_table->entry_add("$lat,$lon", $counts);
    }
    $latlon_table->total->add($self->other);
    $latlon_table->other->add($self->other);
    return $latlon_table;
}

1;
