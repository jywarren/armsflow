/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 * coral_data.c - methods to get trace blocks from the various CORAL
 *                sources.
 *
 */

static const char RCSid[]="$Id: coral_data.c,v 1.247 2007/06/06 18:17:53 kkeys Exp $";

#include "config.h"
#include "coraldefs.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>   
#include <unistd.h>
#include <ctype.h>
#include <time.h>
#include <netinet/in.h>
#include <sys/ioctl.h>

#ifdef HAVE_SYS_IOCCOM_H
#include <sys/ioccom.h>
#endif
#ifdef HAVE_CORAL_DEVICES
# include "drivers/coral_ioctl.h"
#endif

#include "libcoral.h"
#include "libcoral_priv.h"

int coral_max_src = 0, coral_max_iface = 0;

static const struct timeval tvzero = {0, 0};
static const struct timespec tszero = {0, 0};
static struct timespec interval_begin = {0, 0};
static struct timespec interval_end = {0, 0};

/* internal data for duration */
struct timeval coral_duration_end = { -1, -1 };
int coral_all_running = 0;

/* internal data for cell reading */
static coral_iface_t *c_blk_iface = NULL;	/* interface of current blk */

static int coral_int_flag = 0;
static coral_interval_result_t coral_int_result;

/* coral_read_cell_all_common points to either coral_read_cell_natural() or
 * coral_read_cell_sorttime() depending on programmer's options. */
coral_iface_t *(*coral_read_cell_all_common)
    (coral_blk_info_t **binfo, coral_atm_cell_t **cell, struct timeval *tv,
    coral_interval_result_t *int_result, struct timeval *interval) =
	coral_read_cell_natural;

void (*coral_cell_block_hook)(const coral_iface_t *iface,
    const coral_blk_info_t *binfo) = NULL;

coral_source_t *coral_next_source(const coral_source_t *src)
{
    int sd;

    if (src)
	validate_src(src, "coral_next_source", NULL);

    for (sd = src ? src->sd + 1 : 0; sd < coral_config.maxsrc; sd++) {
	if (csource[sd])
	    return csource[sd];
    }
    return NULL;
}

coral_iface_t *coral_next_interface(const coral_iface_t *iface)
{
    int id;

    if (iface)
	validate_iface(iface, "coral_next_interface", NULL);

    for (id = iface ? iface->id + 1 : 0; id < coral_max_iface; id++) {
	if (cinst[id])
	    return cinst[id];
    }
    return NULL;
}

coral_iface_t *coral_next_src_iface(const coral_source_t *src,
    const coral_iface_t *iface)
{
    int sid;

    validate_src(src, "coral_next_src_iface", NULL);
    if (iface) {
	validate_iface(iface, "coral_next_src_iface", NULL);
	if (iface->src != src) {
	    coral_diag(0,("coral_next_src_iface: src and iface don't match\n"));
	    return NULL;
	}
    }

    sid = iface ? iface->sid + 1 : 0;
    return (sid < src->iface_count) ? cinst[src->id[sid]] : NULL;
}

int coral_source_is_block(const coral_source_t *src)
{
    validate_src(src, NULL, CORAL_TYPE_NONE);
    /* NB: (src->type.is_block) would give incorrect result on TSH file */
    return !!src->type.nextblk;
}

int coral_source_get_type(const coral_source_t *src)
{
    validate_src(src, NULL, CORAL_TYPE_NONE);
    return src->type.coral_type;
}

int coral_interface_get_type(const coral_iface_t *iface)
{
    validate_iface(iface, NULL, CORAL_TYPE_NONE);
    return iface->iface_info.hw_type;
}

coral_protocol_t coral_interface_get_datalink(const coral_iface_t *iface)
{
    validate_iface(iface, NULL, -1);
    return iface->iface_info.datalink;
}

coral_protocol_t coral_interface_get_physical(const coral_iface_t *iface)
{
    validate_iface(iface, NULL, -1);
    return iface->iface_info.physical;
}

int32_t coral_interface_get_bandwidth(const coral_iface_t *iface)
{
    validate_iface(iface, NULL, -1);
    return iface->iface_info.bandwidth;
}

time_t coral_interface_get_capturetime(const coral_iface_t *iface)
{
    validate_iface(iface, NULL, -1);
    return iface->iface_info.capture_tv.tv_sec;
}

const struct timeval *coral_interface_get_capture_tv(const coral_iface_t *iface)
{
    validate_iface(iface, NULL, NULL);
    return &iface->iface_info.capture_tv;
}

void set_iface_duration(coral_iface_t *iface)
{
    if (coral_config.duration > 0) {
	iface->duration_end.tv_sec = iface->iface_info.capture_tv.tv_sec;
	iface->duration_end.tv_nsec = iface->iface_info.capture_tv.tv_usec*1000;
	iface->duration_end.tv_sec += coral_config.duration;
	/* This is always called before begin_interval, which may
	 * override period_end. */
	iface->period_end = iface->duration_end;
	if (iface->iface_type->clock_native) {
	    iface->iface_type->clock_native(iface, &iface->period_end,
		&iface->native_period_end);
	}
    } else {
	iface->duration_end.tv_sec = iface->duration_end.tv_nsec = -1;
    }
}

/* Set iface's capture tv if it isn't already (because it wasn't in the file
 * header), using tspec or tstamp. */
void coral_set_iface_capture_tv(coral_iface_t *iface,
    struct timespec *tspec, const coral_timestamp_t *tstamp)
{
    struct timespec lts;

    if (!iface->iface_info.capture_tv.tv_sec /* && tspec->tv_sec >= 0 XXX */) {
	if (!tspec) {
	    tspec = &lts;
	    assert(iface->time_is_normal);
	    coral_clock_timespec_inline(iface, tstamp, tspec, 0);
	}
	iface->iface_info.capture_tv.tv_sec = tspec->tv_sec;
	iface->iface_info.capture_tv.tv_usec = tspec->tv_nsec / 1000;
	set_iface_duration(iface);
    }
}

/* Return index of first record in block between low and high with
 * timestamp >= key.  Assumes timestamps in block are monotonically
 * increasing. */
static long block_time_search(coral_iface_t *iface, const char *data,
    long low, long high, const struct timespec *key)
{
    void *cell;
    const coral_timestamp_t *ts;
    struct timespec tspec;
    long mid;

    /* Usually, last cell is within the time, so test it first. */
    cell = ((char*)data) + coral_cell_size(iface) * (high - 1);
    ts = coral_cell_time_req(iface, cell);

    /* don't bother caching timestamp */
    iface->iface_type->clock_read_timespec(iface, ts, &tspec);
    if (!iface->time_is_normal)
	coral_normalize_timespec(iface, &tspec);

    if (timespeccmp(&tspec, key, <))
	return high;

    /* Otherwise, do a binary search. */
    while (high - low > 1) {
	mid = (high + low) / 2;
	cell = ((char*)data) + coral_cell_size(iface) * mid;
	ts = coral_cell_time_req(iface, cell);

	/* don't bother caching timestamp */
	iface->iface_type->clock_read_timespec(iface, ts, &tspec);
	if (!iface->time_is_normal)
	    coral_normalize_timespec(iface, &tspec);

	if (timespeccmp(&tspec, key, <))
	    low = mid;
	else
	    high = mid;
    }
    return high;
}

/* If a timestamp > iface->duration_end, truncate the block
 * and mark the iface as expired.  Returns the new cell_count.
 * This is called immediately after block is read, before it is queued,
 * so we can't use iface->u.blk. */
long coral_check_block_duration(coral_iface_t *iface, const char *data,
    unsigned long cell_count, unsigned long start)
{
    long result;

    if (iface->duration_end.tv_sec <= 0)
	return cell_count;

    /* Make sure capture_tv and duration are set _correctly_ */
    if (!iface->iface_info.capture_tv.tv_sec) {
	coral_set_iface_capture_tv(iface, NULL,
	    coral_cell_time_req(iface, data));
    }

    result = block_time_search(iface, data, start - 1, cell_count,
	&iface->duration_end);

    if (result < cell_count) {
	coral_diag(4, ("coral_check_block_duration: "
	    "duration expired on interface %d\n", iface->id));
	iface->expired = 1;
    }
    return result;
}

/* Set iface->u.blk.node.next_int to first record past the current interval.
 * This is called when a block reaches the head of a queue or a new interval
 * begins, so we can use iface->u.blk. */
void coral_check_block_interval(coral_iface_t *iface)
{
    if (!iface->have_interval || iface->synced) {
	iface->u.blk.node.next_int = iface->u.blk.node.cell_count;
	return;
    }
    /* index may be > 0 if cells were discarded because of clock reset */
    iface->u.blk.node.next_int = block_time_search(iface,
	iface->u.blk.node.data, iface->u.blk.node.index - 1,
	iface->u.blk.node.cell_count, &iface->period_end);
    iface->synced = (iface->u.blk.node.index >= iface->u.blk.node.next_int);
}

/* Read next block if there is one, and queue it on the iface structure
 * to which it belongs.  If (is_first), ignores queue structure and just
 * stores block in first node.  Or return NULL and errno==EAGAIN.
 * Nonblocking.  Checks for duration.
 */
coral_iface_t *coral_queue_nextblk(coral_source_t *src, int no_queue, int endonly)
{
    coral_iface_t *iface;
    const coral_timestamp_t *ts;
    struct timespec tspec;
    coral_blk_info_t *binfo;
    coral_atm_cell_t *data;
    coral_blknode_t *blknode;
    unsigned long cell_count, idx;
    int is_first;

    if (coral_config.max_blks && coral_config.blks >= coral_config.max_blks) {
	errno = 0;
	return NULL;
    }

    if (!src->type.nextblk) {
	coral_diag(0, ("%s: not a coral block interface\n", src->name));
	errno = EBADF;
	return NULL;
    }

retry:
    if (src->eof) return NULL;
    iface = src->type.nextblk(src, &binfo, &data, endonly);
    if (!iface) {
	if (errno == EAGAIN) return NULL;
	coral_mark_eof_src(src);
	if (errno)
	    coral_diag(0, ("coral_queue_nextblk: %s: %s\n",
		src->name, strerror(errno)));
	return NULL; /* with errno */
    }
    if (iface->eof) {
	/* src may contain other ifaces that aren't done yet. */
	goto retry;
    }
    coral_config.blks++;

    cell_count = ntohl(binfo->cell_count);
    coral_diag(19, ("coral_queue_nextblk: read block with %d records from iface %d\n",
	cell_count, iface->id));

    idx = 0;
    if (no_queue)
	iface->holding = 0;
    if (iface->iface_type->correct_clock && !endonly) {
	idx = iface->iface_type->correct_clock(iface, binfo, data);
	if (errno)
	    return NULL; /* with errno */
    }

    if (binfo->cells_lost) {
	ts = coral_cell_time_req(iface, data);
	CORAL_TIMESTAMP_TO_TIMESPEC(iface, ts, &tspec);
	coral_diag(1, ("warning: interface %d lost %u cells around %d.%09d\n",
	    iface->id, ntohl(binfo->cells_lost),
	    tspec.tv_sec, tspec.tv_nsec));
    }

    /* if a timestamp > iface->duration_end, truncate the block */
    if (cell_count > idx && !endonly && iface->duration_end.tv_sec >=0) {
	cell_count = coral_check_block_duration(iface, data, cell_count, idx);
	if (cell_count <= idx) {
	    coral_mark_eof(iface);
	    goto retry;
	}
	binfo->cell_count = htonl(cell_count);
    }

    if (iface->eof)
	goto retry;	/* ignore data from this iface */

    if (cell_count <= idx)
	goto retry;	/* discard empty block */

    /* If caller requested non-queuing, or queue is empty, use 1st queue node */
    is_first = no_queue || !iface->u.blk.node.data;
    blknode = is_first ? &iface->u.blk.node : malloc(sizeof(coral_blknode_t));
    if (!blknode) return NULL; /* with errno */
    blknode->next = NULL;
    blknode->block = NULL;
    blknode->data = data;
    blknode->binfo = binfo;
    blknode->cell_count = cell_count;
    blknode->index = idx;
    blknode->next_int = cell_count; /* until check_block_interval sets it */
    if (!is_first)
	iface->u.blk.tail->next = blknode;
    iface->u.blk.tail = blknode;
    iface->u.blk.blk_count++;
    iface->have_blk = 1;

    if (coral_cell_block_hook)
	coral_cell_block_hook(iface, binfo);

    if (!iface->holding)
	return iface;
    assert(iface->src->type.coral_type == CORAL_TYPE_FILE);

    if (coral_config.max_blks && coral_config.blks >= coral_config.max_blks) {
	errno = 0;
	return iface;
    }
    /* Steal buffer from iface->src. */
    blknode->block = iface->src->ubase;
    iface->src->ubase = NULL;

    goto retry;
}

static coral_iface_t *coral_read_block_x(coral_source_t *src,
    coral_blk_info_t **binfop, coral_atm_cell_t **cellp,
    struct timeval *timeout, int endonly)
{
    struct timeval tv;
    coral_iface_t *iface;

    validate_src(src, "coral_read_block", NULL);

    if (src->eof) {
	errno = 0;
	return NULL;
    }
    if (!src->type.nextblk) {
	errno = EBADF;
	return NULL;
    }

    timeout = calculate_timeout(timeout, &tv);

    if ((!timeout || timercmp(timeout, &tvzero, >)) && src->type.is_live) {
	fd_set readers;
	int count;

retry:
	FD_ZERO(&readers);
	FD_SET(src->fd, &readers);
	count = select(src->fd + 1, &readers, NULL, NULL, timeout);
	if (count < 0) {
	    coral_diag(0, ("coral_read_blk: select: %s\n", strerror(errno)));
	    return NULL;
	}

	if (realtime_duration_ended(src) && !count) {
	    /* coral drivers will return their last blocks immediately */
	    timeout = NULL;
	    goto retry;
	}

	if (count == 0) {
	    /* timeout (other than duration) */
	    errno = EAGAIN;
	    return NULL;
	}
    }

    iface = coral_queue_nextblk(src, 1, endonly);
    if (iface) {
	*binfop = iface->u.blk.node.binfo;
	*cellp = iface->u.blk.node.data;
    }
    return iface;
}

coral_iface_t *coral_read_block(coral_source_t *src,
    coral_blk_info_t **binfop, coral_atm_cell_t **cellp,
    struct timeval *timeout)
{
    return coral_read_block_x(src, binfop, cellp, timeout, 0);
}

/* Read only the first and last cell within the block, efficiently.
 * Ignores duration and clock correction.
 */
coral_iface_t *coral_read_block_endonly(coral_source_t *src,
    coral_blk_info_t **binfop, coral_atm_cell_t **cellp,
    struct timeval *timeout)
{
    return coral_read_block_x(src, binfop, cellp, timeout, 1);
}

/* Like normal select, but also selects all coral sources for block
 * readability, and STOPs them when duration expires in realtime.
 */
static int coral_blk_select(int nfds, fd_set *rfds, fd_set *wfds, fd_set *efds,
    struct timeval *timeout)
{
    int count = 0;
    struct timeval tv;

    if (coral_noselect_count) {
	timeout = &tv;
	*timeout = tvzero;
    }
    if (coral_select_count) {
	if (!coral_all_running) {
            /* There must be some stopped devices that still have some data.
             * They should return immediately. */
            timeout = NULL;
	} else {
	    timeout = calculate_timeout(timeout, &tv);
	}
    }

    if (coral_select_count > 0 || nfds > 0) {
retry: /* come here after duration expires in select() */
	coral_or_fd_set(coral_select_fd_max + 1, rfds, &coral_select_fds);
	if (nfds <= coral_select_fd_max)
	    nfds = coral_select_fd_max + 1;
	coral_diag(19, ("select...\n"));
	count = select(nfds, rfds, wfds, efds, timeout);
	if (count < 0) {
	    coral_diag(0,("coral_blk_select: select: %s\n", strerror(errno)));
	    return count;
	}
	coral_diag(19, ("select returned %d\n", count));
	if (realtime_duration_ended(NULL) && !count) {
	    /* STOPed drivers should return their last blocks immediately */
	    timeout = NULL;
	    goto retry;
	}
    }
    return count;
}

coral_iface_t *coral_read_block_all(coral_blk_info_t **binfop,
    coral_atm_cell_t **cellp, struct timeval *timeout)
{
    fd_set readable;
    static int sd = 0;
    int stop, count = 0;
    coral_iface_t *iface;
    coral_source_t *src;

    if (!coral_select_count && !coral_noselect_count) {
	/* no sources left; return EOF indicator */
	*binfop = NULL;
	*cellp = NULL;
	errno = 0;
	return NULL;
    }

    FD_ZERO(&readable);
    count = coral_blk_select(0, &readable, NULL, NULL, timeout);
    if (count < 0)
	return NULL;

    if (count == 0 && !coral_noselect_count) {
	errno = EAGAIN; /* indicate timeout */
	return NULL;
    }

    /* Scan the source list starting just after the point where we left off
     * last time, so that each source gets equal treatment.  */
    stop = sd;
    do {
	src = csource[sd];
        sd = (sd + 1) % coral_max_src;
	/* If source is valid, open, and may have data, read it. */
	if (src && !src->eof &&
	    (!src->type.is_live ||
	    (src->fd >= 0 && FD_ISSET(src->fd, &readable))))
	{
	    /* check source for waiting data. */
	    iface = coral_queue_nextblk(src, 1, 0);
	    if (iface) {
		*binfop = iface->u.blk.node.binfo;
		*cellp = iface->u.blk.node.data;
		return iface;
	    } else if (errno) {
		return iface;
	    }
	}
    } while (sd != stop);

    if (!coral_select_count && !coral_noselect_count) {
	/* no fd's left; return EOF indicator */
	coral_diag(19, ("read_block_all: EOF\n"));
	*binfop = NULL;
	*cellp = NULL;
	errno = 0;
	return 0;
    }

    coral_diag(0, ("coral: driver select problem maybe?\n"));
    errno = EBADF;
    return NULL;
}

void coral_align_interval(struct timespec *end, struct timespec *interval)
{
    if (interval->tv_nsec > 0) {
	coral_diag(1, ("rounding end of first interval to whole second\n"));
	end->tv_sec = end->tv_sec;
	end->tv_nsec = 0;
    } else {
	/* TODO: base at midnight localtime instead of unix epoch */
	end->tv_sec = (end->tv_sec / interval->tv_sec) * interval->tv_sec;
	end->tv_nsec = 0;
    }
}

static int interval_is_done(coral_iface_t *iface, struct timespec *ts,
    struct timeval *interval)
{
    struct timespec ts_interval;
    ts_interval.tv_sec = interval->tv_sec;
    ts_interval.tv_nsec = interval->tv_usec * 1000;
    if (timespeccmp(&interval_end, &tszero, ==)) {
	/* begin first interval */
	interval_end = interval_begin = *ts;
	timespecadd(&interval_end, &ts_interval);
	if (coral_config.flags & CORAL_OPT_ALIGNINT)
	    coral_align_interval(&interval_end, &ts_interval);
    } else if (timespeccmp(ts, &interval_end, >=)) {
	coral_int_result.begin.tv_sec = interval_begin.tv_sec;
	coral_int_result.begin.tv_usec = interval_begin.tv_nsec / 1000;
	coral_int_result.end.tv_sec = interval_end.tv_sec;
	coral_int_result.end.tv_usec = interval_end.tv_nsec / 1000;
	coral_int_result.stats = NULL;
	coral_int_flag = 1;
	interval_begin = interval_end;
	timespecadd(&interval_end, &ts_interval);
	coral_diag(8, ("interval end: %u.%06u - %u.%06u\n",
	    coral_int_result.begin.tv_sec, coral_int_result.begin.tv_usec,
	    coral_int_result.end.tv_sec, coral_int_result.end.tv_usec));
	return 1;
    }
    return 0;
}

#define	DEBUG_CELL_TIME	0

#if DEBUG_CELL_TIME
# define DEBUG_DIAG(level, args)	coral_diag(level, args)
#else
# define DEBUG_DIAG(level, args)	do { /* empty */ } while (0)
#endif

/* Returns 1 iff index still points within blk.  If it reaches the end of
 * an expired interface, marks it as EOF. */
static int inline increment_index(coral_iface_t *iface)
{
    iface->u.blk.node.index++;
    if (iface->u.blk.node.index >= iface->u.blk.node.cell_count) {
	coral_diag(19, ("end of block on iface %d\n", iface->id));
	if (iface->expired)
	    coral_mark_eof(iface);
	return 0;
    }
    return 1;
}

/* get source's current {blknode,cell} */
#define scblk(src)	((src)->current_iface->u.blk)
#define scnode(src)	(scblk(src).node)
#define sccell(src)	coral_nth_cell((src)->current_iface, \
    scnode(src).data, scnode(src).index)

/* get a cell from one source (in block order) */
static coral_iface_t *coral_read_cell_common(coral_source_t *src,
    coral_blk_info_t **binfop, coral_atm_cell_t **cellp, struct timeval *tv,
    coral_interval_result_t *int_result, struct timeval *interval)
{
    coral_iface_t *iface;
    union atm_hdr atm_hdr;
    coral_protocol_t proto;
    coral_atm_cell_t *data;
    coral_blk_info_t *binfo;

    if (src->eof ||
       (coral_config.max_cells && coral_config.cells >= coral_config.max_cells))
    {
        errno = 0;
        return NULL;
    }

retry:
    while (!src->current_iface || scnode(src).index >= scnode(src).cell_count) {
	iface = coral_read_block(src, &binfo, &data, tv);

	if (!iface) {		/* error or eof */
	    if (errno)		/* error */
		return NULL;
	    if (!src->current_iface || !interval ||
		timercmp(interval, &tvzero, <=))
	    {
		/* EOF */
		interval_end.tv_sec = interval_end.tv_nsec = 0;
		return NULL;
	    }

	    /* end truncated last interval */
	    int_result->begin.tv_sec = interval_begin.tv_sec;
	    int_result->begin.tv_usec = interval_begin.tv_nsec / 1000;
	    int_result->end.tv_sec = src->ts.tv_sec;
	    int_result->end.tv_usec = src->ts.tv_nsec / 1000;
	    int_result->stats = NULL;
	    iface = src->current_iface;
	    src->current_iface = NULL;	/* so next call will return EOF */
	    return iface;
	}
	src->current_iface = iface;
	iface->pkt_stats.l2_recv += scnode(src).cell_count;
	iface->pkt_stats.l2_drop += ntohl(scnode(src).binfo->cells_lost);
    }
    iface = src->current_iface;		/* just for convenience */

    if (interval && timercmp(interval, &tvzero, >)) {
	coral_clock_timespec_inline_nf(iface,
	    coral_cell_time_req(iface, sccell(src)), &src->ts);
	if (interval_is_done(iface, &src->ts, interval)) {
	    *int_result = coral_int_result;
	    if (binfop) *binfop = NULL;
	    *cellp = NULL;
	    return iface;
	}
    }

    if (binfop)
	*binfop = scnode(src).binfo;
    *cellp = sccell(src);
    increment_index(src->current_iface);

    atm_hdr.ui = ntohl(coral_cell_header_req(iface, *cellp)->ui);
    if (!coral_proto_rule(iface, atm_hdr.h.vpvc, &proto))
	goto retry;

    coral_config.cells++;
    return iface;
}

/* get a cell from any interface, in block order (queueing is never needed) */
coral_iface_t *coral_read_cell_natural(coral_blk_info_t **binfop,
    coral_atm_cell_t **cellp, struct timeval *timeout,
    coral_interval_result_t *int_result, struct timeval *interval)
{
    coral_blk_info_t *binfo;
    coral_atm_cell_t *data;
    union atm_hdr atm_hdr;
    coral_protocol_t proto;

    if (interval && timercmp(interval, &tvzero, >)) {
	coral_set_options(0, CORAL_OPT_SORT_TIME);
	return coral_read_cell_all_common(binfop, cellp, timeout,
	    int_result, interval);
    }

    if (coral_config.max_cells && coral_config.cells >= coral_config.max_cells)
    {
        errno = 0;
        return NULL;
    }

retry:
    while (!c_blk_iface ||
	c_blk_iface->u.blk.node.index >= c_blk_iface->u.blk.node.cell_count)
    {
	c_blk_iface = coral_read_block_all(&binfo, &data, timeout);
	if (!c_blk_iface) return NULL;	/* error or eof (with errno) */
    }

    if (binfop) *binfop = c_blk_iface->u.blk.node.binfo;
    *cellp = coral_iccell(c_blk_iface);
    increment_index(c_blk_iface);

    atm_hdr.ui = ntohl(coral_cell_header_req(c_blk_iface, *cellp)->ui);
    if (!coral_proto_rule(c_blk_iface, atm_hdr.h.vpvc, &proto))
	goto retry;

    coral_config.cells++;
    return c_blk_iface;
}


/* Set up a new current block for iface.  Assumes blknode is not empty. */
void coral_new_current_block(coral_iface_t *iface)
{
    assert(iface->u.blk.node.cell_count > 0);
    iface->have_data = 1;

    /* check block for interval */
    if (iface->have_interval) {
	coral_check_block_interval(iface);
    }

    coral_set_ts(iface, coral_cell_time_req(iface, coral_iccell(iface)));
    iface->src->ts = iface->latest_ts;
    DEBUG_DIAG(19, ("coral_new_current_block: x: new block %d: cell_count %d\n",
	iface->id, iface->u.blk.node.cell_count));
}

/* Generic read_min() for most block sources with 1 interface (which don't need
 * to queue more than 1 block at a time).  It reads until it gets a non-empty
 * block, EOF, EAGAIN, or error.
 *
 * If you edit this, don't forget to edit the other coral_*_read_min functions too.
 */
coral_iface_t *coral_blk_read_min(coral_iface_t *target_iface)
{
    coral_iface_t *iface;

    assert(!target_iface->src->type.release);
    do {
	iface = coral_queue_nextblk(target_iface->src, 0, 0);
	if (!iface) return NULL /* with errno */;
	assert(iface == target_iface);
	assert(!iface->eof);
    } while (target_iface->u.blk.node.cell_count <= 0);
    coral_new_current_block(iface);
    return iface;
}   

/* Generic consume() for interfaces that read cells and may queue blocks. */
int coral_cell_consume(coral_iface_t *iface, int want)
{
    if (!iface->have_blk)
	return 0;
    /* Move to the next cell. */
    if (increment_index(iface)) {
	if (want == CORAL_WANT_TIME) {
	    /* Use next cell to update timestamp */
	    coral_set_ts(iface, coral_cell_time_req(iface,coral_iccell(iface)));
	    iface->src->ts = iface->latest_ts;
	}
	return 1;
    } else if (iface->eof) {
	return 0;
    }
    /* We've reached the end of the current block. */
    if (coral_dequeue_block(iface))
	coral_new_current_block(iface);
    return iface->have_blk;
}

int coral_dequeue_block(coral_iface_t *iface)
{
    coral_blknode_t *next;

    /* Get next blk from queue. (Assume empty blks are not queued.) */
    iface->have_blk = !!(next = iface->u.blk.node.next);
    assert(!next || iface->src->type.release);
    if (iface->src->type.release)
	iface->src->type.release(iface);
    if (!next) { /* End of queue? */
	iface->u.blk.tail = NULL;
	iface->u.blk.node.data = NULL;
	iface->u.blk.node.cell_count = 0;
    } else {
	/* Copy contents of next to current, and free next */
	iface->u.blk.node = *next;
	if (iface->u.blk.tail == next)
	    iface->u.blk.tail = &iface->u.blk.node;
	free(next);
    }
    return iface->have_blk;
}

int coral_freshen(coral_iface_t *iface, int want)
{
    iface->have_data = !!coral_read_iface(iface);
    if (!iface->iface_info.capture_tv.tv_sec) {
	coral_update_latest_ts(iface);
	if (iface->latest_ts.tv_sec >= 0)
	    coral_set_iface_capture_tv(iface, &iface->latest_ts, NULL);
    }

    return iface->have_data;
}

/* See if every interface has a timestamp stored on it.
 * Used only by time-sorting APIs.
 * <want> indicates the kind of read to do:  CORAL_WANT_TIME or CORAL_WANT_PKT.
 * If <rfds> is NULL, this function tests every interfaces, and returns the
 * number that are not current, ie missing timestamps that could possibly be
 * before now.  If <rfds> is not NULL, this function also will read
 * from every iface in <rfds> which is missing a timestamp, until it gets a
 * timestamp or is unable to read more.  Returns the number of interfaces that
 * are still missing timestamps, or -1 for error.  After the call, <mfds> will
 * contain the descriptors of sources that are still missing timestamps, and
 * <selectable> will contain the number of selectable (live) interfaces that
 * are missing timestamps.
 */
int coral_freshen_iface(coral_source_t *src, coral_iface_t *iface, int want,
    fd_set *rfds, fd_set *mfds, int *selectable)
{
    int i, missing = 0, unbuffered_missing = 0;
    int got_data_after_unbuffered_timeout = 0;

    *selectable = 0;
    FD_ZERO(mfds);

    for (i = 0; i < coral_max_iface; i++) {
	if (!coral_total_ifaces)
	    return 0;	/* XXX ? */
	if (!cinst[i] || cinst[i]->eof ||
	    (iface && cinst[i] != iface) || (src && cinst[i]->src != src))
	    continue;	/* don't want it */
	if (cinst[i]->have_data)
	    continue;	/* already have it */
	if (cinst[i]->src->is_interleaved &&
	    cinst[i]->src->current_iface != cinst[i])
	{
	    continue;	/* not current iface of interleaved src */
	}

	if (cinst[i]->src->pktq_max &&
	    cinst[i]->src->pktq_size >= cinst[i]->src->pktq_max)
		continue;	/* iface couldn't be this out-of-sync */

	/* Remember, is_buffered is not the same as is_live */
	if (!rfds ||					/* aren't reading */
	    (cinst[i]->src->type.is_buffered && cinst[i]->src->fd >= 0 &&
	     !FD_ISSET(cinst[i]->src->fd, rfds)))	/* can't read it */
	{
	    missing++;	/* can't get it */
	    if (cinst[i]->src->type.is_live) {
		++*selectable;
		FD_SET(cinst[i]->src->fd, mfds);
	    }
	    coral_diag(26, ("coral_freshen_iface: NOT reading from iface %d\n", i));
	    continue;
	}

	/* Read from cinst[i]->src. */
	coral_diag(25, ("coral_freshen_iface: reading from iface %d...\n", i));
	if (!coral_freshen(cinst[i], want)) {
	    if (errno == EAGAIN) {
		coral_diag(24, ("coral_freshen_iface: out of data on iface %d\n", i));
		if (cinst[i]->src->type.is_buffered) {
		    missing++;	/* can't get it */
		} else {
		    /* We know there's no buffered data, so we know this iface
		     * can't have a timestamp earlier than now.  And, if no
		     * more reads on other ifaces in this loop are successful,
		     * no ifaces with packets can have timestamps later than
		     * now.  So, we count this iface as missing iff there's
		     * another another iface with a successful read.
		     * (If any of the remaining ifaces are live pcap, the
		     * amount of time searching them is >1ms each, which is
		     * plenty of time for a new packet to arrive on this
		     * iface.)
		     */
		     unbuffered_missing++;
		}
		if (cinst[i]->src->type.is_live) {
		    ++*selectable;
		    if (cinst[i]->src->fd >= 0) {
			FD_SET(cinst[i]->src->fd, mfds);
			FD_CLR(cinst[i]->src->fd, rfds);
		    }
		}
	    } else if (!errno) {
		/* EOF (but other sources may still be open and other
		 * ifaces may still have buffers). */
		coral_diag(5, ("coral_freshen_iface: got EOF from iface %d\n", i));
		if (cinst[i]->src->fd >= 0)
		    FD_CLR(cinst[i]->src->fd/*XXX*/, rfds);
	    } else {
		coral_diag(24, ("coral_freshen_iface: returning: ERROR\n"));
		return -1;
	    }
	} else {
	    /* got it! */
	    coral_diag(25, ("coral_freshen_iface: got results from iface %d\n", i));
	    if (unbuffered_missing) got_data_after_unbuffered_timeout++;
	    coral_update_latest_ts(cinst[i]);
	}
    } /* for each iface */

    return missing + (got_data_after_unbuffered_timeout ? unbuffered_missing : 0);
}

/* Of interfaces that have_data, return the interface with the earliest
 * timestamp.  If src is not NULL, it searches only interfaces of src,
 * otherwise it searches all interfaces.  Note, nonsorting api still
 * calls this (via the sorting api) for the first packet of each interval.
 */
coral_iface_t *coral_find_earliest_iface(coral_source_t *src)
{
    int i;
    coral_iface_t *iface = NULL;	/* NULL means none was found yet */

    if (src) {
	if (src->is_interleaved)
	    return src->current_iface && src->current_iface->have_data ?
		src->current_iface : NULL;
	for (i = 0; i < src->iface_count; i++) {
	    int id = src->id[i];
	    if (cinst[id] && cinst[id]->have_data) {
		assert(cinst[id]->ts_is_valid); /* read_iface guarantees this */
		if (!iface || timespeccmp(&cinst[id]->latest_ts, &iface->latest_ts, <))
		    iface = cinst[id];
	    }
	}

    } else {
	for (i = 0; i < coral_max_iface; i++) {
	    /* On interleaved sources, look only at src->current_iface */
	    if (cinst[i] && cinst[i]->have_data &&
		(!cinst[i]->src->is_interleaved ||
		cinst[i] == cinst[i]->src->current_iface))
	    {
		assert(cinst[i]->ts_is_valid); /* read_iface guarantees this */
		if (!iface || timespeccmp(&cinst[i]->latest_ts, &iface->latest_ts, <))
		    iface = cinst[i];
	    }
	}
    }

    return iface;
}

/* All block sources must already have queued blocks.  This function finds
 * the earliest cell from those blocks.  If that cell is past the end of
 * the interval, return the interval info; otherwise, return the cell.
 */
static coral_iface_t *coral_get_sorted_cell(coral_source_t *src,
    coral_blk_info_t **binfop, coral_atm_cell_t **cellp,
    coral_interval_result_t *int_result, struct timeval *interval)
{
    coral_iface_t *last_iface;
    union atm_hdr atm_hdr;
    coral_protocol_t proto;
#if DEBUG_CELL_TIME
    static int count[2] = {0,0};
    int i, j;
    coral_blknode_t *blknode;
#endif

    last_iface = c_blk_iface;
retry:
    c_blk_iface = coral_find_earliest_iface(src);

#if DEBUG_CELL_TIME
    DEBUG_DIAG(30, ("cell_get_sorted_cell: ["));
    for (i = 0; i < coral_max_iface; i++) {
	if (!cinst[i]) continue;
	j = 0;
	for (blknode = &cinst[i]->u.blk.node; blknode; blknode = blknode->next)
	    j++;
	DEBUG_DIAG(30, (" %d", j));
    }
    DEBUG_DIAG(30, ("] "));
    if (c_blk_iface) count[c_blk_iface->id]++;
#endif

    if (!c_blk_iface) {	    /* no blocks left */
	if (!last_iface || !interval || timercmp(interval, &tvzero, <=)) {
	    /* EOF */
	    DEBUG_DIAG(10, ("returning: EOF\n"));
	    errno = 0;
	    interval_end.tv_sec = interval_end.tv_nsec = 0;
	    return NULL;
	}
	/* end truncated last interval */
	coral_int_result.begin.tv_sec = interval_begin.tv_sec;
	coral_int_result.begin.tv_usec = interval_begin.tv_nsec / 1000;
	assert(last_iface->ts_is_valid);
	coral_int_result.end.tv_sec = last_iface->latest_ts.tv_sec;
	coral_int_result.end.tv_usec = last_iface->latest_ts.tv_nsec / 1000;
	coral_int_result.stats = NULL;
	coral_int_flag = 1;
	*int_result = coral_int_result;
	*cellp = NULL;
	return last_iface;
    }

    assert(c_blk_iface->ts_is_valid);
    if (interval && timercmp(interval, &tvzero, >) &&
	interval_is_done(c_blk_iface, &c_blk_iface->latest_ts, interval))
    {
	*int_result = coral_int_result;
	if (binfop) *binfop = NULL;
	*cellp = NULL;
	return c_blk_iface;
    }

    if (binfop)
	*binfop = c_blk_iface->u.blk.node.binfo;
    *cellp = (coral_atm_cell_t*)coral_iccell(c_blk_iface);

    atm_hdr.ui = ntohl(coral_cell_header_req(c_blk_iface, *cellp)->ui);
    if (!coral_proto_rule(c_blk_iface, atm_hdr.h.vpvc, &proto))
	goto retry;

    DEBUG_DIAG(19, ("returning: iface %d, %5d, %3d.%09d (%5d, %5d)\n",
	c_blk_iface->id, c_blk_iface->u.blk.node.index,
	c_blk_iface->ts.tv_sec, c_blk_iface->ts.tv_nsec,
	count[0], count[1]));
    coral_config.cells++;
    return c_blk_iface;
}


/* Read a cell from any interface (in time order).  Blocking.
 * If src != NULL, reads only from src; if src == NULL, reads from all.
 */
static coral_iface_t *coral_wait_sorted_cell(coral_source_t *src,
    coral_blk_info_t **binfop, coral_atm_cell_t **cellp,
    struct timeval *timeout,	/* ignored */
    coral_interval_result_t *int_result, struct timeval *interval)
{
    int missing, selectable, n;
    fd_set rfds;    /* fds of srcs that are readable */
    fd_set mfds;    /* fds of srcs with ifaces that are still missing cells */

    if (coral_config.max_cells && coral_config.cells >= coral_config.max_cells)
    {
        errno = 0;
        return NULL;
    }

    selectable = coral_select_count;

    if (coral_int_flag) {
	coral_int_flag = 0;
    } else if (!c_blk_iface ||		/* first time we've been called */
	!coral_consume(c_blk_iface, CORAL_WANT_TIME))	/* no data left on iface we just used */
    {
	/* Make sure every cell interface has at least one cell in memory,
	 * or is at EOF.
	 */
	coral_copy_fd_set(coral_select_fd_max+1, &mfds, &coral_select_fds);
	do {
	    if (selectable) {
		coral_copy_fd_set(coral_select_fd_max+1, &rfds, &mfds);
		n = select(coral_select_fd_max+1, &rfds, NULL, NULL, NULL);
		if (n < 0) {
		    coral_diag(0, ("select: %s\n", strerror(errno)));
		    return NULL;
		}
	    }
	    missing = coral_freshen_iface(src, NULL/*XXX?*/, CORAL_WANT_TIME,
		&rfds, &mfds, &selectable);
	    if (missing < 0) {
		return NULL;
	    }
	} while (missing > 0);
    }

    return coral_get_sorted_cell(NULL, binfop, cellp, int_result, interval);
}


coral_iface_t *coral_read_cell(coral_source_t *src, coral_blk_info_t **binfop,
    coral_atm_cell_t **cellp, struct timeval *timeout)
{
    return coral_read_cell_common(src, binfop, cellp, timeout,
	NULL, NULL);
}

coral_iface_t *coral_read_cell_sorttime(coral_blk_info_t **binfop,
    coral_atm_cell_t **cellp, struct timeval *timeout,
    coral_interval_result_t *int_result, struct timeval *interval)
{
    return coral_wait_sorted_cell(NULL, binfop, cellp, timeout,
        int_result, interval);
}

coral_iface_t *coral_read_cell_i(coral_source_t *src, coral_blk_info_t **binfop,
    coral_atm_cell_t **cellp, coral_interval_result_t *int_result,
    struct timeval *interval)
{
    return coral_read_cell_common(src, binfop, cellp, NULL,
	int_result, interval);
}

coral_iface_t *coral_read_cell_all(coral_blk_info_t **binfop,
    coral_atm_cell_t **cellp, struct timeval *timeout)
{
    return coral_read_cell_all_common(binfop, cellp, timeout,
	NULL, NULL);
}

coral_iface_t *coral_read_cell_all_i(coral_blk_info_t **binfop,
    coral_atm_cell_t **cellp, coral_interval_result_t *int_result,
    struct timeval *interval)
{
    return coral_read_cell_all_common(binfop, cellp, NULL,
	int_result, interval);
}

#ifdef HAVE_CORAL_DEVICES
int coral_coraldev_start(coral_source_t *src)
{
    if (ioctl(src->fd, CORAL_START) < 0 && errno != EALREADY)
	return -1;
    return 0;
}
#endif

/*
 * tells the card to start listening, 
 * returns 0 for success, -1 for failure.
 */
static int coral_start_withtime(coral_source_t *src, struct timeval *starttime)
{
    struct timeval tv;
    int i;

    validate_src(src, "coral_start", -1);

    if (src->type.is_live && src->fd >= 0) {
	coral_select_count++;
	FD_SET(src->fd, &coral_select_fds);
	if (src->fd > coral_select_fd_max)
	    coral_select_fd_max = src->fd;
    } else {
	coral_noselect_count++;
    }

    *(src->type.is_live ? &coral_live_ifaces : &coral_offline_ifaces) +=
	src->iface_count;
    coral_total_ifaces += src->iface_count;

    if (!starttime) {
	if (gettimeofday(starttime = &tv, NULL) < 0) {
	    starttime->tv_sec = starttime->tv_usec = 0;
	}
    }

    if (src->type.start) {
	if (src->type.start(src) < 0) {
	    coral_diag(0, ("coral_start %s: %s\n",
		src->filename, strerror(errno)));
	    return -1;
	}
	coral_diag(4, ("coral_start: starting %s\n", src->name));
    }

    if (src->type.is_live) {
	struct tm *tm;
	long tzoff;
	const time_t tt = starttime->tv_sec; /* in case tv_sec isn't time_t */

	tm = localtime(&tt);
#ifdef TM_GMTOFF
	tzoff = !tm ? 0 : tm->TM_GMTOFF;
#else
	tzoff = 0;
#endif
	for (i = 0; i < src->iface_count; i++) {
	    cinst[src->id[i]]->iface_info.capture_tv = *starttime;
	    cinst[src->id[i]]->iface_info.tzoff = tzoff;
	}
    }

    for (i = 0; i < src->iface_count; i++) {
        coral_iface_t *iface = cinst[src->id[i]];
	set_iface_duration(iface);
	iface->have_data = 0;
	iface->u.blk.blk_count = 0;
	iface->latest_ts.tv_sec = iface->latest_ts.tv_nsec = -1;
	iface->ts_is_valid = 1;
	iface->eof = 0;
	iface->expired = 0;
    }
    src->eof = 0;
    src->started = 1;

    return 0;
}

int coral_start(coral_source_t *src)
{
    return coral_start_withtime(src, NULL);
}


#ifdef HAVE_CORAL_DEVICES
static inline void clocksync(int sd)
{
    if (ioctl(csource[sd]->fd, CORAL_CLOCKSYNC) < 0) {
	/* This error is not fatal, just a warning */
	coral_diag(1,
	    ("warning: coral_start_all: %s: ioctl CLOCKSYNC: %s",
	    csource[(sd)]->name, strerror(errno)));
    }
}
#endif

static inline int different_time_props(const coral_iface_t *a,
    const coral_iface_t *b)
{
    return ((a->time_is_normal != b->time_is_normal) ||
	(!b->time_is_normal &&
	(a->iface_info.capture_tv.tv_sec != b->iface_info.capture_tv.tv_sec ||
	a->iface_info.capture_tv.tv_usec != b->iface_info.capture_tv.tv_usec)));
}

void normalize_if_needed(const coral_source_t *src, const coral_iface_t *iface)
{
    int i, different = 0;

    if (iface || (coral_config.flags & CORAL_OPT_NORMALIZE_TIME)) {
	return;

    } else if (src) {
	/* find first iface */
	iface = cinst[src->id[0]];
	/* see if any of the other ifaces differ from first */
	for (i = 1; i < src->iface_count; i++)
	    if ((different = different_time_props(iface, cinst[src->id[i]])))
		break;

    } else {
	/* find first iface */
	for (i = 0; i < coral_max_iface; i++)
	    if ((iface = cinst[i])) break;
	/* see if any of the other ifaces differ from first */
	for (++i; i < coral_max_iface; i++)
	    if ((different = different_time_props(iface, cinst[i])))
		break;
    }

    /* If ifaces have different time properties, we must normalize them
     * for sorting, interval, duration */
    if (different) {
	coral_set_options(0, CORAL_OPT_NORMALIZE_TIME);
	coral_diag(1, ("warning: normalizing timestamps\n"));
    }
}

int coral_start_all(void)
{
    int i;
    struct timeval start;

#ifdef HAVE_CORAL_DEVICES
    {
	int point_sd = -1, fatm_sd = -1;

	/* Syncrhonize all the clocks as quickly as possible. */
	/* CLOCKSYNC on a card resets the clocks all the cards of the same
	 * type that are owned by this process.  So we look for one source
	 * of each type, and reset them.
	 */
	for (i = 0; i < CORAL_MAXOPEN; i++) {
	    if (csource[i]) {
		switch (csource[i]->type.coral_type) {
		    case CORAL_TYPE_FATM:	fatm_sd = i;	break;
		    case CORAL_TYPE_POINT:	point_sd = i;	break;
		    default:  break;
		}
	    }
	}

	if (fatm_sd >= 0)  clocksync(fatm_sd);
	if (point_sd >= 0) clocksync(point_sd);
    }
#endif
    gettimeofday(&start, NULL);

    for (i = 0; i < CORAL_MAXOPEN; i++) {
	if (csource[i]) {
	    if (coral_start_withtime(csource[i], &start) < 0)
		return -1;
	}
    }

    if (coral_config.duration > 0) {
        coral_duration_end = start;
        coral_duration_end.tv_sec += coral_config.duration;
	/* Add a little extra so hopefully select() won't expire before
	 * cell timestamps expire, unless traffic is very slow. */
	coral_duration_end.tv_sec += 1;
    } else {
        coral_duration_end.tv_sec = coral_duration_end.tv_usec = -1;
    }
    coral_all_running = 1;
    coral_int_flag = 0;
    c_blk_iface = NULL;
    if (coral_config.flags & CORAL_OPT_SORT_TIME ||
	coral_config.interval.tv_sec || coral_config.interval.tv_usec ||
	coral_config.duration)
    {
	normalize_if_needed(NULL, NULL);
    }

    return 0;
}

#ifdef HAVE_CORAL_DEVICES
/* Stop a coral device */
int coral_coraldev_stop(coral_source_t *src)
{
    if (ioctl(src->fd, CORAL_STOP) < 0) {
	coral_diag(0, ("coral_stop: %s\n", strerror(errno)));
	return -1;
    }
    return 0;
}
#endif

/* Tell source to stop reading from link and filling buffer, but does not mark
 * EOF, since there may still be buffered data for us to read.
 * Returns 0 for success, -1 for error. */
int coral_stop(coral_source_t *src)
{
    validate_src(src, "coral_stop", -1);
    coral_diag(4, ("coral_stop %s\n", src->name));
    if (!src->started)
	return 0;
    src->started = 0;
    return src->type.stop ? src->type.stop(src) : 0;
}

int coral_stop_all(void)
{
    int sd;
    int result = 0;

    for (sd = 0; sd < CORAL_MAXOPEN; sd++) {
	if (csource[sd] && coral_stop(csource[sd]) < 0)
	    result = -1;
    }
    coral_all_running = 0;
    return result;
}

void coral_fprint_cell(FILE *file, int indent, coral_iface_t *iface,
    const coral_atm_cell_t *cell)
{
    union atm_hdr header;
    struct timespec ts;

    coral_clock_timespec_inline_nf(iface, coral_cell_time_req(iface, cell),
	&ts);
    fprintf(file, "%*stime:  %ld.%09ld\n", indent, "", ts.tv_sec, ts.tv_nsec);
    
    header.ui = ntohl(coral_cell_header_req(iface, cell)->ui);
    fprintf(file, "%*sgfc:   %d (0x%04x)\n", indent, "", header.h.gfc, header.h.gfc);
    fprintf(file, "%*svp:vc: %d:%d (0x%02x:0x%04x)\n", indent, "",
	get_vpvc_vp(header.h.vpvc), get_vpvc_vc(header.h.vpvc),
	get_vpvc_vp(header.h.vpvc), get_vpvc_vc(header.h.vpvc));
    fprintf(file, "%*spti:   %d %d %d (", indent, "",
	header.h.oam_rm, header.h.congestion, header.h.sdu_type);
    if (header.h.oam_rm) {
	fprintf(file, "oam/rm");
    } else {
	fprintf(file, "user data, ");
	fprintf(file, "%scongestion, ", header.h.congestion ? "" : "no ");
	fprintf(file, "%slast cell", header.h.sdu_type ? "" : "not ");
    }
    fprintf(file, ")\n%*spayload:\n", indent, "");
    coral_fprint_data(file, indent,
	(unsigned char*)coral_cell_payload_req(iface, cell), ATM_PAYLOAD_SIZE);
}

/* defined as a macro for speed, and as a function in case a ptr is needed */
void (coral_print_cell)(int indent, coral_iface_t *iface,
    const coral_atm_cell_t *cell)
{
    coral_print_cell(indent, iface, cell);
}

