// N-bit random-polynomial cyclical redundancy check, where N is 32 or 64.
// The template's class parameter must be uintN_t; it defaults to uint32_t.

#include <stdlib.h>
#include "config.h"
#include "caida_t.h"
#include "bitmap.h" // for bit counting

template<class T = uint32_t> class CRC {
    static const size_t N = sizeof(T) * 8;
    T poly;
    T lookup[256];
    void compute_lookup();

public:
    // construct CRC with random polynomial
    CRC() { reset(); }

    // construct CRC with given polynomial
    CRC(T polynomial) : poly(polynomial) { compute_lookup(); }

    // generate new random polynomial
    void reset() {
	int on;
	do {
	    poly = 0;
	    for (size_t i = 0; i < N/32; i++)
		poly = ((poly << 16) << 16) | random();
	    poly |= 1;
	    on = 0;
            for (size_t i = 0; i < N/8; i++)
		on += Bitmap_helper::bitcount[
		    reinterpret_cast<uint8_t*>(&poly)[i]];
	} while ((on % 2) != 0); // while polynomial is not good
	compute_lookup();
    }

    // apply CRC to len bytes pointed to by p.  The optional r is the result
    // of a previous CRC calculation.
    inline T operator() (const void *p, size_t len, T r) const;

    T getpoly() const { return poly; }
};


// precompute lookup table
template<class T>
void CRC<T>::compute_lookup()
{
    for (int i = 0; i < 256; i++) {
	T r = T(i) << (N-8); // remainder
	for (int j = 0; j < 8; j++) {
	    r = (r & (T(1) << (N-1))) ? ((r << 1) ^ poly) : (r << 1);
	}
	lookup[i] = r;
    }
}

template<class T>
inline T CRC<T>::operator()(const void *p, size_t len, T r = 0) const
{
    const uint8_t *bp = static_cast<uint8_t*>(p);

    for (size_t i = 0; i < len; i++)
	r = (r<<8) ^ (lookup[r>>(N-8)]) ^ bp[i];

    // append zero bytes to data so all real data affects all bits of result.
    for (size_t i = 0; i < N/8; i++)
	r = (r<<8) ^ (lookup[r >> (N-8)]);

    return r;
}

