/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 * fatm_pci_freebsd.c - jdugan's fore atm driver; pci bookkeeping
 *
 * $Id: fatm_pci_freebsd.c,v 1.38 2007/06/06 18:17:42 kkeys Exp $
 *
 * Revision 1.1  1998/06/27 01:58:25  tesch
 * initial checkin for CORAL stuff.  fatm* are from jdugan's fore driver.
 *
 */

#include <sys/param.h>
#include <sys/systm.h>
#include <sys/kernel.h>
#include <sys/conf.h>
#include <sys/syslog.h>
#include <sys/select.h>

#include <vm/vm.h>
#include <vm/pmap.h>
#include <vm/vm_extern.h>

#include <pci/pcivar.h>
#include <pci/coral_ioctl.h>
#include <pci/fatm_board.h>
#include <pci/coral_common.h>

#define BASE_OFFSET         0x00000400
#define HOST_CONTROL_OFFSET 0x00100000
#define COMMON_ORIGIN       0x00004d40
#define INIT_START          (COMMON_ORIGIN+0x40)

#ifndef MODULE
/*#define MODSTUB*/			/* if you're doing a loadable module */
#endif

struct fatm fatms[NFATM];	/* max number of fore cards in machine */

static void fatm_pci_attach(pcici_t config_id, int unit)
{
    fatm f;
    unsigned int retval;
    vm_offset_t pa_csrs;
    int i;
    struct block *block;
    
    if (unit >= NFATM || unit < 0) {
	printf("haven't compiled in enough FATM devices. not attaching\n");
	return;
    }

    f = &fatms[unit];
    
    /* Initialize the buffer. */
    block_pool_initialize(&f->block_pool);
    
    f->config_id = config_id;
    f->dvp = &MODUNIQ(fatmdevice);
    f->fatmi = unit;

    retval = pci_map_mem(config_id, 0x10, (vm_offset_t *) & f->base, &pa_csrs);
    if (!retval) {
	printf("fatm pci memory map failed\n");
	return;
    }
    
    /* XXX: Scary magic numbers. */
    /* this is kinda weird */
    f->board_control = f->base + HOST_CONTROL_OFFSET;
    f->interrupt_control = f->base + HOST_CONTROL_OFFSET + 4;
    f->psr = f->base + HOST_CONTROL_OFFSET + 8;

    f->host_to_i960 = f->base + BASE_OFFSET;
    f->i960_to_host = f->base + BASE_OFFSET + 4;
    f->boot_status = f->base + BASE_OFFSET + 8;

    f->init_op = f->base + INIT_START;
    f->init_status = f->base + INIT_START + 4;
    f->init_index_bits_avail = f->base + INIT_START + 8;
    f->init_bits_from_vci = f->base + INIT_START + 12;
    f->init_high_vpi_vci = f->base + INIT_START + 16;
    f->init_host_block_size = f->base + INIT_START + 20;
    f->init_cqueue_len = f->base + INIT_START + 24;
    f->enable_timer_interrupt = f->base + INIT_START + 28;
    f->enable_line_loopback = f->base + INIT_START + 32;

    f->command_queue = f->base + COMMON_ORIGIN;
    f->current_host_limit = f->base + COMMON_ORIGIN + 4;
    f->current_host_block = f->base + COMMON_ORIGIN + 8;
    f->next_host_block = f->base + COMMON_ORIGIN + 12;
    f->imask = f->base + COMMON_ORIGIN + 16;
    f->istat = f->base + COMMON_ORIGIN + 20;
/*    f->heap_base = f->base + COMMON_ORIGIN+24; */
    f->hlogger = f->base + COMMON_ORIGIN + 32;
    f->heartbeat = f->base + COMMON_ORIGIN + 36;

    f->fifo_depth_counts = f->base + COMMON_ORIGIN + 108;

    f->current_tx_block = f->base + COMMON_ORIGIN + 172;
    f->current_tx_length = f->base + COMMON_ORIGIN + 176;
    f->current_tx_sent = f->base + COMMON_ORIGIN + 180;
    f->next_tx_block = f->base + COMMON_ORIGIN + 184;
    f->next_tx_length = f->base + COMMON_ORIGIN + 188;
    
    if (!pci_map_int(config_id, (void *)MODUNIQ(fatm_interrupt), (void *) f, &tty_imask)) {
	printf("fatm %d: couldn't map interrupt\n", unit);
	return;
    }

    /* Allocate space for the blocks and the headers. */
    if (!f->buffer) {
	f->buffer = (void *) vm_page_alloc_contig(FATM_CELLBUF_SIZE,
						  0,
						  0xffffffff,
						  PAGE_SIZE);
	
	/* Record each raw block as an available free block. */
	for(i=0; i < FATM_NUM_BLKS; i++) {
	
	    /* Create the new block to hold the raw block. */
	    block=block_create(BLK_IDX_TO_ADR(i, f->buffer, FATM_BLK_SIZE, FATM_NUM_BLKS), BLK_IDX_TO_INFO(i, f->buffer, FATM_BLK_SIZE, FATM_NUM_BLKS), i);
	
	    /* Register this block as being free. */
	    block_pool_free_set(&f->block_pool, block);
	}
    
#ifdef CORAL_DEBUG
	printf("fatm%d: allocated %ld bytes at 0x%x\n", unit,
		FATM_CELLBUF_SIZE, (int)f->buffer);
#endif
    } else {
#ifdef CORAL_DEBUG
	printf("fatm%d: already have f->buffer at %p\n", unit, f->buffer);
#endif
    }
    

#ifdef CORAL_DEBUG
    printf("attaching fatm %p\n", f);
#endif
    MODUNIQ(fatm_attach)(f, unit);
}

static void fatm_pci_shutdown(void *q)
{
}

static pci_probe_return_t fatm_pci_probe(pcici_t config_id, pcidi_t device_id)
{
    if ((device_id & 0xffff) != FORE_VENDOR)
	return 0;
    if (((device_id >> 16) & 0xffff) == PCA200PC_BOARD)
#ifndef MODSTUB
	return "Fore PCA200 ATM interface";
#else
	return 0;
#endif
    return 0;
}

static u_long fatm_pci_count;

struct pci_device MODUNIQ(fatmdevice) =
{
    "fatm",
    fatm_pci_probe,
    fatm_pci_attach,
    &fatm_pci_count,
    (void *) fatm_pci_shutdown,
};

#if __FreeBSD_version < 400000
DATA_SET(pcidevice_set, MODUNIQ(fatmdevice));
#else
COMPAT_PCI_DRIVER (fatms, MODUNIQ(fatmdevice));
#endif
