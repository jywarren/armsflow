#!/usr/local/bin/perl
## $Id: store_monitor_data.pl,v 1.22 2007/06/07 18:27:49 rkoga Exp $ $Name: release-3-8-1 $
## 
## Copyright 2004, 2005, 2007
## The Regents of the University of California 
## All Rights Reserved 
## 
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
## 
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
## 
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
## 
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
## 
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program.  Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
## 
## Report bugs and suggestions to coral-bugs@caida.org.
## 

use warnings;
use strict;

my $rrd_version = 3;
my $coral_dir;
BEGIN { $coral_dir = "/usr/local/Coral"; } # This will be edited during build.
my $rrd_dir;
BEGIN { $rrd_dir = "/usr/local/RRDtool"; } # This will be edited during build.
use lib "$coral_dir/lib"; #coral global libdir#
use lib "../../../lib"; #coral local libdir#
use lib "$rrd_dir/lib/perl";
use CAIDA::Traffic2::FileReader;
use CAIDA::Traffic2::ReportSupport;
use CAIDA::ASFinder;
use CAIDA::NetGeoClient;
use CAIDA::AppPorts;
use CAIDA::Countries;
use RRDs;

if (@ARGV != 2) {
    print STDERR "Usage: $0 <config_file> <monitor_file>\n";
    exit 1;
}

my %mon_config;
my %shared_config;
my %subif_config;
my $monitor_pat = '\s*monitor\s*{';
my $shared_pat = '\s*shared\s*{';
my $main_config = $ARGV[0];
my $input_config = $ARGV[1];
my ($paths, $default, $rrd_creation, $debug);
my %subif_map;

my ($END_SOON, $LOAD_CONFIG) = (0, 1); # Set to do initial config load.
$SIG{HUP} =  sub { $LOAD_CONFIG = 1 };
$SIG{USR1} = sub { $END_SOON = 1    };

my $reader = new CAIDA::Traffic2::FileReader(\*STDIN);

my $separate_icmp_codes = 0;
sub name_unknown_app {
    my ($proto, $ports_ok, $src_port, $dst_port) = @_;
    my $str;
    $str = "UNKNOWN_";
    if ($proto == 6) {
	$str = "NOPORTS_" unless $ports_ok;
	$str .= "TCP";
    } elsif ($proto == 17) {
	$str = "NOPORTS_" unless $ports_ok;
	$str .= "UDP";
    } elsif ($proto == 1) {
	$str .= "ICMP";
	$str .= "_($src_port,$dst_port)" if $ports_ok and $separate_icmp_codes;
    } else {
	$str .= "PROTO_$proto";
    }
    return $str;
}

sub configure_all {
    open CONFIG, $main_config or die "Cannot open config file $main_config";
    parse_config(\*CONFIG, {$monitor_pat => \%mon_config,
			    $shared_pat => \%shared_config});

    open CONFIG, $input_config or die "Cannot open monitor file $input_config";
    parse_config(\*CONFIG, {$shared_pat => \%subif_config});
    close CONFIG;

    $paths = $shared_config{'paths'};
    $default = $shared_config{'default'};
    $rrd_creation = $shared_config{'rrd_creation'};
    $debug = get_config_var($shared_config{'general'}, 'debug');

    my $country_abbr = get_config_var($shared_config{'general'},'country_abbr');
    $separate_icmp_codes = get_config_var($shared_config{'general'},
							'separate_icmp_codes');
    my $netacq_path = get_config_var($paths, 'netacq');
    my $routefile = get_config_var($paths, 'routes');
    my $as_finder = new CAIDA::ASFinder;
    if (defined $routefile) {
	$as_finder->load_file_text($routefile) or
					    die "Error loading $routefile\n";
    }

    my $netgeo = new CAIDA::NetGeoClient;

    my $app_ports = new CAIDA::AppPorts;
    my $ports_file = get_config_var($paths, 'ports');
    if (-e "../../../etc/Application_ports_Master.txt") {
	$ports_file = "../../../etc/Application_ports_Master.txt";
    } else {
	$ports_file = "$coral_dir/etc/Application_ports_Master.txt";
    }
    my $other_ports_file = get_config_var($paths, 'ports');
    $ports_file = $other_ports_file if defined $other_ports_file;
    $app_ports->load_rules($ports_file) or die "Can't load $ports_file";

    my $countries = new CAIDA::Countries;

    my %tables;
    foreach my $name (get_config_keys(\%mon_config)) {
	my $stanza = $mon_config{$name};
	my @mon_tables = get_best_list($default, $stanza, 'tables');
	foreach my $table (@mon_tables) {
	    $tables{$table}++;
	}
    }
    if (keys %tables == 0) {
	print STDERR "No monitors defined in config file, exiting.\n";
	exit;
    }
    $reader->set_desired_table_types(keys %tables);
    $reader->set_conversion_options({'as_finder' => $as_finder,
				     'app_ports' => $app_ports,
				     'netacq' => $netacq_path,
				     'netgeo' => $netgeo,
				     'countries' => $countries,
				     'country_abbr' => $country_abbr,
				     'name_func' => \&name_unknown_app});

    %subif_map = get_config_hash($subif_config{'subif_map'});
}

my $endtime = 0;
while (not $END_SOON) {
    if ($LOAD_CONFIG) {
	configure_all();
	print STDERR "Loading config files $main_config and $input_config\n"
								    if $debug;
	$LOAD_CONFIG = 0;
    }
    my $interval = $reader->get_next_interval();
    last unless defined $interval;
    if ($interval->get_metadata('end') > $endtime) {
	$endtime = int($interval->get_metadata('end'));
    }
    print STDERR scalar(localtime), ": starting interval ",
		$interval->get_metadata('start'), "\n" if $debug;
    foreach my $id_info ($interval->get_id_infos()) {
	my $monitor = $subif_map{$id_info->get_metadata('id')};
	unless (defined $monitor) {
	    print STDERR "No monitor found for id: ",
		    $id_info->get_metadata('id'), ", skipping.\n" if $debug;
	    next;
	}
	my $stanza = $mon_config{$monitor};
	unless (defined $stanza) {
	    print STDERR "Unknown monitor: $monitor, skipping.\n" if $debug;
	    next;
	}
	my @intervals = get_best_list($default, $stanza, 'intervals');
	my @counters = get_best_list($default, $stanza, 'counters');
	my $rrd_store_dir = get_best_var($default, $stanza, 'rrd_dir');
	my $top_n = get_best_var($default, $stanza, 'top_n');
	die "Need RRD directory for $monitor" unless defined $rrd_store_dir;
	my $updated = 0; # For both .lastdata and total.rrd writing
	foreach my $type ($id_info->get_table_types()) {
	    my $table = $interval->get_table($id_info, $type);
	    if (defined $table) {
		# XXX Change this to only find/calculate tables requested
		# for this monitor?
		if ($type =~ /Table/) {
		    my $category = lc $type;
		    $category =~ s/ \(.*\)$//;
		    $category =~ s/ table//;
		    $category =~ s/ /_/g;
		    rrd_store($rrd_store_dir, $table, $type, $monitor,
				$category, $interval, \@counters, $updated);
		    $updated = 1;
		    if ($top_n) {
			sort_rrd_top_n($rrd_store_dir, $table, $monitor,
				    $category, $endtime, $top_n, \@intervals,
				    \@counters);
		    }
		}
	    } else {
		print STDERR "Couldn't find $type\n";
	    }
	}
	if ($updated) {
	    my $timefile = "$rrd_store_dir/$monitor/.lastdata";
	    open LASTDATA, ">$timefile" or
			    die "Failed to write endtime to $timefile: $!";
	    print LASTDATA "$endtime\n";
	    close LASTDATA;
	}
    }
    print STDERR scalar(localtime), ": finished interval\n" if $debug;
}

sub rrd_store {
    my ($rrd_store_dir, $table, $type, $monitor, $category, $interval_obj,
	$counters, $total_stored) = @_;

    unless ($total_stored) { # Only store interval total once.
	unless (-f "$rrd_store_dir/$monitor/total.rrd") {
	    rrd_create($rrd_store_dir, $monitor, '', 'total',
			int($interval_obj->get_metadata('start')), $counters);
	}
	rrd_update($rrd_store_dir, $monitor, '', 'total',
		      $interval_obj->get_metadata('end'),
		      $interval_obj->get_metadata('duration'),
		      $table->total());
    }
    foreach my $key (keys %{$table->data()}){
	my ($field1, $field2) = $table->get_key_fields($key);
	my $rrd_name = $field1;
	unless (-f "$rrd_store_dir/$monitor/$category/$rrd_name.rrd") {
	    rrd_create($rrd_store_dir, $monitor, $category, $rrd_name,
			int($interval_obj->get_metadata('start')), $counters);
	}
	rrd_update($rrd_store_dir, $monitor, $category, $rrd_name,
		      $interval_obj->get_metadata('end'),
		      $interval_obj->get_metadata('duration'),
		      $table->data()->{$key});
    }
}

my %checked_ver;

sub rrd_update {
    my ($rrd_store_dir, $monitor, $category, $rrd_name, $time, $duration,
	$count_ref) = @_ ;
    unless ($checked_ver{$monitor}) {
	my $opened = open VERSION, "$rrd_store_dir/$monitor/version";
	my $check_version;
	unless ($opened and defined ($check_version = <VERSION>) and
		$check_version == $rrd_version)
	{
	    print STDERR
		"Trying to use an incorrect version of RRD directory ",
				"$rrd_store_dir/$monitor.\n",
		"Either use a different directory or ", 
				"convert this one to the correct format.\n",
		"Information regarding this can be found in the ",
				"report generator documentation\n";
	    exit;
	}
	$checked_ver{$monitor} = 1;
    }
    RRDs::update("$rrd_store_dir/$monitor/$category/$rrd_name.rrd",
		 "$time:".($count_ref->bytes()*8/$duration).":".
		 ($count_ref->pkts()/$duration).":".
		 ($count_ref->flows()/$duration));
    my $error = RRDs::error();
    if ($error) {
	die "While updating $rrd_store_dir/$monitor/$category/$rrd_name.rrd: $error";
    }
}

sub rrd_create {
    my ($rrd_store_dir, $monitor, $category, $rrd_name, $start_time,
	$counters) = @_;

    unless (-d "$rrd_store_dir") {
	mkdir "$rrd_store_dir" or die "Cannot create $rrd_store_dir: $!\n";
    }
    unless (-d "$rrd_store_dir/$monitor") {
	mkdir "$rrd_store_dir/$monitor" or die
			"Cannot create $rrd_store_dir/$monitor: $!\n";
	open VERSION, ">$rrd_store_dir/$monitor/version" or die
			"Cannot create $rrd_store_dir/$monitor/version: $!\n";
	print VERSION "$rrd_version\n";
	close VERSION;
    }
    unless (-d "$rrd_store_dir/$monitor/$category") {
	mkdir "$rrd_store_dir/$monitor/$category" or die
			"Cannot create $rrd_store_dir/$monitor/$category: $!\n";
    }

    my $step = get_config_var($rrd_creation, 'step');
    my $heartbeat = get_config_var($rrd_creation, 'heartbeat');
    my $x_file_factor = get_config_var($rrd_creation, 'xff');
    my @rra_steps = get_config_list($rrd_creation, 'rra_steps');
    my @rra_rows = get_config_list($rrd_creation, 'rra_rows');
    my @data_sources;
    my @rras;

    foreach my $source (@$counters) {
	push @data_sources, "DS:$source:GAUGE:$heartbeat:0:U";
    }
    foreach my $cons_func ("AVERAGE", "MIN", "MAX") {
	for (my $idx = 0; $idx < @rra_steps; $idx++) {
	    my $steps = $rra_steps[$idx];
	    my $rows = $rra_rows[$idx];
	    push @rras, "RRA:$cons_func:$x_file_factor:$steps:$rows";
	}
    }
    my @creation_commands = ("$rrd_store_dir/$monitor/$category/$rrd_name.rrd",
	      "--start", $start_time, "--step", $step, @data_sources, @rras);
    RRDs::create (@creation_commands);
    my $error = RRDs::error();
    if ($error) {
	die "While creating $rrd_store_dir/$monitor/$category/$rrd_name.rrd: $error";
    }
}

sub extract_rrd_value {
    my ($file, $unit, $def_func, $agg_func, $timeframe, $endtime) = @_;

    die "$file not found" unless -f $file;
    my $def = "DEF:orig_val=$file:$unit:$def_func";
    my $calc_def;
    # To get average, better to treat undef as 0, but not for max and
    # especially not for min.
    if ($def_func eq 'AVERAGE') {
	$calc_def = "CDEF:new_val=orig_val,UN,0,orig_val,IF";
    } else {
	$calc_def = "CDEF:new_val=orig_val";
    }
    my ($results) = RRDs::graph("", "--start=end-$timeframe", "--end=$endtime",
			$def, $calc_def, "PRINT:new_val:$agg_func:%lf");
    my $error = RRDs::error();
    if ($error) {
	die "While getting $def_func $unit data from $file: $error";
    }
    my $value = $results->[0];
    $value = 0 if $value eq 'NaN';
    return $value;
}

sub sort_rrd_top_n {
    my ($rrd_store_dir, $table, $monitor, $category, $endtime, $top_n,
	$intervals, $counters) = @_;

    my $directory = "$rrd_store_dir/$monitor/$category";

    my @files = glob "$directory/*.rrd";
    return if @files == 0;

    my $func = "AVERAGE";
    foreach my $counter (@$counters) {
	foreach my $interval (@$intervals) {
	    my %rrd_data;
	    my $timeframe = $interval*3600;
	    my $sortfile = "$directory/top_n_for_${interval}_by_$counter.txt";
	    if (-s $sortfile and open SORTED, $sortfile) {
		my %top_rrds;
		undef @files;
		# Reads in previously defined important RRDs
		while (<SORTED>) {
		    my ($rrd) = split /:/;
		    $top_rrds{$rrd}++;
		}
		close SORTED;
		my $selector;
		if ($counter eq 'bits') {
		    $selector = "sort_by_bytes";
		} elsif ($counter eq 'packets') {
		    $selector = "sort_by_pkts";
		} elsif ($counter eq 'tuples') {
		    $selector = "sort_by_flows";
		}
		my @keys = $table->$selector($top_n);
		# Adds in recent important RRDs
		foreach my $key (@keys) {
		    # XXX Only allows for single-keyed RRDs.
		    my ($rrd) = $table->get_key_fields($key);
		    $top_rrds{$rrd}++;
		}
		foreach my $rrd (keys %top_rrds) {
		    push @files, "$directory/$rrd.rrd";
		}
	    }
	    foreach my $file (@files) {
		(my $name = $file) =~ s/$directory\/(.*)\.rrd/$1/;
		$rrd_data{$name} = extract_rrd_value($file, $counter, $func,
						$func, $timeframe, $endtime);
	    }
	    my @good_keys = sort {$rrd_data{$b} <=> $rrd_data{$a}}
								keys %rrd_data;
	    if (@good_keys > $top_n) {
		@good_keys = @good_keys[0 .. $top_n-1];
	    }
	    if ($rrd_data{$good_keys[0]} == 0) { # No top N at all!
		unlink $sortfile if -f $sortfile;
		next;
	    }
	    # Use temporary file to avoid having empty file sitting around.
	    open TOPN, ">${sortfile}_temp";
	    foreach my $key (@good_keys) {
		print TOPN "$key:$rrd_data{$key}\n";
	    }
	    close TOPN;
	    rename "${sortfile}_temp", $sortfile;
	}
    }
}
