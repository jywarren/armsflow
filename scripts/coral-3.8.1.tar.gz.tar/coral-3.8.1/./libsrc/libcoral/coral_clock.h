/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

#ifndef CORAL_CLOCK_H
#define CORAL_CLOCK_H
/*
 * coral_clock.h - Coral timestamp interpreter interface
 *
 * $Id: coral_clock.h,v 1.46 2007/06/06 18:17:53 kkeys Exp $
 */

typedef union {
    uint32_t i[2];
    uint8_t c[8];
} coral_timestamp_t;

double coral_read_clock_double(coral_iface_t *iface,
    const coral_timestamp_t *t);
void coral_read_clock_sec_nsec(coral_iface_t *iface,
    const coral_timestamp_t *t, time_t *sec, long *nsec);
void coral_read_clock_timespec(coral_iface_t *iface,
    const coral_timestamp_t *t, struct timespec *tspec);
void coral_read_clock_order(const coral_iface_t *iface,
    const coral_timestamp_t *src, coral_timestamp_t *dst);

void coral_timestamp_to_dag_clock(coral_iface_t *iface,
    const coral_timestamp_t *src, coral_timestamp_t *dst);


#define CORAL_TIMESTAMP_TO_DOUBLE(iface, ts) coral_read_clock_double(iface, ts)

#define CORAL_TIMESTAMP_TO_SEC_NSEC(iface, ts, sec, nsec) \
    coral_read_clock_sec_nsec(iface, ts, sec, nsec)

#define CORAL_TIMESTAMP_TO_TIMESPEC(iface, ts, tspec) \
    coral_read_clock_timespec((iface), (ts), (tspec))

#define CORAL_TIMESTAMP_TO_TIMEVAL(iface, ts, tval) \
    do { \
	struct timespec tspec; \
	coral_read_clock_timespec((iface), (ts), &tspec); \
	(tval)->tv_sec = tspec.tv_sec; \
	(tval)->tv_usec = tspec.tv_nsec / 1000; \
    } while (0)



/* rest of this file is some nifty time macros */
#define timespectodouble(vp) ((double)(vp)->tv_sec + ((double)(vp)->tv_nsec) \
			      * 1e-9)
#define timevaltodouble(vp) ((double)(vp)->tv_sec + ((double)(vp)->tv_usec) \
			     * 1e-6)


/* stolen from sys/time.h in freebsd3.0 */
#ifndef timespeccmp
#define	timespeccmp(tvp, uvp, cmp)	/* t cmp u */			\
	(((tvp)->tv_sec == (uvp)->tv_sec) ?				\
	    ((tvp)->tv_nsec cmp (uvp)->tv_nsec) :			\
	    ((tvp)->tv_sec cmp (uvp)->tv_sec))
#endif

#ifndef timespecadd
#define timespecadd(vvp, uvp)	/* v += u */				\
        do {                                                            \
                (vvp)->tv_sec += (uvp)->tv_sec;                         \
                (vvp)->tv_nsec += (uvp)->tv_nsec;                       \
                if ((vvp)->tv_nsec >= 1000000000) {                     \
                        (vvp)->tv_sec++;                                \
                        (vvp)->tv_nsec -= 1000000000;                   \
                }                                                       \
        } while (0)
#endif

#ifndef timespecsub
#define timespecsub(vvp, uvp)	/* v -= u */				\
	do {								\
		(vvp)->tv_sec -= (uvp)->tv_sec;				\
		(vvp)->tv_nsec -= (uvp)->tv_nsec;			\
		if ((vvp)->tv_nsec < 0) {				\
			(vvp)->tv_sec--;				\
			(vvp)->tv_nsec += 1000000000;			\
		}							\
	} while (0)

#endif

#undef timercmp	/* timercmp is broken on Solaris. Always use this definition. */
#define	timercmp(tvp, uvp, cmp)						\
	(((tvp)->tv_sec == (uvp)->tv_sec) ?				\
	    ((tvp)->tv_usec cmp (uvp)->tv_usec) :			\
	    ((tvp)->tv_sec cmp (uvp)->tv_sec))

#ifndef timeradd
#define timeradd(tvp, uvp, vvp)	/* v = t + u */				\
	do {								\
		(vvp)->tv_sec = (tvp)->tv_sec + (uvp)->tv_sec;		\
		(vvp)->tv_usec = (tvp)->tv_usec + (uvp)->tv_usec;	\
		if ((vvp)->tv_usec >= 1000000) {			\
			(vvp)->tv_sec++;				\
			(vvp)->tv_usec -= 1000000;			\
		}							\
	} while (0)
#endif

#ifndef timersub
#define timersub(tvp, uvp, vvp)	/* v = t - u */				\
	do {								\
		(vvp)->tv_sec = (tvp)->tv_sec - (uvp)->tv_sec;		\
		(vvp)->tv_usec = (tvp)->tv_usec - (uvp)->tv_usec;	\
		if ((vvp)->tv_usec < 0) {				\
			(vvp)->tv_sec--;				\
			(vvp)->tv_usec += 1000000;			\
		}							\
	} while (0)
#endif

#endif      /* _CORAL_CLOCK_H_ */
