/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 * $Id: crl_byteorder.h,v 1.16 2007/06/06 18:17:56 kkeys Exp $
 * Note:  this is used by other parts of CoralReef, not just libcoral.
 */

#ifndef CRL_BYTEORDER_H
#define CRL_BYTEORDER_H


#define crl_swaps(x) \
        (((x)&0x00FF)<<8 | ((x)&0xFF00)>>8)

#define crl_swapl(x) \
        (((x)&0x000000FFul)<<24 | ((x)&0x0000FF00ul)<<8 | \
	 ((x)&0x00FF0000ul)>>8  | ((x)&0xFF000000ul)>>24)

/* Using casts instead of ULL suffixes prevents warnings in gcc. */
#define crl_swap64(x) \
        (((x) & (((uint64_t)0xFF)<< 0)) <<56 | \
         ((x) & (((uint64_t)0xFF)<< 8)) <<40 | \
         ((x) & (((uint64_t)0xFF)<<16)) <<24 | \
         ((x) & (((uint64_t)0xFF)<<24)) <<8  | \
         ((x) & (((uint64_t)0xFF)<<32)) >>8  | \
         ((x) & (((uint64_t)0xFF)<<40)) >>24 | \
         ((x) & (((uint64_t)0xFF)<<48)) >>40 | \
         ((x) & (((uint64_t)0xFF)<<56)) >>56 )

#ifndef WORDS_BIGENDIAN
# ifndef BYTE_ORDER
#  error "unknown byte order"
# elif (BYTE_ORDER == BIG_ENDIAN)
#  define WORDS_BIGENDIAN 1
# else
#  define WORDS_BIGENDIAN 0
# endif
#endif
#if WORDS_BIGENDIAN

# define crl_htobes(x)	(x)
# define crl_htobel(x)	(x)
# define crl_htobe64(x)	(x)

# define crl_betohs(x)	(x)
# define crl_betohl(x)	(x)
# define crl_betoh64(x)	(x)

# define crl_htoles(x)	crl_swaps(x)
# define crl_htolel(x)	crl_swapl(x)
# define crl_htole64(x)	crl_swap64(x)

# define crl_letohs(x)	crl_swaps(x)
# define crl_letohl(x)	crl_swapl(x)
# define crl_letoh64(x)	crl_swap64(x)

#else

# define crl_htobes(x)	crl_swaps(x)
# define crl_htobel(x)	crl_swapl(x)
# define crl_htobe64(x)	crl_swap64(x)

# define crl_betohs(x)	crl_swaps(x)
# define crl_betohl(x)	crl_swapl(x)
# define crl_betoh64(x)	crl_swap64(x)

# define crl_htoles(x)	(x)
# define crl_htolel(x)	(x)
# define crl_htole64(x)	(x)

# define crl_letohs(x)	(x)
# define crl_letohl(x)	(x)
# define crl_letoh64(x)	(x)

#endif

# define crl_htons(x)   crl_htobes(x)
# define crl_htonl(x)   crl_htobel(x)
# define crl_hton64(x)  crl_htobe64(x)

# define crl_ntohs(x)   crl_betohs(x)
# define crl_ntohl(x)   crl_betohl(x)
# define crl_ntoh64(x)  crl_betoh64(x)

/* convert the network order 32 bit integer pointed to by p to host order.
 * p does not have to be aligned. */
#define crl_nptohl(p) \
   ((((uint8_t*)(p))[0] << 24) | \
    (((uint8_t*)(p))[1] << 16) | \
    (((uint8_t*)(p))[2] << 8) | \
    ((uint8_t*)(p))[3])

/* convert the network order 16 bit integer pointed to by p to host order.
 * p does not have to be aligned. */
#define crl_nptohs(p) \
   ((((uint8_t*)(p))[0] << 8) | ((uint8_t*)(p))[1])

/* copy the host order 16 bit integer in x into the memory pointed to by p
 * in network order.  p does not have to be aligned. */
#define crl_htonps(p, x) \
    do { \
	((uint8_t*)(p))[0] = (x & 0xFF00) >> 8; \
	((uint8_t*)(p))[1] = (x & 0x00FF) >> 0; \
    } while (0)

/* copy the host order 32 bit integer in x into the memory pointed to by p
 * in network order.  p does not have to be aligned. */
#define crl_htonpl(p, x) \
    do { \
	((uint8_t*)(p))[0] = (x & 0xFF000000) >> 24; \
	((uint8_t*)(p))[1] = (x & 0x00FF0000) >> 16; \
	((uint8_t*)(p))[2] = (x & 0x0000FF00) >> 8; \
	((uint8_t*)(p))[3] = (x & 0x000000FF) >> 0; \
    } while (0)

#endif /* CRL_BYTEORDER_H */
