/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 * FATM loadable driver stubs.
 */

#include <sys/param.h>
#include <sys/systm.h>
#include <sys/exec.h>
#include <sys/sysent.h>
#include <sys/lkm.h>

#include <i386/isa/isa_device.h>
#include <pci/pcivar.h>
#if __FreeBSD_version < 300000
#include <pci/pcibus.h>
#endif
#include "fatm_board.h"

MOD_DEV(fatm, LM_DT_CHAR, CDEV_MAJOR, &MODUNIQ(fatm_cdevsw));

/*
 * Function called when loading the driver.
 */
static int fatm_load (struct lkm_table *lkmtp, int cmd)
{
    int i;
    int err;

    for (i = 0; i < NFATM; i++) {
	/* make sure no existing cards are 'open' */
	if (fatms[i].state & ST_OPEN) {
	    uprintf("unable to load module: fatm device %d open\n", i);
	    return EBUSY;
	}
#ifdef DEBUGno
	uprintf("fatms[%d]->state  0x%x\n", i, fatms[i].state);
	uprintf("fatms[%d]->buffer %x\n", i, fatms[i].buffer);
#endif
    }

#if 0
    if ((err = pci_register_lkm(&MODUNIQ(fatmdevice), 0)) < 0) {
	uprintf("pci_register_lkm failed %d\n", err);
	return E2BIG;
    }
#endif
    /* make sure they cant be opened */



    /* register our pci device driver, this will
     * cause the kernel to call our probe function
     * for all unattached devices if we recognise one
     * it will call our attach fxn on it.
     * (afaik, this only works on 2.2.7 ) */
    if (pci_register_lkm(&MODUNIQ(fatmdevice), 0))
	return ENXIO;

    return 0;
}

/*
 * Function called when unloading the driver.
 */
static int fatm_unload (struct lkm_table *lkmtp, int cmd)
{
    int i;

    if (pci_unregister_lkm(&MODUNIQ(fatmdevice))) {
	uprintf("fatm_unload: pci_unregister_lkm failed\n", i);
	return ENXIO;
    }

    for (i = 0; i < NFATM; i++) {

// XXX: tag no longer exists, see pcivar.h.  What is the equiv?
//	/* have we attached to this fatm? */
//	if (fatms[i].config_id.tag == 0) {
//	    uprintf("fatm %d device not attached.\n", i);
//	    continue;
//	}

	/* make sure it's not open */
	if (fatms[i].state & ST_OPEN) {
	    uprintf("unable to load module: fatm device %d open\n", i);
	    return EBUSY;
	}

	/* unregister the interrupt handlers */
	pci_unmap_int(fatms[i].config_id);
    }


    uprintf("fatm driver unloaded\n");
    return 0;
}

/*
 * Dispatcher function for the module (load/unload/stat).
 */
int fatm_mod (struct lkm_table *lkmtp, int cmd, int ver)
{
	MOD_DISPATCH (fatm, lkmtp, cmd, ver,
		fatm_load, fatm_unload, lkm_nullcmd);
}
