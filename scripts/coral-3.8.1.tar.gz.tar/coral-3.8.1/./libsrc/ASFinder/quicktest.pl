#!/usr/local/bin/perl -w
# We hope that the output from each test is identical to the rest.


use strict;
use lib "../../lib";
use CAIDA::ASFinder;
use Socket;

if (@ARGV != 1) {
    print STDERR "Usage: $0 route_file\n";
    exit 1;
}

my $dotted_ip = '192.172.226.30';
my $finder;
my ($as, $net, $mask);
my $as_test;
my $raw_ip;

$finder = new CAIDA::ASFinder;
$finder->load_file_text($ARGV[0]) or die "Cannot load routing file: $ARGV[0]";
($as, $net, $mask) = $finder->get_as($dotted_ip);
$as_test = $finder->get_as($dotted_ip);
if ($as ne $as_test) { die "Scalar and list calls to get_as causing mismatch.";}
if (defined $as) {
    print "Found closest match at AS: $as, network $net/$mask\n";
} else {
    print "Could not find route to IP: $dotted_ip\n";
}

$raw_ip = inet_aton($dotted_ip);
($as, $net, $mask) = $finder->get_as_raw($raw_ip);
$as_test = $finder->get_as_raw($raw_ip);
if ($as ne $as_test) { die "Scalar and list calls to get_as causing mismatch.";}
if (defined $as) {
    print "Found closest match at AS: $as, network $net/$mask\n";
} else {
    print "Could not find route to IP: $dotted_ip\n";
}
