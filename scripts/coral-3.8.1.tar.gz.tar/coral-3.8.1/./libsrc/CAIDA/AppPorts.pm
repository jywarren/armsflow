## Copyright 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
## All Rights Reserved 
##
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
##
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
##
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
##
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
##
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program. Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
##
## Contact: coral-info@caida.org
## ---------------------------------------------------------------------
## $Id: AppPorts.pm,v 1.57 2007/06/06 18:17:43 kkeys Exp $ $Name: release-3-8-1 $

package CAIDA::AppPorts;
use Carp;

eval "require Exporter; require DynaLoader; " .
    "\@ISA = qw(Exporter DynaLoader); " .
    "bootstrap CAIDA::AppPorts;";
if ($@) {
    croak $@ .
	"(Perhaps AppPorts.so was not installed " .
	"because a suitable C++ compiler\n" .
	"was not found when CoralReef was built.)\n" .
	"Cannot load AppPorts";
}
@EXPORT = qw( );

sub new { return CAIDA::AppPorts::new_AppPorts(); }

package _p_AppPorts;
@ISA = qw(CAIDA::AppPorts);

*DESTROY = *CAIDA::AppPorts::delete_AppPorts;
*clear = *CAIDA::AppPorts::AppPorts_clear;
*load_rules = *CAIDA::AppPorts::AppPorts_load_rules;
*dump_rules = *CAIDA::AppPorts::AppPorts_dump_rules;
sub get_rule {
    return unless defined wantarray;
    if (wantarray) {
	return CAIDA::AppPorts::AppPorts_get_rule(@_);
    } else {
	return (CAIDA::AppPorts::AppPorts_get_rule(@_))[0];
    }
}
sub match_rule {
    return unless defined wantarray;
    if (@_ == 7) {
	if (wantarray) {
	    return CAIDA::AppPorts::AppPorts_match_rule_tuple(@_);
	} else {
	    return (CAIDA::AppPorts::AppPorts_match_rule_tuple(@_))[0];
	}
    } elsif (@_ == 5) {
	if (wantarray) {
	    return CAIDA::AppPorts::AppPorts_match_rule_protoports(@_);
	} else {
	    return (CAIDA::AppPorts::AppPorts_match_rule_protoports(@_))[0];
	}
    } else {
	warn "Invalid number of arguments to CAIDA::AppPorts::match_rule.";
    }
}

package _p_app_it;

sub ports_ok {
    warn "ports_ok method no longer exists\n";
    return 0;
}
*DESTROY = *CAIDA::AppPorts::app_it_delete;
*desc = *CAIDA::AppPorts::app_it_desc;
*name = *CAIDA::AppPorts::app_it_name;
*group = *CAIDA::AppPorts::app_it_group;
*symmetric = *CAIDA::AppPorts::app_it_symmetric;
*ports_ok = *CAIDA::AppPorts::app_it_ports_ok;
*src_nets = *CAIDA::AppPorts::app_it_src_nets;
*dst_nets = *CAIDA::AppPorts::app_it_dst_nets;
*src_ports = *CAIDA::AppPorts::app_it_src_ports;
*dst_ports = *CAIDA::AppPorts::app_it_dst_ports;
*protocols = *CAIDA::AppPorts::app_it_protocols;
*priority = *CAIDA::AppPorts::app_it_priority;
*contrib = *CAIDA::AppPorts::app_it_contrib;
*date = *CAIDA::AppPorts::app_it_date;
*notes = *CAIDA::AppPorts::app_it_notes;
*reference = *CAIDA::AppPorts::app_it_reference;
*url = *CAIDA::AppPorts::app_it_url;

1;

__END__

# =================
# POD Documentation
# =================

=head1 NAME

AppPorts.pm - Application name lookup from port numbers

=head1 SYNOPSIS

    # Use module
    use CAIDA::AppPorts;

    # Create a new AppPort object.
    my $app_port_obj = new CAIDA::AppPorts;

    # Clear the contents of the rules list
    $app_port_obj->clear();

    # Load in a rule file.
    $app_port_obj->load_rules($rules_file);

    # Match some rule.
    my $match = $app_port_obj->match_rule($src_ip, $dst_ip, $ip_proto,
					    $ports_ok, $sport, $dport);
    my @other = $app_port_obj->match_rule($ip_proto, $ports_ok, $sport, $dport);
    print $match->desc, "\n";
    foreach my $proto ($match->protocols) {
	print $proto, "\n";
    }
    ... etc

    my @rules = $app_port_obj->get_rule("HTTP");
    # Dump rules for debugging purposes.
    $app_port_obj->dump_rules();

=head1 DESCRIPTION

AppPorts is a module that reads in a formatted text file of
application rules, and then uses those rules to convert
application port numbers and protocols to application names.

The module consists of methods to manage the rules and to search the
rules for matching applications to the protocol, and source and
destination ports.  The rule format and module architecture is
extensible so that this module can be used in a wide variety of
settings.

=head1 RULE FILE FORMAT

B<NOTE>:  Prior to CoralReef 3.5.0, the file format was different.  Most
importantly, any strings with spaces required double quotes around them,
and the rule priority was implicit in their ordering.  If you want to use
an older rule file with the current module, you should strip out extra
double quotes, and add some explicit priorities.  With no priorities
set, the chance of conflicting rule matching is increased greatly.

AppPorts expects a file with entries defining the characteristics of an
application.  The required field is:

=over 4

=item name

A unique name to identify the application.  Must be able to be used as a
UNIX filename.

=back

The optional fields are:

=over 4

=item description

The full name of the application.

=item group

A category for organizing applications, possibly in directory structures,
or for aggregating similar applications, etc.  Must be able to be used as
a UNIX filename.

=item srcnet

=item dstnet

IP subnets to match (source and destination, respectively).  Written in the
form x.x.x.x/x; multiple subnets can be separated by commas.  Defaults to
matching all subnets (can also be defined explicitly with 0.0.0.0/0).
If the mask length is omitted, it defaults to /32.

=item sport

=item dport

The source and destination TCP/UDP/ICMP ports, respectively, to match.  In
the case of ICMP, 'sport' means 'type' and 'dport' means 'code'.  Defined
as a list of ports or port ranges, separated by commas.  The special
character I<*> indicates all ports, and a port range is specified with
a hyphen.  For example:

	sport: 123, 200-300, 4567
	dport: *

Either sport or dport (or both) can be set to 'none', which specifies that
the rule I<only> matches when the ports_ok argument is 0.  For other values
of sport and dport, ports_ok must be non-zero.  If sport and dport are
omitted, the rule will ignore ports_ok completely.  

=item sym

0 or 1, indicates whether the source and destination ports and subnets are
symmetric.  Defaults to 0 (false).  Ports and networks are matched
pairwise.

=item protocol

The IP protocol number(s) to match.  Multiple protocols are separated by
commas.  No ranges are currently supported, but I<*> can be used to
indicate all protocols.

=item priority

Used for sorting multiple matching rules.  1 is highest priority;
defaults to 50.  If two or more matching rules with equal priority
exist, their position relative to each other is undefined.

=item contributor

Who added this rule or most recently updated it.

=item date

When the rule was last updated.

=item notes

Extra information.

=item reference

Source of information for the rule.

=item url

URL with the most definitive source for the rule.

=back

An example entry for the World Wide Web would be:

	description:	World Wide Web
	name:		WWW
	group:		WWW
	srcnet:		0.0.0.0/0
	dstnet:		0.0.0.0/0
	sport:		80,8080
	dport:		*
	sym:		1
	protocol:	6
	priority:	50
	contributor:	bigj
	date:		1999-07-08
	notes:
	reference:	IANA Port assignments
	url:		http://www.iana.org/assignments/port-numbers

Note that srcnet and dstnet can (and should) be omitted, since they default
to matching all subnets.  The notes and priority are similarly the same as
the default.

If one wanted to override this rule with a domain specific application,
such a rule might look like: 

	description:	Our non-web app
	name:		APPFOO
	group:		INTERNAL
	srcnet:		10.0.0.0/8
	sport:		8080
	dport:		*
	sym:		1
	protocol:	6
	priority:	10

Due to the way symmetry works, this would match data from the local network
with a source port of 8080, or to the local network with a destination port
of 8080, but I<not> from the local network with a destination port of 8080,
for example.

It is possible to create a rule to match all cases, as a fall-through.
It should have a low priority in order to be useful, however:

	description:	Unknown TCP
	name:		UNKNOWN_TCP
	protocol:	6
	priority:	90

	description:	Unknown
	name:		UNKNOWN
	protocol:	*
	priority:	100

=head1 METHODS

=over 4

=item new ()

Creates a new AppPorts object.

=item clear ()

Removes all entries from the AppPorts object.  Good to do before re-loading
a rules file.

=item load_rules (FILENAME)

Takes a path to a rules file and converts it into rules that can be applied
to application port numbers.

=item match_rule (SRC_IP, DST_IP, PROTOCOL, PORTS_OK, SPORT, DPORT)

=item match_rule (PROTOCOL, PORTS_OK, SPORT, DPORT)

Does the application matching for the flow data.  If the source and
destination IP addresses are omitted, no rules with subnets will match.
If no match occurs, it returns undef, otherwise it returns a list of
references (or the highest priority reference in a scalar context) to
objects with accessor members for each field:

=over 4

=item * desc

=item * name

=item * group

=item * src_nets

=item * dst_nets

=item * no_ports

=item * check_ports

=item * src_ports

=item * dst_ports

=item * symmetric

=item * protocols

=item * priority

=item * contributor

=item * date

=item * notes

=item * reference

=item * url

=back

Note that protocols, src_nets, dst_nets, src_ports and dst_ports are arrays
of strings.  The port ranges and wildcards are in the same form as the
config file.  The no_ports indicates whether the rule specifically matches
ports_ok == 0, and check_ports indicates whether the rule looks at ports_ok
at all.

=item get_rule (NAME)

Returns a list of rules that have the name NAME.  Returns a single rule in
scalar context.

=item dump_rules ()

A debugging method that outputs the rules in the same format as the input
file.  Presently just dumps to standard out.

=back

=head1 API CHANGES

In CoralReef 3.8.0, the ports_ok rule field was removed and made implicit
based on the sport/dport fields.  The ports_ok accessor function was
replaced with no_ports and check_ports.

CAIDA::AppPorts from CoralReef < 3.5.0 had a different API.  The primary
differences are:

=head2 Removed functions

=over 4

=item * match_first_rule

Replaced with C<match_rule>.  Note: The order of the arguments are different.

=item * name_to_desc

Functionality replaced with C<get_rule>, except that the entire rule is
returned and not just the description.

=item * AppReset

Replaced with C<clear>.

=item * load_rules_iana

=item * match_rules_subset

=item * desc_to_name

=item * dump_rules_iana

=item * html_rules_report

=item * output_rule_html

=item * output_rules_html

=item * make_html_pages

=item * make_html_index

Gone.

=back

=head2 Changed return type

C<match_rule> now returns an opaque object, whereas match_first_rule would
return an array reference.  To access the fields of a rule, we now use
accessor functions instead of reading the array directly.  For example, the
old way was:

	$match = $obj->match_first_rule($sport, $dport, $proto);
	$name = $match->[NAME];

The current way is:

	$match = $obj->match_rule($proto, $ok, $sport, $dport);
	$name = $match->name;

=head1 AUTHOR

CoralReef Development team, CAIDA <coral-info@caida.org>

=cut

#  .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   . 
