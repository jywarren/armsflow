#!/usr/local/bin/perl -w
## 
## Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
## All Rights Reserved 
## 
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
## 
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
## 
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
## 
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
## 
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program. Support for this effort is provided by the CAIDA grant
## NCR-9711092, and by CAIDA members.
## 
## Report bugs and suggestions to coral-bugs@caida.org.
## 

use strict;

use Getopt::Std;
use vars qw($opt_D $opt_s);
my ($show_subif, $show_iface, $show_totals, $short_form);

my $coral_dir;
BEGIN { $coral_dir = "/usr/local/Coral"; } # This will be edited during build.
use lib "$coral_dir/lib"; #coral global libdir#
use lib "../../lib"; #coral local libdir#
use CAIDA::Traffic2::FileReader;
use CAIDA::Tables::Tuple_Table;

$| = 1;                 # don't buffer output

my ($pname) = $0 =~ m#([^/]+)$#;

my ($no_repeat_i, $no_repeat_t); # For suppression of redundant totals
if (!getopts('sD:') or @ARGV > 0) {
    print STDERR "Usage: crl_traffic2 {crl_traffic2_options} | ",
				"$pname {${pname}_options}\n",
	    "   Or: $pname {${pname}_options} < file.t2\n",
	    "$pname options:\n",
	    "-s will output information in 'short mode', with only\n",
	    "   a single line for each interval.\n",
	    "-D[SITsit] controls display options as follows:\n",
	    "        S displays subinterface-level information.\n",
	    "        I displays interface-level totals.\n",
	    "        T displays totals for all interfaces.\n",
	    "        s, i, and t are the same as S, I and T, except that\n",
	    "            redundant information is suppressed.\n",
	    "            (eg. if there's only one interface, only that total\n",
	    "             will be displayed)\n",
	    "The default is equivalent to -Dsit\n";
    exit 1;
}

if ($opt_D) {
    if ($opt_D =~ /s/ or $opt_D =~ /S/) { # s and S are equivalent
	$show_subif = 1;
    }
    if ($opt_D =~ /i/) {
	$show_iface = 1;
	$no_repeat_i = 1;
    }
    if ($opt_D =~ /t/) {
	$show_totals = 1;
	$no_repeat_t = 1;
    }
    if ($opt_D =~ /I/) {
	$show_iface = 1;
	$no_repeat_i = 0;
    }
    if ($opt_D =~ /T/) {
	$show_totals = 1;
	$no_repeat_t = 0;
    }
} else {
    # Equivalent to -Dsit
    $no_repeat_i = $no_repeat_t = 1;
    $show_subif = $show_iface = $show_totals = 1;
}
if ($opt_s) {
    $short_form = 1;
    $show_subif = $show_iface = 0;
}
my $reader = new CAIDA::Traffic2::FileReader(*STDIN);
die "Cannot understand input" if not defined $reader;

my $rates_fmt = "%8s %8s %8s";
my $sub_hdr_fmt = "%6s %10s %8s %8s";
my $sub_data_fmt = "%8.f %10.f %8.f %8.f";

my $data_fmt = "%-11s $sub_data_fmt $rates_fmt\n";
my $short_fmt = "%-10d $sub_data_fmt $rates_fmt\n";
my $hdr_fmt = "%-13s $sub_hdr_fmt $rates_fmt\n";
my $short_hdr_fmt = "%-12s $sub_hdr_fmt $rates_fmt\n";

my $looped_once;

if ($short_form) {
    printf $short_hdr_fmt, "# start", "pkts", "bytes", "flows", "entries",
			"pkts/s", "bits/s", "flows/s";
}
while (my $interval = $reader->get_next_interval()) {
    my %totals;
    my $pkts = 0;
    my $bytes = 0;
    my $flows = 0;
    my $entries = 0;
    my $start = $interval->get_metadata('start');
    my $duration = $interval->get_metadata('duration');
    next unless defined $duration;
    foreach my $id_info ($interval->get_id_infos()) {
	# XXX Get first table, assuming only one is desired.
	my $type = ($id_info->get_table_types())[0];
	my $table;
	if (defined $type) {
	    $table = $interval->get_table($id_info, $type);
	} else {
	    $table = new CAIDA::Tables::Tuple_Table;
	}
	next unless defined $table;
	my $id = $id_info->get_metadata('id');
	my ($iface) = ($id =~ /(\d+)/);
	if ($show_iface) {
	    $totals{$iface}{'ALL'}{'pkts'} += $table->total()->pkts();
	    $totals{$iface}{'ALL'}{'bytes'} += $table->total()->bytes();
	    $totals{$iface}{'ALL'}{'flows'} += $table->total()->flows();
	    $totals{$iface}{'ALL'}{'entries'} += $table->num_entries();
	}
	if ($show_subif) {
	    $totals{$iface}{$id}{'pkts'} += $table->total()->pkts();
	    $totals{$iface}{$id}{'bytes'} += $table->total()->bytes();
	    $totals{$iface}{$id}{'flows'} += $table->total()->flows();
	    $totals{$iface}{$id}{'entries'} += $table->num_entries();
	}
	$totals{'ALL'}{'ALL'}{'pkts'} += $table->total()->pkts();
	$totals{'ALL'}{'ALL'}{'bytes'} += $table->total()->bytes();
	$totals{'ALL'}{'ALL'}{'flows'} += $table->total()->flows();
	$totals{'ALL'}{'ALL'}{'entries'} += $table->num_entries();
    }
    if ($short_form) {
	my $pkts = $totals{'ALL'}{'ALL'}{'pkts'};
	my $bytes = $totals{'ALL'}{'ALL'}{'bytes'};
	my $flows = $totals{'ALL'}{'ALL'}{'flows'};
	my $entries = $totals{'ALL'}{'ALL'}{'entries'};
	$pkts = 0 if not defined $pkts;
	$bytes = 0 if not defined $bytes;
	$flows = 0 if not defined $flows;
	$entries = 0 if not defined $entries;
	printf $short_fmt, $start, $pkts, $bytes, $flows, $entries,
	    format_num($pkts / $duration), format_num($bytes * 8 / $duration),
	    format_num($flows / $duration);
    } else {
	print "\n" if $looped_once;
	print "# time $start (${duration}s)\n";
	printf $hdr_fmt, "# if[subif]", "pkts", "bytes", "flows", "entries",
			"pkts/s", "bits/s", "flows/s";
	my @total_keys = sort keys %totals;
	my $num_ifaces = scalar(@total_keys) - 1;
	foreach my $iface (@total_keys) {
#	    my $showed_subif;
	    my $num_subifs = 0;
	    if ($show_subif and $iface ne 'ALL') {
		$num_subifs = scalar(keys %{$totals{$iface}}) - 1;
		foreach my $id (keys %{$totals{$iface}}) {
		    next if $id eq 'ALL';
		    my $pkts = $totals{$iface}{$id}{'pkts'};
		    my $bytes = $totals{$iface}{$id}{'bytes'};
		    my $flows = $totals{$iface}{$id}{'flows'};
		    my $entries = $totals{$iface}{$id}{'entries'};
		    $pkts = 0 if not defined $pkts;
		    $bytes = 0 if not defined $bytes;
		    $flows = 0 if not defined $flows;
		    $entries = 0 if not defined $entries;
		    printf $data_fmt, $id, $pkts, $bytes, $flows, $entries,
			    format_num($pkts / $duration),
			    format_num($bytes * 8 / $duration),
			    format_num($flows / $duration);
		}
#		$showed_subif = 1;
		next if $num_subifs == 1 and $no_repeat_i;
	    }
	    next if $iface eq 'ALL' and not $show_totals;
	    next unless $iface eq 'ALL' or $show_iface;
	    next if $num_ifaces == 1 and $iface eq 'ALL' and $no_repeat_t;
	    my $pkts = $totals{$iface}{'ALL'}{'pkts'};
	    my $bytes = $totals{$iface}{'ALL'}{'bytes'};
	    my $flows = $totals{$iface}{'ALL'}{'flows'};
	    my $entries = $totals{$iface}{'ALL'}{'entries'};
	    $pkts = 0 if not defined $pkts;
	    $bytes = 0 if not defined $bytes;
	    $flows = 0 if not defined $flows;
	    $entries = 0 if not defined $entries;
	    my $iface_str = sprintf "%-3s TOTAL", $iface;
	    printf $data_fmt, $iface_str, $pkts, $bytes, $flows, $entries,
		    format_num($pkts / $duration),
		    format_num($bytes * 8 / $duration),
		    format_num($flows / $duration);
	    if ($show_subif and $num_ifaces > 1) {
		print "\n";
	    }
	}
    }
    $looped_once = 1;
}

sub format_num {
    my ($num) = @_;
    my $out_str;
    if ($num > 1000000) {
	$out_str = sprintf "%6.2fM", $num / 1000000;
    } elsif ($num > 1000) {
	$out_str = sprintf "%6.2fk", $num / 1000;
    } else {
	$out_str = sprintf "%6.2f ", $num;
    }
    return $out_str;
}
