/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */


#include "config.h"
#include "coraldefs.h"
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <sys/stat.h>
#include <sys/mman.h>

#include "libcoral.h"
#include "libcoral_priv.h"

static const char RCSid[] = "$Id: coral_write.c,v 1.83 2007/06/06 18:17:56 kkeys Exp $";

#ifdef HAVE_LIBZ
# include <zlib.h>
#endif

/* We should align writes on a multiple of the largest block size we expect
 * to see on any system.  (Using a size larger than the current system's may
 * waste a little space, but the file will still be efficient if copied to
 * another system.)
 */
#define FS_BLOCK_SIZE 8192

#define MAX_IFACES	16
#define MAX_WRITERS	16

#define validate_writer(w, label, errval) \
    do { \
	if (!(w) || (w)->wd < 0 || (w)->wd > MAX_WRITERS) { \
	    if (label) \
		coral_diag(0, ("%s (%p): invalid writer\n", label, (w))); \
	    errno = EINVAL; \
	    return errval; \
	} \
    } while (0)

#define validate_unstarted_writer(w, label, errval) \
    do { \
	validate_writer((w), label, errval); \
	if ((w)->started) { \
	    if (label) \
		coral_diag(0, ("%s: writer %d (%s) already started\n", \
		    label, (w)->wd, (w)->filename)); \
	    errno = EBUSY; \
	    return errval; \
	} \
    } while (0)

/* block info is kept in host byte order while we're working with it, and
 * converted to network byte order just before being flushed.
 * file header starts in host byte order before coral_write_start(), network
 * byte order after.
 */
/* Some abbreviations:
 * wd - write descriptor (index into writers[])
 * wid - write interface descriptor (index into writers[wd]->iface[])
 * rid - read interface descriptor (index into cinst[])
 */

typedef struct {
    coral_iface_info_t iface_info;
    size_t cell_size;
    u_int blk_size;			/* size of data blocks */
    uint32_t buffer[CORAL_MAX_HBLK_SIZE/4]; /* uint32_t aligns > char */
} write_iface_t;

struct coral_writer {
    int wd;				/* index of this in writers[] */
    char *filename;			/* file name */
    int error;				/* last error */
    int fd;				/* file descriptor */
#ifdef HAVE_LIBZ
    coral_rf_info_gz_t gzinfo;		/* info for rotating gzip file */
#endif
    coral_rotfile_t *rf;		/* rotatable file pointer */
    int started;			/* true if writing has begun */
    coral_file_header_t file_header;	/* working copy of file header */
    write_iface_t *iface[MAX_IFACES];	/* info for each iface being written */
    int wid[CORAL_MAXOPEN];		/* map of rid's to wid's */
    int rotatable;			/* rotatable? */
    uint32_t iface_info_count;
};

static coral_writer_t *writers[MAX_WRITERS];

/* Write ALL bytes of buf to writer.  Returns 0 for error. */
static size_t crl_write(coral_writer_t *writer, void *voidbuf,
    size_t len)
{
    ssize_t n, remaining = len;
    char *buf = voidbuf;

    for (remaining = len; remaining > 0; remaining -= n) {
	/* Note: for error, gzwrite() returns 0, write() returns -1. */
#ifdef HAVE_LIBZ
	if (writer->gzinfo.gzfile) {
	    n = gzwrite(writer->gzinfo.gzfile, buf, remaining);
	    if (n == 0) goto error;
	} else
#endif
	{
	    n = write(writer->fd, buf, remaining);
	    /* In case the write was bigger than the max (signed) value of n
	     * (e.g. 2^31-1), we check for n==-1 instead of n<0. */
	    if (n == (ssize_t)-1) goto error;
	}
	buf += (size_t)n;
    }
    return len;
error:
    writer->error = errno;
    return -1;
}

static void coral_write_init_block(coral_writer_t *writer, int wid)
{
    coral_blk_info_t *cbh;

    cbh = (coral_blk_info_t*)&writer->iface[wid]->buffer;

    cbh->interface = wid;
    cbh->blk_size = writer->iface[wid]->blk_size;
    cbh->cell_count = 0;
    cbh->unknown_vpi_vci = 0;
    cbh->tbegin.tv_sec = 0;
    cbh->tbegin.tv_nsec = 0;
    cbh->tend.tv_sec = 0;
    cbh->tend.tv_nsec = 0;
}

/* If data is NULL, the block info and the cells are both in writer's buffer.
 * If data is not NULL, only the block info is in writer's buffer, and data
 * contains the cells.
 */
static int coral_write_flush(coral_writer_t *writer, int wid,
    const coral_atm_cell_t *data)
{
    coral_blk_info_t *cbh;
    int len, pad, iovcnt, error;
    struct iovec iov[2];

    assert(writer->started);
    cbh = (coral_blk_info_t*)writer->iface[wid]->buffer;
    len = cbh->cell_count * writer->iface[wid]->cell_size;
    pad = cbh->blk_size - len;

    iov[0].iov_base = (char*)cbh;
    iov[0].iov_len = sizeof(*cbh);
    if (data) {
	/* use the block of cells pointed to by data */
	iov[1].iov_base = (char*)data;
	iov[1].iov_len = len;
	iovcnt = 2;
    } else {
	/* assume cells were put into writer's buffer */
	iov[0].iov_len += len;
	iov[1].iov_len = 0;
	iovcnt = 1;
    }

    cbh->interface	    = htonl(wid);
    cbh->blk_size	    = htonl(cbh->blk_size);
    cbh->cell_count	    = htonl(cbh->cell_count);
    cbh->cells_lost	    = htonl(cbh->cells_lost);
    cbh->unknown_vpi_vci    = htonl(cbh->unknown_vpi_vci);
    cbh->tbegin.tv_sec	    = htonl(cbh->tbegin.tv_sec);
    cbh->tbegin.tv_nsec	    = htonl(cbh->tbegin.tv_nsec);
    cbh->tend.tv_sec	    = htonl(cbh->tend.tv_sec);
    cbh->tend.tv_nsec	    = htonl(cbh->tend.tv_nsec);

    error = 0;
#ifdef HAVE_LIBZ
    if (writer->gzinfo.gzfile) {
	int i;
	for (i = 0; i < iovcnt; i++) {
	    if (gzwrite(writer->gzinfo.gzfile, iov[i].iov_base, iov[i].iov_len) == -1) {
		error++;
		break;
	    }
	}
    } else
#endif
    {
	if (writev(writer->fd, iov, iovcnt) == (ssize_t)-1)
	    error++;
    }
    if (error) {
	writer->error = errno;
	coral_diag(0, ("coral_write_flush: writer %d.%d: %s\n",
	    writer->wd, wid, strerror(errno)));
	errno = writer->error;
	return -1;
    }

    /* pad to end of block */
    if (pad > 0) {
	char *buf;
	error = 0;
	/* We could use seek() here, but this should only happen once per
	 * interface, at the end of the file, and would save <1 block. It's
	 * not worth the complexity of handling gzip and non-regular files.
	 */
	buf = (char*)writer->iface[wid]->buffer + sizeof(*cbh) + len;
	memset(buf, 0, pad);
	if (crl_write(writer, buf, pad) == 0) {
	    coral_diag(0, ("coral_write_flush: writer %d.%d: pad: %s\n",
		writer->wd, wid, strerror(errno)));
	    errno = writer->error;
	    return -1;
	}
    }

    /* prepare a new block */
    coral_write_init_block(writer, wid);
    return 0;
}

static coral_writer_t *coral_write_open_helper(const char *name, int fd,
    int rotatable, const char *temp)
{
    int i, error = 0, wd;

    for (wd = 0; wd < MAX_WRITERS && writers[wd]; wd++);
    if (wd == MAX_WRITERS) {
	coral_diag(0, ("coral_write_open: too many open coral traces\n"));
	errno = ENOMEM;
	return NULL;
    }
    if (!(writers[wd] = calloc(1, sizeof(coral_writer_t)))) {
	coral_diag(0, ("coral_write_open: out of memory\n"));
	errno = ENOMEM;
	return NULL;
    }

    writers[wd]->wd = wd;
    writers[wd]->fd = -1;

    if (fd >= 0 && !name) {
	if ((writers[wd]->filename = malloc(16)))
	    sprintf(writers[wd]->filename, "fd.%d", fd);
	writers[wd]->fd = fd;
    } else if (strcmp(name, "-") == 0) {
	writers[wd]->filename = strdup(name);
	writers[wd]->fd = STDOUT_FILENO;
    } else {
	writers[wd]->filename = coral_filename(name, NULL, PATH_MAX);
	writers[wd]->rotatable = !!rotatable;
	i = name ? strlen(name) : -1;
#ifdef HAVE_LIBZ
	if ((coral_config.gzip && *coral_config.gzip) ||
	    (i > 3 && strcmp(name + i - 3, ".gz") == 0))
	{
	    writers[wd]->gzinfo.gzmode = NULL;
	    writers[wd]->rf = coral_rf_open_gzfile(&writers[wd]->gzinfo,
		writers[wd]->filename, temp, 0);
	} else
#endif
	{
	    writers[wd]->rf = coral_rf_open_fd(&writers[wd]->fd,
		writers[wd]->filename, temp, 0);
	}
	if (!writers[wd]->rf) {
	    error = errno;
	    goto coral_write_open_error;
	}
    }

    if (!writers[wd]->filename) {
	error = ENOMEM;
	coral_diag(0, ("coral_write_open: %s\n", strerror(error)));
	goto coral_write_open_error;
    }

    if (coral_config.comment) {
	strncpy(writers[wd]->file_header.desc, coral_config.comment,
	    sizeof(writers[wd]->file_header.desc) - 1);
    } else {
	int n = sizeof(writers[wd]->file_header.desc) - 1;
	char *buf = writers[wd]->file_header.desc;
	if (gethostname(buf, n) >= 0) {
	    n -= strlen(buf);
	    buf += strlen(buf);
	    crl_snprintf(&buf, &n, ": ");
	}
	for (i = 0; i < coral_config.argc; i++)
	    crl_snprintf(&buf, &n, "%s ", coral_config.argv[i]);
    }
    for (i = 0; i < MAX_IFACES; i++)
	writers[wd]->iface[i] = NULL;

    return writers[wd];

coral_write_open_error:
    if (writers[wd]->filename) free(writers[wd]->filename);
    writers[wd]->fd = -1;
    free(writers[wd]);
    errno = error;
    return NULL;
}

coral_writer_t *coral_write_open(const char *name)
{
    return coral_write_open_helper(name, -1, 0, NULL);
}

coral_writer_t *coral_write_fdopen(int fd)
{
    return coral_write_open_helper(NULL, fd, 0, NULL);
}

coral_writer_t *coral_write_rfopen(const char *name, const char *temp)
{
    return coral_write_open_helper(name, -1, 1, temp);
}

int coral_write_close(coral_writer_t *writer)
{
    coral_blk_info_t *cbh;
    int wid, iface_info_count;

    if (!writer) {
	errno = EINVAL;
	return -1;
    }

    iface_info_count = writer->iface_info_count;

    /* flush all partially filled blocks */
    for (wid = 0; wid < iface_info_count; wid++) {
	cbh = (coral_blk_info_t*)&writer->iface[wid]->buffer;
	if (cbh->cell_count > 0) {
	    coral_write_flush(writer, wid, NULL);
	}
    }

    for (wid = 0; wid < iface_info_count; wid++) {
	free(writer->iface[wid]);
    }
    if (writer->filename);
	free(writer->filename);

    if (writer->rf)
	coral_rf_close(writer->rf);
    else if (writer->fd >= 0)
	close(writer->fd);

    writers[writer->wd] = NULL;
    writer->wd = -1;		/* this will catch use after close */
    writer->fd = -1;
    writer->rf = NULL;
    free(writer);
    return 0;
}

const char *coral_write_get_name(coral_writer_t *writer)
{
    return writer->filename;
}

int coral_write_set_encoding(coral_writer_t *writer, const char *name,
    unsigned version)
{
    validate_unstarted_writer(writer, "coral_write_set_encoding", -1);
    if (name) {
	strncpy(writer->file_header.encoding, name,
	    sizeof(writer->file_header.encoding) - 1);
    } else {
	memset(writer->file_header.encoding, 0,
	    sizeof(writer->file_header.encoding));
    }
    writer->file_header.encoding_version = version;
    return 0;
}

int coral_write_set_comment(coral_writer_t *writer, const char *comment)
{
    validate_unstarted_writer(writer, "coral_write_set_comment", -1);
    if (comment) {
	strncpy(writer->file_header.desc, comment,
	    sizeof(writer->file_header.desc) - 1);
    } else {
	memset(writer->file_header.desc, 0, sizeof(writer->file_header.desc));
    }
    return 0;
}

int coral_write_init_interface(coral_writer_t *writer, coral_iface_t *riface)
{
    int wid = -1;
    int error;

    validate_iface(riface, "coral_write_init_interface", -1);
    validate_unstarted_writer(writer, "coral_write_init_interface", -1);

    wid = writer->iface_info_count;
    writer->wid[riface->id] = wid;

    {
	writer->iface[wid] = malloc(sizeof(write_iface_t));
	if (!writer->iface[wid]) {
	    coral_diag(0, ("coral_write_init_interface: out of memory\n"));
	    error = ENOMEM;
	    goto coral_write_init_interface_error;
	}

	/* Copy iface_info from riface... */
	writer->iface[wid]->iface_info = riface->iface_info;
	/* ...but set a few fields explicitly. */
	writer->iface[wid]->iface_info.sw_type = SW_TYPE_CORAL;
	writer->iface[wid]->iface_info.sw_version = CORAL_VERSION;
	writer->iface[wid]->iface_info.proto_rule_count = 0;

	writer->iface[wid]->cell_size = coral_cell_size(riface);
	writer->iface[wid]->blk_size =
	    (coral_type_is_driver(riface->devinfo.type)) ?
	    riface->devinfo.blk_size : CORAL_MAX_BLK_SIZE;
	coral_write_init_block(writer, wid);
	wid++;
    }

    writer->iface_info_count++;
    return 0;

coral_write_init_interface_error:
    while (wid >= writer->iface_info_count) {
	--wid;
	if (writer->iface[wid])
	    free (writer->iface[wid]);
    }
    errno = error;
    return -1;
}

int coral_write_init_source(coral_writer_t *writer, coral_source_t *src)
{
    int i;

    validate_src(src, "coral_write_init_source", -1);

    for (i = 0; i < src->iface_count; i++) {
	if (coral_write_init_interface(writer, cinst[src->id[i]]) < 0)
	    return -1;
    }
    return 0;
}

int coral_write_init_all(coral_writer_t *writer)
{
    int sd;

    for (sd = 0; sd < CORAL_MAXOPEN; sd++) {
	if (csource[sd])
	    if (coral_write_init_source(writer, csource[sd]) < 0)
		return -1;
    }
    return 0;
}

static size_t coral_write_proto_rule(coral_writer_t *writer,
    coral_proto_rule_t *rule)
{
    coral_proto_rule_t buf;
    buf.subif = htonl(rule->subif);
    buf.subifmask = htonl(rule->subifmask);
    buf.protocol = htonl(rule->protocol);
    buf.allow = rule->allow;
    if (crl_write(writer, &buf, sizeof(buf)) == 0) {
	coral_diag(0, ("coral_write_start: writer %d: write: %s\n",
	    writer->wd, strerror(errno)));
	errno = writer->error;
	return -1;
    }
    return sizeof(buf);
}

/* Inefficient, but it's only needed a few times, when writing a file header */
static coral_iface_t *wid_to_iface(coral_writer_t *writer, int wid)
{
    int id;
    for (id = 0; id < coral_max_iface; id++) {
	if (writer->wid[id] == wid)
	    return cinst[id];
    }
    return NULL;
}

/* Note on protocol rules:
 * There may be protocol rules for interfaces, for sources, and globally.
 * Ifaces we're writing may not be (and are probably not) from the same source,
 * so when writing an iface's rules we must also write its source's rules.
 * The global rules are then written to the section that applies to the whole
 * file.
 */
int coral_write_start(coral_writer_t *writer, const struct timeval *tvp)
{
    coral_file_header_t *cfh = &writer->file_header;
    u_int header_size, iface_info_count, proto_rule_count;
    int wid;
    int written = 0;
    coral_proto_rulenode_t *node;

    if (writer->started)
	return 0;

    /* start rotfile */

    if (writer->rf) {
	if (coral_rf_start(writer->rf, tvp) < 0)
	    return -1;
    }

    /* write header */

    if (!(iface_info_count = writer->iface_info_count)) {
	coral_diag(0, ("coral_write_start(%d): no interfaces defined\n",
	    writer->wd));
	errno = 0;
	return -1;
    }

    proto_rule_count = 0;
    for (node = coral_proto_rules.head; node; node = node->next) {
	proto_rule_count++;
    }

    for (wid = 0; wid < iface_info_count; wid++) {
	coral_iface_t *iface = wid_to_iface(writer, wid);
	for (node = iface->proto_rules.head; node; node = node->next) {
	    writer->iface[wid]->iface_info.proto_rule_count++;
	    proto_rule_count++;
	}
	for (node = iface->src->proto_rules.head; node; node = node->next) {
	    writer->iface[wid]->iface_info.proto_rule_count++;
	    proto_rule_count++;
	}
    }

    cfh->magic = htonl(CORAL_MAGIC);
    header_size =
	sizeof(coral_file_header_t) +
	sizeof(coral_iface_info_t) * iface_info_count +
	sizeof(coral_proto_rule_t) * proto_rule_count;
    header_size = (((header_size - 1) / FS_BLOCK_SIZE) + 1) * FS_BLOCK_SIZE;
    cfh->header_size		= htonl(header_size);
    cfh->version		= htonl(CORAL_VERSION);
    cfh->link_protocol		= htonl(CORAL_PROTO_ATM_AAL5);
    memset(&cfh->checksum, 0, sizeof(cfh->checksum));
    cfh->encoding_version	= htonl(cfh->encoding_version);
    cfh->iface_info_count	= htons(iface_info_count);
    cfh->proto_rule_count	= htons(proto_rule_count);

    if (crl_write(writer, cfh, sizeof(coral_file_header_t)) == 0) {
	coral_diag(0, ("coral_write_start: writer %d: %s\n",
	    writer->wd, strerror(errno)));
	errno = writer->error;
	return -1;
    }
    written += sizeof(coral_file_header_t);

    for (wid = 0; wid < iface_info_count; wid++) {
	coral_iface_info_t buf;
	coral_iface_info_t *iface_info = &writer->iface[wid]->iface_info;
	buf.hw_type		= htonl(iface_info->hw_type);
	buf.hw_version		= htonl(iface_info->hw_version);
	buf.fw_type		= htonl(iface_info->fw_type);
	buf.fw_version		= htonl(iface_info->fw_version);
	buf.sw_type		= htonl(iface_info->sw_type);
	buf.sw_version		= htonl(iface_info->sw_version);
	buf.iomode.flags	= htonl(iface_info->iomode.flags);
	buf.iomode.first_n	= htonl(iface_info->iomode.first_n);
	buf.capture_time	= 0; /* obsolete */
	buf.bandwidth		= htonl(iface_info->bandwidth);
	buf.time_is_le		= htonl(iface_info->time_is_le);
	buf.datalink		= htonl(iface_info->datalink);
	buf.tzoff		= htonl(iface_info->tzoff);
	buf.capture_tv.tv_sec	= htonl(iface_info->capture_tv.tv_sec);
	buf.capture_tv.tv_usec	= htonl(iface_info->capture_tv.tv_usec);
	buf.physical		= htonl(iface_info->physical);
	buf.proto_rule_count	= htons(iface_info->proto_rule_count);
	if (crl_write(writer, &buf, sizeof(buf)) == 0) {
	    coral_diag(0, ("coral_write_start: writer %d: %s\n",
		writer->wd, strerror(errno)));
	    errno = writer->error;
	    return -1;
	}
	written += sizeof(buf);
    }

    for (wid = 0; wid < iface_info_count; wid++) {
	coral_iface_t *iface = wid_to_iface(writer, wid);
	size_t result;
	for (node = iface->proto_rules.head; node; node = node->next) {
	    if ((result = coral_write_proto_rule(writer, &node->rule)) < 0)
		return result;
	    written += result;
	}
	for (node = iface->src->proto_rules.head; node; node = node->next) {
	    if ((result = coral_write_proto_rule(writer, &node->rule)) < 0)
		return result;
	    written += result;
	}
    }

    for (node = coral_proto_rules.head; node; node = node->next) {
	size_t result;
	if ((result = coral_write_proto_rule(writer, &node->rule)) < 0)
	    return result;
	written += result;
    }

    /* pad up to header_size */
    if (header_size > written) {
	int pad = header_size - written;
	char *buf;
	buf = (char*)writer->iface[0]->buffer;
	memset(buf, 0, pad);
	if (crl_write(writer, buf, pad) == 0) {
	    coral_diag(0, ("coral_write_start: writer %d: write: %s\n",
		writer->wd, strerror(errno)));
	    errno = writer->error;
	    return -1;
	}
    }

    writer->started = 1;
    return 0;
}

int coral_write_end(coral_writer_t *writer)
{
    if (!writer->rotatable)
	return -1;
    writer->fd = -1;
    writer->started = 0;
    return coral_rf_end(writer->rf);
}

int coral_write_cells(coral_writer_t *writer, const coral_iface_t *riface,
    const coral_atm_cell_t *cell, int count)
{
    coral_blk_info_t *cbh;
    char *p;
    int wid;

    wid = writer->wid[riface->id];
    cbh = (coral_blk_info_t*)&writer->iface[wid]->buffer;

    if (!writer->started)
	if (coral_write_start(writer, NULL) < 0)
	    return -1;

    while (count > 0) {
	int cells_per_blk = cbh->blk_size / writer->iface[wid]->cell_size;
	int n = cells_per_blk - cbh->cell_count;
	if (n > count) n = count;
	p = (char*)cbh + sizeof(coral_blk_info_t) +
	    cbh->cell_count * coral_cell_size(riface);
	memcpy(p, cell, coral_cell_size(riface) * n);
	if ((cbh->cell_count += n) >= cells_per_blk)
	    if (coral_write_flush(writer, wid, NULL) < 0)
	        return -1;
	count -= n;
    }
    return 0;
}

/* keeps tbegin and tend */
int coral_write_block(coral_writer_t *writer, const coral_iface_t *riface,
    const coral_blk_info_t *rbh, const coral_atm_cell_t *blk)
{
    coral_blk_info_t *wbh;	/* write block info */
    int wid;

    wid = writer->wid[riface->id];
    wbh = (coral_blk_info_t*)&writer->iface[wid]->buffer;

    if (!writer->started)
	if (coral_write_start(writer, NULL) < 0)
	    return -1;

    /* If there's a partially filled block, flush it, so we get a new block. */
    if (wbh->cell_count > 0)
	if (coral_write_flush(writer, wid, NULL) < 0)
	    return -1;

    /* coral_write_flush expects info in host order */
    wbh->blk_size	    = ntohl(rbh->blk_size); /* XXX check for max */
    wbh->cell_count	    = ntohl(rbh->cell_count);
    wbh->cells_lost	    = ntohl(rbh->cells_lost);
    wbh->unknown_vpi_vci    = ntohl(rbh->unknown_vpi_vci);
    wbh->tbegin.tv_sec	    = ntohl(rbh->tbegin.tv_sec);
    wbh->tbegin.tv_nsec	    = ntohl(rbh->tbegin.tv_nsec);
    wbh->tend.tv_sec	    = ntohl(rbh->tend.tv_sec);
    wbh->tend.tv_nsec	    = ntohl(rbh->tend.tv_nsec);

    /* pass blk directly, instead of wasting time copying it to buffer */
    return coral_write_flush(writer, wid, blk);
}

