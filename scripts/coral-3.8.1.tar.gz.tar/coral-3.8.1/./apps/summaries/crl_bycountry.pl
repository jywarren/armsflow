#!/usr/local/bin/perl
## 
## Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
## All Rights Reserved 
## 
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
## 
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
## 
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
## 
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
## 
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program. Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
## 
## Report bugs and suggestions to coral-bugs@caida.org.
## 


## This script will calculate source and destination address histograms for a
##      Coral format packet dump.  It requires the uncensored data files to
##      generate sensible results.  Based on oc32asc.pl by Hans-Werner Braun
##
## USAGE:  crl_bycountry.pl <coral source> <parsed routing table>
##
## $Id: crl_bycountry.pl,v 1.27 2007/06/06 18:17:32 kkeys Exp $

my $coral_dir;
BEGIN { $coral_dir = "/usr/local/Coral"; } # This will be edited during build.
use lib "$coral_dir/lib"; #coral global libdir#
use lib "../../lib"; #coral local libdir#
use lib "/usr/local/apps/perl5.004/lib/site_perl/";
use CRL;
use CAIDA::ASFinder;
use Socket qw(inet_aton);
use Fcntl;
use File::Basename;
use CAIDA::NetGeoClient qw($NO_MATCH $NO_COUNTRY $ARRAY_LENGTH_LIMIT
			    $NETGEO_LIMIT_EXCEEDED);

$cvs_Id = '$Id: crl_bycountry.pl,v 1.27 2007/06/06 18:17:32 kkeys Exp $';
$cvs_Author = '$Author: kkeys $';
$cvs_Name = '$Name: release-3-8-1 $';
$cvs_Revision = '$Revision: 1.27 $';

($script_name, $script_path, $script_suffix) = fileparse($0);
$PNAME = "$script_name$script_suffix";


## Check command-line arguments
if (@ARGV < 2) { 
    Coral::usage($PNAME, "<coral source> <parsed routing table>");
    exit(0);
}


## Note: It is faster to use a combined packets/bytes db with either
## tab separated strings or packed sets of doubles.  These settor and
## accessor functions make the code more readable and allow us to
## change the internal format easily.  It's also easy to extend to
## support things such as tracking packet size std.dev. and similar.

# Depends on $packets and $bytes globals.
sub inc_counts {
    my ($table_ref, $key) = @_;
    my ($ptmp, $btmp) = unpack("dd", ${$table_ref}{$key});
    ${$table_ref}{$key} = pack("dd", $ptmp + $packets, $btmp + $bytes);
}

# Sets $packets and $bytes globals.
sub get_counts {
    my ($table_ref, $key) = @_;
    ($packets, $bytes) = unpack("dd", ${$table_ref}{$key});
}


## Main Code.

# open the filtered here, so it can start up before we may have to build
# the net tables.
my $route_file = pop @ARGV;
my $args;
foreach my $arg (@ARGV) {
    $args .= "\"$arg\" ";
}

open(INFILE, "${script_path}crl_ipmatrix $args |")
    or die("Can't get summary from crl_ipmatrix: $!\n");

my $netgeo = new CAIDA::NetGeoClient($PNAME);
my $asfinder = new CAIDA::ASFinder;
my %as2country;
$asfinder->load_file_text($route_file)
    or die("Can't open route file $route_file: $!\n");

chop ($total_packets = <INFILE>);
chop ($total_bytes = <INFILE>);

$total_packets = 0;
$total_bytes = 0;

while (<INFILE>) {
    chop;
    ($src, $dst, $packets, $bytes) = split /\t/;
    
    $total_packets += $packets;
    $total_bytes += $bytes;
    
    ($src_as, $src_net, $src_masklen) = $asfinder->get_as($src);
    ($dst_as, $dst_net, $dst_masklen) = $asfinder->get_as($dst);
    my $src_netnum = unpack("N", inet_aton($src_net));
    my $dst_netnum = unpack("N", inet_aton($dst_net));
    $src_net .= "/$src_masklen" if $src_net;
    $dst_net .= "/$dst_masklen" if $dst_net;
    $netaddr_masklen_bynet{$src_net} = "$src_netnum\t$src_masklen";
    $netaddr_masklen_bynet{$dst_net} = "$dst_netnum\t$dst_masklen";

    if (not $src_as) {
	if (!$net_warned{$src}) {
	    $net_warned{$src} = 1;
	    print STDERR "Whoa!  No route to source $src!\n";
	}
	$packets_bogus_src += $packets;
	$bytes_bogus_src += $bytes;
	$src_as = "NOROUTE";
    } elsif ($src_as eq "MultipleOrigins") {
	# Can't map to country, but has a route.  Do nothing.
    } else {
	# Deal with this later.
	$as2country{$src_as}++;
    }
    
    if (not $dst_as) {
	if (!$net_warned{$dst}) {
	    $net_warned{$dst} = 1;
	    print STDERR "Whoa!  No route to destination $dst!\n";
	}
	$packets_bogus_dst += $packets;
	$bytes_bogus_dst += $bytes;
	$dst_as = "NOROUTE";
    } elsif ($dst_as eq "MultipleOrigins") {
	# Can't map to country, but has a route.  Do nothing.
    } else {
	# Deal with this later.
	$as2country{$dst_as}++;
    }
    
    if ($src_net) {
	inc_counts(\%counts_by_src_net, $src_net);
	inc_counts(\%counts_by_src_masklen, $src_masklen);
	$masklens{$src_masklen}++;
    }
    
    if ($dst_net) {
	inc_counts(\%counts_by_dst_net, $dst_net);
	inc_counts(\%counts_by_dst_masklen, $dst_masklen);
	$masklens{$dst_masklen}++;
    }
    
    #  if ($src_as) {
    #    inc_counts(\%counts_by_src_as, $src_as);
    #  }
    
    #  if ($dst_as) {
    #    inc_counts(\%counts_by_dst_as, $dst_as);
    #  }
    
    if ($src_as && $dst_as) {
	inc_counts(\%as_matrix, "$src_as\t$dst_as");
    }
    
    #  if ($src_abbrev) {
    #    inc_counts(\%counts_by_src_abbrev, $src_abbrev);
    #  }
    
    #  if ($dst_abbrev) {
    #    inc_counts(\%counts_by_src_abbrev, $src_abbrev);
    #  }
}
@masklens = reverse sort numerically keys %masklens;
%masklens = ();

close INFILE;

# Do the AS->country lookups outside the loop for efficiency.
my @ases = keys %as2country;
my @single_ases;

foreach my $as (@ases) {
    if ($as =~ /^\{/) {
        my $as_set = $as;
        $as =~ s/\{(.*)\}/$1/;
        my @aslist = split /,/, $as;
	my $result_ref = $netgeo->getCountryArray(\@aslist);
	my $sub_ref = shift @$result_ref;
	my $first_country = $sub_ref->{COUNTRY};
        foreach my $sub_ref (@$result_ref) {
	    my $test_country = $sub_ref->{COUNTRY};
            if ($test_country ne $first_country) {
                print STDERR "CONFLICT between $test_country and ",
                            "$first_country for AS set: $as_set\n";
                $as2country{$as_set} = "UNKNOWN";
            }
        }
        $as2country{$as_set} = $first_country;
    } else {
	push @single_ases, $as;
    }
}

# XXX Restore when NetGeoClient can handle longer arrays.
# my $country_array_ref = $netgeo->getCountryArray(\@single_ases);
my $country_array_ref = getCountryList(\@single_ases);
if (scalar(@$country_array_ref) != scalar(@single_ases)) {
    die "Fatal error:  Got the wrong number of responses from NetGeo.";
}

my $idx;
for ($idx = 0; $idx <= $#single_ases; $idx++) {
    my $country = $country_array_ref->[$idx]->{COUNTRY};
    if ($country eq $NO_MATCH or $country eq $NO_COUNTRY) {
	undef $country;
    }
    if (!$country) {
	print STDERR "No country found for AS $single_ases[$idx]\n";
	$country = "UNKNOWN";
    }
    $as2country{$single_ases[$idx]} = $country;
}

foreach $pair (keys %as_matrix) {
    my ($src_abbrev, $dst_abbrev);
    get_counts(\%as_matrix, $pair);
    my ($src_as, $dst_as) = split /\t/, $pair;
    if ($src_as eq "NOROUTE") {
	$src_abbrev = "NOROUTE";
    } elsif ($src_as eq "MultipleOrigins") {
	$src_abbrev = "MultipleOrigins";
    } else {
	$src_abbrev = $as2country{$src_as};
    }
    if ($dst_as eq "NOROUTE") {
	$dst_abbrev = "NOROUTE";
    } elsif ($dst_as eq "MultipleOrigins") {
	$src_abbrev = "MultipleOrigins";
    } else {
	$dst_abbrev = $as2country{$dst_as};
    }
    if ($src_abbrev && $dst_abbrev) {
	inc_counts(\%country_matrix, "$src_abbrev\t$dst_abbrev");
    }
}

##===========================================================================
##
## Print out results
my $filename = $ARGV[$#ARGV];
printf("#Trace File: %s\n",$filename);
printf("#%s\n",$cvs_Id);
printf("#%s\n",$cvs_Author);
printf("#%s\n",$cvs_Name);
printf("#%s\n",$cvs_Revision);
printf("#%.f IP Packets, %.f Total IP Bytes.\n",$total_packets,$total_bytes);
printf("#%.f IP Packets with non-routable source addresses containing %.f Bytes.\n",$packets_bogus_src,$bytes_bogus_src);
printf("#%.f with non-routable destination addresses containing %.f Bytes.\n",$packets_bogus_dst,$bytes_bogus_dst);

$total_packets /= 100;
$total_bytes /= 100;

##---------------------------------------------------------------------------
##
## Per network stats

print "\#Traffic breakdown by source network:\n";
print "\#Network\tNetaddr\tNetmask\tPackets\tpct.\tBytes\tpct.\n";
foreach $net (sort by_net keys %counts_by_src_net) {
    ($netaddr, $masklen) = split /\t/, $netaddr_masklen_bynet{$net};
    $netaddr += 0.0;		# w/o this perl maxes out at 0x7fffffff for %x
    get_counts(\%counts_by_src_net, $net);
    printf ("%s\t0x%.8x\t%u\t%.f\t%2.8f\t%.f\t%2.8f\n",
	    $net, $netaddr, $masklen,
	    $packets, $packets/$total_packets,
	    $bytes, $bytes/$total_bytes);
}

print "\#Traffic breakdown by destination network:\n";
print "\#Network\tNetaddr\tNetmask\tPackets\tpct.\tBytes\tpct.\n";
foreach $net (sort by_net keys %counts_by_dst_net) {
    ($netaddr, $masklen) = split /\t/, $netaddr_masklen_bynet{$net};
    $netaddr += 0.0;		# w/o this perl maxes out at 0x7fffffff for %x
    get_counts(\%counts_by_dst_net, $net);
    printf ("%s\t0x%.8x\t%u\t%.f\t%2.8f\t%.f\t%2.8f\n",
	    $net, $netaddr, $masklen,
	    $packets, $packets/$total_packets,
	    $bytes, $bytes/$total_bytes);
}

##---------------------------------------------------------------------------
##
## Per AS stats

#print "\#Traffic breakdown by source AS:\n";
#foreach $as (sort by_as keys %counts_by_src_as) {
#   get_counts(\%counts_by_src_as, $as);
#   printf ("%d\t%.f\t%2.4f\t%.f\t%2.4f\n", $as,
#	   $packets, $packets/$total_packets,
#	   $bytes, $bytes/$total_bytes);
#}

#print "\#Traffic breakdown by destination AS:\n";
#foreach $as (sort by_as keys %counts_by_dst_as) {
#   get_counts(\%counts_by_dst_as, $as);
#   printf ("%d\t%.f\t%2.4f\t%.f\t%2.4f\n", $as,
#	   $packets, $packets/$total_packets,
#	   $bytes, $bytes/$total_bytes);
#}

print "\#AS Traffic matrix:\n";
print "\#SrcAS\tDstAS\tPackets\tpct.\tBytes\tpct.\n";
foreach $pair (sort by_as_pairs keys %as_matrix) {
    get_counts(\%as_matrix, $pair);
    printf ("%s\t%.f\t%2.4f\t%.f\t%2.4f\n", $pair,
	    $packets, $packets/$total_packets,
	    $bytes, $bytes/$total_bytes);
}

##---------------------------------------------------------------------------
##
## Per prefix length stats

print "\#Traffic breakdown by source prefix length:\n";
print "\#MaskLen\tPackets\tpct.\tBytes\tpct.\n";
foreach $masklen ($masklens[-1]..$masklens[0]) {
    get_counts(\%counts_by_src_masklen, $masklen);
    printf ("%d\t%.f\t%2.4f\t%.f\t%2.4f\t", $masklen,
	    $packets, $packets/$total_packets,
	    $bytes, $bytes/$total_bytes);
    
    if ($packets > 0) {
	printf ("%u", $bytes/$packets);
    }
    print "\n";
}

print "\#Traffic breakdown by destination prefix length:\n";
print "\#MaskLen\tPackets\tpct.\tBytes\tpct.\n";
foreach $masklen ($masklens[-1]..$masklens[0]) {
    get_counts(\%counts_by_dst_masklen, $masklen);
    printf ("%d\t%.f\t%2.4f\t%.f\t%2.4f\t", $masklen,
	    $packets, $packets/$total_packets,
	    $bytes, $bytes/$total_bytes);
    
    if ($packets > 0) {
	printf ("%u", $bytes/$packets);
    }
    print "\n";
}

##---------------------------------------------------------------------------
##
## Per country stats

print "\#Country <-> Country Traffic matrix:\n";
print "\#Src\tDst\tPackets\tpct.\tBytes\tpct.\n";
foreach $pair (sort by_country_pairs keys %country_matrix) {
    get_counts(\%country_matrix, $pair);
    printf ("%s\t%.f\t%2.8f\t%.f\t%2.8f\n", $pair,
	    $packets, $packets/$total_packets,
	    $bytes, $bytes/$total_bytes);
}


##===========================================================================
##
## Subroutines

sub numerically {
    $a <=> $b;
}

sub by_net {
    my ($a1, $a2, $a3, $a4, $a_len) = split /[.\/]/, $a;
    my ($b1, $b2, $b3, $b4, $b_len) = split /[.\/]/, $b;
    
    if ($a1 != $b1) { return $a1 <=> $b1; }
    if ($a2 != $b2) { return $a2 <=> $b2; }
    if ($a3 != $b3) { return $a3 <=> $b3; }
    if ($a4 != $b4) { return $a4 <=> $b4; }
    # swap a & b so that we show larger allocations before suballocations
    return $b_len <=> $a_len;
}

sub as_cmp {
    my ($a, $b) = @_;
    if ($a == 0) {
	if ($b == 0) {
	    return $a cmp $b;
	} else {
	    return 1;
	}
    } else {
	if ($b == 0) {
	    return -1;
	} else {
	    return $a <=> $b;
	}
    }  
}

sub by_as {
    return as_cmp($a, $b);
}

sub by_as_pairs {
    my ($src_a, $dst_a) = split /\t/, $a;
    my ($src_b, $dst_b) = split /\t/, $b;
    my ($src_cmp) = as_cmp($src_a, $src_b);
    
    if ($src_cmp != 0) {
	return $src_cmp;
    } else {
	return as_cmp($dst_a, $dst_b);
    }
}


sub by_country_pairs {
    my ($src_a, $dst_a) = split /\t/, $a;
    my ($src_b, $dst_b) = split /\t/, $b;
    my ($src_cmp) = $src_a cmp $src_b;
    
    if ($src_cmp != 0) {
	return $src_cmp;
    } else {
	return $dst_a cmp $dst_b;
    }
}

sub getCountryList {
    my ($as_array_ref) = @_;
    my @rest_list = @$as_array_ref;
    my @country_list;
    my @trunc_list;
    while (scalar(@rest_list)) {
	if (@rest_list > $ARRAY_LENGTH_LIMIT) {
	    @trunc_list = @rest_list[0 .. $ARRAY_LENGTH_LIMIT-1];
	} else {
	    @trunc_list = @rest_list;
	}
	my $fail_count = 0;
GET:	my $temp_ret_val = $netgeo->getCountryArray(\@trunc_list);
	foreach my $ref (@$temp_ret_val) {
	    if ($ref->{STATUS} eq $NETGEO_LIMIT_EXCEEDED) {
		print STDERR "Exceeded rate limit, sleeping.\n";
		sleep(30 * ++$fail_count + int(rand 5) + 1);
		goto GET;
	    } else {
		shift @trunc_list; # If we need to requery, don't want dup's.
		push @country_list, $ref;
	    }
	}
	splice @rest_list, 0, $ARRAY_LENGTH_LIMIT;
    }

    return \@country_list;
}
