/*
 * fatm_board.h - jdugan's `structures for the fore atm capture stuff.
 *
 * $Id: fatm_board.h,v 1.27 2001/05/02 23:43:41 kkeys Exp $
 *
 */

#undef CORAL_DEBUG

#include <sys/proc.h>
#include <pci/pcivar.h>
#ifdef MODULE
#include "coral_global.h"
#include "aali.h"
#else
#include <pci/coral_global.h>
#include <pci/aali.h>
#endif
#include <pci/coral_common.h>

#define FATM_CELL_SIZE		60
#define FATM_BLK_SIZE		(1024*1024 - CORAL_BLK_HEADER_SIZE)
#define FATM_NUM_BLKS		16
#define FATM_CELLS_PER_BLK	(FATM_BLK_SIZE / FATM_CELL_SIZE)
#define FATM_CELLBUF_SIZE	((CORAL_BLK_HEADER_SIZE + FATM_BLK_SIZE) * \
				    FATM_NUM_BLKS)

#define E_BLK 0x00  /* empty */
#define C_BLK 0x01  /* card */
#define F_BLK 0x02  /* full */
#define U_BLK 0x04  /* user */

#define NFATM 2

typedef unsigned int fatm_reg32;

typedef struct receive_block {
    struct mbuf *f;
    struct receive_block *next;
    unsigned int stat;
} *receive_block;

/* probably not the best deal, but...*/
typedef struct fatm {
    int interrupts;
    int extra_interrupts;
    
    /* Holds the pid of the process that opened the device. */
    pid_t pid;
    
    /* Partitions the raw memory buffer into blocks and keeps track of it. */
    struct block_pool block_pool;
    
    /* The raw memory used by the driver, card, and applications. */
    char *buffer;

    /* A filled block that the card can reuse if it must. */
    struct block *losing;

#define ST_OPEN			0x00000001
#define ST_CARDINIT		0x00000002
#define ST_CAPTURING		0x00000004
    u_int state;

    u_char fatmi;	/* this fatm index */

    struct timeval timeout; /* used for timeout counting */
    int fatmwait;	/* object used to tsleep() on */

    coral_io_mode_t iomode;

    int command_timeout;
    char input_ring[8192];
    int polling_frequency;

    int input_fill_pointer;
    int input_read_pointer;
    int input_overrun;

    struct selinfo s;
    pcici_t config_id;
    struct pci_device *dvp;

    int last_heartbeat;

#if __FreeBSD_version >= 300000
    struct timespec lost_time;
    struct timespec start_time;
    struct timespec loss_begin;
#else
    struct timeval lost_time;
    struct timeval start_time;
    struct timeval loss_begin;
#endif

    fatm_reg32 base; /* the base of all the above reg offsets */

/* why are these all variables? */
/* absolute addrs of registers on the board, 
 * the ordering here doesn't mean anything.  */
    fatm_reg32 i960_to_host;
    fatm_reg32 host_to_i960;
    fatm_reg32 boot_status;
    fatm_reg32 board_control;
    fatm_reg32 interrupt_control;
    fatm_reg32 psr;

/* cp_queues */
    fatm_reg32 command_queue;
    fatm_reg32 current_host_limit;	/* calculated by card from 
					 * current_host_block and 
					 * init.host_block_size, when copying 
					 * to current_host_block */
    fatm_reg32 current_host_block;	/* written by host during init, card 
					 * copies from next_host_block 
					 * afterwards as needed */
    fatm_reg32 next_host_block;		/* written by host during init, 
					 * afterwards when host sees end of 
					 * block was written to */
    fatm_reg32 imask;			/* non zero enables CP to host 
					 * interrupts */
    fatm_reg32 istat;			/* 1 for interrupt posted */
    fatm_reg32 hlogger;			/* non zero for host logging */
    fatm_reg32 heartbeat;
    fatm_reg32 firmware_release;

    fatm_reg32 fifo_depth_counts;

/* tx stuff */
    fatm_reg32 current_tx_block;  /* written by host during init, card copies 
				   * from next_tx_block afterwards as needed */
    fatm_reg32 current_tx_length; /* measured in 32-bit words, written 
				   * by host during init, card 
				   * copies from next_tx_length afterwards 
				   * as needed, card updates 
				   * as read progresses */
    fatm_reg32 current_tx_sent;	 /* measured in 32-bit words, card 
				  * updates as transmit progresses */
    fatm_reg32 next_tx_block;    /* written by host during init, afterwards 
				  * when host sees end 
				  * of block was read from */
    fatm_reg32 next_tx_length;	 /* measured in 32-bit words, written 
				  * same time as current_tx_block */

/* init_block */
    fatm_reg32 init_op;
    fatm_reg32 init_status;           /* initialized and read by host */
    fatm_reg32 init_index_bits_avail; /* filled by card, altered by host,
					 for VPI/VCI state lookup */
    fatm_reg32 init_bits_from_vci;    /* starting at lsb, remainder come 
				       * from VPI */
    fatm_reg32 init_high_vpi_vci;     /* most sig bits (unused for indexing) 
				       * must
				         match this */
    fatm_reg32 init_host_block_size;  /* measured in bytes */
    fatm_reg32 init_cqueue_len;	      /* command queue */
    fatm_reg32 enable_timer_interrupt; /* allow software expansion of 16-bit 
					* h/w timer? */
    fatm_reg32 enable_line_loopback;  /* pass atm clls through */

    fatm_reg32 command_queue_head;

} *fatm;

#ifdef MODULE
#define MODUNIQ(str) mod_##str
extern struct cdevsw MODUNIQ(fatm_cdevsw);
#else
#define MODUNIQ(str) str
#endif

extern struct fatm fatms[];
extern struct pci_device MODUNIQ(fatmdevice);

#define CDEV_MAJOR 208

#define FORE_VENDOR		0x1127
/* 210 is pc200a*/
/* 300 is pc200pc*/
#define PCA200PC_BOARD		0x0300
#define PCA200A_BOARDID		0x03001127
#define fatm_from_dev(x)	(fatms + minor(x))

static inline u_int read_fatm_32(fatm_reg32 addr)
{
    return(*(unsigned int *)(addr));
}
static inline void write_fatm_32(fatm_reg32 addr, u_int32_t val)
{
    (*(unsigned int *)(addr)) = val;
}
static inline u_int8_t read_fatm_8(fatm_reg32 addr)
{
    return(*(unsigned char *)(addr));
}
static inline void write_fatm_8(fatm_reg32 addr, u_int8_t val)
{
    (*(unsigned char *)(addr)) = val;
}

void MODUNIQ(fatm_attach)(fatm f, int unit);
void MODUNIQ(fatm_interrupt)(fatm f);
