## 
## Copyright 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
## All Rights Reserved 
## 
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
## 
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
## 
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
## 
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
## 
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program. Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
## 
## Report bugs and suggestions to coral-bugs@caida.org.
## 

package CAIDA::Traffic2::FileWriter;

use strict;
use Carp;
require CAIDA::Traffic2::Interval;

my $cvs_Id = '$Id: FileWriter.pm,v 1.17 2007/06/06 18:17:50 kkeys Exp $';
my $cvs_Author = '$Author: kkeys $';
my $cvs_Name = '$Name: release-3-8-1 $';
my $cvs_Revision = '$Revision: 1.17 $';

sub new {
    my ($classname, $file, $binary) = @_;
    my $filehandle;
    if (not $file) {
	carp "FileWriter requires a file name or file handle to write to.";
	return undef;
    } elsif (defined fileno $file) {
	$filehandle = $file;
    } elsif (ref $file) {
	carp "FileWriter requires a file name or file handle to write to.";
	return undef;
    } else {
	require IO::File;
	my $new_handle = new IO::File ">$file";
	if (not $new_handle) {
	    carp "Cannot open file $file: $!";
	    return undef;
	}
	$filehandle = $new_handle;
    }
    my $self =  {
		    'file' => $filehandle,
		    'version' => "1.1",
		    'dump tables' => [],
		    'user tables' => [],
		    'valid tables' => {},
		    'binary mode' => $binary,
		    'interval' => undef,
		};
    bless $self;
    $self->_write_header($filehandle);
    return $self;
}

sub _write_header {
    my ($self, $filehandle) = @_;
    print $filehandle "# FileWriter output version: ", $self->{'version'};
    if ($self->{'binary mode'}) {
	print $filehandle " (binary format)\n";
    } else {
	print $filehandle " (text format)\n";
    }
}

sub initialize {
    my ($self, $interval, @dump_tables) = @_;
    foreach my $idx (0 .. $#dump_tables) {
	$dump_tables[$idx] =~ s/_/ /g;
    }
    $self->{'interval'} = $interval;
    $self->{'dump tables'} = \@dump_tables;
}

sub init_user_tables {
    my ($self, @user_tables) = @_;
    foreach my $idx (0 .. $#user_tables) {
	$user_tables[$idx] =~ s/_/ /g;
    }
    $self->{'user tables'} = \@user_tables;
}

sub dump_interval_start {
    my ($self) = @_;
    my $filehandle = $self->{'file'};
    my $interval = $self->{'interval'};
    if (defined $interval) {
	my $fake_header = $interval->_write_header($filehandle);
	foreach my $id_info ($interval->get_id_infos()) {
	    my $id = $id_info->get_metadata('id');
	    $self->{'valid tables'}{$id} =
		    $id_info->_write_header($filehandle, $fake_header,
					    $self->{'dump tables'},
					    $self->{'user tables'});
	}
    }
}

sub dump_interval_table {
    my ($self, $id_info, $type, $table, $use_timestamps) = @_;
    $type =~ s/_/ /g;
    my $filehandle = $self->{'file'};
    my $okay_to_dump = 0;
    my @types;
    my $id = $id_info->get_metadata('id');
    if (defined $self->{'valid tables'}{$id}) {
	@types = @{$self->{'valid tables'}{$id}};
    }
    if ($self->{'user tables'}) {
	push @types, @{$self->{'user tables'}};
    }
    foreach my $to_dump (@types) {
	if ($type eq $to_dump) {
	    $okay_to_dump = 1;
	    last;
	}
    }
    if (not $okay_to_dump) {
	carp "Not dumping $type, as it was specified in neither " .
		"initialize() nor init_user_tables()."
    } elsif (defined $id_info) {
	$id_info->_dump_table($filehandle, $type, $self->{'binary mode'},
				$use_timestamps, $table);
    }
}

sub dump_interval_end {
    my ($self) = @_;
    my $filehandle = $self->{'file'};
    my $interval = $self->{'interval'};
    if (defined $interval) {
	$interval->_write_footer($filehandle);
    }
}

# This requires preloading the entire interval.
sub dump_interval_full {
    my ($self, $use_timestamps) = @_;
    my $filehandle = $self->{'file'};
    my $interval = $self->{'interval'};
    my @dump_tables = @{$self->{'dump tables'}};
    $self->{'user tables'} = []; # Can't dump extra tables with this function.
    if (defined $interval) {
	$self->dump_interval_start();
	foreach my $id_info ($interval->get_id_infos()) {
	    my $id = $id_info->get_metadata('id');
	    my @types;
	    if (@dump_tables > 0) {
		@types = @{$self->{'valid tables'}{$id}};
	    } else {
		# Due to preloading, this is always okay.
		@types = $id_info->get_existing_types();
	    }
	    foreach my $type (@types) {
		$id_info->_dump_table($filehandle, $type,
				    $self->{'binary mode'}, $use_timestamps);
	    }
	}
	$self->dump_interval_end();
    }
}

1;
