/* 
 * Copyright 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 *
 * $Id: crl_ips.c,v 1.7 2007/06/06 18:17:36 kkeys Exp $
 * Prints list of unique IP addresses found in input.
 * Runs in a little over 512MB, no matter what the size of the input.
 *
 */


static const char RCSid[]="$Id: crl_ips.c,v 1.7 2007/06/06 18:17:36 kkeys Exp $";

#include "config.h"
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <signal.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/in_systm.h>
#include <arpa/inet.h>
#include <netinet/ip.h>
#include <sys/param.h>

#include "libcoral.h"



/* from young's ipv4-bitmap.c */

static unsigned char bit_mask[8] = { 1, 2, 4, 8, 16, 32, 64, 128 };

static unsigned char *bitmap;

static void initialize(void)
{
  bitmap = (unsigned char *)malloc(0x1FFFFFFF + 1);
  if (!bitmap)
  {
    fprintf(stderr, "ERROR: Couldn't allocate bitmap.\n");
    exit(1);
  }
}

static void mark_address(unsigned long addr)
{
  unsigned long idx = addr / 8;
  unsigned char mask = bit_mask[addr & 0x7];

  /*  printf("%lu => %lu : %lu (%lx)\n", addr, idx, mask, idx); */

  bitmap[idx] |= mask;
}

static void dump_bitmap(void)
{
  struct in_addr addr;
  unsigned long i;

  for (i = 0; i <= 0x1FFFFFFF; i++)
  {
    unsigned char value = bitmap[i];
    if (value)
    {
      unsigned long base = i * 8;
      unsigned long offset;

      /*      printf("[%lu] %lu => %lu\n", i, value, base); */
      for (offset = 0; offset < 8; offset++, value >>= 1)
      {
	if (value & 0x1)
	{
	  unsigned long n = base + offset;
	  addr.s_addr = htonl(n);
	  /*	  printf("%lu => %s\n", n, inet_ntoa(addr)); */
	  printf("%s\n", inet_ntoa(addr));
	}
      }
    }
  }
}

static void quit(int sig)
{
    coral_pkt_done = 1;
}

static void pkt_handler(coral_iface_t *iface,
    const coral_timestamp_t *timestamp, void *mydata,
    coral_pkt_buffer_t *packet, coral_pkt_buffer_t *header,
    coral_pkt_buffer_t *trailer)
{
    coral_pkt_buffer_t ippkt;
    struct ip *ip;

    if (coral_get_payload_by_layer(packet, &ippkt, 3) < 0)
	return;
    if (ippkt.protocol != CORAL_NETPROTO_IP)
	return;
    ip = (struct ip*)ippkt.buf;

    if (!coral_field_fits(ip,ip_src,ippkt.caplen)) return;
    mark_address(ntohl(ip->ip_src.s_addr));
    if (!coral_field_fits(ip,ip_dst,ippkt.caplen)) return;
    mark_address(ntohl(ip->ip_dst.s_addr));
}

/* end ipv4-bitmap.c */



static void usage(const char *name)
{
    coral_usage(name, "[options] <source>...\n"
	"Prints IPv4 source and destination addresses found in input.\n"
#if 0
	"Options:\n"
	"-P     do not allow partial packets\n"
#endif
	);
}

int main(int argc, char *argv[])
{
    int n, opt;

    signal(SIGINT, quit);

    coral_set_api(CORAL_API_PKT);
    coral_set_iomode(0, CORAL_RX_UNKNOWN, -1, 0); /* clear defaults */
    coral_set_duration(0);

    while ((opt = getopt(argc, argv, "C:")) >= 0) {
        if (opt == 'C') {
            if (coral_config_command(optarg) < 0) {
		usage(argv[0]);
                exit(-1);
	    }
        } else {
	    usage(argv[0]);
            exit(-1);
        }
    }

    while (optind < argc) {
        if (!coral_new_source(argv[optind]))
            exit(-1);
        optind++;
    }

    if ((n = coral_open_all()) < 0)
        exit(-1);
    if (n == 0) {
	coral_diag(0, ("no sources.\n"));
	exit(0);
    }

    initialize();

    if (coral_start_all() < 0)
        exit(-1);

    if (coral_read_pkts(NULL, NULL, pkt_handler, NULL, NULL, NULL, NULL) < 0)
	exit(-1);

    coral_stop_all();
    coral_close_all();

    dump_bitmap();

    return 0;
}

