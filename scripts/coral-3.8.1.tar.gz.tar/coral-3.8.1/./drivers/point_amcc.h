/* 
 * This is partially based on code written by Joel Apisdorf.
 */

/*
 * point_amcc.h - layout of amcc pci controller on apptel point622
 * 
 * this chip does the bus master transfers of data to memory.
 * http://www.amcc.com/ "Matchmaker" S5933Q
 *
 * $Id: point_amcc.h,v 1.5 1999/03/04 00:38:28 kkeys Exp $
 *
 */

#ifndef POINT_AMCC_H
#define POINT_AMCC_H


struct AmccInterruptControlStatus_register {
    
    u_int OutgoingMailBoxByte                       : 2;
    u_int OutgoingMailBoxWord                       : 2;    /* minus one */
    u_int EnableOutgoingMailBoxGoesEmptyInterrupt   : 1;
    u_int Reserved1                                 : 3;    /* must be zero */

    u_int IncomingMailBoxByte                       : 2;
    u_int IncomingMailBoxWord                       : 2;    /* minus one */
    u_int EnableIncomingMailBoxGoesFullInterrupt    : 1;
    u_int Reserved2                                 : 1;    /* must be zero */
    u_int EnableWriteTransferCompleteInterrupt      : 1;    /* 15 */
    u_int EnableReadTransferCompleteInterrupt       : 1;

    /* write one to clear the following */
    u_int OutgoingMailBoxInterrupted                : 1;
    u_int IncomingMailBoxInterrupted                : 1; /* 18 */
    u_int WriteTransferCompleted                    : 1; /* 19 */
    u_int ReadTransferCompleted                     : 1;

    u_int MasterAborted                             : 1;
    u_int TargetAborted                             : 1;
    u_int Reserved3                                 : 1;
/* 	 read only */
/* 	 same as: */
/* 	     ReadTransferCompleted */
/* 	 OR WriteTransferCompleted */
/* 	 OR IncomingMailBoxInterrupted */
/* 	 OR OutgoingMailBoxInterrupted */
    u_int Interrupted                               : 1; /* 24 */

/*  the rest default to zero (NoConversion) */
    u_int EndianConversion                          : 2;
    u_int ReadFifoAdvanceByte                       : 2;
    u_int WriteFifoAdvanceByte                      : 2;
/* 	 toggles after each 32-bit load */
/* 	 if 1, EndianConversion must == Convert64Bits */
    u_int ReadFifoLoadedHigh32Of64Bits              : 1;
    /* toggles after each 32-bit load
     * if 1, EndianConversion must == Convert64Bits */
    u_int WriteFifoLoadedHigh32Of64Bits             : 1;
};

struct AmccMailBoxStatuses_register {
    /* bit is 1 if corresponding byte of corresponding mailbox
     * has been written by PCI bus, but not read by add-on bus */
    u_int OutgoingMailBox1Byte0Full     : 1;
    u_int OutgoingMailBox1Byte1Full     : 1;
    u_int OutgoingMailBox1Byte2Full     : 1;
    u_int OutgoingMailBox1Byte3Full     : 1;
    u_int OutgoingMailBox2Byte0Full     : 1;
    u_int OutgoingMailBox2Byte1Full     : 1;
    u_int OutgoingMailBox2Byte2Full     : 1;
    u_int OutgoingMailBox2Byte3Full     : 1;
    u_int OutgoingMailBox3Byte0Full     : 1;
    u_int OutgoingMailBox3Byte1Full     : 1;
    u_int OutgoingMailBox3Byte2Full     : 1;
    u_int OutgoingMailBox3Byte3Full     : 1;
    u_int OutgoingMailBox4Byte0Full     : 1;
    u_int OutgoingMailBox4Byte1Full     : 1;
    u_int OutgoingMailBox4Byte2Full     : 1;
    u_int OutgoingMailBox4Byte3Full     : 1;

/* 	 bit is 1 if corresponding byte of corresponding mailbox */
/* 	 has been written by add-on bus, but not read by PCI bus */
    u_int IncomingMailBox1Byte0Full     : 1;
    u_int IncomingMailBox1Byte1Full     : 1;
    u_int IncomingMailBox1Byte2Full     : 1;
    u_int IncomingMailBox1Byte3Full     : 1;
    u_int IncomingMailBox2Byte0Full     : 1;
    u_int IncomingMailBox2Byte1Full     : 1;
    u_int IncomingMailBox2Byte2Full     : 1;
    u_int IncomingMailBox2Byte3Full     : 1;
    u_int IncomingMailBox3Byte0Full     : 1;
    u_int IncomingMailBox3Byte1Full     : 1;
    u_int IncomingMailBox3Byte2Full     : 1;
    u_int IncomingMailBox3Byte3Full     : 1;
    u_int IncomingMailBox4Byte0Full     : 1;
    u_int IncomingMailBox4Byte1Full     : 1;
    u_int IncomingMailBox4Byte2Full     : 1;
    u_int IncomingMailBox4Byte3Full     : 1;

};


struct AmccBusMasterControlStatus_register {
    /* these are read only */
    u_int ReadFifoFull                  : 1; /* 0 */
    u_int ReadFifo4WordsEmpty           : 1;
    u_int ReadFifoEmpty                 : 1;

    u_int WriteFifoFull                 : 1; /* 3 */

    u_int WriteFifo4WordsFilled         : 1;
    u_int WriteFifoEmpty                : 1;

    u_int ReadTransferCountZero         : 1;
    u_int WriteTransferCountZero        : 1; /* 7 */

    /* legend:  read    write   behavior (0x100)
     *           vs.     vs.
     *          write   read
     *          0       0       ???undefined???
     *          0       1       write has priority
     *          1       0       read  has priority
     *          1       1       read and write alternate */
    u_int WriteVersusReadPriority       : 1; /* 8 */

    /* when 1, write FIFO must have 4 or more words (0x0200)
     * in it for matchmaker to request PCI bus
     * when 0, write FIFO must have 1 or more words
     * in it for matchmaker to request PCI bus */
    u_int WriteFifo4FilledForPciReq     : 1; /* 9 */

    /* must be 1 for PCI bus master writes to take place (0x0400)
     * can set clear to 0 to disable an active transfer
     * (when the transfer count is nonzero) */
    u_int EnableWriteTransfer           : 1;

    /* must be zero */
    u_int Reserved1                     : 1;

    /* see WriteVersusReadPriority above for legend  (0x1000) */
    u_int ReadVersusWritePriority       : 1;

    /* when 1, read FIFO must have 4 or more words
     * available for matchmaker to request PCI bus
     * when 0, read FIFO must have 1 or more words
     * available for matchmaker to request PCI bus (0x2000) */
    u_int ReadFifo4AvailableForPciReq   : 1;

    /* must be 1 for PCI bus master reads to take place
     * can set clear to 0 to disable an active transfer
     * (when the transfer count is nonzero) (0x4000) */
    u_int EnableReadTransfer            : 1;

    /* must be zero */
    u_int Reserved2                     : 1;

    u_int NvramAddressOrData            : 8; /* (0x00ff 0000) */

    /* 1 asserts reset pin of addon interface
     * 0 deasserts it                          (0x0100 0000) */
    u_int AddonResetPin                 : 1;

    /* next 3 write only */

    /* causes ReadFifoFull = 0, ReadFifoEmpty = 1 (0x0200 0000)
     * ReadFifo4WordsEmpty = 1 */
    u_int ResetReadFifoFlags            : 1;

    /* causes WriteFifoFull = 0, WriteFifoEmpty = 1 (0x0400 0000)
     * ReadFifo4WordsFilled = 0 */
    u_int ResetWriteFifoFlags           : 1;

    /* causes all mailbox flags to become 0 */
    u_int ResetMailBoxFlags             : 1;

    /* must be zero */
    u_int Reserved3                     : 1;

    /* see enum AmccNvramAccessType for opcode mnemonics */
    u_int NvramAccessType               : 2;

    /* wait for this bit to read as 0,
     * then write as 1 along with an opcode in NvramAccessType 
     * and an 8-bit value in NvramAddressOrData
     * also write this bit as 0 if you
     * don't want an nvRAM cycle to occur */
    u_int NvramBusy                     : 1;

};

/* the pci base addr 0 points to this struct in mem */
typedef struct {
    /* PCI slave accesses from host
     * can be 8, 16, or 32 bits wide */
    u_int OutgoingMailBoxes[ 4 ];

    /* PCI slave accesses from host
     * can be 8, 16, or 32 bits wide */
    u_int IncomingMailBoxes[ 4 ];

    /* cannot do a slave burst to this address
     * reading this address from host when no
     * data is available causes a hard lockup!
     * should not be accessed during bus master transfers */
    u_int Fifo;

    /* low 2 bits must be zero,
     * so the address is DWORD aligned */
    u_int MasterWriteAddress;

    /* measured in bytes
     * upper 6 bits must be zero,
     * so max value is 64 MB - 1 */
    u_int MasterWriteTransferCount;

    /* low 2 bits must be zero
     * so the address is DWORD aligned */
    u_int MasterReadAddress;

    /* measured in bytes 
     * upper 6 bits must be zero,
     * so max value is 64 MB - 1 */
    u_int MasterReadTransferCount;

    struct AmccMailBoxStatuses_register MailBoxStatuses;    /* read only */
    struct AmccInterruptControlStatus_register InterruptControlStatus;
    struct AmccBusMasterControlStatus_register BusMasterControlStatus;

} amcc_regs;

#endif /* POINT_AMCC_H */
