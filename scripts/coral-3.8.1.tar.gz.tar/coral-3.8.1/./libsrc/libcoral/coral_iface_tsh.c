/*
 * Copyright 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/* High-level functions for TSH interfaces.
 *
 *  $Id: coral_iface_tsh.c,v 1.46 2007/06/06 18:17:54 kkeys Exp $
 *
 */

#include "config.h"
#include "coraldefs.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/param.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netinet/in_systm.h>
#include <netinet/ip.h>

#include "libcoral.h"
#include "libcoral_priv.h"
#include "coral_clock.h"

static const char RCSid[] = "$Id: coral_iface_tsh.c,v 1.46 2007/06/06 18:17:54 kkeys Exp $";

/*
 * http://pma.nlanr.net/Traces/tsh.format.html
 *
 *      0                   1                   2                   3
 *      0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
 *     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *  0  |                    timestamp (seconds)                        | Time
 *     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *  1  |  interface #  |          timestamp (microseconds)             |
 *     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *  2  |Version|  IHL  |Type of Service|          Total Length         | IP
 *     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *  3  |         Identification        |Flags|      Fragment Offset    |
 *     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *  4  |  Time to Live |    Protocol   |         Header Checksum       |
 *     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *  5  |                       Source Address                          |
 *     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *  6  |                    Destination Address                        |
 *     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *  7  |          Source Port          |       Destination Port        | TCP
 *     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *  8  |                        Sequence Number                        |
 *     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *  9  |                    Acknowledgment Number                      |
 *     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *     |  Data |           |U|A|P|R|S|F|                               |
 *  10 | Offset| Reserved  |R|C|S|S|Y|I|            Window             |
 *     |       |           |G|K|H|T|N|N|                               |
 *     +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
 *
 *  IP options are always omitted.
 */

/* always big endian */
static inline void tsh_clock_order(const coral_iface_t *iface,
    const coral_timestamp_t *src, coral_timestamp_t *dst)
{
    dst->i[0] = ntohl(src->i[0]);
    dst->i[1] = ntohl(src->i[1]) & 0xFFFFFF;
}

static inline void tsh_clock_timespec(const coral_iface_t *iface,
    const coral_timestamp_t *t, struct timespec *tspec)
{
    coral_timestamp_t to;

    tsh_clock_order(iface, t, &to);
    tspec->tv_sec = to.i[0];
    tspec->tv_nsec = to.i[1] * 1000;
}

/* returns -1 for error, 1 for complete packet, 0 for no packet */
static int coral_tsh_prep_pkt(coral_iface_t *target_iface)
{
    coral_iface_t *iface[2];
    coral_tsh_record_t *cell;
    unsigned ifnum;
    const char *payload;
    const struct ip *ip;
    int hl, L4_len;
    coral_source_t *src = target_iface->src;

    iface[0] = cinst[src->id[0]];
    iface[1] = src->iface_count > 1 ? cinst[src->id[1]] : NULL;

    cell = coral_iccell(iface[0]);
    ifnum = ((char*)cell)[4];
    if (src->iface_count == 1 && ifnum == 0) {
	/* ok */
    } else if (src->iface_count == 2 && (ifnum == 1 || ifnum == 2)) {
	/* ok */
	ifnum--;
    } else {
	coral_diag(0, ("%s: bad interface number %u\n",
	    target_iface->src->filename, ifnum));
	if (coral_verbosity >= 2) {
	    coral_puts("record:\n");
	    coral_fprint_data(coral_get_errfile(), 2, (u_char*)cell,
		sizeof(coral_tsh_record_t));
	}
	errno = CORAL_EBADIFNUM;
	return -1;
    }

    if (iface[ifnum]->eof)
	return 0; /* discard data on this iface XXX? */

#if 0 /* XXX tsh packets are always truncated. */
    if (!(coral_config.flags & CORAL_OPT_PARTIAL_PKT)) {
	/* discard partial packet */
	target_iface->pkt_stats.truncated++;
	return 0;
    }
#endif

    if (iface[ifnum]->packetbuf.is_dynamic) {
	free((char*)iface[ifnum]->packetbuf.buf);
	iface[ifnum]->packetbuf.is_dynamic = 0;
    }
    payload = cell->payload;
    ip = (const struct ip*)payload;
    hl = ip->ip_hl * 4;
    if (ip->ip_v == 4 && hl >= 20) {
	L4_len = 16;
	if (hl > 20) {				/* IP options were lost */
	    char *buf = malloc(hl + 16);
	    if (!buf) return -1;
	    memcpy(buf, payload, 20);		/* copy IP header */
	    memset(buf + 20, 0, hl - 20);	/* pad IP options with 0 */
	    /* NLANR's TSH capture program reads the first 48 byte cell of
	     * each packet, which contains 8 bytes of LLC/SNAP, and 40 bytes
	     * of IP.  It writes 20 bytes of IP header, and up to 16 bytes of
	     * layer 4; but if IP options pushed part of the layer 4 beyond
	     * 40 bytes, that part of the layer 4 was lost. */
	    if (hl + 16 > 40) L4_len = 40 - hl;
	    memcpy(buf + hl, payload + 20, L4_len);/* copy layer 4 */
	    iface[ifnum]->packetbuf.is_dynamic = 1;
	    iface[ifnum]->packetbuf.buf = buf;
	} else {
	    iface[ifnum]->packetbuf.buf = payload;	/* use payload without copy */
	}
	iface[ifnum]->packetbuf.caplen = hl + L4_len;
	iface[ifnum]->packetbuf.totlen = -1;
	iface[ifnum]->packetbuf.protocol = CORAL_NETPROTO_IPv4;
    } else {
	iface[ifnum]->packetbuf.buf = payload;
	iface[ifnum]->packetbuf.caplen = 36;
	iface[ifnum]->packetbuf.totlen = -1;
	iface[ifnum]->packetbuf.protocol = CORAL_PROTO_UNKNOWN;
    }

    iface[ifnum]->pkt_stats.pkts_recv++;
    iface[ifnum]->pkt_stats.ok_packet++;

    iface[ifnum]->pkt_result.timestamp = &cell->t;
    iface[ifnum]->pkt_result.packet = &iface[ifnum]->packetbuf;
    iface[ifnum]->pkt_result.header = NULL;
    iface[ifnum]->pkt_result.trailer = NULL;

    coral_blk_prep_pkt(iface[ifnum], iface[0], tsh_clock_timespec);

    if (src->iface_count > 1) {
	if (iface[ifnum]->synced)
	    iface[0]->synced = iface[1]->synced = 1;
	/* iface[x]->ts was set by coral_tsh_read_min or coral_tsh_consume */
	iface[!ifnum]->pkt_result.packet = NULL;
    }
    return !!target_iface->pkt_result.packet;
}

static int coral_tsh_consume(coral_iface_t *target_iface, int want)
{
    coral_iface_t *iface[2];
    coral_source_t *src = target_iface->src;
    const coral_timestamp_t *ts;
    unsigned ifnum;

    iface[0] = cinst[src->id[0]];
    iface[1] = src->iface_count > 1 ? cinst[src->id[1]] : NULL;

    if (!iface[0]->u.blk.node.data)
	return 0;

    /* Move to the next cell. */
    iface[0]->u.blk.node.index++;
    if (iface[0]->u.blk.node.index < iface[0]->u.blk.node.cell_count) {
	ts = &((coral_tsh_record_t*)coral_iccell(iface[0]))->t;

	/* An illegal ifnum will be caught in prep_pkt. */
	ifnum = (ts->c[4] - (src->iface_count > 1));
	if (ifnum > src->iface_count)
	    ifnum = 0;

	/* Use next cell to update timestamp */
	src->current_iface = iface[ifnum];
	src->current_iface->have_data = 1;
	coral_set_latest_ts2(iface[ifnum], ts, tsh_clock_timespec);
	src->ts = iface[ifnum]->latest_ts;
    } else {
	/* We've reached the end of the current block. */
	coral_diag(10, (src->iface_count > 1 ?
	    "end of block on ifaces %d, %d\n" : "end of block on iface %d\n",
	    src->id[0], src->id[1]));
	/* Get next blk from queue. (Assume empty blks are not queued.) */
	iface[0]->u.blk.tail = NULL;
	iface[0]->u.blk.node.data = NULL;
	iface[0]->u.blk.node.cell_count = 0;
	return 0;
    }

    return src->current_iface->have_data && target_iface == src->current_iface;
}

/* For internal use only.  User never sees TSH "cells". */
const coral_iface_type_t coral_iface_type_tsh = {
    {
	sizeof(coral_tsh_record_t),		/* 44 */
	offsetof(coral_tsh_record_t, t),	/* 0 */
	-1,	/* offset of ATM header */
	-1,	/* offset of ATM HEC */
	offsetof(coral_tsh_record_t, payload),	/* 8 */
	-1,	/* offset of caplen */
	-1,	/* offset of totlen */
	-1	/* unused3 */
    },
    "tsh",
    CORAL_API_PKT,
    NULL, /* time_is_normal was set by coral_tsh_init */
    tsh_clock_order,
    NULL /* clock_read_double */,
    tsh_clock_timespec,
    NULL /* correct_clock */,
    NULL /* clock_native */,
    coral_tsh_consume,
    NULL /* consume_pkt */,
    coral_tsh_prep_pkt,
    NULL /* update_pkt_stats */,
    NULL /* close */,
    { { CORAL_RX, 36 }, 0, CORAL_PROTO_UNKNOWN, CORAL_PROTO_UNKNOWN, NULL }
};

