/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

#include "config.h"
#include "coraldefs.h"

static const char RCSid[] = "$Id: coral_to_pcap.c,v 1.39.4.1 2007/07/02 19:35:27 kkeys Exp $";

#ifdef HAVE_LIBPCAP

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h> /* for mkfifo */
#include <sys/wait.h> /* for waitpid */

#include <pcap.h>
#if !defined(HAVE_PCAP_OPEN_DEAD) && defined(HAVE_PCAP_INT_H)
# include <pcap-int.h>
#endif

#include "libcoral.h"
#include "libcoral_priv.h"

#ifdef HAVE_LIBZ
# include <zlib.h>
#endif

/* this part does not require HAVE_PCAP_INT_H or HAVE_PCAP_OPEN_DEAD */
int coral_rf_cb_open_pcap_dump(const char *name, const char *realname, void *vinfo)
{
    char fifoname[PATH_MAX] = "";
    int i;
    coral_rf_info_pcap_dump_t *info = vinfo;
    coral_diag(8, ("coral_rf_open_pcap_dump %s\n", name));

    info->pid = 0;
#ifdef HAVE_LIBZ
    i = strlen(name);
    if (coral_config.gzip || (i > 3 && strcmp(name + i - 3, ".gz") == 0)) {
        /* libpcap can't write gzipped files.  So, we fork a child to gzip a
	 * fifo into a file, and make libpcap write to the fifo.
         * (A more obvious implementation would use popen("gzip -c ..."), but
         * that has problems with shell metachars, race conditions, failing
         * to find gzip, and security (if e.g. this process is setuid)).
         */
        gzFile gzfile = NULL;
        pid_t pid;
        coral_tmpname(fifoname);
	if (strcmp(name, "-") == 0)
	    gzfile = gzdopen(STDOUT_FILENO, coral_gzmode(NULL));
	else
	    gzfile = gzopen(name, coral_gzmode(NULL));
        if (!gzfile) {
            coral_diag(0, ("coral_rf_cb_open_pcap_dump (%s): gzopen %s: %s\n",
                name, name, strerror(errno)));
            goto error;
        }
        if (mkfifo(fifoname, S_IRWXU) < 0) {
            coral_diag(0, ("coral_rf_cb_open_pcap_dump (%s): mkfifo %s: %s\n",
                name, fifoname, strerror(errno)));
            goto error;
        }
        coral_diag(5, ("coral_rf_cb_open_pcap_dump (%s): mkfifo %s\n", name, fifoname));
        if ((pid = fork()) < 0) {
            /* fork: error */
            coral_diag(0, ("coral_rf_cb_open_pcap_dump (%s): fork: %s\n",
                name, strerror(errno)));
            error:
                if (gzfile) gzclose(gzfile);
                unlink(fifoname);
                return -1;
        } else if (pid == 0) {
            /* fork: child */
            /* The gzfile is already open for writing, so the only way the
             * child can fail is in open(fifoname), read() or gzwrite(). */
            ssize_t nread, nwritten, offset;
            int fifo, exitval = 1;
            char buf[8192];
            if ((fifo = open(fifoname, O_RDONLY)) < 0) {
                /* can only happen if someone else messed with the fifo */
                coral_diag(0, ("coral_rf_cb_open_pcap_dump (%s): open %s: %s\n",
                    name, fifoname, strerror(errno)));
                goto childexit;
            }
            while ((nread = read(fifo, buf, sizeof(buf))) > 0) {
                offset = 0;
                while (nread > 0) {
                    nwritten = gzwrite(gzfile, buf + offset, nread);
                    if (nwritten < 0) goto childexit;
                    offset += nwritten;
                    nread -= nwritten;
                }
            }
            if (nread == 0) exitval = 0;
            childexit:
            gzclose(gzfile);
            close(fifo);
	    unlink(fifoname);
            exit(exitval);
        }
        /* parent */
        gzclose(gzfile);
	name = fifoname;
	info->pid = pid;
    }
#endif /* HAVE_LIBZ */

    info->pcap_dumper = pcap_dump_open(info->pcap, name);
    if (!info->pcap_dumper) {
        coral_diag(0, ("%s: %s\n", name, pcap_geterr(info->pcap)));
        return -1;
    }

    return 0;
}

int coral_rf_cb_close_pcap_dump(void *vinfo)
{
    int status;
    coral_rf_info_pcap_dump_t *info = vinfo;
    if (info->pcap_dumper)
	pcap_dump_close(info->pcap_dumper);
    info->pcap_dumper = NULL;
    if (info->pid != 0) {
	waitpid(info->pid, &status, 0);
	coral_diag(8, ("coral_rf_cb_close_pcap_dump (): waited for %d\n",
	    info->pid));
	info->pid = 0;
    }
    return 0;
}


#if defined(HAVE_PCAP_INT_H) || defined(HAVE_PCAP_OPEN_DEAD)

static int coral_proto_to_pcap(coral_protocol_t proto)
{
    switch(proto) {
	case CORAL_DLT_ATM_AAL5:	/* XXX fall through */
	case CORAL_DLT_ATM_RFC1483:	return DLT_ATM_RFC1483;
	case CORAL_DLT_NULL:		return DLT_NULL;
	case CORAL_DLT_ETHER:		return DLT_EN10MB;
	case CORAL_DLT_IEEE802:		return DLT_IEEE802;
	case CORAL_DLT_PPP:		return DLT_PPP;
#ifdef DLT_CHDLC
	case CORAL_DLT_CHDLC:		return DLT_CHDLC;
#endif
	case CORAL_NETPROTO_IPv4:	return DLT_RAW;
	case CORAL_NETPROTO_IPv6:	return DLT_RAW;
	case CORAL_NETPROTO_RAW_IP:	return DLT_RAW;
	case CORAL_DLT_LANE_IEEE8023:   /* fall through */
	case CORAL_DLT_LANE_IEEE8025:   /* fall through */
	case CORAL_DLT_LANE_LLC:	/* fall through */
	case CORAL_DLT_GIGX:		/* fall through */
	default:			return -1;
    }
}

pcap_t *coral_iface_to_alloced_pcapp(const coral_iface_t *iface, int raw)
{
    int dlt;
    int snaplen;

    if (iface->iface_info.iomode.flags & CORAL_RX_USER_ALL) {
	snaplen = MAX_PACKET_SIZE;
    } else {
	snaplen = iface->iface_info.iomode.first_n;
    }

    if (raw) {
	dlt = DLT_RAW;
    } else {
	dlt = coral_proto_to_pcap(iface->iface_info.datalink);
	if (dlt < 0) {
	    coral_diag(1, ("Warning: don't know pcap equivalent of %s "
	       "protocol on interface %d, will try to convert to raw IP.\n",
	       coral_proto_str(iface->iface_info.datalink), iface->id));
	    dlt = DLT_RAW;
	}
    }

#ifdef HAVE_PCAP_OPEN_DEAD /* prefered method */
    return pcap_open_dead(dlt, snaplen);
#else /* old method */
    {
	pcap_t *pcap;
	if (!(pcap = malloc(sizeof(pcap_t)))) return NULL;
	memset(pcap, 0, sizeof(*pcap));
	pcap->fd = -1;
	pcap->tzoff = iface->iface_info.tzoff;
	pcap->linktype = dlt;
	pcap->snapshot = snaplen;
	return pcap;
    }
#endif
}

pcap_t *coral_iface_to_pcapp(coral_iface_t *iface)
{
    if (!iface->user_pcap)
	iface->user_pcap = coral_iface_to_alloced_pcapp(iface, 0);
    return iface->user_pcap;
}

pcap_t *coral_iface_to_pcapp_raw(coral_iface_t *iface)
{
    if (!iface->user_pcap)
	iface->user_pcap = coral_iface_to_alloced_pcapp(iface, 1);
    return iface->user_pcap;
}

int coral_pkt_to_pcap(coral_iface_t *iface,
    const coral_timestamp_t *timestamp,
    const coral_pkt_buffer_t *pkt, pcap_t *pcap, struct pcap_pkthdr *hdr)
{
    coral_pkt_buffer_t ippkt;
    int offset = 0;

    if (pcap_datalink(pcap) != DLT_RAW) {
	int first_time = !iface->pcap_proto;
	if (!iface->pcap_proto)
	    iface->pcap_proto = coral_proto_to_pcap(iface->iface_info.datalink);
	if (iface->pcap_proto != pcap_datalink(pcap)) {
	    if (first_time)
		coral_diag(0, ("Can not convert %s (%d) packets from interface"
		    " %d to pcap interface with incompatible protocol (%d).\n",
		    coral_proto_str(iface->iface_info.datalink),
		    iface->pcap_proto, iface->id, pcap_datalink(pcap)));
	    return -1;
	}

    } else {
	/* Strip up to IPv4 or IPv6 header */
	if (coral_proto_layer(iface->iface_info.datalink) == 3) {
	    ippkt = *pkt;
	} else {
	    if (coral_get_payload_by_layer(pkt, &ippkt, 3) < 0)
		return -1;
	}
	if (ippkt.protocol != CORAL_NETPROTO_IPv4 &&
	    ippkt.protocol != CORAL_NETPROTO_IPv6 &&
	    ippkt.protocol != CORAL_NETPROTO_RAW_IP)
	{
	    return -1;
	}
	offset = ippkt.buf - pkt->buf;
	pkt = &ippkt;
    }

    if (timestamp) {
	struct timespec tspec;
	coral_clock_timespec_inline(iface, timestamp, &tspec, 1);
	hdr->ts.tv_sec = tspec.tv_sec;
	hdr->ts.tv_usec = tspec.tv_nsec / 1000;
    } else {
	hdr->ts.tv_sec = hdr->ts.tv_usec = 0;
    }
    hdr->caplen = pkt->caplen;
    hdr->len = pkt->totlen;
    return offset;
}

int coral_write_pkt_to_pcap(coral_iface_t *iface,
    const coral_timestamp_t *timestamp,
    const coral_pkt_buffer_t *pkt, pcap_t *pcap, pcap_dumper_t *pcap_dumper)
{
    int offset;
    struct pcap_pkthdr pphr;

    offset = coral_pkt_to_pcap(iface, timestamp, pkt, pcap, &pphr);
    if (offset < 0) return offset;
    pcap_dump((unsigned char*)pcap_dumper, &pphr,
	(unsigned char*)pkt->buf + offset);
    return 0;
}

int coral_pkt_filter(coral_iface_t *iface, pcap_t *pcap,
    struct bpf_program *bpfprog, const coral_pkt_buffer_t *pkt)
{
    struct pcap_pkthdr pcap_hdr;
    int offset;

    offset = coral_pkt_to_pcap(iface, NULL, pkt, pcap, &pcap_hdr);
    if (offset < 0) return 0;

    return bpf_filter(bpfprog->bf_insns, (uint8_t*)pkt->buf + offset,
	pcap_hdr.len, pcap_hdr.caplen);
}

#endif /* defined(HAVE_PCAP_INT_H) || defined(HAVE_PCAP_OPEN_DEAD) */
#endif /* HAVE_LIBPCAP */
