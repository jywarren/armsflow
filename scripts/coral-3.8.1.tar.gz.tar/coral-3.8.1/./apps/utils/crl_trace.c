/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 * crltrace.c - program to capture raw packet traces from a Coral device.
 *              (this is the primary program to do so)
 *
 * $Id: crl_trace.c,v 1.102 2007/06/06 18:17:37 kkeys Exp $
 *
 */

static const char RCSid[]="$Id: crl_trace.c,v 1.102 2007/06/06 18:17:37 kkeys Exp $";

#include "config.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>
#include <signal.h>
#include <ctype.h>
#include <time.h>
#include <sys/types.h>
#include <sys/uio.h>
#include <sys/time.h>
#include <sys/stat.h>
#include <errno.h>
#include <netinet/in.h>
#include <limits.h>

#include "libcoral.h"

#if !PATH_MAX
# define PATH_MAX 1024
#endif

enum { ST_RUN, ST_INT, ST_STOPPED, ST_ERROR };

static int state = ST_RUN;
static const char *outfile = "%s.crl";

static void quit(int arg)
{
    state = (state < ST_INT) ? ST_INT : ST_ERROR;
}

static void usage(const char *name)
{
    coral_usage(name, "[-o <outfile>] [-r] <source>...\n"
	"  -o<outfile>   write to <outfile> (default '%s')\n"
	"  -r<N>         rotate output file after every N blocks\n"
	"In <outfile>, '-' means standard output, '%%i' will be replaced with\n"
	"the rotation count, and other %% sequences will be replaced with\n"
	"strftime formatting of the current time.\n"
	"This program records ATM sources only; to record other (packet) sources,\n"
	"use crl_to_pcap.\n",
	outfile);
    fputs("\nUsage example:\n", stderr);
    fprintf(stderr, "%s -r1 -oblock-%%03i.crl -C'duration 60' -C'comment <site_name>' "
	"/dev/point0\n\n", name);
}

struct prev_if_t {
    int blks;
    struct timespec blk_end, cell_end;    /* end of last blk/cell */
    uint64_t cell_count;
} prev_if[CORAL_MAXOPEN];

int main(int argc, char *argv[])
{
    coral_writer_t *writer;
    struct timeval t1, t2, t3;
    double time1, time2, time3;
    coral_iface_t *iface;
    int ifid;
    struct timespec dts;
    uint32_t cell_count;
    int blks = 0;
    double cum_wr_time = 0;
    coral_atm_cell_t *blk;
    coral_blk_info_t *binfo;
    long duration;
    int opt, rotate = 0;


    signal(SIGINT, quit);

    coral_set_duration(duration = 0);
    coral_set_api(CORAL_API_BLOCK | CORAL_API_WRITE);
    coral_set_argv(argc, argv);

    while ((opt = getopt(argc, argv, "C:o:r:")) != -1) {
        switch (opt) {
        case 'C':
            if (coral_config_command(optarg) < 0) {
		usage(argv[0]);
                exit(-1);
	    }
            break;
        case 'o':
            outfile = strdup(optarg);
            break;
        case 'r':
            rotate = atoi(optarg);
	    if (!rotate) {
		usage(argv[0]);
                exit(-1);
	    }
            break;
        default:
            usage(argv[0]);
            exit(-1);
        }
    }

    while (optind < argc) {
        if (!coral_new_source(argv[optind]))
            exit(-1);
        optind++;
    }

    /* Don't compensate for time bugs. */
    coral_set_options(0, CORAL_OPT_RAW_TIME);

    if (coral_open_all() <= 0) {
	exit(2);
    }

    if (coral_start_all() < 0)
	exit(3);

    duration = coral_get_duration();
    if (duration > 0)
	coral_diag(1, ("collection duration set to %d s\n", duration));

    gettimeofday(&t1, 0);

    writer = rotate ? coral_write_rfopen(outfile, NULL) :
	coral_write_open(outfile);
    if (!writer) exit(4);
    coral_diag(1, ("opened output file: %s\n", coral_write_get_name(writer)));
    coral_write_set_encoding(writer, "none", 0);

    if (coral_write_init_all(writer) < 0)
	exit(5);

    while (state <= ST_STOPPED) {
	if (state == ST_INT) {
	    coral_diag(0, ("%s: interrupt, stopping\n", argv[0]));
	    state = ST_STOPPED;
	    if (coral_stop_all() < 0)
		break;
	}
	gettimeofday(&t1, 0);
	iface = coral_read_block_all(&binfo, &blk, NULL);
	if (!iface) {
	    if (errno == EINTR) continue;
	    if (errno) state = ST_ERROR;
	    break;
	}
	ifid = coral_interface_get_number(iface);
	cell_count = ntohl(binfo->cell_count);
	if (cell_count <= 0)
	    continue;

	gettimeofday(&t2, 0);

	if (coral_write_block(writer, iface, binfo, blk) < 0) {
	    state = ST_ERROR;
	    break;
	}

	gettimeofday(&t3, 0);

	/* time before blk request */
	time1 = timevaltodouble(&t1);
	/* time after we got the blk */
	time2 = timevaltodouble(&t2);
	/* time we finished writing */
	time3 = timevaltodouble(&t3);

	/* cumulative time spent in write */
	cum_wr_time += (time3 - time2);

	if (blks % 20 == 0)
	    fprintf(stderr, "%2s %4s %9s %9s %6s %6s %6s %9s %9s\n",
		"if", "blk", "wait", "write", "errors", "count", "lost",
		"blk gap", "cell gap");

	fprintf(stderr, "%2d %4d %9.6f %9.6f %6d %6" PRIu32 " %6" PRIu32,
		ifid,
		prev_if[ifid].blks,
		time2 - time1,
		time3 - time2, 
		binfo->pad1[0],
		cell_count, 
		(uint32_t)ntohl(binfo->cells_lost));

	/* gap between end of last blk and beginning of this one */
	if (prev_if[ifid].blks > 0) {
	    dts.tv_sec = ntohl(binfo->tbegin.tv_sec);
	    dts.tv_nsec = ntohl(binfo->tbegin.tv_nsec);
	    timespecsub(&dts, &prev_if[ifid].blk_end);
	    fprintf(stderr, " %9.6f", timespectodouble(&dts));
	}
	prev_if[ifid].blk_end.tv_sec = ntohl(binfo->tend.tv_sec);
	prev_if[ifid].blk_end.tv_nsec = ntohl(binfo->tend.tv_nsec);

	if (cell_count > 0) {
	    /* gap between last cell of last blk and first cell of this one */
	    if (prev_if[ifid].blks > 0) {
		CORAL_TIMESTAMP_TO_TIMESPEC(iface,
		    coral_cell_time(iface, (char*)blk),
		    &dts);
		timespecsub(&dts, &prev_if[ifid].cell_end);
		fprintf(stderr, " %9.6f", timespectodouble(&dts));
	    }
	    CORAL_TIMESTAMP_TO_TIMESPEC(iface,
		coral_cell_time(iface,
		    (char*)blk + (cell_count-1) * coral_cell_size(iface)),
		&prev_if[ifid].cell_end);
	}

	fprintf(stderr, "\n");
	blks++;
	prev_if[ifid].blks++;
	prev_if[ifid].cell_count += cell_count;

	if (rotate && (blks % rotate == 0)) {
	    coral_write_end(writer);
	    coral_rotate_errfile(NULL);
	}
    }

    fprintf(stderr, "\n------------------------------------------------\n");
    for (ifid = 0; ifid < CORAL_MAXOPEN; ifid++) {
	if (prev_if[ifid].blks) {
	    fprintf(stderr, "interface %d: %8d blocks, %15" PRIu64 " cells\n",
		ifid, prev_if[ifid].blks, prev_if[ifid].cell_count);
	}
    }
    if (cum_wr_time > 0)
        fprintf(stderr, "\navg write speed: %f blk/s\n", blks / cum_wr_time);
    fprintf(stderr, "------------------------------------------------\n");

    coral_stop_all();
    /*coral_stats_all();*/

    fprintf(stderr, "closing output file\n");
    coral_write_close(writer);

    coral_close_all();

    if (state == ST_INT) {
	fprintf(stderr, "terminated by signal\n");
    } else if (state == ST_ERROR) {
	fprintf(stderr, "terminated by error\n");
	exit(-1);
    }
    coral_diag(2, (".... done ....\n"));

    return(0);
}
