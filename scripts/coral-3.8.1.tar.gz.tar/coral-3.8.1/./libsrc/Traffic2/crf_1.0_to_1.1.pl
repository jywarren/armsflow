use strict;

my $pseudointerval;

while (<>) {
    if (/version: (.*) \(/) {
	die "This converter only works on version 1.0 files." if $1 != 1.0;
	s/1\.0/1\.1/;
    } elsif (/bogus interval/ or /pseudo-interval/) {
	$pseudointerval = 1;
    } elsif (/Tuple Table/) {
	if ($pseudointerval) {
	    s/Tuple Table/Tuple Table (active)/g;
	} else {
	    s/Tuple Table/Tuple Table (expired)/g;
	}
    }
    print unless /# expired flows\n/ or /# active flows\n/;
}
