/*
 * Copyright (c) 1999, 2000 The University of Waikato, Hamilton, New Zealand.
 * All rights reserved.
 *
 * This code is derived from software contributed to CAIDA
 * by the University of Waikato WAND research group.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 * 3. All advertising materials mentioning features or use of this software
 *    must display the following acknowledgement:
 *      This product includes software developed by the University of
 *      Waikato, Hamilton, NZ, and its contributors.
 * 4. Neither the name of the University nor the names of its contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE UNIVERSITY AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE UNIVERSITY OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

#include "config.h"
#include "coraldefs.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <assert.h>
#include <time.h>

#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/wait.h>
#include <errno.h>
#ifdef HAVE_SYS_IOCCOM_H
#include <sys/ioccom.h>
#endif
#include <sys/ioctl.h>
#include <sys/mman.h>

#include "drivers/coral_ioctl.h"
#include "libcoral.h"
#include "libcoral_priv.h"

#ifdef HAVE_DAGAPI

static const char RCSid[] = "$Id: coral_type_dag.c,v 1.53 2007/06/05 23:41:55 kkeys Exp $";

#include "coral_dag.h"

#include "dagnew.h"
#include "dagapi.h"

static int
coral_dag_init(coral_source_t *src)
{
    char params[256];
    char *p;
    int ifcount = 1;
    uint32_t bw = 0;
    coral_protocol_t phy = CORAL_PROTO_UNKNOWN, dlt = CORAL_PROTO_UNKNOWN;
    coral_iface_t *iface0 = cinst[src->id[0]];

    if ((src->fd = dag_open(src->filename)) < 0) {
	coral_diag(0, ("coral_open: %s: %s\n", src->filename, strerror(errno)));
	return -1;
    }
    coral_diag(4, ("coral_open: %s: fd %d\n", src->filename, src->fd));

#ifdef DAG_IOGETSPEED
{
    int dagspeed;
    /* dag api doesn't support querying phy and bw, so we must use ioctl */
    if (ioctl(src->fd, DAG_IOGETSPEED, &dagspeed) < 0) {
	coral_diag(0, ("coral_open: unable to determine configuration of %s"
	    " (DAG_IOGETSPEED: %s)\n", src->filename, strerror(errno)));
    } else {
	switch (dagspeed) {
        case OC3c_ATM:   phy = CORAL_PHY_ATM;    bw = KBPS_OC3c;     break;
        case OC12c_ATM:  phy = CORAL_PHY_ATM;    bw = KBPS_OC12c;    break;
        case OC48c_ATM:  phy = CORAL_PHY_ATM;    bw = KBPS_OC48c;    break;
        case OC3c_POS:   phy = CORAL_PHY_POS;    bw = KBPS_OC3c;     break;
        case OC12c_POS:  phy = CORAL_PHY_POS;    bw = KBPS_OC12c;    break;
        case OC48c_POS:  phy = CORAL_PHY_POS;    bw = KBPS_OC48c;    break;
        case ETH_10:     dlt = CORAL_DLT_ETHER;  bw = KBPS_ETH10M;   break;
        case ETH_100:    dlt = CORAL_DLT_ETHER;  bw = KBPS_ETH100M;  break;
        case ETH_1000:   dlt = CORAL_DLT_ETHER;  bw = KBPS_ETH1000M; break;
        case DS3:
        case E3:
	default:         break;
	}
	coral_diag(5, ("coral_dag_init: %s is configured for %s %s %s (dagspeed=%d)\n",
	    src->filename, coral_bandwidth_fmt(bw), coral_proto_str(phy),
	    coral_proto_str(dlt), dagspeed));
    }
}
#endif /* DAG_IOGETSPEED */

    if (src->dev_config.physical == CORAL_PROTO_UNKNOWN) {
	src->dev_config.physical = phy;
    } else if (phy != CORAL_PROTO_UNKNOWN && src->dev_config.physical != phy) {
	coral_diag(0, ("coral: %s: specified physical type (%s) "
	    "does not agree with device (%s)\n",
	    src->filename, coral_proto_str(src->dev_config.physical),
	    coral_proto_str(phy)));
	return -1;
    }

    if (src->dev_config.datalink == CORAL_PROTO_UNKNOWN) {
	src->dev_config.datalink = dlt;
    } else if (dlt != CORAL_PROTO_UNKNOWN && src->dev_config.datalink != dlt) {
	coral_diag(0, ("coral: %s: specified datalink type (%s) "
	    "does not agree with device (%s)\n",
	    src->filename, coral_proto_str(src->dev_config.datalink),
	    coral_proto_str(dlt)));
	return -1;
    }

    if (src->dev_config.bandwidth <= 0) {
	src->dev_config.bandwidth = bw;
    } else if (bw != 0 && src->dev_config.bandwidth != bw) {
	coral_diag(0, ("coral: %s: unsupported bandwidth: %s\n",
	    src->filename, coral_bandwidth_fmt(src->dev_config.bandwidth)));
	return -1;
    }

    iface0->iface_type = &coral_iface_type_dag_erf_varlen;

    if (src->dev_config.physical == CORAL_PHY_POS) {
	coral_cell_field_offset(iface0, PAYLOAD) =
	    sizeof(coral_dag_erf_hdr_t);
	/* DAG doesn't care about the HDLC layer; it works just as
	 * well on POS with any datalink type.  So if the user specified a
	 * datalink type, we use it, but if not we default to CHDLC. */
	if (src->dev_config.datalink == CORAL_PROTO_UNKNOWN)
	    src->dev_config.datalink = CORAL_DLT_CHDLC;

    } else if (src->dev_config.datalink == CORAL_DLT_ETHER) {
	ifcount = 2;
	coral_cell_field_offset(iface0, PAYLOAD) = 18;
	    /* NB: sizeof(coral_dag_erf_ether_hdr_t) is padded */
	src->dev_config.physical = CORAL_PROTO_UNKNOWN;

    } else if (src->dev_config.datalink == CORAL_DLT_ATM_AAL5) {
	coral_cell_field_offset(iface0, HEADER) = sizeof(coral_dag_erf_hdr_t);
	coral_cell_field_offset(iface0, PAYLOAD) =
	    sizeof(coral_dag_erf_hdr_t) + sizeof(union atm_hdr);
	src->dev_config.physical = CORAL_PHY_ATM;
	src->dev_config.datalink = CORAL_DLT_ATM_RFC1483;
	coral_init_atm_iface(iface0);

    } else if (src->dev_config.physical == CORAL_PHY_ATM) {
#if 1
	coral_cell_field_offset(iface0, HEADER) = sizeof(coral_dag_erf_hdr_t);
	coral_cell_field_offset(iface0, PAYLOAD) =
	    sizeof(coral_dag_erf_hdr_t) + sizeof(union atm_hdr);
	/* user must specify dlt and first_n */
	iface0->iface_type = &coral_iface_type_dag_erf_atm;
	coral_init_atm_iface(iface0);
#else
	coral_diag(0, ("coral: %s: ERF ATM is not implemented.\n",
	    src->filename));
	errno = CORAL_ENOPROTO;
	return -1;
#endif

    } else {
	/* It would be nice to read the first record and get phy/proto
	 * from its header.  But we can't read the first record until
	 * we dag_configure, and we need to know phy/proto to call
	 * dag_configure. */
	coral_diag(0, ("coral: %s: unknown DAG configuration.  "
	    "You must specify iomode phy and/or proto.\n",
	    src->filename));
	errno = CORAL_ENOPROTO;
	return -1;
    }

    iface0->iface_type = objdup(iface0->iface_type);

    if (coral_dag_common_init(src, ifcount, 1) < 0)
	return -1;

    /* cinst[id]->iface_info.fw_type       = 0x19671001; */ /* XXX ? */

    p = params;
    if (src->dev_config.physical == CORAL_PHY_ATM) {
	p += sprintf(p, "ncells=%d",
	    src->dev_config.iomode.first_n / ATM_PAYLOAD_SIZE);
	if (src->dev_config.iomode.flags & CORAL_RX_LAST)
	    p += sprintf(p, " lcell");
    } else {
	p += sprintf(p, "slen=%d %svarlen",
	    src->dev_config.iomode.first_n,
	    (src->dev_config.iomode.flags & CORAL_RX_VARLEN) ? "" : "no");
    }
    coral_diag(2, ("coral: dag_configure %s %s\n", src->filename, params));
    if (dag_configure(src->fd, params) < 0) {
	coral_diag(0, ("coral: dag_configure %s: %s\n",
	    src->filename, strerror(errno)));
	return -1;
    }

    src->ubase = dag_mmap(src->fd);
    if (src->ubase == MAP_FAILED) {
	src->ubase = NULL;
	return -1;
    }
    iface0->u.vblk.current = iface0->u.vblk.block = src->ubase;

#define DAG_POLLTIME 500000
    if (!coral_config.user_polltime && (coral_config.polltime == 0 ||
	coral_config.polltime > DAG_POLLTIME))
    {
	coral_config.polltime = DAG_POLLTIME;
    }
    return 0;
}

static int coral_dag_read(coral_source_t *src)
{
    coral_iface_t *iface0;
    int oldstart, oldend, start, i;

    iface0 = cinst[src->id[0]];
    if (src->pktq_head) {
	start = src->pktq_head->rec - iface0->u.vblk.block;
    } else {
	start = iface0->u.vblk.current - iface0->u.vblk.block;
    }
    oldstart = start;
    oldend = iface0->u.vblk.end;

    coral_diag(19, ("read: q=%x, cur=+%x, oldoff=+%x; ",
	src->pktq_size, iface0->u.vblk.current - iface0->u.vblk.block, start));
    /* dag_offset() never returns failure */
    iface0->u.vblk.end = dag_offset(src->fd, &start, DAGF_NONBLOCK);
    coral_diag(19, ("end=+%x, newoff=+%x\n",
	iface0->u.vblk.end, start));
    /* If size decreased, it's because dag_offset switched from the second
     * to the first mmapped region, and we must also remap current.  The
     * change in start tells us exactly much to change current. */
    if (iface0->u.vblk.end < oldend)
	iface0->u.vblk.current += start - oldstart;

    assert(iface0->u.vblk.current >= iface0->u.vblk.block);
    if (iface0->u.vblk.block + iface0->u.vblk.end == iface0->u.vblk.current) {
	/* didn't read anything */
	if (!src->started) {
	    /* card is stopped, we'll never get anything else from it */
	    coral_mark_eof_src(src);
#if 1
	    /* coral_mark_eof_src doesn't mark every iface EOF because it knows
	     * that for a non-interleaved src there may be more valid pkts after
	     * duration expires.  So we must explicitly mark each iface here. */
	    for (i = 0; i < src->iface_count; i++) {
		coral_mark_eof(cinst[src->id[i]]);
	    }
#endif
	    errno = 0;
	} else {
	    /* card is still running, we may get more data later */
	    errno = EAGAIN;
	}
	return 0;
    }
    return 1;
}

static int coral_dag_start(coral_source_t *src)
{
    return dag_start(src->fd);
}

static int coral_dag_stop(coral_source_t *src)
{
    if (dag_stop(src->fd) < 0)
	return -1;
    return coral_mark_eof_src(src);
}

#endif /* HAVE_DAGAPI */

const coral_src_type_t coral_src_type_dag = {
    CORAL_TYPE_DAG,
    "dag",
#ifdef HAVE_DAGAPI
    1 /* is_live */,
    0 /* is_buffered */,
    0 /* is_block */,
    0 /* is_interleaved */,
    coral_dag_init,
    coral_dag_start,
    coral_dag_read,
    coral_dagerf_read_any,
    coral_dagerf_read_iface,
    NULL /* nextblk */,
    NULL /* release */,
    coral_dag_stop,
    NULL /* coral_dag_close */
#endif /* HAVE_DAGAPI */
};
