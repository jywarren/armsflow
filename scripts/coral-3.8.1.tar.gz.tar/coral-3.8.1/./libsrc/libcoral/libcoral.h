/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

#ifndef LIBCORAL_H
#define LIBCORAL_H
/*
 * libcoral.h - unified interface to the CORAL devices and Coral tracefiles.
 *
 * $Id: libcoral.h,v 1.210.4.1 2007/07/02 19:35:27 kkeys Exp $
 *
 * Trace file structure:
 *   coral_file_header_t
 *   array of iface_info_count iface_info_t's
 *   array of filter_rule_count filter_rule_t's
 *   padding to multiple of 512 bytes
 *   array of any number of data blocks
 *
 * Data block structure:
 *   coral_blk_info_t
 *   array of records (e.g., atm cell records)
 */

#ifdef __cplusplus
extern "C" {
#endif

#include <errno.h>
#include "caida_t.h"
#include "drivers/coral_global.h"
#include "libcoral_const.h"

/* Types that aren't Coral Devices (not in drivers/coral_ioctl_const.h) */
#define CORAL_TYPE_PCAP		(-1)	/* pcap file */
#define CORAL_TYPE_PCAPLIVE	(-2)	/* pcap live interface */
#define CORAL_TYPE_DAGFILE	(-3)	/* dag file: fixed record size/legacy */
#define CORAL_TYPE_TSH		(-4)	/* tsh file */
#define CORAL_TYPE_OPTISTAR	(-5)	/* Lucent OptiStar adapter */
#define CORAL_TYPE_CRL		(-6)	/* crl file or device */

/* opaque object types */
typedef struct coral_source	coral_source_t;
typedef struct coral_iface	coral_iface_t;
typedef struct coral_iface_type coral_iface_type_t;
typedef struct coral_writer	coral_writer_t;
typedef struct coral_anon       coral_anon_t;

/* protocol numbers */
#define coral_mkproto(layer, id)	((layer << 28) | (id & 0x0FFFFFFF))
typedef enum {
# define defproto(layer, prefix, abbr, proto_ok, id, desc) \
	CORAL_##prefix##_##abbr = ((layer << 28) | id),
# include "coral_proto.h"
	CORAL_PROTO_ILLEGAL = coral_mkproto(0, -1)
} coral_protocol_t;

/* Solaris crap */
#ifndef IP_OFFMASK
#define IP_OFFMASK 0x1FFF
#endif

#include "coral_clock.h"	    /* macros to access timestamps */
#include "coral_atm_rfc1483.h"	    /* ATM, AAL5, RFC1483 data structures */
#include "coral_pkt.h"		    /* packet data structures */

const char *coral_strerror(void *data, int err); /* never returns NULL */

int coral_config_options(int argc, char *argv[], const char *argsyntax);
int coral_config_arguments(int argc, char *argv[]);

void coral_usage(const char *appname, const char *argsyntax, ...);

int coral_config_file(const char *filename);

int coral_config_command(const char *command);

void coral_config_defaults(void);

int coral_set_api(int api);

void coral_set_argv(int argc, char *argv[]);

int coral_set_max_sources(int n);
int coral_get_max_sources(void);

int coral_set_options(int off, int on);
int coral_get_options(void);

FILE *coral_get_errfile(void);
int coral_set_errfile(FILE *file);
int coral_set_errfilename(const char *filename);

int coral_set_verbosity(int verbosity);
int coral_get_verbosity(void);

int coral_set_comment(const char *comment);
const char *coral_get_comment(void);

int coral_set_duration(long duration);
long coral_get_duration(void);

int coral_set_interval(const struct timeval *interval);
int coral_get_interval(struct timeval *interval);

int coral_set_mintime(const struct timeval *mintime);
int coral_get_mintime(struct timeval *mintime);

int coral_set_maxtime(const struct timeval *maxtime);
int coral_get_maxtime(struct timeval *maxtime);

int coral_set_max_pkts(uint64_t n);
int coral_set_max_blks(uint64_t n);
int coral_set_max_cells(uint64_t n);

uint64_t coral_get_max_pkts(void);
uint64_t coral_get_max_blks(void);
uint64_t coral_get_max_cells(void);

int coral_set_gzip(const char *str);

int coral_get_source_count(void);

char *coral_filename(const char *str, char *dst, size_t len);
char *coral_tfilename(const char *str, char *dst, size_t len,
    const struct timeval *tvp, int i);

typedef struct tm coral_struct_tm; /* prevents declaration of struct tm in
				    coral_strftime parameter list if sys/time.h
				    wasn't included */
size_t coral_strftime(char *buf, size_t maxsize, const char *fmt,
    const struct timeval *tv, struct tm *tm, ...);


typedef struct coral_rotfile { /* should be opaque */
    char *name;
    char *tempname;
    char *safety;
    const char *basename;
    int i;
    char rotatable;
    char started;
    uint8_t flags;
    void *info;
    int (*open)(const char *name, const char *realname, void *info);
    int (*close)(void *info);
    struct coral_rotfile *next;
} coral_rotfile_t;

typedef struct {
    const char *gzmode; /* XXX should be char[8]? */
    void *gzfile;
} coral_rf_info_gz_t;

typedef struct {
    FILE *file;
    const char *gzmode; /* XXX should be char[8]? */
    void *gzfile;
} coral_rf_info_ogz_t;

coral_rotfile_t *coral_rf_open(void *info,
    const char *path, const char *temp, int flags,
    int (*rfopen)(const char *name, const char *realname, void *info),
    int (*rfclose)(void *info));
coral_rotfile_t *coral_rf_open_fd(int *fdp,
    const char *path, const char *temp, int flags);
coral_rotfile_t *coral_rf_open_file(FILE **filep,
    const char *path, const char *temp, int flags);
coral_rotfile_t *coral_rf_open_gzfile(coral_rf_info_gz_t *fp,
    const char *path, const char *temp, int flags);
coral_rotfile_t *coral_rf_open_ogzfile(coral_rf_info_ogz_t *fp,
    const char *path, const char *temp, int flags);
coral_rotfile_t *coral_rf_open_pcap_dump(void *fp,
    const char *path, const char *temp, int flags);
int coral_rf_start(coral_rotfile_t *rf, const struct timeval *tvp);
int coral_rf_end(coral_rotfile_t *rf);
int coral_rf_close(coral_rotfile_t *rf);
int coral_rotate_errfile(const struct timeval *tv);

int coral_rf_cb_open_fd(const char *name, const char *realname, void *vinfo);
int coral_rf_cb_close_fd(void *vinfo);

int coral_rf_cb_open_file(const char *name, const char *realname, void *vinfo);
int coral_rf_cb_close_file(void *vinfo);

int coral_rf_cb_open_gzfile(const char *name, const char *realname, void *vinfo);
int coral_rf_cb_close_gzfile(void *vinfo);

int coral_rf_cb_open_ogzfile(const char *name, const char *realname, void *vinfo);
int coral_rf_cb_close_ogzfile(void *vinfo);

int coral_rf_cb_open_pcap_dump(const char *name, const char *realname, void *vinfo);
int coral_rf_cb_close_pcap_dump(void *vinfo);

#define coral_rf_info(rf) ((rf)->info)

int coral_rf_ogz_write(coral_rf_info_ogz_t *info, const void *buf, size_t len);
int coral_rf_ogz_seek(coral_rf_info_ogz_t *info, long offset, int whence);
int coral_rf_ogz_flush(coral_rf_info_ogz_t *info);


coral_source_t *coral_new_source(const char *filename);
coral_source_t *coral_new_fdsource(int fd, const char *name);

int coral_set_iomode(int off, int on, int first, int fixed);
int coral_source_set_iomode(coral_source_t *src, int off, int on, int first);
int coral_source_set_iomode_all(int off, int on, int first);
const coral_io_mode_t *coral_get_iomode(void);
const coral_io_mode_t *coral_source_get_iomode(const coral_source_t *src);
const coral_io_mode_t *coral_iface_get_iomode(const coral_iface_t *iface);
int coral_format_iomode(char *buffer, const coral_io_mode_t *iomode);
#define CORAL_FORMAT_IOMODE_LEN	64
#define coral_iomode_t coral_io_mode_t

int coral_source_set_firmware(coral_source_t *src, const char *firmware);
int coral_source_set_firmware_all(const char *firmware);
int coral_source_set_special_firmware(coral_source_t *src,
    const char *which, const char *name);
int coral_source_set_special_firmware_all(const char *which, const char *name);


/* The basic API */

int coral_open_all(void);
int coral_open(coral_source_t *src);

int coral_start_all(void);
int coral_start(coral_source_t *src);

coral_iface_t *coral_read_block(coral_source_t *src, coral_blk_info_t **binfop,
    coral_atm_cell_t **cellp, struct timeval *timeout);
coral_iface_t *coral_read_block_endonly(coral_source_t *src,
    coral_blk_info_t **binfop,
    coral_atm_cell_t **cellp, struct timeval *timeout);
coral_iface_t *coral_read_block_all(coral_blk_info_t **binfop,
    coral_atm_cell_t **cellp, struct timeval *timeout);

coral_iface_t *coral_read_cell(coral_source_t *src, coral_blk_info_t **binfop,
    coral_atm_cell_t **cellp, struct timeval *timeout);
coral_iface_t *coral_read_cell_i(coral_source_t *src, coral_blk_info_t **binfop,
    coral_atm_cell_t **cellp,
    coral_interval_result_t *int_result, struct timeval *interval);

coral_iface_t *coral_read_cell_all(coral_blk_info_t **binfop,
    coral_atm_cell_t **cellp, struct timeval *timeout);
coral_iface_t *coral_read_cell_all_i(coral_blk_info_t **binfop,
    coral_atm_cell_t **cellp,
    coral_interval_result_t *int_result, struct timeval *interval);

extern void (*coral_cell_block_hook)(const coral_iface_t *iface,
    const coral_blk_info_t *binfo);

/* get ith cell of blk, which was read from iface */
#define coral_nth_cell(iface, blk, i)  \
    ((coral_atm_cell_t*)((char*)(blk) + (i) * coral_cell_size(iface)))


/* ? */
int coral_sendblk(coral_source_t *src, int ndesc);

int coral_stop_all(void);
int coral_stop(coral_source_t *src);

int coral_close_all(void);
int coral_close(coral_source_t *src);

int coral_inet_pton(int af, const char *src, void *dst);

#define CORAL_FMT_SUBIF_LEN	(11+1)
#define CORAL_FMT_IF_SUBIF_LEN	(11+2+2+1)
int coral_fmt_if_subif(char *buf, const coral_iface_t *iface, uint32_t subif);
int coral_fmt_subif(char *buf, const coral_iface_t *iface, uint32_t subif);
int coral_printf(const char *fmt, ...);
int coral_puts(const char *str);

#define coral_diag(level, args) \
    do { \
	if ((level) <= coral_verbosity) \
	    coral_printf args; \
    } while (0)

extern int coral_verbosity;	/* needs to be global so coral_diag can use it */


coral_source_t *coral_next_source(const coral_source_t *src);
coral_iface_t *coral_next_interface(const coral_iface_t *iface);
coral_iface_t *coral_next_src_iface(const coral_source_t *src,
    const coral_iface_t *iface);

int coral_interface_get_type(const coral_iface_t *iface);
#define coral_iface_get_type coral_interface_get_type
int coral_source_get_type(const coral_source_t *src);
int coral_source_is_block(const coral_source_t *src);

coral_protocol_t coral_interface_get_datalink(const coral_iface_t *iface);
#define coral_iface_get_datalink coral_interface_get_datalink
coral_protocol_t coral_interface_get_physical(const coral_iface_t *iface);
#define coral_iface_get_physical coral_interface_get_physical
int32_t coral_interface_get_bandwidth(const coral_iface_t *iface);
#define coral_iface_get_bandwidth coral_interface_get_bandwidth

time_t coral_interface_get_capturetime(const coral_iface_t *iface);
#define coral_iface_get_capturetime coral_interface_get_capturetime
const struct timeval *coral_interface_get_capture_tv(const coral_iface_t *iface);
#define coral_iface_get_capturetv coral_interface_get_capturetv

void coral_dump(const coral_source_t *src);
void coral_dump_all(void);

void coral_stats(const coral_source_t *src);
void coral_stats_all(void);

#define coral_fwrite_binint(file, p) \
    coral_fwrite_binint_func(file, (p), sizeof(*(p)))
#define coral_fread_binint(file, p) \
    coral_fread_binint_func(file, (p), sizeof(*(p)))

size_t coral_fwrite_binint_func(FILE *file, const void *p, size_t size);
size_t coral_fread_binint_func(FILE *file, void *p, size_t size);

void (coral_print_data)(int indent, const u_char *data, int len);
#define coral_print_data(indent, data, len) \
    coral_fprint_data(stdout, indent, data, len)
void coral_fprint_data(FILE *file, int indent, const u_char *data, int len);
void (coral_print_cell)(int indent, coral_iface_t *iface,
    const coral_atm_cell_t *cell);
#define coral_print_cell(indent, iface, cell) \
    coral_fprint_cell(stdout, indent, iface, cell)
void coral_fprint_cell(FILE *file, int indent, coral_iface_t *iface,
    const coral_atm_cell_t *cell);
void (coral_print_pkt)(coral_iface_t *iface, const coral_timestamp_t *timestamp,
    void *layerp, coral_pkt_buffer_t *packet,
    coral_pkt_buffer_t *header, coral_pkt_buffer_t *trailer);
#define coral_print_pkt(iface, ts, layerp, pkt, head, trail) \
    coral_fmprint_pkt(stdout, iface, ts, 1, ((int*)layerp)[0], pkt, head, trail)
void (coral_fprint_pkt)(FILE *file, coral_iface_t *iface,
    const coral_timestamp_t *timestamp, int layer,
    coral_pkt_buffer_t *packet,
    coral_pkt_buffer_t *header, coral_pkt_buffer_t *trailer);
#define coral_fprint_pkt(file, iface, ts, maxlayer, packet, header, trailer) \
    coral_fmprint_pkt(file, iface, ts, 1, maxlayer, packet, header, trailer)
void coral_mprint_pkt(coral_iface_t *iface, const coral_timestamp_t *timestamp,
    void *layerp, coral_pkt_buffer_t *packet,
    coral_pkt_buffer_t *header, coral_pkt_buffer_t *trailer);
void coral_fmprint_pkt(FILE *file, coral_iface_t *iface,
    const coral_timestamp_t *timestamp, int minlayer, int maxlayer,
    coral_pkt_buffer_t *packet,
    coral_pkt_buffer_t *header, coral_pkt_buffer_t *trailer);

const char *coral_file_version(const coral_source_t *src);
coral_protocol_t coral_proto_id(const char *abbr);
const char *coral_proto_str(coral_protocol_t protocol);
const char *coral_proto_abbr(coral_protocol_t protocol);
const char *coral_proto_desc(coral_protocol_t protocol);
#define coral_dlt_str	    coral_proto_str
#define coral_netproto_str  coral_proto_str
uint8_t coral_dns_str_to_op(const char *str);
uint16_t coral_dns_str_to_qtype(const char *str);
uint16_t coral_dns_str_to_qclass(const char *str);
const char *coral_dns_op_label(uint8_t op);
const char *coral_dns_qtype_label(uint16_t qtype);
const char *coral_dns_qclass_label(uint16_t qclass);
const char *coral_dns_rcode_label(uint16_t rcode);
const char *coral_dns_op_to_str(uint8_t op);
const char *coral_dns_qtype_to_str(uint16_t qtype);
const char *coral_dns_qclass_to_str(uint16_t qclass);

char *coral_base(coral_source_t *src);
size_t coral_msize(coral_source_t *src);



/* The Write API */

coral_writer_t *coral_write_open(const char *name);
coral_writer_t *coral_write_fdopen(int fd);
coral_writer_t *coral_write_rfopen(const char *name, const char *temp);
int coral_write_start(coral_writer_t *writer, const struct timeval *tvp);
int coral_write_end(coral_writer_t *writer);
int coral_write_close(coral_writer_t *writer);

const char *coral_write_get_name(coral_writer_t *writer);
int coral_write_set_encoding(coral_writer_t *writer, const char *name,
    unsigned version);
int coral_write_set_comment(coral_writer_t *writer, const char *comment);

int coral_write_init_all(coral_writer_t *writer);
int coral_write_init_source(coral_writer_t *writer, coral_source_t *src);
int coral_write_init_interface(coral_writer_t *writer, coral_iface_t *iface);

int coral_write_cells(coral_writer_t *writer, const coral_iface_t *iface,
    const coral_atm_cell_t *cell, int count);
int coral_write_block(coral_writer_t *writer, const coral_iface_t *iface,
    const coral_blk_info_t *binfo, const coral_atm_cell_t *blk);

const char *coral_get_pcap_filter(void);
const char *coral_get_pcap_prefilter(void);
const char *coral_get_pcap_ipfilter(void);
int coral_add_pcap_filter(const char *expr);
int coral_add_pcap_prefilter(const char *expr);
int coral_add_pcap_ipfilter(const char *expr);
#ifdef PCAP_VERSION_MAJOR   /* <pcap.h> was included */
pcap_t *coral_iface_to_pcapp(coral_iface_t *iface);
pcap_t *coral_iface_to_pcapp_raw(coral_iface_t *iface);
int coral_pkt_to_pcap(coral_iface_t *iface,
    const coral_timestamp_t *timestamp, const coral_pkt_buffer_t *pkt,
    pcap_t *pcap, struct pcap_pkthdr *hdr);
int coral_write_pkt_to_pcap(coral_iface_t *iface,
    const coral_timestamp_t *timestamp, const coral_pkt_buffer_t *pkt,
    pcap_t *pcap, pcap_dumper_t *pcap_dumper);
int coral_pcap_compile(coral_iface_t *iface, struct bpf_program *fp,
    char *str, int optimize, uint32_t netmask);
int coral_pcap_compile_raw(coral_iface_t *iface, struct bpf_program *fp,
    char *str, int optimize, uint32_t netmask);
int coral_pcap_setfilter(coral_iface_t *iface, struct bpf_program *fp);
int coral_pcap_setprefilter(coral_iface_t *iface, struct bpf_program *fp);
int coral_pcap_setipfilter(coral_iface_t *iface, struct bpf_program *fp);

typedef struct {
    pcap_dumper_t *pcap_dumper;
    pcap_t *pcap;
    pid_t pid;
} coral_rf_info_pcap_dump_t; /* for coral_rf_{open,close}_pcap_dump */
#endif

/* The Layer 2 Packet API */

char *coral_fd(coral_source_t *src);
int coral_pkt_select(int nfds, fd_set *readfds, fd_set *writefds,
    fd_set *exceptfds, struct timeval *timeout);

int coral_read_pkt_init(coral_source_t *src, coral_iface_t *iface,
    struct timeval * interval);
extern coral_iface_t *(*coral_read_pkt)(coral_pkt_result_t *pkt_result,
    coral_interval_result_t *interval_result);
const coral_pkt_stats_t *coral_get_iface_stats(coral_iface_t *iface);

/* programmer writes these */
typedef void (*coral_pre_interval_handler)(coral_iface_t *,
    const struct timeval *, void *);
typedef void (*coral_post_interval_handler)(coral_iface_t *,
    const struct timeval *, const struct timeval *,
    void *, const coral_pkt_stats_t *);
typedef void (*coral_pkt_handler)(coral_iface_t *, const coral_timestamp_t *,
    void *, coral_pkt_buffer_t *, coral_pkt_buffer_t *, coral_pkt_buffer_t *);

/* libcoral provides this, programmer calls it. */
int coral_read_pkts(coral_source_t *src, coral_iface_t *iface,
			coral_pkt_handler pkthandler,
			coral_pre_interval_handler preinthandler,
			coral_post_interval_handler postinthandler,
			struct timeval * interval,
			void *parameter);

extern volatile int coral_pkt_done;
extern int (*coral_pkt_atm_hook)(const coral_iface_t *iface,
    const coral_pkt_buffer_t *packet, const coral_atm_cell_t *cell);

int coral_proto_rule(const coral_iface_t *iface, uint32_t subif,
    coral_protocol_t *protop);
int coral_set_proto_rule(coral_source_t *src, coral_iface_t *iface, int op,
    uint32_t subif, uint32_t subifmask, coral_protocol_t proto);
void coral_delete_proto_rules(coral_source_t *src, coral_iface_t *iface);
int coral_cell_to_pkt(const coral_iface_t *iface,
    coral_atm_cell_t *cell, coral_pkt_buffer_t *pkt);
int (coral_get_payload)(const coral_pkt_buffer_t *src, coral_pkt_buffer_t *dst);
#define coral_get_payload(src, dst) \
    coral_fmt_get_payload((src), (dst), NULL, 0)
int coral_fmt_get_payload(const coral_pkt_buffer_t *src,
    coral_pkt_buffer_t *dst, char *buf, int len);
int coral_get_payload_by_proto(const coral_pkt_buffer_t *src,
    coral_pkt_buffer_t *dst, coral_protocol_t proto);
int coral_get_payload_by_layer(const coral_pkt_buffer_t *src,
    coral_pkt_buffer_t *dst, int layer);
int coral_pkt_truncate(coral_pkt_buffer_t *pkt, int layer, int unknown,
    int payload);
const char *coral_get_net_pkt(const coral_pkt_buffer_t *buffer, int *protocol);

#define coral_field_fits(ptr, field, len) \
    ((size_t)&((ptr)->field) - (size_t)(ptr) + sizeof((ptr)->field) <= (len))


/* internet checksum */
/* Use: initialize psum to 0; call psum = coral_in_cksum_add(psum, data, len)
 * for each segment of buffer; call coral_in_cksum_result(psum) to get result.
 * Segments must be short-aligned.  Entire message must have length < 32768.
 */
uint32_t coral_in_cksum_add(uint32_t psum, const void *data, int len);
uint16_t coral_in_cksum_result(uint32_t psum);


#ifdef CORAL_USE_DMALLOC
# include "libsrc/dmalloc/dmalloc.h"
#endif


/* This is congruent to first few members of coral_iface, to allow inlining. */
typedef struct {
#define coral_iface_pfx \
    /* iface_type MUST be first member, for cell accessor macros */\
    const coral_iface_type_t *iface_type;	/* type-specific funcs/info */\
    int			id;		/* index of this in cinst[] */\
    int			sid;		/* index of this in iface->src->id[] */\
    coral_source_t	*src;		/* source to which this belongs */

    coral_iface_pfx
} coral_iface_pfx_t;

/* This is congruent to first few members of coral_source, to allow inlining. */
typedef struct {
#define coral_src_pfx \
    int			sd;		/* index of this in csource[] */\
    int			fd;		/* file descriptor */\
    char *		desc;		/* description, from file header */\
    char *		name;		/* full name, incl. prefix if any */\
    char *		filename;	/* filename part (w/o prefix) */

    coral_src_pfx
} coral_src_pfx_t;


#define validate_src(src, label, errval)	\
    do { \
	if (!(src) || ((coral_src_pfx_t*)(src))->sd < 0 || \
	    ((coral_src_pfx_t*)(src))->sd >= CORAL_MAXOPEN) \
	{ \
	    if (label) \
		coral_diag(0, ("%s (%p): invalid source\n", label, (src))); \
	    errno = EINVAL; \
	    return errval; \
	} \
    } while (0)

#define validate_unopen_src(src, label, errval)	\
    do { \
	validate_src((src), label, errval); \
	if (((coral_src_pfx_t*)(src))->fd >= 0) { \
	    if (label) \
		coral_diag(0, ("%s: source %d (%s) already open\n", \
		    label, ((coral_src_pfx_t*)(src))->sd, \
		    ((coral_src_pfx_t*)(src))->name)); \
	    errno = EBUSY; \
	    return errval; \
	} \
    } while (0)

#define validate_iface(iface, label, errval)	\
    do { \
	if (!(iface) || ((coral_iface_pfx_t*)(iface))->id < 0 || \
	    ((coral_iface_pfx_t*)(iface))->id >= CORAL_MAXOPEN) \
	{ \
	    if (label) \
		coral_diag(0, ("%s (%p): invalid interface\n", \
		    label, (iface))); \
	    errno = EINVAL; \
	    return errval; \
	} \
    } while (0)


static inline const char *coral_source_get_comment(const coral_source_t *src)
{
    validate_src(src, 0, NULL);
    return ((coral_src_pfx_t*)(src))->desc;
}

static inline const char *coral_source_get_filename(const coral_source_t *src)
{
    validate_src(src, 0, NULL);
    return ((coral_src_pfx_t*)(src))->filename;
}

static inline const char *coral_source_get_name(const coral_source_t *src)
{
    validate_src(src, 0, NULL);
    return ((coral_src_pfx_t*)(src))->name;
}

static inline coral_source_t *coral_interface_get_src(const coral_iface_t *iface)
{
    validate_iface(iface, 0, NULL);
    return ((coral_iface_pfx_t*)(iface))->src;
}
#define coral_iface_get_src coral_interface_get_src

static inline int coral_source_get_number(const coral_source_t *src)
{
    /*validate_src(src, 0, -1);*/ /* omitted for performance */
    return ((coral_src_pfx_t*)(src))->sd;
}

static inline int coral_interface_get_number(const coral_iface_t *iface)
{
    /*validate_iface(iface, 0, -1);*/ /* omitted for performance */
    return ((coral_iface_pfx_t*)(iface))->id;
}
#define coral_iface_get_number coral_interface_get_number



char *coral_strsep(char **strp, const char *delim);

#ifdef __cplusplus
}
#endif

uint32_t coral_anonymize(coral_anon_t *anon, uint32_t addr);
int coral_pkt_anonymize(coral_pkt_buffer_t *pkt);
coral_anon_t *coral_get_anonymizer(void);
int coral_set_anonymizer(coral_anon_t *anon);
#ifdef HAVE_CRYPTOPAN
#include "coral_pan.h"
#endif

#endif /* LIBCORAL_H */
