/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 * coral_global.h -
 * $Id: coral_global.h,v 1.22 2007/06/06 18:17:41 kkeys Exp $
 *
 * Defintions that are used inside and outside the driver.
 */

#ifndef CORAL_GLOBAL_H
#define CORAL_GLOBAL_H

#ifndef __KERNEL__
#include <sys/types.h>
#include <sys/time.h>
#endif

#ifndef inline
/* 
 * If we are using GNU C, we use __inline__ instead of inline to prevent
 * problems compiling as ansi.  If not, don't use inline at all.
 */
# ifdef __GNUC__
#  define inline __inline__
# else
#  define inline
# endif
#endif

/* the space allocated to block headers on disk. */
#define CORAL_V0_BLK_HEADER_SIZE	512
#define CORAL_V3_BLK_HEADER_SIZE	76
#define CORAL_BLK_HEADER_SIZE		CORAL_V3_BLK_HEADER_SIZE

#define CORAL_OLD_CELL_SIZE	60	/* for point OCx and fore OCx */
#define ATM_PAYLOAD_SIZE	48	/* by definition of ATM */

/* changing some of these should be ok, if you want
 *  to do it for perf of something (it does help perf a little)
 * you'll have to recompile kernel and some userland stuff */

/* Maximum size of block data */
#define CORAL_MAX_BLK_SIZE	(1048576)	/* 1 MB */
/* Maximum size of block header plus block data */
#define CORAL_MAX_HBLK_SIZE	(CORAL_MAX_BLK_SIZE + CORAL_BLK_HEADER_SIZE)

/* Historical values */
#define CORAL_V0_BLK_ENTRIES	(17408)		/* cells per block */
#define CORAL_V3_BLK_ENTRIES	(17475)		/* cells per block */

#define CORAL_V0_BLK_SIZE	(CORAL_V0_BLK_ENTRIES * CORAL_OLD_CELL_SIZE)
#define CORAL_V3_BLK_SIZE	(CORAL_V3_BLK_ENTRIES * CORAL_OLD_CELL_SIZE)

#define CORAL_V0_HBLK_SIZE	(CORAL_V0_BLK_HEADER_SIZE + CORAL_V0_BLK_SIZE)
#define CORAL_V3_HBLK_SIZE	(CORAL_V3_BLK_HEADER_SIZE + CORAL_V3_BLK_SIZE)

#if 0
/* obsolete - these are now calculated from device-dependant block size and
 * cell record size
 */
#define CORAL_BLK_ENTRIES	CORAL_V3_BLK_ENTRIES

#define CORAL_HBLK_SIZE		CORAL_V3_HBLK_SIZE

#define CELLBUF_SIZE		((CORAL_BLK_HEADER_SIZE + CORAL_BLK_SIZE) * \
					CORAL_BLKS)

#define CORAL_BLK_SIZE		(CORAL_BLK_ENTRIES * CORAL_OLD_CELL_SIZE)
#endif

#if (__FreeBSD_version < 400000 && defined(KERNEL)) || \
    (__FreeBSD_version >= 400000 && defined(_KERNEL))
# include <pci/coral_ioctl_const.h>
#else
# include "coral_ioctl_const.h"
#endif

typedef struct {
    u_int   flags;
    int	    first_n;
} coral_io_mode_t;

/* coral data structures - per interface */
/* fields in native machine byte order */
typedef struct coral_interface {
    u_int version;		/* version number of driver api */
    int type;			/* type of interface */
    caddr_t kmem_buffer;	/* buffer location in kernel mem (not used) */
    u_int blk_size;		/* size of each rx blk (header + data) */
    char num_blks;		/* number of blks in the kernel buffer */ 
    coral_io_mode_t iomode;	/* types of stuff being captured */
    u_int bitrate;              /* bit rate */

    /* stats */
    u_int tx_errors;
    u_int rx_errors;
    u_int interrupts;

} coral_interface;

/* Version 3 block header */
/* Contains per block info.  Much info that was repeated in every block in
 * version 2 has been moved to the file header.  The size was chosen so
 * that this header plus CORAL_BLK_ENTRIES * CORAL_OLD_CELL_SIZE would
 * be a multiple of 512 for disk performance reasons (and less importantly,
 * exactly 1M, which is a nice round number).
 * All fields are in network byte order (big endian).
 */
typedef struct coral_blk_info_v4 {
    u_int		interface;	/* which card this came from, if 
					 * applicable */
    u_int		blk_size;	/* size (bytes) of data block */
    u_int		cell_count;	/* number of valid cells in data blk */
    u_int		cells_lost;	/* number of cells lost during time 
					 * period */
    u_int		unknown_vpi_vci;/* cells dropped because vpi/vci 
					 * unknown */
    struct timespec	tbegin;		/* time of block start */
    struct timespec	tend;		/* time of block end */
    char		pad1[CORAL_V3_BLK_HEADER_SIZE - 36];
} coral_blk_info_v4_t;

#define coral_blk_info_t coral_blk_info_v4_t


#define DEBUG_DATA1	pad1[0]

/* macros to access parts of the <i>th block in a buffer <base> that contains
 * num_blks data blocks of size <blk_size> followed by num_blks headers */
#define BLK_IDX_TO_INFO(i, base, blk_size, num_blks) \
	((coral_blk_info_t *)((base) + (blk_size * num_blks) + ((i) * CORAL_BLK_HEADER_SIZE)))
#define BLK_IDX_TO_ADR(i, base, blk_size, num_blks) \
	((char *)((base) + (blk_size * (i))))

/* general utulity */
#define HTON_TIMESPEC(ts)	(ts).tv_sec = htonl((ts).tv_sec); \
				(ts).tv_nsec = htonl((ts).tv_nsec)
#define NTOH_TIMESPEC(ts)	(ts).tv_sec = ntohl((ts).tv_sec); \
				(ts).tv_nsec = ntohl((ts).tv_nsec)

#endif /* CORAL_GLOBAL_H */
