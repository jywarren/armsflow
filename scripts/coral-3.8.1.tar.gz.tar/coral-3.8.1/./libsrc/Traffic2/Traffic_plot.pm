package CAIDA::Traffic2::Traffic_plot;
require 5.004;
## $Id: Traffic_plot.pm,v 1.31 2007/06/06 18:17:51 kkeys Exp $ $Name: release-3-8-1 $
##
## -----------------------------------------------------------------------
## Perl module:Traffic_plot.pm
## 
## This Perl module uses the Vpvc_data module to build up more complex
## data structures containing a single sample of data from the Traffic2
## program.
## 
## Note: test routines require the Test.pm module or Perl 5.005
##
## Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
## All Rights Reserved 
##
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
##
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
##
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
##
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
##
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program. Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
##
## Contact: coral-info@caida.org
## ---------------------------------------------------------------------

# Set up object export condition.  No functions accessible directly.
use Exporter ();
@ISA       = qw(Exporter);
@EXPORT    = qw(make_pie_chart_png make_pie_chart_java);
@EXPORT_OK = qw();

# Define required CVS variables
$cvs_Id = '$Id: Traffic_plot.pm,v 1.31 2007/06/06 18:17:51 kkeys Exp $';
$cvs_Author = '$Author: kkeys $';
$cvs_Name = '$Name: release-3-8-1 $';
$cvs_Revision = '$Revision: 1.31 $';

# Enable error messages to come from calling script
use Carp;

# Force this module to adhere to safe programming practices.
use strict;

# Load the GD pie chart generator if available.  Keep track of the error 
# message in case someone tries to use the module even if they don't have
# it loaded.
 BEGIN { 
     use vars qw($GD_message);
     $GD_message = "OK";
     # First load in GD::Graph::pie .. works for all Perl's equally.
     eval 'require GD::Graph::pie';
     unless ($@ eq '')  {
 	$GD_message = "Unable to require GD::Graph::pie" . $@;
     }
     eval 'import GD::Graph::pie';
     unless (($GD_message eq "OK") and ($@ eq '')) {
 	$GD_message = "Unable to import GD::Graph::pie" . $@;
     }
     # Load GD::Graph:Colour ... to control symbols imported under Perl 5.6
     # use autouse feature.
     # XXX For some reason this autouse code is failing, and doesn't seem
     # important anyway.
#     eval 'require 5.6.0';
#     if ($@ eq '') {
#	 eval 'use autouse GD::Graph::colour => qw(:colours :lists :convert)';
#	 unless (($GD_message eq "OK") and  ($@ eq '')) {
#	     $GD_message = "Unable to use GD::Graph::colour" . $@;
#	 }
#     } else { # Stick to old Perl procedure for loading symbols.
	 eval 'require GD::Graph::colour';
	 unless (($GD_message eq "OK") and  ($@ eq '')) {
	     $GD_message = "Unable to require GD::Graph::colour" . $@;
	 }
	 eval 'import GD::Graph::colour qw(:colours :lists :convert)';
	 unless (($GD_message eq "OK") and ($@ eq '')) {
	     $GD_message = "Unable to import GD::Graph::colour" . $@;
	 }
#     }
 }


# Version of module
my $VERSION = 1.0;

# Declare global variable that are legacy global variables from
# the t2_report.pl script.  Serves to keep pie chart filename unique
use vars qw($image_file_cnt);
$image_file_cnt = 0;



# .   .   .   .   .  Exported object functions  .   .   .   .   .   .   .  

sub make_pie_chart_png($$$$$$$$$$$) {
# -------------------------------------------
# Tool for creating Pie Charts.  This variant
# uses Chart-Graph module to create image.
# eventually, this function will call a 
# generalized routine - eliminating the need
# for this script to deal with the specifics
# of the routine used to create the graph.
# -------------------------------------------
  my $filehdl_ref = shift;
  my $table = shift;
  my $hash_ref = shift;
  my $top_n_ref = shift;
  my $count_ref = shift;
  my $elapsed = shift;
  my $graph_title = shift;
  my $key_title = shift;
  my $key_print_func = shift;
  my $unit = shift;
  my $category = shift;
  my @web_color_list;

  # Test if module can be used.  Otherwise simply print out error message
  # that had been carefully squirreled away.
  unless ($GD_message eq "OK") {
      croak $GD_message;
  }

  # Get configuration state from t2_report.
  my $page_dir = $main::config->get('page_dir');
  my $pie_slices = $main::config->get('pie_slices') - 2;
  my $three_d_pie = $main::config->get('3d_pie');
  # Extract totals out of hash to simplify statements
  my $total_amount = $count_ref->$unit();

  my $top_n_count = new CAIDA::Traffic2::FlowCounter(); 
  if(@{$top_n_ref} == 0) {
	  return(0);
  }

  # If number of items in Pie Chart exceeds $pie_slices
  # Shuffle rest into other category to avoid overflowing chart.
  my @top_n = @$top_n_ref;

  if(@top_n > $pie_slices) {
	@top_n = @top_n[0..$pie_slices];
  }

  my @data_names = ();
  my @dummy_names = ();
  my @data_values = ();
  my @data = ();

  # How many items to display in list.
  foreach my $key (@top_n) {
	
      # Compute percentage of unit and unit rate.
      my $amount = $hash_ref->{$key}->$unit();

      $top_n_count->add($hash_ref->{$key});
      push(@data_names, &$key_print_func($table, $key));
      push(@dummy_names, '');
      push(@data_values, $amount);
      #	$data = join("", $data, " '", &$key_print_func($table, $key), "' ", $amount);
  }
  my @color_list = (qw(lred lgreen lblue lyellow lpurple cyan lorange red green blue yellow purple marine orange dred dgreen dblue dyellow dpurple gold pink lbrown dpink dbrown lgray gray dgray));

  my $top_n_amount = $top_n_count->$unit();
  if($top_n_amount < $total_amount) {
      push(@data_names, 'other');
      push(@dummy_names, '');
      push(@data_values, ($total_amount-$top_n_amount));
#	$data = join("", $data, " 'other' ", ($total_amount-$top_n_amount));
      while (@color_list < @data_names) {
	  push @color_list, @color_list;
      }
      @color_list[$#data_names] = "black";
  }

  my $my_graph = new GD::Graph::pie( 400, 400 );

  $my_graph->set( 
		 start_angle => 90,
		 '3d' => $three_d_pie,
		 transparent => 1,
		 l_margin => 5,
		 r_margin => 5,
		 t_margin => 5,
		 b_margin => 5,
		 'dclrs' => \@color_list,
		);
  @data = (\@dummy_names, \@data_values);
  my $filename = "${category}_${unit}_pie_chart.png";

  unless( open(IMG, ">$page_dir/$filename")) {
      croak "Can't create image file $filename";
  }

  
  print IMG $my_graph->plot(\@data)->png;
  close(IMG);

  foreach my $color (@color_list) {
      push @web_color_list, rgb2hex(_rgb($color));
  }

  print $filehdl_ref <<"EOT";
<P>
<table border=0 valign="top" bgcolor="#FFFFFF">
  <tr>
    <td colspan=2>
	   <center><h3>
EOT

	foreach my $title (split(/\\n/, $graph_title)) {
		print $filehdl_ref $title, "<br>\n";
	}

  print $filehdl_ref <<"EOT";
	   </h3></center></td></tr>
	   <tr valign="top"><td bgcolor="#FFFFFF">
           <img src="$filename">
    </td>
EOT
#00FFFF
  #Now create legend as a second table to the right of the graph.
  my $no_colors = scalar(@web_color_list);
  print $filehdl_ref "<td><table border=\"0\" bgcolor=\"#FFFFFF\">\n";
  for (my $i=0; $i < scalar(@data_names); $i++) {
      print $filehdl_ref "<tr><td bgcolor=\"", 
      $web_color_list[$i%$no_colors], "\">",
      "&nbsp;&nbsp;&nbsp;&nbsp;</td><td>", 
      $data_names[$i], "</td></tr>\n";
  }
  print $filehdl_ref "</table></td></tr>\n";
print $filehdl_ref "</table>\n</p>\n";
} #End make_pie_chart_gif

sub make_pie_chart_java($$$$$$$$$ ) {
# -------------------------------------------
# Iteration toward a generalized tool to 
# create HTML tables.  Still specific to
# this need.  Computes total packets and 
# bytes and percentages relative to this
# Vpvc.
# -------------------------------------------
  my $filehdl_ref = shift;
  my $table = shift;
  my $hash_ref = shift;
  my $top_n_ref = shift;
  my $count_ref = shift;
  my $elapsed = shift;
  my $graph_title = shift;
  my $key_title = shift;
  my $key_print_func = shift;

  my $java_server = $main::config->get('javaserver');
  my $java_server_archive = $main::config->get('javaserver_archive');
  my $ARCHIVE;
  if ($java_server_archive) {
      $ARCHIVE = "ARCHIVE=\"$java_server_archive\"";
  } else {
      $ARCHIVE = "";
  }
  # Extract totals out of hash to simplify statements
  my $total_bytes = $count_ref->bytes();

  my $top_n_count = new CAIDA::Traffic2::FlowCounter(); 

  # Send the HTML tags to start table and supply table header
  print $filehdl_ref <<"EOH";
<!-- Start of Java Applet code -->
<P><applet 
           $ARCHIVE
           CODEBASE="$java_server" 
           CODE="jclass/chart/JCChartApplet.class" WIDTH=400 HEIGHT=400>
<PARAM name="chart.header.text" value="$graph_title">
<PARAM name="chart.header.font" value="TimesRoman-bold-14">
<PARAM name="chart.header.isShowing" value="true">
<PARAM name="chart.data.chartType" value="PIE">
<PARAM name="data.Bar.clusterWidth" value="100">
<PARAM name="chart.legend.isShowing" value="true">
<PARAM name="chart.rotateTrigger" value="CTRL">
<PARAM name="chart.chartArea.rotation" value="0">
<PARAM name="chart.chartArea.depth" value="2">
<PARAM name="chart.chartArea.elevation" value="0">
<PARAM name="chart.yaxis.title.text" value="bits/sec">
<PARAM name="chart.yaxis.title.rotation" value="90">
<PARAM name="chart.yaxis.title.placement" value="west">
<PARAM name="chart.background" value="#D1E1FF">
<PARAM name="chart.chartarea.plotArea.background" value="#BCC7E6">
<PARAM name="chart.ZoomTrigger" value="NONE">
EOH


  my $count = 0;
  my $data = "";
  
  my @top_n = @{$top_n_ref};
  # If number of items in Pie Chart exceeds 20 - 
  # Shuffle rest into other category to avoid overflowing chart.
  if(@top_n > 20) {
	@top_n = @top_n[0..19];
  }

  # How many items to display in list.
  foreach my $key (@{top_n}) {
	
	# Compute percentage of bytes and byte rate.
    my $bytes = $hash_ref->{$key}->bytes();

    $top_n_count->add($hash_ref->{$key});
	$data = join("", $data, " '", &$key_print_func($table, $key), "' ", $bytes);
	$count++;
  }

  my $top_n_bytes = $top_n_count->bytes();
  if($top_n_bytes < $total_bytes) {
	$data = join("", $data, " 'other' ", ($total_bytes-$top_n_bytes));
	$count++;
  }

  # Send the table close tags - add any comments/etc. here
  print $filehdl_ref <<"EOH";
<PARAM name="data" value="ARRAY '$key_title' $count 1 HOLE -1 1 $data">
</applet></P>
EOH

} #End make_pie_chart_java

# .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   . 
1; ##must be last active statement in file
# =============================
# POD Documentation for Module

__END__

=head1 NAME

Traffic_plot - "Wrapper" for plotting output from the Traffic2 program

=head1 SYNOPSIS

    use CAIDA::Traffic2::Traffic_plot;


=head1 DESCRIPTION


=head1 EXAMPLE


=head1 AUTHOR

Edouard Lagache <coral-info@caida.org>

=head1 COPYRIGHT

Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
All Rights Reserved 

Permission to use, copy, modify and distribute any part of this
CoralReef software package for educational, research and non-profit
purposes, without fee, and without a written agreement is hereby
granted, provided that the above copyright notice, this paragraph
and the following paragraphs appear in all copies.

Those desiring to incorporate this into commercial products or use
for commercial purposes should contact the Technology Transfer
Office, University of California, San Diego, 9500 Gilman Drive, La
Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.

IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
THE POSSIBILITY OF SUCH DAMAGE.

THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
ANY PATENT, TRADEMARK OR OTHER RIGHTS.

The CoralReef software package is developed by the CoralReef
development team at the University of California, San Diego under
the Cooperative Association for Internet Data Analysis (CAIDA)
Program. Support for this effort is provided by the CAIDA grant
NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
N66001-01-1-8909, and by CAIDA members.

Report bugs and suggestions to coral-bugs@caida.org.

=cut

