/* 
 * This is partially based on code written by Joel Apisdorf.
 */

/*
 * point_suni.h - layout of suni chip on apptel point622
 *
 * $Id: point_suni.h,v 1.6 1999/11/03 23:09:44 swbrown Exp $
 *
 * the suni is the actual physical interface to the oc12
 * line.  it frames atm cells and sends them across the 
 * 'aim' interface to the fpgas.
 *
 * Check the suni622man.pdf file for more info on the register names.  Only
 * a few are included here.
 */

/* data structures for PMC/Sierra S/UNI-622 (a.k.a. PM5355) chip
 *
 * abbreviations used here:
 *
 * RSOP         receive section overhead processor
 * RLOP         receive line overhead processor
 * RPOP         receive path overhead processor
 * RACP         receive ATM cell processor
 * TACP         transmit ATM cell processor
 * any write loads all performance meters in
 * Rsop, RLOP, RPOP, RACP, and TACP blocks
 */
struct SuniRacpControl_register {
    u_char ResetFifo                  : 1;
    u_char DisablePayloadDescrambling : 1;
    u_char AddCosetPolynomialToHcs    : 1;
    u_char PassUncorrectableHcsErrors : 1;
    u_char DisableHcsErrorCorrection  : 1;
    u_char PassFilteredCells          : 1; /* usually means idle/unassigned */
    u_char RxParityEven               : 1;
    u_char EnableFixedStuffing        : 1; /* for SONET payload */
};

typedef struct {
    
    struct {
	u_char Identity       : 4;	/* SUNI revision number */
	u_char Type           : 3;	/* 1 means SUNI-622 */
	u_char Reset          : 1;	/* not self-clearing */
    } Master;
    u_char pad0[3];
    
    struct {
    	
    	/* Receive and transfer modes.  01b is STS-3c, 11b is STS-12c. */
    	u_char RMODE          : 2;
    	u_char TMODE          : 2;
    	
    	u_char FIXPTR         : 1;
    	u_char SDH_C1         : 1;
    	u_char TSTBEN         : 2;
    } MasterConfiguration;
    
    u_int Reserved1[78];
    
    struct SuniRacpControl_register RacpControl;
    u_char pad80[3];

    u_int Reserved2[11];
    
    struct {
	u_char RxGfcEnable0 :	1; /* copy GFC bit 0 to RGFC output */
	u_char RxGfcEnable1 :	1; /* copy GFC bit 1 to RGFC output */
	u_char RxGfcEnable2 :	1; /* copy GFC bit 2 to RGFC output */
	u_char RxGfcEnable3 :	1; /* copy GFC bit 3 to RGFC output */
	u_char Unused	    :	2;
	u_char RxByteParity :	1; /* RXPRTY[1:0] is byte if 1, word if 0 */
	u_char CellDelineationDisable : 1; /* use 1 for full SONET 
					    * payload access (PPP mode) */
    } GfcAndMiscControl;
    u_char pad92[3];

    u_int Reserved3[163];
} suni_regs;
