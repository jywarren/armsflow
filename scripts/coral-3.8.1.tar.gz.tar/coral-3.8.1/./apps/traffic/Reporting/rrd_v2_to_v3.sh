#!/bin/sh
## 
## Copyright 1999, 2000, 2001, 2002, 2003, 2004, 2005, 2007
## The Regents of the University of California 
## All Rights Reserved 
## 
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
## 
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
## 
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
## 
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
## 
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program.  Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
## 
## Report bugs and suggestions to coral-bugs@caida.org.
## 

# This script converts RRDs created by t2_report++ into ones usable with
# the new report generation scripts, by converting bytes/sec into
# bits/sec and moving the total.rrd file.

# Change this if rrdtool isn't in your path
rrdtool="rrdtool"
MIN_MAJOR=1
MIN_MINOR=2

rrd_version=0
# Test that executable exists.
$rrdtool > /dev/null
if [ "$?" -ne "0" ]; then
    echo Please put 'rrdtool' in your path.
    exit 1;
fi
rrd_version=`$rrdtool | awk '/RRDtool [[:digit:]]/ {print $2}'`
major=`echo $rrd_version | cut -d. -f1`;
minor=`echo $rrd_version | cut -d. -f2`;
# Unnecessary at the moment
#subminor=`echo $rrd_version | cut -d. -f3`;
if [ $major -lt $MIN_MAJOR -o $minor -lt $MIN_MINOR ]; then
    echo Old version of RRDtool, this script requires $MIN_MAJOR.$MIN_MINOR or greater.
    exit 1;
fi

update_rrd()
{
    file=$1
    if [ ! -f "$file" ]; then
	echo Couldn\'t open file $file, skipping.
	return
    fi
    $rrdtool dump "$file" > "$file.xml"
    awk 'BEGIN {found_bytes = 0} \
	 /bits/ {exit 1} \
	 /bytes/ {$2 = "bits"; found_bytes = 1} \
	 /<v>/ {if ($9 != "NaN") $9 = sprintf("%.10e", $9 * 8)} \
	 /<value>/ {if (found_bytes) { $2 = sprintf("%.10e", $2 * 8); } found_bytes = 0} \
	 {print}' < "$file.xml" > "$file.tmp.xml"
    if [ "$?" -eq "0" ]; then
	$rrdtool restore "$file.tmp.xml" "$file.copy"
	mv "$file.copy" "$file"
    else
	echo "$file already in correct format, skipping."
    fi
    rm -f "$file.xml" "$file.tmp.xml"
}

version=0
if [ -f "version" ]; then
    version=`cat version`
fi
if [ "$version" -eq 3 ]; then
    echo Monitor data already in correct format, exiting.
    echo \(If you know this to be false, remove the 'version' file.\)
    exit 2
fi
# Fixing the non-AppPorts RRD name changes from old report generator to new
mv app/OTHER_TCP.rrd app/UNKNOWN_TCP.rrd
mv app/OTHER_UDP.rrd app/UNKNOWN_UDP.rrd
mv app/TCP_NOPORTS.rrd app/NOPORTS_TCP.rrd
mv app/UDP_NOPORTS.rrd app/NOPORTS_UDP.rrd
mv app/OTHER_1.rrd app/UNKNOWN_ICMP.rrd
for rrd in app/OTHER_*.rrd
do
    new_rrd=`echo $rrd | sed -e 's/OTHER_/UNKNOWN_PROTO_/'`
    mv $rrd $new_rrd
done
echo Updating total.rrd...
mv proto/total.rrd .
update_rrd total.rrd
for dir in *
do
    if [ -d "$dir" ]; then
	cd "$dir"
	for file in *.rrd
	do
	    echo "Updating $file in $dir..."
	    update_rrd "$file"
	done
	cd ..
    fi
done
echo 3 > version
