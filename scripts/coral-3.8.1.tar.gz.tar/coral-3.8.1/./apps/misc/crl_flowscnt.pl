#! /usr/local/bin/perl -w
## 
## Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
## All Rights Reserved 
## 
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
## 
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
## 
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
## 
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
## 
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program. Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
## 
## Report bugs and suggestions to coral-bugs@caida.org.
## 

## $Id: crl_flowscnt.pl,v 1.32 2007/06/06 18:17:30 kkeys Exp $
## $Author: kkeys $
## $Name: release-3-8-1 $
## $Revision: 1.32 $
##
## USAGE:  crl_flowscnt.pl <Coral Dump>
##


my $coral_dir;
BEGIN { $coral_dir = "/usr/local/Coral"; } # This will be edited during build.
use lib "$coral_dir/lib"; #coral global libdir#
use lib "../../lib"; #coral local libdir#
use CRL;
use Flow_Hist;
use strict;

my @interfaces = (0, 1, "both");
my @bin_sizes = (0.01, 0.10, 1.00, 10.0);

my %flow_hists;

foreach my $interface (@interfaces) {
    foreach my $bin_size (@bin_sizes) {
	$flow_hists{$interface}{$bin_size} = new Flow_Hist($bin_size);
    }
}


my $ip_opts = new Unpacker("ip", ["ip_src", "ip_dst", "ip_p", "ihl"]);
my $tcp_opts = new Unpacker("tcp", ["th_sport", "th_dport"]);
my $udp_opts = new Unpacker("udp", ["uh_sport", "uh_dport"]);

Coral::quick_start();
Coral::read_pkt_init(undef, undef);

my $packet = new Coral::Pkt_result;

my $iface;
my $cnt;
while (defined($iface = Coral::read_pkt($packet))) {
    my $interface = Coral::interface_get_number($iface);
    my $timestamp_ptr = $packet->timestamp;
    my $timestamp = Coral::read_clock_double($iface, $timestamp_ptr);

    my $ip_record = Coral::get_ip($iface, $packet->packet);
    if (!defined $ip_record) { next; } # not an ipv4 packet

    my ($ip_src, $ip_dst, $ip_p, $ihl) = $ip_opts->unpack($ip_record);

    my ($sport, $dport);

    if ($ip_p == 6) {
	($sport, $dport) = $tcp_opts->unpack($ip_record, $ihl);
    } elsif ($ip_p == 17) {
	($sport, $dport) = $udp_opts->unpack($ip_record, $ihl);
    } else {
	$sport = $dport = 0;
    }

    if ((!defined $ip_src) || (!defined $ip_dst) || (!defined $ip_p) ||
	(!defined $sport) || (!defined $dport))
	{
	    # can't measure this guy. XXX - should have counter
	    print STDERR "skipping a packet, fields lost\n";
	    print STDERR "$ip_src\t$ip_dst\t$ip_p\t$sport\t$dport\n";
	    next;
	}

    my $key_5tuple = pack("NNCnn", $ip_src, $ip_dst, $ip_p, $sport, $dport);
    #my $key_2tuple = pack("NN", $ip_src, $ip_dst);

 
    foreach my $bin_size (@bin_sizes) {
	$flow_hists{$interface}{$bin_size}->saw_flow($key_5tuple, $timestamp);
	$flow_hists{"both"}{$bin_size}->saw_flow($key_5tuple, $timestamp);

	next;
	# XXX - should do saw_time() on the other interface?? or not??
	#  might not want to.
        if ($interface == 0) {
            $flow_hists{1}{$bin_size}->saw_time($timestamp);
        } else {
            $flow_hists{0}{$bin_size}->saw_time($timestamp);
        }
    }

    if ((++$cnt) % 100000 == 0) {
	print "# packets so far: $cnt\n";
	foreach my $interface (@interfaces) {
	    print "# interface: $interface\n";
	    print "#bin size\tbins measured\t\tmin\tavg\tmedian\tmax\n";
	    foreach my $bin_size (@bin_sizes) {
		$flow_hists{$interface}{$bin_size}->print_stats();
	    }
	}
	print "\n";
    }
}



print "# final stats:\n";
foreach my $interface (@interfaces) {
    print "# interface: $interface\n";
    print "#bin size\tbins measured\t\tmin\tavg\tmedian\tmax\n";
    foreach my $bin_size (@bin_sizes) {
	$flow_hists{$interface}{$bin_size}->print_stats();
    }
}
