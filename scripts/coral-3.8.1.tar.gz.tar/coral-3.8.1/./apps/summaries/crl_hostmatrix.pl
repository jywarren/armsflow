#!/usr/local/bin/perl
## 
## Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
## All Rights Reserved 
## 
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
## 
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
## 
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
## 
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
## 
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program. Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
## 
## Report bugs and suggestions to coral-bugs@caida.org.
## 
## $Id: crl_hostmatrix.pl,v 1.17 2007/06/06 18:17:32 kkeys Exp $
## $Author: kkeys $
## $Name: release-3-8-1 $
## $Revision: 1.17 $


use Socket;
use Fcntl;
use DB_File;
use File::Basename;

($script_name, $script_path, $script_suffix) = fileparse($0);
$PNAME = "$script_name$script_suffix";


## Check command-line arguments
#if (@ARGV != 1) { 
#    print STDERR " Invalid number of command-line arguments.\n";
#    print STDERR " Usage: ${PNAME} <Coral Dump>\n\n";
#    exit(0);
#}


##  Initialize the temporary hash tables we're going to use.
## #### Currently we're setting this explicitly to use the berkeley DB
## package.

$DB_HASH->{cachesize} = 2*1024*1024;
$db_hostname = tie %hostname, "DB_File", "tmpdir/hostname_byip", O_RDWR|O_CREAT, 0644, $DB_HASH;

sub get_host {
    my ($addr) = @_;
    my $host;
    my ($addr1, $addr2, $addr3, $addr4);
    
    $host = gethostbyaddr(inet_aton($addr), AF_INET);
    if (!$host) {
	($addr1, $addr2, $addr3, $addr4) = split /\./, $addr;
	$host = "$addr4.$addr3.$addr2.$addr1.in-addr";
    }
    $hostname{$addr} = $host;
    
    # $db_hostname->sync();
    
    return $host;
}

my $args;
foreach my $arg (@ARGV) {
    $args .= "\"$arg\" ";
}

open(INFILE, "${script_path}crl_ipmatrix $args |")
    or die("Can't get summary from crl_ipmatrix: $!\n");

chop ($total_packets = <INFILE>);
chop ($total_bytes = <INFILE>);

while (<INFILE>) {
    chop;
    ($src, $dst, $packets, $bytes) = split /\t/;
    
    $hostname{$src} || get_host($src);
    $hostname{$dst} || get_host($dst);
    
    printf ("%s\t%s\t%u\t%2.8f\t%u\t%2.8f\n",
	    $hostname{$src}, $hostname{$dst},
	    $packets, $packets/$total_packets,
	    $bytes, $bytes/$total_bytes);
    
}

untie %hostname;
