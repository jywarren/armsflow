/* 
 * Copyright 2002, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 */

typedef struct {
    const char *outfilename;
    int rotating;
    struct in_addr ip_mask;
    unsigned int names;
    unsigned int hashstats;
    unsigned int nolabels;
    unsigned int nosrc;
    unsigned int nodst;
    unsigned int noproto;
    unsigned int human;
    unsigned int notypes;
    unsigned int no_rd;
    unsigned int no_swap;
    unsigned int no_requests;
    unsigned int no_responses;
    unsigned int print_unusual;
    unsigned int max_entries;
    unsigned int caplen;
    unsigned int binary_out;
    unsigned int dnsstat_in;
} config_t;

enum {
    COL_SRC	= 0x0001,
    COL_DST	= 0x0002,
    COL_PROTO	= 0x0004,
    COL_OP	= 0x0008,
    COL_TYPE	= 0x0010,
    COL_CLASS	= 0x0020,
    COL_QUERIES	= 0x0040,
    COL_MSGS	= 0x0080,
    COL_RD	= 0x0100,
    COL_REQS	= 0x0200,
    COL_RESPS	= 0x0400
};

#define COL_ALL \
    (COL_SRC | COL_DST | COL_PROTO | COL_OP | COL_TYPE | COL_CLASS | \
    COL_QUERIES | COL_MSGS | COL_RD | COL_REQS | COL_RESPS)

enum {
    TYPE_ERR,
    TYPE_COLUMNS,
    TYPE_INTERVAL,
    TYPE_FLOW,
    TYPE_QUERY,
    TYPE_QUERY_0_IN, /* query with opcode=0 qclass=IN */
    TYPE_QUERY_0_IN_A, /* query with opcode=0 qclass=IN qtype=A */
    TYPE_TRUNCATED,
    TYPE_EOI,
    TYPE_EOF,
    TYPE_MQ,
    TYPE_ZQ,
    TYPE_SWAP,
    TYPE_RD,
    TYPE_QL4ERR,
    TYPE_QHTRUNC,
    TYPE_RL4ERR,
    TYPE_RHTRUNC,
    TYPE_QUERY_0_IN_PTR,
    TYPE_QUERY_0_IN_SOA,
    TYPE_QUERY_0_IN_MX,
    TYPE_QUERY_0_IN_NS,
    TYPE_QUERY_0_IN_ANY,
    TYPE_QUERY_0_IN_SRV,
    TYPE_QUERY_0_IN_AAAA,
    TYPE_QUERY_0_IN_A6
};

typedef uint8_t rec_type_t; /* must be 8 bits for ungetc */
typedef uint16_t col_id_t;

typedef struct {
    struct timeval begin, end;
    uint64_t qmessages;		/* # request messages */
    uint64_t qqueries;		/* # response queries */
    uint64_t rmessages;		/* # request messages */
    uint64_t rqueries;		/* # response queries */
    uint64_t multiqueries;	/* # requests with >1 query */
    uint64_t zeroqueries;	/* # requests with 0 queries */
    uint64_t recursion;		/* # requests with RD set */
    uint64_t qL4_errs;		/* # requests with unparseable transport hdr */
    uint64_t qhtrunc;		/* # requests lost b/c header was truncated */
    uint64_t rL4_errs;		/* # responses with unparseable transport hdr */
    uint64_t rhtrunc;		/* # responses lost b/c header was truncated */
    /*uint64_t bytes;*/
} interval_data_t;

typedef struct querystats {
/* key */
    struct flowstats *flowstat;	/* flowstat to which this belongs */
    uint8_t opcode;
    uint8_t truncated;
    uint16_t qtype;
    uint16_t qclass;

/* data */
    uint64_t qqueries;	    	/* # of queries in requests (>= messages) */
    uint64_t rqueries;	    	/* # of queries in responses (>= messages) */
    uint64_t recursion;		/* # of queries in requests with RD set */
    uint64_t qdswapped;		/* # of queries in requests with byte-swapped QDCOUNT */
    struct timespec first;
    struct timespec latest;

/* operational */
    struct querystats *next;	/* next querystats_t in flow's list */
} querystats_t;

typedef struct flowstats {
/* key */
    struct in_addr src;
    struct in_addr dst;
    uint8_t ip_proto;

/* data */
    uint64_t qmessages;		/* # requests for this key */
    uint64_t qqueries;		/* # queries in requests for this key */
    uint64_t rmessages;		/* # responses for this key */
    uint64_t rqueries;		/* # queries in responses for this key */
    uint64_t recursion;		/* # requests with RD set */
    uint64_t multiqueries;	/* # requests with >1 query */
    uint64_t zeroqueries;	/* # requests with 0 queries */
    uint64_t qdswapped;		/* # requests with byte-swapped QDCOUNT */
    uint64_t qL4_errs;		/* # requests w/ unparseable transport hdr */
    uint64_t qhtrunc;		/* # requests lost b/c header was truncated */
    uint64_t rL4_errs;		/* # responses w/ unparseable transport hdr */
    uint64_t rhtrunc;		/* # responses lost b/c header was truncated */
    struct timespec first;
    struct timespec latest;

/* operational */
    struct querystats *querylist;	/* linked list of querystats_t's */
} flowstats_t;

typedef struct dnsstat_file dnsstat_file_t;

int dump_binary_config(FILE *file, const col_id_t columns);
int dump_binary_interval(FILE *file, const interval_data_t *interval);
int dump_binary_eoi(FILE *file, const interval_data_t *interval);
int dump_binary_flowrec(FILE *file, const flowstats_t *flowrec);
int dump_binary_queryrec(FILE *file, const querystats_t *queryrec);
int dump_binary_eof(FILE *file);
rec_type_t read_dnsstat_record(dnsstat_file_t *, config_t *, interval_data_t *,
    flowstats_t *, querystats_t *);
dnsstat_file_t *open_dnsstat_file(const char *filename);
int close_dnsstat_file(dnsstat_file_t *df);

