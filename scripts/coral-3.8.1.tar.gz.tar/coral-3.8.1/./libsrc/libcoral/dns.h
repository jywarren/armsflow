/* 
 * Copyright 2002, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 *
 * $Id: dns.h,v 1.12 2007/06/06 18:17:56 kkeys Exp $
 * DNS protocol structures and constants (RFC 1035, 2136, 1876)
 * These aren't reliably defined in any portable system header.
 *
 */

typedef struct {
        uint16_t        id;            /* query identification number */
#if WORDS_BIGENDIAN
                        /* fields in third byte */
        unsigned        qr:1;          /* response flag */
        unsigned        opcode:4;      /* purpose of message */
        unsigned        aa:1;          /* authoritive answer */
        unsigned        tc:1;          /* truncated message */
        unsigned        rd:1;          /* recursion desired */
                        /* fields in fourth byte */
        unsigned        ra:1;          /* recursion available */
        unsigned        unused:1;      /* unused bits */
        unsigned        ad:1;          /* authentic data from named */
        unsigned        cd:1;          /* checking disabled by resolver */
        unsigned        rcode:4;       /* response code */
#else
                        /* fields in third byte */
        unsigned        rd:1;          /* recursion desired */
        unsigned        tc:1;          /* truncated message */
        unsigned        aa:1;          /* authoritive answer */
        unsigned        opcode:4;      /* purpose of message */
        unsigned        qr:1;          /* response flag */
                        /* fields in fourth byte */
        unsigned        rcode:4;       /* response code */
        unsigned        cd:1;          /* checking disabled by resolver */
        unsigned        ad:1;          /* authentic data from named */
        unsigned        unused:1;      /* unused bits */
        unsigned        ra:1;          /* recursion available */
#endif
                        /* remaining bytes */
        uint16_t        qdcount;       /* number of question entries */
        uint16_t        ancount;       /* number of answer entries */
        uint16_t        nscount;       /* number of authority entries */
        uint16_t        arcount;       /* number of resource entries */
} dnshdr_t;

/* macros for fetching bitfields safely from unaligned (dnshdr_t *) */
#define crl_dns_qr(p)		((((uint8_t*)p)[2] & 0x80) >> 7)
#define crl_dns_opcode(p)	((((uint8_t*)p)[2] & 0x78) >> 3)
#define crl_dns_aa(p)		((((uint8_t*)p)[2] & 0x04) >> 2)
#define crl_dns_tc(p)		((((uint8_t*)p)[2] & 0x02) >> 1)
#define crl_dns_rd(p)		((((uint8_t*)p)[2] & 0x01) >> 0)
#define crl_dns_ra(p)		((((uint8_t*)p)[3] & 0x80) >> 7)
#define crl_dns_unused(p)	((((uint8_t*)p)[3] & 0x40) >> 6)
#define crl_dns_ad(p)		((((uint8_t*)p)[3] & 0x20) >> 5)
#define crl_dns_cd(p)		((((uint8_t*)p)[3] & 0x10) >> 4)
#define crl_dns_rcode(p)	((((uint8_t*)p)[3] & 0x0F) >> 0)

/* opcodes */
#define QUERY		0x0	/* standard query */
#define IQUERY		0x1	/* inverse query (retired) */
#define STATUS		0x2	/* nameserver status query */
/*#define xxx           0x3*/	/* reserved */
#define NS_NOTIFY_OP	0x4	/* notify secondary of SOA change */
#define NS_UPDATE_OP	0x5	/* zone update */

/* response codes */
#define NOERROR		0	/* no error */
#define FORMERR		1	/* format error */
#define SERVFAIL	2	/* server failure */
#define NXDOMAIN	3	/* non existent domain */
#define NOTIMP		4	/* not implemented */
#define REFUSED		5	/* query refused */
#define YXDOMAIN	6	/* name exists */
#define YXRRSET		7	/* RRset exists */
#define NXRRSET		8	/* RRset does not exist */
#define NOTAUTH		9	/* Not authoritative for zone */
#define NOTZONE		10	/* Zone of record different from zone section*/
#define BADVERS		16	/* Bad EDNS version             [RFC2671] */
#define BADSIG		16	/* TSIG Signature Failure       [RFC2845] */
#define BADKEY		17	/* Key not recognized           [RFC2845] */
#define BADTIME		18	/* Signature out of time window [RFC2845] */
#define BADMODE		19	/* Bad TKEY Mode                [RFC2930] */
#define BADNAME		20	/* Duplicate key name           [RFC2930] */
#define BADALG		21	/* Algorithm not supported      [RFC2930] */
#define BADTRUNC	22	/* Bad Truncation               [RFC-ietf-dnsext-tsig-sha-05.txt] */


enum {
#define defqtype(val, label) T_##label = val,
#include "dns_qtype.h"
#undef defqtype
CRL_DNS_T_BOGUS /* prevents comma at end of enum list */
};

enum {
#define defqclass(val, label) C_##label = val,
#include "dns_qclass.h"
#undef defqclass
CRL_DNS_C_BOGUS /* prevents comma at end of enum list */
};

enum {
#define defrcode(val, label) R_##label = val,
#include "dns_rcode.h"
#undef defrcode
CRL_DNS_R_BOGUS /* prevents comma at end of enum list */
};

