/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 *
 * $Id: coral_atm.c,v 1.54 2007/06/06 18:17:52 kkeys Exp $
 *
 */

#include "config.h"
#include "coraldefs.h"
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/time.h>
#include <errno.h>

#ifdef HAVE_LIBPCAP
# include <pcap.h>
#endif

#include "libcoral.h"
#include "libcoral_priv.h"


static const char RCSid[] = "$Id: coral_atm.c,v 1.54 2007/06/06 18:17:52 kkeys Exp $";
 
#define only_first(iomode) \
    (!((iomode)->flags & (CORAL_RX_OAM|CORAL_RX_LAST|CORAL_RX_USER_ALL)) && \
    (iomode)->first_n <= ATM_PAYLOAD_SIZE)



/* Compact representation of a "iface:vpi:vci". */
typedef union {
    uint32_t i;
    struct {
#if WORDS_BIGENDIAN
	uint32_t id	:4;
	uint32_t vpvc	:28;
#else
	uint32_t vpvc	:28;
	uint32_t id	:4;
#endif
    } s;
} coral_idvpvc_t;

struct coral_idvpvc_entry {
    coral_idvpvc_t idvpvc;
    coral_pkt_buffer_t *buffer;
    struct coral_idvpvc_entry *next;
};

union coral_pkt_buffer_entry {
    coral_pkt_buffer_t buffer;
    union coral_pkt_buffer_entry *next;
};

static struct coral_idvpvc_entry *coral_idvpvc_list = NULL;
static struct coral_idvpvc_entry *coral_idvpvc_freelist = NULL;
static union  coral_pkt_buffer_entry *coral_pkt_buffer_freelist = NULL;

static uint64_t cell_num = -1; 

coral_proto_rule_list_t coral_proto_rules = { NULL, NULL };

int (*coral_pkt_atm_hook)(const coral_iface_t *iface,
    const coral_pkt_buffer_t *packet, const coral_atm_cell_t *cell) = NULL;


/* Returns 0 if denied, 1 if allowed.  Fills in *protop with protocol. */
/* RFC 1483, 2684: VC Multiplexing of Routed Protocols */
int coral_proto_rule(const coral_iface_t *iface, uint32_t subif,
    coral_protocol_t *protop)
{
    coral_proto_rulenode_t *node;

    *protop = CORAL_PROTO_UNKNOWN;

    for (node = iface->src->proto_rules.head; node; node = node->next) {
	if ((node->rule.subifmask & subif) == node->rule.subif) {
	    *protop = node->rule.protocol;
	    if (!node->rule.allow)
		return 0;
	    goto end;
	}
    }
    for (node = coral_proto_rules.head; node; node = node->next) {
	if ((node->rule.subifmask & subif) == node->rule.subif) {
	    *protop = node->rule.protocol;
	    if (!node->rule.allow)
		return 0;
	    goto end;
	}
    }

end:
    /* No rule or a rule with UNKNOWN means use iface's datalink, and if
     * that's unknown, pick a default based on vpvc. */
    if (*protop == CORAL_PROTO_UNKNOWN) {
	if (iface->iface_info.datalink != CORAL_PROTO_UNKNOWN)
	    *protop = iface->iface_info.datalink;
	else if (subif == 16)		/* af-ilmi-0065.000 */
	    *protop = CORAL_DLT_ILMI;
	else if (subif & 0xFFFFF0)	/* 0:0 thru 0:15 are ATM signalling */
	    *protop = CORAL_DLT_ATM_RFC1483;
    }

    return 1;
}

void coral_dump_rules(coral_proto_rulenode_t *node, int indent)
{
    for ( ; node; node = node->next) {
	coral_printf("%*s%s ", indent, "", node->rule.allow ? "proto" : "deny");
	/* XXX this should be generalized to any subif format */
	coral_printf((get_vpvc_vp(node->rule.subifmask) == 0) ? "*:" : "%d:",
	    get_vpvc_vp(node->rule.subif));
	coral_printf((get_vpvc_vc(node->rule.subifmask) == 0) ? "*" : "%d",
	    get_vpvc_vc(node->rule.subif));
	if (node->rule.allow)
	    coral_printf(" %s", coral_proto_str(node->rule.protocol));
	coral_printf("\n");
    }
}

inline static coral_pkt_buffer_t *new_buffer(void)
{
    coral_pkt_buffer_t *buffer;

    if (coral_pkt_buffer_freelist) {
	buffer = &coral_pkt_buffer_freelist->buffer;
	coral_pkt_buffer_freelist = coral_pkt_buffer_freelist->next;
    } else {
	if (!(buffer = malloc(sizeof(union coral_pkt_buffer_entry))))
	    return NULL;
	/* Start with a buffer large enough to hold normal packets, but not
	 * necessarily max-sized packets.  Reallocate later if needed.  Larger
	 * buffers would waste a lot of memory if a lot of vpvc's are active
	 * simultaneously (especially on corrupt input with bogus vpvc's).
	 */
	buffer->size = 1<<13;
	if (!(buffer->buf = malloc(buffer->size))) {
	    free(buffer);
	    return NULL;
	}
    }

    buffer->is_dynamic = 1;
    buffer->caplen = 0;
    buffer->totlen = 0;
    buffer->passed = 0;
    return buffer;
}

inline static struct coral_idvpvc_entry *find_entry(u_int ifid, uint32_t vpvc)
{
    struct coral_idvpvc_entry *entry, *prev = NULL;
    coral_idvpvc_t idvpvc;

    idvpvc.s.id = ifid;
    idvpvc.s.vpvc = vpvc;

    for (entry = coral_idvpvc_list; entry; prev = entry, entry = entry->next) {
	if (entry->idvpvc.i == idvpvc.i) {
	    if (prev) {
		/* move most-recently-used entry to front of list */
		prev->next = entry->next;
		entry->next = coral_idvpvc_list;
		coral_idvpvc_list = entry;
	    }
	    return entry;
	}
    }
    return NULL;
}

/* prepare an entry to start reassembling */
inline static struct coral_idvpvc_entry *new_entry(u_int ifid, uint32_t vpvc)
{
    struct coral_idvpvc_entry *entry;

    if (coral_idvpvc_freelist) {
	entry = coral_idvpvc_freelist;
	coral_idvpvc_freelist = coral_idvpvc_freelist->next;
    } else if (!(entry = malloc(sizeof(*entry)))) {
	return NULL;
    }

    entry->idvpvc.s.id = ifid;
    entry->idvpvc.s.vpvc = vpvc;
    entry->buffer = NULL;
    entry->next = coral_idvpvc_list;
    coral_idvpvc_list = entry;
    return entry;
}

inline static void free_buffer(coral_pkt_buffer_t *buffer)
{
    ((union coral_pkt_buffer_entry*)buffer)->next = coral_pkt_buffer_freelist;
    coral_pkt_buffer_freelist = (union coral_pkt_buffer_entry*)buffer;
}

/* make vpvc entry ready to start reassembling a new packet */
inline static void reset_entry(struct coral_idvpvc_entry *entry)
{
    free_buffer(entry->buffer);
    entry->buffer = NULL;
}

/* remove entry, since it's not in start state and not reassembling */
inline static void free_entry(struct coral_idvpvc_entry *entry)
{
    struct coral_idvpvc_entry **pnp;

    for (pnp = &coral_idvpvc_list; *pnp; pnp = &(*pnp)->next) {
	if (*pnp == entry) {
	    break;
	}
    }

    if (entry->buffer) reset_entry(entry);
    *pnp = entry->next;
    entry->next = coral_idvpvc_freelist;
    coral_idvpvc_freelist = entry;
}

void coral_atm_consume_pkt(coral_iface_t *iface)
{
    if (iface->statedata)
	reset_entry(iface->statedata);
    iface->statedata = NULL;
}

/* atm_hdr should be in HOST byte order */
/* Does not set pkt->protocol. */
static inline void coral_hostcell_to_pkt(const coral_iface_t *iface,
    union atm_hdr atm_hdr, const char *payload, coral_pkt_buffer_t *pkt)
{
    aal5_trailer_t *aal5_trailer;
    int length;

    pkt->buf = payload;

    /* default length, if there is no AAL5 trailer */
    pkt->totlen = -1;
    /* The last 7 bytes might be padding, or might be real data.
     * We give it all to the user, and let him decide based on
     * the higher layer protocols.
     */
    pkt->caplen = ATM_PAYLOAD_SIZE;

    if (atm_hdr.h.sdu_type) {
	/* last cell, so get length from AAL5 trailer */
	aal5_trailer = (aal5_trailer_t *)(pkt->buf + ATM_PAYLOAD_SIZE -
	    sizeof(aal5_trailer_t));
	length = ntohs(aal5_trailer->length);

	/* if length actually fits in cell */
	if (length <= ATM_PAYLOAD_SIZE - sizeof(aal5_trailer_t) &&
	/* and trailer was not artificially zero'd (by a sanitizer) */
	    (aal5_trailer->cpcs_uu || aal5_trailer->cpi ||
	    aal5_trailer->length || aal5_trailer->crc))
	{
	    /* use the length from the trailer */
	    pkt->caplen = pkt->totlen = length;
	}
    }
    pkt->parent_proto = CORAL_PROTO_UNKNOWN;
}

/* cell's atm header should be in NETWORK byte order */
int coral_cell_to_pkt(const coral_iface_t *iface, coral_atm_cell_t *cell,
    coral_pkt_buffer_t *pkt)
{
    union atm_hdr atm_hdr;
    int allow;

    atm_hdr.ui = ntohl(coral_cell_header_req(iface, cell)->ui);
    coral_hostcell_to_pkt(iface, atm_hdr, coral_cell_payload_req(iface, cell),
	pkt);

    allow = 1;
    pkt->protocol = CORAL_PROTO_UNKNOWN;

    if (iface)
	allow = coral_proto_rule(iface, atm_hdr.h.vpvc, &pkt->protocol);

    return allow;
}

static inline int coral_atm_pkt_filter(coral_iface_t *iface,
    coral_pkt_buffer_t *pktbuf, coral_atm_cell_t *cell)
{
    if (coral_pkt_atm_hook && !coral_pkt_atm_hook(iface, pktbuf, cell)) {
	return 0;
    }

#ifdef HAVE_BPF_FILTER
    if (iface->prebpfprog && !coral_pkt_filter(iface, iface->internal_pcap,
	iface->prebpfprog, pktbuf))
    {
	return 0;
    }
#endif
	
    return 1;
}

#ifdef HAVE_LIBPCAP
# define has_filter(iface)	(coral_pkt_atm_hook || (iface)->prebpfprog)
#else
# define has_filter(iface)	(coral_pkt_atm_hook)
#endif

/* NB: uses atm_hdr and cell_num from calling scope */
#define cell_diag(level, args) \
    do { \
        if ((level) <= coral_verbosity) { \
	    char buf[16]; \
	    coral_printf("cell %" PRIu64 " on ", cell_num); \
	    coral_fmt_if_subif(buf, iface, atm_hdr.h.vpvc); \
	    coral_printf("%s ", buf); \
            coral_printf args; \
	} \
    } while (0)

/* Reassemble cell onto packet.  If pkt is as complete as possible, returns 1
 * with info in iface->packetbuf; if no pkt was complete, returns 0; if an
 * error is found, returns -1.
 */
int coral_aal5_reassemble(coral_iface_t *iface, coral_atm_cell_t *cell,
    coral_pkt_result_t *pkt_result)
{
    struct coral_idvpvc_entry *entry;
    coral_pkt_buffer_t *buffer;
    aal5_trailer_t *aal5_trailer;
    const coral_io_mode_t *iomode;
    int nominal_len;		/* # of bytes according to aal5 trailer */
    int nominal_cells;		/* # of cells according to aal5 trailer */
    int actual_cells;		/* # of cells actually captured */
    int mode_cells;		/* max # of cells allowed by iomode->first_n */
    coral_protocol_t datalink;
    union atm_hdr atm_hdr;

    const union atm_hdr *const cu = coral_cell_header_req(iface, cell);
    const char *const payload = coral_cell_payload_req(iface, cell);
    const coral_timestamp_t *const timestamp = coral_cell_time_req(iface, cell);

    /* re-order bytes of ATM header */
    atm_hdr.ui = ntohl(cu->ui);
    cell_num++;

#if 0
    /* check for measurement corruption here */
    if (0) {
	iface->pkt_stats.driver_corrupt++;
	return 0;
    }
#endif

    /* we only want user cells, not network OAM/RM cells */
    if (atm_hdr.h.oam_rm) {
	cell_diag(22, ("rejected: OAM/RM\n"));
	return 0;
    }

    if (!coral_proto_rule(iface, atm_hdr.h.vpvc, &datalink)) {
	cell_diag(23, ("rejected by 'deny' rule\n"));
	return 0;
    }

    if (only_first(&iface->iface_info.iomode)) {
	/* we're only receiving first cells, so we can avoid a copy */
	entry = NULL;
	buffer = &iface->packetbuf;
	coral_hostcell_to_pkt(iface, atm_hdr, payload, buffer);
	buffer->is_dynamic = 0;
	buffer->protocol = datalink;
	if (has_filter(iface)) {
	    if (coral_atm_pkt_filter(iface, buffer, cell) <= 0) {
		cell_diag(23, ("rejected by hook/filter\n"));
		return 0;
	    }
	}
	if (buffer->caplen < 0) {
	    iface->pkt_stats.aal5_trailer++;
	    cell_diag(22, ("discarded: invalid (caplen < 0)\n"));
	    return 0;
	}

	if (atm_hdr.h.sdu_type) {
#if 0 /* These were set in coral_init_atm_iface() and never change */
	    iface->trailerbuf.protocol = CORAL_DLT_ATM_AAL5;
	    iface->trailerbuf.is_dynamic = 0;
#endif
	    iface->trailerbuf.buf = payload +
		ATM_PAYLOAD_SIZE - sizeof(aal5_trailer_t);
	    iface->trailerbuf.totlen = iface->trailerbuf.caplen =
		sizeof(aal5_trailer_t);
	    pkt_result->trailer = &iface->trailerbuf;
	} else {
	    iface->pkt_stats.truncated++;
	    if (!(coral_config.flags & CORAL_OPT_PARTIAL_PKT)) {
		cell_diag(24, ("discarded: truncated\n"));
		return 0;
	    }
	    pkt_result->trailer = NULL;
	}

    } else {
	entry = find_entry(iface->id, atm_hdr.h.vpvc);

	if (!entry) {
	    iomode = &iface->iface_info.iomode;
	    if (
		/* only first cells were captured? */
		/* (only_first(iomode)) || */ /* this was caught above */
		/* or, first cell of a POINT capture? */
		/* (POINT records contain cell number) */
		(iface->iface_info.hw_type == CORAL_TYPE_POINT &&
		((u_char*)cell)[0] == 0))
	    {
		/* This is a first cell, so we can start now */
		entry = new_entry(iface->id, atm_hdr.h.vpvc);
		if (!entry) {
		    iface->pkt_stats.too_many_vpvc++;    /* total */
		    cell_diag(0, ("discarded: vpvc overflow\n"));
		    return 0;
		}

	    } else if (atm_hdr.h.sdu_type) {   /* last cell of packet? */
		/* This is a last cell, so we can start at the next cell */
		entry = new_entry(iface->id, atm_hdr.h.vpvc);
		if (!entry)
		    iface->pkt_stats.too_many_vpvc++;    /* total */
		cell_diag(24, ("discarded: last\n"));
		return 0;
	    } else {
		/* We don't know where this cell belongs, skip it. */
		cell_diag(24, ("discarded: unknown\n"));
		return 0;
	    }
	}

	if (!entry->buffer) {
	    if (has_filter(iface)) {
		/* first cell of PDU, and there's a filter */
		coral_hostcell_to_pkt(iface, atm_hdr, payload,
		    &iface->packetbuf);
		iface->packetbuf.is_dynamic = 0;
		iface->packetbuf.protocol = datalink;
		if (!coral_atm_pkt_filter(iface, &iface->packetbuf, cell)) {
		    cell_diag(23, ("rejected by hook/filter\n"));
		    if (!atm_hdr.h.sdu_type)	/* not last cell of pdu? */
			free_entry(entry);
		    return 0;
		}
	    }

	    entry->buffer = new_buffer();
	    if (!entry->buffer) {
		iface->pkt_stats.too_many_vpvc++;    /* concurrent */
		free_entry(entry);
		cell_diag(0, ("discarded: vpvc overflow\n"));
		return 0;
	    }
	    entry->buffer->protocol = datalink;
	}
	buffer = entry->buffer;

	/* make sure there's enough room in the buffer. */
	if (buffer->caplen + ATM_PAYLOAD_SIZE <= buffer->size) {
	    /* append this cell's payload to buffer. */
	    memcpy((char*)buffer->buf + buffer->caplen,
		   payload, ATM_PAYLOAD_SIZE);
	    buffer->caplen += ATM_PAYLOAD_SIZE;
	} else if (buffer->caplen + ATM_PAYLOAD_SIZE <= MAX_PACKET_SIZE &&
	    (buffer->buf = realloc((char*)buffer->buf, MAX_PACKET_SIZE)))
	{
	    buffer->size = MAX_PACKET_SIZE;
	    coral_diag(1, ("reallocated packet buffer\n"));
	    /* append this cell's payload to buffer. */
	    memcpy((char*)buffer->buf + buffer->caplen,
		   payload, ATM_PAYLOAD_SIZE);
	    buffer->caplen += ATM_PAYLOAD_SIZE;

	} else if (!(coral_config.flags & CORAL_OPT_PARTIAL_PKT)) {
	    iface->pkt_stats.buffer_overflow++;
	    free_entry(entry);
	    cell_diag(0, ("discarded: buffer overflow\n"));
	    return 0;
	}
	buffer->totlen += ATM_PAYLOAD_SIZE;

	iomode = &iface->iface_info.iomode;
	actual_cells = buffer->caplen / ATM_PAYLOAD_SIZE;
	mode_cells = divup(iomode->first_n, ATM_PAYLOAD_SIZE);

	/* Check for end of packet, indicated by AAL5 last cell bit. */
	if (atm_hdr.h.sdu_type) {
	    aal5_trailer = (aal5_trailer_t *)(buffer->buf + buffer->caplen -
					      sizeof(aal5_trailer_t));
	    /* if trailer was not artificially zero'd (by a sanitizer),
	     * use its length */
	    if (aal5_trailer->length || aal5_trailer->crc ||
		aal5_trailer->cpcs_uu || aal5_trailer->cpi)
	    {
		nominal_len = ntohs(aal5_trailer->length);
		nominal_cells = (nominal_len + sizeof(aal5_trailer_t) - 1) /
		    ATM_PAYLOAD_SIZE + 1;

		if (actual_cells == nominal_cells) {
		    /* no problem */
		    buffer->caplen = nominal_len;
		} else if (!(iomode->flags & CORAL_RX_USER_ALL) &&
		    iomode->flags & CORAL_RX_LAST &&
		    actual_cells < nominal_cells &&
		    actual_cells == mode_cells + 1)
		{
		    /* There's a gap due to iomode.  Must drop last cell. */
		    buffer->caplen -= ATM_PAYLOAD_SIZE;
		    actual_cells--;
		} else {
		    /* invalid (corrupt trailer, splice, or loss) */
		    iface->pkt_stats.aal5_trailer++;
		    reset_entry(entry);
		    cell_diag(22, ("discarded: invalid (corrupt 1)\n"));
		    return 0;
		}
		buffer->totlen = nominal_len;

#if 0
		if (buffer->caplen < nominal_len) {
		    /* we stopped buffering early */
		} else if (buffer->caplen > nominal_len) {
		    /* zero the padding */
		    memset(buffer->buf + nominal_len, '\0', buffer->caplen - nominal_len);
		    /* truncate the padding */
		    buffer->caplen = nominal_len;
		}
#endif

	    } else {
		if (actual_cells <= mode_cells) {
		    /* no problem */
		} else if (!(iomode->flags & CORAL_RX_USER_ALL) &&
		    iomode->flags & CORAL_RX_LAST &&
		    actual_cells == mode_cells + 1)
		{
		    /* There may be a gap due to iomode.  Drop last cell. */
		    buffer->caplen -= ATM_PAYLOAD_SIZE;
		    actual_cells--;
		} else {
		    /* invalid (corrupt trailer, splice, or loss) */
		    iface->pkt_stats.aal5_trailer++;
		    reset_entry(entry);
		    cell_diag(22, ("discarded: invalid (corrupt 2)\n"));
		    return 0;
		}
		buffer->totlen = -1;  /* unknown */
	    }

	    cell_diag(24, ("used: last\n"));

#if 0 /* These were set in coral_init_atm_iface() and never change */
	    iface->trailerbuf.protocol = CORAL_DLT_ATM_AAL5;
	    iface->trailerbuf.is_dynamic = 0;
#endif
	    iface->trailerbuf.buf = payload +
		ATM_PAYLOAD_SIZE - sizeof(aal5_trailer_t);
	    iface->trailerbuf.totlen = iface->trailerbuf.caplen =
		sizeof(aal5_trailer_t);
	    pkt_result->trailer = &iface->trailerbuf;

	/* Check for packet truncated by insufficient capture. */
	} else if (!(iomode->flags & (CORAL_RX_USER_ALL)) &&
	    actual_cells >= mode_cells)
	{
	    if (actual_cells > mode_cells) {
		/* impossible */
		free_entry(entry);
		cell_diag(22, ("discarded: impossible\n"));
		return 0;
	    }
	    if (iomode->flags & CORAL_RX_LAST) {
		/* We got the mode_cells, now wait for the last cell. */
		cell_diag(24, ("discarded: waiting for last\n"));
		return 0;
	    }
	    iface->pkt_stats.truncated++;
	    if (!(coral_config.flags & CORAL_OPT_PARTIAL_PKT)) {
		free_entry(entry);
		cell_diag(24, ("discarded: truncated\n"));
		return 0;
	    }
	    /* The last 7 bytes might be padding, or might be real data.
	     * We give it all to the user, and let him decide based on
	     * the higher layer protocols.
	     */
	    /* buffer->caplen -= (sizeof(aal5_trailer_t) - 1); */
	    buffer->totlen = -1; /* unknown */
	    pkt_result->trailer = NULL;
	    cell_diag(24, ("used: truncated\n"));

	/* Packet is incomplete, and there are more cells available. */
	} else {
	    cell_diag(24, ("used: nonlast\n"));
	    return 0;
	}
    }

#if 0 /* These were set in coral_init_atm_iface() and never change */
    iface->headerbuf.protocol = CORAL_PHY_ATM;
    iface->headerbuf.is_dynamic = 0;
#endif
    iface->headerbuf.buf = (char*)cu;
    iface->headerbuf.totlen = 5; /* full ATM header including HEC */
    iface->headerbuf.caplen = 4; /* ATM header without HEC */

    /* everything checked out ok, return packet */
    iface->pkt_stats.pkts_recv++;
    iface->pkt_stats.ok_packet++;
    iface->statedata = entry;

    pkt_result->subiface = atm_hdr.h.vpvc;
    pkt_result->timestamp = timestamp;
    pkt_result->packet = buffer;
    pkt_result->header = &iface->headerbuf;

    return 1;
}

void coral_init_atm_iface(coral_iface_t *iface)
{
    iface->headerbuf.protocol = CORAL_PHY_ATM;
    iface->headerbuf.is_dynamic = 0;

    iface->trailerbuf.protocol = CORAL_DLT_ATM_AAL5;
    iface->trailerbuf.is_dynamic = 0;
}

/* generic close function for atm ifaces */
void coral_atm_iface_close(coral_iface_t *iface)
{
    struct coral_idvpvc_entry *entry, *next;

    for (entry = coral_idvpvc_list; entry; entry = next) {
	next = entry->next;
	if (entry->idvpvc.s.id == iface->id)
	    free_entry(entry);
    }
}

