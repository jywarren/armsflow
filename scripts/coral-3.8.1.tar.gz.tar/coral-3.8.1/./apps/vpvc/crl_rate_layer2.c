/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 * $Id: crl_rate_layer2.c,v 1.36 2007/06/06 18:17:37 kkeys Exp $
 *
 */


static const char RCSid[]="$Id: crl_rate_layer2.c,v 1.36 2007/06/06 18:17:37 kkeys Exp $";

#include "config.h"
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <sys/time.h>
#include <sys/errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <signal.h>
#include <errno.h>
#include <netinet/in.h>	/* for htonl() */

#include "libcoral.h"
#include "hashtab.h"

static uint64_t if_cells_lost[CORAL_MAXOPEN];

static void quit(int arg) {
    fprintf(stderr, "got sig %d ", arg);
    coral_pkt_done = 1;
}

#define HASH_TABLE_SIZE 1021
#define ATM_CELL_SIZE 53
#define HUMAN_FORMAT

typedef struct {
    coral_iface_t *iface;
    u_int iface_id;
    u_int subif_id;
    uint64_t cells;
} subif_stats;

/* called for each block */
static void block_stats(const coral_iface_t *iface,
			const coral_blk_info_t *binfo)
{
    if_cells_lost[coral_interface_get_number(iface)] +=
						    ntohl(binfo->cells_lost);
}

/* called for each packet.
 * ups the respective counters.
 * returns -1 on failure, 0 on success.
 */
static int count_subif_stats(hash_tab *ht, coral_iface_t *iface, u_int subif)
{
    subif_stats *rec;
    subif_stats tmp;

    tmp.iface = iface;
    tmp.iface_id = coral_interface_get_number(iface);
    tmp.subif_id = subif;

    if ((rec = (subif_stats*)find_hash_entry(ht, &tmp))) {
	rec->cells++;
    } else {
	rec = malloc(sizeof(subif_stats));

	if (rec == NULL) {
	    fprintf(stderr, "can't malloc subif_stats.\n");
	    return -1;
	}
	*rec = tmp;
	rec->cells = 1;
	add_hash_entry(ht, rec);
    }
    return 0;
}

static void dump_subif_stats(hash_tab *ht, coral_interval_result_t *int_result)
{
    const subif_stats *rec;
    uint64_t total = 0;
    int i;
    double interval = int_result->end.tv_sec - int_result->begin.tv_sec +
	0.000001 * (int_result->end.tv_usec - int_result->begin.tv_usec);

    init_hash_walk(ht);
    
    fprintf(stdout, "# subif/cells @ time %ld.%.06ld to %ld.%.06ld (%.6f s)\n",
	int_result->begin.tv_sec, int_result->begin.tv_usec,
	int_result->end.tv_sec, int_result->end.tv_usec, interval);

    for (i = 0; i < CORAL_MAXOPEN; i++) {
	if (if_cells_lost[i]) {
	    fprintf(stdout, "# %" PRIu64 " cells lost on interface %d\n",
		    if_cells_lost[i], i);
	}
    }

#ifdef HUMAN_FORMAT
    fprintf(stdout, "# if[subif]       cells     Mbit/s\n");
#else
    fprintf(stdout, "# if[subif]\tcells\tMbit/s\n");
#endif

    while ((rec = next_hash_walk(ht))) {
	char buffer[100];

	coral_fmt_if_subif(buffer, rec->iface, rec->subif_id);
	fprintf(stdout,
#ifdef HUMAN_FORMAT
		"%-12s %10" PRIu64 " %10.4f\n",
#else
		"%s\t%" PRIu64 "\t%.4f\n",
#endif
		buffer, rec->cells,
		((double) rec->cells * ATM_CELL_SIZE * 8 / 1000000) / interval);
	total += rec->cells;
    }

    fprintf(stdout,
#ifdef HUMAN_FORMAT
	   "%-12s %10" PRIu64 " %10.4f\n",
#else
	    "%s\t%" PRIu64 "\t%.4f\n",
#endif
	    "TOTAL",
	    total,
	    ((double) total * 53 * 8 / 1000000) / interval);
    fflush(stdout);

    clear_hash_table(ht);
    bzero(if_cells_lost, sizeof(uint64_t)*CORAL_MAXOPEN);
    if (total_hash_entries())
	fprintf(stderr, "error clearing ht, #entries: %d\n",
		(int)total_hash_entries());
}

/* return 0 if the same - for use by the hashtable */
static int compare_subif_stats(const void *entry1, const void *entry2)
{
    const subif_stats *foo1 = entry1;
    const subif_stats *foo2 = entry2;

    return (foo1->subif_id != foo2->subif_id ||
            foo1->iface_id != foo2->iface_id);
}

/* make a hash of an entry - for use by the hashtable */
static unsigned long make_key_subif_stats(const void *entry)
{
    const subif_stats *what = entry;

    return (unsigned) what->subif_id * 425879 + what->iface_id;
}

/* free mem of an entry - for use by the hashtable */
static void delete_subif_stats(void *entry)
{
    subif_stats *what = entry;

    if (!what) return;

    free(what);
}

int main(int argc, char *argv[])
{
    hash_tab *subifhash;
    long count = 0;

    coral_atm_cell_t *cell;
    coral_iface_t *iface;
    struct timeval interval = { 60, 0 };
    union atm_hdr cell_atm;
    coral_interval_result_t int_result;
    coral_source_t *src, *nextsrc;

    coral_cell_block_hook = block_stats;

    coral_set_api(CORAL_API_CELL);
    coral_set_interval(&interval);  /* default */
    coral_set_duration(0);
    coral_set_iomode(0, CORAL_RX_USER_ALL, 1, 1);

    if (coral_config_arguments(argc, argv) < 0)
	exit(1);

    subifhash = init_hash_table("# src dst pkt and byte counter",
				compare_subif_stats, make_key_subif_stats,
				delete_subif_stats, HASH_TABLE_SIZE);

    if (coral_open_all() <= 0)
	exit(1);

    if (coral_start_all() < 0)
	exit(1);

    signal(SIGINT, quit);
    signal(SIGTERM, quit);

    if (coral_get_interval(&interval) >= 0)
	coral_diag(2, ("collection interval set to %ld.%06ld second(s)\n",
	    interval.tv_sec, interval.tv_usec));

    nextsrc = NULL;
    for (src = coral_next_source(NULL); src; src = nextsrc) {
	nextsrc = coral_next_source(src);
	iface = coral_next_src_iface(src, NULL);
	if (coral_interface_get_physical(iface) != CORAL_PHY_ATM) {
	    coral_diag(0, ("%s: %s is not an ATM source, ignoring it.\n",
		argv[0], coral_source_get_filename(src)));
	    coral_close(src);
	}
    }

    bzero(if_cells_lost, sizeof(uint64_t)*CORAL_MAXOPEN);

    while (1) {
	iface = coral_read_cell_all_i(NULL, &cell, &int_result, &interval);
	
	if (!iface) {
	    if (errno == EINTR) continue;
	    exit(errno);
	}

	if (!cell) {
	    dump_subif_stats(subifhash, &int_result);
	    continue;
	}
	count++;

	/* record this cell */
	cell_atm.ui = ntohl(coral_cell_header(iface, cell)->ui);
	count_subif_stats(subifhash, iface, cell_atm.h.vpvc);
    }

    coral_stop_all();
    fprintf(stderr, "\n.... done ....\n");
    /* dump_hashtab_stats(subifhash); */
    return 0;
}
