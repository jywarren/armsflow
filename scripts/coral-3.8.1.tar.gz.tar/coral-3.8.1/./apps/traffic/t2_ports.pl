#!/usr/local/bin/perl
## 
## Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
## All Rights Reserved 
## 
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
## 
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
## 
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
## 
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
## 
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program. Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
## 
## Report bugs and suggestions to coral-bugs@caida.org.
## 

#use Graph;
use FileHandle;
use Getopt::Std;

#This script shows the distribution of ports usage per vpvvc on
#a Coral box.  The format of the output is:
#Mbit/s and Kpackets/s
#it should be run on streams or files that were generated from crl_traffic2
#program.
# written by jambi bigj@caida.org
# if you break this script you get to keep both pieces.


getopts("s", \%opts);
if ($opts{'s'}) {
   $summ = 1;
   $notfirst = 0;
   $counter =0;
}
my $infilel;
$infile = $ARGV[0];
autoflush STDOUT 1;
$i = 0;
open (INFILE, "<$infile") || die "could not open file $infile: $!";
    while ($line = <INFILE>) {
        next if ($line =~ /^\s+$/); 
        
	if ($line =~ /^#\s+trace/) {  ##We are reading in a single time block
	    ($interval) = ($line =~ /(\d+\.\d+)/);
	    if ($summ) {
	       foreach my $key (sort {$total_per_inter{$b} <=> $total_per_inter{$a}} keys (%total_per_inter)) {
	           $i++;
		   if ($i < 11) {
	               print ("dport $key=$total_per_inter{$key} bytes\n");
                   } else { last;}
               }
	       $i = 0;
	       %total_per_inter = ();
	    }	
	    print "---------------------------------------\n";
	}
        if ($line =~ /^#\s+for/) {
           ($pair) = ($line =~ /(\d+:\d+)/);
        }
	if ($line =~ /^#\s+?bytes/) {
	    ($tot_bytes) = ($line =~ /(\d+)$/);
        }
	if ($line =~ /^#\s+?pkts/) {
	    ($tot_pkts) = ($line =~ /(\d+)$/);
        }  
	
	if ($line =~ /^#\s+end/) {
	   #do_html (\%goo, $tot_bytes);
	   if (!$summ) {
           foreach my $vpvc (keys %goo) {
	       print "[1;33m$vpvc[0m\t";
	       foreach my $dport (sort {$a <=> $b} keys %{ $goo{$vpvc} } ) {
		   my $percent = (($goo{$vpvc}{$dport}) /$tot_bytes ) *100;
		   next if ($percent < 1); #for ports it's a must
                   
		   if ($percent > 90) {  
	               print "[1;31m$dport=";
		       printf ("[1;31m%.2f\% ",$percent);
		       printf ("%.f Bytes", $goo{$vpvc}{$dport});
		       printf (" %.f b/s ", ($goo{$vpvc}{$dport})/$interval);
		       printf ("[0m");
                   } else {
	               print "$dport=";
		       printf ("%.2f\% ", $percent);
		   }
               }
	   print "\n";
           }
        }
       %goo = (); ##zero out our hash so we can start a new output
       $tot_bytes = 0;
       }
	next if ($line =~ /^#/); #skip comments
       ($src, $dst, $proto, $ok, $sport, $dport, $pkts, $bytes) =
	                                               split /\s+/, $line;
       
       $goo{$pair}{$sport} += $bytes;
       if ($summ) {
           $total_per_inter{$sport} += $bytes;
       } 

    
    } ##end while readin.
close (INFILE);

###########################################################################
##routines                                                                #
###########################################################################

sub do_html {
    my ($dataref, $tot_bytes) = @_;
    my $html_file = "coral_report.html";
    if (-e $html_file) {
        unlink $html_file;
    }
    open (OUT, ">$html_file") or die "could not open $html_file:$!";
    print OUT "<html>\n";
    print OUT "<head><title>Report for CoralReef</title></head>\n";
    print OUT "<body bgcolor=FFFFFF>\n";
    
    foreach my $vpvc (keys %$dataref) {
        print OUT "$vpvc\t";
        foreach my $proto (sort {$a <=> $b} keys %{ $dataref->{$vpvc} } ) {
            print OUT "$proto="; 
	    printf OUT ("%.2f",( ($dataref->{$vpvc}{$proto}) /$tot_bytes ) *100);
            print OUT "%\t";
        }
        print OUT "\n";
    }
   print OUT "</body></html>\n";
   close OUT;
}    
