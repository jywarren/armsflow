/* 
 * Copyright 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 *
 * $Id: crl_to_pcap.c,v 1.51 2007/06/06 18:17:32 kkeys Exp $
 *
 */

#include "config.h"
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <signal.h>
#include <errno.h>

#ifndef CAN_CONVERT_TO_PCAP
int main(int argc, char *argv[])
{
    fprintf(stderr, "%s requires pcap_open_dead() or <pcap-int.h>, "
	"which were not available when CoralReef was installed.\n",
	argv[0]);
    return -1;
}
#else

#include <pcap.h>
#include "libcoral.h"

static coral_rf_info_pcap_dump_t pdinfo;
static int64_t pkt_count = -1;
static int64_t n_start = 0, n_end = -1;
static double t_start = -1, t_end = -1;
static int trunc_layer = 0;
static int trunc_keep = 0;
static int trunc_payload = 0;

static void quit(int sig)
{
    coral_pkt_done = 1;
}

static void pkthandler(coral_iface_t *iface, const coral_timestamp_t *timestamp,
    void *userdata, coral_pkt_buffer_t *pkt, coral_pkt_buffer_t *header,
    coral_pkt_buffer_t *trailer)
{
    pkt_count++;
    if (pkt_count < n_start)
	return;
    if (n_end >= 0 && pkt_count > n_end) {
	coral_pkt_done = 1;
	return;
    }
    if (t_start > 0 || t_end >= 0) {
	double t = coral_read_clock_double(iface, timestamp);
	if (t_start > 0 && t < t_start)
	    return;
	if (t_end >= 0 && t > t_end) {
	    coral_pkt_done = 1;
	    return;
	}
    }

    if (trunc_layer)
	coral_pkt_truncate(pkt, trunc_layer, !trunc_keep, trunc_payload);

    coral_write_pkt_to_pcap(iface, timestamp, pkt, userdata,
	pdinfo.pcap_dumper);
}

static void usage(const char *name)
{
    coral_usage(name, "[<options>] <source>...\n"
	"Options:\n"
	"-o<file>     dump matches to <file> in pcap binary format (default: stdout)\n"
	"-i<N>        read from interface <N> (default: 0)\n"
	"-r           write raw IP, discarding link layer\n"
	"-f \"<expr>\"  pcap filter expression (same as -C\"filter <expr>\")\n"
	"-n<n>        read only packets with number >= <n>\n"
	"-N<n>        read only packets with number <= <n>\n"
	"-t<t>        read only packets with timestamp >= <t>\n"
	"-T<t>        read only packets with timestamp <= <t>\n"
	"-l<n>        copy only up to protocol layer <n>, and discard unknown protocols\n"
	"-k           with -l, keep unknown protocols\n"
	"-p<n>        copy <n> bytes of payload of layer specified in -l option (default: 0)\n"
	"\n"
	"If a nonzero interval is given and the output filename contains '%%',\n"
	"the output file will rotate every interval.\n");
}

int main(int argc, char *argv[])
{
    int retval = 0;
    int n, opt;
    const char *ofname = NULL;
    coral_iface_t *iface;
    int iface_id = -1;
    int raw = 0;
    coral_rotfile_t *rf;
    struct timeval interval = {0,0}; /* for file rotation */

    signal(SIGINT, quit);

    coral_set_api(CORAL_API_PKT|CORAL_API_WRITE);
#if 0
    coral_set_max_sources(1);  /* There can be only one */
#endif

    /* If you want only full captures, override on command line */
    coral_set_options(0, CORAL_OPT_PARTIAL_PKT | CORAL_OPT_SORT_TIME);

    coral_set_duration(0);
    coral_set_interval(&interval);
    /*coral_set_iomode(0, CORAL_RX_USER_ALL, -1);*/

    while ((opt = getopt(argc, argv, "C:o:f:i:rn:N:t:T:l:kp:")) >= 0) {
	switch (opt) {
        case 'C':
            if (coral_config_command(optarg) < 0)
                exit(-1);
	    break;
        case 'o':
	    ofname = strdup(optarg);  break;
        case 'f':
	    coral_add_pcap_filter(optarg);  break;
        case 'i':
	    iface_id = atoi(optarg);  break;
        case 'r':
	    raw = 1;  break;
	case 'n':
	    n_start = atoi(optarg);  break;
	case 'N':
	    n_end = atoi(optarg);  break;
	case 't':
	    t_start = atof(optarg);  break;
	case 'T':
	    t_end = atof(optarg);  break;
	case 'l':
	    trunc_layer = atoi(optarg);  break;
	case 'k':
	    trunc_keep = 1;  break;
	case 'p':
	    trunc_payload = atoi(optarg);  break;
        default:
            usage(argv[0]);
            exit(-1);
        }
    }

    while (optind < argc) {
        if (!coral_new_source(argv[optind]))
            exit(-1);
        optind++;
    }

    if ((n = coral_open_all()) < 0)
        exit(-1);
    if (n == 0) {
	coral_diag(0, ("no sources.\n"));
	exit(0);
    }

    coral_get_interval(&interval);

    iface = coral_next_interface(NULL);
    if (iface_id >= 0) {
	while (iface && coral_interface_get_number(iface) != iface_id)
	    iface = coral_next_interface(iface);
	if (!iface) {
	    coral_diag(0, ("iface %d not found\n", iface_id));
	    exit(-1);
	}
    }

    if (coral_start_all() < 0)
        exit(-1);

    if (!ofname)
	ofname = "-";
    pdinfo.pcap = raw ? coral_iface_to_pcapp_raw(iface) :
	coral_iface_to_pcapp(iface);
    if (!pdinfo.pcap)
	exit(-1);

    rf = coral_rf_open_pcap_dump(&pdinfo, ofname, "", CORAL_ROT_AUTO);
    if (!rf)
	exit(-1);

    if (coral_read_pkts(NULL, iface_id >= 0 ? iface : NULL, pkthandler,
	NULL, NULL, &interval, pdinfo.pcap) < 0)
	    retval = errno;

    coral_rf_close(rf);
    coral_stop_all();
    coral_close_all();

    exit(retval);
}

#endif /* HAVE_PCAP_INT_H */
