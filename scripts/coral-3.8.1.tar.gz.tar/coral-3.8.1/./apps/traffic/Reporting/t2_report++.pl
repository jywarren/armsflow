#! /usr/local/bin/perl5
## $Id: t2_report++.pl,v 1.166 2007/06/06 18:17:35 kkeys Exp $ $Name: release-3-8-1 $
## -------------------------------------------------------------------
## Traffic2 to HTML report generator.
##
## This Perl application takes data from the crl_flow program
## which pulls data from Internet traffic monitors and generates
## HTML reports on the performance of traffic links and data on 
## the sources of Internet traffic at different levels of analysis.
## Graphing facilities are provided using various tools and data
## can be archived using the RRDtool.
##
## This version of t2_report.pl uses the GD::Graph Perl 
## module to create PNG images.  This module depends in turn on 
## GD Perl and C package to create the graphics file.  Due to 
## patent disputes, the GIF format is being replaced by the open
## standard PNG format.  Beginning with CoralReef 3.4.x, we will only support 
## PNG file generation.  Users needing GIF files should either use commercial
## file converts or stick with CoralReef 3.3.x
##
## This temporary variant moves the graphing faculties into a new
## mediating module: Traffic_plot.pm.  This module will finess 
## the multiple tools which can be used to create graphs.  The long
## term goal is to use the module installation process resolve 
## which graphing options are available and warn the user of 
## what software they may wish to install.
##
## REQUIRES the following Perl modules which should have been included
## in this distribution:
##    CAIDA::Traffic2::Encode
##    CAIDA::Traffic2::FlowCounter
##    CAIDA::Traffic2::CustomBaseHTML
##    CAIDA::Traffic2::FileReader 
##    CAIDA::Traffic2::Interval 
##    CAIDA::Tables::AS_Table.pm
##    CAIDA::Tables::Country_Table.pm
##    CAIDA::Tables::Generic.pm
##    CAIDA::Tables::IP_Table.pm
##    CAIDA::Tables::Proto_Table.pm
##    CAIDA::Tables::Tuple_Table.pm
##    CAIDA::Tables::VPVC_Table.pm
##    Traffic::Vpvc modules
##
## To use the AS features you must have the ASfinder.pm module installed
## which is part of the CoralReef distribution.
##
## To the Geography features, you must have the NetGeoClient installed
## which is part of the CoralReef distribution.
##
## To use the Round Robin Databases, you must have the RRDtool installed.
## It does not come with CoralReef, but is available without cost from 
## Caida.  Visithttp://ee-staff.ethz.ch/~oetiker/webtools/rrdtool/ 
## for more information.
##
## Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
## All Rights Reserved 
##
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
##
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
##
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
##
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
##
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program. Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
##
## Report bugs and suggestions to coral-bugs@caida.org.
## ----------------------------------------------------------------------
## $Id: t2_report++.pl,v 1.166 2007/06/06 18:17:35 kkeys Exp $
## $Author: kkeys $
## $Name: release-3-8-1 $
## $Revision: 1.166 $

my $VERSION = 2.0;

# Use CoralReef Libraries
my $coral_dir;
BEGIN { $coral_dir = "/usr/local/Coral"; } # This will be edited during build.
my $rrd_dir;
BEGIN { $rrd_dir = "/usr/local/RRDtool"; } # This will be edited during build.
use lib "$coral_dir/lib"; #coral global libdir#
use lib "../../../lib"; #coral local libdir#

# Optional Path to RRDtool if you wish to use it.
use lib "$rrd_dir/lib/perl";

# Flags if conditional libraries have been loaded.
my ($RRD_disabled, $NetGeo_disabled, $GD_disabled);
# Flag if we are in a development environment.
my $benchmark_enabled;
my $benchmark = 0;

# Conditional inclusion of benchmarking if in development setting.
# Conditional using of RRDtool and NetGeoClient
BEGIN {
    $benchmark_enabled = 0;
    if (-e "$coral_dir/etc/t2_report.dev" or
	-e "$ENV{HOME}/.Coral/t2_report.dev")
    {
	eval 'require Benchmark; import Benchmark qw(:DEFAULT timesum);';
	if ($@ eq '') {
	    $benchmark_enabled = 1;
	} 
    }
    eval 'require RRDs; import RRDs;';
    if ($@ ne '') {
       $RRD_disabled = 1;
    } else {
       $RRD_disabled = 0;
    }
    eval 'require CAIDA::NetGeoClient; import CAIDA::NetGeoClient;';
    if ($@ ne '') {
       $NetGeo_disabled = 1;
    } else {
       $NetGeo_disabled = 0;
    }
}

# Check if GD pie chart generator can be loaded
BEGIN { 
    eval 'require GD::Graph::pie; import GD::Graph::pie;'; 
        if ($@ ne '') { 
            $GD_disabled = 1; 
        }  else {
	    $GD_disabled = 0; 
	}
}


# Flag for reloading configuration files.
use vars qw($RELOAD_CONFIG);
$main::RELOAD_CONFIG = 0;

# Flag for ending after an interval's done.
use vars qw($END_SOON);
$END_SOON = 0;

# Define flag for dumping traffic2 output directly
use vars qw($DUMP_TRAFFIC2);
$main::DUMP_TRAFFIC2 = 0;

# Perl Standard Libraries
use POSIX 'strftime';
use IO::File;
use AppConfig qw(:argcount);
use Getopt::Std;

# Perl interfaces to Caida Utilities
use CAIDA::ASFinder; # Use BGP routing table to find AS
use CAIDA::AppPorts; # Rule based look up of apps by ports.

# Use the Perl modules to collect and manage data from Traffic2
# Include mediating module Traffic_plot.pm
use CAIDA::Traffic2::Traffic_plot;
use CAIDA::Traffic2::Encode;

# Use the Perl objects for handling Traffic2 Intervals.
use CAIDA::Traffic2::Interval;
use CAIDA::Traffic2::FileReader;
use CAIDA::Traffic2::FileWriter;
use CAIDA::Traffic2::FlowCounter;

# Load configuration information
use CAIDA::Traffic2::ConfigReport;

# Utilities
use CAIDA::Traffic2::ReportUtils;

# Use the CAIDA Table objects.
use CAIDA::Tables::Tuple_Table;
use CAIDA::Tables::IP_Table;
use CAIDA::Tables::Proto_Table;
use CAIDA::Tables::Proto_Ports_Table;
use CAIDA::Tables::AS_Table;
use CAIDA::Tables::Country_Table;
use CAIDA::Tables::VPVC_Table;
use CAIDA::Tables::AppInfo_Table;

# Use appropriate Custom HTML template object - adjust to your usage
# In this example we use custom templates for some and baseline for others.
use CAIDA::Traffic2::CustomBaseHTML;
use CAIDA::Traffic2::CustomCaidaHTML;

# Global references to objects.
use vars qw($BaselineHTML_obj $CustomHTML_obj $config $as_finder $netgeo);
use vars qw($app_ports_obj);

# Global hashes that need to remain global
use vars qw(%as_name_memo %as_country_memo);

# Keep the $debug variable global to simplify adding additional debugging.
use vars qw($debug);

$CustomHTML_obj = new CAIDA::Traffic2::CustomCaidaHTML;
$BaselineHTML_obj = new CAIDA::Traffic2::CustomBaseHTML;
$config = new AppConfig(); # Actually unncessary but clearer.
$config = define_config_state(); #does all work to set "factory settings"

# Set up signal handlers
$SIG{HUP} = \&catch_reconfig_reload;
$SIG{USR1} = \&end_soon;

# Set up signal handler for dumping crl_flow output
$SIG{USR2} = \&change_dump_state;

# Perl Pragmas
use strict;

# Command line option hash
use vars qw(%options);

# Initialize global hashes.
%as_country_memo = ();
%as_name_memo = ();

# .   .   .   .   .  Script Subroutines  .   .   .   .   .   .   .   .  
sub catch_reconfig_reload($ ) {
# -------------------------------------------
# Tiny interrupt handler to set flag to 
# reload configuration files.
# -------------------------------------------
    my $signal = shift;
    
    $main::RELOAD_CONFIG = 1;
}

# Quit program after latest interval has been read.
sub end_soon($ ) {
    my $signal = shift;
    $END_SOON = 1;
}

sub change_dump_state($ ) {
# -------------------------------------------
# Another tiny interrupt handler to flip 
# the state of the traffic2 dump option.
# -------------------------------------------
    my $signal = shift;

    $main::DUMP_TRAFFIC2 = not $main::DUMP_TRAFFIC2;
}

sub remove_element($@) {
# ------------------------------------------
# Basically a "long macro" to remove all
# occurences of a element from an array.
# Provides a more intuitive label for Perl's
# grep facility in this content.
# ------------------------------------------
    my $remove = shift;
    my @array = @_;

    return(grep {$_ ne $remove} @array);

}

sub make_table($$$$$$$$$$ ) {
# -------------------------------------------
# Iteration toward a generalized tool to 
# create HTML tables.  Still specific to
# this need.  Computes total packets and 
# bytes and percentages relative to this
# Vpvc.
# -------------------------------------------
    my $filehdl_ref = shift;
    my $table = shift;
    my $hash_ref = shift;
    my $top_n_ref = shift;
    my $count_ref = shift;
    my $elapsed = shift;
    my $field_name_text = shift;
    my $key_title = shift;
    my $key_print_func = shift;
    my $unit = shift;
    
    # Extract totals out of hash to simplify statements
    my $total_packets = $count_ref->pkts();
    my $total_packets_str = sprintf("%.4f", $total_packets/(1000*$elapsed));
    my $total_bytes = $count_ref->bytes();
    my $total_bytes_str = sprintf("%.4f", ($total_bytes*8)/(1000000*$elapsed));
    my $total_tuples = $count_ref->flows();
    my $total_tuples_str = sprintf("%.4f", $total_tuples/$elapsed);
    
    # Declare values assigned later with protection from /0
    my ($bytes_per, $packets_per, $tuples_per);
    
    my $data_count = $table->num_entries();
    my $display_count = scalar(@{$top_n_ref});

    # XXX maybe in config
    my $bg_bytes = "";
    my $bg_packets = "";
    my $bg_tuples = "";

    if ($unit eq "bytes") {
	$bg_bytes = "BGCOLOR=\"#DCDCDC\"";
    } elsif ($unit eq "packets") {
	$bg_packets = "BGCOLOR=\"#DCDCDC\"";
    } elsif ($unit eq "tuples") {
	$bg_tuples = "BGCOLOR=\"#DCDCDC\"";
    }

    # Send the HTML tags to start table and supply table header
    print $filehdl_ref <<"EOH";
<H3>Overall Performance:</H3>
<BLOCKQUOTE>
  <P>Byte rate: $total_bytes_str Mbits/s<BR>
     Packet rate: $total_packets_str Kpackets/s<BR>
     Tuple rate: $total_tuples_str tuples/s<BR>
     Total unique $field_name_text entries: $data_count 
     (top $display_count by $unit shown)
</P>
</BLOCKQUOTE>

<TABLE BORDER=1>
  <TR>
    <TH>$key_title</TH>
    <TH $bg_bytes>Mbits/s</TH><TH $bg_bytes>% bytes</TH>
    <TH $bg_packets>Kpkts/s</TH><TH $bg_packets>% packets</TH>
    <TH $bg_tuples>tuples/s</TH><TH $bg_tuples>% tuples</TH>
  </TR>
EOH
    
    # How many items to display in list.
    foreach my $key (@{$top_n_ref}) {
	# Compute percentage of packets and packet rate
	my $packets = $hash_ref->{$key}->pkts();
	if($total_packets == 0) { 
	    $packets_per = $packets/100;
	} else {
	    $packets_per = $packets/$total_packets*100;
	}
	$packets /= 1000;
	$packets /= $elapsed;
	
	# Compute percentage of bytes and byte rate.
	my $bytes = $hash_ref->{$key}->bytes();
	if($total_bytes == 0) { 
	    $bytes_per = $bytes/100;
	} else {
	    $bytes_per = $bytes/$total_bytes*100;
	}
	$bytes = $bytes*8/1000000;
	$bytes /= $elapsed;
	
	# Compute percentage of tuples and byte rate.
	my $tuples = $hash_ref->{$key}->flows();
	if($total_tuples == 0) {
	    $tuples_per = $tuples/100;
	} else {
	    $tuples_per = $tuples/$total_tuples*100;
	}
	$tuples /= $elapsed;
	
	# Output the HTML table tags for each data line.
	print($filehdl_ref "<TR>\n");
	printf($filehdl_ref 
		join('', "<TD>%s</TD>",
		     "<TD $bg_bytes>%.4f</TD><TD $bg_bytes>%.2f</TD>",
		     "<TD $bg_packets>%.4f</TD><TD $bg_packets>%.2f</TD>",
		     "<TD $bg_tuples>%.4f</TD><TD $bg_tuples>%.2f</TD>\n"), 
		&$key_print_func($table, $key), $bytes, $bytes_per,
		$packets, $packets_per, $tuples, $tuples_per); 
	print $filehdl_ref "</TR>\n";
    }
    
    # Send the table close tags - add any comments/etc. here
    print $filehdl_ref "</TABLE>\n";
	
} #End make_table

sub make_pie_chart($$$$$$$$$$$) {
# -------------------------------------------
# Tool for creating Pie Charts.  This is
# an intermediate form that handles the
# two tools presently supported to produce
# pie charts.  Eventually this will become 
# another abstraction layer.
# -------------------------------------------
    my $filehdl_ref = shift;
    my $table = shift;
    my $hash_ref = shift;
    my $top_n_ref = shift;
    my $count_ref = shift;
    my $elapsed = shift;
    my $graph_title = shift;
    my $key_title = shift;
    my $key_print_func = shift;
    my $unit = shift;
    my $category = shift;

    # Get config state from config object
    my $graph_tool = $config->get('graphtool');
    
    # Extract totals out of hash to simplify statements
    my $total_bytes = $count_ref->bytes();
    
    if(@{$top_n_ref} == 0) {
	return(0);
    }

    # Code to select among different graphing options - XXX not very general
    if($graph_tool eq "GDGraph") {
	# Use GDGraph.pm
	make_pie_chart_png($filehdl_ref, $table, $hash_ref, $top_n_ref,
			   $count_ref, $elapsed, $graph_title,
			   $key_title, $key_print_func, $unit, $category);
    } 
    elsif ($graph_tool eq "JCChart") {
	# Use Java JCChart to make graphs
	make_pie_chart_java($filehdl_ref, $table, $hash_ref, $top_n_ref,
			    $count_ref, $elapsed, $graph_title,
			    $key_title, $key_print_func);
    # Else do whatever may be required for text only.
    } else {
    }
} #End make_pie_chart



sub make_main_index ($$$ ) {
# ----------------------------------------
# Subroutine to make the point of entry
# HTML index page.  Does basic error
# handling and creates links to more
# report pages.
# ---------------------------------------

    my $interval_obj = shift;
    my $table = shift;
    my $total_counts = shift;

    # Get configuration state information
    my $html_dir = $config->get('html_dir');
    my $site_name = $config->get('site_name');
    my $no_totals = $config->get('zaptotals');    

    my $hash_ref = $table->data();
    
    #local variables

    # XXX isdst = -1 patch for Perl bug in POSIX strftime
    my @GMTime = gmtime($interval_obj->get_metadata('start'));
    $GMTime[8] = -1;
    my $begin = strftime("%c UTC", @GMTime); 
    my $elapsed = $interval_obj->get_metadata('duration');
    my $elapsed_str = sprintf("%.2f", $elapsed);
    my $title = "Data by bytes";
    if ($site_name) {
	$title .= " from $site_name";
    }
    
    # Open file for index
    unless (open(MINDEX, ">$html_dir/index.html")) {
	die "Unable to open file $html_dir/index.html\n$!";
    }
    
    # Transfer state to $config object for Traffic_plot.pm
    $config->set('page_dir', "$html_dir");
    
    # HTML Header information.
    $CustomHTML_obj->html_header(\*MINDEX, "$html_dir/index.html", $title);

    my $extra_html = $config->get('extra_html');
    print MINDEX "$extra_html\n" if $extra_html;

    # HTML Provide processing time data.
    print MINDEX <<"EOH";
<P><B>Beginning time: $begin</B></P>
<P><B>Elapsed time: $elapsed_str seconds</B></P>
EOH

    my @top_vpvc = $table->sort_by_bytes(-1);
    make_pie_chart(\*MINDEX, $table, $hash_ref, \@top_vpvc, $total_counts,
       $interval_obj->get_metadata('duration'), 
       "$title\\n$begin\\n${elapsed_str}s",
       "subinterface", 
       \&do_vpvc_chart_name, "bytes", "main");
    
    make_table(\*MINDEX, $table, $hash_ref, \@top_vpvc, $total_counts,
	       $interval_obj->get_metadata('duration'),
	       "subinterface", "subinterface", \&do_vpvc_name, "bytes");
    
    unless ($no_totals) {
	print MINDEX "<P><A HREF=\"total/\">Total of all vpvcs</A></P>\n";
}
        
    $CustomHTML_obj->html_footer(\*MINDEX);
    unless (close(MINDEX)) {
	warn "Unable to close file $html_dir/index.html"
    }
} #End

sub rrd_image_links($$$$$$ ) {
# --------------------------------------------
# Helper subroutine to produce the HTML that
# corresponds to each image link in the time
# series graphs.
# --------------------------------------------
    my $filehdl = shift;
    my $prefix = shift;
    my $unit = shift;
    my $width = shift;  # XXX Would need returned value from RRD
    my $height = shift; # XXX Perhaps not worth it.
    my $time = shift;

    print $filehdl "<p align=\"center\">",
                   "<img src=\"", 
                   "${prefix}_${unit}_${time}.gif\" ",
#                  "width=\"$width\" height=\"$height\"",
                   "></p>\n";

} # End sub rrd_image_links

sub make_timeseries_index($$$$$$$$$@ ) {
# --------------------------------------------
# Baseline subroutine to produce the index 
# pages for RRDtool timeseries data.  It is 
# called as needed for all times of time
# series data.
# --------------------------------------------
    my $vpvc = shift;
    my $unit = shift;
    my $title = shift;
    my $prefix = shift;

    # Parameter passed configuration state information
    my $html_dir = shift;
    my $site_name = shift;
    my $VPVC_NAMES = shift;
    my $width = shift;
    my $height = shift;
    my @time_intervals = @_;
    
    # Create file.
    unless (open(VINDEX, ">$html_dir/$vpvc/${prefix}_${unit}.html")) {
	die "Cannot create file: $html_dir/$vpvc/${prefix}_${unit}.html\n $!";
    }
    
    # Create page header.
    $CustomHTML_obj->html_header(\*VINDEX,
				 "$html_dir/$vpvc/${prefix}_${unit}.html", 
				 $title);
    print VINDEX "<p><b>Note:</b>\n",
          "Please use shift-reload in your browser as the \n",
          "images may not always reload after the 5 minute expiration time.\n",
          "</p>\n<hr>";


    foreach my $time (@time_intervals) {
       rrd_image_links(\*VINDEX, $prefix, $unit, $width, $height, $time);
    }

    # Use base class of CustomHTML object so have a simple footer.
    $BaselineHTML_obj->html_footer(\*VINDEX, );
    
    unless (close(VINDEX)) {
	warn "Cannot close file: $html_dir/$vpvc/${prefix}_${unit}.html";
    }
} # End sub print_vpvc_index


sub make_vpvc_timeseries_html($$) {
# --------------------------------------------
# Produce html pages with RRDtool graphs of
# VPVC data.
# --------------------------------------------
    my $vpvc = shift;
    my $unit = shift;

    # Get configuration state information
    my $html_dir = $config->get('html_dir');
    my $site_name = $config->get('site_name');
    my $VPVC_NAMES = $config->get('subif_names');
    my $InternetApps = $config->get('internetapps');
    my $with_rrd_top_apps = $config->get('with_rrd_top_apps');
    my $width = $config->get('rrd_graph_width');
    my $height = $config->get('rrd_graph_height');
    my @time_intervals = @{$config->get('rrd_time_samples')};
    my $title = "$unit for subinterface $vpvc";
    if ($VPVC_NAMES->{$vpvc}) {
	$title .= ": $VPVC_NAMES->{$vpvc}";
    }
    
    (my $vpvc_file = $vpvc) =~ s/\[|\]|:/_/g; 
    
    # Make Protocol graph index.
    my $prefix="ts_proto";
    make_timeseries_index($vpvc_file, $unit, "Protocol $title",
			  $prefix, $html_dir, $site_name, $VPVC_NAMES, 
                          $width, $height, @time_intervals);
    
    # Make Protocol percent graph index.
    $prefix="ts_proto_percent";
    make_timeseries_index($vpvc_file, $unit,
			  "Protocol percentage of $title",
			  $prefix, $html_dir, $site_name, $VPVC_NAMES, 
                          $width, $height, @time_intervals);


    # If desired, make Application graph index.
    if ($InternetApps) {
        $prefix="ts_app";
        make_timeseries_index($vpvc_file, $unit, "Application $title",
			  $prefix, $html_dir, $site_name, $VPVC_NAMES, 
                          $width, $height, @time_intervals);
    }
    # If desired, make top N application graph index.
    if ($with_rrd_top_apps) {
        $prefix="ts_top_n_app";
        make_timeseries_index($vpvc_file, $unit,
			  "Top application $title",
			  $prefix, $html_dir, $site_name, $VPVC_NAMES, 
                          $width, $height, @time_intervals);
    }
} # End make_vpvc_timeseries_html


sub create_hlinks_table($$$@ ) {
# ----------------------------------------
# Helper subroutine to create the piece of
# HTML related to the table of hyperlinks
# to the various sorted-by categories.
# ----------------------------------------
    my $file = shift;
    my $file_to_text_ref = shift;
    my @sort_types = @{shift @_};
    my @prefixes = @_;

    # Create table
    foreach my $type (@prefixes) {
	print $file ' 'x4, "<TR>\n", ' 'x7, "<TH>",
	             $file_to_text_ref->{$type},"</TH>\n";
	foreach my $sort (@sort_types) {
	    print $file ' 'x7, "<TD><A HREF=\"${type}_\L$sort\E.html\">",
	          "$sort</A></TD>\n";
	}
	print $file ' 'x4, "</TR>\n"
    }
}

sub make_vpvc_index($$$) {
# ----------------------------------------
# Subroutine to create the index page for
# each of the Vp:Vc pair
# ----------------------------------------
    my $interval_obj = shift;
    my $vpvc = shift;
    my $tuple_table = shift;

    # Get configuration state information
    my $find_AS = $config->get('asfinder');
    my $geography = $config->get('netgeo');
    my $html_dir = $config->get('html_dir');
    my $site_name = $config->get('site_name');
    my $RRDtool = $config->get('rrdtool');
    my $VPVC_NAMES = $config->get('subif_names');
    my $InternetApps = $config->get('internetapps');
    my $with_rrd_top_apps = $config->get('with_rrd_top_apps');
    # Convert time from hash storage value - retrieve other values
    my  $begin = strftime("%c UTC", gmtime($interval_obj->get_metadata('start')));
    my $elapsed = $interval_obj->get_metadata('duration');
    my $elapsed_str = sprintf("%.2f", $elapsed);
    my $title = "Subinterface $vpvc";
    if ($VPVC_NAMES->{$vpvc}) {
	$title .= ": $VPVC_NAMES->{$vpvc}";
    }
    
    (my $vpvc_file = $vpvc) =~ s/\[|\]|:/_/g; 
    
    unless (open(VINDEX, ">$html_dir/$vpvc_file/index.html")) {
	die "Cannot create file: $html_dir/$vpvc_file/index.html\n $!";
    }
    
    $CustomHTML_obj->html_header(\*VINDEX,
				 "$html_dir/$vpvc_file/index.html", $title);

my %file_to_text = (proto => "Current protocol breakdown",
		    app => "Current applications",
		    flows => "Current flows",
		    src_ip => "Current source hosts",
		    dst_ip => "Current destination hosts",
		    src_as => "Current source ASes",
		    dst_as => "Current destination ASes",
		    src_country => "Current source countries",
		    dst_country => "Current destination countries",
		    ts_proto => "Protocol timeseries plot",
		    ts_proto_percent => "Protocol timeseries plot (%)",
		    ts_top_n_app => "Top application timeseries plot",
		    ts_app => "Application timeseries plot", 
		    unknown_tcp => "Current unknown TCP",
		    unknown_udp => "Current unknown UDP"
		   );
my @table_rows = qw(proto flows src_ip dst_ip);
my @sort_types =  ("Bytes", "Packets", "Tuples");
    # Create table of options for data presentation
    print VINDEX "<H3>Tables of current data</H3><BR>\n";
    print VINDEX "<TABLE BORDER=1>\n";

    # Create table headers
    print VINDEX ' 'x4, "<TR><TH></TH><TH COLSPAN=3>Sorted by</TH></TR>\n";
    print VINDEX ' 'x4, "<TR><TH></TH>";
    foreach my $titles (@sort_types) {
	print VINDEX ' 'x4, "<TH>$titles</TH>";
    }
    print VINDEX "\n", ' 'x4, "</TR>\n";

@table_rows = qw(proto app flows src_ip dst_ip unknown_tcp unknown_udp);

    # If applications is turned off remove rows from table.
    unless ($InternetApps) {
	@table_rows = remove_element('app', @table_rows);
	@table_rows = remove_element('unknown_tcp', @table_rows);
	@table_rows = remove_element('unknown_udp', @table_rows);
    }
    unless ($tuple_table) {
	@table_rows = remove_element('flows', @table_rows);
    }

    create_hlinks_table(\*VINDEX, \%file_to_text, \@sort_types, 
			@table_rows
			 );

    # If ASFinder is operating ... provide links to AS data.
    if ($find_AS) {
	create_hlinks_table(\*VINDEX, \%file_to_text, \@sort_types, 
			    qw(src_as dst_as) );
    }
    # If Netgeo is active then provide links to geography info.
    if ($geography) {
	create_hlinks_table(\*VINDEX, \%file_to_text, \@sort_types, 
			    qw(src_country dst_country) );

    }
    # If RRDtool is operating ... provide links to the timeseries charts.
    if ($RRDtool) {
	create_hlinks_table(\*VINDEX, \%file_to_text, \@sort_types, 
			    qw(ts_proto ts_proto_percent) );
	if ($InternetApps) {
	    create_hlinks_table(\*VINDEX, \%file_to_text, \@sort_types,
				qw(ts_app) );
	}

	if ($with_rrd_top_apps and $InternetApps) {
	    create_hlinks_table(\*VINDEX, \%file_to_text, \@sort_types,
				qw(ts_top_n_app) );
	}
    }
    print VINDEX "</TABLE><BR>\n";
    print VINDEX "</BODY>\n";
    print VINDEX "</HTML>\n";

    unless (close(VINDEX)) {
	    warn "Cannot close file: $html_dir/$vpvc_file/index.html";
    }
    if ($RRDtool) {
	foreach my $unit (qw(bytes packets tuples)) {
	    make_vpvc_timeseries_html($vpvc,$unit);
	}
    }
}# End sub print_vpvc_index

sub set_top_rrd_apps($$$ ) {
# ----------------------------------------------------
# Routine to take the "top_n" applications by bytes,
# packets, or flows and compare it against the list
# of applications with RRD timeseries data.  determines
# the top number of small n applications that have 
# RRDtool timeseries data and stores it in another 
# configuration variable.
# ----------------------------------------------------
    my $top_type_set = shift;
    my $AppTable = shift;
    my $top_n_ref = shift;
    my $top_rrd_apps_ref = [];

    foreach my $key (@$top_n_ref) {
	my ($desc, $name) = $AppTable->get_key_fields($key);
	if ($name =~ /\w/) {
 	    push @$top_rrd_apps_ref, [$name, $desc];
	}
    }
    $config->set($top_type_set, $top_rrd_apps_ref);
}

sub make_vpvc_generic ($$$$$$$$$$$ ) {
# ----------------------------------------------------
# Make a baseline HTML report with the VPVC data.
# This subroutine is used as a template for 
# protocol, source IP, dest IP, source AS, dest AS,
# source country, destination country, and flows 
# data.
# ----------------------------------------------------
    my $html_file = shift;
    my $field_name_text = shift;
    my $field_name_graph = shift;
    my $print_func_graph = shift;
    my $field_name_table = shift;
    my $print_func_table = shift;
    my $interval_obj = shift;
    my $vpvc = shift;
    my $table = shift;
    my $counts_ref = shift;
    my $unit = shift;

    # Get configuration state information
    my $html_dir = $config->get('html_dir');
    my $site_name = $config->get('site_name');
    my $rrd_display_count = $config->get('rrd_display_count');
    my $display_count = $config->get('display_count');
    my $VPVC_NAMES = $config->get('subif_names');
    my $top_apps = $config->get('with_rrd_top_apps');

    # could do this, but then harder on filtered stuff, if still want
    # per vpvc percentages
    #my $counts_ref = $table->total();
	
    my $hash_ref = $table->data();
	
    # Get the start time and convert it proper time zone and into string
    my $begin = strftime("%c UTC", gmtime($interval_obj->get_metadata('start')));
    my $elapsed = $interval_obj->get_metadata('duration');
    my $elapsed_str = sprintf("%.2f", $elapsed);
	
    my @top_field_data;
    if ($unit eq "bytes") {
	if($top_apps and $html_file eq 'app') {
	    @top_field_data = $table->sort_by_bytes(-1);
	    set_top_rrd_apps('rrd_top_apps_bytes', $table, 
			     \@top_field_data);
	    if ($#top_field_data > $display_count) {
		@top_field_data = @top_field_data[0..$display_count-1];
	    }
	} else {
	    @top_field_data = $table->sort_by_bytes($display_count);
	}
    } elsif ($unit eq "packets") {
	if($top_apps and $html_file eq 'app') {
	    @top_field_data = $table->sort_by_pkts(-1);
	    set_top_rrd_apps('rrd_top_apps_packets', $table, 
			     \@top_field_data);
	    if ($#top_field_data > $display_count) {
		@top_field_data = @top_field_data[0..$display_count-1];
	    }
	} else {
	    @top_field_data = $table->sort_by_pkts($display_count);
	}
    } elsif ($unit eq "tuples") {
	if($top_apps and $html_file eq 'app') {
	    @top_field_data = $table->sort_by_flows(-1);
	    set_top_rrd_apps('rrd_top_apps_flows', $table,
			     \@top_field_data);
	    if ($#top_field_data > $display_count) {
		@top_field_data = @top_field_data[0..$display_count-1];
	    }
	} else {
	    @top_field_data = $table->sort_by_flows($display_count);
	}
    }

    (my $vpvc_file = $vpvc) =~ s/\[|\]|:/_/g; 

    # Set $config state for Traffic_plot.pm
    my $page_dir = "$html_dir/$vpvc_file";
    $config->set('page_dir', $page_dir);
    my $filename = "$page_dir/${html_file}_${unit}.html";

    # Open file to hold results of protocol data
    unless (open(VINDEX, ">$filename")) {
	die "Unable to open file: $filename\n $!";
    }
	
    # Output the HTML header tags
    my $title = "$field_name_text list for subinterface $vpvc";
    if ($VPVC_NAMES->{$vpvc}) {
	$title .= " ($VPVC_NAMES->{$vpvc})";
    }
    $title .= " sorted by $unit";
    $CustomHTML_obj->html_header(\*VINDEX, "$filename", $title);
	
    # Give the table headings.
    print VINDEX <<"EOH";
<P><B>Beginning time: $begin</B></P>
<P><B>Elapsed time: $elapsed_str seconds</B></P>
EOH


    if ($vpvc =~ /\d/) {
        print VINDEX "<P>Note: Percentages relative to this specific ", 
               "subinterface, not the entire link.</P>\n";
    }
	
    # Create the table
    if (defined($field_name_graph)) {
	my $graph_unit = $unit;
	$graph_unit = 'flows' if $unit eq 'tuples';
	$graph_unit = 'pkts' if $unit eq 'packets';
	make_pie_chart(\*VINDEX, $table, $hash_ref, \@top_field_data,
		       $counts_ref, $elapsed,
		       "$title\\n$begin\\n${elapsed_str}s",
		       $field_name_graph, $print_func_graph,
		       $graph_unit, $html_file);
    }
	
    make_table(\*VINDEX, $table, $hash_ref, \@top_field_data,
	       $counts_ref, $elapsed,
	       $field_name_text, $field_name_table, $print_func_table, $unit);
	
    # Send footer tags
    $CustomHTML_obj->html_footer(\*VINDEX);
	
    # Close the file
    unless (close(VINDEX)) {
	warn "Unable to close file: $filename";
    }
	
}

#  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -
# --------------------------------------------
# A set of subroutines that create HTML files
# with particular characteristics from the 
# primary subroutine to make such things
# make_vpvc_generic
# --------------------------------------------

sub make_vpvc_proto($$$$$ ) {
# --------------------------------------------
    make_vpvc_generic("proto", "Protocol",
		      "Protocol", \&do_proto_name,
		      "Protocol", \&do_proto_name,
		      shift, shift, shift, shift, shift);
}

sub make_vpvc_app($$$$$ ) {
# --------------------------------------------
    make_vpvc_generic("app", "Application",
		      "Application", \&do_app_name,
		      "Application", \&do_app_name,
		      shift, shift, shift, shift, shift);
}


sub make_vpvc_src_ip($$$$$ ) {
# --------------------------------------------
  my $promiscuous = $config->get('promiscuous');
  if ($promiscuous) {
    make_vpvc_generic("src_ip", "Source IP Address",
		      "Source IP Address", \&do_encoded_ip_name,
		      "Source IP Address", \&do_encoded_ip_name,
		      shift, shift, shift, shift, shift);
  } else {
    make_vpvc_generic("src_ip", "Encoded Source IP Address",
		      "Encoded\\nSource IP Address", \&do_encoded_ip_name,
		      "Encoded<BR>Source IP Address", \&do_encoded_ip_name,
		      shift, shift, shift, shift, shift);
  }
}


sub make_vpvc_dst_ip($$$$$ ) {
# --------------------------------------------
  my $promiscuous = $config->get('promiscuous');
  if ($promiscuous) {
    make_vpvc_generic("dst_ip", "Destination IP Address",
		      "Destination IP Address", \&do_encoded_ip_name,
		      "Destination IP Address", 
		      \&do_encoded_ip_name,
		      shift, shift, shift, shift, shift);
  } else {
    make_vpvc_generic("dst_ip", "Encoded Destination IP Address",
		      "Encoded\\nDestination IP Address", \&do_encoded_ip_name,
		      "Encoded<BR>Destination IP Address", 
		      \&do_encoded_ip_name,
		      shift, shift, shift, shift, shift);

  }
}


sub make_vpvc_src_as($$$$$ ) {
# --------------------------------------------
    make_vpvc_generic("src_as", "Source AS",
		      "Source AS", \&do_as_name,
		      "Source AS", \&do_as_name,
		      shift, shift, shift, shift, shift);
}


sub make_vpvc_dst_as($$$$$ ) {
# --------------------------------------------
    make_vpvc_generic("dst_as", "Destination AS",
		      "Destination AS", \&do_as_name,
		      "Destination AS", \&do_as_name,
		      shift, shift, shift, shift, shift);
}


sub make_vpvc_src_country($$$$$ ) {
# --------------------------------------------
    make_vpvc_generic("src_country", "Source Country",
		      "Source Country", \&do_identity_name,
		      "Source Country", \&do_identity_name,
		      shift, shift, shift, shift, shift);
}


sub make_vpvc_dst_country($$$$$ ) {
# --------------------------------------------
    make_vpvc_generic("dst_country", "Destination Country",
		      "Destination Country", \&do_identity_name,
		      "Destination Country", \&do_identity_name,
		      shift, shift, shift, shift, shift);
}


sub make_vpvc_flows($$$$$ ) {
# --------------------------------------------

  my $promiscuous = $config->get('promiscuous');
  if ($promiscuous) {
    make_vpvc_generic("flows", "Flow",
		      undef, undef, # Do not make pie chart.
		      join('', "Source IP Address</TH><TH>",
				"Dest IP Address</TH><TH>Protocol</TH>",
				"<TH>Source Port</TH><TH>Dest Port"),
		      \&do_flows_name,
		      shift, shift, shift, shift, shift);
  } else {
    make_vpvc_generic("flows", "Flow",
		      undef, undef, # Do nott make pie chart.
		      join('', "Encoded<BR>Source IP Address</TH><TH>Encoded",
				"<BR>Dest IP Address</TH><TH>Protocol</TH>",
				"<TH>Source Port</TH><TH>Dest Port"),
		      \&do_flows_name,
		      shift, shift, shift, shift, shift);
  }
}

sub make_vpvc_unknown_tcp($$$$$ ) {
# --------------------------------------------
    make_vpvc_generic("unknown_tcp", "Unknown TCP",
		      undef, undef, #Do not make pie chart.
		      join('', 	"Protocol</TH>",
				"<TH>Source Port</TH><TH>Dest Port"),
		      \&do_proto_ports_name,
		      shift, shift, shift, shift, shift);
}

sub make_vpvc_unknown_udp($$$$$ ) {
# --------------------------------------------
    make_vpvc_generic("unknown_udp", "Unknown UDP",
		      undef, undef, #Do not make pie chart.
		      join('', 	"Protocol</TH>",
				"<TH>Source Port</TH><TH>Dest Port"),
		      \&do_proto_ports_name,
		      shift, shift, shift, shift, shift);
}

#  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -

my $rrd_update_total;
my $rrd_graph_total;

sub make_vpvc_pages ($$$$$$$$$$$$$$ ) {
# -------------------------------------------
# Subroutine to produce the web pages related
# to VPVC data.
# -------------------------------------------
    my $interval_obj = shift;
    my $vpvc = shift;
    my $tuple_table = shift;
    my $proto_table = shift;
    my $app_table = shift;
    my $src_ip_table = shift;
    my $dst_ip_table = shift;
    my $src_as_table = shift;
    my $dst_as_table = shift;
    my $src_country_table = shift;
    my $dst_country_table = shift;
    my $unknown_tcp_table = shift;
    my $unknown_udp_table = shift;
    my $total_count = shift;

    my $html_dir = $config->get('html_dir');
    my @RRD_PROTOS = @{$config->get('RRD_GRAPH_PROTOS')};
    my $InternetApps = $config->get('internetapps');
    my $find_AS = $config->get('asfinder');
    my $geography = $config->get('netgeo');
    my $RRDtool = $config->get('RRDtool');
    my $app_desc;
    (my $vpvc_file = $vpvc) =~ s/\[|\]|:/_/g; 
    
    # Create the actual files
    # Patch for creating directory to store files.
    unless (-d "$html_dir/$vpvc_file") {
	mkdir("$html_dir/$vpvc_file", 0755); #XXX
    }
	
    # Make Index page.
    make_vpvc_index($interval_obj, $vpvc, $tuple_table);
    
    # Make data pages.
    foreach my $unit (qw(bytes packets tuples)) { # XXX
	make_vpvc_proto($interval_obj, $vpvc, $proto_table, 
			$total_count, $unit);
	if ($InternetApps) {
	    make_vpvc_app($interval_obj, $vpvc, $app_table, 
			  $total_count, $unit);
	}
	make_vpvc_src_ip($interval_obj, $vpvc, $src_ip_table, 
			 $total_count, $unit);
	make_vpvc_dst_ip($interval_obj, $vpvc, $dst_ip_table, 
			 $total_count, $unit);
	if ($find_AS) {
	    make_vpvc_src_as($interval_obj, $vpvc, $src_as_table, 
			     $total_count, $unit);
	    make_vpvc_dst_as($interval_obj, $vpvc, $dst_as_table, 
			     $total_count, $unit);
	}
	if($geography) {
	    make_vpvc_src_country($interval_obj, $vpvc, $src_country_table, 
				  $total_count, $unit);
	    make_vpvc_dst_country($interval_obj, $vpvc, $dst_country_table, 
				  $total_count, $unit);
	}
	if (defined $tuple_table) {
	    make_vpvc_flows($interval_obj, $vpvc, $tuple_table, 
			    $total_count, $unit);
	}
	if ($InternetApps) {
	    make_vpvc_unknown_tcp($interval_obj, $vpvc, $unknown_tcp_table,
				  $total_count, $unit);
	    make_vpvc_unknown_udp($interval_obj, $vpvc, $unknown_udp_table,
				  $total_count, $unit);
	}
    }
    if($RRDtool) {
	my ($rrd_timein, $rrd_timeout);
	if ($benchmark) {
	    if (not defined $rrd_update_total or not defined $rrd_graph_total) {
		$rrd_update_total = new Benchmark;
		$rrd_update_total = timediff($rrd_update_total,
						$rrd_update_total);
		$rrd_graph_total = new Benchmark;
		$rrd_graph_total = timediff($rrd_graph_total, $rrd_graph_total);
	    }
	    $rrd_timein = new Benchmark;
	}
	# create & update rrd dbs, make graphs
	my $backdate;
	if ($config->get('RRD_backdate')) {
	    $backdate = $config->get('RRD_backdate');
	} else {
	    $backdate = int($interval_obj->get_metadata('start'));
	}
	
	unless (rrd_db_existence($vpvc_file, "proto", "total") ) {
	    rrd_db_create($vpvc_file, "proto", "total", $backdate);
	}
	rrd_db_update($vpvc_file, "proto", "total",
		      int($interval_obj->get_metadata('end')),
		      $interval_obj->get_metadata('duration'),
		      $total_count);
	foreach my $proto_key (keys %{$proto_table->data()}){
	    my ($proto) = $proto_table->get_key_fields($proto_key);
	    unless (rrd_db_existence($vpvc_file, "proto", $proto) ) {
		rrd_db_create($vpvc_file, "proto", $proto, $backdate);
	    }
	    rrd_db_update($vpvc_file, "proto", $proto,
			  int($interval_obj->get_metadata('end')),
			  $interval_obj->get_metadata('duration'),
			  $proto_table->data()->{$proto_key});
	}
	# In case we want to graph something we haven't seen yet...
	foreach my $proto (@RRD_PROTOS) {
	    unless (rrd_db_existence($vpvc_file, "proto", $proto) ) {
		rrd_db_create($vpvc_file, "proto", $proto, $backdate);
	    }
	}
	if ($InternetApps) {
	    foreach my $app_key (keys %{$app_table->data()}){
		my ($blank, $app) = $app_table->get_key_fields($app_key);
		unless (rrd_db_existence($vpvc_file, "app", $app) ) {
		    rrd_db_create($vpvc_file, "app", $app, $backdate);
		}
		rrd_db_update($vpvc_file, "app", $app,
			      int($interval_obj->get_metadata('end')),
			      $interval_obj->get_metadata('duration'),
			      $app_table->data()->{$app_key});
	    }
	}
	if ($benchmark) {
	    $rrd_timeout = new Benchmark;
	    $rrd_update_total = timesum($rrd_update_total,
				timediff($rrd_timeout, $rrd_timein));
	    $rrd_timein = new Benchmark;
	}
	
	unless ($config->get('RRD_nograph')) {
	    my $end_time = int($interval_obj->get_metadata('end'));
	    foreach my $unit (qw(bytes packets tuples)) {
		rrd_graph_proto($vpvc_file,$unit,$end_time);
		my $app_unit;
		if ($InternetApps) {		
		    # Plot "top N" applications
		    if ($unit eq 'tuples') {
			$app_unit = 'flows';
		    } else {
			$app_unit = $unit;
		    }
		    my $apps_ref = $config->get("rrd_top_apps_$app_unit");
		    if ($apps_ref and scalar(@{$apps_ref})) {
			rrd_graph_app($vpvc_file, $unit, $end_time, $apps_ref, 
				      'app',1,'top_n_');
		    }
		    # Plot user selected applications.
		    my @app_names = @{$config->get('rrd_graph_apps')};
		    my @graph_apps;
		    foreach my $app (@app_names) {
			unless (rrd_db_existence($vpvc_file, "app", $app) ) {
			    rrd_db_create($vpvc_file, "app", $app, $backdate);
			}
			my $rule = $app_ports_obj->get_rule($app);
			my $desc;
			if (not defined $rule) {
			    $desc = $app;
			} else {
			    $desc = $rule->desc;
			}
			push @graph_apps, [$app, $desc];
		    }
		    rrd_graph_app($vpvc_file, $unit, $end_time, \@graph_apps,
					'app',0);
		}
		rrd_graph_proto_percent($vpvc_file,$unit,$end_time);
	    }

	    if ($benchmark) {
		$rrd_timeout = new Benchmark();
		$rrd_graph_total = timesum($rrd_graph_total,
				    timediff($rrd_timeout, $rrd_timein));
	    }
	}
    }
}

my $app_total;

sub generate_vpvc_tables($$$ ) {
# -------------------------------
# Subroutine to create sub tables 
# -------------------------------
# Generate Vp:Vc 
    my ($src_ip_table, $dst_ip_table, $proto_ports_table) = @_;
    my $src_as_table;
    my $dst_as_table;
    my $src_country_table;
    my $dst_country_table;
    my $small_size = { 'table_size' => 17 };
    my $rule_ref;
    my $app_desc;
    my $app_name;
    # Get Configuration state
    my $find_AS = $config->get('asfinder');
    my $geography = $config->get('netgeo');
    my $InternetApps = $config->get('internetapps');
	
    my $proto_table = $proto_ports_table->make_Proto_Table($small_size);
    my $app_table = undef;
    my $unknown_tcp_table = undef;
    my $unknown_udp_table = undef;

    if ($InternetApps) {
	$app_table = new CAIDA::Tables::AppInfo_Table();
	$unknown_tcp_table = new CAIDA::Tables::Proto_Ports_Table();
	$unknown_udp_table = new CAIDA::Tables::Proto_Ports_Table();
    }
    my ($app_timein, $app_timeout);
    if ($benchmark and $InternetApps) {
	if (not defined $app_total) {
	    $app_total = new Benchmark;
	    $app_total = timediff($app_total, $app_total);
	}
    }
     while (my ($opaque_key, $counts) = each %{ $proto_ports_table->data() }) {
  	my ($proto, $ok, $sport, $dport) = 
  	    $proto_ports_table->get_key_fields($opaque_key);

	if ($InternetApps) {
	    if ($benchmark) {
		$app_timein = new Benchmark;
	    }
	    $rule_ref = $app_ports_obj->match_rule($proto, $ok, $sport, $dport);
	    if (defined $rule_ref) {
		$app_desc = $rule_ref->desc();
		$app_name = $rule_ref->name();
	    } elsif ($proto == 6) { 
		$unknown_tcp_table->entry_add($proto, $ok, $sport, 
					      $dport, $counts);
		if($ok) {
		    $app_desc = "Other TCP";
		    $app_name = "OTHER_TCP";
		} else {
		    $app_desc = "Fragmented TCP (or IP options)";
		    $app_name = "TCP_NOPORTS";
		}
	    } elsif ($proto == 17) { 
		$unknown_udp_table->entry_add($proto, $ok, 
					      $sport, $dport, $counts); 
		if ($ok) {
		    $app_desc = "Other UDP"; 
		    $app_name = "OTHER_UDP"; 
		} else {
		    $app_desc = "Fragmented UDP (or IP options)";
		    $app_name = "UDP_NOPORTS";
		}

	    } else { 
		my %PROTO_NAMES = %{$config->get('PROTO_NAMES')};
		my $name = $PROTO_NAMES{$proto};
		if ($name) {
		    $app_desc = "Other $name"; 
		} else {
		    $app_desc = "Other (IP proto: $proto)"; 
		}
		$app_name = "OTHER_$proto";
	    } 
	    if ($benchmark) {
		$app_timeout = new Benchmark;
		$app_total = timesum($app_total,
				    timediff($app_timeout, $app_timein));
	    }

	    $app_table->entry_add($app_desc, $app_name, undef, undef,
				    undef, undef, undef, undef, $counts); 
	}
    }

    my $large = { 'table_size' => 3989 };
    if ($find_AS) { 
	$src_as_table = new CAIDA::Tables::AS_Table(undef, $large);
	$dst_as_table = new CAIDA::Tables::AS_Table(undef, $large);
	
	# Create AS Tables directly from IP tables
	$src_as_table = 
	    $src_ip_table->make_AS_Table({as_finder => $as_finder});
	$dst_as_table = 
	    $dst_ip_table->make_AS_Table({as_finder => $as_finder});
    }
    if ($geography) {
	$src_country_table = new CAIDA::Tables::Country_Table(undef, $large);
	$dst_country_table = new CAIDA::Tables::Country_Table(undef, $large);
	# Create Country tables directly from AS tables
	$src_country_table = 
	    $src_as_table->make_Country_Table({netgeo => $netgeo});
	$dst_country_table = 
	    $dst_as_table->make_Country_Table({netgeo => $netgeo});
    }
    return($proto_table, $app_table,
	   $src_as_table, $dst_as_table,
	   $src_country_table, $dst_country_table, 
	   $unknown_tcp_table, $unknown_udp_table);

} #End sub generate_vpvc_tables


#### Group of many functions that provide the "name" for a table ####
sub do_identity_name ($$ ) {
# -----------------------------------
# Get name from key as part of 
# encoding IP names.
# -----------------------------------
    my ($table, $opaque_key) = @_;
    return $table->get_key_fields($opaque_key);
}

sub do_encoded_ip_name($$ ) {
# ----------------------------------
# Encode names via hash.
# ----------------------------------
    my ($table, $opaque_key) = @_;
    my ($addr) = $table->get_key_fields($opaque_key);

    # Get encode option from config object.
    my $promiscuous = $config->get('promiscuous');
	
    # encode IP address unless raw data is desired.
    unless ($promiscuous) {
	  $addr = CAIDA::Traffic2::Encode::encode_addr($addr); 
    }
    
    return $addr;
}

sub do_proto_name ($$ ) {
# ---------------------------------
# Stand in subroutine for the 
# coming Perl module to convert
# Protocol numbers to protocol
# names.
# ---------------------------------
    my ($table, $opaque_key) = @_;
    my ($proto) = $table->get_key_fields($opaque_key);

    # Get config state
    my %PROTO_NAMES = %{$config->get('PROTO_NAMES')};

    my $name = $PROTO_NAMES{$proto} || "$proto";
    return "$name ($proto)";
}

sub get_proto_name ($ ) {
# ---------------------------------
# Stand in subroutine for the 
# coming Perl module to convert
# Protocol numbers to protocol
# names.
# ---------------------------------
    my ($proto) = @_;

    # Get config state
    my %PROTO_NAMES = %{$config->get('PROTO_NAMES')};

    my $name = $PROTO_NAMES{$proto} || "$proto";
    return "$name ($proto)";
}

sub do_app_name ($$ ) {
# ---------------------------------
# Retrieve the application description
# from opaque key.
# ---------------------------------
    my ($table, $opaque_key) = @_;
    my ($app) = $table->get_key_fields($opaque_key);

    return $app;
}

sub do_as_name ($$ ) {
# --------------------------------
# Encode AS name
# --------------------------------
    my ($table, $opaque_key) = @_;
    my ($as) = $table->get_key_fields($opaque_key);
    my $name;

    # Get Global state.
    my $geography = $config->get('netgeo');
	
    if (!defined($as)) {
	$name = "Undefined \$as - bug";
    } elsif (defined($as_name_memo{$as})) {
	return $as_name_memo{$as};
    } elsif ($as eq "NOROUTE") {
	$name = "NOROUTE";
    } elsif ($as eq "MCAST") {
	$name = "MCAST";
    } elsif ($as =~ /^\{/) {
	$name = "AS-SET: $as";
    } elsif ($as eq "MultipleOrigins") {
	$name = "Multiple Origin ASes";
    } else {
	if (not $geography) {
	    $name = "AS$as";
	} else {
	    my $record = $netgeo->getRecord($as);
	    if (!defined($record) || !defined($record->{"NAME"}) ||
		$record->{"NAME"} eq "")
	    {
		$name = "AS$as";
	    } else {
		$name = $record->{"NAME"} . " ($as)";
	    }
	}
    }
	
    $as_name_memo{$as} = $name;
	
    return $name;
}

sub do_vpvc_name($$ ) {
# ------------------------------
# Put in hyperlink to vpvc data
# ------------------------------
    my $table = shift;
    my $key = shift;
    my $VPVC_NAMES = $config->get('subif_names');
    my ($vpvc) = $table->get_key_fields($key);
    (my $vpvc_clean = $vpvc) =~ s/\[|\]|:/_/g;
#    $vpvc_clean =~ s/%3a/:/;
    my $name = $VPVC_NAMES->{$vpvc};
    if ($name) {
	return "<A HREF=\"./$vpvc_clean\">$name ($vpvc)</A>";
    } else {
	return "<A HREF=\"./$vpvc_clean\">$vpvc</A>";
    }
}

sub do_vpvc_chart_name($$ ) {
# ------------------------------
# Put name for chart
# ------------------------------
    my $table = shift;
    my $key = shift;
    my $VPVC_NAMES = $config->get('subif_names');

    my ($vpvc) = $table->get_key_fields($key);
    my $name = $VPVC_NAMES->{$vpvc};
    if ($name) {
	return("$name ($vpvc)");
    } else {
	return("$vpvc");
    }
}

sub do_flows_name($$ ) {
# -----------------------------
# Hack to get in all the data
# for each tuple into table
# -----------------------------
    my ($table, $opaque_key) = @_; 
    my ($src, $dst, $proto, $ok, $sport, $dport) =
		$table->get_key_fields($opaque_key);
	
    # Get global state information.
    my %PROTO_NAMES = %{$config->get('PROTO_NAMES')};
	my $promiscuous = $config->get('promiscuous');

	
    unless ($promiscuous) {
	$src = CAIDA::Traffic2::Encode::encode_addr($src);
	$dst = CAIDA::Traffic2::Encode::encode_addr($dst);
    }
	
    my $proto_name = $PROTO_NAMES{$proto} || "$proto";
    $proto = "$proto_name ($proto)";
	
    if (not $ok) {
	$sport = $dport = "unknown";
    }
    return("$src</TD><TD>$dst</TD><TD>$proto</TD><TD>$sport</TD><TD>$dport");
	
} # End

sub do_proto_ports_name($$ ) {
# -----------------------------
# Hack to get in all the data
# for each tuple into table
# -----------------------------
    my ($table, $opaque_key) = @_; 
    my ($proto, $ok, $sport, $dport) =
		$table->get_key_fields($opaque_key);
	
    # Get global state information.
    my %PROTO_NAMES = %{$config->get('PROTO_NAMES')};
	
	
    my $proto_name = $PROTO_NAMES{$proto} || "$proto";
    $proto = "$proto_name ($proto)";
	
    if (not $ok) {
	$sport = $dport = "unknown";
    }
    return("$proto</TD><TD>$sport</TD><TD>$dport");
	
} # End


#######################################################
# rrd functions
#######################################################

sub rrd_graph_proto ($$$ ) {
# -----------------------------------------------------
# Create optional RRDTool graphs for those sites that
# want time-series data output.  Graphs can be created
# for VPVC data and Protocol data.
# -----------------------------------------------------
# vpvc proto count_ref

    my ($vpvc, $unit, $end_time) = @_;
    my $vpvc_clean = $vpvc;
    $vpvc_clean =~ s/:/_/;
    my @GRAPH;

    # Get configuration state information
    my $html_dir = $config->get('html_dir');
    my $RRD_DIR = $config->get('RRD_DIR');
    my @RRD_PROTOS = @{$config->get('RRD_GRAPH_PROTOS')};
    my @RRDCOLORS = @{$config->get('RRDCOLORS')};
    my %PROTO_NAMES = %{$config->get('PROTO_NAMES')};
    my $width = $config->get('rrd_graph_width');
    my $height = $config->get('rrd_graph_height');
    my @time_intervals = @{$config->get('rrd_time_samples')};
    
    # Loop through protocols
    push @RRD_PROTOS, "total";
    foreach my $proto (@RRD_PROTOS){
	push(@GRAPH, 
	     "DEF:Pavg$proto=$RRD_DIR/$vpvc_clean/proto/$proto.rrd:$unit:AVERAGE");
	push(@GRAPH, 
	     "DEF:Pmax$proto=$RRD_DIR/$vpvc_clean/proto/$proto.rrd:$unit:MAX");
	push(@GRAPH, 
	     "DEF:Pmin$proto=$RRD_DIR/$vpvc_clean/proto/$proto.rrd:$unit:MIN");
	foreach my $func ('avg', 'max', 'min') {
	    my $cdef = "CDEF:C$func$proto=P$func$proto";
	    if ($unit eq "bytes") {
		$cdef .= ",8,*";
	    }
	    push @GRAPH, $cdef;

	    # Make unknown into 0 for graphing.
	    my $cdef_z = "CDEF:CZ$func$proto=C$func$proto,UN,0,C$func$proto,IF";
	    push @GRAPH, $cdef_z;
	}
    }
    pop @RRD_PROTOS;
    #Define total traffic, Top N apps, and difference
    foreach my $range (qw(min avg max)) {
	push @GRAPH, "CDEF:C${range}subtotal=0,CZ$range" .
			  join(",+,CZ$range", @RRD_PROTOS) .  ",+";
	# For the GPRINT line
	push @GRAPH, "CDEF:C${range}other=0,CZ${range}total," .
			 "C${range}subtotal,-,MAX";
	# For the graph
	push @GRAPH, "CDEF:CZ${range}other=C${range}other";
    }
    push @RRD_PROTOS, "other";

    # Pad number of characters in protocols.
    my $key_str = "Protocol";
    my $pad = length($key_str);
    foreach my $proto (@RRD_PROTOS){
	my $proto_name = get_proto_name($proto);

	if (length($proto_name) > $pad) {
	    $pad = length($proto_name);
	}
    }

    push @GRAPH, "COMMENT:  $key_str " . (" " x ($pad - length($key_str)));
    push @GRAPH, "COMMENT:         Min";
    push @GRAPH, "COMMENT:         Avg";
    push @GRAPH, "COMMENT:         Max  \\c";
    # Trick to fake out RRDtool and set the numerical scale.
    if (@RRD_PROTOS > 0) {
	push @GRAPH, "PRINT:Cavg" . $RRD_PROTOS[0] . ":AVERAGE:%10.2lf %S";
    }

    my  $TAG = "AREA";
    foreach my $proto (@RRD_PROTOS){
	my $color;
	if ($proto eq "other") {
	    $color = "#000000"; # Make other category black for contrast
	} else {
	    $color = shift @RRDCOLORS;
	    push @RRDCOLORS, $color;
	}
	my $proto_name = get_proto_name($proto);
	push @GRAPH, "$TAG:CZavg$proto$color:$proto_name";
	push @GRAPH, "COMMENT: " . (" " x ($pad - length($proto_name)));
	push @GRAPH, "GPRINT:Cmin$proto:MIN:%10.2lf %S";
	push @GRAPH, "GPRINT:Cavg$proto:AVERAGE:%10.2lf %S";
        push @GRAPH, "GPRINT:Cmax$proto:MAX:%10.2lf %S\\c";

	$TAG = "STACK";
    }

    my $label = $unit;
    if ($unit eq "bytes") {
	$label = "bits";
    }
    $label .= "/s";
    
# Change if you want Universal Time instead
#    my $time = strftime("%c UTC", gmtime(time()));
    my $time = strftime("%c %Z", localtime(time()));
    if ($RRDs::VERSION >= 1.2) {
	$time =~ s/:/\\:/g;
    }
    push @GRAPH, "COMMENT:\\s";
    push @GRAPH, "COMMENT:generated $time\\c";

    # Save time zone so that it can be reverted after running RRDGraph
#    my $save_tz = $ENV{"TZ"};
#    $ENV{"TZ"} = "UTC";

    # Loop through hours, days, weeks, months.
    foreach my $length  (@time_intervals) {
        my $title = "Protocol Breakdown - ";
	if ($length < 24) {
	    $title .= "$length hour" . ($length == 1 ? "" : "s");
	} else {
	    my $day_length = $length / 24;
	    $title .= "$day_length day" . ($day_length == 1 ? "" : "s");
	}

	# Produce graphs
	RRDs::graph("$html_dir/$vpvc/ts_proto_${unit}_$length.gif", 
		    "--title", $title,
		    "--width", $width,
		    "--height", $height,
		    "--vertical-label", "${label}", 
		    "--start" , "end-" . $length*(3600),
		    "--end", $end_time,
#		    "--lazy",
		    "--lower-limit", 0,
		    @GRAPH,);
		    my $ERROR =  RRDs::error();
	if ($ERROR) {
	    die "While generating $html_dir/$vpvc/ts_proto_${unit}_$length.gif:" .
		" $ERROR";
	}
    }    
    
    # Return time zone if needed.
#    $ENV{"TZ"} = $save_tz;
}

sub rrd_graph_app ($$$$$$;$ ) {
# -----------------------------------------------------
# Create optional RRDTool graphs for those sites that
# want time-series data output.  Graphs are created on
# applications in the preference file for each VPVC.
# This same routine graphs the top 'N" applications
# for a given sample interval if that option is
# enabled.  It can compute an 'other' category if
# the 5th parameter is set to true.  The other category
# is computed by substracting the traffic from the top 
# 'N' applications from all the traffic as measured by
# all protocols.
# -----------------------------------------------------

    my $vpvc = shift;
    my $unit = shift;
    my $end_time = shift;
    my @RRD_APPS = @{shift(@_)};
    my $directory = shift;
    my $other = shift;
    my $prefix = shift;
    my $vpvc_clean = $vpvc;
    $vpvc_clean =~ s/:/_/;
    my @GRAPH = ();

    # Get configuration state information
    my $html_dir = $config->get('html_dir');
    my $RRD_DIR = $config->get('RRD_DIR');
    my @RRDCOLORS = @{$config->get('RRDCOLORS')};
    my $top_n_count = $config->get('rrd_display_count');
    my $width = $config->get('rrd_graph_width');
    my $height = $config->get('rrd_graph_height');
    my @time_intervals = @{$config->get('rrd_time_samples')};
    my @app_list;

#    my $save_tz;
    my $label;
    my $color;

    #If we are looking at the top N limit to display count.
    if($prefix eq "top_n_" and @RRD_APPS > $top_n_count) {
	@RRD_APPS = @RRD_APPS[0..$top_n_count-1];
    }

    # Loop through applications
    my $app_counter = 0;
    my $app_n;
    foreach my $app_ref (@RRD_APPS) {
	my ($app) = @$app_ref;
	    $app_n = "app" . $app_counter++;
	    push @app_list, $app_n;
	push (@GRAPH, 
	      "DEF:Pavg$app_n=$RRD_DIR/$vpvc_clean/$directory/$app.rrd" . 
	      ":$unit:AVERAGE");
	push (@GRAPH, 
	      "DEF:Pmax$app_n=$RRD_DIR/$vpvc_clean/$directory/$app.rrd" . 
	      ":$unit:MAX");
	push (@GRAPH, 
	      "DEF:Pmin$app_n=$RRD_DIR/$vpvc_clean/$directory/$app.rrd" . 
	      ":$unit:MIN");
	# Fix data that is in bytes to be bits/sec
	foreach my $func ('avg', 'max', 'min') {
	    my $cdef = "CDEF:C$func$app_n=P$func$app_n";
	    if ($unit eq "bytes") {
		$cdef .= ",8,*";
	    }
	    # Make unknown into 0 for graphing.
	    my $cdef_z = "CDEF:CZ$func$app_n=C$func$app_n,UN,0,C$func$app_n,IF";
	    push @GRAPH, $cdef;
	    push @GRAPH, $cdef_z;
	}
    } # Foreach app

    # Add the other category if desired.
    if ($other) {
	# Define total
	push @GRAPH, 
	  "DEF:Pavgtotal=$RRD_DIR/$vpvc_clean/proto/total.rrd:$unit:AVERAGE";
	push @GRAPH, 
	  "DEF:Pmaxtotal=$RRD_DIR/$vpvc_clean/proto/total.rrd:$unit:MAX";
	push @GRAPH, 
	  "DEF:Pmintotal=$RRD_DIR/$vpvc_clean/proto/total.rrd:$unit:MIN";
	# Fix data that is in bytes to be bits/sec
	foreach my $func ('avg', 'max', 'min') {
	    my $cdef = "CDEF:C${func}total=P${func}total";
	    if ($unit eq "bytes") {
		$cdef .= ",8,*";
	    }
	    # Make unknown into 0 for graphing.
	    my $cdef_z =
		"CDEF:CZ${func}total=C${func}total,UN,0,C${func}total,IF";
	    push @GRAPH, $cdef;
	    push @GRAPH, $cdef_z;
	}
	
	#Define other
	foreach my $range (qw(min avg max)) {
	    push @GRAPH, "CDEF:C${range}MainApps=0,CZ$range" .
			      join(",+,CZ$range", @app_list) .  ",+";
	    # For the GPRINT line
	    push @GRAPH, "CDEF:C${range}other=0,CZ${range}total," .
			     "C${range}MainApps,-,MAX";
	    # For the graph
	    push @GRAPH, "CDEF:CZ${range}other=C${range}other";
	}
	# Add "other" to list of apps to graph.
	push @RRD_APPS, ["other", "other"];
    }
    
    # Pad number of characters in application name
    my $key_str = "Application";
    my $pad = length($key_str);
    foreach my $app_ref (@RRD_APPS){
	my ($app, $app_name) = @$app_ref;
	my $app_str = "$app ($app_name)";
	
	if (length($app_str) > $pad) {
	    $pad = length($app_str);
	}
    }

    push @GRAPH, "COMMENT:  $key_str " . (" " x ($pad - length($key_str)));
    push @GRAPH, "COMMENT:         Min";
    push @GRAPH, "COMMENT:         Avg";
    push @GRAPH, "COMMENT:         Max  \\c";
    # Trick to fake out RRDtool and set the numerical scale.
    if (@RRD_APPS > 0) {
	push @GRAPH, "PRINT:Cavgapp0:AVERAGE:%10.2lf %S";
    }

    my  $TAG = "AREA";
    $app_counter = 0;
    foreach my $app_ref (@RRD_APPS){
	$app_n = "app" . $app_counter++;
	my ($app, $app_name) = @$app_ref;
	my $app_str = "$app ($app_name)";
	my $length = length($app_str);
	$app_str =~ s/:/\\:/g;
	if ($app eq "other") {
	    $color = "#000000"; # Make other category black for contrast
	    $app_n = $app;
	} else {
	    $color = shift @RRDCOLORS;
	    push @RRDCOLORS, $color;
	}
	push @GRAPH, "$TAG:CZavg$app_n$color:$app_str";
	push @GRAPH, "COMMENT: " . (" " x ($pad - $length));
	push @GRAPH, "GPRINT:Cmin$app_n:MIN:%10.2lf %S";
	push @GRAPH, "GPRINT:Cavg$app_n:AVERAGE:%10.2lf %S";
	push @GRAPH, "GPRINT:Cmax$app_n:MAX:%10.2lf %S\\c";
	
	$TAG = "STACK";
    }

    $label = $unit;
    if ($unit eq "bytes") {
	$label = "bits";
    }
    $label .= "/s";
    
    # Change if you want Universal Time instead
    #    my $time = strftime("%c UTC", gmtime(time()));
    my $time = strftime("%c %Z", localtime(time()));
    if ($RRDs::VERSION >= 1.2) {
	$time =~ s/:/\\:/g;
    }
    push @GRAPH, "COMMENT:\\s";
    push @GRAPH, "COMMENT:generated $time\\c";


    # Save time zone so that it can be reverted after running RRDGraph
#    $save_tz = $ENV{"TZ"};
    #    $ENV{"TZ"} = "UTC";

    # Loop through hours, days, weeks, months.
    foreach my $length  (@time_intervals) {
	my $title = "Application Breakdown - ";
	if ($length < 24) {
	    $title .= "$length hour" . ($length == 1 ? "" : "s");
	} else {
	    my $day_length = $length / 24;
	    $title .= "$day_length day" . ($day_length == 1 ? "" : "s");
	}

	if ($debug >= 4) {
	    foreach my $command (@GRAPH) {
		print STDERR "$command\n";
	    }
	}

	# Produce graphs
	RRDs::graph("$html_dir/$vpvc/ts_${prefix}app_${unit}_$length.gif", 
		    "--title", $title,
		    "--width", $width,
		    "--height", $height,
		    "--vertical-label", $label, 
		    "--start" , "end-" . $length*(3600),
		    "--end", $end_time,
#		    "--lazy",
		    "--lower-limit", 0,
		    @GRAPH,);
	    my $ERROR =  RRDs::error();
	    if ($ERROR) {
		print STDERR join(' ', "While generating ", 
			 "$html_dir/$vpvc/ts_app_${unit}_$length.gif:" .
			 " \n$ERROR\n");
		if ($debug) {
		    print STDERR "Error caused by the following commands:\n";
		    foreach my $command (@GRAPH) {
			print STDERR "\t$command\n";
		    }
		}
		die;
	    }
    }    
    # Return time zone if needed.
#    $ENV{"TZ"} = $save_tz;
} # End rrd_graph_app

sub rrd_graph_proto_percent ($$$){
# -----------------------------------------------------
# Make Percentage graphs from RRD data.
# -----------------------------------------------------
    my ($vpvc, $unit, $end_time) = @_;
    my $vpvc_clean=$vpvc;
    $vpvc_clean =~ s/:/_/;

    # Get configuration state information
    my $html_dir = $config->get('html_dir');
    my $RRD_DIR = $config->get('RRD_DIR');
    my @RRD_PROTOS = @{$config->get('RRD_GRAPH_PROTOS')};
    my @RRDCOLORS = @{$config->get('RRDCOLORS')};
    my %PROTO_NAMES = %{$config->get('PROTO_NAMES')};
    my $width = $config->get('rrd_graph_width');
    my $height = $config->get('rrd_graph_height');
    my @time_intervals = @{$config->get('rrd_time_samples')};
	
    my @GRAPH;
	
    foreach my $proto (@RRD_PROTOS){
	push @GRAPH, 
	  "DEF:raw$proto=$RRD_DIR/$vpvc_clean/proto/$proto.rrd:$unit:AVERAGE";
	push @GRAPH, "CDEF:cooked$proto=raw$proto,UN,0,raw$proto,IF";
    };
    push @GRAPH, "DEF:total=$RRD_DIR/$vpvc_clean/proto/total.rrd:$unit:AVERAGE";
    push @GRAPH, "CDEF:subtotal=0,cooked" . join (",+,cooked", @RRD_PROTOS)
		    . ",+";
	
    foreach my $proto (@RRD_PROTOS){
	push @GRAPH, "CDEF:percent$proto=cooked$proto,total,/,100,*";
    }
#    push @GRAPH, "CDEF:subtotal=0,percent" . join (",+,percent", @RRD_PROTOS)
#		    . ",+";
    push @GRAPH, "CDEF:percentother=total,subtotal,-,total,/,100,*";
#    push @GRAPH, "CDEF:percentother=100,subtotal,-";
	
    my  $TAG = "AREA";
    foreach my $proto (@RRD_PROTOS){
	my $color = shift @RRDCOLORS;
	push @RRDCOLORS, $color;
	my $proto_name = get_proto_name($proto);
        push @GRAPH, "$TAG:percent$proto$color:$proto_name";
	$TAG = "STACK";
    }
    push @GRAPH, "STACK:percentother#000000:other";
	
#    my $time = strftime("%c UTC", gmtime(time()));
    my $time = strftime("%c %Z", localtime(time()));
    if ($RRDs::VERSION >= 1.2) {
	$time =~ s/:/\\:/g;
    }
    push @GRAPH, "COMMENT:\\s";
    push @GRAPH, "COMMENT: ";
    push @GRAPH, "COMMENT:\\s";
    push @GRAPH, "COMMENT:generated $time\\c";
	
    my $label = "percentage $unit";
	
#    my $save_tz = $ENV{"TZ"};
#    $ENV{"TZ"} = "UTC";
	
    foreach my $length  (@time_intervals) {
        my $title = "Protocol Breakdown - ";
	if ($length < 24) {
	    $title .= "$length hour" . ($length == 1 ? "" : "s");
	} else {
	    my $day_length = $length / 24;
	    $title .= "$day_length day" . ($day_length == 1 ? "" : "s");
	}
	
	RRDs::graph("$html_dir/$vpvc/ts_proto_percent_${unit}_$length.gif", 
		    "--title", $title,
		    "--width", $width,
		    "--height", $height,
		    "--vertical-label", "${label}", 
		    "--start" , "end-" . $length*(3600),
		    "--end", $end_time,
#		    "--lazy",
		    "--lower-limit", 0,
		    "--upper-limit", 100,
		    "--rigid",
		    @GRAPH,);
	my $ERROR = RRDs::error();
	die "While generating $html_dir/$vpvc/ts_proto_percent_${unit}_$length.gif: $ERROR" if $ERROR;
    }    
    
#    $ENV{"TZ"} = $save_tz;
}


sub rrd_db_update ($$$$$$ ) {
# --------------------------------------------
# Add data to RRD files.
# --------------------------------------------
    my($vpvc,$table_type,$key,$time,$duration,$count_ref) = @_ ;

    # Get configuration state information
    my $RRD_DIR = $config->get('RRD_DIR');

    unless (defined $count_ref) {
	$count_ref=new CAIDA::Traffic2::FlowCounter();
    }

    RRDs::update("$RRD_DIR/$vpvc/$table_type/$key.rrd",
		 ## Can add if desired "--template", "bytes:packets:tuples",
		 "$time:".($count_ref->bytes()/$duration).":".
		 ($count_ref->pkts()/$duration).":".
		 ($count_ref->flows()/$duration));
    my $ERROR = RRDs::error();
    if ($ERROR) {
	die "While updating $RRD_DIR/$vpvc/$table_type/$key.rrd: $ERROR";
    }
}

# arg vpvc

sub rrd_db_existence($$$ ) {
# --------------------------------------------
# Helper predicate based on rrd_db_create to
# make a simple test to see if the RRDtool
# database file exists or not.
# --------------------------------------------
    my ($vpvc, $table_type, $key ) = @_;

    # Get configuration state information
    my $RRD_DIR = $config->get('RRD_DIR');

    return (-f "$RRD_DIR/$vpvc/$table_type/$key.rrd");
}

sub rrd_db_create ($$$$ ) {
# --------------------------------------------
# Create RRD files if needed.
# --------------------------------------------
    my ($vpvc, $table_type, $key, $start_time) = @_;

    # Get configuration state information
    my $RRD_DIR = $config->get('RRD_DIR');

    my $vpvc_clean = $vpvc;
    $vpvc_clean =~ s/:/_/;

    # XXX Check return values be graceful.
    unless (-d "$RRD_DIR/$vpvc") {
	mkdir("$RRD_DIR/$vpvc", 0755);
    }
    unless (-e "$RRD_DIR/$vpvc_clean") {
	symlink "$vpvc", "$RRD_DIR/$vpvc_clean";
    }
    unless (-d "$RRD_DIR/$vpvc/$table_type") {
	mkdir("$RRD_DIR/$vpvc/$table_type", 0755);
    }
    if (not -f "$RRD_DIR/$vpvc/$table_type/$key.rrd") {
	RRDs::create ("$RRD_DIR/$vpvc/$table_type/$key.rrd",
		      "--start", $start_time,
		      "--step", '300',
		      "DS:bytes:GAUGE:600:U:U",
		      "DS:packets:GAUGE:600:U:U",
		      "DS:tuples:GAUGE:600:U:U",
		      "RRA:AVERAGE:0.5:1:".(2*24*12),
		      "RRA:MIN:0.5:1:".(2*24*12),
		      "RRA:MAX:0.5:1:".(2*24*12),
		      "RRA:AVERAGE:0.5:6:".(2*7*48),
		      "RRA:MIN:0.5:6:".(2*7*48),
		      "RRA:MAX:0.5:6:".(2*7*48),
		      "RRA:AVERAGE:0.5:24:".(2*12*32),
		      "RRA:MIN:0.5:24:".(2*12*32),
		      "RRA:MAX:0.5:24:".(2*12*32),
		      "RRA:AVERAGE:0.5:288:".(760),
		      "RRA:MIN:0.5:288:".(760),
		      "RRA:MAX:0.5:288:".(760));
	my $ERROR = RRDs::error();
	if ($ERROR) {
	    die "While creating $RRD_DIR/$vpvc/$table_type/$key.rrd: $ERROR";
	}
    }
}

sub initialize_t2_report($$) {
# --------------------------------------
# Subroutine to carry out any initial
# setup needed to get t2_report to
# begin processing data.  This includes
# creating directories, opening 
# filehandles and other housekeeping.
# 
# This work used to be carried out by 
# the same subroutine that processed 
# command line arguments.
# --------------------------------------
    my $html_dir = shift;
    my $args_ref = shift;
    my $RRDtool = $config->get('RRDtool');
    my $RRD_DIR = $config->get('RRD_DIR');
    my $site_name = $config->get('site_name');
    my $traffic2_dump_dir = $config->get('traffic2_dump_dir');
    my $source_file;
    
    # Unless directory exists we better make it.
    unless ((-w $html_dir) and (-d $html_dir)) {
	unless ($html_dir and mkdir("$html_dir", 0755)) {
	    die	 "Unable to create destination directory $html_dir\n$!";
	}
    }
    Debug_Diag($debug, "Report destination directory: $html_dir");
    
    # Unless $RDDtool directory exists we better make it.
    if ($RRDtool) {
	if (-d $RRD_DIR) {
	    unless (-w $RRD_DIR) {
		die "Fatal: RRD directory $RRD_DIR is not write-able\n";
	    }
	    my $ver_file = new IO::File "$RRD_DIR/version";
	    my $version;
	    unless ($ver_file and ($version = <$ver_file>) and
		    $version >= $VERSION)
	    {
		print STDERR
		    "Trying to use obsolete RRD directory $RRD_DIR.\n",
		    "Either use a different directory or ", 
		    "convert this one to the newer format.\n",
		    "Information regarding this can be found in the t2_report ",
		    "documentation\n";
		exit;
	    }
	} else {
	    unless (mkdir("$RRD_DIR", 0755)) {
		die "Fatal:  Unable to create RRD directory $RRD_DIR: $!";
	    }
	    my $ver_file = new IO::File ">$RRD_DIR/version";
	    print $ver_file "$VERSION\n";
	}
	Debug_Diag($debug, "RRD directory: $RRD_DIR");
    }
    
    Debug_Diag($debug, "Site name title set to: $site_name");

    # Check if the traffic2 dump directory exists 
    if ($traffic2_dump_dir) {
	unless ((-w $traffic2_dump_dir) and (-d $traffic2_dump_dir)) {
	    unless (mkdir("$traffic2_dump_dir", 0755)) {
		die "Unable to create traffic2 dump directory" .
                    "$traffic2_dump_dir\n$!";
	    }
	}
	Debug_Diag($debug, "Traffic2 dump directory: $traffic2_dump_dir");
    }

    # Check optional argument either return filename or undef.
    my @args = @$args_ref;
    if ($#args > -1) {
	$source_file =  shift(@args);
	unless (-r $source_file) {
	    die "Unable to access source file: $source_file\n $!";
	}
	Debug_Diag($debug, "Using source file: $source_file");
	return($source_file); # Got a filename - return it.
    } else {
	# or else return previous config settings (if any)
	return($config->get('source_file'));
    }
} #End sub initialize_t2_report

sub reload_configuration($ ) {
# -----------------------------------------------------------
# Routine to go through the motions of reloading the 
# Configuration state from files.  This is called when a 
# signal is received from the user.
# -----------------------------------------------------------
    my $app_ports_file = shift;
    my $find_AS = $config->get('asfinder');
    my $InternetApps = $config->get('internetapps');



    # Preserve state of Perl module related configuration.
    my $AS_state = $config->get('asfinder');
    my $NetGeo_state = $config->get('netgeo');
    my $RRD_state = $config->get('RRDtool');
    if ($debug) {
	print STDERR "-D> Reloading configuration files at ", 
	scalar(localtime()), "\n";
    }

    # Clobber the configuration arrays because AppConfig appends
    reset_config_state($config);
    # Call the same routine to reinitialize configuration
    my @args = @ARGV;
    get_config_state($config, $coral_dir, \@args);
    $debug = $config->get('debug');

    # If any of the Perl state configuration was changed - override.
    if ($AS_state != $config->get('asfinder') or
	$NetGeo_state != $config->get('netgeo') or
	$RRD_state != $config->get('RRDtool')
       ) {
	print STDERR "WARNING: Attempt to change loaded Perl modules ",
	             "in the middle of $0\n",
	             "Changes will be ignored\n";
	$config->set('asfinder', $AS_state);
	$config->set('netgeo', $NetGeo_state);
	$config->set('RRDtool', $RRD_state);
    }
    if ($config->get('RRD_backdate')) {
	$config->set('RRD_backdate', 0);
    }
    # Dump final state of variables if in debug mode 
    if ($debug >= 2) {
	dump_config_state($config);
    }

    # Reload AS table if one exists.
    if ($find_AS) {
	if (-e $config->get('route_table')) {
	    $as_finder->load_file_text($config->get('route_table'));	
	}
    }

    # Reload ports if we get signal to reload ports file.
    if ($app_ports_file and $InternetApps) {
	$app_ports_obj->clear();
	$app_ports_obj->load_rules($app_ports_file);
    }
    if ($debug == 3) {
	$app_ports_obj->dump_rules();
    }
    # Print out status of some key configuration variables
    if ($debug) {
	output_status();
    }
} # End of Reload configuration.

sub output_status( ) {
# ------------------------------------------------
# Convenient subroutine that groups "vitals"
# that should be reported on whenever t2_report
# is either started or configuration variables
# are reloaded.
# ------------------------------------------------
    my $InternetApps = $config->get('internetapps');
    my $RRD_top_apps = $config->get('with_rrd_top_apps');
    my $graph_tool = $config->get("graphtool");
    my $NoTotals = $config->get('zaptotals');

    Print_Diag("Graphing output tool: $graph_tool");
    if ($NoTotals) {
	Print_Diag("Totals for all VPVCs has been disabled");
    } else {
	Print_Diag("Totals for all VPVCs has been enabled");
    }

    if($InternetApps and $RRD_top_apps) {
	Print_Diag("Internet Application tracking enabled");
	Print_Diag("Top application timeseries plotting enabled");
    }    
    elsif($InternetApps) {
	Print_Diag("Internet Application tracking enabled");
    } else {
	Print_Diag("Internet Application tracking disabled");
    }

}


#######################################################

# - - - - - - - - - - - - - - - - - - - - - - - - - - -
# Main program
#
# File I/O is evil - replace ASAP!!
# - - - - - - - - - - - - - - - - - - - - - - - - - - -

autoflush STDOUT;

# Reference for read file handle
my $filehdl_ref;
my $sample_count = 0;
my $app_ports_file;
my ($startup_timein, $startup_timeout, $sample_timein, $sample_timeout);
my ($vpvc_timein, $vpvc_timeout);
my ($sample_total, $report_total) = (undef, undef);
my ($report_timein, $report_timeout, $reload_timein, $reload_timeout);

# We won't need first/latest, so don't store them - XXX
$CAIDA::Tables::Generic::default_counter_kind =
	new CAIDA::Traffic2::FlowCounter_Light();

# Create object to store values and combined values
my $combined_obj = new CAIDA::Traffic2::Interval;

# Get configuration state
my @args = @ARGV;
get_config_state($config, $coral_dir, \@args);
$debug = $config->get('debug');

# Force Netgeo and RRDtool options off if not installed
if ($NetGeo_disabled) {
    if($config->get('netgeo')) {
	print STDERR "Attempt to use Netgeo without a complete installation\n";
	print STDERR "Netgeo will be disabled\n";
    }
    $config->set('netgeo', 0);
}
if ($RRD_disabled) {
    if($config->get('RRDtool')) {
	print STDERR 
	    "Attempt to use RRDtool without a complete installation\n";
	print STDERR "RRDtool will be disabled\n";
    }

    $config->set('RRDtool', 0);
}

# Dump final state of variables if in debug mode 
if ($debug >= 2) {
    dump_config_state($config);
}


# Set local variables to global config settings.
my $html_dir = $config->get('html_dir');
my $sample_limit = $config->get('sample_limit');
my $combine = $config->get('combine_samples');
my $combine_format = $config->get('combine_format');
my $find_AS = $config->get('asfinder');
my $geography = $config->get('netgeo');
my $no_totals = $config->get('zaptotals');
my $InternetApps = $config->get('internetapps');
my %VerboseOptions = %{$config->get('verbose')};
my $graph_tool = $config->get('graphtool');

if ($benchmark_enabled) {
    if ($VerboseOptions{'benchmarks'}) {
	$startup_timein = new Benchmark();
	Debug_Diag($debug, "Benchmarking enabled");
	$benchmark = 1;
    } else {
	Debug_Diag($debug, "Benchmarking loaded but not enabled");
    }
}

if (($graph_tool eq "GDGraph") and $GD_disabled) {
        print "Attempting to use GD::Graph without GD::Graph completely ",
	      "installed\n"; 
        warn "Graph output set to \"none\"";
	$graph_tool = "none";
	$config->set("graphtool", $graph_tool);
    }

my $traffic2_dump_dir = $config->get('traffic2_dump_dir');

if ($config->get('promiscuous')) {
  print STDERR "WARNING: Promiscuous mode selected - ",
               "real IP addresses will be shown\n";
}

$app_ports_file = $config->get('AppPorts_rules');
$app_ports_obj = new CAIDA::AppPorts(); # Create a new App ports object.

# Initialize directories and get back source file (if any)
my $source_file = initialize_t2_report($html_dir, \@args);

# Check if ASFinder can be used.
if ($find_AS) {
    eval { $as_finder = new CAIDA::ASFinder(); };
    if ($@) {
	print "Attempting to find AS without ASFinder installed\n";
	warn "ASFinder features will be disabled";
	$find_AS = 0;
	$config->set('asfinder', 0);
    }
    unless(-e $config->get('route_table')) {
	if ($config->get('route_table')) {
	    print "Unable to locate BGP route table: ",
		  $config->get('route_table'), "\n";
	} else {
	    print "No BGP route table defined\n";
	}
	warn "ASFinder features will be disabled";
	$find_AS = 0;
	$config->set('asfinder', 0);
    }
    $as_finder->load_file_text($config->get('route_table'));
}

# Check if Netgeo can truly be used.
if ($geography) {
    if (not $find_AS) {
	warn "Attempt to use Netgeo without ASFinder, " . 
		"Geography features will be disabled";
	$geography = 0;
	$config->set('netgeo', 0);
    } else {
	eval { $netgeo = new CAIDA::NetGeoClient(); };
	if ($@) {
	    warn "unable to create NetGeoClient object, " . 
		"Geography features will be disabled";
	    $geography = 0;
	    $config->set('netgeo', 0);
	}
    }
}

# If there is an application ports listing, load rules for first pass.
if ($app_ports_file and $InternetApps) { 
    $app_ports_obj->clear();
    $app_ports_obj->load_rules($app_ports_file);
    if ($debug == 3) {
	$app_ports_obj->dump_rules();
    }
}

# Print out status of some key configuration variables
if ($debug) {
    output_status();
}

if ($benchmark) {
    $startup_timeout = new Benchmark();
    Print_Benchmark("t2_report startup time was:", 
		    timestr(timediff($startup_timeout, $startup_timein)));
}


# Get source from either file or STDIN
if (defined($source_file)) {
    unless (open(SOURCE, $source_file)) {
	die "Unable to open data file $source_file for reading\n $!";
    }
    $filehdl_ref = \*SOURCE;
} else {
    # We are getting data from standard in - probably a pipe
    $filehdl_ref = \*STDIN;
}

my @table_list;
push @table_list, "Tuple Table", "src IP Table", "dst IP Table",
		    "Proto Ports Table";
my $file_reader = new CAIDA::Traffic2::FileReader($filehdl_ref);
$file_reader->set_desired_table_types(@table_list);

# While we have data, slurp it up!  Stop if debugging and reached limit
SAMPLE_LOOP:
while(((not eof($filehdl_ref)) and ($sample_limit == -1)) or 
      ((not eof($filehdl_ref)) and ($sample_count < $sample_limit)))
{
    if ($benchmark) {
	$sample_timein = new Benchmark();
    }

    my $preload;
    if ($combine_format eq 'none' and $config->get('incremental_read')) {
	# Since we're not combining, it's safe to use incremental reading,
	# as long as the input won't lose data from being blocked.
	# This results in slight memory reduction, especially when data is
	# spread across multiple subinterfaces.
	$preload = 0;
    } else {
	# Any combining must be done with all the data preloaded.
	$preload = 1;
    }
    
    # Get an interval's worth of data
    my $interval = $file_reader->get_next_interval($preload);
    next if not defined $interval;
    $sample_count++;

    # Useful indicator that program is still working properly
    Debug_Diag($debug, "Processing item:", $interval->get_metadata('start'));

    if ($combine_format ne "none") {
	my $int_duration = $interval->get_metadata('duration');
	# Don't need to bother keeping the original around after adding.
	$combined_obj->nadd($interval);
	if ($combine_format eq "time") {
	    if ($combine > $int_duration) {
		$combine -= $int_duration;
		next SAMPLE_LOOP;
	    } else {
		$combine = $config->get('combine_samples')
	    }
	    
	    # Else we have a list of counts.
	} else {
	    if ($combine > 1) {
		$combine--;
		next SAMPLE_LOOP;
	    } else {
		$combine = $config->get('combine_samples');
	    }
	}
    } else {
	# No combining needed - just use sample reference
	$combined_obj = $interval;
    }
    Debug_Diag(($debug and ($combine_format ne "none")),
	       "Processing sample of:", 
	       $combined_obj->get_metadata('duration'), 
	       " seconds");
	
    my $small = { 'table_size' => 17 };
    my $medium = { 'table_size' => 101 };
    my $large = { 'table_size' => 3989 };
    my $vpvc_table = new CAIDA::Tables::VPVC_Table(undef, $medium);
    my $total_tuple_table = new CAIDA::Tables::Tuple_Table();
    my $total_proto_table = new CAIDA::Tables::Proto_Table(undef, $small);

    my $total_app_table = undef;
    if ($InternetApps) {
	$total_app_table = new CAIDA::Tables::AppInfo_Table();
    }
    my $total_src_ip_table = new CAIDA::Tables::IP_Table();
    my $total_dst_ip_table = new CAIDA::Tables::IP_Table();

    my $total_unknown_tcp_table = undef;
    my $total_unknown_udp_table = undef;
    if ($InternetApps) {
	$total_unknown_tcp_table = new CAIDA::Tables::Proto_Ports_Table();
	$total_unknown_udp_table = new CAIDA::Tables::Proto_Ports_Table();
    }
    my ($total_src_as_table, $total_dst_as_table, $total_src_country_table,
	$total_dst_country_table);

    if ($find_AS) {
	$total_src_as_table = new CAIDA::Tables::AS_Table(undef, $large);
	$total_dst_as_table = new CAIDA::Tables::AS_Table(undef, $large);
    }
    if ($geography) { 
	$total_src_country_table = new CAIDA::Tables::Country_Table(undef,
								    $large);
	$total_dst_country_table = new CAIDA::Tables::Country_Table(undef,
								    $large);
    }
	
    # Create the files for each subinterface
    Debug_Diag($debug, "Generating pages at:", scalar localtime);

    if ($benchmark) {
	$sample_timeout = new Benchmark();
	$sample_total = timediff($sample_timeout, $sample_timein);
    }

    my $file_writer;
    if ($traffic2_dump_dir and $DUMP_TRAFFIC2) {
	my $dump_file = join('', $traffic2_dump_dir, "/", 
			     $combined_obj->get_metadata('start'),".t2");
	Debug_Diag($debug, "Dumping sample to file:",
		    $combined_obj->get_metadata('start') . ".t2");
	$file_writer = new CAIDA::Traffic2::FileWriter($dump_file);
	$file_writer->initialize($combined_obj);
	if ($preload) {
	    $file_writer->dump_interval_full();
	} else {
	    $file_writer->dump_interval_start();
	}
    }

    foreach my $vpvc_object ($combined_obj->get_id_infos()) {
	my ($tuple_table, $src_ip_table, $dst_ip_table, $proto_ports_table);
	foreach my $type ($vpvc_object->get_table_types()) {
	    my $table = $combined_obj->get_table($vpvc_object, $type);
	    if (not defined $table) { # Didn't find that type
		next;
	    } elsif ($type =~ /active/) {
		next;  # We don't deal well with 'active' tables.
	    } elsif ($type =~ /Tuple Table/) {
		$tuple_table = $table;
	    } elsif ($type =~ /src IP Table/) {
		$src_ip_table = $table;
	    } elsif ($type =~ /dst IP Table/) {
		$dst_ip_table = $table;
	    } elsif ($type =~ /Proto Ports Table/) {
		$proto_ports_table = $table;
	    } else {
		Debug_Diag($debug, "Unknown table type $type, ignoring");
	    }
	    if ($traffic2_dump_dir and $DUMP_TRAFFIC2 and not $preload) {
		$file_writer->dump_interval_table($vpvc_object, $type, $table);
	    }
	}
	# Don't bother with data-less tables.
	next if not $proto_ports_table or not $src_ip_table or not $dst_ip_table
		    or $proto_ports_table->num_entries() == 0;

	my $total_count = new CAIDA::Traffic2::FlowCounter(
				$vpvc_object->get_metadata("packets"),
				$vpvc_object->get_metadata("bytes"),
				$vpvc_object->get_metadata("flows")  );

	my $vpvc = $vpvc_object->get_metadata('id');
	$vpvc_table->entry_add($vpvc, $total_count);
	
	# Create table objects.  

	if ($benchmark) {
	    $vpvc_timein = new Benchmark();
	}

	my ($proto_table, $app_table, $src_as_table, $dst_as_table,
	    $src_country_table, $dst_country_table,
	    $unknown_tcp_table, $unknown_udp_table) = 
		    generate_vpvc_tables($src_ip_table, $dst_ip_table,
					$proto_ports_table);

	if ($benchmark) {
	    $vpvc_timeout = new Benchmark();
	    my $vpvc_total = timediff($vpvc_timeout, $vpvc_timein);
	    $sample_total = timesum($sample_total, $vpvc_total);
	}

	if ($benchmark) {
	    $vpvc_timein = new Benchmark();
	}
	make_vpvc_pages($combined_obj, $vpvc,
			$tuple_table, $proto_table,
			$app_table,
			$src_ip_table, $dst_ip_table,
			$src_as_table, $dst_as_table,
			$src_country_table, $dst_country_table,
			$unknown_tcp_table, $unknown_udp_table, $total_count); 	

	if ($benchmark) {
	    $vpvc_timeout = new Benchmark();
	    my $vpvc_total = timediff($vpvc_timeout, $vpvc_timein);
	    unless ($report_total) {
		$report_total = new Benchmark();
		$report_total = timediff($report_total, $report_total);
	    }
	    $report_total = timesum($report_total, $vpvc_total);
	}

	if ($benchmark) {
	    $vpvc_timein = new Benchmark();
	}
	
	# Unless totals is turned off, compute totals.
	unless ($no_totals) {
	    $total_tuple_table->nadd($tuple_table) if defined $tuple_table;
	    $tuple_table = undef;
	    $total_proto_table->nadd($proto_table);
	    $proto_table = undef;
	    if ($InternetApps) {
		$total_app_table->nadd($app_table);
		$app_table = undef;
	    }
	    $total_src_ip_table->nadd($src_ip_table);
	    $src_ip_table = undef;
	    $total_dst_ip_table->nadd($dst_ip_table);
	    $dst_ip_table = undef;
	    if ($InternetApps) {
		$total_unknown_tcp_table->nadd($unknown_tcp_table);
		$unknown_tcp_table = undef;
		$total_unknown_udp_table->nadd($unknown_udp_table);
		$unknown_udp_table = undef;
	    }

	    # Add these entries if desired and libraries are available.
	    if ($find_AS) {
		$total_src_as_table->nadd($src_as_table);
		$src_as_table = undef;
		$total_dst_as_table->nadd($dst_as_table);
		$dst_as_table = undef;
	    }
	    if ($geography) { 
		$total_src_country_table->nadd($src_country_table);
		$src_country_table = undef;
		$total_dst_country_table->nadd($dst_country_table);
		$dst_country_table = undef;
	    }
	}
	if ($benchmark) {
	    $vpvc_timeout = new Benchmark();
	    my $vpvc_total = timediff($vpvc_timeout, $vpvc_timein);
	    $sample_total = timesum($sample_total, $vpvc_total);
	}

    }
    if ($traffic2_dump_dir and $DUMP_TRAFFIC2 and not $preload) {
	$file_writer->dump_interval_end();
    }

    if ($benchmark and $InternetApps) {
	Print_Benchmark("Application lookup time:", timestr($app_total));
	undef $app_total;
    }

    if ($benchmark and $config->get('RRDtool')) {
	Print_Benchmark("RRD update time:", timestr($rrd_update_total));
	unless ($config->get('RRD_nograph')) {
	    Print_Benchmark("RRD graph time:", timestr($rrd_graph_total));
	}
	undef $rrd_update_total;
	undef $rrd_graph_total;
    }

    if ($benchmark) {
	$sample_timeout = new Benchmark();
	Print_Benchmark("t2_report sample processing time was", 
			timestr($sample_total));
	undef $sample_total;
    }

    if ($benchmark) {
	$report_timein = new Benchmark();
    }

    # Create total page unless computing totals is turned off.
    unless ($no_totals) {
	make_vpvc_pages($combined_obj, "total",
			$total_tuple_table, $total_proto_table, 
			$total_app_table,
			$total_src_ip_table, $total_dst_ip_table,
			$total_src_as_table, $total_dst_as_table,
			$total_src_country_table, $total_dst_country_table,
			$total_unknown_tcp_table, $total_unknown_udp_table,
			$vpvc_table->total()); 
    }

    # Now that other files are created, create page to access rest
    make_main_index($combined_obj, $vpvc_table, $vpvc_table->total());
	
    if ($benchmark) {
	$report_timeout = new Benchmark();
	my $totals_time = timediff($report_timeout, $report_timein);
	$report_total = timesum($totals_time, $report_total);
	Print_Benchmark("t2_report html generation time was",
			timestr($report_total));
	undef $report_total;
    }

    # Reset the combined interval object.
    $combined_obj = new CAIDA::Traffic2::Interval;

    Debug_Diag($debug, "Pages completed at", scalar localtime);

    # Reload configuration files if we get signal.
    if ($main::RELOAD_CONFIG) {
	$main::RELOAD_CONFIG = 0;
	if ($benchmark) {
	    $reload_timein = new Benchmark();
	}

	reload_configuration($app_ports_file);
	if ($benchmark) {
	    $reload_timeout = new Benchmark();
	    Print_Benchmark("t2_report configuration reload time ",
			    timestr(timediff($reload_timeout, $reload_timein))
			   );
	}

    }

    last if $END_SOON;
} # End data-read while.

# Close source file if data came from a file instead of pipe
if (defined($source_file)) {
    unless (close(SOURCE)) {
	die "Unable to close data file $source_file\n $!";
    }
}

# =============================
# POD Documentation for Script

__END__

=head1 NAME

t2_report++ - Generate HTML reports from the output of crl_flow.

=head1 SYNOPSIS

    t2_report++ <options> [source file]

=head1 DESCRIPTION

B<t2_report++> is an HTML report generator that is part
of the Caida CoralReef Internet Traffic Monitoring Software suite.  It
is intended to read output from the B<crl_flow> program and
produce a series of HTML pages that can include some pie charts and/or
some time-series data stored in RRDtool Round Robin
Databases. B<t2_report++> produces pie charts using either the
GD::Graph module freely available for Perl or alternatively the JClass
Chart Java applet.  The JClass Chart Java applet is a commercial
product.  See http://www.sitraka.com for more information.

=head1 REQUIREMENTS

B<t2_report++> requires Perl 5.004 or greater and two modules from
the CPAN distribution: GD.pm and GD::Graph.pm.  These are B<not>
included with CoralReef but may be obtained at no cost from any
Internet site that provides Perl distributions and the CPAN archive.
These modules depend on some other modules - check the module
documentation for exact details.  GD.pm in turn depends on the C
graphics library gd, which has its own requirements.  In order to get
AS information, you will need the ASFinder module which is included
with CoralReef.  However, you will also need a BGP routing table.
Information on getting such a table can be found in the ASFinder
documentation.  Country information requires the NetGeo client that is
also included in the CoralReef distribution.  Finally, if you wish to
use Round Robin Databases you will need RRDtool.  For more information
on RRDtool see: http://ee-staff.ethz.ch/~oetiker/webtools/rrdtool/

=head1 CONFIGURATION

Because B<t2_report++> supports long command line options, all options
require a space between the letter (or now word) and the value.  In
addition, the command line option formerly C<-c> (for combining) has been
changed to C<-m> (or C<--merge>).  C<-c> (or C<--command>) now allows the
user to specify extra options.

B<t2_report++> looks for a configuration file in the F<etc>
directory of the CoralReef file tree, the directory F<~/.Coral>
directory of the user running B<t2_report++> and then configuration
files specified in the command line arguments.  This permits nested
configuration commands.  A configuration file can be specified on the
command line and it will be processed before any other command line
arguments.  The default name for the configuration file is
F<t2_report.conf>.  However, any filename can be passed as a command
line argument.  Because the same parser is used for command line
arguments as for config file items, the same syntax is used for both.
The only difference is that on the command line, the
configuration variable names are preceded by one or two dashes.
It is recommended that users only modify variables on the
command line for which single character aliases exist.

 +-------------------------------------------------------------------------+
 |              Config file variables and command line options             |
 +--------------+-----+---------------------------+------------------------+
 | Long name    |short| Controls                  | Arguments              |
 +--------------+-----+---------------------------+------------------------+
 | ASfinder     |  a  | Using ASFinder for IP->AS | 0, 1, or BGP table     |
 | backdate     |  b  | Backdate RRDtool database | RRDtool date format    |
 | command      |  c  | Configuration commands    | see below              |
 | debug        |  d  | Turn on debugging messages| 0, 1                   |
 | configfile   |  f  | read in config file       | path to config file    |
 | graphtool    |  g  | set graphing output tool  | none, JCChart, GDGraph |
 | help         |  h  | access to UserGuide       | none, list, all, ...   |
 | internetapps |  i  | Track Top-N applications  | 0, 1                   |
 | javaserver   |  j  | Java server for JCChart   | URL                    |
 | merge        |  m  | time or samples to merge  | see below for format   |
 | netgeo       |  n  | enable IP->country data.  | 0, 1                   |
 | promiscuous  |  p  | turn off IP encoding      | 0, 1                   |
 | RRDtool      |  r  | enable time-series plots  | path to RRD data       |
 | samples      |  s  | limit processing to N     | number of samples      |
 | todisplay    |  t  | change top-10 to top-N    | number to display      |
 | zaptotals    |  z  | suppress totals calcs     | 0, 1                   |
 +--------------+-----+---------------------------+------------------------+ 

There is considerable flexibility in specifying command line arguments.
For example, one or two dashes can be used to specify long command
line arguments.  Also case is ignored.  so C<-r>, C<-rrdtool>, and
C<--RRDtool> have exactly the same effect.

There is usage information available through the option
C<--help> or C<-h>.  Simply specifying that option alone will provide brief
usage information along with the list above of command line options.
--help list provides the same information with as --help, namely a
list of options that can be used along with general usage information.
--help <name> will provide particular details of any command line
option.  --help all is a verbose listing all usage information.

As a matter of efficiency, B<t2_report++> only handles absolute pathnames
for files in the configuration and command-line system.

Four command line options require further explanation.  The C<-c> or
C<--command> option allows for B<t2_report++> configuration options to be
specified in a manner somewhat resembling commands passed to other
CoralReef programs.  This is intended to simplify the use of
B<t2_report++> for coral users.  For example, the option
C<--debug 1> can also be written C<--command 'debug 1'>.  This also
allows for configuration file variables that aren't normally changed
on the command line to be changed.  There is one command line option
which is not accessible in this way.  The configuration file option
(C<--configfile> or C<-f> option will not work via the C<-c> syntax
because it processed before any other command line arguments.

The merge option (not implemented in the current release) allows for
data to be combined from a shorter B<crl_flow> sampling interval into
reports with a longer time-span between reports.  Merging can happen on
either a sample by sample basis or by specifying a time interval.  For
example, if you have B<crl_flow> producing output every minute (60
seconds) then C<--merge 5> would produce 5 minute reports. Specifying
a time is more complicated.  All times require some sort of colon
designation (to differentiate from merging a fixed number of samples.)
In order to provide full functionality, the program assumes that
smaller time steps are implied not larger.  Thus, C<-m 5:> means 5
B<hours> not 5 seconds.  Five minutes would be C<-merge 0:5> and five
seconds would be C<--merge 0:0:5>

The zaptotals option (C<--zaptotals> or C<-z>) allows B<t2_report++> to
skip computing the totals for all the subinterfaces on this link.  This can
be useful on a heavily congested link where the report generator is unable
to keep up with the B<crl_flow> feed.  

B<t2_report++> InternetApps option (C<--InternetApps> or C<-i>)
enables timeseries tracking of the top "N" (user configurable) number
of Internet Applications.  Internet Applications are identified by the
port numbers they use and as recorded in the AppPorts.pm module.
Unlike the configuration settings below which allow users to track a
fixed number of applications, the purpose of this option is to allow
B<t2_report++> to track trends in the top applications.  It thus, can
only be on or off.  It displays the top "N" applications as observed
in the last sample period.  Thus, the cumulative plots do not
necessarily correspond to top applications over the longer term.

In addition to variables listed above.  There are some other variables
that may be set in configuration files only (or by the C<--command>
option).  These are listed below.

 +----------------------------------------------------------------------+
 |                 Config file variables                                |
 +-----------------+---------------------------+------------------------+
 |   Name          | Controls                  | Arguments              |
 +-----------------+---------------------------+------------------------+
 | RRD_DIR         | path to RRD databases     | path to RRD databases  |
 | RRD_GRAPH_PROTOS| Protocols to graph        | RRD protocols to be    |
 |                 |                           | graphed                |
 | PROTO_NAMES     | names displayed for proto.| hash numbers to names  |
 | subif_names     | names displayed for subifs| hash subifs to name    |
 | RRDCOLORS       | values for colors in RRD  | list of hex values     |
 | html_dir        | location for html files   | directory path         |
 | incremental_read| read data in parts instead| 0, 1 (default to 1)    |
 |                 | of all at once            |                        |
 | site_name       | name of site for reports  | text                   |
 | route_table     | BGP table used by ASFinder| path to BGPtable       |
 | source_table    | source data file          | path to file           |
 | rrd_graph_width | width of timeseries graphs| width in pixels        |
 | rrd_graph_height| height of graphs          | height in pixels       |
 | rrd_time_samples| Intervals for RRDtool     | list of times in hours |
 |                 | timeseries databases      |                        |
 | RRD_nograph     | RRD updates but no graphs | 0, 1                   |
 | pie_slices      | Number of slices shown    | number                 |
 | 3d_pie          | Enables 3d pie chart      | 0, 1                   |
 | rrd_graph_apps  | application to graph      | list of names to graph |
 |traffic2_dump_dir| directory for data dumps  | directory for data     |
 +-----------------+---------------------------+------------------------+

Since B<t2_report++> can left running for extended periods of time,
it now permits you to reload the configuration settings by sending
a HUP signal to the report generator while running.
This causes B<t2_report++> go through the same initialization
process that occurs at the start of the program.  Because of this, the
same command line arguments that were passed to the program at startup
are retained.  While this could be seen as a feature, it means that
these settings cannot be changed while the program is running.  Items
in the configuration files on the otherhand can be edited while
B<t2_report++> is running.  For this reason, it is best to place most
configuration information in the configuration files.

If you send a USR1 signal, B<t2_report++> will finish processing its
current interval and then exit.

=head1 CONFIGURATION FILE FORMAT

The sample configuration file F<example_t2_report.conf> is included in
the CoralReef distribution.  The format is consistent with the
AppConfig.pm module and most UNIX applications.  Comment lines are
preceded with the pound sign C<# >.  Identifiers are followed by
values.  To initialize arrays and hashes, each value must be specified
on a separate line.  Below is some sample settings from the B<t2_report++>
configuration file:

     #  Disable ASfinder by default (requires a routing table).
     ASFinder = 0 
     # Disable NetGeo client (it requires ASfinder).
     NetGeo = 0
     # Disable RRDtool unless installed. 
     RRDtool = 0 

     # Protocols to graph.
     RRD_GRAPH_PROTOS = 6
     RRD_GRAPH_PROTOS = 17 
     RRD_GRAPH_PROTOS = 1 
     RRD_GRAPH_PROTOS = 4

     # Set directory to store resulting HTML
     html_dir = "/usr/local/Coral/data/CoralReef_html_dir"

     # Set default graph tool to GDGraph
     # graphtool = "GDGraph"

     # Enable debugging information
     debug = 1


Note that for the sake of consistency, the logical values assigned to
a variable should be explicitly listed as 0 or 1.  The values for
arrays are entered by listing the same variable multiple times.
hashes are handled in a similar fashion with key/value pairs being
listed.


=head1 APPLICATION PORTS FILE

B<t2_report++> can track application based on their
ports they use.  The capability is implemented in the Perl module
F<AppPorts.pm> and the configuration file F<t2_report.ports>.  More
information can be found in the AppPorts documentation.  An example ports
file is provided in the CoralReef distribution in:
F<etc/Application_ports_Master.txt>.

The module provides for both a UNIX/RRDtool compatible name to be used
for nonambiguous identification and a human-friendly description for
display in graphs.  While not presently used, there exists a group
field for coarser aggregation.  Information is also stored to
facilitate tracking the source of the entry.

B<t2_report++> will attempt to collect data on every item in the
F<t2_report.ports> file.  However, it will not display more than the web
page limit sizes set by the configuration file.

=head1 CONFIGURING RRDTOOL TIMESERIES GRAPHS

B<t2_report++> can optionally use RRDtool to keep time series data on
protocols and applications.  To use RRDtool with B<t2_report++>, first
install RRDtool.  You can then use the C<--with-rrd> option when using
C<configure> to install the CoralReef software suite to set the directory
where B<t2_report++> will look for the RRDtool perl libraries.

B<NOTE: For CoralReef 3.5, the RRD directory structure changed from its
previous form.  If you wish to use RRDs created before 3.5, you will need
to convert some of the files.  See the file F<README.RRDtool> in the
apps/traffic/Reporting directory.>

RRDtool can be used to collect data and display graphs.  All protocols and
applications identified are automatically collected, and any subset of them
can be graphed.

You may use the variable C<PROTO_NAMES> to assign descriptive text to
each protocol number.

     # Hash of protocol numbers to names
     PROTO_NAMES 1 = 'ICMP'
     PROTO_NAMES 2 = 'IGMP'
     PROTO_NAMES 4 = 'IPENCAP'
     PROTO_NAMES 6 = 'TCP'
     PROTO_NAMES 17 = 'UDP'
     PROTO_NAMES 47 = 'GRE'
     PROTO_NAMES 50 = 'IPSEC-ESP'
     PROTO_NAMES 51 = 'IPSEC-AH'
     PROTO_NAMES 93 = 'AX.25'
     PROTO_NAMES 94 = 'IPIP'

C<RRD_GRAPH_PROTOS> is another array variable that specifies which
protocols will be graphed.

     # Protocols to graph.
     RRD_GRAPH_PROTOS = 6
     RRD_GRAPH_PROTOS = 17 

For B<t2_report++>, configurating applications is similar, but the
application names come from AppPorts and thus need not be explicitly
specified.

As with protocols, B<t2_report++> can graph any application that it can
identify.  It is likely that you will wish only to graph a subset of these.
This can be done by assigning values to the C<rrd_graph_apps> array.  This
variable expects application identifiers instead of protocol numbers.
These identifiers come from the F<t2_report.ports> file.

     # Applications to be graphed.
     rrd_graph_apps	NAPSTER_DATA
     rrd_graph_apps	REALAUDIO_UDP
     rrd_graph_apps	GNUTELLA
     rrd_graph_apps	QUAKE
     rrd_graph_apps	AOL

=head1 DUMPING ADDITIONAL DIAGNOSTIC INFORMATION

B<t2_report++> takes data from B<crl_flow> in order to generate the
report pages.  While B<crl_flow> is not as complete as raw trace
data, nonetheless the B<crl_flow> output can be useful for
diagnosing events in a network.  B<t2_report++> provides a toggle
switch to permit the saving of B<crl_flow> output for further
processing.  Sending a USR2 signal to B<t2_report++> will cause it to
dump each sample processed into the directory assigned by the
configuration variable I<traffic2_dump_dir>.  If I<traffic2_dump_dir>
is not set, the USR2 signal will be ignored.  To stop the data dumps,
one can send another USR2 signal.  B<Note:>  While B<crl_flow>
files are much smaller than raw trace files, they still grow very
quickly.  Leaving B<t2_report++> in dump mode is likely to fill up all
available disk space in a short time.  When possible, try to use a
separate partition to store the dumps from B<t2_report++>, and always
be cautious in its use.

=head1 T2_REPORT++ USAGE

    t2_report++ <options> [source file]

If a configuration file is used, often no other command line options are
needed.  The source file is also optional.  If there is no file specified,
B<t2_report++> will assume it is getting data from standard in.  This
allows B<t2_report++> to be used as a real-time report generator.  Visit
the CoralReef web site at http://www.caida.org/tools/measurement/coralreef/
to see an example of the report generator being used in this way.

=head1 EXAMPLE

Assuming that all other options are included in the configuration file
F<~/.Coral/t2_report.conf>, the command to run B<t2_report++> on the file
F<vbns_sample> would be:

    t2_report++  vbns_sample

To do the same thing but limit the samples read to 9 and turn off IP
encoding, the command would be:

    t2_report++ -p -s 9 vbns_sample

or using long command line options:

    t2_report++ -promiscuous -sample 9 vbns_sample

To run the report generator on live data, it is important to NOT
use a pipe to connect crl_flow and t2_report.  If the pipe ever fills up,
crl_flow will block until it has cleared, often causing it to lose data.
A better solution is to dump to intermediate files and have t2_report read
those:

    crl_flow -I -O%s.t2 /dev/fatm0
    spoolcat '*.t2' | t2_report++ -c 'site_name="vBNS data"'

(B<spoolcat> is a small script that waits forever in a directory for any
files that match a pattern, prints them to stdout, and can delete/move them.)

Note the use of the C<-c> command to change the site name.  This can be
convenient method to "tweak" multiple runs of B<t2_report++> that otherwise
use the same configuration file.

Also note that the input files to B<t2_report++> MUST have been generated
using the -I option of crl_flow.  The reports require that all flows be
expired at the end of every interval.

=head1 HTML OUTPUT

The default output of B<t2_report++> includes a link to Caida's website,
a logo, and an email address for reaching Caida.  This was done by creating
a Perl module called CustomCaidaHTML.pm (in libsrc/Traffic2, in the source
directory), which is derived from CustomBaseHTML.pm.  To customize the
output for your own site, create your own output module derived from
CustomBaseHTML.pm, and change the source file (t2_report++.pl) to use it.

=head1 KNOWN BUGS

In this release the feature to accumulate samples is disabled.

B<t2_report++> can create a large memory footprint if it reports on data
with many flows.  When listening to a link with many subinterfaces (such as
vp:vcs on an ATM link), the incremental_read option can significantly
reduce memory used.  Memory use can also be reduced by using a shorter
interval with crl_flow.

If memory and/or CPU limitations prevent you from running B<t2_report++>
on a collection machine, B<t2_report++> can be run on a separate machine.
This only requires copying the output files (created with crl_flow's -O
option) to the reporting machine.

=head1 AUTHORS

CoralReef Development team, CAIDA <coral-info@caida.org>

=head1 COPYRIGHT

Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
All Rights Reserved 

Permission to use, copy, modify and distribute any part of this
CoralReef software package for educational, research and non-profit
purposes, without fee, and without a written agreement is hereby
granted, provided that the above copyright notice, this paragraph
and the following paragraphs appear in all copies.

Those desiring to incorporate this into commercial products or use
for commercial purposes should contact the Technology Transfer
Office, University of California, San Diego, 9500 Gilman Drive, La
Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.

IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
THE POSSIBILITY OF SUCH DAMAGE.

THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
ANY PATENT, TRADEMARK OR OTHER RIGHTS.

The CoralReef software package is developed by the CoralReef
development team at the University of California, San Diego under
the Cooperative Association for Internet Data Analysis (CAIDA)
Program. Support for this effort is provided by the CAIDA grant
NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
N66001-01-1-8909, and by CAIDA members.

Report bugs and suggestions to coral-bugs@caida.org.

=cut
