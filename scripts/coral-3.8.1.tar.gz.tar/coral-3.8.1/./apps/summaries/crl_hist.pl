#!/usr/local/bin/perl -w
## 
## Copyright 1999, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
## All Rights Reserved 
## 
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
## 
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (619) 534-5815, FAX: (619) 534-7345.
## 
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
## 
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
## 
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program. Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
## 
## Report bugs and suggestions to coral-bugs@caida.org.
## 


## This script will calculate source and destination address histograms for a
##      Coral format packet dump.  It requires the uncensored data files to
##      generate sensible results.  Based on oc32asc.pl by Hans-Werner Braun
##
## USAGE:  crl_hist.pl <Coral Dump>
##
## $Id: crl_hist.pl,v 2.20 2007/06/06 18:17:32 kkeys Exp $

use strict;

my $coral_dir;
BEGIN { $coral_dir = "/usr/local/Coral"; } # This will be edited during build.
use lib "$coral_dir/lib";	#coral global libdir#
use lib "../../lib";		#coral local libdir#

use CRL;

use CAIDA::CRL_report qw(get_counts
                inc_counts
                parse_header
                print_header
                print_plen_hist
                print_proto_table
                print_port_table
                print_4_table
                print_4_table_top10
                );

##===========================================================================
# global constants

my $cvs_Id = '$Id: crl_hist.pl,v 2.20 2007/06/06 18:17:32 kkeys Exp $';
my $cvs_Author = '$Author: kkeys $';
my $cvs_Name = '$Name: release-3-8-1 $';
my $cvs_Revision = '$Revision: 2.20 $';

# assign $PNAME to the actual program name
use vars qw($PNAME);
($PNAME) = $0 =~ m,([^/]+)$,;

$CAIDA::CRL_report::debug = 0;
my $debug = 0;

my $do_troops = 0;
my $do_ports_top10 = 1;
my $do_plen_hist_byproto = 1;

my $PORTS_OK	= 1;
my $IS_FRAG	= 2;

my $header;

my ($pcount, $bytecount, $opcount);
my ($frags_byproto, $fragcount, $tcpfragcount, $udpfragcount);
my ($nofragcount, $nonip, $start_time, $end_time);

my ($counts_byproto, $matrix_tcp_byport, $matrix_udp_byport);
my ($icmp_bytype, $igmp_bytype);

## We want the packet length histogram to be a list, not a hash
my $plen_hist = [];
my ($counts_tcp_bysourceport, $counts_tcp_bydestport);
my (%histogram_tcp_bysrcport, %histogram_tcp_bydstport);
my ($counts_udp_bysourceport, $counts_udp_bydestport);
my (%histogram_udp_bysrcport, %histogram_udp_bydstport);
my ($counts_byinterface);

my ($ip_opts, $icmp_opts, $igmp_opts);
my ($packet);

my ($llc_dsap, $llc_ssap, $llc_cntl, $snap_org, $snap_type);
my ($timestamp, $timestamp_ptr);
my ($iface, $blockhead, $cell);

my ($interface, $proto, $flags, $sport, $dport, $plen, $packets);

my $script_path = "$coral_dir/bin";

## Port list for AIX
my %interesting_tcp_ports =
	(
	 20	=> 1,		# FTP-data
	 25	=> 1,		# SMTP
	 80	=> 1,		# HTTP
	 110	=> 1,		# POP3
	 119	=> 1,		# NNTP
	 139	=> 1,		# NetBIOS-SSN
	 443	=> 1,		# HTTPS
	 554	=> 1,		# RTSP (Real Audio)
	 1051	=> 1,		# ???
	 1062	=> 1,		# ???
	 1085	=> 1,		# ???
	 1144	=> 1,		# ???
	 1755	=> 1,		# ???
	 3128	=> 1,		# Web Cache
	 5501	=> 1,		# Hotline
	 6000	=> 1,		# X11
	 6688	=> 1,		# ???
	 6697	=> 1,		# Napster
	 6699	=> 1,		# Napster
	 7070	=> 1,		# RealAudio
	 8000	=> 1,		# Shoutcast
	 8080	=> 1,		# Shoutcast
	);

my %interesting_udp_ports =
	(
	 53	=> 1,		# DNS
	 137	=> 1,		# NetBIOS-NS
	 2049	=> 1,		# NFS
	 3130	=> 1,		# ???
	 6112	=> 1,		# Starcraft
	 6770	=> 1,		# ???
	 6970	=> 1,		# RealAudio
	 6971	=> 1,		# RealAudio
	 6972	=> 1,		# RealAudio
	 7070	=> 1,		# RealAudio (summarized)
	 7648	=> 1,		# CU-SeeMe
	 7777	=> 1,		# Unreal
         9000	=> 1,		# ???
         9001	=> 1,		# ???
         9005	=> 1,		# ???
	 27001	=> 1,		# QuakeWorld
	 27005	=> 1,		# ???
	 27015	=> 1,		# Half Life
	 27901	=> 1,		# Quake II
	 27910	=> 1,		# Quake II
	 27960	=> 1,		# Quake 3: Arena
	 27500	=> 1,		# QuakeWorld
	 37370	=> 1,		# ???
	);

## Port list for NCREN traces
#@interesting_tcp_ports = ( 3128, 5501, 7070, 1042, 1158, 1231, 1234, 2643, 2791, 46904, 46935, 46937, 46939, 46948, 46966 );
#@interesting_udp_ports = ( 2049, 1103, 50957, 5320, 3386, 1034, 1029, 1025, 1033, 32872, 1134, 4920, 43522, 5320, 42418, 23824, 4640, 30554, 26406, 5310, 29946 );

##===========================================================================

my $show_names = 0;
if ($show_names) {
    ## Mapping of IP-Protocols to names.
    ## rfc1340 gives many more, these come from a couple merged /etc/protocols
    my %ip_proto_names =
	(
	 0	=> "IP",	# internet protocol, pseudo protocol number
	 1	=> "ICMP",	# internet control message protocol
	 2	=> "IGMP",	# Internet Group Management
	 3	=> "GGP",	# gateway-gateway protocol
	 4	=> "IP-ENCAP",	# IP encapsulated in IP (officially ``IP'')
	 5	=> "ST",	# ST datagram mode
	 6	=> "TCP",	# transmission control protocol
	 8	=> "EGP",	# exterior gateway protocol
	 12	=> "PUP",	# PARC universal packet protocol
	 17	=> "UDP",	# user datagram protocol
	 20	=> "HMP",	# host monitoring protocol
	 22	=> "XNS-IDP",	# Xerox NS IDP
	 27	=> "RDP",	# "reliable datagram" protocol
	 29	=> "ISO-TP4",	# ISO Transport Protocol class 4
	 36	=> "XTP",	# Xpress Tranfer Protocol
	 39	=> "IDPR-CMTP",	# IDPR Control Message Transport
	 41	=> "IPV6",	# internet protocol version 6
	 46	=> "RSVP",	# Resource ReSerVation Protocol
	 58	=> "ICMPV6",	# ICMP for IPv6
	 80	=> "ISO-IP",	# ISO Internet Protocol
	 81	=> "VMTP",	# Versatile Message Transport
	 89	=> "OSPFIGP",	# Open Shortest Path First IGP
	 94	=> "IPIP",	# Yet Another IP encapsulation
	 98	=> "ENCAP",	# Yet Another IP encapsulation (rfc1241)
	 254	=> "DIVERT",	# Divert pseudo-protocol
	);
    
    
    ## Names of a few well known tcp ports
    ## #### maybe should just parse /etc/services.
    my %tcp_port_names =
	(
	 20	=> "ftp-data",
	 22	=> "ssh",
	 23	=> "telnet",
	 25	=> "smtp",
	 80	=> "http",
	 110	=> "pop3",
	 119	=> "nntp",
	 139	=> "netbios-ssn",
	 179	=> "bgp",
	 443	=> "https",
	 513	=> "rlogin",
	 514	=> "rsh",
	 3128	=> "icp",
	);
}

##===========================================================================

sub build_header($) {
    my ($header) = @_;

## crl_bycountry values
#    ${$header}{"bytes_bogus_dst"} = $bytes_bogus_dst;
#    ${$header}{"bytes_bogus_src"} = $bytes_bogus_src;
#    ${$header}{"packets_bogus_dst"} = $packets_bogus_dst;
#    ${$header}{"packets_bogus_src"} = $packets_bogus_src;

    ${$header}{"fragcount"} = $fragcount;
    ${$header}{"tcpfragcount"} = $tcpfragcount;
    ${$header}{"udpfragcount"} = $udpfragcount;
    ${$header}{"total_bytes"} = $bytecount;
    ${$header}{"total_packets"} = $pcount;
    ${$header}{"total_time"} = ${$header}{"end_time"} -
        ${$header}{"start_time"};

## Add in unstructured header lines
    ${$header}{"unstructured"} = "";

    ${$header}{"unstructured"} .= "#Interesting TCP Ports:";
    foreach my $i ( sort { $a <=> $b } keys(%interesting_tcp_ports) ) {
        ${$header}{"unstructured"} .= " $i";
    }
    ${$header}{"unstructured"} .= "\n";

    ${$header}{"unstructured"} .= "#Interesting UDP Ports:";
    foreach my $i ( sort { $a <=> $b } keys(%interesting_udp_ports) ) {
        ${$header}{"unstructured"} .= " $i";
    }
    ${$header}{"unstructured"} .= "\n";

    ${$header}{"unstructured"} .=
        sprintf("#Starts at %.10f, Ends at %.10f, Duration %.10f\n",
        ${$header}{"start_time"},
        ${$header}{"end_time"},
        ${$header}{"total_time"} );

     return $header;
}

##===========================================================================
##
## These routines operate on Unpack.pm output

# SNAP types seen on sdsc dmz: 0x0001 0x0806 0x2000 0x6002 0x6004
# 0x0001	0000-05DC	IEEE802.3 length field
# 0x0806	0806		ARP
# 0x2000			???
# 0x6002	6002		DEC MOP Remote Console
# 0x6004	6004		DEC LAT
# 0x8035	8035		RARP
sub handle_non_ip {

}

sub handle_ip {
    my ($record_ip) = @_;
    
    if ($do_troops) {
        my (%bin, %lastbin, $runcount, %troophist);
        ##
        ## Packet Troops
        ##    We have to be careful about which interface the current block is from...
        ##
        ##    Bins:   0-44
        ##           45-90
        ##           91-180
        ##          181-260
        ##          261-576
        ##          577-1120
        ##         1121+
        ##
        ## Decide which bin the current packet belongs in
        if ( $plen < 45 ) {
            $bin{$interface} = 1;
        } elsif ( $plen < 91 ) {
            $bin{$interface} = 2;
        } elsif ( $plen < 181 ) {
            $bin{$interface} = 3;
        } elsif ( $plen < 261 ) {
            $bin{$interface} = 4;
        } elsif ( $plen < 577 ) {
            $bin{$interface} = 5;
        } elsif ( $plen < 1121 ) {
            $bin{$interface} = 6;
        } else {
            $bin{$interface} = 7;
        }
    
        ## Check if we are at the end of a troop
        if ( $lastbin{$interface} == $bin{$interface} )  {
            $runcount++;
        } else {
            ## We are, so increment the histogram for the previous bin, and reset
            ($troophist{$interface}[$lastbin{$interface}][$runcount])++;
            $runcount = 1;
        }
    
        $lastbin{$interface} = $bin{$interface};
    } # End if ($do_troops)

}    

##===========================================================================
##
##  These routines operate on crl_hist_helper output

sub handle_icmp($$$$) {
    my ($type, $code, $plen, $packets) = @_;

    my $key = "$type\t$code";
    my $bytes = $packets * $plen;
    $icmp_bytype = inc_counts($icmp_bytype, $key, [$packets, $bytes]);
}

sub handle_igmp($$$$) {
    my ($type, $code, $plen, $packets) = @_;

    my $key = "$type\t$code";
    my $bytes = $packets * $plen;
    $igmp_bytype = inc_counts($igmp_bytype, $key, [$packets, $bytes]);
}

sub handle_tcp($$$$) {
    my ($sport, $dport, $plen, $count) = @_;
    
    my ($analy_src, $analy_dst);
    my $packets = $count;
    my $bytes = $plen * $count;
    
    ## Check for `interesting' port numbers
    $analy_src = $interesting_tcp_ports{$sport};
    $analy_dst = $interesting_tcp_ports{$dport};
    
## Calculate source and dest histograms BEFORE summarizing port info!!
if ( $do_ports_top10 ) {
    $counts_tcp_bysourceport = inc_counts($counts_tcp_bysourceport, $sport,
	[$packets, $bytes]);
    $counts_tcp_bydestport = inc_counts($counts_tcp_bydestport, $dport,
	[$packets, $bytes]);
}
    
if ( $do_plen_hist_byproto ) {
    ## Record packet length histograms for interesting ports
    if ($analy_src) {
        if ( ! defined $histogram_tcp_bysrcport{$sport} ) {
        ## Force object to be a list
            $histogram_tcp_bysrcport{$sport} = [];
        }
	$histogram_tcp_bysrcport{$sport} =
            inc_counts($histogram_tcp_bysrcport{$sport},
            $plen,[$packets, $bytes]);
    }
    if ($analy_dst) {
        if ( ! defined $histogram_tcp_bydstport{$dport} ) {
        ## Force object to be a list
            $histogram_tcp_bydstport{$dport} = [];
        }
        $histogram_tcp_bydstport{$dport} =
            inc_counts($histogram_tcp_bydstport{$dport},
            $plen,[$packets, $bytes]);
    }
}
    
    ## Summarize port info based on connection type
    ## DNS
    if ( ( $sport == 53 ) && ( $dport != 53 ) ) {
	$dport = 0;
    } elsif ( ( $dport == 53 ) && ( $sport != 53 ) ) {
	$sport = 0;
	## HTTP
    } elsif ( ( $sport == 80 ) && ( $dport > 1023 ) ) {
	$dport = 0;
    } elsif ( ( $dport == 80 ) && ( $sport > 1023 ) ) {
	$sport = 0;
	## NNTP
    } elsif ( ( $sport == 119 ) && ( $dport > 1023 ) ) {
	$dport = 0;
    } elsif ( ( $dport == 119 ) && ( $sport > 1023 ) ) {
	$sport = 0;
	## SSH
    } elsif ( $sport == 22 ) {
	$dport = 0;
    } elsif ( $dport == 22 ) {
	$sport = 0;
	## Rlogin
    } elsif ( $sport == 513 ) {
	$dport = 0;
    } elsif ( $dport == 513 ) {
	$sport = 0;
	## Rsh
    } elsif ( $sport == 514 ) {
	$dport = 0;
    } elsif ( $dport == 514 ) {
	$sport = 0;
    }
    
    ## Collapse random high-numbered ports
    if ( $sport > 1023 ) {
	$sport = 0 unless $interesting_tcp_ports{$sport};
    }
    if ( $dport > 1023 ) {
	$dport = 0 unless $interesting_tcp_ports{$dport};
    }
    
    ## Increment trafic matrix cells
    $matrix_tcp_byport = inc_counts($matrix_tcp_byport, "$sport\t$dport",
	[$packets, $bytes]);
}


##===========================================================================

sub handle_udp($$$$) {
    my ($sport, $dport, $plen, $count) = @_;
    
    my ($analy_src, $analy_dst);
    my $packets = $count;
    my $bytes = $plen * $count;
    
    ## Check for `interesting' port numbers
    $analy_src = $interesting_udp_ports{$sport};
    $analy_dst = $interesting_udp_ports{$dport};
    
## Calculate source and dest histograms BEFORE summarizing port info!!
if ( $do_ports_top10 ) {
    $counts_udp_bysourceport = inc_counts($counts_udp_bysourceport, $sport,
	[$packets, $bytes]);
    $counts_udp_bydestport = inc_counts($counts_udp_bydestport, $dport,
	[$packets, $bytes]);
}

if ( $do_plen_hist_byproto ) {
    ## Record packet length histograms for interesting ports
    if ($analy_src) {
        if ( ! defined $histogram_udp_bysrcport{$sport} ) {
        ## Force object to be a list
            $histogram_udp_bysrcport{$sport} = [];
        }
        $histogram_udp_bysrcport{$sport} =
            inc_counts($histogram_udp_bysrcport{$sport},
            $plen,[$packets, $bytes]);
    }
    if ($analy_dst) {
        if ( ! defined $histogram_udp_bydstport{$dport} ) {
        ## Force object to be a list
            $histogram_udp_bydstport{$dport} = [];
        }
        $histogram_udp_bydstport{$dport} =
            inc_counts($histogram_udp_bydstport{$dport},
            $plen,[$packets, $bytes]);
    }
}
    
    ## Summarize port info based on connection type
    ## DNS
    if ( ( $sport == 53 ) && ( $dport != 53 ) ) {
	$dport = 0;
    } elsif ( ( $dport == 53 ) && ( $sport != 53 ) ) {
	$sport = 0;
	## NTP
    } elsif ( ( $sport == 123 ) && ( $dport != 123 ) ) {
	$dport = 0;
    } elsif ( ( $dport == 123 ) && ( $sport != 123 ) ) {
	$sport = 0;
	## RealAudio
    } elsif ( ( $dport > 6969 ) && ( $dport < 7171 ) ) {
	$dport = 7070;
	$sport = 0;
    }
    
    ## Collapse random high-numbered ports
    if ( $sport > 1023 ) {
	$sport = 0 unless $interesting_udp_ports{$sport};
    }
    if ( $dport > 1023 ) {
	$dport = 0 unless $interesting_udp_ports{$dport};
    }
    
    ## Increment trafic matrix cells
    $matrix_udp_byport = inc_counts($matrix_udp_byport, "$sport\t$dport",
	[$packets, $bytes]);
}


##===========================================================================

## Open the port summary filehandle here, so that it can start up before
## we need the data.
if (!-x "${script_path}/crl_hist_helper") {
    die("Where is crl_hist_helper???");
}

{
    my $args;
    foreach my $arg (@ARGV) {
        $args .= "\"$arg\" ";
    }

    open(SUMMARY, "${script_path}/crl_hist_helper -I -Ci=300 $args |")
        || die("Can't get summary from crl_hist_helper: $!\n");
}

if ($do_troops) {
##
## BEGIN CRL.pm dependent code
#
#

$packet = new Coral::Pkt_result;

Coral::quick_start(0);
Coral::read_pkt_init(undef, undef);

## Read Coral dump block header
while (defined($iface = Coral::read_pkt($packet))) {
    my ($payload, $ip_record);

    $payload = $packet->packet->buf;
    $ip_record = Coral::get_ip($iface, $packet->packet);
    if ($ip_record) {
        handle_ip($ip_record);
    } else {
        my ($non_ip_buffer);
        $non_ip_buffer = new Coral::Pkt_buffer;
        Coral::get_payload_by_layer($packet->packet, $non_ip_buffer, 3);
        handle_non_ip($non_ip_buffer);
    }
}

#
#
## END CRL.pm dependent code
##
}

print STDERR "Reading summary file\n" if $debug;

while (<SUMMARY>) {
## Comment lines mean trace processing is done
    last if /^#/;

    chop;
    ($interface, $proto, $flags, $sport, $dport, $plen, $packets) = split /\t/, $_;
    my $bytes = $plen * $packets;

    $pcount += $packets;
    $bytecount += $bytes;

    print STDERR "$pcount packets, $bytecount bytes\n" if $debug;

    $counts_byinterface = inc_counts($counts_byinterface, $interface,
	[$packets, $bytes]);
    $counts_byproto = inc_counts($counts_byproto, $proto,
	[$packets, $bytes]);
    if ( $plen > 0 ) {
        $plen_hist = inc_counts($plen_hist,$plen,[$packets]);
    } else {
        warn "Invalid packet length $plen";
    }

    ##          Fragment Count
    if ( $flags & $IS_FRAG ) {
        $fragcount += $packets;
        if ( $proto == 6 ) {
            $tcpfragcount += $packets;
        } elsif ( $proto == 17 ) {
            $udpfragcount += $packets;
        }
        if ( $proto >= 0 ) {
            $frags_byproto = inc_counts($frags_byproto, $proto,
                [$packets, $bytes]);
        } else {
            warn "Invalid protocol value $proto";
        }
    }

    if ( $flags & $PORTS_OK ) {
	if ($proto == 6) {
	    handle_tcp($sport, $dport, $plen, $packets);
	} elsif ($proto == 17) {
	    handle_udp($sport, $dport, $plen, $packets);
	} elsif ($proto == 1) {
	    handle_icmp($sport, $dport, $plen, $packets);
	} elsif ($proto == 2) {
	    handle_igmp($sport, $dport, $plen, $packets);
	}
    }
}

## Read in trace summary info
($header) = parse_header(\*SUMMARY,$header);

close SUMMARY;


##===========================================================================
##
## Print out results

$header = build_header($header);

{
    my $filename = Coral::source_get_filename(Coral::next_source(undef));
    if ( ! defined $filename ) {
        $filename = $ARGV[0];
    }
    printf("#Trace File: %s\n",$filename);
}
printf("#%s\n",$cvs_Id);  
printf("#%s\n",$cvs_Author);  
printf("#%s\n",$cvs_Name);  
printf("#%s\n",$cvs_Revision);  
print "\#Report Library\n";
printf("#%s\n",$CAIDA::CRL_report::cvs_Id);  
printf("#%s\n",$CAIDA::CRL_report::cvs_Author);  
printf("#%s\n",$CAIDA::CRL_report::cvs_Name);  
printf("#%s\n",$CAIDA::CRL_report::cvs_Revision);  

print_header(%{$header});

print "#Packet and byte counts by IP length\n";
print "\#Size\tNum\tCumPkts\tpct.\tCumByte\tpct.\n";
print_plen_hist($plen_hist,${$header}{total_packets},${$header}{total_bytes});

warn "Printing protocol table...\n" if $debug;
print "\#Traffic breakdown by protocol:\n";
print "\#proto\tpcount\tpct.\tbytes\tpct.\tavg. size\n";
print_proto_table($counts_byproto,%{$header});

warn "Printing TCP port matrix...\n" if $debug;
my $table_header = "\#TCP Traffic matrix:\n\#src\tdst\tpackets\tpct.\tbytes\tpct\tavg. size\n";
print_port_table($matrix_tcp_byport, $table_header,
	get_counts($counts_byproto,6));

warn "Printing UDP port matrix...\n" if $debug;
$table_header = "\#UDP Traffic matrix:\n\#src\tdst\tpackets\tpct.\tbytes\tpct\tavg. size\n";
print_port_table($matrix_udp_byport, $table_header,
	get_counts($counts_byproto,17));

print "\#Fragment breakdown by protocol:\n";
print "\#proto\tpcount\tpct.\tbytes\tpct.\tavg. size\n";
print_proto_table($frags_byproto,%{$header});

foreach my $port ( keys %histogram_tcp_bysrcport ) {
    print "#Packet and byte counts from $port/tcp by IP length\n";
    print "\#Size\tNum\tCumPkts\tpct.\tCumByte\tpct.\n";
    print_plen_hist($histogram_tcp_bysrcport{$port},
        get_counts($counts_tcp_bysourceport,$port));
}

foreach my $port ( keys %histogram_tcp_bydstport ) {
    print "#Packet and byte counts to $port/tcp by IP length\n";
    print "\#Size\tNum\tCumPkts\tpct.\tCumByte\tpct.\n";
    print_plen_hist($histogram_tcp_bydstport{$port},
        get_counts($counts_tcp_bydestport,$port));
}

foreach my $port ( keys %histogram_udp_bysrcport ) {
    print "#Packet and byte counts from $port/udp by IP length\n";
    print "\#Size\tNum\tCumPkts\tpct.\tCumByte\tpct.\n";
    print_plen_hist($histogram_udp_bysrcport{$port},
        get_counts($counts_udp_bysourceport,$port));
}

foreach my $port ( keys %histogram_udp_bydstport ) {
    print "#Packet and byte counts to $port/udp by IP length\n";
    print "\#Size\tNum\tCumPkts\tpct.\tCumByte\tpct.\n";
    print_plen_hist($histogram_udp_bydstport{$port},
        get_counts($counts_udp_bydestport,$port));
}

print "#ICMP traffic breakdown\n";
print "\#Type\tCode\tpackets\tpct.\tbytes\tpct\tavg. size\n";
print_4_table($icmp_bytype,get_counts($counts_byproto,1));

print "#IGMP traffic breakdown\n";
print "\#Type\tCode\tpackets\tpct.\tbytes\tpct\tavg. size\n";
print_4_table($igmp_bytype,get_counts($counts_byproto,2));

print "#TCP packet and byte counts by source port (top 10)\n";
print "\#Port\tpackets\tpct.\tbytes\tpct\tavg. size\n";
print_4_table_top10($counts_tcp_bysourceport,get_counts($counts_byproto,6));

print "#TCP packet and byte counts by destination port (top 10)\n";
print "\#Port\tpackets\tpct.\tbytes\tpct\tavg. size\n";
print_4_table_top10($counts_tcp_bydestport,get_counts($counts_byproto,6));

print "#UDP packet and byte counts by source port (top 10)\n";
print "\#Port\tpackets\tpct.\tbytes\tpct\tavg. size\n";
print_4_table_top10($counts_udp_bysourceport,get_counts($counts_byproto,17));

print "#UDP packet and byte counts by destination port (top 10)\n";
print "\#Port\tpackets\tpct.\tbytes\tpct\tavg. size\n";
print_4_table_top10($counts_udp_bydestport,get_counts($counts_byproto,17));
