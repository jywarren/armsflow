package CAIDA::Traffic2::ReportUserGuide;
require 5.004;
## $Id: ReportUserGuide.pm,v 1.14 2007/06/06 18:17:51 kkeys Exp $ $Name: release-3-8-1 $
## -----------------------------------------------------------------------
## Perl module:ReportUserGuide.pm
## 
## This Perl module (Traffic Human Computer Interface) provides a
## consistent framework displaying help and diagnostic messages from
## the CoralReef report generator.  It's may role as a module is
## partition code that doesn't belong in either main script or any
## other module and to standardize the format of help information.
## 
## Note: test routines require the Test.pm module or Perl 5.005
##
## Copyright 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
## All Rights Reserved 
##
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
##
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
##
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
##
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
##
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program. Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
##
## Contact: coral-info@caida.org
## ---------------------------------------------------------------------

use CAIDA::UserGuide::UserGuide;

# Set up object export condition.  No functions accessible directly.
use Exporter ();
@ISA       = qw(CAIDA::UserGuide::UserGuide);

# Define required CVS variables
$cvs_Id = '$Id: ReportUserGuide.pm,v 1.14 2007/06/06 18:17:51 kkeys Exp $';
$cvs_Author = '$Author: kkeys $';
$cvs_Name = '$Name: release-3-8-1 $';
$cvs_Revision = '$Revision: 1.14 $';

# Enable error messages to come from calling script
use Carp;

# Force this module to adhere to safe programming practices.
use strict;
use Text::Wrap;

# argument count types
use constant SHORTCUT   => 0;
use constant DESCRIPTION  => 1;
use constant NOTES  => 2;


# Now for all the dirty work ... all the data strings needed for
# Human Computer Interface system for t2_report appear here.
# TO NOT EDIT ELSEWHERE!!
use vars qw($Report_data);

$Report_data = {asfinder => 
		['a', 
		 join(' ', "Enable the mapping of IP addresses to",
		      "\"Associated Systems\" (AS) by lookup in a BGP",
		      "Routing table.  Requires a BGP routing table,",
		      "which can either be given as an argument or",
		      "specified in t2_report configuration file."
		     ),
		 ""
		],
		backdate =>
		['b',
		 join(' ', "Change the creation date for the RRD databases",
		      "to the argument.  Used mainly to \"synchronize\"",
		      "the output to data that is coming.  Any valid date",
		      "format that RRDtool uses can be supplied as an",
		      "argument to this option."
		  ),
		 ""
		],
		command =>
		['c',
		 join(' ', "Allows for the setting of t2_report options in",
		      "the same style as other CoralReef applications",
		      "So for example the backdate option --backdate",
		      "20000101 could also be accomplished by the option",
		      "--command 'backdate=20000101' . As in other",
		      "CoralReef applications, the argument/value pair",
		      "must be quoted to avoid being evaluated by the",
		      "UNIX shell."
		     ),
		 ""
		],
		debug =>
		['d',
		 join(' ', "Turns on debugging messages.  Presently the",
		      "only debugging level is 1, but this is expected to",
		      "change in the next release."
		     ),
		 ""
		 ],
		configfile =>
		['f',
		 join(' ', "Specifies the path to an additional configuration",
		      "file that will be read after the configuration files",
		      "in the default locations have been read.  Information",
		      "in this file will be read before any other command",
		      "options are processed."
		     ),
		 ""
		],
		graphtool =>
		['g',
		 join(' ', "Specifies with graphing tool will be used to",
		      "make the pie charts.  \'none\' will suppress the",
		      "pie charts (but not the RRDtool graphs,)  \'GDGraph\'",
		      "uses the Perl modules that interface to the gd",
		      "graphics library, and \'JCChart\' use the JCChart",
		      "Java applet."
		     ),
		 ""
		 ],
		internetapps =>
		['i',
		 join(' ', "Enable the tracking of the top 'N' applications",
		           "using RRDtool.  Requires RRDtool.  Takes only",
                           "1 or 0 as arguments."
		     ),
		 ""
		 ],
		javaserver =>
		['j',
		 join(' ', "Specify location of java server to be used with",
		      "JCChart.  Note: this option does NOT change the",
		      "currently chosen graphtool."
		     ),
		 ""
		 ],
		merge =>
		['m',
		 join(' ', "Merge the data coming out from crl_traffic2 into",
		      "another sample size.  This can either be a simple",
		      "number in which case integral numbers of crl_traffic2",
		      "samples will be merged together before a report is",
		      "generated.  Alternatively, a time can be specified to",
		      "group the data into.  Times are differentiated from",
		      "simple numbers by colons.  In order to an unambiguous",
		      "access to all possible values, the default is hours",
		      "to seconds.  So --merge 5: means five hours not",
		      "seconds.  The command for five minutes would be",
		      "--merge 0:5 and for 5 seconds it would be --merge",
		      "0:0:5 ."
		     ),
		 ""
		 ],
		netgeo =>
		['n',
		 join(' ', "Turn on the netgeo mapping of AS to country.",
		      "Due to oddities of command line parsing, you must",
		      "specify 1 to make the value true, thus: --netgeo 1 .",
		      "In addition, you can set the netgeo command line",
		      "option to choose the blocking mode for NetGeo",
		      "lookups.  This is done with by the option",
		      "--netgeo setblocking"
		     ),
		 ""
		 ],
		promiscuous =>
		['p',
		 join(' ', "Turn on actual displaying of IP addresses.  Due",
		      "to oddities of command line parsing, you must specify",
		      "1 to make the value true, thus: --promiscuous 1"
		     ),
		 ""
		 ],
		RRDtool =>
		['r',
		 join(' ', "Enable RRDtool to collect data and create",
		      "timeseries graphs from data.  To use RRDtool, you",
		      "must installed RRDtool - it does not come with",
		      "CoralReef.  Once installed, you will need to modify",
		      "t2_report to load the RRDtool libraries.  One can",
		      "either specify the path to where the RRD databases",
		      "are to be stored, or just give it the true value 1",
		      "if you are specifying that path in a configuration",
		      "file instead."
		     ),
		 ""
		 ],
		samples =>
		['s',
		 join(' ', "A debugging aid that stops the report generator",
		      "after --sample N samples have been read in from",
		      "crl_traffic2.  N can be any positive integer."
		     ),
		 ""
		 ],
		todisplay =>
		['t',
		 join(' ', "Set the number of values will be displayed in the",
		      "\"Top-10\" displays."
		     ),
		 ""
		 ],
		zaptotals =>
		['z',
		 join(' ', "Turn off the computation of totals for all vpvcs.",
		           "This can help t2_report keep up with very",
		           "high traffic links or operate on less powerful",
		           "hardware."
		     ),
		 ""
		 ],

	       };

# Version of module
my $VERSION = 1.0;

# .   .   .   .   .  Internal object functions  .   .   .   .   .   .   .  


# .   .   .   .   .  User Method Subroutines  .   .   .   .   .   .   .   .  

sub new($ ) {
# -----------------------------------------------
# Create new object.  Since this is a leaf
# object in the class hierarchy, there is no 
# need to do careful initialization.
# -----------------------------------------------
    # retrieve parameters
    my $class_name = shift;
    
    # allocate space for object and bless it.
    my	$HCI_object = {};
    bless $HCI_object, $class_name;

    # Make initialization from ancestor.
    $HCI_object->SUPER::_initialize();

    $HCI_object->{'HCI_data'} = $Report_data;
    $HCI_object->{'HCI_Header'} = [ "Option", "Abbr", "Description", "Notes"];
    $HCI_object->{'HCI_general_message'} = 
	join(' ', "Usage: \"$0 <Command line options> <input file>\"",
	     "Where the only optional argument is the input file. ",
	     "Otherwise $0 will assume that data is coming from standard",
	     "input."
	    );
    # Return object reference
    return($HCI_object);
}

# =============================
# POD Documentation for Module

__END__

=head1 NAME

ReportUserGuide.pm - Container for t2_report[++] command line help info.

=head1 DESCRIPTION

This is an internal module to t2_report[++].  See the t2_report[++]
documentation for details on the program.

=head1 AUTHOR

CoralReef Development team, CAIDA Group <coral-info@caida.org>

=head1 COPYRIGHT

Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
All Rights Reserved 

Permission to use, copy, modify and distribute any part of this
CoralReef software package for educational, research and non-profit
purposes, without fee, and without a written agreement is hereby
granted, provided that the above copyright notice, this paragraph
and the following paragraphs appear in all copies.

Those desiring to incorporate this into commercial products or use
for commercial purposes should contact the Technology Transfer
Office, University of California, San Diego, 9500 Gilman Drive, La
Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.

IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
THE POSSIBILITY OF SUCH DAMAGE.

THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
ANY PATENT, TRADEMARK OR OTHER RIGHTS.

The CoralReef software package is developed by the CoralReef
development team at the University of California, San Diego under
the Cooperative Association for Internet Data Analysis (CAIDA)
Program. Support for this effort is provided by the CAIDA grant
NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
N66001-01-1-8909, and by CAIDA members.

Report bugs and suggestions to coral-bugs@caida.org.

=cut

# .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   . 
1; ##must be last line in the file
