##
## Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
## All Rights Reserved 
##
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
##
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
##
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
##
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
##
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program. Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
##
## Report bugs and suggestions to coral-bugs@caida.org.
## 
## ---------------------------------------------------------------------
## Perl module:  CAIDA::Tables::Generic.pm
## 
## Base set of methods to implement a number of different table types
## such as Tuple tables, Protocol tables, IP tables, and AS tables.
## Tables inherit from this base class.  Also, this file contains
## 3 additional classes that inherit from this base class: pack, 
## split, and single key.
##
## In the properly OOPS tradition, all methods required to work on the
## the data structure are bound to the objects themselves.  In order
## to make the Generic table object truly generic, the methods used
## to store data and access data are also bound to the object but 
## in an implementation independent manner.  The fields 
## _implode_filter and _explode_filter contain references to the 
## Perl subroutines that perform these functions.

package CAIDA::Tables;

use vars qw($DEBUG $FORCE_C $FORCE_PERL %failed_new);

if (-f '.developer') {
    $DEBUG = 1;
} else {
    $DEBUG = 0;
}

package CAIDA::Tables::Generic;

# Define required CVS variables
$cvs_Id = '$Id: Generic.pm,v 1.52 2007/06/06 18:17:47 kkeys Exp $';
$cvs_Author = '$Author: kkeys $';
$cvs_Name = '$Name: release-3-8-1 $';
$cvs_Revision = '$Revision: 1.52 $';

# Version of module
$VERSION = 2.0;

# Enable error messages to come from calling script
use Carp;

# Force this module to adhere to safe programming practices.
use strict;

use CAIDA::Traffic2::FlowCounter;	# default counter is FlowCounter

use FileHandle;

use vars qw($default_counter_kind);

$default_counter_kind = new CAIDA::Traffic2::FlowCounter;
my $test_counter = new CAIDA::Traffic2::FlowCounter;

my $already_warned = 0;

# .   .   .   .   .  User Method Subroutines  .   .   .   .   .   .   .   .

# XXX - todo: change _has_data to num_entries, and use in nadd to
#             swap trees when smart to minimize additions

sub new ($@ ) {
# -----------------------------------------------
# Generic table creation method.  Objects
# created by this method aren't immediately 
# usable.  Some _initialize method is expected
# usually supplied by the descendant object
# classes.
# -----------------------------------------------
    my ($self, $counter_kind, $arg_hash_ref) = @_;
    my $type = ref($self) || $self;
    my $force_perl = 0;
    my $new_size = $arg_hash_ref->{'table_size'};
    my $table;

    if ($arg_hash_ref->{'force_perl'} or $CAIDA::Tables::FORCE_PERL
	or exists $CAIDA::Tables::failed_new{$type})
    {
	$force_perl = 1;
    }

    unless (defined($counter_kind)) {
	$counter_kind = $default_counter_kind;
    }

    if (ref($counter_kind) eq ref($test_counter) and not $force_perl) {
	my $changed_type = $type . '_SWIG';
	my $modfile = $changed_type . '.pm';
	$modfile =~ s/::/\//g;
	if ($new_size) {
	    eval {
		require $modfile;
		$table = new $changed_type($new_size);
	    };
	} else {
	    eval {
		require $modfile;
		$table = new $changed_type;
	    };
	}
	if ($@ eq '') {
	    return $table;
	} else {
	    $CAIDA::Tables::failed_new{$type} = 1;
	}
	# Otherwise default to Perl-only version.
    }

    if ($CAIDA::Tables::FORCE_C) {
	if ($force_perl) {
	    croak "Error:  must choose between Perl and C backends.\n";
	}
	croak "Cannot use C++ tables!  $@\n";
    }
    
    if ($CAIDA::Tables::DEBUG or not $already_warned) {
	print STDERR "Using Perl-only version.\n";
	print STDERR "Reason: $@\n" if $@;
	$@ = '';
	$already_warned = 1;
    }

    $table = {
		 '_counter_kind' => $counter_kind,
		 '_kind' => undef,
		 #'_total_counts' => undef,
		 '_data' => {},
		 '_args' => $arg_hash_ref,
		 '_implode_filters' => undef, # Undefined in generic case.
		 '_explode_filters' => undef,
		 '_num_fields' => undef,
	     };

    bless $table, $type;

    # Set counter type temporarily to undefined
    $table->{'_total_counts'} = undef;
    $table->{'_other'} = undef;
    # Initialize the object.  Normally from descendant object class.
    $table->_initialize($arg_hash_ref);

    # Allow users to define their own counter object if they wish
    # in _initialize.  Otherwise use the default.
    unless ($table->{'_total_counts'}) {
	$table->{'_total_counts'} = $table->_new_counter();
    }
    unless ($table->{'_other'}) {
	$table->{'_other'} = $table->_new_counter();
    }
    
    return $table;
}


sub _initialize (@) {
# -----------------------------------------------
# Initialization for objects mainly for 
# overloading.  This allows for subclasses to 
# to modify the object creation scheme without
# having to overload the 'new' method itself.
#
# Any subclass should call 
# $self->SUPER::_initialize at the end of their
# overiding _initialize method.
# -----------------------------------------------
    my ($self, $arg_hash_ref) = @_;
    # XXX check for valid _kind _implode_filters _explode_filters here
}


sub _explode ($$ ) {
# - - - - - - - - - - - - - - - - - - - - - - - -
# Stand in for methods that translate form an 
# Opaque key to a list of the external form of
# the keys.  For example a flow might consist
# of a unique key consisting of src and dest IP, 
# protocol, and src and dest ports.  These items
# are compressed into a single hash key for
# storage efficiency.  This method should
# convert the single key into a list of key
# elements.
#
# Placeholder function - should never actually
# be called.  
# - - - - - - - - - - - - - - - - - - - - - - - -
    croak "Must overload CAIDA::Tables::Generic _explode method";
}


sub _implode ($@ ) {
# - - - - - - - - - - - - - - - - - - - - - - - -
# Stand in for methods that take a list of key
# elements and compress it into a single opaque
# key.
#
# Placeholder function - should never actually
# be called.
# - - - - - - - - - - - - - - - - - - - - - - - -
    croak "Must overload CAIDA::Tables::Generic _implode method";
}


sub _new_counter ($ ) {
# -----------------------------------------------
# Method to create a new counter object associated
# with the table object
# -----------------------------------------------
    my ($self) = @_;

    return $self->{'_counter_kind'}->new();
}


sub _new_aggregate ($ ) {
# -----------------------------------------------
# Internal method to create a new aggregate table
# using the same counter type as this object.  It 
# is used by aggregate_columns
# -----------------------------------------------
    my ($self) = @_;

    return $self->new($self->{'_counter_kind'}, $self->{'_args'});
}


sub _generate_opaque ($@ ) {
# -----------------------------------------------
# Internal method to convert data from the 
# external key element(s) to merged "opaque" 
# format.  This permits for this object class to
# support subclasses with different internal 
# representations without changing the base
# class.  A generic way to create "opaque"
# data is to the use something like the Perl
# pack function.  Also, domain specific tools
# can be used such as the UNIX library call
# inet_aton.
# -----------------------------------------------
    my ($self, @fields) = @_;

    if (scalar(@fields) != $self->{'_num_fields'}) {
	croak $self->{'_kind'} . " requires " . $self->{'_num_fields'} .
		" fields (you gave " . scalar(@fields) . ")";
    }

    # Retrieve references to implode functions
    my @filters = @{ $self->{'_implode_filters'} };

    for (my $i = 0; $i < @filters; $i++) {
	my $filter = $filters[$i]; 
	if (defined($filter)) {
	    # Apply $filter functions to fields to implode
	    $fields[$i] = &{$filter}($fields[$i]);
	}
    }

    # Merge imploded fields.
    return $self->_implode(@fields);
}


sub _has_data ($ ) {
# ----------------------------------------------
# Method predicate to check if object has any
# data stored in it.
# OBSOLETE METHOD!!  Use num_entries instead.
# ----------------------------------------------
    my ($self) = @_;

	warn "This method is obsolete and will be removed soon";
    return(num_entries($self));
}

sub _same_kind ($$ ) {
# ----------------------------------------------
# Method predicate that checks if the second 
# object is of the same kind as the first
# ----------------------------------------------
# XXX needs extension to properly deal with 
# checking equivalence of "aggregated" tables
# to raw ones and also should probably verify
# that the same counter types are used.
  my $self = shift;
  my $other = shift;

  return ($self->{'_kind'} eq $other->{'_kind'});
}

sub data ($ ) {
# ----------------------------------------------
# Accessor method to get reference to data
# ----------------------------------------------
    my ($self) = @_;

    return $self->{'_data'};
}


sub total ($ ) {
# ----------------------------------------------
# Accessor method to get total counts in table
# ----------------------------------------------
    my ($self) = @_;

    return $self->{'_total_counts'};
}

sub other ($ ) {
# --------------------------------------
# Accessor method to get 'other' counter
# --------------------------------------
    my ($self) = @_;

    return $self->{'_other'};
}

sub read_other {
# -------------------------------------------------------
# Convenience method to convert string to 'other' counter
# -------------------------------------------------------
    my ($self, $string) = @_;
    my @counts = split /\t/, $string;
    undef $counts[3] if not $counts[3];
    undef $counts[4] if not $counts[4];
    my $count = new CAIDA::Traffic2::FlowCounter(@counts);
    $self->{'_other'} = $count;
    $self->{'_total_counts'}->add($count);
}

sub write_other {
# -------------------------------------------------------
# Convenience method to convert 'other' counter to string
# -------------------------------------------------------
    my ($self, $save_all) = @_;
    $save_all = 1 if not defined $save_all;
    my $other = $self->{'_other'};
    my $string = join "\t", $other->pkts(),
		    $other->bytes(), $other->flows();
    if ($save_all) {
	$string .= "\t";
	if (defined $other->first()) {
	    $string .= $other->first();
	} else {
	    $string .= "0";
	}
	$string .= "\t";
	if (defined $other->latest()) {
	    $string .= $other->latest();
	} else {
	    $string .= "0";
	}
    }
    return $string;
}

sub num_entries ($ ) {
# ----------------------------------------------
# Return number of entries in the table.  
# Replacement for the _has_data internal 
# predicate method.
# ----------------------------------------------
    my ($self) = @_;

    return scalar(keys %{ $self->{'_data'} });
}

sub clear ($) {
# ---------------------------------------------
# Clear all data from table.
# ---------------------------------------------
    my ($self) = @_;
    $self->{'_data'} = {};
    $self->{'_total_counts'}->reset();
    $self->{'_other'}->reset();
}

sub get_key_fields ($$ ) {
# ---------------------------------------------
# Accessor method to convert an opaque field
# into the list of key(s) that were originally
# supplied.
# ---------------------------------------------
    my ($self, $opaque_key) = @_;

    # fetch explode functions
    my @filters = @{ $self->{'_explode_filters'} };

    # unpack the fields from their compressed format
    my @fields = $self->_explode($opaque_key);

    for (my $i = 0; $i < @filters; $i++) {
	my $filter = $filters[$i]; 
	if (defined($filter)) {
	    # Apply unpacking functions to each field.
	    $fields[$i] = &{$filter}($fields[$i]);
	}
    }

    return @fields;
}


sub entry_get ($@ ) {
# --------------------------------------------
# Lookup the counter associated with the given
# external key list.
# --------------------------------------------
    my ($self, @fields) = @_;
    my $opaque_key = $self->_generate_opaque(@fields);

    return $self->{'_data'}->{$opaque_key};
}


sub entry_add ($@ ) {
# --------------------------------------------
# Find counter in table associated with given
# external key(s) list, creating (if needed)
# and then adding the counter argument onto
# the existing value.
# --------------------------------------------
    my ($self, @fields) = @_;
    my $amount = pop @fields;

    # Create a new key to new data
    my $opaque_key = $self->_generate_opaque(@fields);
    my $entry = $self->{'_data'}->{$opaque_key};

    # If entry doesn't already exist add it.
    unless (defined ($entry)) {
	  $entry = $self->_new_counter();
	  $self->{'_data'}->{$opaque_key} = $entry;
    }

    $self->{'_total_counts'}->add($amount);

    return $entry->add($amount);
}


sub add ($$ ) {
# ------------------------------------------
# merge data to an existing table into 
# another table.  Both tables are preserved.
# ------------------------------------------
    my ($self, $other) = @_;

    # Only merge compatible tables
    unless ($self->_same_kind($other)) {
	  croak "Incompatible table kinds: ``",
		$self->{'_kind'}, "'' and ``",
		$other->{'_kind'}, "''\n";
    }
	
    my $hash_ref = $self->data();

    # While there is data in the other table - move it over.
    while (my ($opaque_key, $value) = each %{ $other->data() }) {
	my $entry = $hash_ref->{$opaque_key};
	unless (defined($entry)) {
	    $entry = $self->_new_counter();
	    $hash_ref->{$opaque_key} = $entry;
	}
	$entry->add($value);
    }

    # Update total counts - (another call to the same method)
    $self->{'_total_counts'}->add($other->{'_total_counts'});
    $self->{'_total_counts'}->add($other->{'_other'});
    $self->{'_other'}->add($other->{'_other'});

    return $self;
}


sub nadd ($$ ) {
# ----------------------------------------
# Transfer data from another table into
# this table object.  Depending on 
# implementation the other table may be 
# destroyed to save memory.
#
# Implementation may change as this code
# is migrated from Perl to C.
# ----------------------------------------
    my ($self, $other) = @_;

    # Only merge compatible tables
    unless ($self->_same_kind($other)) {
	  croak "Incompatible table kinds: $self  and  $other\n";
    }

    # If the base object doesn't have any data simply swap references
    if (not $self->num_entries()) {
	  $self->{'_data'} = $other->{'_data'};
	  $other->{'_data'} = {}; # Allows Perl garbage collector to reclaim.
    } else {
	  my $hash_ref = $self->data();
	  my $other_hash_ref = $other->data();

	  # Else loop through other objects data adding if appropriate
	  while (my ($opaque_key, $value) = each %{ $other_hash_ref }) {
	    my $entry = $hash_ref->{$opaque_key};
	    if (defined($entry)) {
		  $entry->nadd($value);		
	    } else {
		  $hash_ref->{$opaque_key} = $value;	    
		}
	    delete $other_hash_ref->{$opaque_key}; # Free up space
	  }
    }

    # Update counters
    $self->{'_total_counts'}->add($other->{'_total_counts'});
    # Other has been "emptied" so reset counter to "zero".
    $other->{'_total_counts'} = $other->_new_counter();

    return $self;
}


sub _aggregate_setup ($$@ ) {
# -----------------------------------------
# Helper function to assist in aggregating
# data.
#
# Many subclasses will need to overload or 
# extend this method to update their table
# state to reflect the new subset of
# columns.
# -----------------------------------------
    my ($self, $orig, @columns) = @_;

    my @implode_filters = @{ $orig->{'_implode_filters'} };
    my @explode_filters = @{ $orig->{'_explode_filters'} };

    @implode_filters = @implode_filters[@columns];
    @explode_filters = @explode_filters[@columns];

    $self->{'_counter_kind'} = $orig->{'_counter_kind'};
    $self->{'_kind'} .= ": " . join(" ", @columns);
    $self->{'_implode_filters'} = \@implode_filters;
    $self->{'_explode_filters'} = \@explode_filters;
    $self->{'_total_counts'} = $self->_new_counter();
    $self->{'_other'} = $self->_new_counter();
    $self->{'_num_fields'} = scalar(@columns);
}


sub aggregate_columns ($@ ) {
# -----------------------------------------
# Creates an entirely new table with the
# related columns in it.  Aggregation is
# done by adding up previous rows which 
# now map to a single row.
# -----------------------------------------
    my ($self, @columns) = @_;
    my $result = $self->_new_aggregate();

    $result->_aggregate_setup($self, @columns);

    my $result_hash = $result->data();

    # Loop through data in object 
    while (my ($opaque_key, $value) = each %{ $self->data() }) {
	# Expand data to aggregate it.
	my @fields = $self->_explode($opaque_key);
	my $new_opaque_key = $result->_implode(@fields[@columns]);

	my $entry = $result_hash->{$new_opaque_key};
	unless (defined($entry)) {
	    $entry = $self->_new_counter();
	    $result_hash->{$new_opaque_key} = $entry;
	}
	$entry->add($value);
    }

    $result->{'_total_counts'}->add($self->total());
    $result->{'_total_counts'}->add($self->{'_other'});
    $result->{'_other'}->add($self->{'_other'});
    
    return $result;
}

sub save_text($$$) {
    my ($self, $file, $save_all) = @_;
    $save_all = 1 if not defined $save_all;
    if (not $file) {
	carp "save_text requires a file name or file handle to write to.";
	return undef;
    } elsif (defined fileno $file) {
	# Do nothing, this is okay.
    } elsif (ref $file) {
	carp "save_text requires a file name or file handle to write to.";
	return undef;
    } else {
	require IO::File;
	my $new_handle = new IO::File ">$file";
	if (not $new_handle) {
	    carp "Cannot open file $file: $!";
	    return undef;
	}
	$file = $new_handle;
    }
    while (my ($opaque_key, $value) = each %{ $self->data() }) {
	my @fields = $self->get_key_fields($opaque_key);
	print $file join "\t", @fields, $value->pkts(),
			$value->bytes(), $value->flows();
	if ($save_all) {
	    if (defined $value->first()) {
		print $file "\t", $value->first();
	    } else {
		print $file "\t0";
	    }
	    if (defined $value->latest()) {
		print $file "\t", $value->latest();
	    } else {
		print $file "\t0";
	    }
	}
	print $file "\n";
    }
    print $file "# end of text table\n";
    return 1;
}

sub load_text($$) {
    my ($self, $file) = @_;
    my $num_fields = $self->{'_num_fields'};
    if (not $file) {
	carp "load_text requires a file name or file handle to read from.";
	return undef;
    } elsif (defined fileno $file) {
	# Do nothing, this is okay.
    } elsif (ref $file) {
	carp "load_text requires a file name or file handle to read from.";
	return undef;
    } else {
	require IO::File;
	my $new_handle = new IO::File "<$file";
	if (not $new_handle) {
	    carp "Cannot open file $file: $!";
	    return undef;
	}
	$file = $new_handle;
    }
    while (<$file>) {
	chomp;
	if (substr($_, 0, 1) eq '#') {
	    return $_;
	}
	my @data = split /\t/;
	my @counts = splice @data, $num_fields;
	undef $counts[3] if not $counts[3];
	undef $counts[4] if not $counts[4];
	my $count = new CAIDA::Traffic2::FlowCounter(@counts);
	$self->entry_add(@data, $count);
    }
    return undef;
}

sub _num_to_n64 ($) {
    my ($num) = @_;
    my ($high_half, $low_half);
    $high_half = int($num / 2**32);
    $low_half = $num % 2**32;
    return ($high_half, $low_half);
}

sub _n64_to_num ($$) {
    my ($high_half, $low_half) = @_;
    my $num;
    $num = $high_half * 2**32;
    $num += $low_half;
    return $num;
}

sub save_binary($$$) {
    my ($self, $file, $save_all) = @_;
    $save_all = 1 if not defined $save_all;
    if (not $file) {
	carp "save_binary requires a file name or file handle to write to.";
	return undef;
    } elsif (defined fileno $file) {
	# Do nothing, this is okay.
    } elsif (ref $file) {
	carp "save_binary requires a file name or file handle to write to.";
	return undef;
    } else {
	require IO::File;
	my $new_handle = new IO::File ">$file";
	if (not $new_handle) {
	    carp "Cannot open file $file: $!";
	    return undef;
	}
	$file = $new_handle;
    }
    while (my ($opaque_key, $value) = each %{ $self->data() }) {
	print $file pack('C', length($opaque_key));
	print $file pack('C', $save_all);
	print $file $opaque_key;
	print $file pack('N6', _num_to_n64($value->pkts()),
				_num_to_n64($value->bytes()),
				_num_to_n64($value->flows()));
	if ($save_all) {
	    if (defined $value->first()) {
		my $first = $value->first();
		my $sec_part = int($first);
		my $nsec_part = 1e9 * ($first - int($first));
		print $file pack('N2', $sec_part, $nsec_part);
	    } else {
		print $file pack('N2', 0, 0);
	    }
	    if (defined $value->latest()) {
		my $latest = $value->latest();
		my $sec_part = int($latest);
		my $nsec_part = 1e9 * ($latest - int($latest));
		print $file pack('N2', $sec_part, $nsec_part);
	    } else {
		print $file pack('N2', 0, 0);
	    }
	}
    }
    print $file pack('C', 0);
    print $file "\n# end of binary table\n";
    return 1;
}

sub load_binary($$) {
    my ($self, $file) = @_;
    if (not $file) {
	carp "load_binary requires a file name or file handle to read from.";
	return undef;
    } elsif (defined fileno $file) {
	# Do nothing, this is okay.
    } elsif (ref $file) {
	carp "load_binary requires a file name or file handle to read from.";
	return undef;
    } else {
	require IO::File;
	my $new_handle = new IO::File "<$file";
	if (not $new_handle) {
	    carp "Cannot open file $file: $!";
	    return undef;
	}
	$file = $new_handle;
    }
    my ($opaque_key, $length, $flow_data, $full_count);
    while ((read $file, $length, 1) == 1) {
	$length = unpack 'C', $length;
	last if not $length;
	read $file, $full_count, 1;
	$full_count = unpack 'C', $full_count;
	read $file, $opaque_key, $length;
	read $file, $flow_data, 4*6;
	my @counts = unpack 'N6', $flow_data;
	my ($pkts, $bytes, $flows);
	$pkts = _n64_to_num($counts[0], $counts[1]);
	$bytes = _n64_to_num($counts[2], $counts[3]);
	$flows = _n64_to_num($counts[4], $counts[5]);
	my ($first, $latest);
	if ($full_count) {
	    read $file, $flow_data, 4*4;
	    my ($first_sec, $first_nsec, $latest_sec, $latest_nsec) =
				unpack 'N4', $flow_data;

	    $latest = $latest_sec + $latest_nsec/1e9;
	    $first = $first_sec + $first_nsec/1e9;
	    undef $first if not $first;
	    undef $latest if not $latest;
	}

	my $count = new CAIDA::Traffic2::FlowCounter($pkts, $bytes, $flows,
						     $first, $latest);
	my $entry = $self->{'_data'}->{$opaque_key};

	# If entry doesn't already exist add it.
	unless (defined ($entry)) {
	      $entry = $self->_new_counter();
	      $self->{'_data'}->{$opaque_key} = $entry;
	}

	$self->{'_total_counts'}->add($count);
	$entry->add($count);
    }
    <$file>; # munch trailing newline.
    return <$file>;  # give back the next line
}

sub _my_sort ($$); # To avoid prototype warning.
sub _my_sort ($$) {
# ---------------------------------------------------
# Do-it-yourself quicksort "borrowed" from Ken Keys'
# Tiny Fugue implementation.
# ---------------------------------------------------
    my $func = shift;
    my $input_ref = shift;
    my @input = @{ $input_ref };
    my @same;
    my @small;
    my @large;
	
    # Base case - return single item.
    if (scalar(@input) <= 1) {
	return @input;
    }
	
    # Recursive case - split list into larger and smaller.
    my $key = $input[scalar(@input)/2];
	
    while (@input) {
	my $current = shift @input;
	
	my $diff = &{$func}($current, $key);
	
	if (!$diff) {
	    push @same, $current;
	} elsif ($diff < 0) {
	    push @small, $current;
	} else {
	    push @large, $current;
	}
    }
	
    # Recursive calls
    @small = _my_sort($func, \@small);
    #@same = @same;
    @large = _my_sort($func, \@large);
	
    # Return reassembled list.
    return (@small, @same, @large);
}


sub _my_n_sort ($$$); # To avoid prototype warning.
sub _my_n_sort ($$$) {
# ----------------------------------------------------
# Variation on Quicksort to get top 'N' items in list.
#  "borrowed" from Ken Keys'Tiny Fugue implementation.
# ----------------------------------------------------
    my $N = shift;
    my $func = shift;
    my $input_ref = shift;
    my @input = @{ $input_ref };
    my @same;
    my @small;
    my @large;
    my $nsame;
    my $nsmall = 0;
    my $nlarge;
	
    # Normal base case.
    if (scalar(@input) <= 1) {
	return @input;
    }
	
    # Remaining base case.  If you have the needed top N - return
    if ($N >= scalar(@input) || $N < 0) {
	return _my_sort($func, \@input);
    }
	
    # Recursive case .... split list.
    my $key = $input[0];
	
    while (@input) {
	my $current = shift @input;
	
	my $diff = &{$func}($current, $key);
	
	if ($diff < 0) {
	    push @small, $current;
	    $nsmall++;
	} elsif ($N <= $nsmall) {
	    @large = ();
	    @same = ();
	} elsif (!$diff) {
	    push @same, $current;
	    $nsame++;
	} elsif ($N <= $nsmall + $nsame) {
	    @large = ();
	} else {
	    push @large, $current;
	    $nlarge++;
	}
    }
	
    # Recursive calls
    if ($N <= $nsmall) {
	@large = ();
	@same = ();
	@small = _my_n_sort($N, $func, \@small);
    } elsif ($N <= $nsmall + $nsame) {
	@large = ();
	@same = @same[0..($N-$nsmall-1)];
	@small = _my_sort($func, \@small);
    } else {
	@large = _my_n_sort($N - $nsmall - $nsame, $func, \@large);
	#@same = @same;
	@small = _my_sort($func, \@small);
    }
	
    # Reassemble list
    return (@small, @same, @large);
}


# -----------------------------------------
# Routines to grab the top 'N' items
# in a hash.  Take a reference to
# hash and the 'N' items to be returned.
# Setting 'N' to -1 means return all
# values (reverts to sort.)
# Needs to be generalized
# to handle more cases.
#
# Note1: 'N' indexes from 1 not 0
# -----------------------------------------

sub sort_by_counter_field($$$;$) {
    my $self = shift;
    my $field = shift;
    my $top_n = shift;
    my $ascend_sort = shift;
    my $data = $self->data();
    my @keys = keys %{ $data };

    my $sort_sub;

    if ($ascend_sort) {
	$sort_sub = sub {
			  my $first = shift;
			  my $second = shift;
			  return($data->{$first}->$field() <=>
				 $data->{$second}->$field());
		        };
    } else {
	$sort_sub = sub {
			  my $first = shift;
			  my $second = shift;
			  return($data->{$second}->$field() <=>
				 $data->{$first}->$field());
		        };
    }
    return _my_n_sort($top_n, $sort_sub, \@keys);
}

sub sort_by_pkts($$;$ ) {
    return sort_by_counter_field(shift, "pkts", shift, shift);
}

sub sort_by_bytes($$;$ ) {
    return sort_by_counter_field(shift, "bytes", shift, shift);
}

sub sort_by_flows($$;$ ) {
    return sort_by_counter_field(shift, "flows", shift, shift);
}

sub sort_by_first($$;$ ) {
    return sort_by_counter_field(shift, "first", shift, shift);
}

sub sort_by_latest($$;$ ) {
    return sort_by_counter_field(shift, "latest", shift, shift);
}

sub sort_by_duration($$;$ ) {
    return sort_by_counter_field(shift, "duration", shift, shift);
}

sub sort_by_keys($$;$ ) {
    my $self = shift;
    my $top_n = shift;
    my $ascend_sort = shift;
    my $data = $self->data();
    my @keys = keys %{ $data };
    
    my $sort_sub;

    if ($ascend_sort) {
	$sort_sub = sub {
			  my $first = shift;
			  my $second = shift;
			  return $first cmp $second;
		        };
    } else {
	$sort_sub = sub {
			  my $first = shift;
			  my $second = shift;
			  return $second cmp $first;
		        };
    }
    return _my_n_sort($top_n, $sort_sub, \@keys);
}

# .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   . 

######### SPECIFIC GENERAL PURPOSE SUBCLASSES ###########
## These 3 subclasses are examples of how to use the 
## table object in particular ways.  They are relatively
## general however and may serve in a wide range of 
## cases.  They are: Using Perl's Pack function, 
## Storing the key in a string, and the trivial case
## of a table with a single key for the hash.
#########################################################

package CAIDA::Tables::Generic::Pack;
## ***********************************************
## Methods to deal with tables that use the Perl
## builtin function pack to efficiently store
## data
##
## The Pack methods are well suited for table
## with fixed length binary data.
## ***********************************************
no strict;
@ISA = (CAIDA::Tables::Generic);
$VERSION = 2.0;
use strict;

sub _initialize (@ ) {
# ----------------------------------------------
# Initialize objects with pack attributes
# ----------------------------------------------
    my ($self) = @_;

    # XXX check for _pack_elements here
    $self->{'_pack_string'} = join("", @{ $self->{'_pack_elements'} });

    $self->SUPER::_initialize();
}


sub _explode ($$ ) {
# ---------------------------------------------
# Explode string .... just unpack
# ---------------------------------------------
    my ($self, $opaque_key) = @_;
    return unpack($self->{'_pack_string'}, $opaque_key);
}


sub _implode ($@ ) {
# --------------------------------------------
# Implode string .... use pack
# --------------------------------------------
    my ($self, @fields) = @_;
    return pack($self->{'_pack_string'}, @fields);
}


sub _aggregate_setup ($$@ ) {
# --------------------------------------------
# Overload to aggregate_setup function.
# perform the packing required before calling
# base methods.
# --------------------------------------------
    my ($self, $orig, @columns) = @_;

    my @pack_elements = @{ $orig->{'_pack_elements'} };

    @pack_elements = @pack_elements[@columns];

    $self->{'_pack_elements'} = \@pack_elements;
    $self->{'_pack_string'} = join("", @pack_elements);

    $self->SUPER::_aggregate_setup($orig, @columns);
}

# .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   . 

# Sub packages in same file
package CAIDA::Tables::Generic::Split;
## ***********************************************
## Methods to deal with tables that have
## delimiting characters (such as colons or tabs)
## ***********************************************
no strict;
@ISA = (CAIDA::Tables::Generic);
$VERSION = 2.0;
use strict;

sub _initialize (@ ) {
    my ($self) = @_;

    # XXX check for _split_char here

    $self->SUPER::_initialize();
}


sub _explode ($$ ) {
    my ($self, $opaque_key) = @_;
    return split($self->{'_split_char'}, $opaque_key);
}


sub _implode ($@ ) {
    my ($self, @fields) = @_;
    return join($self->{'_split_char'}, @fields);
}


sub _aggregate_setup ($$@ ) {
    my ($self, $orig, @columns) = @_;

    $self->{'_split_char'} = $orig->{'_split_char'};

    $self->SUPER::_aggregate_setup($orig, @columns);
}

# .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   . 

# Sub packages in same file

package CAIDA::Tables::Generic::SingleKey;
## ***********************************************
## Methods to deal with a single key for a table.
##
## Useful for tables that already have only one
## hash key.
## ***********************************************
no strict;
@ISA = (CAIDA::Tables::Generic);
$VERSION = 2.0;
use strict;


sub _explode ($$ ) {
# -----------------------------------------------
# Accessor function to retrieve the key
# -----------------------------------------------
    my ($self, $opaque_key) = @_;
    return $opaque_key;
}


sub _implode ($@ ) {
# ----------------------------------------------
# Accessor function to return the single key
# In this case the first element of the array
# ----------------------------------------------
    my ($self, @fields) = @_;
    return $fields[0];
}



# .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   . 
1; ##must be last line in the file
