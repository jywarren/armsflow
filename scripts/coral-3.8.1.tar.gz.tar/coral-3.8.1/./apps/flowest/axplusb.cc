/* based on code by cestan@cs.ucsd.edu 09/10/2002 */

/* Implementing random 32 bit hash using (a*X+b)mod p */

#include <iostream>
#include <cmath>
#include <stdlib.h>
#include <assert.h>
#include "config.h"
#include "caida_t.h"
#include "intmath.h"
#include "axplusb.h"

using namespace std;

class PrimeTab {
    uint32_t primes[6542];
public:
    PrimeTab();
    uint32_t operator[] (int i) const { return primes[i]; }
};

PrimeTab::PrimeTab()
{
    int i, j, n = 1;
    primes[0] = 2;
    for (i = 3; i < 65522; i += 2) {
	uint32_t max = static_cast<uint32_t>(std::sqrt(float(i)));
        for (j = 1; ; j++) {
	    if (j == n || primes[j] > max) {
		primes[n++] = i;
		break;
	    }
	    if (i % primes[j] == 0) /* Not a prime. */
		break;
	}
    }
}

int isprime(uint32_t n)
{
    static const PrimeTab primetab;
    int i;
    for (i = 0; i < 6542; i++) {
        if (n % primetab[i] == 0) /* Not a prime. */
            return 0;
    }
    return 1;
}

AXplusB::AXplusB()
{
    // RNG must return integers in the range [0, 2^31-1]

    do { p = random(); } while (p<0x1000000 || !isprime(p));
    a = random() % (p-1) + 1;
    b = random() % p;
}

