/* 
 * Copyright 2003, 2004, 2005, 2007
 * The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program.  Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

// A flowest_table is a hash_map plus adaptive samplers and an "other" entry.

// $Id: flowest_table.h,v 1.13 2007/06/06 18:17:29 kkeys Exp $

#ifndef FLOWEST_TABLE
#define FLOWEST_TABLE

#if defined(HAVE_HASH_MAP)
# include <hash_map>
#elif defined(HAVE_EXT_HASH_MAP)
# include <ext/hash_map>
#else
# error "Cannot build without hash_map"
#endif

// fetime's interface allows lazy conversion of an arbitrary timestamp
// representation to double
class fetime
{
public:
    virtual double operator()() const = 0;
};

class sampler
{
    const char *tabname;
    const char *shname;
    uint32_t lcm; // least common multiple, to avoid floats
    double sample_rate;
    double desired_sample_rate;
    uint32_t max_thresh;
    uint32_t sample_thresh;
    uint32_t used;
    uint32_t allowed;	// # of entries allowed between start_time and end_time
    uint32_t mark1;	// # of entries at which we mark the time
    uint32_t mark2;	// # of entries allowed before we recalculate
    double interval_start_time, interval, start_time, end_time, mark1_time;
    bool passed_mark1;
    int rmark;
public:
    sampler(const char *p_tabname, const char *p_shname, uint32_t p_lcm,
	uint32_t p_max) :
	tabname(p_tabname), shname(p_shname), lcm(p_lcm), sample_rate(1),
	desired_sample_rate(1), max_thresh(p_max), sample_thresh(p_max), used()
	{}
    void update(int decisions, const fetime &now);
    void start_fixed(uint32_t recip) {
	if (recip) {
	    sample_rate = 1.0/recip;
	    sample_thresh = max_thresh / recip;
	} else {
	    sample_rate = 0;
	    sample_thresh = 0;
	}
	desired_sample_rate = sample_rate;
    }
    void restart_adaptive(double st, double p_interval, uint32_t entries, int p_rmark) {
	rmark = p_rmark;
	interval_start_time = start_time = st;
	interval = p_interval;
	end_time = st + interval * 1.1;
	used = 0;
	sample_rate = 1;
	desired_sample_rate = 1;
	sample_thresh = max_thresh;
	allowed = entries * lcm;
	mark2 = allowed / rmark;
	mark1 = allowed / rmark / 2;
	passed_mark1 = false;
    }
    bool sampleP(uint32_t val) const
	{ return sample_rate == 1.0 || val < sample_thresh; }
    double get_rate() const { return sample_rate; }
    void presample_adjust(double presample_rate) {
	// recalibrate sample_rate whenever presample_rate changes.
	sample_rate = desired_sample_rate / presample_rate;
	if (sample_rate > 1) {
	    sample_rate = 1;
	}
    } 
};

void sampler::update(int decisions, const fetime &now)
{
    used += lcm/decisions;
    if (!passed_mark1) {
	if (used > mark1) {
	    mark1_time = now();
	    passed_mark1 = true;
	}
	return;
    }
    if (used < mark2)
	return;

    double dnow = now();
    double period1 = mark1_time - start_time;
    double period2 = dnow - mark1_time;
    double delta = period2 - period1;
    if (delta < 0) delta = 0;
    int n = 2 * (rmark - 1);
    double exhaust_time = dnow + period2 * n + delta * n * (n+1) / 2;
#ifndef NDEBUG
    fprintf(stderr, "%10.6f %s %14s: %.2f entries, ",
	dnow - interval_start_time, shname, tabname, double(used)/lcm); //XXX
#endif
    if (exhaust_time < end_time) {
	sample_rate *= (exhaust_time - dnow) / (end_time - dnow);
	sample_thresh = uint32_t(max_thresh * sample_rate + 0.5);
#ifndef NDEBUG
	fprintf(stderr, "new rate %.9f\n", sample_rate); //XXX
    } else {
	fprintf(stderr, "no rate change\n"); //XXX
#endif
    }
    start_time = dnow;
    mark2 = used + (allowed - used) / rmark;
    mark1 = used + (allowed - used) / rmark / 2;
    passed_mark1 = false;
    // end_time = dnow + time_remaining_in_interval * 1.1;
    end_time = dnow + (interval_start_time + interval - dnow) * 1.1;
}

struct sample_parms_t {
    uint32_t psh;
    uint32_t fsh;
    uint32_t entries;
    double begin;
    double interval;
    int rmark;
};

#ifdef HAVE_EXT_HASH_MAP // XXX Hackery in assuming ext/hash_map is GCC 3.x
template <class Key, class Data, class HashFcn = __gnu_cxx::hash<Key>, class EqualKey = std::equal_to<Key> >
class flowest_table : public __gnu_cxx::hash_map<Key, Data, HashFcn, EqualKey>
{
    typedef __gnu_cxx::hash_map<Key, Data, HashFcn, EqualKey> HM;
#else
template <class Key, class Data, class HashFcn = hash<Key>, class EqualKey = std::equal_to<Key> >
class flowest_table : public hash_map<Key, Data, HashFcn, EqualKey>
{
    typedef hash_map<Key, Data, HashFcn, EqualKey> HM;
#endif
    flowest_table operator=(const flowest_table& x)
    {
	coral_diag(1, ("flowest_table error, copy constructor not implemented\n"));
	abort();
//	throw NotImplemented;  // Where is NotImplemented defined?
    }
    void init(const sample_parms_t &sample_parms) {
	if (sample_parms.psh || sample_parms.fsh)
	    start_fixed(sample_parms.psh, sample_parms.fsh);
	if (sample_parms.entries)
	    restart_adaptive(sample_parms.begin, sample_parms.interval,
		sample_parms.entries, sample_parms.rmark);
    }
public:
    sampler psh, fsh;
    Data other;
    flowest_table(const sample_parms_t &sample_parms, const char *tabname,
	uint32_t psh_max, uint32_t fsh_max) :
	HM(), other(), psh(tabname, "psh", 6, psh_max),
	fsh(tabname, "fsh", 6, fsh_max)
	{ init(sample_parms); }
    flowest_table(const sample_parms_t &sample_parms, const char *tabname,
	uint32_t psh_max, uint32_t fsh_max, size_t n) :
	HM(n), other(), psh(tabname, "psh", 6, psh_max),
	fsh(tabname, "fsh", 6, fsh_max)
	{ init(sample_parms); }
    flowest_table(const sample_parms_t &sample_parms, const char *tabname,
	uint32_t psh_max, uint32_t fsh_max, size_t n, const typename HM::hasher& h) :
	HM(n,h), other(), psh(tabname, "psh", 6, psh_max),
	fsh(tabname, "fsh", 6, fsh_max)
	{ init(sample_parms); }
    flowest_table(const sample_parms_t &sample_parms, const char *tabname,
	uint32_t psh_max, uint32_t fsh_max, size_t n, const typename HM::hasher& h,
	const typename HM::key_equal& k) :
	HM(n,h,k), other(), psh(tabname, "psh", 6, psh_max),
	fsh(tabname, "fsh", 6, fsh_max)
	{ init(sample_parms); }
    flowest_table(const sample_parms_t &sample_parms, const char *tabname,
	uint32_t psh_max, uint32_t fsh_max, const flowest_table& x) :
	HM(x), other(), psh(tabname, "psh", 6, psh_max),
	fsh(tabname, "fsh", 6, fsh_max)
	{ init(sample_parms); }
    void start_fixed(uint32_t psh_recip, uint32_t fsh_recip)
    {
	psh.start_fixed(psh_recip);
	fsh.start_fixed(fsh_recip);
    }
    void restart_adaptive(double st, double interval, uint32_t entries,
	int p_rmark)
    {
	psh.restart_adaptive(st, interval, entries, p_rmark);
	fsh.restart_adaptive(st, interval, entries, p_rmark);
    }
};

#endif // FLOWEST_TABLE
