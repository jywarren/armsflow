##
## Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
## All Rights Reserved 
##
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
##
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
##
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
##
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
##
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program. Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
##
## Report bugs and suggestions to coral-bugs@caida.org.
##
## ---------------------------------------------------------------------
## Perl module:  CAIDA::Tables::Proto_Ports_Table.pm

package CAIDA::Tables::Proto_Ports_Table;

# Set up object export condition.  No functions accessible directly.
use CAIDA::Tables::Generic;

# Inherit from the pack based generic table code.
@ISA = (CAIDA::Tables::Generic::Pack);

# Version of module
$VERSION = 2.0;

# Define required CVS variables
$cvs_Id = '$Id: Proto_Ports_Table.pm,v 1.17 2007/06/06 18:17:48 kkeys Exp $';
$cvs_Author = '$Author: kkeys $';
$cvs_Name = '$Name: release-3-8-1 $';
$cvs_Revision = '$Revision: 1.17 $';


# Enable error messages to come from calling script
use Carp;

# Force this module to adhere to safe programming practices.
use strict;


# .   .   .   .   .  User Method Subroutines  .   .   .   .   .   .   .   .


sub _initialize (@ ) {
    my ($self, $arg_hash_ref) = @_;

    $self->{'_kind'} = "Proto_Ports_Table";
    $self->{'_pack_elements'} = [ "C", "C", "n", "n" ];
    $self->{'_implode_filters'} = [ undef,
				    undef,
				    undef,
				    undef,
				  ];
    $self->{'_explode_filters'} = [ undef,
				    undef,
				    undef,
				    undef,
				  ];
    $self->{'_num_fields'} = 4;

    $self->SUPER::_initialize($arg_hash_ref);
}

sub make_Proto_Table (@ ) {
# -----------------------------------------------
# Quasi constructor function for Protocol
# tables.  It is a hack in that it depends on 
# the internal representation of Proto_Table
# being a variation on Proto_Ports_Table.
# -----------------------------------------------
    my ($self) = @_;
    
    my $result = $self->aggregate_columns(0);
    
    # XXX this depends on knowing that the internal representation of
    # an Proto_Table is the same as aggregate_columns(2) on a Proto_Ports_Table.
    $result->{'_kind'} = "Proto_Table";
    require CAIDA::Tables::Proto_Table;
    bless $result, "CAIDA::Tables::Proto_Table";
    
    return $result;
}   

sub make_Port_Matrix (@ ) {
    my ($self, $arg_hash_ref) = @_;
    my $protocol = $arg_hash_ref->{'protocol'};
    
    require CAIDA::Tables::Port_Matrix;
    my $port_matrix = new CAIDA::Tables::Port_Matrix();
    while (my ($opaque_key, $counts) = each %{ $self->data() }) {
	my ($ip_proto, $p_ok, $src_port, $dst_port) =
				$self->get_key_fields($opaque_key);
	unless (defined $protocol and $protocol != $ip_proto) {
	    $port_matrix->entry_add($src_port, $dst_port, $counts);
	}
    }
    $port_matrix->total->add($self->other);
    $port_matrix->other->add($self->other);
    return $port_matrix;
}   

sub make_src_Port_Table (@ ) {
    my ($self, $arg_hash_ref) = @_;
    my $protocol = $arg_hash_ref->{'protocol'};
    
    require CAIDA::Tables::Port_Table;
    my $port_table = new CAIDA::Tables::Port_Table();
    while (my ($opaque_key, $counts) = each %{ $self->data() }) {
	my ($ip_proto, $p_ok, $src_port, $dst_port) =
				$self->get_key_fields($opaque_key);
	unless (defined $protocol and $protocol != $ip_proto) {
	    $port_table->entry_add($src_port, $counts);
	}
    }
    $port_table->total->add($self->other);
    $port_table->other->add($self->other);
    return $port_table;
}   

sub make_dst_Port_Table (@ ) {
    my ($self, $arg_hash_ref) = @_;
    my $protocol = $arg_hash_ref->{'protocol'};
    
    require CAIDA::Tables::Port_Table;
    my $port_table = new CAIDA::Tables::Port_Table();
    while (my ($opaque_key, $counts) = each %{ $self->data() }) {
	my ($ip_proto, $p_ok, $src_port, $dst_port) =
				$self->get_key_fields($opaque_key);
	unless (defined $protocol and $protocol != $ip_proto) {
	    $port_table->entry_add($dst_port, $counts);
	}
    }
    $port_table->total->add($self->other);
    $port_table->other->add($self->other);
    return $port_table;
}   

sub make_src_Proto_Port_Table (@ ) {
    my ($self, $arg_hash_ref) = @_;
    my $protocol = $arg_hash_ref->{'protocol'};
    
    require CAIDA::Tables::Proto_Port_Table;
    my $port_table = new CAIDA::Tables::Proto_Port_Table();
    while (my ($opaque_key, $counts) = each %{ $self->data() }) {
	my ($ip_proto, $p_ok, $src_port, $dst_port) =
				$self->get_key_fields($opaque_key);
	unless (defined $protocol and $protocol != $ip_proto) {
	    $port_table->entry_add($ip_proto, $p_ok, $src_port, $counts);
	}
    }
    $port_table->total->add($self->other);
    $port_table->other->add($self->other);
    return $port_table;
}   

sub make_dst_Proto_Port_Table (@ ) {
    my ($self, $arg_hash_ref) = @_;
    my $protocol = $arg_hash_ref->{'protocol'};
    
    require CAIDA::Tables::Proto_Port_Table;
    my $port_table = new CAIDA::Tables::Proto_Port_Table();
    while (my ($opaque_key, $counts) = each %{ $self->data() }) {
	my ($ip_proto, $p_ok, $src_port, $dst_port) =
				$self->get_key_fields($opaque_key);
	unless (defined $protocol and $protocol != $ip_proto) {
	    $port_table->entry_add($ip_proto, $p_ok, $dst_port, $counts);
	}
    }
    $port_table->total->add($self->other);
    $port_table->other->add($self->other);
    return $port_table;
}   

# .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   . 
1; ##must be last line in the file
