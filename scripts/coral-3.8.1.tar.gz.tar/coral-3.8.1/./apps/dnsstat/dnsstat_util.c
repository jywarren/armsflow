/* 
 * Copyright 2002, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 */

/*
 * $Id: dnsstat_util.c,v 1.13 2007/06/06 18:17:28 kkeys Exp $
 */
/*
 * Keep statistics on DNS usage.
 */


static const char RCSid[]="$Id: dnsstat_util.c,v 1.13 2007/06/06 18:17:28 kkeys Exp $";

#include "config.h"
#include <sys/param.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <sys/time.h>
#include <sys/errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <signal.h>
#include <errno.h>
#include <netinet/in.h>

#include "libcoral.h"
#include "crl_byteorder.h"
#include "dns.h" /* ../../libsrc/libcoral */

#include "dnsstat.h"

struct dnsstat_file {
    FILE *file;
    int binary_version;
    rec_type_t (*read)(struct dnsstat_file *, config_t *, interval_data_t *,
	flowstats_t *, querystats_t *);
};

static col_id_t columns;

#define write_binary_int(file, n) \
    fwrite_binary_int(file, &(n), sizeof(n))
#define read_binary_int(file, n) \
    fread_binary_int(file, &(n), sizeof(n))

#define BISIZE1	    0x00
#define BISIZE2	    0x40
#define BISIZE4	    0x80
#define BISIZE8	    0xc0

typedef union {
    uint8_t n8;
    uint16_t n16;
    uint32_t n32;
    uint64_t n64;
    char c[8];
} binint_t;

#define dump_binary_note(file, field, type) \
    do { \
	if (field) { \
	    rec_type_t rec_type = type; \
	    if (!write_binary_int(file, rec_type)) return 0; \
	    if (!write_binary_int(file, field)) return 0; \
	} \
    } while (0)

/* writes integer in network order */
static size_t fwrite_binary_int(FILE *file, const void *p, size_t size)
{
    binint_t b;

    switch (size) {
    case 1:
	return fwrite(p, 1, 1, file);
    case 2:
	b.n16 = crl_htons(*(uint16_t*)p);
	return fwrite(&b.n16, 2, 1, file);
    case 4:
	b.n32 = crl_htonl(*(uint32_t*)p);
	return fwrite(&b.n32, 4, 1, file);
    case 8:
	/* compression: first 2 bits tells whether integer is
	 * 6, 14, 30, or 62 bits. */
	b.n64 = *(uint64_t*)p;
	if (b.n64 <= 0x3F) {
	    b.n8 = b.n64;
	    b.c[0] |= BISIZE1;
	    return fwrite(&b.n8, 1, 1, file);
	} else if (b.n64 <= 0x3FFF) {
	    b.n16 = crl_htons(b.n64);
	    b.c[0] |= BISIZE2;
	    return fwrite(&b.n16, 2, 1, file);
	} else if (b.n64 <= 0x3FFFFFFFul) {
	    b.n32 = crl_htonl(b.n64);
	    b.c[0] |= BISIZE4;
	    return fwrite(&b.n32, 4, 1, file);
	} else if (b.n64 <= 0x3FFFFFFFFFFFFFFFull) {
	    b.n64 = crl_hton64(b.n64);
	    b.c[0] |= BISIZE8;
	    return fwrite(&b.n32, 8, 1, file);
	} else {
	    fprintf(stderr, "number too large\n");
	    return 0;
	}
    }
    return 1;
}

/* reads network order integer */
static size_t fread_binary_int(dnsstat_file_t *df, void *p, size_t size)
{
    binint_t b;
    uint8_t bisize;

    switch (size) {
    case 1:
	return fread(p, 1, 1, df->file);
    case 2:
	if ((size = fread(&b.n16, 2, 1, df->file)))
	    *(uint16_t*)p = crl_ntohs(b.n16);
	return size;
    case 4:
	if ((size = fread(&b.n32, 4, 1, df->file)))
	    *(uint32_t*)p = crl_ntohl(b.n32);
	return size;
    case 8:
	if (!(size = fread(&b.c[0], 1, 1, df->file)))
	    return 0;
	bisize = (b.c[0] & 0xc0);
	b.c[0] &= ~0xc0;
	switch (bisize) {
	case BISIZE1:
	    *(uint64_t*)p = b.n8;
	    return 1;
	case BISIZE2:
	    if ((size = fread(&b.c[1], 1, 1, df->file)))
		*(uint64_t*)p = crl_ntohs(b.n16);
	    return size+1;
	case BISIZE4:
	    if ((size = fread(&b.c[1], 1, 3, df->file)))
		*(uint64_t*)p = crl_ntohl(b.n32);
	    return size+1;
	case BISIZE8:
	    if ((size = fread(&b.c[1], 1, 7, df->file)))
		*(uint64_t*)p = crl_ntoh64(b.n64);
	    return size+1;
	}
    }
    return 0;
}

int dump_binary_config(FILE *file, const col_id_t user_columns)
{
    rec_type_t type = TYPE_COLUMNS;

    columns = user_columns;
    fputs("# dnsstat binary v4\n", file);
    if (!write_binary_int(file, type)) return 0;
    if (!write_binary_int(file, columns)) return 0;
    return 1;
}

int dump_binary_interval(FILE *file, const interval_data_t *interval)
{
    rec_type_t type = TYPE_INTERVAL;

    if (!write_binary_int(file, type)) return 0;
    if (!write_binary_int(file, interval->begin.tv_sec)) return 0;
    if (!write_binary_int(file, interval->begin.tv_usec)) return 0;
    if (!write_binary_int(file, interval->end.tv_sec)) return 0;
    if (!write_binary_int(file, interval->end.tv_usec)) return 0;
    if (columns & COL_REQS) {
	if (!write_binary_int(file, interval->qmessages)) return 0;
	if (columns & COL_QUERIES)
	    if (!write_binary_int(file, interval->qqueries)) return 0;
    }
    if (columns & COL_RESPS) {
	if (!write_binary_int(file, interval->rmessages)) return 0;
	if (columns & COL_QUERIES)
	    if (!write_binary_int(file, interval->rqueries)) return 0;
    }
    return 1;
}

int dump_binary_eoi(FILE *file, const interval_data_t *interval)
{
    rec_type_t type = TYPE_EOI;

    if (!write_binary_int(file, type)) return 0;
    fflush(file);
    return 1;
}

int dump_binary_flowrec(FILE *file, const flowstats_t *flowrec)
{
    rec_type_t type = TYPE_FLOW;

    write_binary_int(file, type);
    if (columns & COL_SRC)
	if (!fwrite(&flowrec->src, sizeof(flowrec->src), 1, file)) return 0;
    if (columns & COL_DST)
	if (!fwrite(&flowrec->dst, sizeof(flowrec->dst), 1, file)) return 0;
    if (columns & COL_PROTO)
	if (!write_binary_int(file, flowrec->ip_proto)) return 0;
    if (columns & COL_REQS) {
	if (columns & COL_QUERIES)
	    if (!write_binary_int(file, flowrec->qqueries)) return 0;
	if (!write_binary_int(file, flowrec->qmessages)) return 0;
    }
    if (columns & COL_RESPS) {
	if (columns & COL_QUERIES)
	    if (!write_binary_int(file, flowrec->rqueries)) return 0;
	if (!write_binary_int(file, flowrec->rmessages)) return 0;
    }

    dump_binary_note(file, flowrec->multiqueries, TYPE_MQ);
    dump_binary_note(file, flowrec->zeroqueries, TYPE_ZQ);
    dump_binary_note(file, flowrec->qdswapped, TYPE_SWAP);
    dump_binary_note(file, flowrec->recursion, TYPE_RD);
    dump_binary_note(file, flowrec->qL4_errs, TYPE_QL4ERR);
    dump_binary_note(file, flowrec->qhtrunc, TYPE_QHTRUNC);
    dump_binary_note(file, flowrec->rL4_errs, TYPE_RL4ERR);
    dump_binary_note(file, flowrec->rhtrunc, TYPE_RHTRUNC);

    return 1;
}

int dump_binary_queryrec(FILE *file, const querystats_t *queryrec)
{
    rec_type_t type;

    if (queryrec->truncated) {
	type = TYPE_TRUNCATED;
    } else if (queryrec->qclass == C_IN && queryrec->opcode == 0) {
	/* compress common qtypes */
	switch (queryrec->qtype) {
	    case T_A:     type = TYPE_QUERY_0_IN_A;    break;
	    case T_PTR:   type = TYPE_QUERY_0_IN_PTR;  break;
	    case T_SOA:   type = TYPE_QUERY_0_IN_SOA;  break;
	    case T_MX:    type = TYPE_QUERY_0_IN_MX;   break;
	    case T_NS:    type = TYPE_QUERY_0_IN_NS;   break;
	    case T_ANY:   type = TYPE_QUERY_0_IN_ANY;  break;
	    case T_SRV:   type = TYPE_QUERY_0_IN_SRV;  break;
	    case T_AAAA:  type = TYPE_QUERY_0_IN_AAAA; break;
	    case T_A6:    type = TYPE_QUERY_0_IN_A6;   break;
	    default:      type = TYPE_QUERY_0_IN;      break;
	}
    } else {
	type = TYPE_QUERY;
    }

    if (!write_binary_int(file, type)) return 0;

    switch (type) {
    case TYPE_QUERY:
	if (!write_binary_int(file, queryrec->opcode)) return 0;
	if (!write_binary_int(file, queryrec->qtype)) return 0;
	if (!write_binary_int(file, queryrec->qclass)) return 0;
	break;

    case TYPE_QUERY_0_IN:
	if (!write_binary_int(file, queryrec->qtype)) return 0;
	break;

    case TYPE_TRUNCATED:
	if (!write_binary_int(file, queryrec->opcode)) return 0;
	break;

    /* case TYPE_QUERY_0_IN_*: break; */
    }

    if (columns & COL_REQS)
	if (!write_binary_int(file, queryrec->qqueries)) return 0;
    if (columns & COL_RESPS)
	if (!write_binary_int(file, queryrec->rqueries)) return 0;

    dump_binary_note(file, queryrec->qdswapped, TYPE_SWAP);
    dump_binary_note(file, queryrec->recursion, TYPE_RD);

    return 1;
}

int dump_binary_eof(FILE *file)
{
    rec_type_t type = TYPE_EOF;
    return write_binary_int(file, type);
}


static rec_type_t read_binary_record(dnsstat_file_t *df, config_t *config,
    interval_data_t *interval, flowstats_t *flowrec, querystats_t *queryrec)
{
    rec_type_t type;
    char buf[80];

next:
    if (!read_binary_int(df, type))
	return TYPE_ERR;

    switch (type) {
    case '#':
	fgets(buf, sizeof(buf), df->file);
	fprintf(stderr, "### %s", buf);
	goto next;

    case TYPE_COLUMNS:
	if (!read_binary_int(df, columns)) return TYPE_ERR;
	if (!(columns & COL_SRC)) config->nosrc = 1;
	if (!(columns & COL_DST)) config->nodst = 1;
	if (!(columns & COL_PROTO)) config->noproto = 1;
	if (!(columns & COL_REQS)) config->no_requests = 1;
	if (!(columns & COL_RESPS)) config->no_responses = 1;
	if (!(columns & (COL_OP | COL_TYPE | COL_CLASS))) config->notypes = 1;
	/*if (!(columns & COL_SWAP)) config->no_swap = 1;*/
	return type;

    case TYPE_INTERVAL:
	memset(interval, 0, sizeof(*interval));
	if (!read_binary_int(df, interval->begin.tv_sec)) return TYPE_ERR;
	if (!read_binary_int(df, interval->begin.tv_usec)) return TYPE_ERR;
	if (!read_binary_int(df, interval->end.tv_sec)) return TYPE_ERR;
	if (!read_binary_int(df, interval->end.tv_usec)) return TYPE_ERR;
	if (columns & COL_REQS) {
	    if (!read_binary_int(df, interval->qmessages)) return TYPE_ERR;
	    if (columns & COL_QUERIES)
		if (!read_binary_int(df, interval->qqueries)) return TYPE_ERR;
	}
	if (columns & COL_RESPS) {
	    if (!read_binary_int(df, interval->rmessages)) return TYPE_ERR;
	    if (columns & COL_QUERIES)
		if (!read_binary_int(df, interval->rqueries)) return TYPE_ERR;
	}
	return type;

    case TYPE_FLOW:
	memset(flowrec, 0, sizeof(*flowrec));
	if (columns & COL_SRC)
	    if (!fread(&flowrec->src, sizeof(flowrec->src), 1, df->file))
		return TYPE_ERR;
	if (columns & COL_DST)
	    if (!fread(&flowrec->dst, sizeof(flowrec->dst), 1, df->file))
		return TYPE_ERR;
	if (columns & COL_PROTO)
	    if (!read_binary_int(df, flowrec->ip_proto)) return TYPE_ERR;
	if (columns & COL_REQS) {
	    if (columns & COL_QUERIES)
		if (!read_binary_int(df, flowrec->qqueries)) return TYPE_ERR;
	    if (!read_binary_int(df, flowrec->qmessages)) return TYPE_ERR;
	}
	if (columns & COL_RESPS) {
	    if (columns & COL_QUERIES)
		if (!read_binary_int(df, flowrec->rqueries)) return TYPE_ERR;
	    if (!read_binary_int(df, flowrec->rmessages)) return TYPE_ERR;
	}

	/* "notes" */
	while (1) {
	    if (!read_binary_int(df, type))
		return TYPE_ERR;
	    switch (type) {
	    case TYPE_MQ:
		if (!read_binary_int(df, flowrec->multiqueries))
		    return TYPE_ERR;
		break;
	    case TYPE_ZQ:
		if (!read_binary_int(df, flowrec->zeroqueries))
		    return TYPE_ERR;
		break;
	    case TYPE_SWAP:
		if (!read_binary_int(df, flowrec->qdswapped))
		    return TYPE_ERR;
		break;
	    case TYPE_RD:
		if (!read_binary_int(df, flowrec->recursion))
		    return TYPE_ERR;
		break;
	    case TYPE_QL4ERR:
		if (!read_binary_int(df, flowrec->qL4_errs))
		    return TYPE_ERR;
		break;
	    case TYPE_RL4ERR:
		if (!read_binary_int(df, flowrec->rL4_errs))
		    return TYPE_ERR;
		break;
	    case TYPE_QHTRUNC:
		if (!read_binary_int(df, flowrec->qhtrunc))
		    return TYPE_ERR;
		break;
	    case TYPE_RHTRUNC:
		if (!read_binary_int(df, flowrec->rhtrunc))
		    return TYPE_ERR;
		break;
	    default:
		ungetc(type, df->file); /* push type back on stream */
		return TYPE_FLOW;
	    }
	}

	/* unreachable */
	return TYPE_FLOW;

    case TYPE_EOI:
    case TYPE_EOF:
    case TYPE_ERR:
	return type;
    }

    /* all query record types, or invalid */
    memset(queryrec, 0, sizeof(*queryrec));
    queryrec->qclass = C_IN;
    queryrec->opcode = 0;
    queryrec->truncated = 0;

    switch (type) {
    case TYPE_QUERY:
	if (!read_binary_int(df, queryrec->opcode)) return TYPE_ERR;
	if (!read_binary_int(df, queryrec->qtype)) return TYPE_ERR;
	if (!read_binary_int(df, queryrec->qclass)) return TYPE_ERR;
	break;

    case TYPE_QUERY_0_IN:
	if (!read_binary_int(df, queryrec->qtype)) return TYPE_ERR;
	break;

    case TYPE_TRUNCATED:
	queryrec->truncated = 1;
	if (!read_binary_int(df, queryrec->opcode)) return TYPE_ERR;
	queryrec->qtype = -1;
	queryrec->qclass = -1;
	break;

    case TYPE_QUERY_0_IN_A:    queryrec->qtype = T_A;    break;
    case TYPE_QUERY_0_IN_PTR:  queryrec->qtype = T_PTR;  break;
    case TYPE_QUERY_0_IN_SOA:  queryrec->qtype = T_SOA;  break;
    case TYPE_QUERY_0_IN_MX:   queryrec->qtype = T_MX;   break;
    case TYPE_QUERY_0_IN_NS:   queryrec->qtype = T_NS;   break;
    case TYPE_QUERY_0_IN_ANY:  queryrec->qtype = T_ANY;  break;
    case TYPE_QUERY_0_IN_SRV:  queryrec->qtype = T_SRV;  break;
    case TYPE_QUERY_0_IN_AAAA: queryrec->qtype = T_AAAA; break;
    case TYPE_QUERY_0_IN_A6:   queryrec->qtype = T_A6;   break;

    default:
	fprintf(stderr, "unknown record type %02x\n", type);
	return TYPE_ERR;
    }

    if (columns & COL_REQS)
	if (!read_binary_int(df, queryrec->qqueries)) return TYPE_ERR;
    if (columns & COL_RESPS)
	if (!read_binary_int(df, queryrec->rqueries)) return TYPE_ERR;

    /* "notes" */
    while (1) {
	if (!read_binary_int(df, type))
	    return TYPE_ERR;
	switch (type) {
	case TYPE_SWAP:
	    if (!read_binary_int(df, queryrec->qdswapped))
		return TYPE_ERR;
	    break;
	case TYPE_RD:
	    if (!read_binary_int(df, queryrec->recursion))
		return TYPE_ERR;
	    break;
	default:
	    ungetc(type, df->file); /* push type back on stream */
	    return TYPE_QUERY;
	}
    }

    /* unreached */
    return TYPE_QUERY;
}

static rec_type_t read_text_record(dnsstat_file_t *df, config_t *config,
    interval_data_t *interval, flowstats_t *flowrec, querystats_t *queryrec)
{
    rec_type_t type;
    char line[132];
    const char *s, *next;
    static int state = 0;

    if (state == 1) {
	state++;
	return TYPE_INTERVAL;
    }

next:
    if (!fgets(line, sizeof(line), df->file)) {
	if (ferror(df->file)) {
	    fprintf(stderr, "%s\n", strerror(errno));
	    return TYPE_ERR;
	}
	fclose(df->file);
	return TYPE_EOF;
    }

#if 0
    if (sscanf(line, "# dnsstat output version: %d.%d",
	&df->text_major_version, &df->text_minor_version) == 2)
    {
	/* do nothing */

    } else
#endif
    if (sscanf(line, "# begin trace interval at %ld.%ld, duration %ld.%ld",
	&interval->begin.tv_sec, &interval->begin.tv_usec,
	&interval->end.tv_sec, &interval->end.tv_usec) == 4)
    {
	timeradd(&interval->end, &interval->begin, &interval->end);
	interval->qmessages = interval->qqueries = 0;
	interval->rmessages = interval->rqueries = 0;

	if (!fgets(line, sizeof(line), df->file)) {
	    fprintf(stderr, "%s\n", strerror(errno));
	    return TYPE_ERR;
	}
	if (sscanf(line,
		"# DNS requests: %" SCNu64 " (%*d.%*d/s); "
		"DNS request queries: %" SCNu64 " (%*d.%*d/s)",
		&interval->qmessages, &interval->qqueries) == 2 ||
	    sscanf(line,
		"# DNS messages: %" SCNu64 " (%*d.%*d/s); "
		"DNS queries: %" SCNu64 " (%*d.%*d/s)",
		&interval->qmessages, &interval->qqueries) == 2)
	{
	    if (!fgets(line, sizeof(line), df->file)) {
		fprintf(stderr, "%s\n", strerror(errno));
		return TYPE_ERR;
	    }
	}

	if (sscanf(line,
	    "# DNS responses: %" SCNu64 " (%*d.%*d/s); "
	    "DNS response queries: %" SCNu64 " (%*d.%*d/s)",
	    &interval->rmessages, &interval->rqueries) != 2)
	{
	    if (!fgets(line, sizeof(line), df->file)) {
		fprintf(stderr, "%s\n", strerror(errno));
		return TYPE_ERR;
	    }
	}

	config->nosrc = 1;
	config->nodst = 1;
	config->noproto = 1;
	config->notypes = 1;
	config->no_rd = 1;
	config->no_requests = 1;
	config->no_responses = 1;
	while (1) {
	    if (line[0] == '#' && line[1] != ' ') break;
	    if (line[0] != '#' && line[0] != '\n') {
		fprintf(stderr, "missing header\n");
		return TYPE_ERR;
	    }
	    if (!fgets(line, sizeof(line), df->file)) {
		fprintf(stderr, "%s\n", strerror(errno));
		return TYPE_ERR;
	    }
	}
	for (s = strtok(line+1, " \n"); s; s = next) {
	    next = strtok(NULL, " \n");
	    if (strcmp(s, "src") == 0)
		config->nosrc = 0;
	    else if (strcmp(s, "dst") == 0)
		config->nodst = 0;
	    else if (strcmp(s, "proto") == 0)
		config->noproto = 0;
	    else if (strcmp(s, "op") == 0 ||
		strcmp(s, "type") == 0 ||
		strcmp(s, "class") == 0)
		    config->notypes = 0;
	    else if (strcmp(s, "rd") == 0)
		config->no_rd = 0;
	    else if (strcmp(s, "queries") == 0 ||
		strcmp(s, "msgs") == 0 ||
		strcmp(s, "reqs") == 0 ||
		strcmp(s, "req?s") == 0)
		    config->no_requests = 0;
	    else if (strcmp(s, "resps") == 0 ||
		strcmp(s, "resp?s") == 0)
		    config->no_responses = 0;
	    else if (strcmp(s, "notes") == 0)
		/* do nothing */;
	    else {
		fprintf(stderr, "unknown column %s\n", s);
		return TYPE_ERR;
	    }
	}

	if (state == 0) {
	    state++;
	    return TYPE_COLUMNS;
	}
	return TYPE_INTERVAL;

    } else if (strcmp(line, "# end trace interval\n") == 0) {
	return TYPE_EOI;

    } else if (line[0] == '#' || !(s = strtok(line+1, " \n"))) {
	goto next;

    } else {
	memset(flowrec, 0, sizeof(*flowrec));
	memset(queryrec, 0, sizeof(*queryrec));
	if (!config->nosrc) {
	    if (!coral_inet_pton(AF_INET, s, &flowrec->src)) {
		fprintf(stderr, "bad src address\n");
		return TYPE_ERR;
	    }
	    s = strtok(NULL, " \n");
	}
	if (!config->nodst) {
	    if (!coral_inet_pton(AF_INET, s, &flowrec->dst)) {
		fprintf(stderr, "bad dst address\n");
		return TYPE_ERR;
	    }
	    s = strtok(NULL, " \n");
	}
	if (!config->notypes) {
	    if (strcmp(s, "-") == 0) {
		type = TYPE_FLOW;
		s = strtok(NULL, " \n");
		if (strcmp(s, "-") != 0) return TYPE_ERR;
		s = strtok(NULL, " \n");
		if (strcmp(s, "-") != 0) return TYPE_ERR;
		s = strtok(NULL, " \n");
	    } else {
		/* TYPE_QEURY */
		queryrec->opcode = coral_dns_str_to_op(s);
		s = strtok(NULL, " \n");
		if (strcmp(s, "?") == 0)
		    return TYPE_TRUNCATED;
		queryrec->qtype = coral_dns_str_to_qtype(s);
		s = strtok(NULL, " \n");
		queryrec->qclass = coral_dns_str_to_qclass(s);
		if (!config->no_requests) {
		    s = strtok(NULL, " \n");
		    queryrec->qqueries = strtol(s, NULL, 10);
		    if (!config->no_responses)
			s = strtok(NULL, " \n"); /* eat the "-" column */
		}
		if (!config->no_responses) {
		    s = strtok(NULL, " \n");
		    queryrec->rqueries = strtol(s, NULL, 10);
		    s = strtok(NULL, " \n"); /* eat the "-" column */
		}
		s = strtok(NULL, " \n");
		if (s && !config->no_rd) {
		    queryrec->recursion = strtol(s, NULL, 10);
		} else {
		    queryrec->recursion = 0;
		}

		s = strtok(NULL, " \n");
		while (s) {
		    next = strtok(NULL, " \n");
		    if (sscanf(s, "swap=%" SCNu64, &queryrec->qdswapped) != 1)
		    {
			fprintf(stderr, "unknown note: %s\n", s);
			return TYPE_ERR;
		    }
		    s = next;
		}
		return TYPE_QUERY;
	    }
	}

	if (!config->no_requests) {
	    flowrec->qqueries = strtol(s, NULL, 10);
	    s = strtok(NULL, " \n");
	    flowrec->qmessages = strtol(s, NULL, 10);
	    s = strtok(NULL, " \n");
	}
	if (!config->no_responses) {
	    flowrec->rqueries = strtol(s, NULL, 10);
	    s = strtok(NULL, " \n");
	    flowrec->rmessages = strtol(s, NULL, 10);
	    s = strtok(NULL, " \n");
	}
	if (!config->no_rd) {
	    flowrec->recursion = strtol(s, NULL, 10);
	    s = strtok(NULL, " \n");
	} else {
	    flowrec->recursion = 0;
	}

	while (s) {
	    next = strtok(NULL, " \n");
	    if (strncmp(s, "rd!=", 4) != 0 &&
		sscanf(s, "qL4err=%" SCNu64, &flowrec->qL4_errs) != 1 &&
		sscanf(s, "qhtrunc=%" SCNu64, &flowrec->qhtrunc) != 1 &&
		sscanf(s, "rL4err=%" SCNu64, &flowrec->rL4_errs) != 1 &&
		sscanf(s, "rhtrunc=%" SCNu64, &flowrec->rhtrunc) != 1 &&
		sscanf(s, "swap=%" SCNu64, &flowrec->qdswapped) != 1 &&
		sscanf(s, "mq=%" SCNu64, &flowrec->multiqueries) != 1 &&
		sscanf(s, "zq=%" SCNu64, &flowrec->zeroqueries) != 1)
	    {
		fprintf(stderr, "unknown note: %s\n", s);
		return TYPE_ERR;
	    }
	    s = next;
	}
	return TYPE_FLOW;
    }

    return type;
}

rec_type_t read_dnsstat_record(dnsstat_file_t *df, config_t *config,
    interval_data_t *interval, flowstats_t *flowrec, querystats_t *queryrec)
{
    return df->read(df, config, interval, flowrec, queryrec);
}

dnsstat_file_t *open_dnsstat_file(const char *filename)
{
    char buf[80];
    dnsstat_file_t *df;

    df = calloc(1, sizeof(*df));
    if (!df) return NULL;
    if (!filename || strcmp(filename, "-") == 0)
	df->file = stdin;
    else {
	if (!(df->file = fopen(filename, "r"))) {
	    coral_diag(0, ("%s: %s\n", filename, strerror(errno)));
	    free(df);
	    return NULL;
	}
    }
    
    fgets(buf, sizeof(buf), df->file);
    if (sscanf(buf, "# dnsstat binary v%d", &df->binary_version) == 1) {
	df->read = read_binary_record;
    } else {
	df->read = read_text_record;
    }
    return df;
}

int close_dnsstat_file(dnsstat_file_t *df)
{
    return fclose(df->file);
}
