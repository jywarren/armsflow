/* 
 * Copyright 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 * Common functions and data structures for coral drivers.
 *
 * This contains the struct block and struct block_pool code.  Use the
 * block_pool struct to handle storing and retreiving blocks of a certain
 * type.  The types supported are: free, locked, filling, and filled.  The
 * functions you'll be interested in are block_* and block_pool_*.  The
 * routines here currently handle locking by setting interrupt levels. 
 * Ideally, they will use spinlocks someday.
 *
 * For example, initialize your block_pool structure with
 * block_pool_initialize.  Create some blocks using block_create, add them
 * to the free block queue with block_pool_free_set.
 */

#ifndef CORAL_COMMON_H
#define CORAL_COMMON_H

#if (__FreeBSD_version < 400000 && defined(KERNEL)) || \
    (__FreeBSD_version >= 400000 && defined(_KERNEL))
#include <pci/coral_global.h>
#else
#include "coral_global.h"
#endif

#if __FreeBSD_version >= 340000
#define pci_probe_return_t const char *
#else
#define pci_probe_return_t char *
#endif

/* 
 * Information about each block available to the driver.  This includes the
 * raw memory address, coral block info, and the index number.
 */
struct block {
    
    /* Pointer to the next block of the same type or NULL if none. */
    struct block *next;
    
    /* Coral info about this block.  Timestamps and the like. */
    coral_blk_info_t *header;
    
    /* Index number of this block. */
    int index;
    
    /* Pointer to the raw block of data that the card fills with cells. */
    char *raw_block;
};

/*
 * Initializes a block; clears the header info.
 */
void block_initialize(struct block *block, int interface,
    u_int blk_size);

/* 
 * Create a new block given memory to use for the raw block.
 */
struct block *block_create(char *raw_block, coral_blk_info_t *header, int index);


/* 
 * A queue structure for the driver to store groups of blocks with and allow
 * for insertion at the end and removal at the tail.
 *
 * Should only be used internally by coral_common.c.
 *
 * Proper locking of this datastructure is required and taken care of by the
 * block_queue_* functions.  Use them and avoid poking directly at this
 * structure.
 */
struct block_queue {
    
    /* First block of a queue or NULL if none. */
    struct block *head;
    
    /* Last block of a queue or NULL if none. */
    struct block *tail;
};

/* 
 * Initialize a block queue. 
 */
void block_queue_initialize(struct block_queue *block_queue);

/* 
 * Insert to a block queue. 
 */
void block_queue_insert(struct block_queue *block_queue, struct block *block);

/* 
 * Remove from a block queue. 
 */
struct block *block_queue_remove(struct block_queue *block_queue);

/* 
 * Check if a queue is empty.  Returns TRUE/FALSE. 
 */
int block_queue_is_empty(struct block_queue *block_queue);


/* 
 * Holds queues of blocks of different types for the driver.  Keeps track of
 * which blocks are filled, which are free, etc..
 *
 * For use by coral drivers.  Use block_pool_* functions to access this,
 * avoid poking at it by hand.
 */
struct block_pool {
    
    /* Queue of free blocks available to the driver. */
    struct block_queue block_free;
    
    /* Queue of filled blocks. */
    struct block_queue block_filled;
    
    /* Queue of locked blocks (in use by user). */
    struct block_queue block_locked;
    
    /* Queue of blocks currently being filled by the card. */
    struct block_queue block_filling;
};

/*
 * Initialize a new buffer.
 */
void block_pool_initialize(struct block_pool *block_pool);

/*
 * Resets the buffer, setting default values on all blocks.
 */
void block_pool_reset(struct block_pool *block_pool, int interface,
    u_int blk_size);

/*
 * Check if we have any filled blocks.  Returns TRUE/FALSE.
 */
static inline int block_pool_has_filled_blocks(struct block_pool *block_pool);

/*
 * Get a locked block.  Returns NULL if there isn't one.
 *
 * All 'get' functions including this one return the oldest saved block of
 * the group.
 */
static inline struct block *block_pool_locked_get(struct block_pool *block_pool);

/*
 * Save a block as locked.
 */
static inline void block_pool_locked_set(struct block_pool *block_pool, struct block *block);

/*
 * Get a filled block.  Returns NULL if there isn't one.
 */
static inline struct block *block_pool_filled_get(struct block_pool *block_pool);

/*
 * Save a block as filled.
 */
static inline void block_pool_filled_set(struct block_pool *block_pool, struct block *block);

/*
 * Get a block that was being filled.
 */
static inline struct block *block_pool_filling_get(struct block_pool *block_pool);

/*
 * Set a block as being filled.
 */
static inline void block_pool_filling_set(struct block_pool *block_pool, struct block *block);

/*
 * Get a free block.  Returns NULL if there isn't one.
 */
static inline struct block *block_pool_free_get(struct block_pool *block_pool);

/*
 * Save a block as free.
 */
static inline void block_pool_free_set(struct block_pool *block_pool, struct block *block);


/*
 * End of definitions.  The following are 'macros' of simple and commonly
 * used functions to ensure that by not having to deal with the overhead of
 * a stack frame, the interrupt routines will be quick.
 */

/*
 * Check if we have any filled blocks.  Returns TRUE/FALSE.
 */
static inline int block_pool_has_filled_blocks(struct block_pool *block_pool) {
    
    /* Check if the queue is empty or not. */
    return(!block_queue_is_empty(&block_pool->block_filled));
}


/*
 * Save a block as free.
 */
static inline void block_pool_free_set(struct block_pool *block_pool, struct block *block) {
    
    /* Add this block to the free queue */
    block_queue_insert(&block_pool->block_free, block);
    
    return;
}


/*
 * Save a block as locked.
 */
static inline void block_pool_locked_set(struct block_pool *block_pool, struct block *block) {
    
    /* Add this block to the locked queue. */
    block_queue_insert(&block_pool->block_locked, block);
    
    return;
}


/*
 * Save a block as filled.
 */
static inline void block_pool_filled_set(struct block_pool *block_pool, struct block *block) {
    
    /* Add this block to the filled queue. */
    block_queue_insert(&block_pool->block_filled, block);
    
    return;
}


/*
 * Set a block as being filled; filling.
 */
static inline void block_pool_filling_set(struct block_pool *block_pool, struct block *block) {
    
    /* Add this block to the filling queue. */
    block_queue_insert(&block_pool->block_filling, block);
    
    return;
}


/*
 * Get the block that was being filled.
 */
static inline struct block *block_pool_filling_get(struct block_pool *block_pool) {
    
    /* Return the last block in the filling queue or NULL if none. */
    return(block_queue_remove(&block_pool->block_filling));
}


/*
 * Get a free block.  Returns NULL if there isn't one.
 */
static inline struct block *block_pool_free_get(struct block_pool *block_pool) {
    
    /* Return the first block in the free queue or NULL if none. */
    return(block_queue_remove(&block_pool->block_free));
}


/*
 * Get a filled block.  Returns NULL if there isn't one.
 */
static inline struct block *block_pool_filled_get(struct block_pool *block_pool) {
    
    /* Return the first block in the filled queue or NULL if none. */
    return(block_queue_remove(&block_pool->block_filled));
}


/*
 * Get a locked block.  Returns NULL if there isn't one.
 */
static inline struct block *block_pool_locked_get(struct block_pool *block_pool) {
    
    /* Return the first block in the locked queue or NULL if none. */
    return(block_queue_remove(&block_pool->block_locked));
}


#endif
