/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 * coral_pkt.h - libcoral packet definitions
 *
 * $Id: coral_atm_rfc1483.h,v 1.9 2007/06/06 18:17:52 kkeys Exp $
 */

#ifndef CORAL_ATM_RFC1483_H
#define CORAL_ATM_RFC1483_H

/* IMPORTANT: application must do ntohl(atm_hdr.ui) before accessing fields of
 * atm_hdr.h, because fields cross byte boundaries.
 */
union atm_hdr {
#if defined(BYTE_ORDER) || defined(WORDS_BIGENDIAN)
    struct {
# if (defined(WORDS_BIGENDIAN) && WORDS_BIGENDIAN) || \
  (defined(BYTE_ORDER) && (BYTE_ORDER == BIG_ENDIAN))
        uint32_t gfc         : 4;  /* generic flow control */
        uint32_t vpvc        : 24; /* virtual path + circuit indicators */
        uint32_t oam_rm      : 1;  /* PTI: OAM/RM indicator (not user data) */
        uint32_t congestion  : 1;  /* PTI: we don't use this */
        uint32_t sdu_type    : 1;  /* PTI: in AAL5, this marks end of SAR-SDU */
        uint32_t clp         : 1;  /* cell loss priority */
# else
        uint32_t clp         : 1;  /* cell loss priority */
        uint32_t sdu_type    : 1;  /* PTI: in AAL5, this marks end of SAR-SDU */
        uint32_t congestion  : 1;  /* PTI: we don't use this */
        uint32_t oam_rm      : 1;  /* PTI: OAM/RM indicator (not user data) */
        uint32_t vpvc        : 24; /* virtual path + circuit indicators */
        uint32_t gfc         : 4;  /* generic flow control */
# endif
    } h;
#endif
    uint32_t ui;
};

/* macros to access the parts of a vpvc */
#define get_vpvc_vp(vpvc)	(((vpvc) & 0xFF0000) >> 16)
#define get_vpvc_vc(vpvc)	((vpvc) & 0xFFFF)
#define set_vpvc_vp(vpvc, vp)	\
    ((vpvc) = ((vpvc) & ~0xFF0000) | (((vp) << 16) & 0xFF0000))
#define set_vpvc_vc(vpvc, vc)	\
    ((vpvc) = ((vpvc) & ~0xFFFF) | ((vc) & 0xFFFF))

#define vp_vc_to_vpvc(vp, vc)	(((vp) << 16) | ((vc) & 0xFFFF))

typedef void coral_atm_cell_t;


/*
 * cell accessors
 */

/* indexes of values in cell_layout array */
enum {
    CORAL_CELL_SIZE_IDX,
    CORAL_CELL_OFFSET_TIME_IDX,
    CORAL_CELL_OFFSET_HEADER_IDX,
    CORAL_CELL_OFFSET_HEC_IDX,
    CORAL_CELL_OFFSET_PAYLOAD_IDX,
    CORAL_CELL_OFFSET_CAPLEN_IDX,
    CORAL_CELL_OFFSET_TOTLEN_IDX,
    CORAL_CELL_OFFSET_UNUSED3_IDX,	/* for future use */
    /* If any new fields are inserted here, initializers in coral_iface_*.c
     * will need to be fixed. */
    CORAL_CELL_NUM_FIELDS
};

#define OLD_CELL_LAYOUT	 { \
    sizeof(coral_old_atm_cell_t), /* 60 */ \
    offsetof(coral_old_atm_cell_t, t),	/* 0 */ \
    offsetof(coral_old_atm_cell_t, cu),	/* 8 */ \
    /* HEC offset */ -1, \
    offsetof(coral_old_atm_cell_t, p),	/* 12 */ \
    /* caplen offset */ -1, \
    /* totlen offset */ -1, \
    /* unused3 offset */ -1 \
    }

#define coral_cell_size(iface)		\
    ((*(int**)(iface))[CORAL_CELL_SIZE_IDX])

#define coral_cell_field_offset(iface, field) \
    ((*(int**)(iface))[CORAL_CELL_OFFSET_##field##_IDX])

/* pointer to required field in cell */
#define coral_cell_field_req(iface, cell, field)	\
    ((char*)(cell) + coral_cell_field_offset((iface), field))

/* pointer to optional field in cell, or NULL if not present */
#define coral_cell_field(iface, cell, field)	\
    (coral_cell_field_offset(iface, field) >= 0 ? \
	((char*)(cell) + coral_cell_field_offset((iface), field)) : \
	NULL)

#define coral_cell_time(iface, cell)	\
    ((const coral_timestamp_t*)coral_cell_field(iface, cell, TIME))
#define coral_cell_time_req(iface, cell)	\
    ((const coral_timestamp_t*)coral_cell_field_req(iface, cell, TIME))
#define coral_cell_header(iface, cell)	\
    ((const union atm_hdr*)coral_cell_field(iface, cell, HEADER))
#define coral_cell_header_req(iface, cell)	\
    ((const union atm_hdr*)coral_cell_field_req(iface, cell, HEADER))
#define coral_cell_hec(iface, cell)	\
    ((const char *)coral_cell_field(iface, cell, HEC))
#define coral_cell_payload(iface, cell)	\
    ((const char*)coral_cell_field(iface, cell, PAYLOAD))
#define coral_cell_payload_req(iface, cell)	\
    ((const char*)coral_cell_field_req(iface, cell, PAYLOAD))
#define coral_cell_caplen(iface, cell)	\
    ((const int*)coral_cell_field(iface, cell, CAPLEN))
#define coral_cell_totlen(iface, cell)	\
    ((const int*)coral_cell_field(iface, cell, TOTLEN))

#define coral_cell_time_double(iface, cell) \
    coral_read_clock_double(iface, coral_cell_time(iface, cell))



/* this belongs in some other header */
typedef struct {
    uint8_t	cpcs_uu;	/* CPCS user-to-user inidication */
    uint8_t	cpi;		/* common part indicator */
    uint16_t	length;		/* length of CPCS PDU payload */
    uint32_t	crc;		/* cyclic redundancy check of CPCS PDU */
} aal5_trailer_t;


/* this belongs in some other header */
typedef struct {
    /* LLC/SNAP header (802.2 and rfc1042) */
    uint8_t     llc_dsap;	/* always 170 (0xAA) */
    uint8_t     llc_ssap;	/* always 170 (0xAA) */
    uint8_t     llc_cntl;	/* always 3 */
    uint8_t     snap_org[3];	/* always 0 */
    uint16_t    snap_type;	/* see rfc1340 for assigned types */
} coral_llcsnap_t;


#endif /* CORAL_ATM_RFC1483_H */
