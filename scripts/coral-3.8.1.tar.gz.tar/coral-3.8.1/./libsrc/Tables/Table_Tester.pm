## 
## Copyright 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
## All Rights Reserved 
##
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
##
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
##
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
##
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
##
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program. Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
##
## Report bugs and suggestions to coral-bugs@caida.org.
## 
## ---------------------------------------------------------------------
## Perl module:  Table_Tester.pm

package Table_Tester;

use vars qw($cvs_Id $cvs_Author $cvs_Name $cvs_Revision $VERSION);
# Define required CVS variables
$cvs_Id = '$Id: Table_Tester.pm,v 1.37 2007/06/06 18:17:48 kkeys Exp $';
$cvs_Author = '$Author: kkeys $';
$cvs_Name = '$Name: release-3-8-1 $';
$cvs_Revision = '$Revision: 1.37 $';

# Version of module
$VERSION = 2.0;

use strict;

use CAIDA::Traffic2::FlowCounter;
use CAIDA::ASFinder;

use Benchmark;

my ($netgeo, $as_finder);
my $route_table = "routes.txt"; # Generic name, replace as necessary.

sub print_table {
    my ($table) = @_;
    while (my ($opaque_key, $value) = each %{ $table->data() }) {
	my @fields = $table->get_key_fields($opaque_key);
	print join("\t", @fields,
		   $value->pkts(), $value->bytes(), $value->flows()), "\n";
    }
}

sub print_table_full {
    my ($table) = @_;
    while (my ($opaque_key, $value) = each %{ $table->data() }) {
	my @fields = $table->get_key_fields($opaque_key);
	print join("    ", @fields,
		    $value->pkts(), $value->bytes(), $value->flows(),
		    $value->first(), $value->latest()), "\n";
    }
}

sub test_IP_Table () {
    require CAIDA::Tables::IP_Table;
    my $ip_table = new CAIDA::Tables::IP_Table;
    my $counts = new CAIDA::Traffic2::FlowCounter;
    $counts->pkts(1);
    $counts->bytes(100);
    $counts->flows(1);
   
    $ip_table->entry_add("255.255.255.255", $counts);

    foreach my $i (1..10) {
	$ip_table->entry_add("192.$i.1.1", $counts);
	$ip_table->entry_add("192.$i.1.1", $counts);
    }

    print "IP_Table data:\n";
    print_table($ip_table);

    if (not defined $as_finder) {
	$as_finder = new CAIDA::ASFinder;
	$as_finder->load_file_text($route_table);
    }
    my $as_table = $ip_table->make_AS_Table({"as_finder" => $as_finder});
    print "aggregated AS_Table data:\n";
    print_table($as_table);

    if (not defined $netgeo) {
	require CAIDA::NetGeoClient;
	$netgeo = new CAIDA::NetGeoClient;
    }
    my $country_table = $ip_table->make_Country_Table(
					{"as_finder" => $as_finder,
					 "netgeo" => $netgeo});
    print "aggregated Country_Table data:\n";
    print_table($country_table);
}

sub test_IP_Matrix () {
    require CAIDA::Tables::IP_Matrix;
    my $ip_matrix = new CAIDA::Tables::IP_Matrix;
    my $counts = new CAIDA::Traffic2::FlowCounter;
    $counts->pkts(1);
    $counts->bytes(100);
    $counts->flows(1);
   
    $ip_matrix->entry_add("255.255.255.255", "0.0.0.0", $counts);

    foreach my $i (1..10) {
	$ip_matrix->entry_add("192.$i.1.1", "208.$i.1.1", $counts);
	$ip_matrix->entry_add("192.$i.1.1", "208.$i.1.1", $counts);
    }

    print "IP_Matrix data:\n";
    print_table($ip_matrix);

    my @top = $ip_matrix->sort_by_keys(5, 1);
    print "First 5 keys (sorted):\n";
    foreach my $val (@top) {
	print join(" ", $ip_matrix->get_key_fields($val)), "\n";
    }

    my $src_ip_table = $ip_matrix->make_src_IP_Table();
    print "aggregated src IP_Table data:\n";
    print_table($src_ip_table);

    my $dst_ip_table = $ip_matrix->make_dst_IP_Table();
    print "aggregated dst IP_Table data:\n";
    print_table($dst_ip_table);

    if (not defined $as_finder) {
	$as_finder = new CAIDA::ASFinder;
	$as_finder->load_file_text($route_table);
    }
    my $as_matrix = $ip_matrix->make_AS_Matrix({"as_finder" => $as_finder});
    print "aggregated AS_Matrix data:\n";
    print_table($as_matrix);

    if (not defined $netgeo) {
	require CAIDA::NetGeoClient;
	$netgeo = new CAIDA::NetGeoClient;
    }
    my $country_matrix = $ip_matrix->make_Country_Matrix(
					{"as_finder" => $as_finder,
					 "netgeo" => $netgeo});

    print "aggregated Country_Matrix data:\n";
    print_table($country_matrix);

    my $country_table = $ip_matrix->make_src_Country_Table(
					{"as_finder" => $as_finder,
					 "netgeo" => $netgeo});

    print "aggregated src Country_Table data:\n";
    print_table($country_table);

    $country_table = $ip_matrix->make_dst_Country_Table(
					{"as_finder" => $as_finder,
					 "netgeo" => $netgeo});

    print "aggregated dst Country_Table data:\n";
    print_table($country_table);
}

sub test_Proto_Table () {
    require CAIDA::Tables::Proto_Table;
    my $proto_table = new CAIDA::Tables::Proto_Table();
    my $counts = new CAIDA::Traffic2::FlowCounter();
    $counts->pkts(1);
    $counts->bytes(100);
    $counts->flows(1);
    
    $proto_table->entry_add(24, $counts);

    foreach my $i (1..10) {
	$proto_table->entry_add($i, $counts);
	$proto_table->entry_add($i, $counts);
    }
    print "Proto_Table data:\n";
    print_table($proto_table);
}

sub test_Proto_Ports_Table () {
    require CAIDA::Tables::Proto_Ports_Table;
    my $proto_ports_table = new CAIDA::Tables::Proto_Ports_Table(undef, {'table_size' => 100});
    my $counts = new CAIDA::Traffic2::FlowCounter();
    $counts->pkts(1);
    $counts->bytes(100);
    $counts->flows(1);

    $proto_ports_table->entry_add(17, 1, 7070, 7070, $counts);

    foreach my $i (1..10) {
	$proto_ports_table->entry_add(6, 1, $i, $i*2, $counts);
	$proto_ports_table->entry_add(6, 1, $i, $i*2, $counts);
	$proto_ports_table->entry_add(6, 1, 42, 42, $counts);
    }

    print "Proto_Ports_Table data:\n";
    print_table($proto_ports_table);

    my $proto_table = $proto_ports_table->make_Proto_Table();
    print "aggregated Proto_Table data:\n";
    print_table($proto_table);

    my $port_matrix = $proto_ports_table->make_Port_Matrix();
    print "aggregated Port_Matrix data:\n";
    print_table($port_matrix);

    my $src_proto_port_table = $proto_ports_table->make_src_Proto_Port_Table();
    print "aggregated src Proto_Port_Table data:\n";
    print_table($src_proto_port_table);

    my $dst_proto_port_table = $proto_ports_table->make_dst_Proto_Port_Table();
    print "aggregated dst Proto_Port_Table data:\n";
    print_table($dst_proto_port_table);

}

sub test_Proto_Port_Table () {
    require CAIDA::Tables::Proto_Port_Table;
    my $proto_port_table = new CAIDA::Tables::Proto_Port_Table(undef, {'table_size' => 100});
    my $counts = new CAIDA::Traffic2::FlowCounter();
    $counts->pkts(1);
    $counts->bytes(100);
    $counts->flows(1);

    $proto_port_table->entry_add(17, 1, 7070, $counts);

    foreach my $i (1..10) {
	$proto_port_table->entry_add(6, 1, $i, $counts);
	$proto_port_table->entry_add(6, 1, $i, $counts);
	$proto_port_table->entry_add(6, 1, 42, $counts);
    }

    print "Proto_Port_Table data:\n";
    print_table($proto_port_table);

    my $proto_table = $proto_port_table->make_Proto_Table();
    print "aggregated Proto_Table data:\n";
    print_table($proto_table);

    my $port_table = $proto_port_table->make_Port_Table();
    print "aggregated Port_Table data:\n";
    print_table($port_table);
}

sub test_Port_Matrix () {
    require CAIDA::Tables::Port_Matrix;
    my $port_matrix = new CAIDA::Tables::Port_Matrix;
    my $counts = new CAIDA::Traffic2::FlowCounter();
    $counts->pkts(1);
    $counts->bytes(100);
    $counts->flows(1);

    $port_matrix->entry_add(7070, 80, $counts);

    foreach my $i (1..10) {
	$port_matrix->entry_add($i, $i*2, $counts);
	$port_matrix->entry_add($i, $i*2, $counts);
	$port_matrix->entry_add(42, 42, $counts);
    }

    print "Port_Matrix data:\n";
    print_table($port_matrix);

    my $src_port_table = $port_matrix->make_src_Port_Table();
    print "aggregated src Port_Table data:\n";
    print_table($src_port_table);

    my $dst_port_table = $port_matrix->make_dst_Port_Table();
    print "aggregated dst Port_Table data:\n";
    print_table($dst_port_table);
}

sub test_Port_Table () {
    require CAIDA::Tables::Port_Table;
    my $port_table = new CAIDA::Tables::Port_Table;
    my $counts = new CAIDA::Traffic2::FlowCounter();
    $counts->pkts(1);
    $counts->bytes(100);
    $counts->flows(1);

    $port_table->entry_add(80, $counts);

    foreach my $i (1..10) {
	$port_table->entry_add($i, $counts);
	$port_table->entry_add($i, $counts);
	$port_table->entry_add(42, $counts);
    }

    print "Port_Table data:\n";
    print_table($port_table);
}

sub test_AS_Table () {
    require CAIDA::Tables::AS_Table;
    my $as_table = new CAIDA::Tables::AS_Table();
    my $counts = new CAIDA::Traffic2::FlowCounter();
    $counts->pkts(1);
    $counts->bytes(100);
    $counts->flows(1);
    
    $as_table->entry_add("NOROUTE", $counts);
    $as_table->entry_add("MCAST", $counts);
    $as_table->entry_add("{34,2,521}", $counts);
    $as_table->entry_add("{20,51}", $counts);

    foreach my $i (1..10) {
	$as_table->entry_add(100*$i, $counts);
	$as_table->entry_add(100*$i, $counts);
    }

    print "AS_Table data:\n";
    print_table($as_table);

    my @top = $as_table->sort_by_keys(5, 1);
    print "First 5 keys (sorted):\n";
    foreach my $val (@top) {
	print join(" ", $as_table->get_key_fields($val)), "\n";
    }

    if (not defined $netgeo) {
	require CAIDA::NetGeoClient;
	$netgeo = new CAIDA::NetGeoClient;
    }
    my $country_table = $as_table->make_Country_Table({'netgeo' => $netgeo});

    print "aggregated Country_Table data:\n";
    print_table($country_table);
}

sub test_AS_Matrix () {
    require CAIDA::Tables::AS_Matrix;
    my $as_matrix = new CAIDA::Tables::AS_Matrix();
    my $counts = new CAIDA::Traffic2::FlowCounter();
    $counts->pkts(1);
    $counts->bytes(100);
    $counts->flows(1);
    
    $as_matrix->entry_add("NOROUTE", "NOROUTE", $counts);
    $as_matrix->entry_add("{34,2,521}", "MCAST", $counts);
    $as_matrix->entry_add("300", "{20,51}", $counts);

    foreach my $i (1..10) {
	$as_matrix->entry_add(100*$i, 15*$i, $counts);
	$as_matrix->entry_add(100*$i, 200 - 15*$i, $counts);
    }

    print "AS_Matrix data:\n";
    print_table($as_matrix);

    my @top = $as_matrix->sort_by_keys(5, 1);
    print "First 5 keys (sorted):\n";
    foreach my $val (@top) {
	print join(" ", $as_matrix->get_key_fields($val)), "\n";
    }

    my $src_as_table = $as_matrix->make_src_AS_Table();
    print "aggregated src AS_Table data:\n";
    print_table($src_as_table);

    my $dst_as_table = $as_matrix->make_dst_AS_Table();
    print "aggregated dst AS_Table data:\n";
    print_table($dst_as_table);

    if (not defined $netgeo) {
	require CAIDA::NetGeoClient;
	$netgeo = new CAIDA::NetGeoClient;
    }
    my $country_matrix = $as_matrix->make_Country_Matrix({'netgeo' => $netgeo});

    print "aggregated Country_Matrix data:\n";
    print_table($country_matrix);

    my $country_table = $as_matrix->make_src_Country_Table(
					{"netgeo" => $netgeo});

    print "aggregated src Country_Table data:\n";
    print_table($country_table);

    $country_table = $as_matrix->make_dst_Country_Table(
					{"netgeo" => $netgeo});

    print "aggregated dst Country_Table data:\n";
    print_table($country_table);
}

sub test_Country_Table () {
    require CAIDA::Tables::Country_Table;
    my $country_table = new CAIDA::Tables::Country_Table();
    my $counts = new CAIDA::Traffic2::FlowCounter();
    $counts->pkts(1);
    $counts->bytes(100);
    $counts->flows(1);
   
    $country_table->entry_add("US", $counts);

    foreach my $i ("TW", "CA", "JP", "NZ", "DE") {
	$country_table->entry_add($i, $counts);
	$country_table->entry_add($i, $counts);
    }

    print "Country_Table data:\n";
    print_table($country_table);
}

sub test_Country_Matrix () {
    require CAIDA::Tables::Country_Matrix;
    my $country_matrix = new CAIDA::Tables::Country_Matrix();
    my $counts = new CAIDA::Traffic2::FlowCounter();
    $counts->pkts(1);
    $counts->bytes(100);
    $counts->flows(1);
   
    $country_matrix->entry_add("US", "JP", $counts);

    foreach my $i ("TW", "CA", "JP", "NZ", "DE") {
	$country_matrix->entry_add($i, $i, $counts);
	$country_matrix->entry_add($i, $i, $counts);
    }

    print "Country_Matrix data:\n";
    print_table($country_matrix);

    my $country_table = $country_matrix->make_src_Country_Table();

    print "aggregated src Country_Table data:\n";
    print_table($country_table);

    $country_table = $country_matrix->make_dst_Country_Table();

    print "aggregated dst Country_Table data:\n";
    print_table($country_table);
}

sub test_App_Table () {
    require CAIDA::Tables::App_Table;
    my $app_table = new CAIDA::Tables::App_Table();
    my $counts = new CAIDA::Traffic2::FlowCounter();
    $counts->pkts(1);
    $counts->bytes(100);
    $counts->flows(1);
   
    $app_table->entry_add("FTP", $counts);

    foreach my $i ("Half-life", "StarCraft", "Quake 3 Arena", "Homeworld") {
	$app_table->entry_add("$i", $counts);
	$app_table->entry_add("$i", $counts);
    }

    print "App_Table data:\n";
    print_table($app_table);
}

sub test_AppInfo_Table () {
    require CAIDA::Tables::AppInfo_Table;
    my $table = new CAIDA::Tables::AppInfo_Table();
    my $counts = new CAIDA::Traffic2::FlowCounter();
    $counts->pkts(1);
    $counts->bytes(100);
    $counts->flows(1);
   
    $table->entry_add("File Transfer Protocol", "FTP", "NETWORK", "rkoga",
		"2000-01-01", "none", "Foo corp", "http://foo.com", $counts);

    my $count2 = $table->entry_get("", "FTP", "", "", "", "", "", "");
    print join("\t", "For FTP:",
	       $count2->pkts(), $count2->bytes(), $count2->flows()), "\n";

    print "AppInfo_Table data:\n";
    print_table($table);
}

sub test_Length_Table () {
    require CAIDA::Tables::Length_Table;
    my $length_table = new CAIDA::Tables::Length_Table();
    my $counts = new CAIDA::Traffic2::FlowCounter();
    $counts->pkts(1);
    $counts->bytes(100);
    $counts->flows(1);
   
    $length_table->entry_add(40, $counts);

    foreach my $i (1500, 40, 1480) {
	$length_table->entry_add($i, $counts);
	$length_table->entry_add($i, $counts);
    }

    print "Length_Table data:\n";
    print_table($length_table);
}

sub test_VPVC_Table () {
    require CAIDA::Tables::VPVC_Table;
    my $vpvc_table = new CAIDA::Tables::VPVC_Table();
    my $counts = new CAIDA::Traffic2::FlowCounter();
    $counts->pkts(1);
    $counts->bytes(100);
    $counts->flows(1);
   
    $vpvc_table->entry_add("1:234", $counts);

    foreach my $i (1..10) {
	$vpvc_table->entry_add("0:$i", $counts);
	$vpvc_table->entry_add("0:$i", $counts);
    }

    print "VPVC_Table data:\n";
    print_table($vpvc_table);
}

sub test_Tuple_Table () {
    require CAIDA::Tables::Tuple_Table;
    my $tuple_table = new CAIDA::Tables::Tuple_Table(undef, {'table_size' => 100});
    my $counts = new CAIDA::Traffic2::FlowCounter(5, 100, 1);

    $tuple_table->entry_add("208.178.101.40", "204.174.18.129",
			    17, 1, 7070, 7070, $counts);
    my $count2 = $tuple_table->entry_get("208.178.101.40", "204.174.18.129",
                                17, 1, 7070, 7070);

    foreach my $i (1..10) {
	# For testing sort_by_* functions.

	my $other_counts = new CAIDA::Traffic2::FlowCounter(2*$i, 5*$i, 11-$i);
	$tuple_table->entry_add("199.$i.1.1", "208.$i.1.1", 6, 1, $i, $i*2,
							    $other_counts);
	$tuple_table->entry_add("199.$i.1.1", "208.$i.1.1", 6, 1, $i, $i*2,
							    $other_counts);
	$tuple_table->entry_add("192.$i.1.1", "208.$i.1.1", 6, 1, 42, 42,
							    $other_counts);
    }

    print "Tuple_Table data:\n";
    print "Number of entries: ", $tuple_table->num_entries(), "\n";
    print_table($tuple_table);

    my @top;
    @top = $tuple_table->sort_by_pkts(5);
    print "Top 5 pkts:\t";
    foreach my $val (@top) {
	print $tuple_table->data()->{$val}->pkts(), "\t";
    }
    print "\n";

    @top = $tuple_table->sort_by_counter_field('pkts', 5);
    print "Top 5 pkts (alternate method):\t";
    foreach my $val (@top) {
	print $tuple_table->data()->{$val}->pkts(), "\t";
    }
    print "\n";
    
    @top = $tuple_table->sort_by_bytes(5);
    print "Top 5 bytes:\t";
    foreach my $val (@top) {
	print $tuple_table->data()->{$val}->bytes(), "\t";
    }
    print "\n";

    @top = $tuple_table->sort_by_flows(5);
    print "Top 5 flows:\t";
    foreach my $val (@top) {
	print $tuple_table->data()->{$val}->flows(), "\t";
    }
    print "\n";

    @top = $tuple_table->sort_by_keys(5, 1);
    print "First 5 keys (sorted):\n";
    foreach my $val (@top) {
	print join(" ", $tuple_table->get_key_fields($val)), "\n";
    }

# Equivalent
#    my $src_ip_table = $tuple_table->aggregate_columns(0);
    my $src_ip_table = $tuple_table->make_src_IP_Table({"table_size" => 20});
    print "aggregated src IP_Table data:\n";
    print_table($src_ip_table);

    my $dst_ip_table = $tuple_table->make_dst_IP_Table({"table_size" => 5});
    print "aggregated dst IP_Table data:\n";
    print_table($dst_ip_table);

    my $proto_table = $tuple_table->make_Proto_Table();
    print "aggregated Proto_Table data:\n";
    print_table($proto_table);

    my $proto_ports_table = $tuple_table->make_Proto_Ports_Table();
    print "aggregated Proto_Ports_Table data:\n";
    print_table($proto_ports_table);

    my $src_proto_port_table = $tuple_table->make_src_Proto_Port_Table();
    print "aggregated src Proto_Port_Table data:\n";
    print_table($src_proto_port_table);

    my $dst_proto_port_table = $tuple_table->make_dst_Proto_Port_Table();
    print "aggregated dst Proto_Port_Table data:\n";
    print_table($dst_proto_port_table);

    my $ip_matrix = $tuple_table->make_IP_Matrix();
    print "aggregated IP_Matrix data:\n";
    print_table($ip_matrix);

    if (not defined $as_finder) {
	$as_finder = new CAIDA::ASFinder;
	$as_finder->load_file_text($route_table);
    }
    my $as_matrix = $tuple_table->make_AS_Matrix({"as_finder" => $as_finder});
    print "aggregated AS_Matrix data:\n";
    print_table($as_matrix);

    if (not defined $netgeo) {
	require CAIDA::NetGeoClient;
	$netgeo = new CAIDA::NetGeoClient;
    }
    my $country_matrix = $tuple_table->make_Country_Matrix(
					{"as_finder" => $as_finder,
					 "netgeo" => $netgeo});
    print "aggregated Country_Matrix data:\n";
    print_table($country_matrix);

    my $country_table = $tuple_table->make_src_Country_Table(
					{"as_finder" => $as_finder,
					 "netgeo" => $netgeo});

    print "aggregated src Country_Table data:\n";
    print_table($country_table);

    $country_table = $tuple_table->make_dst_Country_Table(
					{"as_finder" => $as_finder,
					 "netgeo" => $netgeo});

    print "aggregated dst Country_Table data:\n";
    print_table($country_table);

    my $port_matrix = $tuple_table->make_Port_Matrix({"protocol" => 17});
    print "aggregated Port_Matrix data:\n";
    print_table($port_matrix);

    my $src_port_table = $tuple_table->make_src_Port_Table({"protocol" => 6});
    print "aggregated src Port_Table data:\n";
    print_table($src_port_table);

    my $dst_port_table = $tuple_table->make_dst_Port_Table();
    print "aggregated dst Port_Table data:\n";
    print_table($dst_port_table);

    my $agg_table = $tuple_table->aggregate_columns(2, 0);
    print "aggregate_columns data:\n";
    print_table($agg_table);

    print "Total data for Tuple_Table and associated (should be identical):\n";
    foreach my $table ($tuple_table, $src_ip_table, $dst_ip_table,
			$proto_table, $proto_ports_table, $ip_matrix,
			$as_matrix, $country_matrix, $country_table, $agg_table)
    {
	my $total = $table->total();
	print join("\t",
		   $total->pkts(), $total->bytes(), $total->flows()), "\n";
    }


    $src_ip_table->add($dst_ip_table);
    print "src IP_Table data added to dst IP_Table:\n";
    print_table($src_ip_table);

    $src_ip_table->clear();
    print "Number of entries in src IP_Table after clearing (should be 0): ",
		$src_ip_table->num_entries(), "\n";

    my $total = $src_ip_table->total();
    print "Total data for src IP_Table after clearing (should be empty): ",
	    join("\t", $total->pkts(), $total->bytes(), $total->flows()), "\n";
}


sub test_load_save (;$) {
    my ($full_count) = @_;
    $full_count = 1 if not defined $full_count;
    require CAIDA::Tables::Tuple_Table;
    my $tuple_table = new CAIDA::Tables::Tuple_Table;
    my $loaded_text = new CAIDA::Tables::Tuple_Table;
    my $loaded_bin = new CAIDA::Tables::Tuple_Table;
    my $counts = new CAIDA::Traffic2::FlowCounter(5, 123, 1, 10, 20);

    foreach my $i (1..10) {
	$tuple_table->entry_add("10.10.10.10", "20.20.20.20", 6, 1, $i, $i*2,
							    $counts);
	$tuple_table->entry_add("10.10.10.10", "20.20.20.20", 6, 1, $i, $i*2,
							    $counts);
	$tuple_table->entry_add("15.15.15.$i", "25.25.25.25", 6, 1, 42, 42,
							    $counts);
    }
    print "Original Tuple_Table data:\n";
    print "Number of entries: ", $tuple_table->num_entries(), "\n";
    print_table_full($tuple_table);

    my $filename;

    $filename = "output.dump";
    print "Dumping table to $filename\n";
    $tuple_table->save_text($filename, $full_count);

    $loaded_text->load_text($filename);

    print "Text-loaded Tuple_Table data:\n";
    print "Number of entries: ", $loaded_text->num_entries(), "\n";
    if ($full_count) {
	print_table_full($loaded_text);
    } else {
	print_table($loaded_text);
    }

    $filename = "output.bin";
    print "Dumping binary table to $filename\n";
    $tuple_table->save_binary($filename, $full_count);

    my $last_line = $loaded_bin->load_binary($filename);

    print "Binary-loaded Tuple_Table data:\n";
    print "Number of entries: ", $loaded_bin->num_entries(), "\n";
    if ($full_count) {
	print_table_full($loaded_bin);
    } else {
	print_table($loaded_bin);
    }
}

sub test_str_load_save (;$) {
    my ($full_count) = @_;
    $full_count = 1 if not defined $full_count;
    require CAIDA::Tables::AS_Matrix;
    my $as_matrix = new CAIDA::Tables::AS_Matrix;
    my $counts = new CAIDA::Traffic2::FlowCounter(5, 100, 1, 10, 20);

    foreach my $i (1..10) {
	$as_matrix->entry_add("This is a string", "and goop", $counts);
	$as_matrix->entry_add("This has", "!@#^%&%^*() characters", $counts);
	$as_matrix->entry_add("1", "$i", $counts);
    }
    print "Original AS_Matrix data:\n";
    print "Number of entries: ", $as_matrix->num_entries(), "\n";
    if ($full_count) {
	print_table_full($as_matrix);
    } else {
	print_table($as_matrix);
    }

    my $filename = "str.dump";
    print "Dumping table to $filename\n";
    $as_matrix->save_text($filename, $full_count);

    my $loaded_text = new CAIDA::Tables::AS_Matrix;
    $loaded_text->load_text($filename);

    print "Text-loaded AS_Matrix data:\n";
    print "Number of entries: ", $loaded_text->num_entries(), "\n";
    if ($full_count) {
	print_table_full($loaded_text);
    } else {
	print_table($loaded_text);
    }

    $filename = "str.bin";
    print "Dumping binary table to $filename\n";
    $as_matrix->save_binary($filename, $full_count);

    my $loaded_bin = new CAIDA::Tables::AS_Matrix;
    my $last_line = $loaded_bin->load_binary($filename);

    print "Binary-loaded AS_Matrix data:\n";
    print "Number of entries: ", $loaded_bin->num_entries(), "\n";
    if ($full_count) {
	print_table_full($loaded_bin);
    } else {
	print_table($loaded_bin);
    }
}

sub test_load_speed () {
    require CAIDA::Tables::Tuple_Table;
    my $tuple_table = new CAIDA::Tables::Tuple_Table;
    my $loaded_table = new CAIDA::Tables::Tuple_Table;
    my $counts = new CAIDA::Traffic2::FlowCounter(5, 100, 1, 10, 20);

    foreach my $i (1..100000) {
	my $src = int(rand(255)+1) . "." . int(rand(255)+1) . "." .
		    int(rand(255)+1) . "." . int(rand(255)+1);
	my $dst = int(rand(255)+1) . "." . int(rand(255)+1) . "." .
		    int(rand(255)+1) . "." . int(rand(255)+1);
	$tuple_table->entry_add($src, $dst, 6, 1, $i, $i, $counts);
    }
    my ($filename, $code);

    $filename = "output.dump";
    print "Dumping table to $filename\n";
    $code = sub { $tuple_table->save_text($filename); };
    timethis(10, $code, 'Text saving: ');

    $filename = "output.bin";
    print "Dumping binary table to $filename\n";
    $code = sub { $tuple_table->save_binary($filename); };
    timethis(10, $code, 'Binary saving: ');

    undef $tuple_table; # We don't want memory use to bias the results.

    $filename = "output.dump";
    $code = sub { $loaded_table->load_text($filename); $loaded_table->clear()};
    timethis(10, $code, 'Text loading: ');

    $filename = "output.bin";
    $code = sub { $loaded_table->load_binary($filename); $loaded_table->clear()};
    timethis(10, $code, 'Binary loading: ');
}

sub test_memory {
    require CAIDA::Tables::Tuple_Table;
    my $table = new CAIDA::Tables::Tuple_Table;
    my $count = new CAIDA::Traffic2::FlowCounter(1,1,1);
    foreach my $i (1..1000000000) {
	$table->entry_add("1.1.1.1", "2.2.2.2", $i, $i, $i, $i, $count);
    }
}

# Uncomment to run tests.
#$CAIDA::Tables::FORCE_PERL = 1;	# note this dies in AppInfo lookups
#$CAIDA::Tables::FORCE_C = 1;  # note this dies on aggregate_columns
test_IP_Table();
test_IP_Matrix();
test_Port_Matrix();
test_Port_Table();
test_Proto_Table();
test_Proto_Ports_Table();
test_Proto_Port_Table();
test_AS_Table();
test_AS_Matrix();
test_Country_Table();
test_Country_Matrix();
test_App_Table();
test_AppInfo_Table();
test_Length_Table();
test_VPVC_Table();
test_Tuple_Table();
#test_load_save();
#test_load_save(0); # This doesn't use first/latest
#test_str_load_save();
#test_load_speed();
# Warning:  this test should not be run without some tight memory limits,
# as its purpose to attempt to exhaust available memory.
#test_memory();

# .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   . 
1; ##must be last line in the file
