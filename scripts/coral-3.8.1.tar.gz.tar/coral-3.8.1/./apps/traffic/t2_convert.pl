#!/usr/local/bin/perl -w
## 
## Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
## All Rights Reserved 
## 
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
## 
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
## 
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
## 
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
## 
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program. Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
## 
## Report bugs and suggestions to coral-bugs@caida.org.
## 

use strict;

use Getopt::Std;
use vars qw($opt_F $opt_t $opt_R $opt_P $opt_b $opt_N $opt_s);

my $coral_dir;
BEGIN { $coral_dir = "/usr/local/Coral"; } # This will be edited during build.
use lib "$coral_dir/lib"; #coral global libdir#
use lib "../../lib"; #coral local libdir#
use CAIDA::Traffic2::FileReader;
use CAIDA::Traffic2::FileWriter;
use CAIDA::ASFinder;
use CAIDA::NetGeoClient;
use CAIDA::AppPorts;

$| = 1;                 # don't buffer output

sub name_unknown_app {
    my ($proto, $ports_ok, $src_port, $dst_port) = @_;
    my $str;
    $str = "UNKNOWN_";
    if ($proto == 6) {
	$str = "NOPORTS_" unless $ports_ok;
	$str .= "TCP";
    } elsif ($proto == 17) {
	$str = "NOPORTS_" unless $ports_ok;
	$str .= "UDP";
    } elsif ($proto == 1) {
	$str .= "ICMP";
	$str .= "_($src_port,$dst_port)" if $ports_ok and $opt_s;
    } else {
	$str .= "PROTO_$proto";
    }
    return $str;
}

my ($pname) = $0 =~ m#([^/]+)$#;

if (!getopts("FtR:P:N:bs") or @ARGV < 1) {
    print STDERR "Usage: crl_flow {crl_flow_options} | ",
				"$pname {${pname}_options} to_table_kind(s) \n",
	    "   Or: $pname {${pname}_options} to_table_kind(s) < file.t2\n",
	    "${pname} options:\n",
	    "-t outputs timestamp information for each entry.\n",
	    "-F flattens the flows count to 1 for each entry in the\n",
	    "   converted table(s).\n",
	    "-R <route table> specifies an ASFinder compatible routing table\n",
	    "   to be used for AS aggregation.\n",
	    "-P <ports table> specifies an AppPorts compatible port table\n",
	    "   to be used for application aggregation.\n",
	    "-b outputs tables in binary format.\n",
	    "-s separate out unknown ICMP codes.\n",
	    "";
    exit 1;
}

if (not defined $opt_t) { $opt_t = 0; }

my $reader = new CAIDA::Traffic2::FileReader(*STDIN)
					    or die "Cannot understand input";

my %conversion_options;

$conversion_options{'netgeo'} = new CAIDA::NetGeoClient;
$conversion_options{'name_func'} = \&name_unknown_app;

if (defined $opt_R) {
    my $as_finder = new CAIDA::ASFinder;
    $as_finder->load_file_text($opt_R) or die "Error loading $opt_R";
    $conversion_options{'as_finder'} = $as_finder;
}

if (defined $opt_N) { # XXX netacq is a CAIDA-only tool
    $conversion_options{'netacq'} = $opt_N;
}

my $ports_file;
# For local use
if (-e "../../etc/Application_ports_Master.txt") {
    $ports_file = "../../etc/Application_ports_Master.txt";
} else {
    $ports_file = "$coral_dir/etc/Application_ports_Master.txt";
}

$ports_file = $opt_P if defined $opt_P;

my $app_ports = new CAIDA::AppPorts;
$app_ports->load_rules($ports_file) or die "Can't load $ports_file";
$conversion_options{'app_ports'} = $app_ports;

$reader->set_conversion_options(\%conversion_options);

my $writer = new CAIDA::Traffic2::FileWriter(*STDOUT, $opt_b);

$reader->set_desired_table_types(@ARGV);
while (my $interval = $reader->get_next_interval()) {
    $writer->initialize($interval, @ARGV);
    $writer->dump_interval_start();
    foreach my $id_info ($interval->get_id_infos()) {
	foreach my $kind ($id_info->get_table_types()) {
	    my $table = $interval->get_table($id_info, $kind);
	    if (not $table) {
		print STDERR "Couldn't get $kind for ",
			    $id_info->get_metadata('id'), "\n";
		next;
	    }
	    if ($opt_F) {
		# Flatten the flows field to 1 before aggregating.
		my $data = $table->data();
		while (my ($opaque_key, $counter) = each %{ $data }) {
		    $counter->flows(1);
		}
	    }
	    $writer->dump_interval_table($id_info, $kind, $table, $opt_t);
	}
    }
    $writer->dump_interval_end();
}
