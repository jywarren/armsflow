/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/* $Id: options.h,v 1.16 2007/06/06 18:17:45 kkeys Exp $ */

#ifndef OPTIONS_H
#define OPTIONS_H

#define OPT_UNKNOWN 0
#define OPT_ip_v 1
#define OPT_ip_hl 2
#define OPT_ip_tos 3
#define OPT_ip_len 4
#define OPT_ip_id 5
#define OPT_ip_off 6
#define OPT_ip_df 7
#define OPT_ip_mf 8
#define OPT_ip_offset 9
#define OPT_ip_frag 10
#define OPT_ip_ttl 11
#define OPT_ip_p 12
#define OPT_ip_sum 13
#define OPT_ip_src 14
#define OPT_ip_dst 15
#define OPT_ihl 16

#define OPT_th_sport 17
#define OPT_th_dport 18
#define OPT_th_seq 19
#define OPT_th_ack 20
#define OPT_th_off 21
#define OPT_th_x2 22
#define OPT_th_flags 23
#define OPT_th_win 24
#define OPT_th_sum 25
#define OPT_th_urp 26
#define OPT_fin 28
#define OPT_syn 29
#define OPT_rst 30
#define OPT_psh 31
#define OPT_ack 32
#define OPT_urg 33

#define OPT_uh_sport 34
#define OPT_uh_dport 35
#define OPT_uh_ulen 36
#define OPT_uh_sum 37

#define OPT_llc_dsap 38
#define OPT_llc_ssap 39
#define OPT_llc_cntl 40
#define OPT_snap_org 41
#define OPT_snap_org1 42
#define OPT_snap_org2 43
#define OPT_snap_org3 44
#define OPT_snap_type 45

#define OPT_igmp_type 46
#define OPT_igmp_code 47
#define OPT_igmp_cksum 48
#define OPT_igmp_group 49

#define OPT_ip_src_dotted 50
#define OPT_ip_dst_dotted 51

#define OPT_interface 52
#define OPT_blk_size 53
#define OPT_cell_count 54
#define OPT_cells_lost 55
#define OPT_unknown_vpi_vci 56
#define OPT_tbegin_sec 57
#define OPT_tbegin_nsec 58
#define OPT_tend_sec 59
#define OPT_tend_nsec 60

#define OPT_gfc 61
#define OPT_vp 62
#define OPT_vc 63
#define OPT_oam_rm 64
#define OPT_congestion 65
#define OPT_sdu_type 66
#define OPT_clp 67

#define OPT_icmp_type 68
#define OPT_icmp_code 69
#define OPT_icmp_cksum 70

#endif
