/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

#ifndef CORAL_IOCTL_CONST_H
#define CORAL_IOCTL_CONST_H

/* capture modes */
#define CORAL_TX		0x00000001ul
#define CORAL_RX		0x00000002ul
#define CORAL_RX_IDLE		0x00000004ul	/* get all cells, including 
						 * atm idle cells */
#define CORAL_RX_OAM		0x00000008ul	/* get oam/rm cells */
#define CORAL_RX_LAST		0x00000010ul	/* get last cell of each PDU */
#define CORAL_RX_USER_ALL	0x00000020ul	/* get all cells of each PDU */
#define CORAL_RX_ECHO		0x00000040ul	/* copy rx to tx */
#define CORAL_RX_SCRAMBLE	0x00000080ul	/* POS scrambling - obsolete */
#define CORAL_RX_VARLEN		0x00000100ul	/* variable length records */

#define CORAL_RX_UNKNOWN	0x80000000ul	/* unknown (e.g., trace doesn't
						 * say what mode was used) */

/* capture modes supported by hardware */
/* This doesn't belong here */
#define CORAL_FATM_MODES	(CORAL_RX | CORAL_TX | CORAL_RX_ECHO)
#define CORAL_POINT_MODES	(CORAL_RX | CORAL_RX_IDLE | CORAL_RX_OAM | \
				CORAL_RX_LAST | CORAL_RX_USER_ALL | \
				CORAL_RX_ECHO)

/* Definitions for ocN link speeds.  Use these numbers exactly, so that anyone
 * can test for them explicitly.  These are the B-ICI user information bit
 * rates, excluding the physical layer (SONET) related OAM information
 * transported in overhead bytes.
 * The "c" suffix in "OCNc" means "concatenated", meaning the N STS-1 channels
 * are used as a single fat pipe, rather than as a collection of small pipes.
 * This suffix is often omitted out of sloppiness in the ATM world.
 * Note that here, as in all low level communcations contexts, "K" means 10^3,
 * not 2^10; and "M" means 10^6, not 2^20.
 * See also: ATM Forum technical specifications at
 * http://www.atmforum.com/atmforum/specs/specs.html
 */
			/* data rate */	/* line rate */
#define KBPS_OC3c	  149760	/*   155520 */
#define KBPS_OC12c	  599040	/*   622080 */
#define KBPS_OC48c	 2396160	/*  2488320 */
/* #define KBPS_OC192c	 9584640    */	/*  9953280 */
/* #define KBPS_OC768c	38338560    */	/* 39813120 */
#define KBPS_ETH10M	     /* ??? */        10000
#define KBPS_ETH100M	     /* ??? */       100000
#define KBPS_ETH1000M	     /* ??? */      1000000

/* non coral driver types (all <= 1) */
/* Note: libcoral defines extended types with negative numbers */
#define CORAL_TYPE_NONE		0
#define CORAL_TYPE_FILE		1
/* coral driver types (all >= 2) */
#define CORAL_TYPE_FATM		2
#define CORAL_TYPE_POINT	3
#define CORAL_TYPE_DAG		4

#define coral_type_is_driver(type)	(type > CORAL_TYPE_FILE)

#endif /* CORAL_IOCTL_CONST_H */
