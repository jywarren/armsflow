//===========================================================================
//  $Name: release-3-8-1 $
//  $Id: Ipv4Network.hh,v 1.10 2004/06/24 19:09:07 kkeys Exp $
//
//  Daniel W. McRobb
//  CAIDA
//  December 1998
//===========================================================================

#ifndef _IPV4NETWORK_HH_
#define _IPV4NETWORK_HH_

extern "C" {
#include "caida_t.h"
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
}

#include <iostream>
#include "ipv4addr.hh"

//----------------------------------------------------------------------------
//                            class Ipv4Network                            
//----------------------------------------------------------------------------
//!  This class encapsulates an IPv4 network address.  It's really
//!  nothing more than a struct (not the data members are public) with
//!  some constructors and overloaded operators, plus a Matches() member
//!  for testing whether or not a host IP address in inside the
//!  Ipv4Network (where 'inside' means the network portion of the host IP
//!  address matches the Ipv4Network).
//----------------------------------------------------------------------------
class Ipv4Network 
{
public:
  typedef ipv4addr_t ipaddr_type;
  static const int family = ipaddr_type::family;
  ipaddr_type  net;
  uint8_t      maskLen;

  //--------------------------------------------------------------------------
  //                              Ipv4Network()                              
  //..........................................................................
  //!  constructor
  //--------------------------------------------------------------------------
  Ipv4Network()
  {
    this->net     = 0;
    this->maskLen = 32;
  }

  //--------------------------------------------------------------------------
  //               Ipv4Network(const Ipv4Network & ipv4Network) 
  //..........................................................................
  //!  copy constructor
  //--------------------------------------------------------------------------
  Ipv4Network(const Ipv4Network & ipv4Network)
  {
    this->net     = ipv4Network.net;
    this->maskLen = ipv4Network.maskLen;
  }

  //--------------------------------------------------------------------------
  //           Ipv4Network(ipv4addr_t network, uint8_t masklength)           
  //..........................................................................
  //!  Constructor that accepts netaork address and masklength as
  //!  parameters.  'network' must be in network byte order.  It may be
  //!  a host or network address; in either case the constructed object
  //!  will have a network address of (network & netmask), where netmask
  //!  is determined by the masklength.
  //--------------------------------------------------------------------------
  Ipv4Network(ipv4addr_t network, uint8_t masklength)
      : maskLen(masklength)
  {
    ipv4addr_t  netmask = 0xffffffff;

    if (masklength != 32) {
      if (masklength == 0) {
        netmask = 0;
      }
      else {
        netmask = htonl(0xffffffff << (32 - masklength));
      }
    }

    this->net = network & netmask;
  }

  //--------------------------------------------------------------------------
  //            Ipv4Network & operator = (const Ipv4Network & key)           
  //..........................................................................
  //!  Overloaded = operator.  Deep-copies one Ipv4Network object to
  //!  another Ipv4Network.
  //--------------------------------------------------------------------------
  Ipv4Network & operator = (const Ipv4Network & key)
  {
    this->net     = key.net;
    this->maskLen = key.maskLen;
    return(*this);
  }

  //--------------------------------------------------------------------------
  //       bool operator == (const Ipv4Network & key) const 
  //..........................................................................
  //!  == operator.  Returns true if *this is exactly equal to key
  //!  (both net and maskLen match exactly).  Else returns false.
  //--------------------------------------------------------------------------
  bool operator == (const Ipv4Network & key) const
  {
    return(this->net == key.net && this->maskLen == key.maskLen);
  }

  //--------------------------------------------------------------------------
  //             bool operator < (const Ipv4Network & key) const             
  //..........................................................................
  //!  Overloaded < operator.  If the LHS network address is less than
  //!  the RHS network address, or the network addresses are equal but
  //!  the LHS network mask length is less than the RHS network mask
  //!  length, we return true.  Else we return false.  This permits
  //!  semi-standard ordering of objects by network address.
  //--------------------------------------------------------------------------
  bool operator < (const Ipv4Network & key) const
  {
    return((this->net < key.net) ||
           ((this->net == key.net) && (this->maskLen < key.maskLen)));
  }

  //--------------------------------------------------------------------------
  //                 bool Matches(ipv4addr_t ipv4addr) const                 
  //..........................................................................
  //!  Given an IP address, return true if it falls within the Ipv4Network.
  //!  Else return false.
  //--------------------------------------------------------------------------
  bool Matches(ipv4addr_t ipv4addr) const
  {
    if (this->maskLen == 0) return true;
    ipv4addr_t netmask = htonl(0xffffffff << (32 - this->maskLen));
    return((ipv4addr & netmask) == this->net);
  }

  //--------------------------------------------------------------------------
  //        friend std::ostream & operator << (std::ostream & os,               
  //                                      const Ipv4Network & ipv4net)  
  //..........................................................................
  //!  Overloaded << operator.  Prints an Ipv4Network to an ostream and
  //!  returns a reference to the ostream.
  //--------------------------------------------------------------------------
  friend std::ostream & operator << (std::ostream & os,
                                const Ipv4Network & ipv4net)
  {
    os << ipv4net.net << "/" << (int)ipv4net.maskLen;
    return(os);
  }

// These had to be fixed a little when I changed ipv4addr_t from a uint32_t
// to a proper class, and while I was at it I made them much more compact,
// but I haven't tested them.  I don't think they are used anywhere anyway.
// But I left the code here in case they are needed. -kkeys
#if 0
  //--------------------------------------------------------------------------
  //                       std::istream & read(istream & is)
  //..........................................................................
  //!  Reads an Ipv4Network from an istream.  Returns the istream.
  //--------------------------------------------------------------------------
  std::istream & read(std::istream & is)
  {
    is.read(&this->maskLen,sizeof(this->maskLen));
    uint8_t  netSize = (this->maskLen + 7) / 8;
    uint8_t *p = static_cast<uint8_t*>(&this->net);
    memset(p, 0, 4);
    switch (netSize) {
	case 4: is.read(p++,sizeof(uint8_t)); // fall through
	case 3: is.read(p++,sizeof(uint8_t)); // fall through
	case 2: is.read(p++,sizeof(uint8_t)); // fall through
	case 1: is.read(p++,sizeof(uint8_t));
    }
    return(is);
  }

  //--------------------------------------------------------------------------
  //                             int read(int fd) 
  //..........................................................................
  //!  Reads an Ipv4Network from a file descriptor.  Returns the number of
  //!  bytes read on success, -1 on failure.
  //--------------------------------------------------------------------------
  int read(int fd)
  {
    int   rc;
    int   bytesRead = 0;

    rc = ::read(fd,&this->maskLen,sizeof(this->maskLen));
    if (rc < (int)sizeof(this->maskLen))
      return(-1);
    bytesRead += rc;

    uint8_t  netSize = (this->maskLen + 7) / 8;
    uint8_t *p = static_cast<uint8_t*>(&this->net);
    memset(p, 0, 4);

    switch (netSize) {
      case 4:
        rc = ::read(fd,p++,sizeof(uint8_t));
        if (rc < (int)sizeof(uint8_t)) return(-1);
        bytesRead += rc;
	// fall through
      case 3:
        rc = ::read(fd,p++,sizeof(uint8_t));
        if (rc < (int)sizeof(uint8_t)) return(-1);
        bytesRead += rc;
	// fall through
      case 2:
        rc = ::read(fd,p++,sizeof(uint8_t));
        if (rc < (int)sizeof(uint8_t)) return(-1);
        bytesRead += rc;
	// fall through
      case 1:
        rc = ::read(fd,p++,sizeof(uint8_t));
        if (rc < (int)sizeof(uint8_t)) return(-1);
        bytesRead += rc;
    }
    return(bytesRead);
  }


  //--------------------------------------------------------------------------
  //                   std::ostream & write(std::ostream & os) const
  //..........................................................................
  //!  Writes an Ipv4Network to an ostream.  Returns the ostream.
  //--------------------------------------------------------------------------
  std::ostream & write(std::ostream & os) const
  {
    //  first we write the netmask length
    os.write(&this->maskLen,sizeof(this->maskLen));

    uint8_t  netSize = (this->maskLen + 7) / 8;
    uint8_t *p = static_cast<uint8_t*>(&this->net);

    // and then write the network prefix
    switch (netSize) {
        case 4: os.write(p++,sizeof(uint8_t)); // fall through
        case 3: os.write(p++,sizeof(uint8_t)); // fall through
        case 2: os.write(p++,sizeof(uint8_t)); // fall through
        case 1: os.write(p++,sizeof(uint8_t));
    }
    return(os);
  }

  //--------------------------------------------------------------------------
  //                         int write(int fd) const 
  //..........................................................................
  //!  Writes an Ipv4Network to a file descriptor.  Returns the number
  //!  of bytes written on success, -1 on failure.
  //--------------------------------------------------------------------------
  int write(int fd) const
  {
    int   rc;
    int   bytesWritten = 0;

    rc = ::write(fd,&this->maskLen,sizeof(this->maskLen));
    if (rc < (int)sizeof(this->maskLen)) return(-1);
    bytesWritten += rc;

    uint8_t  netSize = (this->maskLen + 7) / 8;
    uint8_t *p = static_cast<uint8_t*>(&this->net);

    switch (netSize) {
      case 4:
        rc = ::write(fd,p++,sizeof(uint8_t));
        if (rc < (int)sizeof(uint8_t)) return(-1);
        bytesWritten += rc;
	// fall through
      case 3:
        rc = ::write(fd,p++,sizeof(uint8_t));
        if (rc < (int)sizeof(uint8_t)) return(-1);
        bytesWritten += rc;
	// fall through
      case 2:
        rc = ::write(fd,p++,sizeof(uint8_t));
        if (rc < (int)sizeof(uint8_t)) return(-1);
        bytesWritten += rc;
	// fall through
      case 1:
        rc = ::write(fd,p++,sizeof(uint8_t));
        if (rc < (int)sizeof(uint8_t)) return(-1);
        bytesWritten += rc;
    }
    return(bytesWritten);
  }

  //--------------------------------------------------------------------------
  //                         uint32_t Length() const                         
  //..........................................................................
  //!  Returns the number of bytes required to store the Ipv4Network on
  //!  disk.
  //--------------------------------------------------------------------------
  uint32_t Length() const
  {
    uint8_t  netSize = (this->maskLen + 7) / 8;
    return(sizeof(this->maskLen) + netSize);
  }
#endif // unused -kkeys

};


#endif  // _IPV4NETWORK_HH_
