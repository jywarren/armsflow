#define defproto(layer, prefix, abbr, proto_ok, id, desc) \
    %constant prefix##_##abbr = (layer << 28 | id);

#include "coral_proto.h"
