/* 
 * Copyright 2004, 2007 The Regents of the University of California
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */
/*
 * $Id: crl_fce.cc,v 1.8 2007/06/06 18:17:29 kkeys Exp $
 */
/*
 * Flow Counting Extension for crl_anf
 */

static const char RCSid[]="$Id: crl_fce.cc,v 1.8 2007/06/06 18:17:29 kkeys Exp $";

#include "config.h"
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <cstddef>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <sys/time.h>
#include <time.h>
#include <sys/errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <signal.h>
#include <errno.h>
#include <stdexcept>

#include <netinet/in.h>
#include <netinet/in_systm.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <netinet/ip_icmp.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/resource.h> // getrusage

#include "libcoral.h"
#include "crl_byteorder.h"
#include "hashtab.h"

#include <utility>
#if defined(HAVE_HASH_SET)
# include <hash_set>
#elif defined(HAVE_EXT_HASH_SET)
# include <ext/hash_set>
#else
# error "Cannot build without hash_set"
#endif
#include "h3.h"
#include "poolallocator.h"
#include "alignmentof.h"

#undef NDEBUG
#include <assert.h>

#define OUTPUT_VERSION "1.1"

// Hack: key bits and counter bits are mixed into a single byte on output
// so existing CoralReef table readers didn't need to be modified to read
// a new counter column.
#define PORTS_NONE  0x00    // port fields are not valid
#define PORTS_DPORT 0x01    // dport is a valid dst port
#define PORTS_SPORT 0x02    // sport is a valid src port
#define PORTS_PORTS (PORTS_SPORT | PORTS_DPORT)
#define PORTS_OTHER 0x04    // "ports" are really other proto-dependent values
			    // (icmp: type/code)
#define PORTS_KEY   0x0F    // key portion of ports_ok
#define PORTS_CTR   0xF0    // counter portion of ports_ok
#define PORTS_SYN   0x10    // TCP SYN flag seen on this flow

#if !PATH_MAX
# define PATH_MAX 1024
#endif



class SampProb {
public:
    double d; // denominator

    SampProb(uint32_t pd = 1) : d(pd) {};

    operator double() { return 1.0 / double(d); }
    // don't define conversion to integer, to avoid accidents

    bool operator== (const SampProb &b) const { return d == b.d; }
    SampProb& operator*= (const SampProb &b) { d *= b.d; }
    SampProb& operator/= (uint32_t &i) { d *= i; }
};

inline SampProb operator* (const SampProb &a, const SampProb &b) {
    SampProb r = a;
    return r *= b;
}

inline SampProb operator/ (const SampProb &a, uint32_t i) {
    SampProb r = a;
    return r /= i;
}



typedef uint64_t tuple_hashval_t;
#define PRIxTUP PRIx64

typedef uint64_t flow_t;

static const char *hostname(const struct in_addr *addr);

class Procstats
{
    const char *firstheap;
    const char *lastheap;
    struct timeval firstcpu, lastcpu;
public:
    Procstats() {
	firstheap = lastheap = (char*)sbrk(0);
	lastcpu.tv_sec = 0;
	lastcpu.tv_usec = 0;
    }
    ~Procstats() {
#ifndef NDEBUG
	(*this)("end app");
#endif
    }
    void operator()(const char *label) {
	struct timeval cpu, cpudiff;
	if (coral_verbosity < 2) return;
	struct rusage ru;
	const char *thisheap = (char*)sbrk(0);
	getrusage(RUSAGE_SELF, &ru);
	timeradd(&ru.ru_utime, &ru.ru_stime, &cpu);
	coral_printf("# %s: heap %ld KB, cpu %ld.%03lds ",
	    label, (thisheap - firstheap) / 1024, cpu.tv_sec, cpu.tv_usec/1000);
	timersub(&cpu, &lastcpu, &cpudiff);
	coral_printf("(+%ld KB, +%ld.%03lds)\n",
	    (thisheap - lastheap) / 1024, cpudiff.tv_sec, cpudiff.tv_usec/1000);
	lastheap = thisheap;
	lastcpu = cpu;
    }
    void mem(const struct timespec *ts);
} procstats;

struct config {
    double dinterval;
    double E;
    u_int netmask;
    SampProb flow_prob;
    size_t report_size;
    u_char mem;
    uint32_t adapt_sampling;
    u_char sampling;
    u_char cnames;
    u_char stats;
    u_char binary;
    u_char pretty;  /* non-pretty isn't needed if apps can read pretty format */
    u_char rotate_files;
    u_char skip_ephemeral_ports;
    u_char est_prec;
    const char *outfilename;
    coral_rotfile_t *rf;
    FILE *file;
} config;

struct {
    double ipbytes;
    double notIP;
    coral_pkt_stats_t *pkt_stats;
    double begin;
    double end;
} interval_data;

#define VPVC_HASH_TABLE_SIZE	229
#define FLOW_HASH_TABLE_SIZE	199999
#define TUPLE_HASH_TABLE_SIZE	1999999		// TUPLE

// assuming random() generates at least [0, 2^31-1], we mask it off to
// exactly [0, 2^31-1]
const uint32_t RAND_MASK = 0x7FFFFFFFul;
const uint32_t RAND_RANGE = 0x80000000ul;

const unsigned PKT_BKTS = 32;

struct subif_stats;

struct tuple_key {
    static const char *fmt_lheader, *fmt_rheader;
    static const char *fmt_addr, *fmt_right;
    struct in_addr src, dst;
    uint16_t sport;
    uint16_t dport;
    uint8_t proto;
    uint8_t ports_ok;

    bool operator== (const tuple_key &b) const
    {
	return
	    src.s_addr == b.src.s_addr &&
	    dst.s_addr == b.dst.s_addr &&
	    sport == b.sport && dport == b.dport &&
	    proto == b.proto && ports_ok == b.ports_ok;
    }

    static void header()
    {
	fprintf(config.file, fmt_lheader, "src     ", "dst     ");
	fprintf(config.file, fmt_rheader, "pro", "ok", "sport", "dport");
    }

    void dump_text() const
    {
	fprintf(config.file, fmt_addr, hostname(&src));
	fprintf(config.file, fmt_addr, hostname(&dst));
	fprintf(config.file, fmt_right,
	    proto, ports_ok, sport, dport);
    }

    void dump_binary() const
    {
	uint8_t pok = ports_ok;
        uint8_t length = sizeof(src) + sizeof(dst) + sizeof(proto) +
	    sizeof(ports_ok) + sizeof(sport) + sizeof(dport);
        uint8_t full_save = 0; // there are no first and latest timestamps
        uint16_t nsport = htons(sport);
        uint16_t ndport = htons(dport);
        fwrite(&length, sizeof(length), 1, config.file);
        fwrite(&full_save, sizeof(full_save), 1, config.file);
        fwrite(&src, sizeof(src), 1, config.file);
        fwrite(&dst, sizeof(dst), 1, config.file);
        fwrite(&proto, sizeof(proto), 1, config.file);
        fwrite(&pok, sizeof(pok), 1, config.file);
        fwrite(&nsport, sizeof(nsport), 1, config.file);
        fwrite(&ndport, sizeof(ndport), 1, config.file);
    }
};

template<class T>
struct tuple_key_hash {
    const H3<T, 13> h;
    tuple_key_hash() : h() {};

    T operator()(const tuple_key &key) const
    {
	return h(&key, 13, 0); // ports_ok wouldn't help much, so skip it
    }
};

static tuple_key_hash<tuple_hashval_t> *tuple_hash;

template<> struct hash<tuple_key> {
    size_t operator()(const tuple_key & key) const
    {
	return /* (size_t)(key.parent) ^ */ // XXX must include if/subif
	    ((size_t)(key.src.s_addr) * 59) ^
	    ((size_t)(key.dst.s_addr)) ^
	    ((size_t)(key.sport) << 16) ^
	    ((size_t)(key.dport)) ^
	    ((size_t)(key.proto));
    }
};

const char *fmt_dataheader, *fmt_data;
const char *tuple_key::fmt_lheader, *tuple_key::fmt_rheader;
const char *tuple_key::fmt_addr, *tuple_key::fmt_right;


// hash_set plus sampling probability
template <class Key, class HashFcn = hash<Key>, class EqualKey = equal_to<Key> >
class Flowtab : public hash_set<Key, HashFcn, EqualKey>
{
    typedef hash_set<Key, HashFcn, EqualKey> HS;
    Flowtab operator=(const Flowtab& x)
	{ throw NotImplemented; }
    SampProb _flow_prob;
    tuple_hashval_t sampthresh;

    void init()
    {
	sampthresh = tuple_hashval_t(~(tuple_hashval_t)0 / _flow_prob.d);
    }

    void clean()
    {
	iterator flowit, next;
	for (flowit = begin(); flowit != end(); flowit = next)
	{
	    next = flowit;
	    ++next;
	    if (!sampleflow(*flowit)) {
		erase(flowit);
	    }
	}
    }

public:
    Flowtab(SampProb prob) :
	HS(), _flow_prob(prob)
	{ init(); }
    Flowtab(SampProb prob, size_t n) :
	HS(n), _flow_prob(prob)
	{ init(); }
    Flowtab(SampProb prob, size_t n, const hasher& h) :
	HS(n,h), _flow_prob(prob)
	{ init(); }
    Flowtab(SampProb prob, size_t n, const hasher& h, const key_equal& k) :
	HS(n,h,k), _flow_prob(prob)
	{ init(); }
    Flowtab(SampProb prob, const Flowtab& x) :
	HS(x), _flow_prob(prob)
	{ init(); }

    SampProb flow_prob() { return _flow_prob; }
    SampProb flow_prob(SampProb prob)
	{ _flow_prob = prob; init(); return _flow_prob; }
    bool sampleflow(const Key &key)
	{ return (*tuple_hash)(key) < sampthresh; }

    void start_normalizer()
    {
	// resample to half
	if (!config.adapt_sampling) return;
	
	while (size() > 2 * config.report_size) {
	    coral_diag(1, ("cleaner start: size %d, prob %u/%f, thresh %" PRIxTUP "\n",
		size(), 1, _flow_prob.d, sampthresh)); // XXX

	    _flow_prob.d *= 2;
	    sampthresh = sampthresh >> 1;

	    clean();

	    coral_diag(1, ("cleaner done: size %d, prob %u/%f, thresh %" PRIxTUP "\n",
		size(), 1, _flow_prob.d, sampthresh)); // XXX
	}
    }

    void final_normalizer()
    {
	// resample to exactly the right size
	if (!config.adapt_sampling) return;

	if (config.adapt_sampling && size() > 1.1 * config.report_size) {
	    coral_diag(1, ("cleaner start: size %d, prob %u/%f, thresh %" PRIxTUP "\n",
		size(), 1, _flow_prob.d, sampthresh)); // XXX

	    _flow_prob.d =
		_flow_prob.d / (double(config.report_size) / size());
	    sampthresh =
		tuple_hashval_t(sampthresh * double(config.report_size) / size());

	    clean();

	    coral_diag(1, ("cleaner done: size %d, prob %u/%f, thresh %" PRIxTUP "\n",
		size(), 1, _flow_prob.d, sampthresh)); // XXX
	}
    }
};


typedef Flowtab<tuple_key> tuple_tab_t;

template<class C> inline void cleartable(C*& c)
{
    typename C::iterator it;
//    for (it = c->begin(); it != c->end(); ++it)
//	delete it->second;
    c->clear();
    delete c;
    c = NULL;
}

typedef uint64_t pktcnt;
typedef uint64_t bytecnt;

struct subif_stats {
// key
    coral_iface_t *iface;
    u_int iface_id;
    u_int subif_id;

// data
    pktcnt pkts;
    bytecnt bytes;
    pktcnt unknown_encaps;
    pktcnt ip_not_v4;
    tuple_tab_t *tuple_tab;

    subif_stats(coral_iface_t *p_iface, u_int p_iface_id, u_int p_subif_id) :
	iface(p_iface), iface_id(p_iface_id), subif_id(p_subif_id),
	pkts(), bytes(), unknown_encaps(), ip_not_v4(), tuple_tab()
	{}

    void clear() {
	if (tuple_tab) cleartable(tuple_tab);
    }

    ~subif_stats() { clear(); }
};

hash_tab *subif_hash = NULL;

void Procstats::mem(const struct timespec *ts) {
    static const struct subif_stats *subifrec = NULL; // XXX hack, assumes only one subif
    if (!subifrec) {
	init_hash_walk(subif_hash);
	subifrec = (const subif_stats*)next_hash_walk(subif_hash);
    }
    const char *thisheap = (char*)sbrk(0);
    coral_printf("# %ld.%06ld\t%ld\t%ld\n",
	ts->tv_sec, ts->tv_nsec/1000,
	(thisheap - firstheap) / 1024,
	subifrec->tuple_tab->size());
}

int interrupted = 0;
const char rotating_filename[] = "%010s.%f.t2";


/* ---- hash table per subif fxns begin ---- */
/* -- per subif hash table fxns -- */

/* return 0 if the same - for use by the hashtable */
static int compare_subif_stats(const void *entry1, const void *entry2)
{
    const subif_stats *foo1 = (const subif_stats *)entry1;
    const subif_stats *foo2 = (const subif_stats *)entry2;

    return (foo1->subif_id != foo2->subif_id ||
	    foo1->iface_id != foo2->iface_id);
}

/* make a hash of an entry - for use by the hashtable */
static unsigned long make_key_subif_stats(const void *entry)
{
    const subif_stats *what = (const subif_stats *)entry;

    return (unsigned) what->subif_id * 425879 + what->iface_id;
}

/* free mem of an entry - for use by the hashtable */
static void delete_subif_stats(void *entry)
{
    subif_stats *what = (subif_stats *)entry;
    if (!what) return;
    free(what);
}
/* -- end of subif type hash table fxns -- */


/* ---- hash table fxns end ---- */


static void count_packet(subif_stats *subif, coral_iface_t *iface,
    const coral_pkt_buffer_t *netpkt, const coral_timestamp_t *ts,
    uint64_t bytes)
{
    short offset;
    struct ip * ip;
    coral_pkt_buffer_t payload;
    uint16_t sport, dport;

    tuple_key flowid;

    ip = (struct ip*)netpkt->buf;
    offset = ntohs(ip->ip_off) & IP_OFFMASK;

    flowid.src.s_addr = config.netmask & ip->ip_src.s_addr;
    flowid.dst.s_addr = config.netmask & ip->ip_dst.s_addr;
    flowid.proto = ip->ip_p;
    flowid.ports_ok = 0;
    sport = flowid.sport = 0;
    dport = flowid.dport = 0;

    coral_get_payload(netpkt, &payload);
    /* NOT get_payload_by_layer(..., 4); we want the payload, no matter what
     * layer it claims to be.  (Specifically, we don't want to go through
     * IPIP encapsulations.)
     */

    /* extract port info */
    if (offset != 0) {
	// non-first fragment, no layer 4 header
    } else if (ip->ip_p == IPPROTO_TCP) {
	if (payload.caplen >= 4) {
	    struct tcphdr *t = (struct tcphdr*)payload.buf;
	    sport = flowid.sport = ntohs(t->th_sport);
	    dport = flowid.dport = ntohs(t->th_dport);
	    flowid.ports_ok = PORTS_PORTS;
	}
    } else if (ip->ip_p == IPPROTO_UDP) {
	if (payload.caplen >= 4) {
	    struct udphdr *u = (struct udphdr*)payload.buf;
	    sport = flowid.sport = ntohs(u->uh_sport);
	    dport = flowid.dport = ntohs(u->uh_dport);
	    flowid.ports_ok = PORTS_PORTS;
	}
    } else if (ip->ip_p == IPPROTO_ICMP) {
	if (payload.caplen >= 2) {
	    struct icmp *icmp = (struct icmp*)payload.buf;
	    flowid.sport = icmp->icmp_type;
	    flowid.dport = icmp->icmp_code;
	    sport = dport = (icmp->icmp_type << 8) | icmp->icmp_code;
	    flowid.ports_ok = PORTS_OTHER;
	}
#if 0
    } else if (ip->ip_p == IPPROTO_IGMP) {
	    ...
	    flowid.sport = igmp->igmp_type;
	    flowid.dport = igmp->igmp_code;
	    flowid.ports_ok = PORTS_OTHER;
#endif
    }

    if (subif->tuple_tab->sampleflow(flowid)) {
	subif->tuple_tab->insert(flowid);
	subif->tuple_tab->start_normalizer();
    }
}

/* NB: returns a pointer to static data */
static const char *hostname(const struct in_addr *addr)
{
    struct hostent *h;
    if (config.cnames &&
	(h = gethostbyaddr((char*)addr, sizeof(struct in_addr), AF_INET)))
    {
	return h->h_name;
    } else {
	return inet_ntoa(*addr);
    }
}

static void dump_binary_flow_table(tuple_tab_t& table)
{
    tuple_tab_t::iterator flowit;

    fputs("#binary data follows\n", config.file);

    for (flowit = table.begin(); flowit != table.end(); ++flowit) {
	uint64_t pkts = 0;
	uint64_t bytes = 0;
	uint64_t flows = 1;

	flowit->dump_binary();
	fwrite(&pkts, sizeof(pkts), 1, config.file);
	fwrite(&bytes, sizeof(bytes), 1, config.file);
	fwrite(&flows, sizeof(flows), 1, config.file);
    }
    fwrite("\0", 1, 1, config.file); // table trailer
    fputs("\n# end of binary table\n\n", config.file);

    fflush(config.file);
}

static void dump_text_flow_table(tuple_tab_t& table)
{
    tuple_tab_t::iterator flowit;

    tuple_key::header();
    fprintf(config.file, fmt_dataheader, "pkts", "bytes", "flows");

    for (flowit = table.begin(); flowit != table.end(); ++flowit) {
	flowit->dump_text();
	fprintf(config.file, fmt_data, uint64_t(0), uint64_t(0), uint32_t(1));
    }
    fputs("# end of text table\n\n", config.file);

    fflush(config.file);
}

static void dump_flow_table(const subif_stats *subifrec,
    tuple_tab_t& table, const char *label)
{
    char buf[32];
    coral_fmt_if_subif(buf, subifrec->iface, subifrec->subif_id);

    // XXX resample to EXACTLY the right size (not half)
    table.final_normalizer();

    // before "# begin" line to avoid choking parser
    // tuple_key::notes();
    fprintf(config.file, "# initial flow sample prob: %u/%f\n",
	1, config.flow_prob.d);
    if (config.adapt_sampling) {
	fprintf(config.file, "# final flow sample prob: %u/%f\n",
	    1, table.flow_prob().d);
    }

    fprintf(config.file, "# (%d entries)\n", table.size());

    fprintf(config.file, "# begin %s Table ID: %s\n", label, buf);
    if (config.binary) {
	dump_binary_flow_table(table);
    } else {
	dump_text_flow_table(table);
    }
}

/* 
 * keep track of some subif related stats, and count_packet().
 */
static void count_subif_stats(coral_iface_t *iface,
    coral_pkt_result_t *pkt_result)
{
    subif_stats *subifrec;
    subif_stats tmp(iface, coral_interface_get_number(iface), pkt_result->subiface);
    coral_pkt_buffer_t netpkt;
    struct ip *ip;

    if (!(subifrec = (subif_stats*)find_hash_entry(subif_hash, &tmp))) {
	subifrec = new subif_stats(tmp.iface, tmp.iface_id, tmp.subif_id);
	if (subifrec == NULL) {
	    fprintf(stderr, "can't allocate subif_stats.\n");
	    abort();
	}
	subifrec->tuple_tab = new tuple_tab_t(config.flow_prob,
	    2 * config.report_size);
        add_hash_entry(subif_hash, subifrec);
#ifndef NDEBUG
	procstats("init hash");
#endif
    }

    if (coral_get_payload_by_layer(pkt_result->packet, &netpkt, 3) < 0) {
	subifrec->unknown_encaps++;
	return;
    }

    if (!coral_proto_is_IP(netpkt.protocol)) {
	interval_data.notIP++;
	return;
    }

    ip = (struct ip*)netpkt.buf;
    if (ip->ip_v != 4) {
	subifrec->ip_not_v4++;
	return;
    }

    /* do stats --- */
    uint64_t bytes = ntohs(ip->ip_len);
    subifrec->pkts++;
    subifrec->bytes += bytes;
    interval_data.ipbytes += bytes;
    count_packet(subifrec, iface, &netpkt, pkt_result->timestamp, bytes);
}

static void init_hashes(void)
{
    subif_hash = init_hash_table("# subif hash",
			       compare_subif_stats, make_key_subif_stats,
			       delete_subif_stats, VPVC_HASH_TABLE_SIZE);
}


static void dump_hash_stats(void)
{
    dump_hashtab_stats(subif_hash);
}

static void dump_data(void)
{
    const subif_stats *subifrec;
    double begin;
    double end;
    int count;

    begin = interval_data.begin;
    end = interval_data.end;

    /* Normal (possibly empty) interval */
    fprintf(config.file, "\n# begin trace interval: %f\n", begin);
    fprintf(config.file, "# trace interval duration: %f s\n"
		    "# Layer 2 PDUs dropped: %" PRIu64 "\n"
		    "# IP: %.4f Mbit/s\n"
		    "# Non-IP: %.4f pkts/s\n",
	(end - begin), 
	interval_data.pkt_stats->l2_drop,
	interval_data.ipbytes * 8 / (1000 * 1000 * (end - begin)),
	interval_data.notIP/(end - begin));

    fputs("# Table IDs: ", config.file);
    init_hash_walk(subif_hash);
    count = 0;
    while ((subifrec = (const subif_stats*)next_hash_walk(subif_hash))) {
	if (subifrec->tuple_tab ||
	    subifrec->unknown_encaps || subifrec->ip_not_v4)
	{
	    char buf[32];
	    if (count++)
		fputs(", ", config.file);
	    coral_fmt_if_subif(buf, subifrec->iface, subifrec->subif_id);
	    fprintf(config.file, "%s", buf);
	}
    }
    fputs("\n\n", config.file);

    init_hash_walk(subif_hash);
    while ((subifrec = (const subif_stats*)next_hash_walk(subif_hash))) {
	if (subifrec->tuple_tab ||
	    subifrec->unknown_encaps || subifrec->ip_not_v4)
	{
	    char buf[32];
	    coral_fmt_if_subif(buf, subifrec->iface, subifrec->subif_id), 
	    fprintf(config.file, "# ID: %s\n"
		    "# unknown_encaps: %" PRIu64 "\n"
		    "#      ip_not_v4: %" PRIu64 "\n",
		    buf,
		    subifrec->unknown_encaps,
		    subifrec->ip_not_v4);
	    if (subifrec->pkts > 0) {
		fprintf(config.file, "#      true pkts: %" PRIu64 "\n",
		    subifrec->pkts);
		fprintf(config.file, "#     true bytes: %" PRIu64 "\n",
		    subifrec->bytes);
		fprintf(config.file, "#          flows: 0\n");
		fprintf(config.file,
			"#          first: 0\n"
			"#         latest: 0\n"); // XXX
		fputs("# Table types: Tuple Table\n", config.file);
	    }
	    fputs("\n", config.file); 
	}
    }

    init_hash_walk(subif_hash);
    while ((subifrec = (const subif_stats*)next_hash_walk(subif_hash))) {
	dump_flow_table(subifrec, *subifrec->tuple_tab, "Tuple");
    }
    fputs("# end trace interval\n", config.file);
    fflush(config.file);
}

static void clear_data(void)
{
    subif_stats *subifrec;

    interval_data.ipbytes = 0;
    interval_data.notIP = 0;

    init_hash_walk(subif_hash);
    while ((subifrec = (subif_stats*)next_hash_walk(subif_hash))) {
	subifrec->clear();
    }
#if defined(TUPLE) || defined(BLOOM)
    tuple_set->clear();
    if (config.hostdegree)
	hostdegree_set->clear();
#endif // defined(TUPLE) || defined(BLOOM)
    clear_hash_table(subif_hash);
}

static void stop(int sig)
{
    interrupted = 1;
}

int main(int argc, char *argv[])
{
    int retval = 0;
    int i;
    coral_iface_t *iface;
    coral_pkt_result_t pkt_result;
    coral_interval_result_t interval_result;
#   define CIDR_LEN 32
    u_int cidr_len = CIDR_LEN;
    struct timeval interval = { 300, 0 };
    u_int duration;
    int opt;
    int error = 0, first = 1, seeded = 0;
    char file_header[1024], *p;

    config.outfilename = "-"; /* Default to stdout */

    coral_set_api(CORAL_API_PKT);
    coral_set_duration(0);
    coral_set_interval(&interval);
    coral_set_iomode(0, CORAL_RX, 48, 0);
    coral_set_options(0, CORAL_OPT_PARTIAL_PKT | CORAL_OPT_NORMALIZE_TIME);

    config.report_size = 0;

    const char *options = "C:p:asBfhO:o:rS:eM:F:mu:";

    while (!error && (opt = getopt(argc, argv, options)) != -1) {
	switch (opt) {
	case 'C':
	    if (coral_config_command(optarg) < 0)
		error++;
	    break;
	case 'p':
	    cidr_len = atoi(optarg);
	    if (cidr_len > 32 || cidr_len < 8) {
		fprintf(stderr,
			"%s: valid CIDR prefix lengths are between 8 and 32\n",
			argv[0]);
		error++;
	    }
	    break;
	case 'a':
	    config.cnames = 1;
	    break;
	case 's':
	    config.stats = 1;
	    break;
	case 'B':
	    config.binary = 1;
	    break;
	case 'f':
	    config.est_prec = 6;
	    break;
	case 'm':
	    config.mem = 1;
	    break;
	case 'M':
	    config.report_size = atoi(optarg);
	    break;
	case 'S': // XXX
	    seeded++;
	    srandom(atoi(optarg)); // XXX
	    fprintf(stderr, "SRANDOM\n");
	    break;
	case 'h':
	    config.pretty = 1;
	    break;
	case 'r':
	    config.rotate_files = 1;
	    config.outfilename = rotating_filename;
	    break;
	case 'O':
	    config.rotate_files = 1;
	    /* fall through */
	case 'o':
	    config.outfilename = strdup(optarg);
	    break;
	case 'F':
	    config.flow_prob = SampProb(atoi(optarg));
	    break;
	case 'e': // XXX
	    config.skip_ephemeral_ports = 1;
	    break;
	default:
	    error++;
	    break;
	}
    }

    if (error) {
	coral_usage(argv[0], "[<options>] <source>...\n"
	    "Options:\n"
	    "-p<n>      use <n> as length of CIDR prefix (default %d)\n"
	    "-a         resolve IP addresses to hostnames (only makes sense with -p32)\n"
	    "-s         print hash table statistics\n"
	    "-B         print binary table data\n"
	    "-h         print human readable table data\n"
	    "-o<file>   specify the name of the output file (default: -)\n"
	    "-r         rotate the output file every interval (requires a filename with\n"
	    "           %% specifiers; the default filename with -r is '%s')\n"
	    "-O<file>   equivalent to -r -o<file>\n\n"
	    "-n         normalize immediately instead of in parallel\n" // XXX
	    "Performance parameters:\n"
	    "-e	        \"fold\" ephemeral ports\n"
	    "-M<n>      report <n> entries\n"
	    "-F<d>	sample 1 out of <d> flows initially\n" // XXX
	    "Testing:\n"
	    "-m         periodically print memory usage to stderr\n" // XXX
	    "\n"
"    <file> is the name of the output file, which may contain %% specifiers\n"
"    for formatting a timestamp.  For -o, the timestamp is the beginning of\n"
"    the trace; for -O, the timestamp is the beginning of the interval.\n"
"    The %% specifiers are any of those allowed by strftime(), plus:\n"
"        %%s   number of (whole) seconds since 1970-01-01 00:00:00 UTC\n"
"        %%f   fractional part of seconds (6 decimal places)\n"
"        %%F   equivalent to %%Y-%%m-%%d\n"
"    Except for %%f, all specifiers may contain printf-style modifiers\n"
"    (e.g., \"%%010s\").\n"
"    For -o, '-' means standard output.\n",
	    CIDR_LEN,
	    rotating_filename);
	exit(-1);
    }

    config.adapt_sampling = (config.report_size > 0);
    if (!seeded) srandom(time(NULL) ^ getpid()); /* XXX use /dev/random */

    while (optind < argc) {
	if (!coral_new_source(argv[optind]))
	    exit(-1);
	optind++;
    }

    if (!coral_next_source(NULL)) {
	coral_diag(1, ("%s: warning: no sources specified.\n", argv[0]));
    }

    init_hashes();
    tuple_hash = new tuple_key_hash<tuple_hashval_t>;

    /* generate a netmask from the cidr length */
    config.netmask = 0xFFFFFFFF << (32 - cidr_len);

    /* corrected for endianess */
    config.netmask = ntohl(config.netmask);

    if (coral_open_all() <= 0)
	exit(-1);

    if (coral_start_all() < 0)
	exit(-1);

    signal(SIGINT, stop);

    coral_get_interval(&interval);
    config.dinterval = timevaltodouble(&interval);
    interval_data.begin = 0;
    interval_data.end = 0;
    interval_data.pkt_stats = NULL;

    duration = coral_get_duration();
    if (duration)
	coral_diag(2, ("collection duration max set to %d second(s)\n", 
		       duration));

    coral_read_pkt_init(NULL, NULL, &interval);

    p = file_header;
    p += sprintf(p, "# crl_anf output version: %s (%s format)\n",
	    OUTPUT_VERSION,
	    config.binary ? "binary" : config.pretty ? "pretty" : "text" );
    p += sprintf(p, "# generated by: ");
    for (i = 0; i < argc; i++)
	p += sprintf(p, " %s", argv[i]);
    sprintf(p, "\n");

    if (!config.binary) {
        if (!config.pretty) {
            tuple_key::fmt_lheader = "#%s\t%s\t";
            tuple_key::fmt_rheader = "%s\t%s\t%s\t%s\t";
            tuple_key::fmt_addr = "%s\t";
            tuple_key::fmt_right = "%u\t%u\t%u\t%u\t";
            fmt_dataheader = "%s\t%s\t%s\n";
            fmt_data = "%" PRIu64 "\t%" PRIu64 "\t%u\n";
        } else {
            if (config.cnames) {
                tuple_key::fmt_lheader = "#%-29s %-30s ";
                tuple_key::fmt_addr = "%-30s ";
            } else {
                tuple_key::fmt_lheader = "#%-14s %-15s ";
                tuple_key::fmt_addr = "%-15s ";
            }
            tuple_key::fmt_rheader = "%-5s %-2s %5s %5s ";
            tuple_key::fmt_right = "%5u %2u %5u %5u ";
            fmt_dataheader = "%13s %15s %9s\n";
            fmt_data = "%13" PRIu64 " %15" PRIu64 " %9u\n";
        }
    }

    config.rf = coral_rf_open_file(&config.file, config.outfilename, "", 0);
    if (!config.rf)
	exit(1);
#ifndef NDEBUG
    procstats("start loop");
#endif

    while (1) {
	if (interrupted) {
	    coral_stop_all();
	    interrupted = 0;
	}
	iface = coral_read_pkt(&pkt_result, &interval_result);

	if (!iface) {
	    if (errno == EINTR || errno == EAGAIN) continue;
	    retval = errno;
	    break;
	}

	if (!pkt_result.packet && !interval_result.stats) {
	    /* beginning of interval */
#ifndef NDEBUG
	    procstats("start int");
#endif
	    double begin = timevaltodouble(&interval_result.begin);
	    interval_data.begin = begin;
	    if (config.rotate_files || first) {
		coral_rf_start(config.rf, &interval_result.begin);
		fputs(file_header, config.file);
		first = 0;
	    }

	} else if (pkt_result.packet) {
	    /* got packet */
	    count_subif_stats(iface, &pkt_result);
	    if (config.mem) {
		static uint64_t n = 0;
		if (n++ % 10000 == 0) {
		    struct timespec ts;
		    coral_read_clock_timespec(iface, pkt_result.timestamp, &ts);
#ifndef NDEBUG
		    procstats.mem(&ts);
#endif
		}
	    }

	} else if (!pkt_result.packet && interval_result.stats) {
	    /* end of interval */
	    struct timeval tv1, tv2;
#ifndef NDEBUG
	    procstats("end int");
#endif
	    interval_data.end = timevaltodouble(&interval_result.end);
	    interval_data.pkt_stats = interval_result.stats;

	    gettimeofday(&tv1, NULL);

	    dump_data();
	    if (config.rotate_files)
		coral_rf_end(config.rf);
	    clear_data();
	    gettimeofday(&tv2, NULL);
	    timersub(&tv2, &tv1, &tv1);
	    coral_diag(3, ("crl_anf: closed %f s interval in %d.%06d s\n",
		interval_data.end - interval_data.begin,
		tv1.tv_sec, tv1.tv_usec));

	    /* reset the interval time, and other timers */
	    interval_data.begin = 0;
	    interval_data.end = 0;
	    interval_data.pkt_stats = NULL;
	}
    }

    coral_rf_close(config.rf);
    coral_stop_all();

    /* clean up stuff */
    if (config.stats) dump_hash_stats();
#if 0
    clear_hash_table(subif_hash);
    srcip_tab.clear();
    dstip_tab.clear();
#endif

    return retval;
}

