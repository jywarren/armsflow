#!/usr/local/bin/perl
## $Id: config_graphs.pl,v 1.13 2007/06/07 18:27:48 rkoga Exp $ $Name: release-3-8-1 $
## 
## Copyright 2004, 2005, 2007
## The Regents of the University of California 
## All Rights Reserved 
## 
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
## 
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
## 
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
## 
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
## 
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program.  Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
## 
## Report bugs and suggestions to coral-bugs@caida.org.
## 

use warnings;
use strict;
no strict 'refs';

my $coral_dir;
BEGIN { $coral_dir = "/usr/local/Coral"; } # This will be edited during build.
use lib "$coral_dir/lib"; #coral global libdir#
use lib "../../../lib"; #coral local libdir#
use CAIDA::Traffic2::ReportSupport;

my %mon_config;
my %shared_config;
my $monitor_pat = '\s*monitor\s*{';
my $shared_pat = '\s*shared\s*{';

my @monitors = @ARGV;

use vars qw($rrd_store_dir $delay $graph_dir $big_dir $table_dir $abs_or_perc
	    $make_ts $make_big_ts $make_pie $make_table $make_map);
use vars qw($to_graph $max_rrds $graph_func $use_other $counters
	    $intervals $def_colors $map $pll_path $pll_data $pll_type
	    $circle_color $font $max_diam $diam_scale);
my (@special_vars, @stanza_vars);
@special_vars = qw(rrd_store_dir delay graph_dir big_dir table_dir abs_or_perc
	    make_ts make_big_ts make_pie make_table make_map);
@stanza_vars = qw(to_graph max_rrds graph_func use_other counters
	    intervals def_colors map pll_path pll_data pll_type
	    circle_color font max_diam diam_scale watermark);
parse_config(\*STDIN, {$monitor_pat => \%mon_config,
			$shared_pat => \%shared_config});

my $default = $shared_config{'default'};

my @all_stanzas;
my $graph_counter = 1;
foreach my $mon_name (@monitors) {
    my $stanza = $mon_config{$mon_name};
    next unless defined $stanza;

    foreach my $var_name (@special_vars, @stanza_vars) {
	$$var_name = get_best_var($default, $stanza, $var_name);
    }

    $rrd_store_dir = get_best_var($default, $stanza, 'rrd_dir');
    die "rrd_dir must be specified in default or monitor stanza"
						unless defined $rrd_store_dir;
    my $timefile = "$rrd_store_dir/$mon_name/.lastdata";
    open LASTDATA, $timefile or die "Failed to get endtime from $timefile: $!";
    $delay = get_best_var($default, $stanza, 'delay');
    my $endtime = <LASTDATA>;
    chomp $endtime;
    $endtime -= $delay*3600 if $delay; # Delay expressed in hours
    close LASTDATA;

    my %cat_map = get_best_list($default, $stanza, 'cat_map');
    my @categories = keys %cat_map;
    my ($width, $height) = get_best_list($default, $stanza, 'dimensions');
    my ($big_width, $big_height) = get_best_list($default, $stanza,
						'big_dimensions');

    my %basic_stanza;
    $basic_stanza{'monitor'} = $mon_name;
    $basic_stanza{'format'} = 'rrd';
    $basic_stanza{'rrd_dir'} = $rrd_store_dir;
    $basic_stanza{'width'} = $width if defined $width;
    $basic_stanza{'height'} = $height if defined $height;
    $basic_stanza{'endtime'} = $endtime;
    $basic_stanza{'dir'} = $graph_dir;

    foreach my $var_name (@stanza_vars) {
	$basic_stanza{$var_name} = $$var_name if defined $$var_name;
    }
    my @use_perc;
    if (not defined $abs_or_perc or $abs_or_perc eq 'abs') {
	@use_perc = (0);
    } elsif ($abs_or_perc eq 'perc') {
	@use_perc = (1);
    } elsif ($abs_or_perc eq 'both') {
	@use_perc = (0,1);
    } else {
	die "Unknown value for abs_or_perc: $abs_or_perc";
    }
    foreach my $category (@categories) {
	my %stanza = %basic_stanza;
	$stanza{'category'} = $category;
	$stanza{'type'} = $cat_map{$category};
	foreach my $perc (@use_perc) {
	    if ($make_ts) {
		my %ts_stanza = %stanza;
		$ts_stanza{'name'} = 'graph_set' . $graph_counter++;
		$ts_stanza{'style'} = 'timeseries';
		$ts_stanza{'use_perc'} = $perc;
		push @all_stanzas, \%ts_stanza;
	    }
	    if ($make_big_ts) {
		my %big_stanza = %stanza;
		$big_stanza{'name'} = 'graph_set' . $graph_counter++;
		$big_stanza{'style'} = 'timeseries';
		$big_stanza{'dir'} = $big_dir;
		$big_stanza{'width'} = $big_width;
		$big_stanza{'height'} = $big_height;
		$big_stanza{'use_perc'} = $perc;
		push @all_stanzas, \%big_stanza;
	    }
	}
	if ($make_pie) {
	    my %pie_stanza = %stanza;
	    $pie_stanza{'name'} = 'graph_set' . $graph_counter++;
	    $pie_stanza{'style'} = 'pie';
	    push @all_stanzas, \%pie_stanza;
	}
	if ($make_table) {
	    my %table_stanza = %stanza;
	    $table_stanza{'name'} = 'graph_set' . $graph_counter++;
	    $table_stanza{'dir'} = $table_dir;
	    $table_stanza{'style'} = 'table';
	    push @all_stanzas, \%table_stanza;
	}
	if ($make_map and $category =~ /country/) {
	    my %map_stanza = %stanza;
	    $map_stanza{'name'} = 'graph_set' . $graph_counter++;
	    $map_stanza{'style'} = 'map';
	    push @all_stanzas, \%map_stanza;
	}
    }
}

# Pass on all 'shared' stanzas for create_graphs.
foreach my $shared_name (get_config_keys(\%shared_config)) {
    my $stanza = $shared_config{$shared_name};
    print "shared {\n";
    print "\tname:\t$shared_name\n";
    foreach my $field (get_config_keys($stanza)) {
	my $value = get_config_var($stanza, $field);
	print "\t$field:\t$value\n" if defined $value;
    }
    print "}\n\n";
}

# Output graph commands.
foreach my $stanza (@all_stanzas) {
    print "graph {\n";
    while (my ($field, $value) = each %$stanza) {
	print "\t$field:\t$value\n" if defined $value;
    }
    print "}\n\n";
}
