package CAIDA::Traffic2::CustomBaseHTML;
require 5.004;
## $Id: CustomBaseHTML.pm,v 1.15 2007/06/06 18:17:50 kkeys Exp $ $Name: release-3-8-1 $
##
## -----------------------------------------------------------------------
## Perl module:CustomBaseHTML.pm
## 
## This Perl module provides a framework for customizing the HTML
## produced by make_html_graph.pl.  This permits for custom HTML
## report pages without changes to the make script.  This is the base
## class for that object.  Inheritance isn't used to much advantage in 
## this case, but it can be used for example to provide a custom piece
## without changing the rest of the report appearance.
## 
## Note: test routines require the Test.pm module or Perl 5.005
##
## Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
## All Rights Reserved 
##
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
##
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
##
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
##
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
##
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program. Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
##
## Contact: coral-info@caida.org
## ---------------------------------------------------------------------

# Set up object export condition.  No functions accessible directly.
use Exporter ();
@ISA       = qw(Exporter);
@EXPORT    = qw();
@EXPORT_OK = qw();

# Define required CVS variables
$cvs_Id = '$Id: CustomBaseHTML.pm,v 1.15 2007/06/06 18:17:50 kkeys Exp $';
$cvs_Author = '$Author: kkeys $';
$cvs_Name = '$Name: release-3-8-1 $';
$cvs_Revision = '$Revision: 1.15 $';

# Enable error messages to come from calling script
use Carp;

# Force this module to adhere to safe programming practices.
use strict;

# Version of module
my $VERSION = 1.0;

# .   .   .   .   .  Internal object functions  .   .   .   .   .   .   .  

sub _is_blank_line($ ) {
# ---------------------------------------------------
# Small helper function (predicate) to determine if 
# the argument is an empty line
# ---------------------------------------------------
    my $data_line = shift;

    return($data_line =~ /^\s*$/);
}


# .   .   .   .   .  User Method Subroutines  .   .   .   .   .   .   .   .  

sub new($ ) {
# -----------------------------------------------
# Create new object.  Object oriented features
# exist mainly to have multiple report styles.
# -----------------------------------------------
    # retrieve parameters
    my $class_name = shift;
    
    # allocate space for object and bless it.
    my	$sample_object = {};
    bless $sample_object, $class_name;

#    $sample_object->reset();
    
    # Return object reference
    return($sample_object);
}
	
sub html_header($$$$) {
# -------------------------------------
# Generic HTML header for report
# -------------------------------------
    my $obj_ref = shift;
    my $filehdl_ref = shift;
    my $refresh_http = shift;
    my $title = shift;
    
    # Make page expire immediately since anytime the reload button is hit
    # The page is obsolete.
    my $expires = gmtime;
    
    # Use "here-document" to include standard Caida HTML header
    print $filehdl_ref <<"EOH";
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2//EN">
<!-- ************************** -->
<!-- Generic HTML Output header -->
<!-- for Traffic2 to .......... -->
<!-- make_html_graph.pl ....... -->
<!-- ************************** -->
<HTML>
<HEAD>
    <TITLE>
    $title
    </TITLE>

    <META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=iso-8859-1">
    <META NAME="resource-type" CONTENT="document">
    <META NAME="description" CONTENT="$title">
    <META NAME="pragma" CONTENT="no-cache">
    <!-- Set page to expire immediately.  Reload should go back to server -->
    <META HTTP-EQUIV="expires" CONTENT="$expires GMT"> 
    <!-- Force page to reload after 5 minutes -->
    <META HTTP-EQUIV="refresh" CONTENT=300>
</HEAD>

<BODY BGCOLOR="#FFFFFF">
    <!-- Standard Caida Title with organizational logo -->
	<H1><CENTER>$title</CENTER></H1><BR>
	<!-- Body of HTML document starts here -->
	<HR>
EOH

} # End sub html_header

sub html_footer ($$) {
# ----------------------------------------
# Subroutine to send out the HTML tags
# a generic HTML footer
# ----------------------------------------
    my $obj_ref = shift;
    my $filehdl_ref = shift;
    
    print $filehdl_ref <<"EOT";
	<HR>
</BODY>
</HTML>
EOT
    
}# End sub html_footer


# =============================
# POD Documentation for Module

__END__

=head1 NAME

CustomBaseHTML.pm - Base class for Custom HTML in Traffic2 reports.

=head1 SYNOPSIS

    use CAIDA::Traffic2::CustomBaseHTML;

    # Create a sample object to store data and an object combine sets.
    my html_obj = new CAIDA::Traffic2::CustomBaseHTML();

	# Create HTML header
	html_obj->html_header($obj_ref, $filehdl_ref, $refresh_http, $title);
	
	# Create HTML footer
	html_obj->html_header($obj_ref, $filehdl_ref);
	
=head1 DESCRIPTION

CustomBaseHTML.pm is a first cut at a base class of HTML templates to
facilitate the creation of customized reports.  Custom versions of this
base class can be used to provide unique report display features while
inheriting existing features to avoid "reinventing the wheel."

=head1 EXAMPLE

See synopsis above for usage.  Custom HTML is best created by modifying a
copy of this file and instead making it an instance of this base class. 
See the CustomCaidaHTML.pm file for an example.

=head1 AUTHOR

CoralReef Development team, CAIDA Group <coral-info@caida.org>

=head1 COPYRIGHT

Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
All Rights Reserved 

Permission to use, copy, modify and distribute any part of this
CoralReef software package for educational, research and non-profit
purposes, without fee, and without a written agreement is hereby
granted, provided that the above copyright notice, this paragraph
and the following paragraphs appear in all copies.

Those desiring to incorporate this into commercial products or use
for commercial purposes should contact the Technology Transfer
Office, University of California, San Diego, 9500 Gilman Drive, La
Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.

IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
THE POSSIBILITY OF SUCH DAMAGE.

THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
ANY PATENT, TRADEMARK OR OTHER RIGHTS.

The CoralReef software package is developed by the CoralReef
development team at the University of California, San Diego under
the Cooperative Association for Internet Data Analysis (CAIDA)
Program. Support for this effort is provided by the CAIDA grant
NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
N66001-01-1-8909, and by CAIDA members.

Report bugs and suggestions to coral-bugs@caida.org.

=cut

# .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   .   . 
1; ##must be last line in the file
