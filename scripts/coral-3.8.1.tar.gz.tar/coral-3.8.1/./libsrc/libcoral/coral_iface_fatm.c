/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/* High-level functions for FORE ATM interfaces (devices or tracefiles).
 *
 *  $Id: coral_iface_fatm.c,v 1.39 2007/06/06 18:17:53 kkeys Exp $
 *
 */

#include "config.h"
#include "coraldefs.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/param.h>

#include "libcoral.h"
#include "libcoral_priv.h"
#include "coral_clock.h"

/* Seconds in each tick of the hardware clock */
#define FORE_OC3_SEC_PER_TICK           40e-9
/* number of seconds to hold blocks for discontinuity checking */
#define MAX_HOLD			16

static const char RCSid[] = "$Id: coral_iface_fatm.c,v 1.39 2007/06/06 18:17:53 kkeys Exp $";

/*
 * The "hard" clock is a 16-bit counter kept on the card.  Almost (!) every
 * time it wraps around, the "soft" clock, a 32-bit counter, is incremented by
 * an interrupt handler.  It is possible for the soft clock to miss a hard
 * clock wrap, so the code handling these clocks needs to check for a hard
 * clock wrap where the soft clock didn't get changed.  We assume that each
 * timestamp passed into this function will always be >= the timestamp
 * passed into the previous call.
 *
 * To make life interesting, there are two different OC3 clock formats.
 * Say that S3S2S1S0 is the 32-bit firmware clock, where S3 is the MSB and S0 
 * the LSB.  Similarly, H1H0 is the hardware clock and F1F0 the FIFO depth.
 *
 * If the data is in network order, the format is:
 *       +-------------------+
 *       | S3 | S2 | S1 | S0 |
 *       +-------------------+
 *       | H1 | H0 | F1 | F0 |
 *       +-------------------+
 *
 * Otherwise, the data has had the byte order reversed completely:
 *       +-------------------+
 *       | F0 | F1 | H0 | H1 |
 *       +-------------------+
 *       | S0 | S1 | S2 | S3 |
 *       +-------------------+
 */

static inline void fatm_clock_order(const coral_iface_t *iface,
    const coral_timestamp_t *src, coral_timestamp_t *dst)
{
    if (iface->iface_info.time_is_le) {
	dst->i[0] = crl_letohl(src->i[1]);
	dst->i[1] = ((src->c[3] << 8) | src->c[2]);
    } else {
	dst->i[0] = crl_betohl(src->i[0]);
	dst->i[1] = ((src->c[4] << 8) | src->c[5]);
    }
}

static inline void coral_fatm_oclock_timespec(const coral_iface_t *iface,
    const coral_timestamp_t *t, struct timespec *tspec)
{
    double d;

    d = ((double)0x10000 * t->i[0] + t->i[1]) * FORE_OC3_SEC_PER_TICK;
    tspec->tv_sec = d;
    tspec->tv_nsec = (d - tspec->tv_sec) * 1000000000 + 0.5;
}

static void coral_fatm_clock_timespec(const coral_iface_t *iface,
    const coral_timestamp_t *t, struct timespec *tspec)
{
    coral_timestamp_t to;
    fatm_clock_order(iface, t, &to);
    coral_fatm_oclock_timespec(iface, &to, tspec);
}

#if 0
/* compare fatm host-order timestamps:  a cmp b */
#define fatm_clock_cmp(a, b, cmp) \
    ((a)->i[0] == (b)->i[0] ? (a)->i[1] cmp (b)->i[1] : (a)->i[0] cmp (b)->i[0])
#endif

/* subtract fatm host-order timestamps:  diff = a - b */
static inline void fatm_clock_diff(const coral_timestamp_t *a,
    const coral_timestamp_t *b, coral_timestamp_t *diff)
{
    diff->i[0] = a->i[0] - b->i[0];
    if (a->i[1] >= b->i[1]) {
	diff->i[1] = a->i[1] - b->i[1];
    } else {
	diff->i[1] = 0x10000 + a->i[1] - b->i[1];
        diff->i[0]--;
    }
}

/* add fatm host-order timestamps:  sum = a - b */
static inline void fatm_clock_sum(const coral_timestamp_t *a,
    const coral_timestamp_t *b, coral_timestamp_t *sum)
{
    sum->i[0] = a->i[0] + b->i[0];
    sum->i[1] = a->i[1] + b->i[1];
    if (sum->i[1] > 0x10000) {
	sum->i[1] -= 0x10000;
        sum->i[0]++;
    }
}

static int handle_discontinuity(coral_iface_t *iface,
    const coral_timestamp_t *before, const coral_timestamp_t *after,
    int *errorp, int i, int indx, const char *dir)
{
    int correctable;
    struct timespec before_ts, after_ts;
    
    correctable = iface->holding || !iface->u.blk.blk_count;
    iface->clock.correction = 0;

    coral_diag(correctable ? 1 : 0, (
	"%s %s clock discontinuity at iface %d, blk %ld, cell %d",
	correctable || coral_config.flags & CORAL_OPT_IGNORE_TIME_ERR ?
	    "warning:" : "uncorrectable",
	dir, iface->id, iface->u.blk.blk_count, i));

    if (coral_config.flags & CORAL_OPT_IGNORE_TIME_ERR) {
	/* do nothing */
    } else if (correctable) {
	uint32_t discarded = 0;
	/* discard all queued blocks */
	while (iface->u.blk.node.data) {
	    discarded += iface->u.blk.node.cell_count - iface->u.blk.node.index;
	    coral_dequeue_block(iface);
	}
	/* discard beginning of this block */
	discarded += i - indx;
	indx = i;
	coral_diag(1, ("; discarded %d cells", discarded));
    } else {
	*errorp = CORAL_EBADTIME;
    }

    coral_diag(correctable ? 1 : 0, ("\n"));

    if (coral_verbosity >= 1) {
	coral_fatm_oclock_timespec(iface, before, &before_ts);
	coral_fatm_oclock_timespec(iface, after, &after_ts);
	coral_diag(1, ("\t[%ld.%09ld (0x%08x %04x) to "
	    "%ld.%09ld (0x%08x %04x)]\n",
	    before_ts.tv_sec, before_ts.tv_nsec, before->i[0], before->i[1], 
	    after_ts.tv_sec, after_ts.tv_nsec, after->i[0], after->i[1]));
    }
    return indx;
}

/* When the FATM hardware clock wraps, it interrupts the firmware, which
 * increments the firmware clock.  But several cells may arrive before the
 * firmware handles the interrupt, so they will have incorrect timestamps.
 * We try to correct that here.
 * Also, NLANR traces may have multiple timestamp discontinuities, and all
 * cells before the last one are corrupt.  The last one may occur up to ~14.4s
 * into the trace.  So we buffer blocks until we've seen 16s of cells,
 * discarding everything whenever we see a discontinuity.  A discontinuity can
 * be a negative jump of any size, or a large positive jump.
 */
static int fatm_correct_clock(coral_iface_t *iface,
    coral_blk_info_t *binfo, coral_atm_cell_t *vcell)
{
    int i, count;
    int indx;	/* new start point of block */
    int start;	/* start of slope segment */
    int error = 0;
    coral_timestamp_t to; /* ordered timestamp: 0 firmware, 1 hardware */
    coral_timestamp_t first_to, rise;	/* for calculating average slope */
    uint32_t max_diff_fw, run;		/* for calculating average slope */
    coral_fatm_atm_cell_t *cell = vcell;
    coral_timestamp_t last_to, orig_last_to;

    if (coral_config.flags & CORAL_OPT_FATM_RAW_TIME)
	return 0;

    /*
     * 1 cell at OC3:		    2.831 us
     * 65536 byte pdu at OC3:	 3867.515 us
     * 1 FATM sw tick:		    0.040 us
     * 1 FATM fw tick:		 2621.440 us
     * 1 nlanr fatm blk at OC3:	49285.470 us
     */

    orig_last_to = iface->clock.last_to;
    last_to = orig_last_to;
    count = ntohl(binfo->cell_count);
    rise.i[0] = 0;
    rise.i[1] = 0;
    run = 0;
    start = 0;
    indx = 0;

    for (i = 0; i < count; i++) {
	fatm_clock_order(iface, &cell[i].t, &to);
	if (i == 0)
	    first_to = to;

	/* note: (to.i[0] == last_to.i[0] && to.i[1] < last_to.i[1]) is
	 * considered a failed increment, not a negative discontinuity.
	 */
	if (to.i[0] < last_to.i[0]) {
	    iface->clock.correction = 0;
	    indx = handle_discontinuity(iface, &last_to,
		&to, &error, i, indx, "negative");
	    /* accumulate slope of segment ending here. */
	    fatm_clock_sum(&rise, &last_to, &rise);
	    fatm_clock_diff(&rise, &first_to, &rise);
	    first_to = to;
	    run += i - 1 - start;
	    start = i;

	} else {
	    /* If hw wrapped, increment correction. */
	    if (to.i[1] < last_to.i[1]) {
		iface->clock.correction++;
	    }
	    /* If fw increased, subtract the delta from the correction. */
	    if (to.i[0] > last_to.i[0]) {
		iface->clock.correction -=
		    (to.i[0] - last_to.i[0]);
		if (iface->clock.correction < 0)
		    iface->clock.correction = 0;
	    }
	    if (iface->holding &&
		to.i[0] > MAX_HOLD / (FORE_OC3_SEC_PER_TICK * 0x10000))
	    {
		iface->holding = 0;
		coral_diag(18, ("iface %d: done holding\n", iface->id));
	    }
	}
	/* remember values */
	last_to = to;
	/* add correction */
	if (iface->clock.correction) {
	    to.i[0] += iface->clock.correction;
	    if (iface->iface_info.time_is_le) {
		cell[i].t.i[1] = crl_htolel(to.i[0]);
	    } else {
		cell[i].t.i[0] = crl_htobel(to.i[0]);
	    }
	}
    }

    if (indx < count) {
	/* accumulate slope of last segment */
	fatm_clock_sum(&rise, &last_to, &rise);
	fatm_clock_diff(&rise, &first_to, &rise);
	run += count - 1 - start;
	/* XXX parameters should be configurable */
	max_diff_fw = 8 * (rise.i[0] + 1) / run + 33;
	coral_diag(19, ("rise=%d, run=%d, max_diff_fw=%d\n",
	    rise.i[0], run, max_diff_fw));

	/* search for positive discontinuities within last valid segment or
	 * this block, whichever is smaller
	 */
	if (indx == 0) {
	    last_to = orig_last_to; /* last timestamp of previous block */
	} else {
	    last_to.i[0] = 0;
	    last_to.i[1] = 0;
	}
	for (i = indx; i < count; i++) {
	    fatm_clock_order(iface, &cell[i].t, &to);
	    if ((last_to.i[0] || last_to.i[1]) &&
		(to.i[0] > last_to.i[0]) &&
		(to.i[0] - last_to.i[0] > max_diff_fw))
	    {
		indx = handle_discontinuity(iface, &last_to,
		    &to, &error, i, indx, "positive");
	    }
	    last_to = to;
	}
    }

    iface->clock.last_to = last_to; /* remember for next block */
    errno = error;
    return indx;
}

static void fatm_iface_init(coral_iface_t *iface)
{
    iface->time_is_normal = 0;
    iface->holding =
	iface->src->type.coral_type == CORAL_TYPE_FILE &&
	!(coral_config.flags &
	    (CORAL_OPT_IGNORE_TIME_ERR | CORAL_OPT_FATM_RAW_TIME));
}


#define IFACE_TYPE fatm
#include "coral_atm.h"


const coral_iface_type_t coral_iface_type_fatm = {
    OLD_CELL_LAYOUT,
    "fatm",
    CORAL_API_BLOCK | CORAL_API_CELL | CORAL_API_PKT,
    fatm_iface_init,
    fatm_clock_order,
    NULL /* clock_read_double */,
    coral_fatm_clock_timespec,
    fatm_correct_clock,
    NULL /* clock_native */,
    coral_cell_consume,
    coral_atm_consume_pkt,
    coral_fatm_atm_prep_pkt,
    NULL /* update_pkt_stats */,
    coral_atm_iface_close,
    { { CORAL_RX, 48 }, KBPS_OC3c, CORAL_PHY_ATM, CORAL_DLT_ATM_RFC1483,
	NULL /* determined dynamically from iomode */ }
};

