/* Versions of math functions that take integers, to avoid ambiguity in
 * functions that are overloaded on some platforms. */

#ifndef INTMATH_H
#define INTMATH_H
inline double sqrt(int n) { return sqrt(static_cast<double>(n)); }
inline double sqrt(unsigned int n) { return sqrt(static_cast<double>(n)); }

inline double log(int n) { return log(static_cast<double>(n)); }
inline double log(unsigned int n) { return log(static_cast<double>(n)); }
#endif /* INTMATH_H */

