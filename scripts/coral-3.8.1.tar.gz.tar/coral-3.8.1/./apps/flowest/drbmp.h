/* 
 * Copyright 2003, 2004, 2005, 2007
 * The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program.  Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

#ifndef DRBMP_H
#define DRBMP_H

#include <memory>
#include <cmath>
#include <stdexcept>
#include "intmath.h"
#include "poolallocator.h"

template<class tag, class Key> class DirectBmp {
    typedef Bitmap<tag> BMP_t;
    BMP_t bmp;

public:
    friend class Param;
    class Param {
	friend class DirectBmp;
	unsigned b;
	mutable PoolAllocator alloc;
    public:
	Param(unsigned pb);
	Param(uint64_t N, double E);
	void init(uint64_t N);
	unsigned nbits() const { return b; }
	size_t varbytes() const { return BMP_t::bytes(); }
	size_t bytes() const { return varbytes(); }
	void stats() const { alloc.stats(); }
	static double err(double rho, unsigned pb)
	    { return sqrt(exp(rho) - rho - 1) / (rho * sqrt(pb)); }
	std::string namestr() const { return "DirectBmp::Param"; }
	std::string paramstr() const
	{
	    char buf[64]; // XXX Someday, stringstream is the way to go here
	    std::string ret_val;
	    sprintf(buf, "b=%u", b);
	    ret_val += buf;
	    return ret_val;
	}
    };

    static const Param *p;

    void setmagic() { bmp.setmagic(); }

    void *operator new(size_t size)
    {
	void *ptr = p->alloc();
	(static_cast<DirectBmp*>(ptr))->setmagic();
	return ptr;
    }

    void operator delete(void *ptr, size_t size) { p->alloc.free(ptr); }
    DirectBmp() : bmp() {}
    DirectBmp & reset() { bmp.reset(); return *this; }
    DirectBmp & set(Key key) { bmp.set(key % p->b); return *this; }
    bool test(Key key) { return bmp.test(key % p->b); }
    static double estimate(unsigned b, unsigned z) { return b * log(double(b)/z); }
    double estimate() const { return estimate(p->b, bmp.nzero()); }
    unsigned count() const { return bmp.count(); }
};

template<class tag, class Key> void DirectBmp<tag, Key>::Param::init(uint64_t N)
{
    BMP_t::nbits = nbits();
    alloc = PoolAllocator(bytes(), alignmentof(DirectBmp));
}

template<class tag, class Key> DirectBmp<tag, Key>::Param::Param(unsigned pb)
    : b(pb)
{
    if (b<=1)
	throw std::domain_error("DirectBmp b must be > 1");
    init(2*b); // XXX ???
}

template<class tag, class Key> DirectBmp<tag, Key>::Param::Param(uint64_t N, double E)
{
    if (E >= 1.0)
	throw std::domain_error("DirectBmp error must be < 1.0");
    // Since the drbmp must be 32-bit aligned, there's no point in trying sizes
    // that aren't multiples of 32.
    for (b = 32; b < N; b += 32) {
	if (err(double(N)/b, b) <= E) break;
    }
    init(N);
}

template<class tag, class Key> const typename DirectBmp<tag, Key>::Param *DirectBmp<tag, Key>::p = 0;

#endif // DRBMP_H
