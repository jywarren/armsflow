#!/usr/local/bin/perl -w
## 
## Copyright 2006, 2007 The Regents of the University of California 
## All Rights Reserved 
## 
## Permission to use, copy, modify and distribute any part of this
## CoralReef software package for educational, research and non-profit
## purposes, without fee, and without a written agreement is hereby
## granted, provided that the above copyright notice, this paragraph
## and the following paragraphs appear in all copies.
## 
## Those desiring to incorporate this into commercial products or use
## for commercial purposes should contact the Technology Transfer
## Office, University of California, San Diego, 9500 Gilman Drive, La
## Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
## 
## IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
## PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
## DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
## SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
## THE POSSIBILITY OF SUCH DAMAGE.
## 
## THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
## UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
## SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
## OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
## OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
## TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
## PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
## ANY PATENT, TRADEMARK OR OTHER RIGHTS.
## 
## The CoralReef software package is developed by the CoralReef
## development team at the University of California, San Diego under
## the Cooperative Association for Internet Data Analysis (CAIDA)
## Program. Support for this effort is provided by the CAIDA grant
## NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
## N66001-01-1-8909, and by CAIDA members.
## 
## Report bugs and suggestions to coral-bugs@caida.org.
## 

use strict;

use Getopt::Std;
use vars qw($opt_t $opt_i $opt_b);

my $coral_dir;
BEGIN { $coral_dir = "/usr/local/Coral"; } # This will be edited during build.
use lib "$coral_dir/lib"; #coral global libdir#
use lib "../../lib"; #coral local libdir#
use CAIDA::Traffic2::FileReader;
use CAIDA::Traffic2::FileWriter;

$| = 1;                 # don't buffer output

my ($pname) = $0 =~ m#([^/]+)$#;

if (!getopts("tib") or @ARGV != 0) {
    print STDERR "Usage: crl_flow {crl_flow_options} | ",
				"$pname {${pname}_options}\n",
	    "   Or: $pname {${pname}_options} < file.t2\n",
	    "${pname} options:\n",
	    "-t outputs timestamp information for each entry.\n",
	    "-i merges interfaces in addition to subinterfaces.\n",
	    "-b outputs tables in binary format.\n",
	    "";
    exit 1;
}

if (not defined $opt_t) { $opt_t = 0; }

my $reader = new CAIDA::Traffic2::FileReader(*STDIN)
					    or die "Cannot understand input";
my $writer = new CAIDA::Traffic2::FileWriter(*STDOUT, $opt_b);

while (my $interval = $reader->get_next_interval('preload')) {
    my %new_subifs;
    my $new_int = new CAIDA::Traffic2::Interval;
    $new_int->set_metadata('start', $interval->get_metadata('start'));
    $new_int->set_metadata('end', $interval->get_metadata('end'));
    $new_int->set_metadata('duration', $interval->get_metadata('duration'));
    $new_int->set_metadata('file', $interval->get_metadata('file'));
    $new_int->set_metadata('ip', $interval->get_metadata('ip'));
    $new_int->set_metadata('non-ip', $interval->get_metadata('non-ip'));
    $new_int->set_metadata('dropped pdu', $interval->get_metadata('dropped pdu'));
    $new_int->set_metadata('dropped pkt', $interval->get_metadata('dropped pkt'));
    foreach my $id_info ($interval->get_id_infos()) {
	my $id = $id_info->get_metadata('id');
	if ($opt_i) {
	    $id = 0;
	} elsif ($id =~ /(\d+)\[\d+\]/) {
	    $id = $1;
	}
	unless (exists $new_subifs{$id}) {
	    $new_subifs{$id} = new CAIDA::Traffic2::SubinterfaceInfo;
	}
	$new_subifs{$id}->add($id_info);
    }
    foreach my $id (keys %new_subifs) {
	# add overwrites the 'id' field with whatever is being added.
	$new_subifs{$id}->set_metadata('id', $id);
    }
    $new_int->set_metadata('id info', \%new_subifs);
    $new_int->set_metadata('ids', [sort keys %new_subifs]);
    $writer->initialize($new_int);
    $writer->dump_interval_full($opt_t);
}
