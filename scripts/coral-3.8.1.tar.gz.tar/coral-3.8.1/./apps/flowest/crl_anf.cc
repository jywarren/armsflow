/* 
 * Copyright 2004, 2007 The Regents of the University of California
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */
/*
 * $Id: crl_anf.cc,v 1.30 2007/06/06 18:17:28 kkeys Exp $
 */
/*
 * NetFlow-like system with adaptive sampling probability
 */

static const char RCSid[]="$Id: crl_anf.cc,v 1.30 2007/06/06 18:17:28 kkeys Exp $";

#include "config.h"
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <cstddef>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <sys/time.h>
#include <time.h>
#include <sys/errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <signal.h>
#include <errno.h>
#include <stdexcept>

#include <netinet/in.h>
#include <netinet/in_systm.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>
#include <netinet/ip_icmp.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/resource.h> // getrusage

#include "libcoral.h"
#include "crl_byteorder.h"
#include "hashtab.h"

#include <utility>
#if defined(HAVE_HASH_MAP)
# include <hash_map>
#elif defined(HAVE_EXT_HASH_MAP)
# include <ext/hash_map>
#else
# error "Cannot build without hash_map"
#endif
#include "h3.h"
#include "poolallocator.h"
#include "alignmentof.h"

#undef NDEBUG
#include <assert.h>

//#define OUTPUT_VERSION "1.1"
#define OUTPUT_VERSION "1.2"	    // fixed renormalization of flow's syn flag

// Hack: key bits and counter bits are mixed into a single byte on output
// so existing CoralReef table readers didn't need to be modified to read
// a new counter column.
#define PORTS_NONE   0x00 // port fields are not valid
#define PORTS_LEGACY 0x01 // dport and sport have valid values (old format ONLY)
#define PORTS_DPORT  0x02 // dport is a valid dst port
#define PORTS_SPORT  0x04 // sport is a valid src port
#define PORTS_PORTS  (PORTS_SPORT | PORTS_DPORT)
#define PORTS_OTHER  0x08 // "ports" are really other proto-dependent values
			  // (icmp: type/code)

#if !PATH_MAX
# define PATH_MAX 1024
#endif

using namespace std;
#ifdef HAVE_EXT_HASH_MAP // XXX Hackery in assuming ext/hash_map is GCC 3.x
using namespace __gnu_cxx;
#endif


class SampProb {
public:
//    uint32_t d; // denominator
    double d; // denominator

    SampProb(uint32_t pd = 1) : d(pd) {};

    operator double() { return 1.0 / double(d); }
    // don't define conversion to integer, to avoid accidents

    bool operator== (const SampProb &b) const { return d == b.d; }
    SampProb& operator*= (const SampProb &b) { d *= b.d; }
    SampProb& operator/= (uint32_t &i) { d *= i; }
};

inline SampProb operator* (const SampProb &a, const SampProb &b) {
    SampProb r = a;
    return r *= b;
}

inline SampProb operator/ (const SampProb &a, uint32_t i) {
    SampProb r = a;
    return r /= i;
}



typedef uint64_t tuple_hashval_t;
#define PRIxTUP PRIx64

typedef uint64_t flow_t;

static const char *hostname(const struct in_addr *addr);

class Procstats
{
    const char *firstheap;
    const char *lastheap;
    struct timeval firstcpu, lastcpu;
public:
    Procstats() {
	firstheap = lastheap = (char*)sbrk(0);
	lastcpu.tv_sec = 0;
	lastcpu.tv_usec = 0;
    }
    ~Procstats() {
#ifndef NDEBUG
	(*this)("end app");
#endif
    }
    void operator()(const char *label) {
	struct timeval cpu, cpudiff;
	if (coral_verbosity < 2) return;
	struct rusage ru;
	const char *thisheap = (char*)sbrk(0);
	getrusage(RUSAGE_SELF, &ru);
	timeradd(&ru.ru_utime, &ru.ru_stime, &cpu);
	coral_printf("# %s: heap %ld KB, cpu %ld.%03lds ",
	    label, (thisheap - firstheap) / 1024, cpu.tv_sec, cpu.tv_usec/1000);
	timersub(&cpu, &lastcpu, &cpudiff);
	coral_printf("(+%ld KB, +%ld.%03lds)\n",
	    (thisheap - lastheap) / 1024, cpudiff.tv_sec, cpudiff.tv_usec/1000);
	lastheap = thisheap;
	lastcpu = cpu;
    }
    void mem(const struct timespec *ts);
} procstats;

struct config {
    double dinterval;
    double E;
    u_int netmask;
    SampProb pkt_prob;
    SampProb byte_prob;
    SampProb flow_prob;
    size_t report_size;
    size_t normal_size;
    size_t max_size;
    u_char mem;
    int normalizer_pkts;
    int normalizer_entries;
    u_char adapt_sampling;
//    u_char sampling; // XXX not currently used --rkoga
    u_char flow_counting;
    u_char output_syn;
    u_char normalize_immediately;
    u_char cnames;
    u_char stats;
    u_char binary;
    u_char pretty;  /* non-pretty isn't needed if apps can read pretty format */
    u_char rotate_files;
//    u_char skip_ephemeral_ports; // XXX not currently used --rkoga
//    u_char est_prec; // XXX not currently used --rkoga
    const char *outfilename;
    coral_rotfile_t *rf;
    FILE *file;
} config;

struct {
    double ipbytes;
    double notIP;
    coral_pkt_stats_t *pkt_stats;
    double begin;
    double end;
} interval_data;

#define VPVC_HASH_TABLE_SIZE	229
#define FLOW_HASH_TABLE_SIZE	199999
#define TUPLE_HASH_TABLE_SIZE	1999999		// TUPLE

// assuming random() generates at least [0, 2^31-1], we mask it off to
// exactly [0, 2^31-1]
const uint32_t RAND_MASK = 0x7FFFFFFFul;
const uint32_t RAND_RANGE = 0x80000000ul;

const unsigned PKT_BKTS = 32;

struct subif_stats;

struct tuple_key {
    static const char *fmt_lheader, *fmt_rheader;
    static const char *fmt_addr, *fmt_right;
    struct in_addr src, dst;
    uint16_t sport;
    uint16_t dport;
    uint8_t proto;
    uint8_t ports_ok;

    bool operator== (const tuple_key &b) const
    {
	return
	    src.s_addr == b.src.s_addr &&
	    dst.s_addr == b.dst.s_addr &&
	    sport == b.sport && dport == b.dport &&
	    proto == b.proto && ports_ok == b.ports_ok;
    }

    static void header()
    {
	fprintf(config.file, fmt_lheader, "src     ", "dst     ");
	fprintf(config.file, fmt_rheader, "pro", "ok", "sport", "dport");
    }

    void dump_text() const
    {
	fprintf(config.file, fmt_addr, hostname(&src));
	fprintf(config.file, fmt_addr, hostname(&dst));
	fprintf(config.file, fmt_right,
	    proto, ports_ok, sport, dport);
    }

    void dump_binary() const
    {
        uint8_t length = sizeof(src) + sizeof(dst) + sizeof(proto) +
	    sizeof(ports_ok) + sizeof(sport) + sizeof(dport);
        uint8_t full_save = 0; // there are no first and latest timestamps
        uint16_t nsport = htons(sport);
        uint16_t ndport = htons(dport);
        fwrite(&length, sizeof(length), 1, config.file);
        fwrite(&full_save, sizeof(full_save), 1, config.file);
        fwrite(&src, sizeof(src), 1, config.file);
        fwrite(&dst, sizeof(dst), 1, config.file);
        fwrite(&proto, sizeof(proto), 1, config.file);
        fwrite(&ports_ok, sizeof(ports_ok), 1, config.file);
        fwrite(&nsport, sizeof(nsport), 1, config.file);
        fwrite(&ndport, sizeof(ndport), 1, config.file);
    }
};

template<class T>
struct tuple_key_hash {
    const H3<T, 13> h;
    tuple_key_hash() : h() {};

    T operator()(const tuple_key &key) const
    {
	return h(&key, 13, 0); // ports_ok wouldn't help much, so skip it
    }
};

static const tuple_key_hash<tuple_hashval_t> tuple_hash;

#ifdef HAVE_EXT_HASH_MAP // XXX Hackery in assuming ext/hash_map is GCC 3.x
namespace __gnu_cxx {
#endif
template<> struct hash<tuple_key> {
    size_t operator()(const tuple_key & key) const
    {
	return /* (size_t)(key.parent) ^ */ // XXX must include if/subif
	    ((size_t)(key.src.s_addr) * 59) ^
	    ((size_t)(key.dst.s_addr)) ^
	    ((size_t)(key.sport) << 16) ^
	    ((size_t)(key.dport)) ^
	    ((size_t)(key.proto));
    }
};
#ifdef HAVE_EXT_HASH_MAP // XXX Hackery in assuming ext/hash_map is GCC 3.x
}
#endif

const char *fmt_dataheader, *fmt_data;
const char *tuple_key::fmt_lheader, *tuple_key::fmt_rheader;
const char *tuple_key::fmt_addr, *tuple_key::fmt_right;


// calculates floor(log2(x)) fairly efficiently
inline int flog2(uint32_t x) {
    int r = 0;
#define TEST(m,e) if (x & m) {x &= m; r += e;} else {x &= ~m;}
    TEST(0xFFFF0000ul, 16)
    TEST(0xFF00FF00ul, 8)
    TEST(0xF0F0F0F0ul, 4)
    TEST(0xCCCCCCCCul, 2)
    TEST(0xAAAAAAAAul, 1)
#undef TEST
    return r;
}

// calculates floor(log2(x)) fairly efficiently
inline int flog2(uint64_t x) {
    int r = 0;
#define TEST(m,e) if (x & m) {x &= m; r += e;} else {x &= ~m;}
    TEST(0xFFFFFFFF00000000ull, 32)
    TEST(0xFFFF0000FFFF0000ull, 16)
    TEST(0xFF00FF00FF00FF00ull, 8)
    TEST(0xF0F0F0F0F0F0F0F0ull, 4)
    TEST(0xCCCCCCCCCCCCCCCCull, 2)
    TEST(0xAAAAAAAAAAAAAAAAull, 1)
#undef TEST
    return r;
}

// ceil(log2(x))
inline uint32_t clog2(uint32_t x) { return flog2(x - 1) + 1; }
inline uint64_t clog2(uint64_t x) { return flog2(x - 1) + 1; }

struct flow_data; // forward declaration

// hash_map plus sampling probabilities for packet counting synopsis
template <class Key, class Data, class HashFcn = hash<Key>, class EqualKey = equal_to<Key> >
class Flowtab : public hash_map<Key, Data, HashFcn, EqualKey>
{
    friend struct flow_data;

    typedef hash_map<Key, Data, HashFcn, EqualKey> HM;
    Flowtab operator=(const Flowtab& x)
    {
	coral_diag(1, ("Flowtab error, copy constructor not implemented\n"));
	abort();
//	throw NotImplemented;  // Where is NotImplemented defined?
    }
    SampProb _pkt_prob, _byte_prob, _flow_prob;
    uint32_t _psampn;
    tuple_hashval_t _fsampthresh;

    void init()
    {
	_psampn = random() % (uint32_t)_pkt_prob.d; // random starting offset
	for (unsigned i = 0; i < PKT_BKTS; i++) pbkt[i].hist = 0;
	// Fine to convert double to int here, because the user can only
	// specify an integer denominator by this point. --rkoga
	_fsampthresh = tuple_hashval_t(~(tuple_hashval_t)0 /
				    (tuple_hashval_t)_flow_prob.d);
    }

/* XXX Not currently used. --rkoga
    struct scanner : public unary_function<HM::value_type&, void> {
	uint32_t one, many;
	void operator() (HM::value_type &val) {
	    flow_data *data = val.second;
	    // assert(data->pkt_prob == _pkt_prob);
	    if (data->pkts == 1) one++;
	    else if (data->pkts > 1) many++;
	}
    };
*/
    void clean_flows()
    {
	typename HM::iterator flowit, next;
	for (flowit = this->begin(); flowit != this->end(); flowit = next)
	{
	    next = flowit;
	    ++next;
	    if (!sampleflow(flowit->first)) {
		delete flowit->second;
		erase(flowit);
	    }
 	}
    }

    struct {		// information about entries with a given number of pkts
	uint64_t hist;	// histogram: number of entries with this many pkts
	uint64_t fmean;	// normalizer: floor of mean of distribution
	uint64_t total;	// normalizer: # of entries tested 
	uint64_t inc;	// normalizer: # of entries incremented
	uint32_t rem;	// normalizer: remainder
    } pbkt[PKT_BKTS];

    bool normalizing;
    int normalizer_pkts;
    int normalizer_tested;
    int normalizer_zeroed;
    typename HM::iterator normalizer_it;
    typename HM::iterator normalizer_end;

public:
    Flowtab(SampProb ppkt_prob, SampProb pbyte_prob, SampProb pflow_prob) :
	HM(), _pkt_prob(ppkt_prob), _byte_prob(pbyte_prob),
	_flow_prob(pflow_prob), _psampn(), pbkt(), normalizing(false)
	{ init(); }
    Flowtab(SampProb ppkt_prob, SampProb pbyte_prob, SampProb pflow_prob,
	size_t n) :
	HM(n), _pkt_prob(ppkt_prob), _byte_prob(pbyte_prob),
	_flow_prob(pflow_prob), _psampn(), pbkt(), normalizing(false)
	{ init(); }
    Flowtab(SampProb ppkt_prob, SampProb pbyte_prob, SampProb pflow_prob,
	size_t n, const typename HM::hasher& h) :
	HM(n,h), _pkt_prob(ppkt_prob), _byte_prob(pbyte_prob),
	_flow_prob(pflow_prob), _psampn(), pbkt(), normalizing(false)
	{ init(); }
    Flowtab(SampProb ppkt_prob, SampProb pbyte_prob, SampProb pflow_prob,
	size_t n, const typename HM::hasher& h,
	const typename HM::key_equal& k) :
	HM(n,h,k), _pkt_prob(ppkt_prob), _byte_prob(pbyte_prob),
	_flow_prob(pflow_prob), _psampn(), pbkt(), normalizing(false)
	{ init(); }
    Flowtab(SampProb ppkt_prob, SampProb pbyte_prob, SampProb pflow_prob,
	const Flowtab& x) :
	HM(x), _pkt_prob(ppkt_prob), _byte_prob(pbyte_prob),
	_flow_prob(pflow_prob), _psampn(), pbkt(), normalizing(false)
	{ init(); }

    SampProb pkt_prob() { return _pkt_prob; }
    SampProb byte_prob() { return _byte_prob; }
    SampProb pkt_prob(SampProb prob)
	{ _pkt_prob = prob; return _pkt_prob; }
    SampProb byte_prob(SampProb prob)
	{ return _byte_prob = prob; /* XXX */ }
    SampProb flow_prob() { return _flow_prob; }
    SampProb flow_prob(SampProb prob)
	{ _flow_prob = prob; init(); return _flow_prob; }
    bool samplepkt()
	{ if (++_psampn < _pkt_prob.d) return false; _psampn = 0; return true; }
    bool samplebyte()
	{ return false; /* XXX */ }
    bool sampleflow(const Key &key)
	{ return tuple_hash(key) < _fsampthresh; }

    int sizetobucket(uint64_t n) { return n < PKT_BKTS ? n : 0; }

    void adj_pkt_hist(uint64_t n0, uint64_t n1)
    {
	if (n0 > 0) pbkt[sizetobucket(n0)].hist--;
	if (n1 > 0) pbkt[sizetobucket(n1)].hist++;
    }

    uint64_t pkt_est()
    {
	uint64_t pkts = 0;
	for (typename HM::iterator it = this->begin(); it != this->end(); it++){
	    pkts += it->second->pkts;
	}
	return pkts * (uint32_t)_pkt_prob.d;
    }

    uint64_t byte_est()
    {
	uint64_t bytes = 0;
	for (typename HM::iterator it = this->begin(); it != this->end(); it++){
	    bytes += it->second->bytes;
	}
	return bytes * (uint32_t)_pkt_prob.d;
    }

    uint64_t flow_est()
    {
	return (uint64_t)(this->size() * _flow_prob.d);
    }

    void start_normalizer(bool force, uint64_t true_pkts)
    {
	if (!config.adapt_sampling) return;
	if ((force && this->size() > config.report_size) ||
	    (!normalizing && this->size() >= config.normal_size) ||
	    (this->size() >= config.max_size))
	{
	    uint64_t t0;    // reciprocal of old sampling prob
	    uint64_t t1;    // reciprocal of new sampling prob
	    unsigned b;	    // bucket number
	    uint64_t goal;  // # of entries we want to delete
	    uint64_t E;	    // # of entries we expect to delete with current t1
	    uint64_t sum;   // running sum of (pbkt[b].hist * (t1 - b*t0));
	    uint64_t cdf;   // CDF of pbkt[1].hist ... pbkt[b-1].hist

	    // pick new pkt_prob
	    {
		if (config.normalize_immediately) { // XXX debugging
		    static uint64_t old_true_pkts = 0;
		    coral_diag(1, ("starting normalizer: packets: %" PRIu64
			" (+%" PRIu64 ")\n",
			true_pkts, true_pkts - old_true_pkts));
		    old_true_pkts = true_pkts;
		}

#ifndef NDEBUG
		procstats("starting normalizer");
#endif
		goal = this->size() - config.report_size;
		// assert(_pkt_prob.n == 1);
		t0 = (uint32_t)_pkt_prob.d;

		// quickly pick reasonable starting point for t1
		t1 = (pbkt[1].hist < goal * 2) ? t0 * 2 + 1 : t0 + 1;

		// calculate cdf and sum for initial set of buckets
		sum = 0;
		cdf = 0;
		for (b = 1; t0 * b < t1; b++) {
		    sum += (pbkt[b].hist * (t1 - b*t0));
		    cdf += pbkt[b].hist;
		}

		// while we haven't reached goal, update cdf and sum
		uint64_t max_t1 = PKT_BKTS * t0;
		while (sum < goal * t1) {
		    sum += cdf;
		    t1++;
		    assert(t1 < max_t1); // XXX must handle this
		    // t1++ may include one additional bucket
		    if (t0 * b < t1) {
			sum += pbkt[b].hist * (t1 - b*t0);
			cdf += pbkt[b].hist;
			b++;
		    }
		}

		E = uint64_t(sum / double(t1));
		// _pkt_prob.n = 1;
		_pkt_prob.d = t1;
	    }

	    if (normalizing) {
		coral_diag(1, ("normalizer REstarted: size %d, prob %u/%f, "
		    "tested %d, zeroed %d\n", this->size(), 1, _pkt_prob.d,
		    normalizer_tested, normalizer_zeroed)); // XXX
	    } else {
		coral_diag(1, ("normalizer started: size %d, prob %u/%f\n",
		    this->size(), 1, _pkt_prob.d)); // XXX
	    }
	    coral_diag(1, ("normalizer goal %" PRIu64 ", expect %" PRIu64 "\n",
		goal, E)); // XXX
	    coral_diag(1, ("normalizer pkt hist: "));
	    for (b = 1; b < PKT_BKTS; b++)
		coral_diag(1, (" %" PRIu64, pbkt[b].hist));
	    coral_diag(1, (" (%" PRIu64 ")\n", pbkt[0].hist));

	    // start normalizer
	    normalizing = true;
	    normalizer_it = this->begin();
	    normalizer_pkts = config.normalizer_pkts;
	    normalizer_zeroed = 0;
	    normalizer_tested = 0;

	    for (b = 1; b < PKT_BKTS; b++) {
		// NB: integer division
		pbkt[b].fmean = b * t0 / t1;
		pbkt[b].rem = b * t0 % t1;

		// start with random offset into cycle to avoid bias
		pbkt[b].total = random() % t1;
		pbkt[b].inc = pbkt[b].total * pbkt[b].rem / t1;

		coral_diag(1, ("normalizer state: bkt %2d, entries %6" PRIu64
		    ", mean %3" PRIu64 " +%4" PRIu32 "/%f"
		    " (%4" PRIu64 "/%" PRIu64 ")\n",
		    b, pbkt[b].hist,
		    pbkt[b].fmean, pbkt[b].rem, _pkt_prob.d,
		    pbkt[b].inc, pbkt[b].total)); // XXX
	    }
	}
    }

    void run_normalizer(bool to_end);
    void flow_normalizer(bool final)
    {
	double preferred_size;
	if (final) {
	    preferred_size = 1.1 * config.report_size;
	} else {
	    preferred_size = 2.0 * config.report_size;
	}
	if (!config.adapt_sampling || this->size() < preferred_size) return;

	coral_diag(1, ("cleaner start: size %d, prob %u/%f, thresh %"
		PRIxTUP "\n", this->size(), 1, _flow_prob.d, _fsampthresh)); // XXX

	if (final) {
	    _flow_prob.d = _flow_prob.d / (double(config.report_size) / this->size());
	    _fsampthresh = tuple_hashval_t(_fsampthresh *
					double(config.report_size) / this->size());
	} else {
	    _flow_prob.d *= 2;
	    _fsampthresh = _fsampthresh >> 1;
	}

	clean_flows();

	coral_diag(1, ("cleaner done: size %d, prob %u/%f, thresh %"
		PRIxTUP "\n", this->size(), 1, _flow_prob.d, _fsampthresh)); // XXX
    }
};

typedef Flowtab<tuple_key, flow_data*> tuple_tab_t;

typedef uint64_t pktcnt;
typedef uint64_t bytecnt;

struct flow_data {
    pktcnt pkts;	// must be 8-byte aligned on some architectures
    bytecnt bytes;	// must be 8-byte aligned on some architectures
    bool syn;
    SampProb pkt_prob;	// table's pkt_prob when pkt counter was last updated

    flow_data() : pkts(), bytes(), syn(false), pkt_prob() {}
    ~flow_data() {}

    // The obviously correct thing to do would be to effectively resample
    // every packet by calculating a new count with a binomial distribution
    // in (pkts, p); but that's expensive.  Instead, we find the (real) mean
    // of the binomial distribution, and pick the (integer) floor or ceiling
    // of the mean with probability such that the resulting distribution has
    // the same mean.  This is still unbiased, and actually improves variance.
    bool resample(tuple_tab_t *table)
    {
	bool inc;
	pktcnt n = pkts;

	table->normalizer_tested++;
	if (n == 0) {
	    return false; // shouldn't happen
	} else if (n < PKT_BKTS) {
	    // use precalculated mean and increment-ratio
	    table->pbkt[n].total++;
	    pkts = table->pbkt[n].fmean;
	    inc = (table->pbkt[n].inc + 1) * table->pkt_prob().d <=
		table->pbkt[n].total * table->pbkt[n].rem;
	    if (inc) {
		table->pbkt[n].inc++;
		pkts++;
	    }
	} else {
	    // calculate mean and random increment
	    uint32_t t0 = (uint32_t)pkt_prob.d;
	    uint32_t t1 = (uint32_t)table->pkt_prob().d;
	    pkts = n * t0 / t1;
	    inc = (random() % t1) < (n * t0 % t1); // (n*t0 % t1) in t1 odds
	    if (inc)
		pkts++;
	}
	if (config.output_syn && syn) {
	    // odds of keeping syn = # of pkts kept / original # of pkts
	    uint32_t t0 = (uint32_t)pkt_prob.d;
	    uint32_t t1 = (uint32_t)table->pkt_prob().d;
	    for (int i = syn; i > 0; i--) {
		if ((random() % n) >= pkts)
		    syn = false;
	    }
	}

	bytes = bytes * pkts / n;
	pkt_prob = table->pkt_prob();
	table->adj_pkt_hist(n, pkts);
	if (pkts == 0 && bytes == 0) {
	    table->normalizer_zeroed++;
	    return true;
	}
	return false;
    }
};

template <class Key, class Data, class HashFcn, class EqualKey>
void Flowtab<Key, Data, HashFcn, EqualKey>::run_normalizer(bool to_end)
{
    if (normalizing && (to_end || --normalizer_pkts == 0)) {
	int entries = config.normalizer_entries;
	typename HM::iterator flowit;

	for (flowit = normalizer_it; flowit != this->end();
						flowit = normalizer_it)
	{
	    ++normalizer_it;
	    flow_data *data = flowit->second;
	    if (data->pkt_prob != pkt_prob()) {
		if (data->resample(this)) {
		    delete data;
		    erase(flowit);
		}
	    }
	    if (!to_end && --entries == 0) break;
	}

	if (flowit == this->end()) {
	    normalizing = false;
	    coral_diag(1, ("normalizer done: size %d, prob %u/%f, "
		"tested %d, zeroed %d\n", this->size(), 1, _pkt_prob.d,
		normalizer_tested, normalizer_zeroed)); // XXX
#ifndef NDEBUG
	    procstats("normalizer done");
#endif
	} else {
	    normalizer_pkts = config.normalizer_pkts;
	}
    }
}

template<class C> inline void cleartable(C*& c)
{
    typename C::iterator it;
    for (it = c->begin(); it != c->end(); ++it)
	delete it->second;
    c->clear();
    delete c;
    c = NULL;
}

struct subif_stats {
// key
    coral_iface_t *iface;
    u_int iface_id;
    u_int subif_id;

// data
    pktcnt pkts;
    bytecnt bytes;
    pktcnt unknown_encaps;
    pktcnt ip_not_v4;
    tuple_tab_t *tuple_tab;

    subif_stats(coral_iface_t *p_iface, u_int p_iface_id, u_int p_subif_id) :
	iface(p_iface), iface_id(p_iface_id), subif_id(p_subif_id),
	pkts(), bytes(), unknown_encaps(), ip_not_v4(), tuple_tab()
	{}

    void clear() {
	if (tuple_tab) cleartable(tuple_tab);
    }

    ~subif_stats() { clear(); }
};

hash_tab *subif_hash = NULL;

void Procstats::mem(const struct timespec *ts) {
    static const struct subif_stats *subifrec = NULL; // XXX hack, assumes only one subif
    if (!subifrec) {
	init_hash_walk(subif_hash);
	subifrec = (const subif_stats*)next_hash_walk(subif_hash);
    }
    const char *thisheap = (char*)sbrk(0);
    coral_printf("# %ld.%06ld\t%ld\t%ld\n",
	ts->tv_sec, ts->tv_nsec/1000,
	(thisheap - firstheap) / 1024,
	subifrec->tuple_tab->size());
}

int interrupted = 0;
const char rotating_filename[] = "%010s.%f.t2";


/* ---- hash table per subif fxns begin ---- */
/* -- per subif hash table fxns -- */

/* return 0 if the same - for use by the hashtable */
static int compare_subif_stats(const void *entry1, const void *entry2)
{
    const subif_stats *foo1 = (const subif_stats *)entry1;
    const subif_stats *foo2 = (const subif_stats *)entry2;

    return (foo1->subif_id != foo2->subif_id ||
	    foo1->iface_id != foo2->iface_id);
}

/* make a hash of an entry - for use by the hashtable */
static unsigned long make_key_subif_stats(const void *entry)
{
    const subif_stats *what = (const subif_stats *)entry;

    return (unsigned) what->subif_id * 425879 + what->iface_id;
}

/* free mem of an entry - for use by the hashtable */
static void delete_subif_stats(void *entry)
{
    subif_stats *what = (subif_stats *)entry;
    if (!what) return;
    free(what);
}
/* -- end of subif type hash table fxns -- */


/* ---- hash table fxns end ---- */


static void count_packet(subif_stats *subif, coral_iface_t *iface,
    const coral_pkt_buffer_t *netpkt, const coral_timestamp_t *ts,
    uint64_t bytes)
{
    short offset;
    struct ip * ip;
    coral_pkt_buffer_t payload;
    uint16_t sport, dport;
    bool syn = false;
    flow_data *data = 0;
    tuple_tab_t::iterator flowit;

    tuple_key flowid;

    ip = (struct ip*)netpkt->buf;
    offset = ntohs(ip->ip_off) & IP_OFFMASK;

    flowid.src.s_addr = config.netmask & ip->ip_src.s_addr;
    flowid.dst.s_addr = config.netmask & ip->ip_dst.s_addr;
    flowid.proto = ip->ip_p;
    flowid.ports_ok = 0;
    sport = flowid.sport = 0;
    dport = flowid.dport = 0;

    coral_get_payload(netpkt, &payload);
    /* NOT get_payload_by_layer(..., 4); we want the payload, no matter what
     * layer it claims to be.  (Specifically, we don't want to go through
     * IPIP encapsulations.)
     */

    /* extract port info */
    if (offset != 0) {
	// non-first fragment, no layer 4 header
    } else if (ip->ip_p == IPPROTO_TCP) {
	if (payload.caplen >= 4) {
	    struct tcphdr *t = (struct tcphdr*)payload.buf;
	    sport = flowid.sport = ntohs(t->th_sport);
	    dport = flowid.dport = ntohs(t->th_dport);
	    flowid.ports_ok = PORTS_PORTS;
	    syn = !!(t->th_flags & TH_SYN);
	}
    } else if (ip->ip_p == IPPROTO_UDP) {
	if (payload.caplen >= 4) {
	    struct udphdr *u = (struct udphdr*)payload.buf;
	    sport = flowid.sport = ntohs(u->uh_sport);
	    dport = flowid.dport = ntohs(u->uh_dport);
	    flowid.ports_ok = PORTS_PORTS;
	}
    } else if (ip->ip_p == IPPROTO_ICMP) {
	if (payload.caplen >= 2) {
	    struct icmp *icmp = (struct icmp*)payload.buf;
	    flowid.sport = icmp->icmp_type;
	    flowid.dport = icmp->icmp_code;
	    sport = dport = (icmp->icmp_type << 8) | icmp->icmp_code;
	    flowid.ports_ok = PORTS_OTHER;
	}
#if 0
    } else if (ip->ip_p == IPPROTO_IGMP) {
	    ...
	    flowid.sport = igmp->igmp_type;
	    flowid.dport = igmp->igmp_code;
	    flowid.ports_ok = PORTS_OTHER;
#endif
    }

/* XXX Seemingly useless code --rkoga
    if ((flowit = subif->tuple_tab->find(flowid)) != subif->tuple_tab->end()) {
	data = flowit->second;
    }
*/

    bool chosen_sample = false;
    if (config.flow_counting) {
	chosen_sample = subif->tuple_tab->sampleflow(flowid);
    } else {
	chosen_sample = subif->tuple_tab->samplepkt();
    }
    if (!chosen_sample) return;

    flowit = (subif->tuple_tab->insert(
	tuple_tab_t::value_type(flowid, NULL))).first;
    if (flowit->second) {
	// found existing entry
	data = flowit->second;
#if 1
	// about to update an entry that needs renormalizing
	if (data->pkt_prob != subif->tuple_tab->pkt_prob()) {
	    data->resample(subif->tuple_tab);
	}
#endif
    } else {
	// inserted new entry
	flowit->second = data = new flow_data();
	if (config.flow_counting) {
	    subif->tuple_tab->flow_normalizer(false);
	} else {
	    subif->tuple_tab->start_normalizer(false, subif->pkts);
	    if (config.normalize_immediately)
		subif->tuple_tab->run_normalizer(true);
	}
    }
    pktcnt oldpkts = data->pkts++;
    data->pkt_prob = subif->tuple_tab->pkt_prob();
    subif->tuple_tab->adj_pkt_hist(oldpkts, data->pkts);
    data->bytes += bytes;
    if (syn) data->syn = true;

    if (!config.flow_counting)
	subif->tuple_tab->run_normalizer(false);
}

/* NB: returns a pointer to static data */
static const char *hostname(const struct in_addr *addr)
{
    struct hostent *h;
    if (config.cnames &&
	(h = gethostbyaddr((char*)addr, sizeof(struct in_addr), AF_INET)))
    {
	return h->h_name;
    } else {
	return inet_ntoa(*addr);
    }
}

static void dump_binary_flow_table(tuple_tab_t& table)
{
    tuple_tab_t::iterator flowit;

    fputs("#binary data follows\n", config.file);

    for (flowit = table.begin(); flowit != table.end(); ++flowit) {
	if (flowit->second->pkts) {
	    uint64_t pkts = flowit->second->pkts;
	    uint64_t bytes = flowit->second->bytes;
	    uint64_t flows = 1;

	    flowit->first.dump_binary();
	    fwrite(&pkts, sizeof(pkts), 1, config.file);
	    fwrite(&bytes, sizeof(bytes), 1, config.file);
	    fwrite(&flows, sizeof(flows), 1, config.file);
	}
    }
    fwrite("\0", 1, 1, config.file); // table trailer
    fputs("\n# end of binary table\n\n", config.file);

    fflush(config.file);
}

static void dump_text_flow(flow_data *counter,
    uint64_t& total_pkts, uint64_t& total_bytes, uint64_t& total_flows)
{
    unsigned int flows;
    total_pkts += counter->pkts;
    total_bytes += counter->bytes;
    // XXX Generalize this to a separate option later --rkoga
    if (config.flow_counting || !config.output_syn) {
	flows = 1;
    } else {
	flows = counter->syn;
    }
    fprintf(config.file, fmt_data, counter->pkts, counter->bytes, flows);
    if (total_flows >= 0) total_flows++;
}

static void dump_text_flow_table(tuple_tab_t& table)
{
    tuple_tab_t::iterator flowit;
    uint64_t total_pkts = 0, total_bytes = 0, total_flows = 0;

    tuple_key::header();
    fprintf(config.file, fmt_dataheader, "pkts", "bytes", "flows");

    for (flowit = table.begin(); flowit != table.end(); ++flowit) {
	flowit->first.dump_text();
	dump_text_flow(flowit->second, total_pkts, total_bytes, total_flows);
    }
    fprintf(config.file, "# pkts=%" PRIu64 " bytes=%" PRIu64,
	total_pkts, total_bytes);
    fprintf(config.file, " flows=%" PRIu64 "\n", total_flows);
    fputs("# end of text table\n\n", config.file);

    fflush(config.file);
}

static void dump_flow_table(const subif_stats *subifrec,
    tuple_tab_t& table, const char *label)
{
    if (table.empty()) return;
    char buf[32];
    coral_fmt_if_subif(buf, subifrec->iface, subifrec->subif_id);

    // before "# begin" line to avoid choking parser
    // tuple_key::notes();
    if (!config.flow_counting) {
	fprintf(config.file, "# initial pkt sample prob: %u/%f\n",
	    1, config.pkt_prob.d);
#if 0
    fprintf(config.file, "# initial byte sample prob: %u/%f\n",
	1, config.byte_prob.d);
#endif
    } else {
	fprintf(config.file, "# initial flow sample prob: %u/%f\n",
	    1, config.flow_prob.d);
    }
    if (config.adapt_sampling) {
	if (!config.flow_counting) {
	    fprintf(config.file, "# final pkt sample prob: %u/%f\n",
		1, table.pkt_prob().d);
#if 0
	fprintf(config.file, "# final byte sample prob: %u/%f\n",
	    1, table.byte_prob().d);
#endif
	} else {
	    fprintf(config.file, "# final flow sample prob: %u/%f\n",
		1, table.flow_prob().d);
	}
    }
    if (config.output_syn) {
	fprintf(config.file, "# TCP SYN in flow column\n");
    }
    fprintf(config.file, "# begin %s Table ID: %s (%d entries)\n", label, buf,
			    table.size());
    if (config.binary) {
	dump_binary_flow_table(table);
    } else {
	dump_text_flow_table(table);
    }
}

/* 
 * keep track of some subif related stats, and count_packet().
 */
static void count_subif_stats(coral_iface_t *iface,
    coral_pkt_result_t *pkt_result)
{
    subif_stats *subifrec;
    subif_stats tmp(iface, coral_interface_get_number(iface), pkt_result->subiface);
    coral_pkt_buffer_t netpkt;
    struct ip *ip;

    if (!(subifrec = (subif_stats*)find_hash_entry(subif_hash, &tmp))) {
	subifrec = new subif_stats(tmp.iface, tmp.iface_id, tmp.subif_id);
	if (subifrec == NULL) {
	    fprintf(stderr, "can't allocate subif_stats.\n");
	    abort();
	}
	subifrec->tuple_tab = new tuple_tab_t(config.pkt_prob,
	    config.byte_prob, config.flow_prob, config.max_size);
        add_hash_entry(subif_hash, subifrec);
#ifndef NDEBUG
	procstats("init hash");
#endif
    }

    if (coral_get_payload_by_layer(pkt_result->packet, &netpkt, 3) < 0) {
	subifrec->unknown_encaps++;
	return;
    }

    if (!coral_proto_is_IP(netpkt.protocol)) {
	interval_data.notIP++;
	return;
    }

    ip = (struct ip*)netpkt.buf;
    if (ip->ip_v != 4) {
	subifrec->ip_not_v4++;
	return;
    }

    /* do stats --- */
    uint64_t bytes = ntohs(ip->ip_len);
    subifrec->pkts++;
    subifrec->bytes += bytes;
    interval_data.ipbytes += bytes;
    count_packet(subifrec, iface, &netpkt, pkt_result->timestamp, bytes);
}

static void init_hashes(void)
{
    subif_hash = init_hash_table("# subif hash",
			       compare_subif_stats, make_key_subif_stats,
			       delete_subif_stats, VPVC_HASH_TABLE_SIZE);
}


static void dump_hash_stats(void)
{
    dump_hashtab_stats(subif_hash);
}

static void dump_data(void)
{
    const subif_stats *subifrec;
    double begin;
    double end;
    int count;

    begin = interval_data.begin;
    end = interval_data.end;

    /* Normal (possibly empty) interval */
    fprintf(config.file, "\n# begin trace interval: %f\n", begin);
    fprintf(config.file, "# trace interval duration: %f s\n"
		    "# Layer 2 PDUs dropped: %" PRIu64 "\n"
		    "# IP: %.4f Mbit/s\n"
		    "# Non-IP: %.4f pkts/s\n",
	(end - begin), 
	interval_data.pkt_stats->l2_drop,
	interval_data.ipbytes * 8 / (1000 * 1000 * (end - begin)),
	interval_data.notIP/(end - begin));

    fputs("# Table IDs: ", config.file);
    init_hash_walk(subif_hash);
    count = 0;
    while ((subifrec = (const subif_stats*)next_hash_walk(subif_hash))) {
	if (subifrec->tuple_tab ||
	    subifrec->unknown_encaps || subifrec->ip_not_v4)
	{
	    char buf[32];
	    if (count++)
		fputs(", ", config.file);
	    coral_fmt_if_subif(buf, subifrec->iface, subifrec->subif_id);
	    fprintf(config.file, "%s", buf);
	}
    }
    fputs("\n\n", config.file);

    init_hash_walk(subif_hash);
    while ((subifrec = (const subif_stats*)next_hash_walk(subif_hash))) {
	if (subifrec->tuple_tab ||
	    subifrec->unknown_encaps || subifrec->ip_not_v4)
	{
	    if (config.flow_counting) {
		// XXX resample to EXACTLY the right size (not half)
		subifrec->tuple_tab->flow_normalizer(true);
	    } else {
		// finish normalization in progress, if any
		subifrec->tuple_tab->run_normalizer(true);

		// normalize to get the requested number of entries
		subifrec->tuple_tab->start_normalizer(true, subifrec->pkts);
		subifrec->tuple_tab->run_normalizer(true);
	    }
	    char buf[32];
	    coral_fmt_if_subif(buf, subifrec->iface, subifrec->subif_id), 
	    fprintf(config.file, "# ID: %s\n"
		    "# unknown_encaps: %" PRIu64 "\n"
		    "#      ip_not_v4: %" PRIu64 "\n",
		    buf,
		    subifrec->unknown_encaps,
		    subifrec->ip_not_v4);
	    if (subifrec->pkts > 0) {
		fprintf(config.file, "#           pkts: %" PRIu64 "\n",
		    subifrec->pkts);
		if (!config.flow_counting) {
		    fprintf(config.file, "#       est pkts: %" PRIu64 "\n",
			subifrec->tuple_tab->pkt_est());
		}
		fprintf(config.file, "#          bytes: %" PRIu64 "\n",
		    subifrec->bytes);
		if (!config.flow_counting) {
		    fprintf(config.file, "#      est bytes: %" PRIu64 "\n",
			subifrec->tuple_tab->byte_est());
		}
		fprintf(config.file, "#          flows: 0\n");
		if (config.flow_counting) {
		    fprintf(config.file, "#      est flows: %" PRIu64 "\n",
			subifrec->tuple_tab->flow_est());
		}
		fprintf(config.file,
			"#          first: 0\n"
			"#         latest: 0\n"); // XXX
		fputs("# Table types: Tuple Table\n", config.file);
	    }
	    fputs("\n", config.file); 
	}
    }

    init_hash_walk(subif_hash);
    while ((subifrec = (const subif_stats*)next_hash_walk(subif_hash))) {
	dump_flow_table(subifrec, *subifrec->tuple_tab, "Tuple");
    }
    fputs("# end trace interval\n", config.file);
    fflush(config.file);
}

static void clear_data(void)
{
    subif_stats *subifrec;

    interval_data.ipbytes = 0;
    interval_data.notIP = 0;

    init_hash_walk(subif_hash);
    while ((subifrec = (subif_stats*)next_hash_walk(subif_hash))) {
	subifrec->clear();
    }
    clear_hash_table(subif_hash);
}

static void stop(int sig)
{
    interrupted = 1;
}

int main(int argc, char *argv[])
{
    int retval = 0;
    int i;
    coral_iface_t *iface;
    coral_pkt_result_t pkt_result;
    coral_interval_result_t interval_result;
#   define CIDR_LEN 32
    u_int cidr_len = CIDR_LEN;
    struct timeval interval = { 300, 0 };
    u_int duration;
    int opt;
    int error = 0, first = 1, seeded = 0;
    char file_header[1024], *p;

    config.outfilename = "-"; /* Default to stdout */

    coral_set_api(CORAL_API_PKT);
    coral_set_duration(0);
    coral_set_interval(&interval);
    coral_set_iomode(0, CORAL_RX, 48, 0);
    coral_set_options(0, CORAL_OPT_PARTIAL_PKT | CORAL_OPT_NORMALIZE_TIME);

    config.report_size = 0;
    config.flow_counting = 0;
    config.output_syn = 0;
    config.normalizer_pkts = 8;
    config.normalizer_entries = 24;

    const char *options = "C:p:asBfyhO:o:rS:eM:K:Y:F:mn";

    while (!error && (opt = getopt(argc, argv, options)) != -1) {
	switch (opt) {
	case 'C':
	    if (coral_config_command(optarg) < 0)
		error++;
	    break;
	case 'p':
	    cidr_len = atoi(optarg);
	    if (cidr_len > 32 || cidr_len < 8) {
		fprintf(stderr,
			"%s: valid CIDR prefix lengths are between 8 and 32\n",
			argv[0]);
		error++;
	    }
	    break;
	case 'a':
	    config.cnames = 1;
	    break;
	case 's':
	    config.stats = 1;
	    break;
	case 'B':
	    // XXX Remove when binary output is valid.
	    coral_puts("Binary output is not yet fully supported.");
	    exit(1);
	    config.binary = 1;
	    break;
	case 'f':
//	    config.est_prec = 6;
	    config.flow_counting = 1;
	    break;
	case 'y':
	    config.output_syn = 1;
	    break;
	case 'm':
	    config.mem = 1;
	    break;
	case 'M':
	    config.report_size = atoi(optarg);
	    break;
	case 'S': // XXX
	    seeded++;
	    srandom(atoi(optarg)); // XXX
	    break;
	case 'h':
	    config.pretty = 1;
	    break;
	case 'r':
	    config.rotate_files = 1;
	    config.outfilename = rotating_filename;
	    break;
	case 'O':
	    config.rotate_files = 1;
	    /* fall through */
	case 'o':
	    config.outfilename = strdup(optarg);
	    break;
	case 'K':
	    config.pkt_prob = SampProb(atoi(optarg));
	    break;
#if 0
	case 'Y':
	    config.byte_prob = SampProb(atoi(optarg));
	    break;
#endif
	case 'F':
	    config.flow_prob = SampProb(atoi(optarg));
	    break;
	case 'e': // XXX does nothing --rkoga
//	    config.skip_ephemeral_ports = 1;
	    break;
	case 'n':
	    config.normalize_immediately = 1;
	    break;
	default:
	    error++;
	    break;
	}
    }

    if (error) {
	coral_usage(argv[0], "[<options>] <source>...\n"
	    "Options:\n"
	    "-p<n>      use <n> as length of CIDR prefix (default %d)\n"
	    "-a         resolve IP addresses to hostnames (only makes sense with -p32)\n"
	    "-s         print hash table statistics\n"
//	    "-B         print binary table data\n"
	    "-f         use Flow Counting Extension to sample flows instead of packets\n"
	    "-y         flow column represents if a TCP SYN has been seen (not used with -f)\n"
	    "-h         print human readable table data\n"
	    "-o<file>   specify the name of the output file (default: -)\n"
	    "-r         rotate the output file every interval (requires a filename with\n"
	    "           %% specifiers; the default filename with -r is '%s')\n"
	    "-O<file>   equivalent to -r -o<file>\n\n"
	    "-n         normalize immediately instead of in parallel\n" // XXX
	    "Performance parameters:\n"
#if 0
	    "-e         \"fold\" ephemeral ports\n" // XXX does nothing --rkoga
#endif
	    "-M<n>      report <n> entries\n"
	    "-K<d>      sample 1 out of <d> packets initially\n" // XXX
#if 0
	    "-Y<d>      sample 1 out of <d> bytes initially\n" // XXX
#endif
	    "-F<d>      sample 1 out of <d> flows initially\n" // XXX
	    "Testing:\n"
	    "-m         periodically print memory usage to stderr\n" // XXX
	    "\n"
"    <file> is the name of the output file, which may contain %% specifiers\n"
"    for formatting a timestamp.  For -o, the timestamp is the beginning of\n"
"    the trace; for -O, the timestamp is the beginning of the interval.\n"
"    The %% specifiers are any of those allowed by strftime(), plus:\n"
"        %%s   number of (whole) seconds since 1970-01-01 00:00:00 UTC\n"
"        %%f   fractional part of seconds (6 decimal places)\n"
"        %%F   equivalent to %%Y-%%m-%%d\n"
"    Except for %%f, all specifiers may contain printf-style modifiers\n"
"    (e.g., \"%%010s\").\n"
"    For -o, '-' means standard output.\n",
	    CIDR_LEN,
	    rotating_filename);
	exit(-1);
    }

    config.normal_size = config.report_size * 2;
    config.max_size = config.report_size * 3;
    config.adapt_sampling = (config.report_size > 0);
    if (config.flow_counting) config.output_syn = 0; // potential conflict
    if (!seeded) srandom(time(NULL) ^ getpid()); /* XXX use /dev/random */

    while (optind < argc) {
	if (!coral_new_source(argv[optind]))
	    exit(-1);
	optind++;
    }

    if (!coral_next_source(NULL)) {
	coral_diag(1, ("%s: warning: no sources specified.\n", argv[0]));
    }

    init_hashes();

    /* generate a netmask from the cidr length */
    config.netmask = 0xFFFFFFFF << (32 - cidr_len);

    /* corrected for endianess */
    config.netmask = ntohl(config.netmask);

    if (coral_open_all() <= 0)
	exit(-1);

    if (coral_start_all() < 0)
	exit(-1);

    signal(SIGINT, stop);

    coral_get_interval(&interval);
    config.dinterval = timevaltodouble(&interval);
    interval_data.begin = 0;
    interval_data.end = 0;
    interval_data.pkt_stats = NULL;

    duration = coral_get_duration();
    if (duration)
	coral_diag(2, ("collection duration max set to %d second(s)\n", 
		       duration));

    coral_read_pkt_init(NULL, NULL, &interval);

    p = file_header;
    p += sprintf(p, "# crl_anf output version: %s (%s format)\n",
	    OUTPUT_VERSION,
	    config.binary ? "binary" : config.pretty ? "pretty" : "text" );
    p += sprintf(p, "# generated by: ");
    for (i = 0; i < argc; i++)
	p += sprintf(p, " %s", argv[i]);
    sprintf(p, "\n");

    if (!config.binary) {
        if (!config.pretty) {
            tuple_key::fmt_lheader = "#%s\t%s\t";
            tuple_key::fmt_rheader = "%s\t%s\t%s\t%s\t";
            tuple_key::fmt_addr = "%s\t";
            tuple_key::fmt_right = "%u\t%u\t%u\t%u\t";
            fmt_dataheader = "%s\t%s\t%s\n";
            fmt_data = "%" PRIu64 "\t%" PRIu64 "\t%u\n";
        } else {
            if (config.cnames) {
                tuple_key::fmt_lheader = "#%-29s %-30s ";
                tuple_key::fmt_addr = "%-30s ";
            } else {
                tuple_key::fmt_lheader = "#%-14s %-15s ";
                tuple_key::fmt_addr = "%-15s ";
            }
            tuple_key::fmt_rheader = "%-5s %-2s %5s %5s ";
            tuple_key::fmt_right = "%5u %2u %5u %5u ";
            fmt_dataheader = "%13s %15s %9s\n";
            fmt_data = "%13" PRIu64 " %15" PRIu64 " %9u\n";
        }
    }

    config.rf = coral_rf_open_file(&config.file, config.outfilename, "", 0);
    if (!config.rf)
	exit(1);
#ifndef NDEBUG
    procstats("start loop");
#endif

    while (1) {
	if (interrupted) {
	    coral_stop_all();
	    interrupted = 0;
	}
	iface = coral_read_pkt(&pkt_result, &interval_result);

	if (!iface) {
	    if (errno == EINTR || errno == EAGAIN) continue;
	    retval = errno;
	    break;
	}

	if (!pkt_result.packet && !interval_result.stats) {
	    /* beginning of interval */
#ifndef NDEBUG
	    procstats("start int");
#endif
	    double begin = timevaltodouble(&interval_result.begin);
	    interval_data.begin = begin;
	    if (config.rotate_files || first) {
		coral_rf_start(config.rf, &interval_result.begin);
		fputs(file_header, config.file);
		first = 0;
	    }

	} else if (pkt_result.packet) {
	    /* got packet */
	    count_subif_stats(iface, &pkt_result);
	    if (config.mem) {
		static uint64_t n = 0;
		if (n++ % 10000 == 0) {
		    struct timespec ts;
		    coral_read_clock_timespec(iface, pkt_result.timestamp, &ts);
#ifndef NDEBUG
		    procstats.mem(&ts);
#endif
		}
	    }

	} else if (!pkt_result.packet && interval_result.stats) {
	    /* end of interval */
	    struct timeval tv1, tv2;
#ifndef NDEBUG
	    procstats("end int");
#endif
	    interval_data.end = timevaltodouble(&interval_result.end);
	    interval_data.pkt_stats = interval_result.stats;

	    gettimeofday(&tv1, NULL);

	    dump_data();
	    if (config.rotate_files)
		coral_rf_end(config.rf);
	    clear_data();
	    gettimeofday(&tv2, NULL);
	    timersub(&tv2, &tv1, &tv1);
	    coral_diag(3, ("crl_anf: closed %f s interval in %d.%06d s\n",
		interval_data.end - interval_data.begin,
		tv1.tv_sec, tv1.tv_usec));

	    /* reset the interval time, and other timers */
	    interval_data.begin = 0;
	    interval_data.end = 0;
	    interval_data.pkt_stats = NULL;
	}
    }

    coral_rf_close(config.rf);
    coral_stop_all();

    /* clean up stuff */
    if (config.stats) dump_hash_stats();
#if 0
    clear_hash_table(subif_hash);
    srcip_tab.clear();
    dstip_tab.clear();
#endif

    return retval;
}

