/*
 * Copyright 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

#ifndef CORAL_DAG_H
#define CORAL_DAG_H

#ifdef __cplusplus
extern "C" {
#endif

/* DAG 4 ERF header for POS, ATM, and AAL5 */
typedef struct {
    coral_timestamp_t t;
    uint8_t type;
    uint8_t flags;
    uint16_t rlen; /* record length (dag header + caplen of packet) */
    uint16_t lctr;
    uint16_t wlen; /* wire length (totlen of packet) */
} coral_dag_erf_hdr_t;

/* The DAG 2&3 POS header is compatible with the DAG 4 ERF header above,
 * with type=0, flags=0, rlen=64.
 */

/* DAG 4 ERF header for ETH */
typedef struct {
    coral_timestamp_t t;
    uint8_t type;
    uint8_t flags;
    uint16_t rlen; /* record length (dag header + caplen of packet) */
    uint16_t loss;
    uint16_t wlen; /* wire length (totlen of packet) */
    uint8_t offset;
    uint8_t pad;
    /* NB: most compilers add extra padding, so don't use sizeof() on this */
} coral_dag_erf_ether_hdr_t;

#define DAG_HDR_SIZE		18  /* big enough to hold any DAG header */

#define DAG_TYPE_LEGACY		0
#define DAG_TYPE_HDLC_POS	1
#define DAG_TYPE_ETH		2
#define DAG_TYPE_ATM		3
#define DAG_TYPE_AAL5		4

#define DAG_FLAG_IFMASK		0x03
#define DAG_FLAG_VARLEN		0x04
#define DAG_FLAG_TRUNC		0x08
#define DAG_FLAG_RXERR		0x10
#define DAG_FLAG_DSERR		0x20

#ifdef __cplusplus
}
#endif

#endif /* CORAL_DAG_H */
