/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 * coral_init.c - main entry point for libcoral.  
 *		sets up stuff to make it work.
 *		routines to initialize & open devices, check setup, etc...
 */

static const char RCSid[]="$Id: coral_init.c,v 1.223 2007/06/06 18:17:54 kkeys Exp $";

#include "config.h"
#include "coraldefs.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdarg.h>
#include <signal.h>
#include <fcntl.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <assert.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <netinet/in.h>
#include <time.h>

#ifndef HAVE_PWD_H
# undef HAVE_GETPWNAM
#else
# ifdef HAVE_GETPWNAM
#  include <pwd.h>      /* getpwnam() */
# endif
#endif

#ifdef HAVE_LIBPCAP
# include <pcap.h>
#endif

#ifdef HAVE_CORAL_DEVICES
# include "drivers/coral_ioctl.h"
#endif
#include "libcoral.h"
#include "libcoral_priv.h"

#if 0
coral_internal_stats_t coral_internal_stats;
#endif

coral_source_t *csource[CORAL_MAXOPEN];
coral_iface_t *cinst[CORAL_MAXOPEN];
fd_set coral_select_fds;
#ifndef FD_SETSIZE
# define FD_SETSIZE 1024
#endif
coral_source_t *coral_fd_table[FD_SETSIZE];
int coral_select_fd_max = -1;
int coral_select_count = 0;	/* number of sources that need select() */
int coral_noselect_count = 0;	/* number of sources that don't need select() */
int coral_live_ifaces = 0;	/* number of valid live interfaces */
int coral_offline_ifaces = 0;	/* number of valid non-live interfaces */
int coral_total_ifaces = 0;	/* total number of valid interfaces */

coral_dev_config_t null_dev_config = {
    { CORAL_RX_UNKNOWN, -1 },	/* iomode */
    0,				/* bandwidth */
    CORAL_PROTO_UNKNOWN		/* protocol */
    /* remaining fields are 0 */
};

static coral_source_t *pending_src = NULL;

/* if you write a new coral source type, you need to add it here */
static const coral_src_type_t *coral_types[] = {
    &coral_src_type_file,
    &coral_src_type_dagfile,
    &coral_src_type_point,
    &coral_src_type_fatm,
    &coral_src_type_dag,
    &coral_src_type_optistar,
    &coral_src_type_pcap,
    &coral_src_type_pcaplive,
    &coral_src_type_tsh,
    NULL
};

const coral_iface_type_t *const coral_iface_types[] = {
#ifdef HAVE_CORAL_POINT
    &coral_iface_type_point,
#endif
#ifdef HAVE_CORAL_FATM
    &coral_iface_type_fatm,
#endif
#ifdef HAVE_DAGAPI
    /* &coral_iface_type_dag_atm, */
    /* &coral_iface_type_dag_pos, */
    /* &coral_iface_type_dag_erf_novarlen, */
    &coral_iface_type_dag_erf_varlen,
#endif
#ifdef HAVE_CORAL_OPTISTAR
    &coral_iface_type_optistar,
#endif
#ifdef HAVE_LIBPCAP
    &coral_iface_type_pcap,
#endif
    &coral_iface_type_tsh,
    NULL
};

int coral_new_instance(coral_source_t *src, int sid)
{
    int id;

    for (id = 0; id < CORAL_MAXOPEN && cinst[id]; id++)
	;

    if (id == CORAL_MAXOPEN) {
	coral_diag(0, ("coral_open: too many open coral devices\n"));
	return -1;
    }

    cinst[id] = (coral_iface_t *)calloc(1, sizeof(coral_iface_t));
    if (!cinst[id]) {
	coral_diag(0, ("coral_new_instance: calloc: %s\n", strerror(errno)));
	return -1;
    }

    cinst[id]->src = src;
    src->id[sid] = cinst[id]->id = id;
    cinst[id]->sid = sid;
    cinst[id]->eof = 1; /* not started */
    cinst[id]->synced = 0;
    cinst[id]->have_interval = 0;
    cinst[id]->raw_ts.i[0] = -1; /* can't use 0, it's a valid value */
    cinst[id]->raw_ts.i[1] = -1; /* can't use 0, it's a valid value */
    cinst[id]->period_end.tv_sec = cinst[id]->period_end.tv_nsec = -1;
    if (coral_max_iface <= id)
	coral_max_iface = id + 1;

    return id;
}

static coral_source_t *coral_init_source(void)
{
    int sd, i;
    static int first_time = 1;

    if (first_time) {
	first_time = 0;
	memset(coral_fd_table, sizeof(coral_fd_table), 0);
    }

    for (sd = 0; sd < coral_config.maxsrc && csource[sd]; sd++)
	;

    if (sd == coral_config.maxsrc) {
	coral_diag(0, ("coral_open: too many coral sources\n"));
	errno = EMFILE;
	return NULL;
    }

    csource[sd] = (coral_source_t *)calloc(1, sizeof(coral_source_t));
    if (!csource[sd]) {
	coral_diag(0, ("coral_new_source: malloc: %s\n", strerror(errno)));
	return NULL;
    }
    csource[sd]->sd = sd;

    csource[sd]->eof = 1; /* not started */
    csource[sd]->fd = -1;  /* initialize to invalid fd */
    csource[sd]->version = 0;
    csource[sd]->iface_count = 0;
    for (i = 0; i < CORAL_MAXOPEN; i++) {
	csource[sd]->id[i] = -1;
    }
    csource[sd]->dev_config = null_dev_config;
    csource[sd]->dev_config.vlan_hack = coral_config.dev_config.vlan_hack;
    csource[sd]->dev_config.num_ifaces = coral_config.dev_config.num_ifaces;
    csource[sd]->proto_rules.head = csource[sd]->proto_rules.tail = NULL;

    coral_config.source_count++;
    if (coral_max_src <= sd)
	coral_max_src = sd + 1;
    return csource[sd];
}

/* close a src's file such that source can be used for next file in compound */
static int coral_src_recycle(coral_source_t *src, int final)
{
    int ret = 0;
    int i;

    validate_src(src, "coral_close", -1);
    coral_diag(4, ("coral_close %s\n", src->filename));
    for (i = 0; i < src->iface_count; i++) {
	cinst[src->id[i]]->prev_ts = cinst[src->id[i]]->latest_ts;
    }

    if (src->type.close)
	ret = src->type.close(src, final);

    if (src->fd >= 0) {
	close(src->fd);
	src->fd = -1;
    }
    return ret;
}

coral_source_t *coral_new_source(const char *name)
{
    const char *filename;
    coral_source_t *src;

    if (pending_src) {
	src = pending_src;
	src->name = realloc(src->name, strlen(src->name) + 1 + strlen(name));
	strcat(src->name, " ");
	strcat(src->name, name);
	if (strcmp(name, "]") == 0) {
	    pending_src = NULL;
	    if (src->filename_count == 0) {
		coral_diag(0, ("source list contains no filenames\n"));
		coral_close(src);
		return NULL;
	    }
	    return src;
	}
	filename = name;
    } else {
	if (!(src = coral_init_source()))
	    return NULL;
	if ((filename = strchr(name, ':'))) {
	    filename++;
	} else {
	    filename = name;
	}
	src->name = strdup(name);
	if (strcmp(filename, "[") == 0) {
	    if (coral_config.flags & CORAL_OPT_NO_COMPOUND_SRC) {
		coral_diag(0, ("%s: compound sources are not allowed\n",
		    coral_config.argv ? coral_config.argv[0] : "error"));
		coral_close(src);
		return NULL;
	    }
	    return pending_src = src;
	}
    }

    src->filename_list = realloc(src->filename_list,
	(src->filename_count + 1) * sizeof(char *));
    src->filename_list[src->filename_count] =
	coral_filename(filename, NULL, PATH_MAX);
    if (!src->name || !src->filename_list[src->filename_count]) {
	coral_diag(0, ("coral_new_source(%s): malloc: %s\n", name,
	    strerror(errno)));
	coral_close(src);
	errno = ENOMEM;
	return NULL;
    }

    src->filename_count++;
    src->filename_index = 0;
    src->filename = src->filename_list[0];
    return src;
}

coral_source_t *coral_new_fdsource(int fd, const char *name)
{
    coral_source_t *src;

    if (!(src = coral_init_source()))
	return NULL;

    if (name) {
	src->name = strdup(name);
	src->filename = strdup(name);
    } else if ((src->name = malloc(16))) {
	sprintf(src->name, "fd.%d", fd);
	src->filename = strdup(src->name);
    }
    if (!src->name || !src->filename) {
	coral_diag(0, ("coral_new_fdsource: malloc: %s\n", strerror(errno)));
	coral_close(src);
	errno = ENOMEM;
	return NULL;
    }
    src->fd = fd;

    return src;
}

int coral_next_compound_file(coral_source_t *src)
{
    coral_source_t orig_src;
    coral_iface_t orig_iface[CORAL_MAXOPEN];
    int i;

#define verify_comp_src(field, label, fmt) \
    do { \
	if (src->field != orig_src.field) { \
	    coral_diag(0, \
		("%s of %s (" fmt ") disagrees with that of %s (" fmt ")\n", \
		label, src->filename, src->field, \
		orig_src.filename, orig_src.field)); \
	    goto error; \
	} \
    } while (0)

#define verify_comp_if(field, label, fmt) \
    do { \
	if (cinst[src->id[i]]->field != orig_iface[i].field) { \
	    coral_diag(0, ("%s of interface %d of %s (" fmt ") " \
		"disagrees with that of %s (" fmt ")\n", \
		label, i, src->filename, cinst[src->id[i]]->field, \
		orig_src.filename, orig_iface[i].field)); \
	    goto error; \
	} \
    } while (0)

    assert(!src->type.is_live);
    orig_src = *src;
    for (i = 0; i < src->iface_count; i++) {
	orig_iface[i] = *cinst[src->id[i]];
    }

    coral_src_recycle(src, 0);
    if (++src->filename_index >= src->filename_count)
	goto error;
    src->filename = src->filename_list[src->filename_index];
    if (src->type.init(src) < 0)
	goto error;

    verify_comp_src(iface_count, "iface_count", "%d");
    verify_comp_src(type.coral_type, "type", "%d");
    verify_comp_src(type.init, "type.init", "%p");
    verify_comp_src(type.start, "type.start", "%p");
    if (orig_src.ubase)
	verify_comp_src(ubase, "ubase", "%p");
    verify_comp_src(dev_config.iomode.flags, "iomode.flags", "%04x");
    verify_comp_src(dev_config.iomode.first_n, "iomode.first", "%d");
    verify_comp_src(dev_config.bandwidth, "bandwidth", "%d");
    verify_comp_src(dev_config.physical, "physical", "%d");
    verify_comp_src(dev_config.datalink, "datalink", "%d");
    verify_comp_src(pktq_max, "pktq_max", "%d");
    verify_comp_src(pktq_head, "pktq_head", "%p");

    for (i = 0; i < src->iface_count; i++) {
	/* restore fields that may have been incorrectly clobbered by init() */
	cinst[src->id[i]]->iface_info.capture_tv =
	    orig_iface[i].iface_info.capture_tv;
	cinst[src->id[i]]->duration_end = orig_iface[i].duration_end;
	cinst[src->id[i]]->period_end = orig_iface[i].period_end;
	cinst[src->id[i]]->native_period_end = orig_iface[i].native_period_end;

	cinst[src->id[i]]->must_check_file_order = 1;
	coral_diag(3, ("new file %s on interface %d\n", src->filename, src->id[i]));

	/* verify that other fields are the same */
	verify_comp_if(iface_info.hw_type, "hw_type", "%d");
	verify_comp_if(iface_type->cell_layout[CORAL_CELL_SIZE_IDX],
	    "record size", "%d");
	verify_comp_if(iface_type->cell_layout[CORAL_CELL_OFFSET_HEADER_IDX],
	    "L2 header offset", "%d");
	verify_comp_if(iface_type->cell_layout[CORAL_CELL_OFFSET_PAYLOAD_IDX],
	    "payload offset", "%d");
	verify_comp_if(id, "id", "%d");
	verify_comp_if(sid, "sid", "%d");
	verify_comp_if(iface_info.bandwidth, "bandwidth", "%d");
	verify_comp_if(iface_info.physical, "physical", "%d");
	verify_comp_if(iface_info.proto_rule_count, "proto_rule_count", "%d");
	verify_comp_if(devinfo.type, "devinfo.type", "%d");
	verify_comp_if(devinfo.blk_size, "blk_size", "%d");
	verify_comp_if(time_is_normal, "time_is_normal", "%d");
	verify_comp_if(pktq_head, "pktq_head", "%d");

    }

    return 1;
error:
    coral_mark_eof_src(src);
    return 0;
}

/* If any dev_config fields are unset, set them from default_config. */
void coral_set_dev_config_defaults(coral_dev_config_t *dev_config,
    const coral_dev_config_t *const default_config)
{
    if (dev_config->iomode.flags == CORAL_RX_UNKNOWN)
	dev_config->iomode = default_config->iomode;
    if (dev_config->iomode.first_n < 0)
	dev_config->iomode.first_n = default_config->iomode.first_n;
    if (dev_config->bandwidth <= 0)
	dev_config->bandwidth = default_config->bandwidth;
    if (dev_config->physical == CORAL_PROTO_UNKNOWN)
	dev_config->physical = default_config->physical;
    if (dev_config->datalink == CORAL_PROTO_UNKNOWN)
	dev_config->datalink = default_config->datalink;
    if (!dev_config->firmware && default_config->firmware)
	dev_config->firmware = strdup(default_config->firmware);
}

/*
 * coral_open_all - 
 * first function called.  opens all initialized members of csource[].
 * this should do everything necessary to get the card ready to go,
 * including loading firmware, etc...  the next call should be coral_start
 *
 * returns - number of opened sources if successful, or -1 for failure.
 */

int coral_open_all(void)
{
    int total = 0;	/* number of opened interfaces */
    int n, sd;

    if (pending_src) {
	coral_diag(0, ("missing ']' on source name\n"));
	return NULL;
    }

    for (sd = 0; sd < CORAL_MAXOPEN; sd++) {
	if (!csource[sd]) continue;
	if ((n = coral_open(csource[sd])) < 0)
	    return -1;
	total += n;
    }
    return total;
}

#ifdef HAVE_BPF_FILTER
static struct bpf_program *coral_pcap_compile2(coral_iface_t *iface, char *str,
    int raw)
{
    struct bpf_program *fp;
    pcap_t **pp;

    fp = malloc(sizeof(struct bpf_program));
    if (!fp) {
	coral_diag(0, ("malloc: %s\n", strerror(errno)));
	return NULL;
    }

    pp = raw ? &iface->ip_pcap : &iface->internal_pcap;
    if (!*pp)
	*pp = coral_iface_to_alloced_pcapp(iface, raw);

    if (coral_pcap_compile_verbose(iface, *pp, fp, str, 1, 0) < 0) {
	free(fp);
	return NULL;
    }
    return fp;
}
#endif

static int coral_filesuffix_to_type(const char *filename)
{
    /* Look for suffix and set type explicitly */
    char *start, *end;
    start = end = strchr(filename, '\0');
retrysuffix:
    do {
	if (--start <= filename || *start == '/') {
	    /* No suffix, look for other substring */
	    start++;
	    if (strncmp(start, "OptiStar", 8) == 0) {
		return CORAL_TYPE_OPTISTAR;
	    } else if (strncmp(start, "dag", 3) == 0) {
		return CORAL_TYPE_DAG;
	    } else {
		return CORAL_TYPE_NONE;
	    }
	}
    } while (*start != '.');

#define suffixeq(sfx, start, end) \
    ((end - start == sizeof(sfx) - 1) && (strncmp(sfx, start, end-start) == 0))

    if (suffixeq(".crl", start, end)) {
	return CORAL_TYPE_CRL;
    } else if (suffixeq(".pcap", start, end)) {
	return CORAL_TYPE_PCAP;
    } else if (suffixeq(".dag", start, end)) {
	return CORAL_TYPE_DAGFILE;
    } else if (suffixeq(".tsh", start, end)) {
	return CORAL_TYPE_TSH;
    } else if (suffixeq(".enc", start, end)) {
	end = start;
	goto retrysuffix;
    } else if (strcmp(start, ".gz") == 0) {
	end = start;
	goto retrysuffix;
    } else {
	return CORAL_TYPE_NONE; /* some other suffix */
    }
}

int coral_open(coral_source_t *src)
{
    int i, id, error, len;
    struct stat statbuf;
    int preopened;
    int maybe_coraldev = 0;

    if (pending_src) {
	coral_diag(0, ("missing ']' in source name\n"));
	return NULL;
    }

#if 0 /* why was this here? */
    static int sigpipe_handler_installed = 0;

    if (!sigpipe_handler_installed) {
	if (signal(SIGPIPE, SIG_IGN) == SIG_ERR)
	    coral_diag(0, ("signal: %s\n", strerror(errno)));
	else
	    sigpipe_handler_installed = 1;
    }
#endif

    validate_src(src, "coral_open", -1);
    preopened = (src->fd >= 0);

    /* reopen requires the file's name to refer to a regular file; things
     * like "-" and "/dev/fd/0" (if it's a device, as on freebsd) can not
     * be reopened even if the file they point to is regular. */
    src->can_reopen = strcmp(src->filename, "-") != 0 &&
	(stat(src->filename, &statbuf) == 0 && (statbuf.st_mode & S_IFREG));

    /* If any src->dev_config fields are unset, set them from coral_config. */
    coral_set_dev_config_defaults(&src->dev_config, &coral_config.dev_config);
    /* If they're still unset, they'll be set to device defaults later. */

    /* Open first instance here; type.init() will open more as needed. */
    if ((id = coral_new_instance(src, 0)) < 0)
	goto coral_open_error;
    src->iface_count = 1;
    cinst[id]->devinfo.type = CORAL_TYPE_NONE; /* unknown */

    len = strcspn(src->name, ":/");
    if (src->name[len] == ':') {
	/* Detect prefix and set type explicitly */
	if (strncmp(src->name, "crl:", len) == 0) {
	    cinst[id]->devinfo.type = CORAL_TYPE_CRL;
	} else if (strncmp(src->name, "if:", len) == 0) {
	    cinst[id]->devinfo.type = CORAL_TYPE_PCAPLIVE;
	} else if (strncmp(src->name, "pcap:", len) == 0) {
	    cinst[id]->devinfo.type = CORAL_TYPE_PCAP;
	} else if (strncmp(src->name, "dag:", len) == 0) {
	    cinst[id]->devinfo.type = CORAL_TYPE_DAGFILE;
	} else if (strncmp(src->name, "tsh:", len) == 0) {
	    cinst[id]->devinfo.type = CORAL_TYPE_TSH;
	} else if (strncmp(src->name, "optistar:", len) == 0) {
	    cinst[id]->devinfo.type = CORAL_TYPE_OPTISTAR;
	} else {
	    coral_diag(0, ("coral_open: %s: unknown prefix '%.*s'\n",
		src->name, len, src->name));
	    errno = ENOENT;
	    return -1;
	}

    } else {
	cinst[id]->devinfo.type = coral_filesuffix_to_type(src->filename);
    }

    if (cinst[id]->devinfo.type == CORAL_TYPE_NONE ||
	cinst[id]->devinfo.type == CORAL_TYPE_CRL)
    {
	/* Coral device or Coral tracefile */
	if (strcmp(src->filename, "-") == 0) {
	    src->fd = STDIN_FILENO;

	} else {
	    if (!preopened) {
		if ((src->fd = open(src->filename, O_RDONLY, 0)) < 0) {
		    coral_diag(0, ("coral_open: %s: open: %s\n",
			src->filename, strerror(errno)));
		    goto coral_open_error;
		}
		coral_diag(4, ("coral_open: %s: fd %d\n", src->filename, src->fd));
	    }

	    if (fstat(src->fd, &statbuf) < 0) {
		coral_diag(0, ("coral_open: %s: stat: %s\n",
		    src->filename, strerror(errno)));
		goto coral_open_error;
	    }
	    if ((statbuf.st_mode & S_IFMT) == S_IFDIR) {
		errno = EISDIR;
		coral_diag(0, ("coral_open: %s: %s\n",
		    src->filename, strerror(errno)));
		goto coral_open_error;
	    }
	    if ((statbuf.st_mode & S_IFMT) == S_IFCHR)
		maybe_coraldev = 1;
	}
    }

    if (!maybe_coraldev) {
	/* not a Coral Device */
	if (src->dev_config.iomode.flags & CORAL_RX_ECHO)
	    coral_diag(1, ("warning: coral_open: %s: 'echo' iomode ignored"));
	if (src->dev_config.iomode.flags & CORAL_TX)
	    coral_diag(1, ("warning: coral_open: %s: 'tx' iomode ignored"));
	if (cinst[id]->devinfo.type == CORAL_TYPE_CRL)
	    cinst[id]->devinfo.type = CORAL_TYPE_FILE;

    } else if (preopened) {
	coral_diag(0, ("coral_open: %s: unknown type", src->filename));
	goto coral_open_error;

    } else {
#ifdef HAVE_CORAL_DEVICES
	/* device (or other non-regular, in which case ioctl will fail) */

	if (ioctl(src->fd, CORAL_FILLINFO, &cinst[id]->devinfo) < 0) {
	    coral_diag(0, ("coral_open: %s: ioctl FILLINFO: %s.  "
		"Retrying as regular file.\n", src->filename, strerror(errno)));
	    /*goto coral_open_error;*/
	    goto end_device;
	}

	/* The drivers need O_RDWR because they do writes
	 * during initialization. (for now) */
	close(src->fd);
	if ((src->fd = open(src->filename, O_RDWR, 0)) < 0) {
	    coral_diag(0, ("coral_open: %s: open: %s\n",
		src->filename, strerror(errno)));
	    goto coral_open_error;
	}
	/*coral_diag(4, ("coral_open: %s: fd %d\n", src->filename, src->fd));*/

	if (cinst[id]->devinfo.version != CORAL_DRIVER_VERSION) {
	    coral_diag(0, ("coral_open: %s: "
		"incorrect driver version %d (expected %d)\n", 
		src->filename, cinst[id]->devinfo.version,
		CORAL_DRIVER_VERSION));
	    errno = ENXIO;
	    goto coral_open_error;
	}

	/* Mmap in the driver's buffer for this card. */
	coral_diag(6, ("coral (%s): mmap %d blocks of %d bytes = %d bytes\n",
	    src->filename,
	    cinst[id]->devinfo.num_blks, cinst[id]->devinfo.blk_size,
	    cinst[id]->devinfo.num_blks * cinst[id]->devinfo.blk_size));
	src->ubase = mmap(0,
	    cinst[id]->devinfo.num_blks * cinst[id]->devinfo.blk_size,
	    PROT_READ|PROT_WRITE, MAP_SHARED, src->fd, 0);
	if(src->ubase == MAP_FAILED) {
	    coral_diag(0, ("coral_open: %s: Could not mmap card's buffer: %s\n",
		src->filename, strerror(errno)));
	    goto coral_open_error;
	}
# ifdef DEBUG
	/* coral_stats(src); */
# endif

	coral_diag(5, ("coral offset: %s: %p mmap: 0x%x\n",
	    src->filename, cinst[id]->devinfo.kmem_buffer, (u_int)src->ubase));

#else	/* ! HAVE_CORAL_DEVICES */
	coral_diag(0, ("coral_open: %s is a device file, "
	    "and CoralReef was not built with device support.  "
	    "Retrying as regular file.\n", src->filename));
	goto end_device;
	/*errno = ENODEV;*/
	/*goto coral_open_error;*/
#endif	/* HAVE_CORAL_DEVICES */
    }
end_device:

    /* find the fxn's for the type of device */
    if (cinst[id]->devinfo.type == CORAL_TYPE_NONE) {
	/* file of unspecified type; coral_file_init will try to identify */
	src->type = coral_src_type_file;
	src->type.coral_type = CORAL_TYPE_NONE;
    } else {
	for (i = 0; coral_types[i]; i++)
	    if (coral_types[i]->coral_type == cinst[id]->devinfo.type) break;
	if (!coral_types[i]->init) {
	    coral_diag(0, ("coral_open: %s: support for %s (coral type %d) "
		"was not compiled in to this copy of libcoral.\n", 
		src->filename, coral_types[i]->name, cinst[id]->devinfo.type));
	    errno = ENODEV;
	    goto coral_open_error;
	}
	src->type = *coral_types[i];
    }

    /* call the init function for this source's type */
    if (src->type.init(src) < 0) {
	if (!errno)
	    errno = ENODEV; /* XXX wrong errno */
	goto coral_open_error;
    }
    src->is_interleaved = (src->type.can_interleave && src->iface_count > 1);

    if (src->dev_config.num_ifaces &&
	src->dev_config.num_ifaces != src->iface_count)
    {
	coral_diag(1, ("warning: %s has exactly %d interfaces.\n",
	    src->filename, src->iface_count));
	/* note: making this a fatal error would break crl_guess */
    }

    if ((src->dev_config.iomode.flags & CORAL_RX) && (src->dev_config.iomode.flags & CORAL_TX)) {
	coral_diag(0,
	    ("coral_open: %s: can't receive and transmit on same device\n",
	    src->filename));
	errno = ENODEV;
	goto coral_open_error;
    }

    /*coral_fd_set[coral_fd(src)] = src;*/

    for (i = 0; i < src->iface_count; i++) {
	coral_iface_t *iface = cinst[src->id[i]];

	if (iface->iface_type->init)
	    iface->iface_type->init(iface);

	/* Hack to allow user to say "PPP" instead of "PPPoHDLC", etc.
	 * For each "PPP" interface, select the appropriate type of PPP
	 * framing according to the physical layer */
	if (iface->iface_info.datalink == CORAL_DLT_PPP) {
	    switch (iface->iface_info.physical) {
	    case CORAL_PHY_POS:
		iface->iface_info.datalink = CORAL_DLT_PPPoHDLC;
		break;
	    default:
		break;
	    }
	}

#ifdef HAVE_BPF_FILTER
	/* Each interface could have a different datalink type, so we can't
	 * just reuse a single compiled program on every interface.
	 */
	if (coral_config.bpf_filter_text) {
	    struct bpf_program *fp;
	    fp = coral_pcap_compile2(iface, coral_config.bpf_filter_text, 0);
	    if (!fp || coral_pcap_setfilter(iface, fp) < 0) {
		if (fp) free(fp);
		errno = 0;
		goto coral_open_error;
	    }
	    iface->bpfprog = fp;
	    iface->bpfprog_is_private = 1;
	}
	if (coral_config.bpf_prefilter_text) {
	    struct bpf_program *fp;
	    fp = coral_pcap_compile2(iface, coral_config.bpf_prefilter_text, 0);
	    if (!fp || coral_pcap_setprefilter(iface, fp) < 0) {
		if (fp) free(fp);
		errno = 0;
		goto coral_open_error;
	    }
	    iface->prebpfprog = fp;
	}
	if (coral_config.bpf_ipfilter_text) {
	    struct bpf_program *fp;
	    fp = coral_pcap_compile2(iface, coral_config.bpf_ipfilter_text, 1);
	    if (!fp || coral_pcap_setipfilter(iface, fp) < 0) {
		if (fp) free(fp);
		errno = 0;
		goto coral_open_error;
	    }
	    iface->ip_bpfprog = fp;
	}
#endif
    }

    return src->iface_count;

coral_open_error:
    error = errno;
    coral_close(src);
    errno = error;
    return -1;
}

/*
 * Mark iface as having reached EOF so we don't return any more data from it,
 * but don't deallocate anything.  iface->src may still have other ifaces that
 * we haven't finished reading yet.
 */
void coral_mark_eof(coral_iface_t *iface)
{
    int i, remaining;
    int saved_error = errno;
    /* note: if iface->src is a file not in uncompressed crl format,
     * then fd == -1
     */
    if (iface->eof) return; /* shouldn't happen */
    iface->eof = 1;
    iface->synced = 0; /* make sure only non-eof ifaces are counted as synced */
    if (iface->holding) {
	iface->holding = 0;
	coral_read_iface(iface); /* use previously held block */
    }
    if (!iface->src->type.is_live)
	coral_offline_ifaces--;
    else
	coral_live_ifaces--;
    coral_total_ifaces--;

    /* XXX coral_free_iface_blocks(cinst[src->id[i]]); */
    /* If there are no interfaces left, stop watching this source. */
    for (i = 0, remaining = 0; i < iface->src->iface_count; i++)
	remaining += !cinst[iface->src->id[i]]->eof;
    if (!remaining)
	coral_mark_eof_src(iface->src);

    errno = saved_error;
}

/* Mark src as having reached EOF, but don't dallocate anything.  src may
 * still have ifaces with queued data that we've read but haven't given
 * to the user yet, but we will never try to read from src->fd again.
 * This should not be called just because duration is expired; call
 * coral_stop instead.
 * Guranteed to not modify errno.
 */
int coral_mark_eof_src(coral_source_t *src)
{
    int i;

    if (src->eof) return 0;
    src->eof = 1;
    if (!src->type.is_live) {
	coral_noselect_count--;
	for (i = 0; i < src->iface_count; i++) {
	    coral_iface_t *iface = cinst[src->id[i]];
	    if (!iface->eof && !iface->have_data && !iface->have_blk &&
		!iface->pktq_head)
	    {
		iface->eof = 1;
		iface->synced = 0;
		coral_offline_ifaces--;
		coral_total_ifaces--;
	    }
	}
    } else {
	if (src->fd >= 0) {
	    if (!FD_ISSET(src->fd, &coral_select_fds)) {
		coral_diag(0, ("internal error: src %d already clear\n",
		    src->id));
	    } else {
		FD_CLR(src->fd, &coral_select_fds);
		coral_select_count--;
	    }
	    for (i = 0; i < src->iface_count; i++) {
		coral_iface_t *iface = cinst[src->id[i]];
		if (!iface->eof && !iface->have_data && !iface->have_blk &&
		    !iface->pktq_head)
		{
		    iface->eof = 1;
		    iface->synced = 0;
		    coral_live_ifaces--;
		    coral_total_ifaces--;
		}
	    }
	} else {
	    coral_live_ifaces -= src->iface_count; /* ??? */
	    coral_total_ifaces -= src->iface_count; /* ??? */
	    coral_noselect_count--;
	}
    }
    return 0;	/* for compatibility with coral_src_type_t.stop */
}

/* coral_close
 * find associated fd, close it, remove it from the set of select fds.
 * if final: free all associated cinst's, free struct.
 */
int coral_close(coral_source_t *src)
{
    int ret = 0;
    int i, id;

    ret = coral_src_recycle(src, 1);

    coral_mark_eof_src(src);

    for (i = 0; i < src->iface_count; i++) {
	if ((id = src->id[i]) < 0) continue;

	if (cinst[id]->iface_type && cinst[id]->iface_type->close)
	    cinst[id]->iface_type->close(cinst[id]);

#ifdef HAVE_LIBPCAP
	if (cinst[id]->src->type.coral_type != CORAL_TYPE_PCAP &&
	    cinst[id]->src->type.coral_type != CORAL_TYPE_PCAPLIVE && 
	    cinst[id]->internal_pcap)
	{
# ifdef HAVE_PCAP_OPEN_DEAD
	    pcap_close(cinst[id]->internal_pcap);
# else
	    free(cinst[id]->internal_pcap);
# endif
	}
	cinst[id]->internal_pcap = NULL;

	if (cinst[id]->ip_pcap) {
# ifdef HAVE_PCAP_OPEN_DEAD
	    pcap_close(cinst[id]->ip_pcap);
# else
	    free(cinst[id]->ip_pcap);
# endif
	}
	cinst[id]->ip_pcap = NULL;

	if (cinst[id]->user_pcap) {
# ifdef HAVE_PCAP_OPEN_DEAD
	    pcap_close(cinst[id]->user_pcap);
# else
	    free(cinst[id]->user_pcap);
# endif
	}
	cinst[id]->user_pcap = NULL;

	if (cinst[id]->bpfprog && cinst[id]->bpfprog_is_private)
	    free(cinst[id]->bpfprog);
	if (cinst[id]->prebpfprog)
	    free(cinst[id]->prebpfprog);
	if (cinst[id]->packetbuf.is_dynamic) {
	    free((void*)cinst[id]->packetbuf.buf);
	    cinst[id]->packetbuf.is_dynamic = 0;
	}
#endif

	if (!cinst[id]->eof) {
	    cinst[id]->eof = 1;	/* foil any future (mis)use of iface */
	    if (!cinst[id]->src->type.is_live)
		coral_offline_ifaces--;
	    else
		coral_live_ifaces--;
	    coral_total_ifaces--;
	}

	cinst[id]->src = NULL;	/* foil any future (mis)use of iface */
	free(cinst[id]);
	cinst[id] = NULL;
    }

    if (src->desc) free(src->desc);
    if (src->encoding) free(src->encoding);
    if (src->name) free(src->name);
    if (src->filename_list) {
	for (i = 0; i < src->filename_count; i++)
	    free(src->filename_list[i]);
	/* don't free filename, it points to an item in filename_list */
    } else if (src->filename) {
	free(src->filename);
    }
    csource[src->sd] = NULL;
    src->sd = -1;	/* foil any future (mis)use of this */
    free(src);
    coral_config.source_count--;

#if 0
# define print_stat(field) \
    coral_diag(0, (#field "\t%" PRId64 "\n", coral_internal_stats.field))

    print_stat(clock_order);
    print_stat(clock_double);
    print_stat(clock_timespec);
    coral_internal_stats.clock_order = 0;
    coral_internal_stats.clock_double = 0;
    coral_internal_stats.clock_timespec = 0;
#endif
    return ret;
}

/* generic close function for block sources */
int coral_blk_close(coral_source_t *src, int final)
{
    int i, id;
    coral_blknode_t *nextbn;

    if (!final) return 0;

    for (i = 0; i < src->iface_count; i++) {
	if ((id = src->id[i]) < 0) continue;
	nextbn = cinst[id]->u.blk.node.next;
	if (cinst[id]->src->type.release)
	    cinst[id]->src->type.release(cinst[id]);
	assert(!nextbn || src->type.release);
	while (nextbn) {
	    cinst[id]->u.blk.node = *nextbn;
	    free(nextbn);
	    nextbn = cinst[id]->u.blk.node.next;
	    src->type.release(cinst[id]);
	}
    }
    return 0;
}

int coral_close_all(void)
{
    int n = 0;	    /* number of closed sources */
    int sd;

    for (sd = 0; sd < CORAL_MAXOPEN; sd++) {
	if (!csource[sd]) continue;
	if (coral_close(csource[sd]) < 0)
	    return -1;
	n++;
    }
    return n;
}

int coral_format_iomode(char *buffer, const coral_io_mode_t *iomode)
{
    char *s = buffer;

    if (iomode->flags & CORAL_RX_UNKNOWN) {
	s += sprintf(s, "unspecified,");
    } else {
	if (iomode->flags & CORAL_RX_USER_ALL) {
	    s += sprintf(s, "user,");
	} else {
	    if (iomode->first_n >= 0)
		s += sprintf(s, "first=%d,", iomode->first_n);
	    if (iomode->flags & CORAL_RX_LAST)
		s += sprintf(s, "last,");
	}
	if (iomode->flags & CORAL_RX_VARLEN)
	    s += sprintf(s, "varlen,");
	if (iomode->flags & CORAL_TX)
	    s += sprintf(s, "tx,");
	if (iomode->flags & CORAL_RX)
	    s += sprintf(s, "rx,");
	if (iomode->flags & CORAL_RX_IDLE)
	    s += sprintf(s, "idle,");
	if (iomode->flags & CORAL_RX_OAM)
	    s += sprintf(s, "ctrl,");
	if (iomode->flags & CORAL_RX_ECHO)
	    s += sprintf(s, "echo,");
    }
    if (s > buffer) --s; /* remove trailing comma */
    *s = '\0';
    return s - buffer;
}

const coral_protolabel_t coral_protolabel[] = {
#define defproto(layer, prefix, abbr, proto_ok, id, desc) \
    { coral_mkproto(layer, id), #abbr, desc, proto_ok },
#include "coral_proto.h"
    { 0, NULL, NULL }
};

const coral_protolabel_t *coral_protolabel_by_name(const char *name)
{
    const coral_protolabel_t *pl;

    if (!name) return NULL;

    for (pl = coral_protolabel; pl->abbr; pl++) {
	if (cstrcmp(pl->abbr, name) == 0 || cstrcmp(pl->desc, name) == 0)
	    return pl;
    }

    return NULL;
}

coral_protocol_t coral_proto_id(const char *name)
{
    const coral_protolabel_t *pl;

    if (!name) return CORAL_PROTO_ILLEGAL;

    for (pl = coral_protolabel; pl->abbr; pl++) {
	if (cstrcmp(pl->abbr, name) == 0 || cstrcmp(pl->desc, name) == 0)
	    return pl->id;
    }

    return CORAL_PROTO_ILLEGAL;
}

const char *coral_proto_desc(coral_protocol_t protocol)
{
    const coral_protolabel_t *pl;

    for (pl = coral_protolabel; pl->abbr; pl++) {
	if (pl->id == protocol)
	    return pl->desc;
    }

    return NULL;
}

const char *coral_proto_abbr(coral_protocol_t protocol)
{
    const coral_protolabel_t *pl;

    for (pl = coral_protolabel; pl->abbr; pl++) {
	if (pl->id == protocol)
	    return pl->abbr;
    }

    return NULL;
}

const char *coral_proto_str(coral_protocol_t protocol)
{
    static char scratch[32];
    const char *result;

    result = coral_proto_abbr(protocol);
    if (result) return result;
    sprintf(scratch, "unknown %d:%d",
	coral_proto_layer(protocol), coral_proto_num(protocol));
    return scratch;
}

const char *coral_file_version(const coral_source_t *src)
{
    static char buffer[32];
    char *p = buffer;
    u_int version = CORAL_VERSION;

    if (src) {
	validate_src(src, "coral_file_version", NULL);
	version = src->version;
    }

    if (CORAL_VERSION_IS_NEW(version)) {
        p += sprintf(p, "%d ", CORAL_VERSION_VALUE(version));
    } else {
        switch(version) {
        case CORAL_VERSION_OLD_ANY:   p += sprintf(p, "0 ");       break;
        case CORAL_VERSION_OLD_NLANR: p += sprintf(p, "0.nlanr "); break;
        case CORAL_VERSION_OLD_MCI:   p += sprintf(p, "0.mci ");   break;
        }
    }
    sprintf(p, "(%#x)", version);
    return buffer;
}

void coral_dump(const coral_source_t *src)
{
    int i;
    coral_iface_t *iface;
    coral_iface_info_t *iinfo;
    char iomode_buffer[CORAL_FORMAT_IOMODE_LEN];
    long tzoff;

    coral_printf("%s:\n", src->name);
    coral_printf("  type:     %s\n", src->type.name);
    if (src->type.coral_type == CORAL_TYPE_FILE) {
	coral_printf("  version:  %s\n", coral_file_version(src));
	if (src->desc)
	    coral_printf("  comment:  %s\n", src->desc);
	if (src->encoding)
	    coral_printf("  encoding: %s  version %u\n",
		src->encoding, src->encoding_version);
    }

    coral_format_iomode(iomode_buffer, &src->dev_config.iomode);
    coral_printf("  iomode:   %s\n", iomode_buffer);

    for (i = 0; i < src->iface_count; i++) {
        iface = cinst[src->id[i]];
	iinfo = &iface->iface_info;
	coral_printf("  interface %d\n", i);
	coral_printf("    timestamps:  %s endian, %snormalized\n",
	    iface->iface_info.time_is_le ? "little" : "big",
	    iface->time_is_normal ? "" : "not ");
	coral_printf("    hardware:  ");
	switch (iinfo->hw_type) {
	    case CORAL_TYPE_FATM:	coral_printf("fatm"); break;
	    case CORAL_TYPE_POINT:	coral_printf("point"); break;
	    case CORAL_TYPE_DAG:	coral_printf("dag"); break;
	    case CORAL_TYPE_OPTISTAR:	coral_printf("OptiStar"); break;
	    default: coral_printf("(unknown: %#x)", iinfo->hw_type);
	}
	coral_printf("  version %#x\n", iinfo->hw_version);
	coral_printf("    software:  ");
	switch (iinfo->sw_type) {
	    case SW_TYPE_NONE:	coral_printf("none\n"); break;
	    case SW_TYPE_MCI:	coral_printf("MCI\n"); break;
	    case SW_TYPE_NLANR:	coral_printf("NLANR\n"); break;
	    case SW_TYPE_DAG:	coral_printf("DAG\n"); break;
	    case SW_TYPE_CORAL:
		coral_printf("Coral version %d\n",
		    iinfo->sw_version & 0x7FFFFFFFul);
		break;
	    case SW_TYPE_PCAP:
		coral_printf("pcap version %d.%d\n",
		    iinfo->sw_version >> 16, iinfo->sw_version & 0xFFFF);
		break;
	    default: coral_printf("(unknown: %#x)", iinfo->sw_type);
	}
	if (iinfo->physical != CORAL_PROTO_UNKNOWN)
	    coral_printf("    physical:  %s\n", coral_dlt_str(iinfo->physical));
	coral_printf("    data link: %s\n", coral_dlt_str(iinfo->datalink));
	if (iinfo->capture_tv.tv_sec) {
	    char scratch[32];
	    struct tm *tm;
	    time_t tv_sec = iinfo->capture_tv.tv_sec;
	    tm = gmtime(&tv_sec); /* timeval.tv_sec may not be a time_t */
	    strftime(scratch, sizeof(scratch), "%Y-%m-%d %H:%M:%S", tm);
	    coral_printf("    captured:  %s.%06ld UTC (%ld.%06ld)\n",
		scratch, iinfo->capture_tv.tv_usec,
		iinfo->capture_tv.tv_sec, iinfo->capture_tv.tv_usec);
	}

	if (iinfo->tzoff < 0) {
	    coral_printf("    tz offset: -");
	    tzoff = -iinfo->tzoff;
	} else {
	    coral_printf("    tz offset: ");
	    tzoff = iinfo->tzoff;
	}
	coral_printf("%02d:%02d", tzoff / 3600, tzoff % 3600 / 60);
	if (tzoff % 60)
	    coral_printf(":%02d", tzoff % 60);
	coral_puts("");

	coral_format_iomode(iomode_buffer, &iinfo->iomode);
	coral_printf("    iomode:    %s\n", iomode_buffer);
	if (iinfo->bandwidth)
	    coral_printf("    bandwidth: %s\n",
		coral_bandwidth_fmt(iinfo->bandwidth));
	if (iface->proto_rules.head) {
	    coral_printf("    iface proto rules:\n");
	    coral_dump_rules(iface->proto_rules.head, 4);
	}
    }
    if (src->proto_rules.head) {
	coral_printf("  src proto rules:\n");
	coral_dump_rules(src->proto_rules.head, 4);
    }
    coral_printf("\n");
}

void coral_dump_all(void)
{
    int sd;

    for (sd = 0; sd < CORAL_MAXOPEN; sd++) {
	if (!csource[sd]) continue;
	coral_dump(csource[sd]);
    }
    if (coral_proto_rules.head) {
	coral_printf("  global proto rules:\n");
	coral_dump_rules(coral_proto_rules.head, 4);
    }
}

void coral_stats(const coral_source_t *src)
{
    int i, id;

/*  coral_printf("lost %d.09d seconds\n",
	src->devinfo.lost_time.tv_sec,
	src->devinfo.lost_time.tv_nsec)); */
    coral_printf("coral source %d (%s):\n", src->sd, src->name);
    coral_printf("  fd     %d\n", src->fd);
    coral_printf("  ubase  %p\n", src->ubase);
    coral_printf("  interface       kmem  tx err  rx err    intr\n");
    for (i = 0; i < src->iface_count; i++) {
        id = src->id[i];
#ifdef HAVE_CORAL_DEVICES
	if (coral_type_is_driver(cinst[id]->devinfo.type)) {
	    if (ioctl(src->fd, CORAL_FILLINFO, &cinst[id]->devinfo) < 0) {
		coral_diag(0, ("coral_stats: ioctl FILLINFO: %s: %s\n",
		    src->name, strerror(errno)));
	    }
	}
#endif
	coral_printf("  %3d (%3d) %10p  %6d  %6d  %6d\n", i, id,
	    cinst[id]->devinfo.kmem_buffer,
	    cinst[id]->devinfo.tx_errors,
	    cinst[id]->devinfo.rx_errors,
	    cinst[id]->devinfo.interrupts);
    }
}

void coral_stats_all(void)
{
    int sd;

    for (sd = 0; sd < CORAL_MAXOPEN; sd++) {
	if (!csource[sd]) continue;
	coral_stats(csource[sd]);
    }
}

char *coral_base(coral_source_t *src)
{
    coral_iface_t *iface;
    validate_src(src, "coral_base", NULL);
    iface = cinst[src->id[0]];
    return (coral_type_is_driver(iface->devinfo.type)) ?
	src->ubase :
	0;
}

size_t coral_msize(coral_source_t *src)
{
    coral_iface_t *iface;
    validate_src(src, "coral_msize", -1);
    iface = cinst[src->id[0]];
    return (coral_type_is_driver(iface->devinfo.type)) ?
	iface->devinfo.num_blks * iface->devinfo.blk_size :
	0;
}

#if 0
char *coral_fd(coral_source_t *src)
{
    validate_src(src, "coral_fd", NULL);
    return src->type.get_fd ? src->type.get_fd() : src->fd;
}
#endif

/* At least one of tv or tm must be non-NULL.  If one is NULL, it is generated
 * from the other.
 * Extensions:
 *   %s   seconds
 *   %f   residual fractions of second
 *   %F   ISO 8601 date (%Y-%m-%d)
 *   %i   optional integer argument
 */
size_t coral_strftime(char *buf, size_t maxsize, const char *fmt,
    const struct timeval *tvp, struct tm *tm, ...)
{
    char scratch[1024], tfmt[16] = "%", pfmt[16] = "%";
    size_t n;
    size_t size = 0;
    struct timeval tv_buf;
    va_list ap;
    int got_i = 0, i = 0;

    if (!tvp) {
	tv_buf.tv_sec = mktime(tm);
	tv_buf.tv_usec = 0;
	tvp = &tv_buf;
    } else if (!tm) {
	const time_t sec = tvp->tv_sec;    /* in case tv_sec is not time_t */
	tm = localtime(&sec);
    }

    while (*fmt) {
	if (*fmt != '%' || *++fmt == '%') {
	    buf[size++] = *(fmt++);
	    if (size >= maxsize) return 0;
	} else {
	    int pi = 1;
	    int ti = 1;
	    while (!isalpha(*fmt))
		pfmt[pi++] = *(fmt++);
	    switch (*fmt) {
	    case 'i':
		if (!got_i) {
		    va_start(ap, tm);
		    i = va_arg(ap, int);
		    va_end(ap);
		    got_i++;
		}
		pfmt[pi++] = 'd';
		pfmt[pi++] = '\0';
		n = snprintf(buf + size, maxsize - size, pfmt, i);
		break;
	    case 's':
		pfmt[pi++] = 'l';
		pfmt[pi++] = 'd';
		pfmt[pi++] = '\0';
		n = snprintf(buf + size, maxsize - size, pfmt, tvp->tv_sec);
		break;
	    case 'f':
		n = snprintf(buf + size, maxsize - size, "%06ld", tvp->tv_usec);
		break;
	    case 'F':
		pfmt[pi++] = 's';
		pfmt[pi++] = '\0';
		n = strftime(scratch, sizeof(scratch), "%Y-%m-%d", tm);
		if (n <= 0) return 0;
		n = snprintf(buf + size, maxsize - size, pfmt, scratch);
		break;
	    case 'E':
	    case 'O':
		tfmt[ti++] = *(fmt++);
	    default:
		pfmt[pi++] = 's';
		pfmt[pi++] = '\0';
		tfmt[ti++] = *fmt;
		tfmt[ti++] = '\0';
		n = strftime(scratch, sizeof(scratch), tfmt, tm);
		if (n <= 0) return 0;
		n = snprintf(buf + size, maxsize - size, pfmt, scratch);
	    }
	    if (n <= 0) return 0;
	    size += n;
	    fmt++;
	}
    }
    buf[size] = '\0';
    return size;
}

/* Copy str to dst, with leading "~" home directory expansion.
 * If dst is NULL, coral_filename allocates len characters for it.
 * Returns expanded buffer.
 */
char *coral_filename(const char *str, char *dst, size_t len)
{
    const char *dir = NULL, *user;
    char *result;
    int n, is_dynamic = 0;

    if ((is_dynamic = !dst) && !(dst = malloc(len)))
	return NULL;

    result = dst;

    if (*str == '~') {
	for (user = ++str; *str && *str != '/'; str++);
	if (str == user) {
	    dir = getenv("HOME");
#ifdef HAVE_GETPWNAM
	} else if (str - user < len) {
	    struct passwd *pw;
	    strncpy(dst, user, str - user);
	    dst[str-user] = '\0';
	    if ((pw = getpwnam(dst)))
		dir = pw->pw_dir;
#endif /* HAVE_GETPWNAM */
	}
	if (dir) {
	    strncpy(dst, dir, len);
	    n = strlen(dir);
	    len -= n;
	    dst += n;
	} else {
	    str = user - 1;
	}
    }

    strncpy(dst, str, len);
    return result;
}

/* Generate a name for a temporary file */
void coral_tmpname(char *buf)
{
    char *dir;
    static int tmpcount = 0;
    /* tmpnam() does not honor TMPDIR, and causes a (spurious) warning
     * in the linker (on FreeBSD), so we just generate our own name. */
    dir = getenv("TMPDIR");
    sprintf(buf, "%.*s/crl.%d.%d", PATH_MAX - 27,
	dir ? dir : "/tmp", tmpcount++, getpid());
}

