/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 * fatm_dev.c -
 *
 * The fatm card is a bit more complex than normal cards.  Instead of working
 * one block at a time, it wants to be given two blocks.  One block is the
 * current block (current_host_block) and the other block is the next block
 * (next_host_block).  When the card has finished filling the current block, it
 * sets current_host_block = next_host_block, sets next_host_block = 0, and
 * issues an interrupt to tell the host "give me a new next block".  But if
 * next_host_block is 0 when the current block is filled, the card does NOT
 * issue an interrupt, and starts losing data.  The interrupt handler takes the
 * block that used to be the current block and saves it, then feeds the card a
 * new next block from the free queue.  Because the card already has a next
 * block when it fills its current block, we don't have to race to give the
 * card a new block in the interrupt routine.  Unfortunantly, it requires a bit
 * of work to make sure the coral block timestamps are set correctly, pay
 * careful attention to use of savetime().  To start the card it must be given
 * a current block and a next block.  After that, the interrupt routine just
 * needs to give the card next blocks.  If we have filled the buffer full and
 * don't have a free block to feed the card, we go into 'losing' mode, and tell
 * the card to reuse the most recent filled block if it must.  If fatm_release
 * is called before the card fills its current block, we can give the card a
 * new next block so it doesn't have to reuse the filled block; but if we get
 * an interrupt first, it means the card has started to reuse that filled
 * block, so we count its old contents as lost.
 *
 * Calling fatm_nextblk means that the user is done with the last block
 * returned by it, so that block becomes available to feed the card with.  In
 * this way, the user can only hold onto one block at a time.  If the user
 * wants to hold onto more than one block at a time, he can use the
 * CORAL_NEXTBLK_NORELEASE ioctl.  This tells fatm_nextblk via setting the
 * norelease argument to not release the last user locked block.  When the user
 * is done with a block, he must call the CORAL_RELEASE ioctl which calls
 * fatm_release.  This puts the oldest locked block back into the block_pool.
 * You cannot currently release blocks out of order.
 *
 * The structure used to manage blocks is block_pool.  It can be found in the
 * coral_common.* files.  They contain code that should be generic enough to
 * use in all coral drivers.
 *
 * $Id: fatm_dev.c,v 1.86 2007/06/06 18:17:41 kkeys Exp $
 */


#include <sys/param.h>
#include <sys/conf.h>
#include <sys/systm.h>
#include <sys/uio.h>
#include <sys/mman.h>
#include <sys/ioccom.h>
#include <sys/syslog.h>
#include <sys/proc.h>
#include <sys/select.h>	/* sys/proc.h doesn't include this in FreeBSD 4.x */
#include <machine/clock.h>

#include <vm/vm.h>
#include <vm/pmap.h>
#include <vm/vm_extern.h>

#ifdef MODULE
#include "coral_ioctl.h"
#include "fatm_board.h"
#else
#include <pci/coral_ioctl.h>
#include <pci/fatm_board.h>
#endif

#if __FreeBSD_version >= 300000
#include <sys/poll.h>
#else
#include <sys/fcntl.h>
#endif

static void fatm_busywait(void);
static void fatm_stop(fatm f);
static int fatm_start(fatm f);
static int fatm_nextblk(fatm f, int *idxp, int norelease);
static int fatm_sendblk(fatm f, u_int desc_count);

static d_open_t fatmopen;
static d_close_t fatmclose;
static d_read_t fatmread;
static d_write_t fatmwrite;
static d_ioctl_t fatmioctl;
static d_poll_t fatmselect;
static d_mmap_t fatmmmap;

#define AVAILABLE 0x01000000
extern int hz;
#ifndef MIN
#define MIN(x,y) (((x) < (y)) ? (x) : (y))
#endif
#define MIN_TIMEOUT (hz/100)
#define MAX_TIMEOUT (10*hz)

#if 0
#define FATMSLEEP(usec, idstr) \
    do { \
	f->timeout.tv_sec = usec / 1000000; \
	f->timeout.tv_usec = usec - 1000000 * (usec / 1000000); \
	tsleep(f, PRIBIO | PCATCH, idstr, \
	       usec ? tvtohz(&f->timeout) : 0); \
    } while(0)
#else
#define FATMSLEEP(usec, idstr)	DELAY(usec)
#endif

#define MAX_FIFO_DEPTH		16
#define WORDS_PER_SEND		14    /* how many words in a send descriptor */

/* FreeBSD 2 doesn't have nanotime.  The shame.  Let's help it out. */
#if __FreeBSD_version < 300000
static inline void nanotime(struct timespec *time) {
    struct timeval tvtime;

    /* 
     * Get the time with microtime and convert it to units as seen with
     * nanotime.
     */
    microtime(&tvtime);
    TIMEVAL_TO_TIMESPEC(&tvtime, time);
}
#endif

/* 
 * Save the time on our block timestamp. 
 */
static inline void savetime(struct timespec *time_location) {
    nanotime(time_location);
    return;
}

#ifdef CORAL_DEBUG
# define BLK_ADR_IDX(f, adr) \
    (adr ? ((adr - vtophys(f->buffer)) / FATM_BLK_SIZE) : -1)

# define BLK_ADR_FMT(f, adr) \
	(adr - vtophys(f->buffer)) / FATM_BLK_SIZE, \
	((adr - vtophys(f->buffer)) % FATM_BLK_SIZE) / FATM_CELL_SIZE, \
	(adr - vtophys(f->buffer)) % FATM_CELL_SIZE

# define DEBUG_BLK_INFO(title, f, idx, cur, nxt, losing, feed) \
    do { \
	printf("fatm%d: %-7s: i=%2d", f->fatmi, title, idx); \
	printf(" cur="); \
	cur ? printf("%2d[%05d]+%d", BLK_ADR_FMT(f,cur)) : printf("%08x   ", cur); \
	printf(" nxt="); \
	nxt ? printf("%2d[%05d]+%d", BLK_ADR_FMT(f,nxt)) : printf("%08x   ", nxt); \
	printf(" losing="); \
	losing ? printf("%2d", losing->index) : printf("--"); \
	feed>=0 ? printf(" feed=%2d\n", feed) : printf("\n"); \
    } while (0)

#else
# define DEBUG_BLK_INFO(title, f, idx, cur, nxt, losing, feed) \
    do { /* nothing */ } while (0)
#endif


/* 
 * Give the card the next available block if possible and tell the amcc (the
 * card's pci dma controller) to start filling it with cells.  If a block is
 * not available, return NULL.
 *
 * Note that it takes the register to write to.  This can be either
 * next_host_block or current_host_block.  Current_host_block is used only
 * during the card's initialization.  It refers to the block that the card
 * is actively using.
 */
static inline struct block *FEED_BLK(fatm f, fatm_reg32 reg)
{
    struct block *block;

    /* Get a free block to fill. */
    block = block_pool_free_get(&f->block_pool);

    if (block) {
	block->header->cells_lost = 0;
	/* Denote this block as being filled by the card. */
	block_pool_filling_set(&f->block_pool, block);
#ifdef CORAL_DEBUG
	{ /* This is useful for detecting incorrectly filled/counted blocks. */
	    u_int i, deadbeef = htonl(0xDEADBEEF);
	    for (i = 0; i < FATM_BLK_SIZE / sizeof(u_int); i++)
		((u_int*)block->raw_block)[i] = deadbeef;
	    block->header->cell_count = deadbeef;
	}
#endif

    } else {
	/* 
	 * We're out of free blocks...
	 */
	return NULL;
    }

    /* Tell the card to start writing to this block. */
    write_fatm_32(reg, vtophys(block->raw_block));

    return block;
}


/*
 * Take the current block off the filling queue and save it for the user. 
 */
static inline struct block *EAT_BLK(fatm f)
{
    struct block *block;

    /* Take the block that just finished filling off the filling list. */
    block = block_pool_filling_get(&f->block_pool);

    /* If we have no previously filled block we can just skip this code. */
    if (!block) {
    	return(NULL);
    }

#if 0
    /* XXX: How do we do lost cell checks on this card? */
    block->header->cells_lost += 0;
#endif

    /* Save the time we completed this block. */
    savetime(&block->header->tend);

    if ((f->state & ST_CAPTURING) &&
	block_queue_is_empty(&f->block_pool.block_free))
    {
	/* Can't give this block to the user yet, must keep it for the card
	 * to use as next_host_block in 'losing' mode.
	 */
    } else {
	/* Stick this block in the list of filled blocks. */
	block_pool_filled_set(&f->block_pool, block);
    }

    /* Wake up libcoral apps to read this new block we got. */
    selwakeup(&f->s);

    return(block);
}

static unsigned int command_result;
static void issue_command(fatm f, int opcode)
{
    if (f->state & ST_OPEN) {
	write_fatm_32(f->command_queue_head, opcode/*|op_interrupt_sel*/);
	command_result = StatPending;
    }
}


/* 
 * Interrupt handler, called when the fore card needs a new next block.  We are
 * responsible for taking the filled block off the card, saving it, and giving
 * it a new one to fill.  If a block isn't available to fill, we go one more
 * step into 'losing' mode and tell the card it can recycle the latest filled
 * block if it has to.  If a block is released later while we're in losing
 * mode, we'll give it to the card, and that filled block isn't lost.  If the
 * card reaches the end of the current block before we can give it a clean next
 * block, this handler is called again, and counts the cells in the current
 * block as lost.
 */
void MODUNIQ(fatm_interrupt)(fatm f)
{
    struct block *old, *new = NULL;
    u_int current, next;

    if (!(f->state & ST_CAPTURING)) {
	/* for now, dont expect people to rx AND tx */

	if (f->iomode.flags & CORAL_TX) {

	} else {
	    printf("fatm%d: spurious interrupt (not capturing)\n", f->fatmi);
	}

    } else {
	current = read_fatm_32(f->current_host_block);
	next = read_fatm_32(f->next_host_block);
	old = f->block_pool.block_filling.head;

	if (!old) {
	    /* There was no block filling! Why were we interrupted?! */
	    printf("fatm%d: spurious interrupt (not filling)\n", f->fatmi);
	    DEBUG_BLK_INFO("SPURIOUS INT", f, -1, current, next, f->losing, -1);
	    goto exit_interrupt;

	} else if (next) {
	    /* The card has not used the next block! Why were we interrupted? */
	    /* Note: sometimes the card's current_host_block pointer still
	     * (validly?) points to the last cell of the block we're about
	     * to eat, so we can't consider this a bad interrupt just because
	     * that's true.
	     */
	    f->extra_interrupts++;
	    if (f->extra_interrupts < 0x400) {
		printf("fatm%d: spurious interrupt (card has next)\n",
		    f->fatmi);
	    } else if (f->extra_interrupts == 0x400) {
		printf("fatm%d: %d extra interrupts have occured per %d valid"
		    " interrupts; no longer logging all spurious interrupts.\n",
		    f->fatmi, f->interrupts, f->extra_interrupts);
	    } else if (f->extra_interrupts % 0x4000 == 0) {
		printf("fatm%d: %d extra interrupts have occured per %d valid"
		    " interrupts.\n",
		    f->fatmi, f->interrupts, f->extra_interrupts);
	    }
	    DEBUG_BLK_INFO("EXTRA INT", f, -1, current, next, f->losing, -1);
	    goto exit_interrupt;
	}

	/* Get the former current block. */
	old = EAT_BLK(f);
	old->header->cell_count = htonl(FATM_CELLS_PER_BLK);

	if (f->losing) {
	    /* Card is now reusing the 'losing' block.  Move that block 
	     * to the filling queue, and count its old contents as lost.
	     */
	    new = f->losing;
	    f->losing = NULL;
	    old->header->cells_lost =
		new->header->cells_lost + FATM_CELLS_PER_BLK;
	    new->header->cells_lost = 0;
	    block_pool_filling_set(&f->block_pool, new);
	} else {
	    new = f->block_pool.block_filling.head;
	}

	/* Set the start time on the new current block. */
	savetime(&new->header->tbegin);

	/* Give the card a new next block to fill after it fills current. */
	if (!(new = FEED_BLK(f, f->next_host_block))) {
	    /* There was no free block.  Tell the card it can reuse the last
	     * filled block if it has to. */
	    write_fatm_32(f->next_host_block, vtophys(old->raw_block));
	    f->losing = old;
	    DEBUG_BLK_INFO("int", f,
		old ? old->index : -1, current, next, f->losing, -1);
	} else {
	    DEBUG_BLK_INFO("int", f,
		old ? old->index : -1, current, next, f->losing, new->index);
	}
    }

    /* Count the good interrupts, but not the bad ones. */
    f->interrupts++;

exit_interrupt:
    /* Signal to the card that we have completed the interrupt. */
    write_fatm_32(f->imask, 1);
    write_fatm_32(f->istat, 0);
    write_fatm_32(f->board_control, 0x10);
    write_fatm_32(f->interrupt_control, 0);
}


/*
 * Start the card capturing.
 */
static int fatm_start(fatm f)
{
    int intlevel;

    /* We shouldn't be starting unless the card is initialized already. */
    if (!(f->state & ST_CARDINIT)) {
	printf("fatm%d: fatm_start called before card initalized\n", f->fatmi);
	return ENODEV;
    }

    /* We shouldn't be starting while the card is already capturing. */
    if (f->state & ST_CAPTURING) {
	printf("fatm%d: fatm_start called while already receiving\n", f->fatmi);
	return EALREADY;
    }

    /* Record that we are now capturing cells. */
    f->state |= ST_CAPTURING;

    /* Tell card to start writing at the beginning of the current block
     * (discarding anything the card wrote since it was initialized), and feed
     * the card a next block to write into when it's done with the current.
     */
    intlevel = splhigh();
    write_fatm_32(f->current_host_block,
	vtophys(f->block_pool.block_filling.head->raw_block));	/* XXX hack */
    FEED_BLK(f, f->next_host_block);
    f->interrupts = 0;
    f->extra_interrupts = 0;
    splx(intlevel);

    return(0);
}


/*
 * Stop the card from capturing. 
 */
static void fatm_stop(fatm f)
{
    u_int last_adr, idx, cell_count;
    struct block *block;

    /* We must have been started to be able to stop. :) */
    if(!(f->state & ST_CAPTURING)) {
#ifdef CORAL_DEBUG
	uprintf("fatm%d: fatm_stop called before fatm_start state:%x\n",
		f->fatmi, f->state);
#endif
	return;
    }

    /* Stop the card. */
    issue_command(f, op_shutdown);
    f->state &= (~ST_CAPTURING);

    if (f->losing) {
	/* Card never did reuse this block, so it still contains valid data. */
	block_pool_filled_set(&f->block_pool, f->losing);
	f->losing = NULL;
    }

    last_adr = read_fatm_32(f->current_host_block);

    /* Take the block that is currently being filled off the card. */
    block=EAT_BLK(f);

    /* If we had a partially filled block, record how full it was. */
    if (block) {
        /* calculate how many cells the card has written */
	idx = block->index;
	if (last_adr)
	    cell_count = (last_adr - vtophys(BLK_IDX_TO_ADR(idx, f->buffer,
		FATM_BLK_SIZE, FATM_NUM_BLKS))) / FATM_CELL_SIZE;
	else
	    cell_count = FATM_CELLS_PER_BLK;
        block->header->cell_count = htonl(cell_count);
    } else {
	idx = -1;
	cell_count = -1;
    }
#ifdef CORAL_DEBUG
    {
	u_int next = read_fatm_32(f->next_host_block);
	DEBUG_BLK_INFO("stopped", f, idx, last_adr, next, f->losing, -1);
    }
#endif

    return;
}


/*
 * Release the oldest user locked block back to the free block list.  If we're
 * in losing mode, immediately give the freed block to the card and move it to
 * the filling queue, and move the 'losing' block to the filled queue where
 * it belongs now that the card won't reuse it.
 */
static int fatm_release(fatm f) {
    struct block *block;

    /* Free the oldest user locked block. */
    block = block_pool_locked_get(&f->block_pool);
    if (block) {
        /* Free the block. */
        block_pool_free_set(&f->block_pool, block);

        /* Had we previously run out of blocks to feed the card? */
        if (f->losing && (f->state & ST_CAPTURING)) {
            /* Give the free block to the card, before it reuses the
	     * already-filled 'losing' block, and put the losing block
	     * on the filled queue where the user can get it.
	     */
	    FEED_BLK(f, f->next_host_block);
	    block_pool_filled_set(&f->block_pool, f->losing);
	    f->losing = NULL;
        }
    }

    /* We didn't have any user locked blocks?  Silly user. */
    else {
    	return(EAGAIN);
    }

    return(0);
}


/*
 * fatm_nextblk -
 *	this acts like a poll, if (there's no data available) return EAGAIN;
 *	else {
 *		return the index of the next full blk.
 *		if the card is stopped because of lack of memory 
 *		to give to the card, give it some and restart it.
 *	}
 */
static int fatm_nextblk(fatm f, int *idxp, int norelease)
{
    coral_blk_info_t *info;
    struct block *filled;

    /* 
     * If norelease isn't set, we should free the previous user block if one
     * exists.
     */
    if (!norelease) {
        (void) fatm_release(f);
    }

    /* Take a block off the filled list. */
    filled = block_pool_filled_get(&f->block_pool);

    /* Did we not have any available blocks? */
    if (!filled) {
    	if (!(f->state & ST_CAPTURING)) {
	    /* Return ok with index -1 to indicate there are no more blocks. */
	    *idxp = -1;
	    return 0;
	} else if (f->losing) {
	    /* Tell the caller we're stuck until he releases a block. */
	    return EDEADLK;
	} else {
	    /* Tell the caller to try again some other time. */
	    return EAGAIN;
	}
    }

    /* Add this block to the locked by the user list. */
    block_pool_locked_set(&f->block_pool, filled);

    /* Return the index of this block. */
    *idxp = filled->index;

    /* 
     * XXX Why is this here?  If it's just a speedup hack for the int
     * routine, that's just silly.  Ints don't happen that quickly to
     * bother adding mess to the driver.
     */
    info = BLK_IDX_TO_INFO(*idxp, f->buffer, FATM_BLK_SIZE, FATM_NUM_BLKS);
    info->tbegin.tv_sec = htonl(info->tbegin.tv_sec);
    info->tbegin.tv_nsec = htonl(info->tbegin.tv_nsec);
    info->tend.tv_sec = htonl(info->tend.tv_sec);
    info->tend.tv_nsec = htonl(info->tend.tv_nsec);

    info->cells_lost = htonl(info->cells_lost);

#ifdef CORAL_DEBUG
    {
	u_int current = read_fatm_32(f->current_host_block);
	u_int next = read_fatm_32(f->next_host_block);
	DEBUG_BLK_INFO("nextblk", f, *idxp, current, next, f->losing, -1);
    }
#endif

    return(0);
}


static volatile int in_read = 0;

/* 
 * this reads text from the card's internal serial interface
 * and stores it in a buffer for the user to get from a read()
 * syscall.
 */
static int fatm_monitor_read(fatm f)
{
    unsigned int k;
    int count = 0;
    int wait = 0;

    in_read = 1;
    while ((wait++ < 1000) && (count < 32)) {
	if ((k = read_fatm_32(f->i960_to_host)) & AVAILABLE) {
	    wait = 0;
	    f->input_ring[f->input_fill_pointer] = k & 255;
	    f->input_fill_pointer = (f->input_fill_pointer + 1) %
		sizeof(f->input_ring);
	    count++;
	    if (f->input_fill_pointer == f->input_read_pointer) {
		f->input_read_pointer = f->input_fill_pointer + 1;
		f->input_overrun = 1;
	    }
	    write_fatm_32(f->i960_to_host, 0);
	}
    }
    in_read = 0;
    return(count);
}

static void fatm_monitor_timeout(fatm f)
{
    if (!in_read && fatm_monitor_read(f)) {
	f->polling_frequency = MIN_TIMEOUT;
    } else {
	f->polling_frequency = MIN(MAX_TIMEOUT, f->polling_frequency + 20);
    }
#if FATM_WATCH_HEARTBEAT
    if (f->state & ST_CARDINIT) {
	if ((new_heartbeat = read_fatm_32(f,f->heartbeat)) ==
	    f->last_heartbeat) {

	    printf("fatm%d: is dead %x\n", f->fatmi, new_heartbeat);
	    f->firmware_booted = 0;
	} else
	    f->last_heartbeat = new_heartbeat;
    }
#endif /* FATM_WATCH_HEARTBEAT */
    if (f->state & ST_OPEN)
	timeout((void *)fatm_monitor_timeout, f, f->polling_frequency);
}

#define WAIT 1000	/* XXX ick */

static int write_to_monitor (fatm f, unsigned char *z, int len)
{
    unsigned int i, check;

    f->polling_frequency = 1;

    for (i = 0; i < len; i++) {
	for (check = 0; (read_fatm_32(f->host_to_i960)
			 && (check < WAIT)); check++)
	    fatm_monitor_read(f);
	if (check < WAIT) {
	    write_fatm_32(f->host_to_i960, z[i]|AVAILABLE);
	} else {
	    log(LOG_ERR, "fatm write failed\n");
	    return(i);
	}
    }
    return(i);
}


/*
 * Initialize the firmware for the card.  At firmware initialization time
 * the card needs information about where we plan on storing returned cells
 * so we have to do some of the block_pool initialization in this routine.
 */
static int fatm_init_firmware(fatm f, coral_io_mode_t *iomode) {
    int i;
    struct block *block;

#ifdef CORAL_DEBUG
    printf("fatm%d: init firmware, base %x\n", f->fatmi, f->base);
#endif

#if 0
    if (iomode->flags & ~CORAL_FATM_MODES) {
        uprintf("fatm%d: unsupported mode\n", f->fatmi);
        return ENODEV;
    }
#endif

    f->iomode = *iomode;

    /* Reset the buffer so all blocks are free and have sane settings. */
    block_pool_reset(&f->block_pool, f->fatmi, FATM_BLK_SIZE);

    /* Set the current block that the card will first write cells to. */
    block=FEED_BLK(f, f->current_host_block);

    /* Mark the time we started filling the block. */
    savetime(&block->header->tbegin);

    /*write_fatm_32(f->current_tx_block, vtophys(&nullsendrec));*/
    /*write_fatm_32(f->current_tx_length, WORDS_PER_SEND);*/

    write_fatm_32(f->init_host_block_size, FATM_CELLS_PER_BLK * FATM_CELL_SIZE);
    write_fatm_32(f->hlogger, 1);

    write_fatm_32(f->enable_line_loopback,
	(iomode->flags & CORAL_RX_ECHO) && !(iomode->flags & CORAL_TX));

    write_fatm_32(f->init_index_bits_avail, 20);
    write_fatm_32(f->init_bits_from_vci, 12);
    write_fatm_32(f->init_high_vpi_vci, 0);
    write_fatm_32(f->init_cqueue_len, 1);
    write_fatm_32(f->init_status, StatPending);
    write_fatm_32(f->init_op, op_initialize);

    for (i = 0; (i<20000) && (read_fatm_32(f->init_status) == 1); i++)
	fatm_monitor_read(f);

    if (read_fatm_32(f->init_status) != 2) {
	log(LOG_ERR, "fatm%d init command failed, status %d\n", f->fatmi,
		read_fatm_32(f->init_status));
	return ENXIO;
    }

    f->last_heartbeat = read_fatm_32(f->heartbeat);

    write_fatm_32(f->interrupt_control, 0);
    write_fatm_32(f->imask, 1);
    write_fatm_32(f->istat, 0);
    write_fatm_32(f->board_control, 0x10);

    for (i = 0; i < MAX_FIFO_DEPTH; i++)
	write_fatm_32(f->fifo_depth_counts + (4 * i), 0);
    f->command_queue_head = f->base + read_fatm_32(f->command_queue);

    /* assumption about addressing*/
    write_fatm_32(f->command_queue_head + 4, vtophys(&command_result));
    issue_command(f, op_clear_timestamp);

    f->state |= ST_CARDINIT;
    return 0;
}


#define	COLDSTART      0xc01dc01d
#define	SELFTEST_OK    0x02201958
#define	SELFTEST_FAIL  0xadbadbad
#define	CP_RUNNING     0xce11feed /* - application is ready */
#define	MON960_2_BIG   0x10aded00
#define FATM_TIMEOUT   4000000


/*
 * Cause the fatm card to reset itself.
 */
static int fatm_reset(fatm f)
{
    unsigned int i, k, status;
    int z, err = 0;

#ifdef CORAL_DEBUG
    printf("fatm_reset called\n");
#endif
    z = splhigh();

    write_fatm_32(f->boot_status, COLDSTART); /* signal cold start*/
    write_fatm_32(f->board_control, 1);       /* board reset*/
    for (i = 0; i < 700000; i++) 
	fatm_busywait();   /* leave it set for at least
			    * 64 cycles */
    write_fatm_32(f->board_control, 0);	/* clear the reset */

    k = 0;
    while (((status = read_fatm_32(f->boot_status)) == 0xc01dc01d) 
	   && (k++ < FATM_TIMEOUT))
	fatm_busywait();

    if (status == SELFTEST_FAIL || k >= FATM_TIMEOUT) {
	log(LOG_ERR, "fatm%d: reset - self test failed\n", f->fatmi);
	err = ETIMEDOUT;
    }

    write_fatm_32(f->host_to_i960, 0); /* huh? */
    splx(z);
    return err;
}

/* must have called CORAL_INIT with iomode.flags |= CORAL_TX */

/* XXX: Haven't tested this recently. */
static int fatm_sendblk(fatm f, u_int desc_count)
{
    int tmp = f->interrupts;

    if (!(f->iomode.flags & CORAL_TX)) {
	log(LOG_ERR, "fatm%d: tx failed, card not ready/tx disabled\n", 
	       f->fatmi);
	return ENXIO;
    }

    write_fatm_32(f->next_tx_block, vtophys(BLK_IDX_TO_ADR(0, f->buffer, FATM_BLK_SIZE, FATM_NUM_BLKS)));
    write_fatm_32(f->next_tx_length, desc_count * WORDS_PER_SEND);

    /* allow 10us for each cell - assume 1 cell / record - BAD XXX */
    FATMSLEEP(desc_count * 10, "fatm_sendblk");
    DELAY(10);

    if (tmp == f->interrupts) {
/*	printf("fatm%d: sendblk(%d) failed.\n", f->fatmi, desc_count); */
	return EAGAIN;
    }
#ifdef CORAL_DEBUG
    printf("fatm%d: sent block(%d).\n", f->fatmi, desc_count);
#endif

    return 0;
}

/* VFS entrypoints for character devices. */
#if __FreeBSD_version < 400000
struct cdevsw MODUNIQ(fatm_cdevsw) =
{
    fatmopen,
    fatmclose,
    fatmread,
    fatmwrite,
    fatmioctl,
    nostop,
    noreset,
    nodevtotty,
    fatmselect,
    fatmmmap,
    NULL,
    "fatm",
    NULL,
    -1,
};

#else /* __FreeBSD_version < 400000 */
struct cdevsw MODUNIQ(fatm_cdevsw) =
{
    fatmopen,
    fatmclose,
    fatmread,
    fatmwrite,
    fatmioctl,
    fatmselect,
    fatmmmap,
    NULL,
    "fatm",
    CDEV_MAJOR,
    nodump,
    nopsize,
    0,
    -1
};
#endif

/* needs to deal with multiple units and loadable 
 * already-attached; only gets called at boot */
void MODUNIQ(fatm_attach)(fatm f, int unit)
{
    int err;
    static int once = 0;

    f->fatmi = unit;
    f->state = 0;

#ifdef MODULE

#ifdef CORAL_DEBUG
    uprintf("module fatm_attach called.\n");
#endif

#else

    if (!once++) {
#if __FreeBSD_version >= 400000
	err = cdevsw_add(&fatm_cdevsw);
#else
	dev_t dev;
	dev = makedev(CDEV_MAJOR, unit);
	err = cdevsw_add(&dev, &fatm_cdevsw, NULL);
#endif
	if (err)
	    log(LOG_ERR, " .. cdevsw_add() returned %d\n", err);
#endif
    }

#if __FreeBSD_version >= 400000
    make_dev(&fatm_cdevsw, unit, UID_ROOT, GID_WHEEL, 0644, "fatm%d", unit);
#endif
}


/*
 * Handles openings of the fatm device.
 */
static int fatmopen(dev_t dev, int flag, int mode, struct proc *p)
{
    fatm f = fatm_from_dev(dev);

    if (f->state & ST_OPEN) {
	return EBUSY;
    }
    if (!f->buffer) {
	log(LOG_ERR, "fatm%d: no buffer allocated\n", f->fatmi);
	return ENXIO;
    }

    f->losing = NULL;
    f->iomode.flags = 0;
    f->iomode.first_n = 1;
    f->state |= ST_OPEN;

    /* Save the pid of the process opening us so we can CLOCKSYNC correctly. */
    f->pid=p->p_pid;

    bzero(&f->s, sizeof(struct selinfo));

    f->input_fill_pointer = 0;
    f->input_read_pointer = 0;
    f->input_overrun = 0;

    f->interrupts=0;

    f->polling_frequency = MIN_TIMEOUT;
    timeout((void *)fatm_monitor_timeout, f, f->polling_frequency);

    return(0);
}


/* only get to close it once! */
static int fatmclose(dev_t dev, int flag, int mode, struct proc *p)
{
    fatm f = fatm_from_dev(dev);

#ifdef CORAL_DEBUG
    printf("fatm%d: close\n", f->fatmi);
#endif

    if (f->state & ST_CAPTURING) {
	fatm_stop(f);
    }

    f->state = 0;

    return (0);
}


/* 
 * Ioctl handler for the fatm character device.  Handles the CORAL_* icotls
 * as defined in coral_ioctl*.h
 */
static int fatmioctl(dev_t dev, u_long cmd, caddr_t data, 
		     int flag, struct proc *p)
{
    fatm f = fatm_from_dev(dev);
    coral_interface *ci;
    memory_copy m;
    int i;
    int s;

    switch (cmd) {
    case CORAL_FILLINFO:
	ci = (coral_interface *)data;
	ci->version = CORAL_DRIVER_VERSION;
	ci->type = CORAL_TYPE_FATM;
	ci->kmem_buffer = f->buffer;
	ci->blk_size = FATM_BLK_SIZE;
	ci->num_blks = FATM_NUM_BLKS;
	ci->iomode = f->iomode;
	ci->tx_errors = 0;
	ci->rx_errors = 0;
	ci->interrupts = f->interrupts;
        break;
	
    case FATM_MWRITE:
	m = (memory_copy)data;
	write_fatm_32(f->base + m->address, m->value);
	break;

    case CORAL_RESET:
	return fatm_reset(f);
	break;

    case CORAL_INIT:
	return fatm_init_firmware(f, (coral_io_mode_t *)data);
	break;

    case CORAL_CLOCKSYNC:
	
	/* these should be done as close together as possible */
	s = splhigh();
	for (i = 0; i < NFATM; i++) {
	    
	    /* We only reset cards opened by the caller process. */
	    if ((fatms[i].state & ST_OPEN) && (fatms[i].pid == p->p_pid)) {

#ifdef CORAL_DEBUG
		uprintf("XXX: Issuing clear on card %d for pid %d.\n", i, p->p_pid);
#endif
		
		/* Reset this card's timestamp. */
		issue_command(&fatms[i], op_clear_timestamp);
	    }
        }
	splx(s);
	break;

    case CORAL_CLRTSTAMP:
	issue_command(f, op_clear_timestamp);
	break;

    case CORAL_START:
	return fatm_start(f);
	break;

    case CORAL_STOP:
	fatm_stop(f);
	break;

    case CORAL_NEXTBLK:
	return fatm_nextblk(f, (int *)data, 0);
	break;

    case CORAL_NEXTBLK_NORELEASE:
	return fatm_nextblk(f, (int *)data, 1);
	break;

    case CORAL_RELEASE:
    	return fatm_release(f);
    	break;

    case CORAL_SENDBLK:
	return fatm_sendblk(f, *(u_int *)data);
	break;

    default:
	log(LOG_ERR, "fatm%d unknown ioctl: %x\n", f->fatmi, (int) cmd);
    }
    return(0);
}


/*
 * Select() handler for the fatm device.  If data is ready or we are no
 * longer capturing, signal the user.  Otherwise, put the caller to sleep
 * until we have data available.[C
 */
static int fatmselect(dev_t dev, int rw, struct proc *pr)
{
    fatm f = fatm_from_dev(dev);
    int intlevel, revents = 0;

#if __FreeBSD_version >= 300000
    if (rw != POLLRDNORM) {
#else
    if (rw != FREAD) {
#endif
	log(LOG_ERR, "fatm%d: select pooped out, rw:%d\n", f->fatmi, rw);
	return 0;
    }

    /* 
     * If we have any filled blocks, signal the caller so.  Must all be done
     * exclusively in case the interrupt routine manages to give us a block
     * before we have recorded the process as sleeping on select.
     */
     intlevel=splhigh();
    if (block_pool_has_filled_blocks(&f->block_pool) ||
	!(f->state & ST_CAPTURING))
    {
#if __FreeBSD_version >= 300000
	revents = POLLIN | POLLRDNORM;
#else
	revents = TRUE;
#endif

    /* We had no filled blocks, so save the caller to be woken up when we do. */
    } else {
    	selrecord(pr, &f->s);
    }
    splx(intlevel);

    /* Return the select status. */
    return(revents);
}


/* this is a little weird, you always end up reading a 
 * null terminated string.  because that's my prerogative.
 * i can do what i wanna do...
 */
static int fatmread(dev_t dev, struct uio *uio, int flag)
{
    fatm f = fatm_from_dev(dev);

    int veci = 0;	/* which uoi->uo_iov we're filling now */
    int xferlen;	/* # bytes to copy next copyout */
    int remaining;	/* contiguous bytes in f->input ring to copy */
    int bufavail;	/* bytes not filled in current veci */
    char *ptr;		/* where in the uio_iov we currently are */
    int tot = 0;

    do {
	ptr = uio->uio_iov[veci].iov_base;
	bufavail = uio->uio_iov[veci].iov_len - 1;

	do {
	    remaining = f->input_fill_pointer - f->input_read_pointer;
	    if (0 > remaining)
		remaining = sizeof(f->input_ring) - f->input_read_pointer;
	    
	    xferlen = MIN(bufavail, remaining);
	    copyout(f->input_ring + f->input_read_pointer, ptr, xferlen);
	    f->input_read_pointer = (f->input_read_pointer + xferlen) % 
		sizeof(f->input_ring);
	    ptr += xferlen;
	    tot += xferlen;
	    remaining -= xferlen;
	    bufavail -= xferlen;
	} while (remaining && bufavail);

	copyout("", ptr, 1); /* null terminated, say what you like, it works */
	veci++;
    } while (veci < uio->uio_iovcnt &&
	     f->input_fill_pointer != f->input_read_pointer);

/*    printf("fatm_read tot: %d\n", tot); */

    /* wtf? */
    uio->uio_resid = bufavail + 1;
    for (veci++; veci < uio->uio_iovcnt; veci++)
	uio->uio_resid += uio->uio_iov[veci].iov_len;

    return(0);
}

/*
 * Handles writes to the fatm device.  This is currently how sending card
 * firmware is implemented.
 */
static int fatmwrite(dev_t dev, struct uio *uio, int flag)
{
    fatm f = fatm_from_dev(dev);
    int veci = 0;
    int xferlen;
    int remaining;
    char *ptr;
    char buffer[512];

    for (veci = 0; veci < uio->uio_iovcnt; veci++) {
	remaining = uio->uio_iov[veci].iov_len;
	ptr = uio->uio_iov[veci].iov_base;

	while (remaining) {
	    xferlen = MIN(remaining, sizeof(buffer));
	    copyin(ptr, buffer, xferlen);
	    write_to_monitor(f, buffer, xferlen);
	    ptr += xferlen;
	    remaining -= xferlen;
	}
    }

    return(0);
}

/*
 * Mmap the card's cell buffer.
 */
#if __FreeBSD_version >= 340000
static int fatmmmap(dev_t dev, vm_offset_t offset, int prot)
#else
static int fatmmmap(dev_t dev, int offset, int prot)
#endif
{
    fatm f;

    /* Sanity check arguments, must be in range and non-executable. */
    if(!(offset >= 0 && offset < FATM_CELLBUF_SIZE) || prot & PROT_EXEC) {
        return(-1);
    }

    /* Get the fatm structure corresponding to this device. */
    f = fatm_from_dev(dev);

    /* Return the offset to our buffer. */
#ifdef __i386__
    return i386_btop(vtophys(f->buffer + offset));
#endif
#ifdef __alpha__
    return alpha_btop(vtophys(f->buffer + offset));
#endif
}

/* 
 * XXX: This needs to cause actual delay or it could be optimized out,
 * possibly causing problems with initialization of the card.
 */
void fatm_busywait()
{
}
