/* 
 * Copyright 1999, 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/* coral interface fxns for the fatm device.
 *
 *  $Id: coral_type_fatm.c,v 1.94 2007/06/06 18:17:55 kkeys Exp $
 *
 */

#include "config.h"
#include "coraldefs.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <assert.h>

#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <errno.h>
#ifdef HAVE_SYS_IOCCOM_H
#include <sys/ioccom.h>
#endif
#include <sys/ioctl.h>
#include <sys/mman.h>

#include "drivers/coral_ioctl.h"
#include "libcoral.h"
#include "libcoral_priv.h"

static const char RCSid[] = "$Id: coral_type_fatm.c,v 1.94 2007/06/06 18:17:55 kkeys Exp $";

#ifdef HAVE_CORAL_FATM

static int fatm_download_direct(int fd, const char *s, const char *fw_path);
static int fatm_download_firmware(int fd, const char *s, const char *fw_path, 
				  coral_io_mode_t *iomode);
static int fatm_dump_console(int fd, char *buf, int size);

static int coral_fatm_init(coral_source_t *src)
{
    int id;
    const char *firmware = NULL;

    id = src->id[0];

    if (ioctl(src->fd, CORAL_RESET) < 0) {
	coral_diag(0, ("coral: reset: %s: %s\n", src->name, strerror(errno)));
	return -1;
    }

    /* If any src->dev_config fields are still unset, use device defaults. */
    coral_set_dev_config_defaults(&src->dev_config,
	&coral_iface_type_fatm.default_config);

    if (src->dev_config.physical != CORAL_PHY_ATM) {
	coral_diag(0, ("coral: %s: illegal physical type: %s\n",
	    src->name, coral_proto_str(src->dev_config.physical)));
	goto fail;
    }

    if (src->dev_config.bandwidth > 0 && src->dev_config.bandwidth != KBPS_OC3c)
    {
        coral_diag(0, ("coral: %s: unsupported bandwidth: %s\n",
            src->filename, coral_bandwidth_fmt(src->dev_config.bandwidth)));
        goto fail;
    }

    {
        char iomode_buf[80];
        coral_format_iomode(iomode_buf, &src->dev_config.iomode);
        coral_diag(6, ("%s iomode: %s\n", src->filename, iomode_buf));
    }

    if (!src->dev_config.firmware) {
	/* Choose firmware based on iomode.  See etc/fatm/INFO.fatm.
	 */
	if (src->dev_config.iomode.flags & CORAL_RX_OAM) {
	    /* not supported */
	} else if (src->dev_config.iomode.flags & CORAL_RX_USER_ALL) {
	    firmware = FATM_FW_DIR "/pay_all.bin";
	} else if (src->dev_config.iomode.flags & CORAL_RX_LAST) {
	    switch (divup(src->dev_config.iomode.first_n, ATM_PAYLOAD_SIZE)) {
	    case 0:  firmware = FATM_FW_DIR "/pay_last.bin"; break;
	    case 1:  firmware = FATM_FW_DIR "/1st_last.bin"; break;
	    default: break;
	    }
	} else {
	    switch (divup(src->dev_config.iomode.first_n, ATM_PAYLOAD_SIZE)) {
	    case 1:  firmware = FATM_FW_DIR "/pca200e.bin"; break;
	    case 2:  firmware = FATM_FW_DIR "/2cell.bin"; break;
	    case 3:  firmware = FATM_FW_DIR "/3cell.bin"; break;
	    default: break;
	    }
	}
	if (!firmware) {
	    coral_diag(0, ("coral: %s: unsupported iomode\n", src->filename));
	    goto fail;
	}
	src->dev_config.firmware = strdup(firmware);
    }

    if (fatm_download_firmware(src->fd, src->filename, src->dev_config.firmware,
        &src->dev_config.iomode) < 0)
    {
	/* coral_diag(0, ("coral: download_firmware: %s\n", strerror(errno))); */
	goto fail;
    }

    coral_init_atm_iface(cinst[id]);
    cinst[id]->iface_info.hw_type	= CORAL_TYPE_FATM;
    cinst[id]->iface_info.hw_version	= 0;
    cinst[id]->iface_info.fw_type	= 0;
    cinst[id]->iface_info.fw_version	= 0;
    cinst[id]->iface_info.iomode	= src->dev_config.iomode;
    cinst[id]->iface_info.capture_time	= 0; /* obsolete */
    cinst[id]->iface_info.bandwidth	= KBPS_OC3c;
    cinst[id]->iface_info.time_is_le	= 1;
    cinst[id]->iface_type		= &coral_iface_type_fatm;
    cinst[id]->iface_info.datalink	= src->dev_config.datalink;
    cinst[id]->iface_info.physical	= CORAL_PHY_ATM;
    cinst[id]->iface_info.tzoff		= 0; /* will be set in coral_start */
    cinst[id]->iface_info.capture_tv.tv_sec = 0;     /* set in coral_start */
    cinst[id]->iface_info.capture_tv.tv_usec = 0;    /* set in coral_start */

    return 0;

 fail:
    return -1;
}

static coral_iface_t *coral_fatm_nextblk(coral_source_t *src,
    coral_blk_info_t **binfop, coral_atm_cell_t **cellp, int endonly)
{
    int idx, i, cell_count;
    int op = CORAL_NEXTBLK;
    coral_iface_t *iface;

    /* probably unnecessary, take out after done debugging */
    fatm_dump_console(src->fd, NULL, 0);

    if (ioctl(src->fd, op, &idx) < 0) {
	return NULL;
    }
    if (idx < 0) {	/* device is stopped, return EOF indicator */
	errno = 0;
	return NULL;
    }

    iface = cinst[src->id[0]];
    *binfop = BLK_IDX_TO_INFO(idx, src->ubase, iface->devinfo.blk_size,
	iface->devinfo.num_blks);
    *cellp = (coral_atm_cell_t *)BLK_IDX_TO_ADR(idx, src->ubase,
	iface->devinfo.blk_size, iface->devinfo.num_blks);

    /* The fore card returns atm headers in little endian order.
     * We make them big endian (network order).
     */
    cell_count = ntohl((*binfop)->cell_count);
#if 1
    if (cell_count > iface->devinfo.blk_size / coral_cell_size(iface)) {
	coral_diag(0, ("%s: bogus cell count: %d\n",
	    src->filename, cell_count));
	cell_count = 0;
	(*binfop)->cell_count = htonl(cell_count);
    }
#endif
    for (i = 0; i < cell_count; i++) {
	u_int *hp = &((coral_fatm_atm_cell_t*)*cellp)[i].cu.ui;
	*hp = crl_swapl(*hp);
    }

    return iface;
}


/*
 * fatm fxns are from jdugan's libfatm, modified to work w/ 
 * CORAL driver interface and library.
 * returns 0 for failure, else an offset address internal to the i960 
 *  to be used for issuing commands (?weird)
 */

static int fatm_download_direct(int fd, const char *s, const char *fw_path)
{
    unsigned int *buf;
    unsigned int i;
    struct stat sb;
    struct mem_copy m;
    unsigned int start, start2;
    int firmware_fd;
    
    if ((firmware_fd = open(fw_path, O_RDONLY, 0)) < 0) {
	coral_diag(0, ("coral: %s fatm_download_direct: open %s: %s\n",
	    s, fw_path, strerror(errno)));
	return(0);
    }
    
    fstat(firmware_fd, &sb);
    
    buf = (unsigned int *) malloc(sb.st_size);
    if (!buf) {
	coral_diag(0, ("coral: %s fatm_download_direct: malloc(%d): %s\n",
	    s, (int)sb.st_size, strerror(errno)));
	return(0);
    }
    
    if (read(firmware_fd, buf, sb.st_size) == sb.st_size) {
	start  = buf[3];
	start2 = buf[2];
	
	for(i = 0; i < ((sb.st_size) / 4); i++) {
	    m.address = start2 + (i * 4);
	    m.value = buf[i];
	    ioctl(fd, FATM_MWRITE, &m);
	}

	return(start);
    } else {
	return(0);
    }
}


static int fatm_dump_console(int fd, char *buf, int size)
{
    int len, pri = 0;
    char buffer[1024];

    if (!buf) {
	size = sizeof(buffer);
	buf = buffer;
	pri = 1;
    }

    len = read(fd, buf, size);

    if (pri && len)
	coral_diag(9, ("i960: "));
    
    coral_diag(9, ("%s", buf));
    return len;
}

/*
 * returns -1 for failure 
 *
 * some of this is questionable, but i haven't seen it fail...yet
 *
 */
static int fatm_download_firmware(int fd, const char *s, const char *fw_path, 
				  coral_io_mode_t *iomode)
{
    int state = 0, done = 0;
    unsigned int firmware_begin;
    char buf[1024];
    char hack = 0;
    struct timeval tval;
    coral_io_mode_t driver_mode;

    tval.tv_sec = 0;
    tval.tv_usec = 100;

    coral_diag(5, ("coral (%s): downloading file: %s\n", s, fw_path));

    while (!done) {
	while (fatm_dump_console(fd, buf, sizeof(buf)) || !done) {

	    sleep(2);

	    switch (state) {
	    case 0:
		coral_diag(6, ("coral (%s): fatm_download_firmware -- "
			"getting attention\n", s));
		write(fd, "\r\n", 2); /* poke the i960 */
		sleep(1);
		write(fd, "\r\n", 2); /* poke the i960 */
		if (strstr(buf, "Mon960")) {
		    state++;
		}
		break;
	    case 1:
		if (0 == (firmware_begin = 
			  fatm_download_direct(fd, s, fw_path))) {

		    coral_diag(0, ("coral: downloading direct failed for %s\n",
			    s));
		    return(-1);
		}
		coral_diag(6, ("coral (%s): fatm_download_firmware -- "
			"firmware start address %x\n", s, firmware_begin));
		sprintf(buf, "go %x\r", firmware_begin);
		if (0 > write(fd, buf, strlen(buf))) {
		    coral_diag(0, ("coral (%s): problem writing to dev: %s\n",
				   s, strerror(errno)));
		    return -1;
		}		    
		state++;
		sleep(3);
		break;
	    case 2:
		driver_mode.flags = iomode->flags;
		driver_mode.first_n = divup(iomode->first_n, ATM_PAYLOAD_SIZE);
		coral_diag(5, ("%s: CORAL_INIT (iomode 0x%x %d)\n",
		    s, driver_mode.flags, driver_mode.first_n));
		if (ioctl(fd, CORAL_INIT, &driver_mode) < 0) {
		    coral_diag(0, ("%s: CORAL_INIT (iomode 0x%x %d): %s\n",
			s, driver_mode.flags, driver_mode.first_n,
			strerror(errno)));
		    fatm_dump_console(fd, buf, sizeof(buf));
		    return -1;
		} else
		    state++;
		sleep(3);
		break;
	    case 3:
		/* clear timestamps ? */
		
		done = 1;
		break;
	    }
	}
	coral_diag(6, ("coral (%s): fatm_download_firmware -- (4)\n", s));
    }
    return(hack);
}

static int coral_fatm_close(coral_source_t *src, int final)
{
    fatm_dump_console(src->fd, NULL, 0);
    return coral_blk_close(src, final);
}

int coral_sendblk(coral_source_t *src, int ndesc)
{
    int result = 0;

    validate_src(src, "coral_sendblk", -1);

    if (!(src->dev_config.iomode.flags & CORAL_TX)) {
	errno = EBADF;
	return -1;
    }
    
    switch (src->type.coral_type) {
    case CORAL_TYPE_POINT:
	coral_diag(0, ("coral: %s: what? you cant send to a point device\n",
	    src->name));
	break;
    case CORAL_TYPE_FATM:
	if ((result = ioctl(src->fd, CORAL_SENDBLK, &ndesc)) < 0) {
/*	    coral_diag(0, ("coral: %s: tx failed: %s\n", src->name, 
		    strerror(errno))); */
	}
	break;
    case CORAL_TYPE_FILE:
	coral_diag(0, ("coral: %s: what? you cant send to a file\n", src->name));
	/* at least not yet */
	break;

    default:
	coral_diag(0, ("coral_sendblk: Unrecognized CORAL type!\n"));
	assert(0);
	result = 0;
    }
    fatm_dump_console(src->fd, NULL, 0);
    return result;
}
#endif /* HAVE_CORAL_FATM */


const coral_src_type_t coral_src_type_fatm = {
    CORAL_TYPE_FATM,
    "fatm",
#ifdef HAVE_CORAL_FATM
    1 /* is_live */,
    1 /* is_buffered */,
    1 /* is_block */,
    0 /* is_interleaved */,
    coral_fatm_init,
    coral_coraldev_start,
    NULL /* read_raw */,
    coral_blk_read_min,
    coral_blk_read_min,
    coral_fatm_nextblk,
    NULL /* release */,
    coral_coraldev_stop,
    coral_fatm_close
#endif /* HAVE_CORAL_FATM */
};

