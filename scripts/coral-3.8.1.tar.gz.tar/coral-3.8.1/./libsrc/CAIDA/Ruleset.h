/* 
 * Copyright 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

#ifndef RULESET_H
#define RULESET_H
#include "Ipv4Network.hh"
#include "IpPrefixPatricia.hh"
#include <list>
#include <vector>
#include <map>
#include <functional>
#include "table_types.h"

#include <iostream>

struct num_range
{
    unsigned int begin;
    unsigned int end;
    num_range(int new_beg, int new_end) : begin(new_beg), end(new_end) {}
};


template <class DATA>
struct rule_t
{
    int priority;
    bool symmetric;
    bool check_ports;
    bool no_ports;
    std::vector<int16_t> protocols;
    std::vector<Ipv4Network> src_nets;
    std::vector<Ipv4Network> dst_nets;
    std::vector<num_range> src_ports;
    std::vector<num_range> dst_ports;
    DATA data;
    rule_t() : priority(50), symmetric(false), check_ports(false),
		no_ports(false) {}
};

template <class DATA>
class Ruleset
{
    typedef std::list< rule_t<DATA> > rule_list;
    typedef typename rule_list::const_iterator rule_list_it;
    typedef std::vector<rule_list_it> rl_it_vec;
    typedef std::map<unsigned int, rl_it_vec> num_map;
    typedef Ipv4PrefixPatricia<rl_it_vec> ip_map;

    public:
    typedef rule_list_it iterator;
    typedef rl_it_vec iterator_vec;
    typedef rule_t<DATA> rule_type;
    void clear()
    {
	rules.clear();
	port_to_it.clear();
	ip_to_it.erase(ip_to_it.begin(), ip_to_it.end());
	no_port_rules.clear();
	proto_rules.clear();
    }
    void add_rule(const rule_type& new_rule);
    rl_it_vec match_rule(const Table::tuple_t& tup);
    rl_it_vec match_rule(const Table::proto_ports_t& tup);
    iterator end() { return rules.end(); }
    static const num_range& all_ports()
    {
	static const num_range wild(0, 65535);
	return wild;
    }
    static const char * ports_to_str(const num_range& ports)
    {
	static char buf[30];
	if (ports.begin == ports.end) {
	    sprintf(buf, "%u", ports.begin);
	} else if (ports.begin == all_ports().begin &&
		    ports.end == all_ports().end)
	{
	    sprintf(buf, "*");
	} else {
	    sprintf(buf, "%u-%u", ports.begin, ports.end);
	}
	return buf;
    }
    static const char * net_to_str(const Ipv4Network& subnet)
    {
	static char buf[30];
	sprintf(buf, "%s/%u", inet_ntoa(subnet.net), subnet.maskLen);
	return buf;
    }
    static const char * proto_to_str(const int16_t& proto)
    {
	static char buf[10];
	if (proto < 0) {
	    sprintf(buf, "*");
	} else {
	    sprintf(buf, "%u", proto);
	}
	return buf;
    }

    protected:
    rule_list rules;

    private:
    num_map port_to_it;
    ip_map ip_to_it;
    rl_it_vec no_port_rules;  // For rules that specifically don't use ports
    rl_it_vec proto_rules;    // For rules that only use protocol
};

// These are all local helper functions
namespace {
    bool num_range_match(const unsigned int& num,
				const std::vector<num_range>& list)
    {
	std::vector<num_range>::const_iterator it;
	for (it = list.begin(); it != list.end(); it++) {
	    if (it->begin <= num && it->end >= num) {
		return true;
	    }
	}
	return false;
    }

    bool proto_match(const uint8_t& num, const std::vector<int16_t>& list)
    {
	std::vector<int16_t>::const_iterator it;
	for (it = list.begin(); it != list.end(); it++) {
	    if (*it < 0) {
		return true;  // Wildcard, always true
	    }
	    if (static_cast<uint8_t>(*it) == num) {
		return true;
	    }
	}
	return false;
    }

    bool ip_match(const in_addr& addr, const std::vector<Ipv4Network>& list)
    {
	if (list.empty()) {
	    return true;
	} // We call no IPs the same as all IPs.
	std::vector<Ipv4Network>::const_iterator it;
	for (it = list.begin(); it != list.end(); it++) {
	    if (it->Matches(addr))
		return true;
	}
	return false;
    }

    template <class DATA>
    bool priority_less(const typename Ruleset<DATA>::iterator& it1,
			const typename Ruleset<DATA>::iterator& it2)
    {
	return it1->priority < it2->priority;
    }

    template <class DATA>
    bool name_less(const typename Ruleset<DATA>::iterator& it1,
			const typename Ruleset<DATA>::iterator& it2)
    {
	return it1->data.name < it2->data.name;
    }

    template <class DATA>
    bool matches(const Table::tuple_t& info, const rule_t<DATA>& rule)
    {
	// Protocol check first
	if (!proto_match(info.ip_proto, rule.protocols)) {
	    return false;
	}

	if (!rule.check_ports || (rule.no_ports && info.ports_ok == 0)) {
	    // Check standard order
	    if (ip_match(info.src, rule.src_nets) &&
		ip_match(info.dst, rule.dst_nets))
	    {
		return true;
	    }

	    // Check with src/dst reversed
	    if (rule.symmetric &&
		ip_match(info.src, rule.dst_nets) &&
		ip_match(info.dst, rule.src_nets))
	    {
		return true;
	    }
	} else if (!rule.no_ports && info.ports_ok != 0) {
	    // Check standard order
	    if (num_range_match(info.sport, rule.src_ports) &&
		num_range_match(info.dport, rule.dst_ports) &&
		ip_match(info.src, rule.src_nets) &&
		ip_match(info.dst, rule.dst_nets))
	    {
		return true;
	    }

	    // Check with src/dst reversed
	    // When matching with IPs, want to keep IP and port matched
	    // pairwise, src IP & port, dst IP & port.
	    if (rule.symmetric &&
		num_range_match(info.sport, rule.dst_ports) &&
		num_range_match(info.dport, rule.src_ports) &&
		ip_match(info.src, rule.dst_nets) &&
		ip_match(info.dst, rule.src_nets))
	    {
		return true;
	    }
	} // else check_ports true, and ports_ok doesn't match rule -> false

	return false;
    }

    template <class DATA>
    bool matches(const Table::proto_ports_t& info, const rule_t<DATA>& rule)
    {
	// Protocol check first
	if (!proto_match(info.ip_proto, rule.protocols)) {
	    return false;
	}

	// Disallow rules that are looking for an IP match
	if ((rule.src_nets.size() >= 1 && rule.src_nets[0].maskLen != 0) ||
	    (rule.dst_nets.size() >= 1 && rule.dst_nets[0].maskLen != 0))
	{
	    return false;
	}

	if (!rule.check_ports || (rule.no_ports && info.ports_ok == 0)) {
	    return true; // Can only match on protocol
	} else if (!rule.no_ports && info.ports_ok != 0) {
	    // Check standard order
	    if (num_range_match(info.sport, rule.src_ports) &&
		num_range_match(info.dport, rule.dst_ports))
	    {
		return true;
	    }

	    // Check with src/dst reversed
	    if (rule.symmetric &&
		num_range_match(info.sport, rule.dst_ports) &&
		num_range_match(info.dport, rule.src_ports))
	    {
		return true;
	    }
	} // else check_ports true, and ports_ok doesn't match rule -> false

	return false;
    }
} // end anonymous namespace

template <class DATA>
void Ruleset<DATA>::add_rule(const rule_t<DATA>& new_rule)
{
    rules.push_back(new_rule);
    rule_list_it rule_pos = --rules.end();
    int idx;
    unsigned int port;
    Ipv4Network net;

    // Only do a port index for those rules with no IP restrictions.
    // A single rule with masklen of 0 is allowed as a wildcard.
    if ((new_rule.src_nets.empty() ||
	(new_rule.src_nets.size() == 1 && new_rule.src_nets[0].maskLen == 0)) &&
	(new_rule.dst_nets.empty() ||
	(new_rule.dst_nets.size() == 1 && new_rule.dst_nets[0].maskLen == 0)))
    {
	if (!new_rule.check_ports ||
		new_rule.src_ports.size() == 1 &&
		new_rule.dst_ports.size() == 1 &&
		new_rule.src_ports[0].begin == all_ports().begin &&
		new_rule.src_ports[0].end == all_ports().end &&
		new_rule.dst_ports[0].begin == all_ports().begin &&
		new_rule.dst_ports[0].end == all_ports().end)
	{ // This is a proto-only rule.
	    proto_rules.push_back(rule_pos);
	} else if (new_rule.no_ports) {
	    no_port_rules.push_back(rule_pos);
	} else { // Normal rule
	    for (idx = 0; idx < new_rule.src_ports.size(); idx++) {
		num_range ports = new_rule.src_ports[idx];

		// Don't include * wildcard.
		if (ports.begin == all_ports().begin &&
		    ports.end == all_ports().end) { continue; }

		for (port = ports.begin; port <= ports.end; port++) {
		    port_to_it[port].push_back(rule_pos);
		}
	    }
	    for (idx = 0; idx < new_rule.dst_ports.size(); idx++) {
		num_range ports = new_rule.dst_ports[idx];

		// Don't include * wildcard.
		if (ports.begin == all_ports().begin &&
		    ports.end == all_ports().end) { continue; }

		for (port = ports.begin; port <= ports.end; port++) {
		    port_to_it[port].push_back(rule_pos);
		}
	    }
	}
    } else { // Index by IP match
	for (idx = 0; idx < new_rule.src_nets.size(); idx++) {
	    net = new_rule.src_nets[idx];
	    ip_to_it[net].push_back(rule_pos);
	}
	for (idx = 0; idx < new_rule.dst_nets.size(); idx++) {
	    net = new_rule.dst_nets[idx];
	    ip_to_it[net].push_back(rule_pos);
	}
    }
}

template <class DATA>
typename Ruleset<DATA>::rl_it_vec
    Ruleset<DATA>::match_rule(const Table::tuple_t& tup)
{
    rl_it_vec poss_matches;
    typename ip_map::iterator ip_it;
    typename num_map::iterator port_it;

    ip_it = ip_to_it.LongestMatch(tup.src.s_addr);
    if (ip_it != ip_to_it.end()) {
	poss_matches.insert(poss_matches.begin(), (*ip_it).second.begin(),
			    (*ip_it).second.end());
    }
    
    ip_it = ip_to_it.LongestMatch(tup.dst.s_addr);
    if (ip_it != ip_to_it.end()) {
	poss_matches.insert(poss_matches.begin(), (*ip_it).second.begin(),
			    (*ip_it).second.end());
    }

    if (tup.ports_ok) {
	port_it = port_to_it.find(tup.sport);
	if (port_it != port_to_it.end()) {
	    poss_matches.insert(poss_matches.begin(), port_it->second.begin(),
				port_it->second.end());
	}
	port_it = port_to_it.find(tup.dport);
	if (port_it != port_to_it.end()) {
	    poss_matches.insert(poss_matches.begin(), port_it->second.begin(),
				port_it->second.end());
	}
    } else {
	poss_matches.insert(poss_matches.begin(), no_port_rules.begin(),
			    no_port_rules.end());
    }

    poss_matches.insert(poss_matches.begin(), proto_rules.begin(),
			proto_rules.end());

    if (poss_matches.empty()) { return poss_matches; }

    std::sort(poss_matches.begin(), poss_matches.end(), name_less<DATA>);
    poss_matches.erase(unique(poss_matches.begin(), poss_matches.end()),
			poss_matches.end());

    rl_it_vec best_matches;
    for (unsigned int idx = 0; idx < poss_matches.size(); idx++) {
	if (matches(tup, *poss_matches[idx])) {
	    best_matches.push_back(poss_matches[idx]);
	}
    }
    std::sort(best_matches.begin(), best_matches.end(), priority_less<DATA>);

    return best_matches;
}

template <class DATA>
typename Ruleset<DATA>::rl_it_vec
    Ruleset<DATA>::match_rule(const Table::proto_ports_t& pp)
{
    rl_it_vec poss_matches;
    typename num_map::iterator port_it;

    if (pp.ports_ok) {
	port_it = port_to_it.find(pp.sport);
	if (port_it != port_to_it.end()) {
	    poss_matches.insert(poss_matches.begin(), port_it->second.begin(),
				port_it->second.end());
	}
	port_it = port_to_it.find(pp.dport);
	if (port_it != port_to_it.end()) {
	    poss_matches.insert(poss_matches.begin(), port_it->second.begin(),
				port_it->second.end());
	}
    } else {
	poss_matches.insert(poss_matches.begin(), no_port_rules.begin(),
			    no_port_rules.end());
    }

    poss_matches.insert(poss_matches.begin(), proto_rules.begin(),
			proto_rules.end());

    if (poss_matches.empty()) { return poss_matches; }

    std::sort(poss_matches.begin(), poss_matches.end(), name_less<DATA>);
    poss_matches.erase(unique(poss_matches.begin(), poss_matches.end()),
			poss_matches.end());

    rl_it_vec best_matches;
    for (unsigned int idx = 0; idx < poss_matches.size(); idx++) {
	if (matches(pp, *poss_matches[idx])) {
	    best_matches.push_back(poss_matches[idx]);
	}
    }
    std::sort(best_matches.begin(), best_matches.end(), priority_less<DATA>);

    return best_matches;
}

#endif // RULESET_H
