/* 
 * Copyright 2000, 2001, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 *
 * $Id: crl_print_pkt.c,v 1.48.4.1 2007/07/02 19:35:26 kkeys Exp $
 *
 */


static const char RCSid[]="$Id: crl_print_pkt.c,v 1.48.4.1 2007/07/02 19:35:26 kkeys Exp $";

#include "config.h"
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <signal.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/in_systm.h>
#include <arpa/inet.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>

#include "libcoral.h"
#include "crl_byteorder.h"

#ifndef TH_ECE
# define TH_ECE 0x40
#endif
#ifndef TH_CWR
# define TH_CWR 0x80
#endif

int layers[2] = { 1, 7 };

static void quit(int sig)
{
    coral_pkt_done = 1;
}

static int cksum_flag = 0;
static int hextime = 0;
static int extra_flag = 0;
static FILE *of;

static void coral_mprint_pkt_file(coral_iface_t *iface,
    const coral_timestamp_t *timestamp, void *ignore,
    coral_pkt_buffer_t *packet, coral_pkt_buffer_t *header,
    coral_pkt_buffer_t *trailer)
{
    /* note: this uses the global variable layers, rather than the passed-in
	layerp */
    coral_fmprint_pkt(of, iface, timestamp, layers[0], layers[1], packet, header, trailer);
}

static coral_pkt_handler pkt_handler = coral_mprint_pkt_file;

static void short_print(coral_iface_t *iface,
    const coral_timestamp_t *timestamp, void *mydata,
    coral_pkt_buffer_t *packet, coral_pkt_buffer_t *header,
    coral_pkt_buffer_t *trailer)
{
    struct timespec tspec;
    coral_pkt_buffer_t ippkt, L4pkt;
    struct ip *ip;
    struct udphdr *udp;
    struct tcphdr *tcp;

    CORAL_TIMESTAMP_TO_TIMESPEC(iface, timestamp, &tspec);
    fprintf(of, "%2d  ", coral_interface_get_number(iface));
    if (hextime) {
	coral_timestamp_t host_order_ts;
	coral_read_clock_order(iface, timestamp, &host_order_ts);
	fprintf(of, "%08x %08x", host_order_ts.i[0], host_order_ts.i[1]);
    } else {
	fprintf(of,"%10ld.%06ld", tspec.tv_sec, tspec.tv_nsec/1000);
    }
    if (coral_get_payload_by_proto(packet, &ippkt, CORAL_NETPROTO_IP) < 0)
	goto end;
    ip = (struct ip*)ippkt.buf;
    /* If a field isn't included in the caplen, we can't print it. */
    fprintf(of, " %-15s", coral_field_fits(ip,ip_src,ippkt.caplen) ?
	inet_ntoa(ip->ip_src) : "");
    fprintf(of, " %-15s", coral_field_fits(ip,ip_dst,ippkt.caplen) ?
	inet_ntoa(ip->ip_dst) : "");
    if (!coral_field_fits(ip, ip_len, ippkt.caplen)) goto end;
    fprintf(of, " %5d", ntohs(ip->ip_len));
    if (!coral_field_fits(ip, ip_p, ippkt.caplen)) goto end;
    fprintf(of, " %3d", ip->ip_p);
    if (extra_flag) {
	fprintf(of, " %02x", ip->ip_tos);
	if (!coral_field_fits(ip, ip_id, ippkt.caplen)) goto end;
	fprintf(of, " %5u", ntohs(ip->ip_id));
	if (!coral_field_fits(ip, ip_ttl, ippkt.caplen)) goto end;
	fprintf(of, " %3u", ip->ip_ttl);
    }

    if (cksum_flag) {
	uint32_t hl = ip->ip_hl*4;
	if (hl > ippkt.caplen) {
	    fprintf(of, "  ?");
	} else {
	    register uint32_t cksum;
	    cksum = coral_in_cksum_add(0, ip, hl);
	    fprintf(of, " %2d", coral_in_cksum_result(cksum) == 0);
	}
    }

    if (!coral_field_fits(ip, ip_p, ippkt.caplen)) goto end;
    /* don't interpret fragment as header */
    if (crl_nptohs(&ip->ip_off) & IP_OFFMASK) goto end;

    switch (ip->ip_p) {
    case IPPROTO_TCP:
	if (coral_get_payload(&ippkt, &L4pkt) < 0) goto end;
	tcp = (struct tcphdr*)L4pkt.buf;
	if (!coral_field_fits(tcp, th_dport, L4pkt.caplen)) goto end;
	fprintf(of, " %5d %5d", ntohs(tcp->th_sport), ntohs(tcp->th_dport));
	if (extra_flag) {
	    if (!coral_field_fits(tcp, th_seq, L4pkt.caplen)) goto end;
	    fprintf(of, " %08lx", ntohl(tcp->th_seq));
	    if (!coral_field_fits(tcp, th_flags, L4pkt.caplen)) goto end;
	    if (tcp->th_flags & TH_ACK) {
		fprintf(of, " %08lx", ntohl(tcp->th_ack));
	    } else {
		fprintf(of, " %-8s", "-");
	    }
	    fprintf(of, " %c%c%c%c%c%c",
		tcp->th_flags & TH_FIN ? 'F' : '-',
		tcp->th_flags & TH_SYN ? 'S' : '-',
		tcp->th_flags & TH_RST ? 'R' : '-',
		tcp->th_flags & TH_PUSH ? 'P' : '-',
		tcp->th_flags & TH_ECE ? 'E' : '-',
		tcp->th_flags & TH_CWR ? 'C' : '-');
	}
	break;
    case IPPROTO_UDP:
	if (coral_get_payload(&ippkt, &L4pkt) < 0) goto end;
	udp = (struct udphdr*)L4pkt.buf;
	if (!coral_field_fits(udp, uh_dport, L4pkt.caplen)) goto end;
	fprintf(of, " %5d %5d", ntohs(udp->uh_sport), ntohs(udp->uh_dport));
	break;
    case IPPROTO_ICMP:
	if (coral_get_payload(&ippkt, &L4pkt) < 0) goto end;
	if (L4pkt.caplen < 2) goto end;
	/* <ip_icmp.h> isn't portable; easier to grab type/code manually. */
	fprintf(of, " %5d %5d", L4pkt.buf[0], L4pkt.buf[1]);
	break;
    }
end:
    fputc('\n', of);
}

static void usage(const char *name)
{
    coral_usage(name, "[options] <source>...\n"
	"Options:\n"
	"-P        do not allow partial packets\n"
	"-p        allow partial packets\n"
	"-m<n>     skip information about layers below <n> (default %d)\n"
	"-l<n>     interpret up to layer <n> (default %d)\n"
	"-s        print only IPv4 information, in short format\n"
	"-c        print and verify IP checksums\n"
	"-x        with -s, print timestamps in native hex format\n"
	"-e        with -s, print extra fields: IP ToS, ID, TTL; TCP seq, ack, flags\n"
	"-o<file>  print to <file> (default: stdout; supports file rotation)\n",
	layers[0], layers[1]);
}

static int open_outfile_header(const char *name, const char *realname, void *info)
{
    FILE *file;
    if (coral_rf_cb_open_file(name, realname, info) < 0) return -1;
    file = *(FILE**)info;
    if (pkt_handler == short_print) {
	fprintf(file, "#%2s %9s%-8s %-15s %-15s %5s %3s %s%s%5s %5s%s\n",
	    "if", "", "time", "src addr", "dst addr", "len", "pro",
	    extra_flag ? "ts ip.id ttl " : "",
	    cksum_flag ? "ck " : "",
	    "sport", "dport",
	    extra_flag ? " tcp.seq  tcp.ack  flags" : "");
    }
    return 0;
}

int main(int argc, char *argv[])
{
    int n, opt;
    const char *ofname = NULL;
    coral_rotfile_t *rf;
    struct timeval interval = {0,0}; /* for file rotation */

    signal(SIGINT, quit);

    coral_set_api(CORAL_API_PKT);
    coral_set_iomode(0, CORAL_RX_UNKNOWN, -1, 0);
    coral_set_duration(0);
    coral_set_interval(&interval);

    while ((opt = getopt(argc, argv, "C:pPm:l:scxeo:")) >= 0) {
        if (opt == 'C') {
            if (coral_config_command(optarg) < 0) {
		usage(argv[0]);
                exit(-1);
	    }
        } else if (opt == 'P') {
	    coral_set_options(CORAL_OPT_PARTIAL_PKT, 0);
        } else if (opt == 'p') {
	    coral_set_options(0, CORAL_OPT_PARTIAL_PKT);
        } else if (opt == 's') {
	    pkt_handler = short_print;
        } else if (opt == 'e') {
	    extra_flag = 1;
        } else if (opt == 'c') {
	    cksum_flag = 1;
	    coral_set_options(0, CORAL_OPT_IP_CKSUM);
        } else if (opt == 'x') {
	    hextime = 1;
        } else if (opt == 'l') {
	    layers[1] = atoi(optarg);
	    if (layers[1] < 1 || layers[1] > 7) {
                fprintf(stderr, "%s: layer must be between 1 and 7\n", argv[0]);
                exit(-1);
	    }
        } else if (opt == 'm') {
	    layers[0] = atoi(optarg);
	    if (layers[0] < 1 || layers[0] > 7) {
                fprintf(stderr, "%s: layer must be between 1 and 7\n", argv[0]);
                exit(-1);
	    }
	} else if (opt == 'o') {
	    ofname = strdup(optarg);
        } else {
	    usage(argv[0]);
            exit(-1);
        }
    }

    if (!ofname)
	ofname = "-";

    while (optind < argc) {
        if (!coral_new_source(argv[optind]))
            exit(-1);
        optind++;
    }

    if ((n = coral_open_all()) < 0)
        exit(-1);
    if (n == 0) {
	coral_diag(0, ("no sources.\n"));
	exit(0);
    }

    coral_get_interval(&interval);

    if (coral_start_all() < 0)
        exit(-1);

    rf = coral_rf_open(&of, ofname, NULL, CORAL_ROT_AUTO, &open_outfile_header, &coral_rf_cb_close_file);
    if (!rf)
	exit(-1);


    if (coral_read_pkts(NULL, NULL, pkt_handler, NULL, NULL, &interval, layers) < 0)
	exit(-1);

    coral_rf_close(rf);
    coral_stop_all();
    coral_close_all();
    return 0;
}
