/* 
 * Copyright 1999, 2000, 2001, 2002, 2003, 2004, 2005, 2006, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 *
 * $Id: coral_print.c,v 1.10 2007/06/06 18:17:54 kkeys Exp $
 *
 */

#include "config.h"
#include "coraldefs.h"
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <ctype.h>

#include "libcoral.h"
#include "libcoral_priv.h"

#ifdef HAVE_LIBZ
# include <zlib.h>
#endif


static const char RCSid[] = "$Id: coral_print.c,v 1.10 2007/06/06 18:17:54 kkeys Exp $";

int coral_verbosity = 1;
FILE *coral_errfile = NULL;

void crl_sncat(char **buf, int *len, const char *src, int srclen, const char *esc)
{
    for ( ; *len > 0 && srclen > 0; src++, srclen--) {
	if (!isprint(*src)) {
	    crl_snprintf(buf, len, "\\%03o", (unsigned char)*src);
	} else {
	    if (*src == '\\' || (esc && strchr(esc, *src)))
		crl_snappend(buf, len, '\\');
	    crl_snappend(buf, len, *src);
	}
    }
}

#ifdef HAVE_VSNPRINTF
/* like snprintf(), execpt *buf and *len are modified. */
int crl_snprintf(char **buf, int *len, const char *fmt, ...)
{
    va_list ap;
    int n;

    va_start(ap, fmt);
    n = vsnprintf(*buf, *len, fmt, ap);
    va_end(ap);
    if (n < 0 || n >= *len) {
	*len = 0;
    } else {
	*buf += n;
	*len -= n;
    }
    return n;
}

#else
int crl_snprintf(char **buf, int *len, const char *fmt, ...)
{
    if (*len > 0)
	**buf = '\0';
    return -1;
}
#endif

/* This preserves errno so it's safe to use to print diagnostics in functions
 * that need to leave errno set.  (Of course, if the printf itself fails, we
 * won't know why.) */
int coral_printf(const char *fmt, ...)
{
    va_list ap;
    int result, err;

    err = errno;
    va_start(ap, fmt);
    result = vfprintf(coral_errfile ? coral_errfile : stderr,
	fmt, ap);
    va_end(ap);
    errno = err;
    return result;
}

int coral_puts(const char *str)
{
    int result, err;

    err = errno;
    result = fputs(str, coral_errfile ? coral_errfile : stderr);
    fputc('\n', coral_errfile ? coral_errfile : stderr);
    errno = err;
    return result;
}

const char *coral_strerror(void *data, int err)
{
    static char buf[80];
    const char *result;

    if (err >= 0 && (result = (strerror)(err)))
	return result;
    switch (err) {
	case CORAL_ERROR:	return "Error -1";
	case CORAL_ENOPROTO:	return "Unsupported protocol";
	case CORAL_ELENGTH:	return "Packet too short";
	case CORAL_ESYNTAX:	return "Packet syntax error";
	case CORAL_ETRUNCBLK:	return "truncated block";
	case CORAL_EBADIFNUM:	return "bad interface number";
	case CORAL_EBADTIME:	return "bad timestamp";
	case CORAL_EGZIP:
#ifdef HAVE_LIBZ
	    if (data) {
		result = gzerror(data, &err);
		if (err == Z_ERRNO) return coral_strerror(NULL, errno);
		if (result) {
		    sprintf(buf, "gzip error: %.*s", (int)sizeof(buf)-13,
			result);
		    return buf;
		}
	    }
#endif
	    return "gzip error";
	case CORAL_EPCAP:	return "pcap error";
	default:
	    sprintf(buf, "Unknown error %d", err);
	    return buf;
    }
}

void coral_snprint_data(char **dumpbuf, int *buflen, int indent,
    const u_char *data, int len)
{
    int i;

    while (len > 0 && *buflen > 0) {
	crl_snprintf(dumpbuf, buflen, "%*s", indent, "");
	for (i = 0; i < 16; i++) {
	    if (i && (i % 4 == 0))
		crl_snappend(dumpbuf, buflen, ' ');
	    if (i < len)
		crl_snprintf(dumpbuf, buflen, "%02x ", data[i]);
	    else
		crl_snprintf(dumpbuf, buflen, "   ");
	}
	crl_snprintf(dumpbuf, buflen, " |");
	for (i = 0; i < 16 && i < len; i++) {
	    crl_snappend(dumpbuf, buflen, isprint(data[i]) ? data[i] : '.');
	}
	crl_snprintf(dumpbuf, buflen, "|\n");
	len -= 16;
	data += 16;
    }
}

void coral_fprint_data(FILE *file, int indent, const u_char *data, int len)
{
    char buf[81], *bufp;
    int buflen = sizeof(buf);

    while (len > 0) {
	buflen = sizeof(buf);
	bufp = buf;
	coral_snprint_data(&bufp, &buflen, indent, data, len > 16 ? 16 : len);
	fputs(buf, file);
	len -= 16;
	data += 16;
    }
}

/* defined as a macro for speed, and as a function in case a ptr is needed */
void (coral_print_data)(int indent, const u_char *data, int len)
{
    coral_print_data(indent, data, len);
}

#ifndef cstrcmp
/* case-insensitive strcmp() */
int cstrcmp(const char *s, const char *t)
{
    register int diff = 0;
    while ((*s || *t) && !(diff = tolower(*s) - tolower(*t))) s++, t++;
    return diff;
}
#endif

