/* 
 * Copyright 2003, 2004, 2007 The Regents of the University of California 
 * All Rights Reserved 
 * 
 * Permission to use, copy, modify and distribute any part of this
 * CoralReef software package for educational, research and non-profit
 * purposes, without fee, and without a written agreement is hereby
 * granted, provided that the above copyright notice, this paragraph
 * and the following paragraphs appear in all copies.
 * 
 * Those desiring to incorporate this into commercial products or use
 * for commercial purposes should contact the Technology Transfer
 * Office, University of California, San Diego, 9500 Gilman Drive, La
 * Jolla, CA 92093-0910, Ph: (858) 534-5815, FAX: (858) 534-7345.
 * 
 * IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY
 * PARTY FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL
 * DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF THE UNIVERSITY OF CALIFORNIA HAS BEEN ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 * 
 * THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE
 * UNIVERSITY OF CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE,
 * SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY
 * OF CALIFORNIA MAKES NO REPRESENTATIONS AND EXTENDS NO WARRANTIES
 * OF ANY KIND, EITHER IMPLIED OR EXPRESS, INCLUDING, BUT NOT LIMITED
 * TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY OR FITNESS FOR A
 * PARTICULAR PURPOSE, OR THAT THE USE OF THE SOFTWARE WILL NOT INFRINGE
 * ANY PATENT, TRADEMARK OR OTHER RIGHTS.
 * 
 * The CoralReef software package is developed by the CoralReef
 * development team at the University of California, San Diego under
 * the Cooperative Association for Internet Data Analysis (CAIDA)
 * Program. Support for this effort is provided by the CAIDA grant
 * NCR-9711092, DARPA NGI Contract N66001-98-2-8922, DARPA NMS Grant
 * N66001-01-1-8909, and by CAIDA members.
 * 
 * Report bugs and suggestions to coral-bugs@caida.org.
 */

/*
 *
 * $Id: crl_attack.cc,v 1.16 2007/06/06 18:17:29 kkeys Exp $
 *
 */

#include "config.h"
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
#include <time.h>
#include <signal.h>
#include <errno.h>
#include <netinet/in.h>
#include <netinet/in_systm.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <netinet/udp.h>

#ifndef CAN_CONVERT_TO_PCAP
int main(int argc, char *argv[])
{
    fprintf(stderr, "%s requires pcap_open_dead() or <pcap-int.h>, "
	"which were not available when CoralReef was installed.\n",
	argv[0]);
    return -1;
}
#else

#include <pcap.h>
#include "libcoral.h"

static coral_rf_info_pcap_dump_t pdinfo;
static int64_t pkt_count = 0;
//static uint64_t n_pkts = 0;		// # pkts on "wire" (for should_skip())

struct {
    double worm_rate;
    double ddos_rate;
    long seed;
    int sample;
    int seeded;
} config;

static void quit(int sig)
{
    coral_pkt_done = 1;
}


static inline void write_pkt(pcap_dumper_t *pcap_dumper,
    struct pcap_pkthdr *pphr, const char *buf)
{
    pcap_dump((unsigned char*)pcap_dumper, pphr, (unsigned char*)buf);
}

static inline void send_sample_thresh(coral_iface_t *iface, const double &t,
    uint32_t thresh)
{
    struct pcap_pkthdr pphr;
    uint32_t nthresh = htonl(thresh);
    pphr.ts.tv_sec = long(t);
    pphr.ts.tv_usec = long((t - pphr.ts.tv_sec) * 1000000);
    pphr.caplen = 4;
    pphr.len = 4;
    write_pkt(pdinfo.pcap_dumper, &pphr, (char*)&nthresh);
}

#define MAXDEPTH 1048576 /* 64MB buffer of 64B records */
#define CHECK 65536 /* nice round number, smaller than MAXDEPTH/8 */
static inline int32_t should_skip(coral_iface_t *iface, double t_pkt)
{
    const char *msg;
    struct timeval tv;
    double t_read, dt_read, dt_pkt;
    double rate_prod = 0;		// production rate (pkts/s)
    static uint64_t n_cons = 0;		// # pkts consumed (dequeued) by reader
    static uint64_t n_prod = 0;		// # pkts produced (enqueued) by "card"
    static double old_t_pkt = 0;	// previous pkt time
    static double old_t_read = 0;	// previous reader time
    static double sample_prob = 1;	// sampling probability, [0,1]
    static uint32_t sample_thresh = 0x80000000ul;
    static uint64_t old_n_cons = 0;	// # pkts consumed (dequeued) by reader
    static double rate_cons = 0;	// last known consumption rate (pkts/s)
    static uint64_t dprod = 0;		// # pkts produced since last check
    static uint64_t dpkts = 0;		// # pkts on "wire" since last check

    if (!config.sample) return 0;
    if (n_prod % CHECK == 0) {
	gettimeofday(&tv, NULL);
	t_read = timevaltodouble(&tv);
	if (old_t_pkt > 0) {
	    // dt_read would not be known by the card; we use it to simulate
	    // depth, which would be known.
	    uint32_t old_thresh = sample_thresh;
	    dt_pkt = (t_pkt - old_t_pkt);
	    dt_read = (t_read - old_t_read);
	    uint64_t dcons = uint64_t(dprod * dt_pkt / dt_read);
	    n_cons += dcons;
	    int32_t depth = n_prod - n_cons;
	    if (depth < 0) {
		n_cons = n_prod;
		dcons = n_cons - old_n_cons;
		depth = 0;
	    }
	    rate_prod = dprod / dt_pkt;
	    if (depth > 0) {
		rate_cons = dcons / dt_pkt;
	    }

	    // Calculate sample_prob using only parameters card would know.
	    if (depth == 0) {
		// doing well: raise rate
		msg = "good";
		if (sample_prob < 1) {
		    sample_prob = 1.05 * sample_prob * rate_cons / rate_prod;
		    if (sample_prob > 1) sample_prob = 1;
		}
	    } else if (depth < MAXDEPTH/4) {
		// falling slightly behind: wait and see
		msg = "not bad";
	    } else if (depth < MAXDEPTH/2) {
		// falling behind: lower rate to match what reader can handle
		msg = "behind";
		if (rate_cons > rate_prod) {
		    // expect consumer to catch up
		} else {
		    sample_prob = sample_prob * rate_cons / rate_prod;
		    if (sample_prob > 1) sample_prob = 1;
		}
	    } else {
		// falling far behind: lower rate enough for reader to catch up
		msg = (depth <= MAXDEPTH) ? "far behind" : "ERR: FULL";
		sample_prob = sample_prob * (MAXDEPTH - depth) / MAXDEPTH;
	    }
	    sample_thresh = uint32_t(0x80000000ul * sample_prob);
	    if (sample_thresh != old_thresh)
		send_sample_thresh(iface, t_pkt, sample_thresh);
	    coral_diag(2, ("%10s: %7d  %7" PRIu64
		"  %.6f %11" PRIu64 " %6" PRIu64 " %14.6f"
		"  %.6f %11" PRIu64 " %6" PRIu64 " %14.6f"
		"  %.06f\n",
		msg, depth, dpkts,
		dt_pkt, n_prod, dprod, rate_prod,
		dt_read, n_cons, dcons, rate_cons,
		sample_prob));
	} else {
	    coral_diag(2, ("%10s  %7s  %7s"
		"  %8s %11s %6s %14s"
		"  %8s %11s %6s %14s"
		"  %8s\n",
		"", "depth", "dpkts",
		"dt_pkt", "n_prod", "dprod", "rate_prod",
		"dt_read", "n_cons", "dcons", "rate_cons",
		"new_prob"));
	}
	old_t_pkt = t_pkt;
	old_t_read = t_read;
	old_n_cons = n_cons;
	dpkts = 1;
	dprod = 1;
    }
    
    uint32_t skip = uint32_t(ceil(dpkts * sample_prob) / sample_prob - dpkts);
    dpkts += skip + 1;
    //n_pkts += skip + 1;
    n_prod++;
    dprod++;
    if (sample_prob < 1) coral_diag(3, ("skip %d\n", skip));
    return skip;
}

static void pkthandler(coral_iface_t *iface, const coral_timestamp_t *timestamp,
    void *userdata, coral_pkt_buffer_t *pkt, coral_pkt_buffer_t *header,
    coral_pkt_buffer_t *trailer)
{
    struct atkpkt_t {
	char linklayer[32];
        struct ip ip;
        struct tcphdr tcp;
        atkpkt_t() {
            ip.ip_v = 4;
            ip.ip_hl = 5;
            ip.ip_tos = 0;
	    ip.ip_len = htons(sizeof(atkpkt_t) - sizeof(linklayer));
            ip.ip_off = htons(0);
            ip.ip_ttl = 255;
            ip.ip_p = IPPROTO_TCP;
            tcp.th_off = sizeof(struct tcphdr)/4;
            tcp.th_flags = TH_SYN;
        }
    };

    static atkpkt_t atkpkt;
    static coral_pkt_buffer_t pkt_buffer;
    static double begin = 0;
    static uint32_t worm_count = 0, ddos_count = 0;
    static coral_pkt_result_t held_pkt_result;
    static coral_interval_result_t held_interval_result;
    static bool held = false;
    static int linklen;
    static int32_t skip = -1;

    uint32_t worm_needed = 0, ddos_needed = 0;
    int offset;
    struct pcap_pkthdr pphr;
    double now, t;
    coral_pkt_buffer_t netpkt;

// address repeats every 2^24, port repeats every 2^16-1, creating a cycle
// length of 1099494850570.  (It would take almost 45 hours to send that many
// minimum-length packets on OC48.)
#define simaddr(count) htonl(0x0A000000 | (count & 0x00FFFFFF))
#define simport(count) ((count % 0xFFFF) + 1)

    now = coral_read_clock_double(iface, timestamp);
    if (begin == 0 && coral_get_payload_by_layer(pkt, &netpkt, 3) == 0) {
	linklen = netpkt.buf - pkt->buf;
	memcpy((char*)&atkpkt.ip - linklen, pkt->buf, linklen);
	begin = now;
    } else {
	worm_needed = (uint32_t)((now - begin) * config.worm_rate);
	ddos_needed = (uint32_t)((now - begin) * config.ddos_rate);
    }

    atkpkt.ip.ip_src.s_addr = htonl(0x7F000001); // 127.0.0.1
    atkpkt.tcp.th_dport = htons(666);

    while (worm_count < worm_needed) {
	t = begin + (worm_count + 1) / config.worm_rate;
	if (skip < 0)
	    skip = should_skip(iface, t);
	if (skip >= worm_needed - worm_count) {
	    skip -= worm_needed - worm_count;
	    pkt_count += worm_needed - worm_count;
	    worm_count = worm_needed;
	    break;
	} else {
	    pkt_count += skip;
	    worm_count += skip;
	}
	skip = -1;
        worm_count++;
	pkt_count++;

        atkpkt.ip.ip_dst.s_addr = simaddr(worm_count);
	atkpkt.tcp.th_sport = simport(worm_count);
        pkt_buffer.caplen = pkt_buffer.totlen =
	    ntohs(atkpkt.ip.ip_len) + linklen;
        pkt_buffer.buf = (const char *)(&atkpkt.ip) - linklen;
        pkt_buffer.protocol = CORAL_NETPROTO_IP;

	offset = coral_pkt_to_pcap(iface, NULL, &pkt_buffer, (pcap_t*)userdata,
	    &pphr);
	pphr.ts.tv_sec = long(t);
	pphr.ts.tv_usec = long((t - pphr.ts.tv_sec) * 1000000);
	write_pkt(pdinfo.pcap_dumper, &pphr, pkt_buffer.buf + offset);
    }

    atkpkt.ip.ip_dst.s_addr = htonl(0x7F000001); // 127.0.0.1
    atkpkt.tcp.th_dport = htons(80);

    while (ddos_count < ddos_needed) {
	t = begin + (ddos_count + 1) / config.ddos_rate;
	if (skip < 0)
	    skip = should_skip(iface, t);
	if (skip >= ddos_needed - ddos_count) {
	    skip -= ddos_needed - ddos_count;
	    pkt_count += ddos_needed - ddos_count;
	    ddos_count = ddos_needed;
	    break;
	} else {
	    pkt_count += skip;
	    ddos_count += skip;
	}
	skip = -1;
        ddos_count++;
	pkt_count++;

        atkpkt.ip.ip_src.s_addr = simaddr(ddos_count);
	atkpkt.tcp.th_sport = simport(ddos_count);
        pkt_buffer.caplen = pkt_buffer.totlen =
	    ntohs(atkpkt.ip.ip_len) + linklen;
        pkt_buffer.buf = (const char *)(&atkpkt.ip) - linklen;
        pkt_buffer.protocol = CORAL_NETPROTO_IP;

	offset = coral_pkt_to_pcap(iface, NULL, &pkt_buffer, (pcap_t*)userdata,
	    &pphr);
	pphr.ts.tv_sec = long(t);
	pphr.ts.tv_usec = long((t - pphr.ts.tv_sec) * 1000000);
	write_pkt(pdinfo.pcap_dumper, &pphr, pkt_buffer.buf + offset);
    }

    pkt_count++;
    if (skip < 0)
	skip = should_skip(iface, now);
    if (skip > 0) {
	skip--;
	return;
    }

    skip--;
    offset = coral_pkt_to_pcap(iface, timestamp, pkt, (pcap_t*)userdata, &pphr);
    if (offset < 0) return;
    write_pkt(pdinfo.pcap_dumper, &pphr, pkt->buf + offset);
}

static void usage(const char *name)
{
    coral_usage(name, "[-o <dumpfile>] [-i<N>] [-f \"<expr>\"] <source>...\n"
	"-W<rate>     simulate a worm with <rate> pkts/s\n"
	"-D<rate>     simulate a random src DDoS with <rate> pkts/s\n"
	"-s           sample if reader doesn't keep up\n"
	"-S<seed>     set random seed\n"
	"-o<file>     dump packets to <file> in pcap binary format (default: stdout)\n"
	"-i<N>        read from interface <N> (default: 0)\n"
	"-r           write raw IP, discarding link layer\n"
	"\n"
	"If a nonzero interval is given and the output filename contains '%%',\n"
	"the output file will rotate every interval.\n");
}

int main(int argc, char *argv[])
{
    int retval = 0;
    int n, opt;
    const char *ofname = NULL;
    coral_iface_t *iface;
    int iface_id = -1;
    int raw = 0;
    coral_rotfile_t *rf;
    struct timeval interval = {0,0}; /* for file rotation */

    signal(SIGINT, quit);

    coral_set_api(CORAL_API_PKT);
#if 0
    coral_set_max_sources(1);  /* There can be only one */
#endif

    /* If you want only full captures, override on command line */
    coral_set_options(0, CORAL_OPT_PARTIAL_PKT | CORAL_OPT_SORT_TIME);

    coral_set_duration(0);
    coral_set_interval(&interval);
    /*coral_set_iomode(0, CORAL_RX_USER_ALL, -1);*/

    while ((opt = getopt(argc, argv, "C:o:i:rW:D:S:s")) >= 0) {
	switch (opt) {
        case 'C':
            if (coral_config_command(optarg) < 0)
                exit(-1);
	    break;
        case 'o':
	    ofname = strdup(optarg);  break;
        case 'i':
	    iface_id = atoi(optarg);  break;
        case 'r':
	    raw = 1;  break;
        case 'W':
            config.worm_rate = atof(optarg);
            break;
        case 'D':
            config.ddos_rate = atof(optarg);
            break;
        case 'S':
            config.seed = strtol(optarg, NULL, 10);
            config.seeded = 1;
            break;
        case 's':
            config.sample = 1;
            break;
        default:
            usage(argv[0]);
            exit(-1);
        }
    }

    if (config.worm_rate && config.ddos_rate) {
	coral_diag(0, ("can not simulate worm and DDoS simultaneously.\n"));
	exit(1);
    }
    while (optind < argc) {
        if (!coral_new_source(argv[optind]))
            exit(-1);
        optind++;
    }

    if (config.sample) {
	if (!config.seeded)
	    config.seed = getpid() ^ time(NULL);
	srandom(config.seed);
    }

    if ((n = coral_open_all()) < 0)
        exit(-1);
    if (n == 0) {
	coral_diag(0, ("no sources.\n"));
	exit(0);
    }

    coral_get_interval(&interval);

    iface = coral_next_interface(NULL);
    if (iface_id >= 0) {
	while (iface && coral_interface_get_number(iface) != iface_id)
	    iface = coral_next_interface(iface);
	if (!iface) {
	    coral_diag(0, ("iface %d not found\n", iface_id));
	    exit(-1);
	}
    }

    if (coral_start_all() < 0)
        exit(-1);

    if (!ofname)
	ofname = "-";
    pdinfo.pcap = raw ? coral_iface_to_pcapp_raw(iface) :
	coral_iface_to_pcapp(iface);
    if (!pdinfo.pcap)
	exit(-1);

    rf = coral_rf_open_pcap_dump(&pdinfo, ofname, "", CORAL_ROT_AUTO);
    if (!rf)
	exit(-1);

    if (coral_read_pkts(NULL, iface_id >= 0 ? iface : NULL, pkthandler,
	NULL, NULL, &interval, pdinfo.pcap) < 0)
	    retval = errno;

    //coral_diag(0, ("n_pkts:    %" PRId64 "\n", n_pkts));
    coral_diag(0, ("pkt_count: %" PRId64 "\n", pkt_count));

    coral_rf_close(rf);
    coral_stop_all();
    coral_close_all();

    exit(retval);
}

#endif /* HAVE_PCAP_INT_H */
